# Diagnostic decision
Both diagnostic versions executed verified complete App operations; no production
change or runtime acceptance is claimed. Nested Instant/counter costs and codegen
perturbation prohibit adding inclusive rows or calling them exact CPU shares.
Response handler/construction and Service ready pinned-packet send are near the timer floor. SmallDevice async finish_send uses a different mapped helper and is not covered by slot7; a zero count is missing coverage, not zero cost.
Service async has material work before/after dispatch, including two next-timeout
scans. Do not optimize constructor microcosts merely from source appearances.

A distinct packet-owner overlap remains worth implementing: DedupEntry reserves
256 inline replay bytes plus an optional TX pin even though its public builders
make them mutually exclusive. This makes each history row and its copies larger;
new/with_tx_pin also represent an inactive zeroed replay array. Overlay these
alternatives with a safe private enum, keep REPLAY_MAX256, row counts and pin
release behavior. Measure complete App runtime and retained memory together.
No claim that this owner dominates the diagnostic; lower memory is independently
checkable and runtime acceptance still uses the unchanged complete-App gates.
Do not reuse or retest the rejected receive-side variants.

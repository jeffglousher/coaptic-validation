
D:\CoapticCurrent\short-inline-replay-20261106\active-bytes\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14000b240:     	pushq	%rbp
14000b241:     	movq	%rsp, %rbp
14000b244:     	movq	0x20(%rdx), %rax
14000b248:     	movups	(%rdx), %xmm0
14000b24b:     	movups	0x10(%rdx), %xmm1
14000b24f:     	movups	%xmm1, 0x10(%rcx)
14000b253:     	movups	%xmm0, (%rcx)
14000b256:     	movq	%rax, 0x20(%rcx)
14000b25a:     	movb	$0x1, 0x28(%rcx)
14000b25e:     	movb	%r9b, 0x29(%rcx)
14000b262:     	movups	(%r8), %xmm0
14000b266:     	movups	0x10(%r8), %xmm1
14000b26b:     	movups	0x20(%r8), %xmm2
14000b270:     	movups	0x30(%r8), %xmm3
14000b275:     	movups	%xmm0, 0x2a(%rcx)
14000b279:     	movups	%xmm1, 0x3a(%rcx)
14000b27d:     	movups	%xmm2, 0x4a(%rcx)
14000b281:     	movups	%xmm3, 0x5a(%rcx)
14000b285:     	movups	0x40(%r8), %xmm0
14000b28a:     	movups	%xmm0, 0x6a(%rcx)
14000b28e:     	movups	0x50(%r8), %xmm0
14000b293:     	movups	%xmm0, 0x7a(%rcx)
14000b297:     	movups	0x60(%r8), %xmm0
14000b29c:     	movups	%xmm0, 0x8a(%rcx)
14000b2a3:     	movups	0x70(%r8), %xmm0
14000b2a8:     	movups	%xmm0, 0x9a(%rcx)
14000b2af:     	popq	%rbp
14000b2b0:     	retq

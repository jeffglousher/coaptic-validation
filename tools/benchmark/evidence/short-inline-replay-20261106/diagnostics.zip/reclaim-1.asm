
D:\CoapticCurrent\short-inline-replay-20261106\active-bytes\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009e680:     	pushq	%rbp
14009e681:     	pushq	%r15
14009e683:     	pushq	%r14
14009e685:     	pushq	%r13
14009e687:     	pushq	%r12
14009e689:     	pushq	%rsi
14009e68a:     	pushq	%rdi
14009e68b:     	pushq	%rbx
14009e68c:     	subq	$0x218, %rsp            # imm = 0x218
14009e693:     	leaq	0x80(%rsp), %rbp
14009e69b:     	movaps	%xmm6, 0x180(%rbp)
14009e6a2:     	leaq	0xfe0(%rcx), %r8
14009e6a9:     	leaq	0x1970(%rcx), %rsi
14009e6b0:     	leaq	0x1998(%rcx), %rax
14009e6b7:     	xorl	%r10d, %r10d
14009e6ba:     	movl	$0x1, %r11d
14009e6c0:     	xorl	%r9d, %r9d
14009e6c3:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009e6ca:     	addq	%rax, %rdi
14009e6cd:     	jmp	0x14009e6e0 <.text+0x9d6e0>
14009e6cf:     	nop
14009e6d0:     	incq	%r10
14009e6d3:     	addq	$0x130, %rdi            # imm = 0x130
14009e6da:     	cmpq	$0x4, %r10
14009e6de:     	je	0x14009e72a <.text+0x9d72a>
14009e6e0:     	cmpl	$0x0, 0x1e30(%rcx,%r10,4)
14009e6e9:     	je	0x14009e6d0 <.text+0x9d6d0>
14009e6eb:     	cmpb	$0x2, -0xe(%rdi)
14009e6ef:     	je	0x14009e6d0 <.text+0x9d6d0>
14009e6f1:     	cmpb	$0x3, (%rdi)
14009e6f4:     	movq	-0x8(%rdi), %rdi
14009e6f8:     	setne	%bl
14009e6fb:     	testq	%rdi, %rdi
14009e6fe:     	sete	%r15b
14009e702:     	orb	%bl, %r15b
14009e705:     	cmpq	%r14, %rdi
14009e708:     	setae	%bl
14009e70b:     	andb	%r9b, %bl
14009e70e:     	testb	%r15b, %r15b
14009e711:     	cmoveq	%r11, %r9
14009e715:     	orb	%r15b, %bl
14009e718:     	cmoveq	%r10, %rdx
14009e71c:     	cmoveq	%rdi, %r14
14009e720:     	cmpq	$0x3, %r10
14009e724:     	leaq	0x1(%r10), %r10
14009e728:     	jb	0x14009e6c3 <.text+0x9d6c3>
14009e72a:     	xorl	%eax, %eax
14009e72c:     	cmpq	$0x1, %r9
14009e730:     	jne	0x14009e83d <.text+0x9d83d>
14009e736:     	cmpq	$0x4, %rdx
14009e73a:     	jae	0x14009e83d <.text+0x9d83d>
14009e740:     	cmpl	$0x0, 0x1e30(%rcx,%rdx,4)
14009e748:     	je	0x14009e83b <.text+0x9d83b>
14009e74e:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009e755:     	movzbl	0x1a(%rsi,%rax), %r15d
14009e75b:     	cmpb	$0x2, %r15b
14009e75f:     	je	0x14009e83b <.text+0x9d83b>
14009e765:     	addq	%rsi, %rax
14009e768:     	cmpb	$0x3, 0x28(%rax)
14009e76c:     	jne	0x14009e83b <.text+0x9d83b>
14009e772:     	movq	0x30(%rax), %r9
14009e776:     	movq	(%rax), %r12
14009e779:     	movq	0x8(%rax), %rdx
14009e77d:     	movq	%rdx, 0x170(%rbp)
14009e784:     	movl	0x10(%rax), %r13d
14009e788:     	movl	0x14(%rax), %edi
14009e78b:     	movzwl	0x18(%rax), %edx
14009e78f:     	movw	%dx, 0x17e(%rbp)
14009e796:     	movzbl	0x1b(%rax), %edx
14009e79a:     	movb	%dl, 0x17d(%rbp)
14009e7a0:     	movss	0x1c(%rax), %xmm6
14009e7a5:     	movzwl	0x1c(%rax), %eax
14009e7a9:     	movzwl	%ax, %edx
14009e7ac:     	cmpq	$0x1, %r9
14009e7b0:     	ja	0x14009e805 <.text+0x9d805>
14009e7b2:     	cmpb	$0x1, 0x1968(%rcx,%r9)
14009e7bb:     	jne	0x14009e805 <.text+0x9d805>
14009e7bd:     	cmpb	$0x0, 0x196a(%rcx,%r9)
14009e7c6:     	jne	0x14009e805 <.text+0x9d805>
14009e7c8:     	movb	$0x0, 0x1968(%rcx,%r9)
14009e7d1:     	decq	0x1960(%rcx)
14009e7d8:     	movq	$0x0, 0x18e0(%rcx,%r9,8)
14009e7e4:     	leaq	(%r9,%r9,8), %r10
14009e7e8:     	leaq	(%r10,%r10,2), %r10
14009e7ec:     	addq	%r9, %r10
14009e7ef:     	movb	$0x2, 0x95a(%r8,%r10)
14009e7f8:     	leaq	(%r9,%r9,2), %r9
14009e7fc:     	movb	$0x2, 0x91d(%r8,%r9,8)
14009e805:     	addl	$0x2, %edx
14009e808:     	movb	$0x1, %r9b
14009e80b:     	cmpl	%edx, 0x1e30(%rcx)
14009e811:     	jne	0x14009e821 <.text+0x9d821>
14009e813:     	movzbl	0x198a(%rcx), %r8d
14009e81b:     	cmpb	$0x2, %r8b
14009e81f:     	jne	0x14009e858 <.text+0x9d858>
14009e821:     	xorl	%r8d, %r8d
14009e824:     	cmpl	%edx, 0x1e34(%rcx)
14009e82a:     	movl	%edi, 0x178(%rbp)
14009e830:     	jne	0x14009e8ec <.text+0x9d8ec>
14009e836:     	jmp	0x14009e8da <.text+0x9d8da>
14009e83b:     	xorl	%eax, %eax
14009e83d:     	movaps	0x180(%rbp), %xmm6
14009e844:     	addq	$0x218, %rsp            # imm = 0x218
14009e84b:     	popq	%rbx
14009e84c:     	popq	%rdi
14009e84d:     	popq	%rsi
14009e84e:     	popq	%r12
14009e850:     	popq	%r13
14009e852:     	popq	%r14
14009e854:     	popq	%r15
14009e856:     	popq	%rbp
14009e857:     	retq
14009e858:     	cmpw	%ax, 0x198c(%rcx)
14009e85f:     	sete	%r9b
14009e863:     	cmpl	%r13d, 0x1980(%rcx)
14009e86a:     	sete	%r10b
14009e86e:     	andb	%r9b, %r10b
14009e871:     	cmpl	%edi, 0x1984(%rcx)
14009e877:     	sete	%r9b
14009e87b:     	movzwl	0x17e(%rbp), %r11d
14009e883:     	cmpw	%r11w, 0x1988(%rcx)
14009e88b:     	sete	%r11b
14009e88f:     	andb	%r9b, %r11b
14009e892:     	andb	%r10b, %r11b
14009e895:     	cmpb	%r15b, %r8b
14009e898:     	sete	%r8b
14009e89c:     	movq	0x1978(%rcx), %r9
14009e8a3:     	xorq	0x170(%rbp), %r9
14009e8aa:     	movq	0x1970(%rcx), %r10
14009e8b1:     	xorq	%r12, %r10
14009e8b4:     	orq	%r9, %r10
14009e8b7:     	sete	%r9b
14009e8bb:     	andb	%r8b, %r9b
14009e8be:     	andb	%r11b, %r9b
14009e8c1:     	movzbl	%r9b, %r8d
14009e8c5:     	movl	%r8d, %r9d
14009e8c8:     	xorb	$0x1, %r9b
14009e8cc:     	cmpl	%edx, 0x1e34(%rcx)
14009e8d2:     	movl	%edi, 0x178(%rbp)
14009e8d8:     	jne	0x14009e8ec <.text+0x9d8ec>
14009e8da:     	movzbl	0x1aba(%rcx), %r10d
14009e8e2:     	cmpb	$0x2, %r10b
14009e8e6:     	jne	0x14009e996 <.text+0x9d996>
14009e8ec:     	xorl	%r9d, %r9d
14009e8ef:     	cmpl	%edx, 0x1e38(%rcx)
14009e8f5:     	jne	0x14009ea33 <.text+0x9da33>
14009e8fb:     	movzbl	0x1bea(%rcx), %r10d
14009e903:     	cmpb	$0x2, %r10b
14009e907:     	je	0x14009ea33 <.text+0x9da33>
14009e90d:     	cmpb	%r15b, %r10b
14009e910:     	jne	0x14009ea33 <.text+0x9da33>
14009e916:     	cmpw	%ax, 0x1bec(%rcx)
14009e91d:     	jne	0x14009ea33 <.text+0x9da33>
14009e923:     	cmpl	%r13d, 0x1be0(%rcx)
14009e92a:     	jne	0x14009ea33 <.text+0x9da33>
14009e930:     	cmpl	%edi, 0x1be4(%rcx)
14009e936:     	jne	0x14009ea33 <.text+0x9da33>
14009e93c:     	movzwl	0x17e(%rbp), %r10d
14009e944:     	cmpw	%r10w, 0x1be8(%rcx)
14009e94c:     	jne	0x14009ea33 <.text+0x9da33>
14009e952:     	movq	0x1bd0(%rcx), %r10
14009e959:     	xorq	%r12, %r10
14009e95c:     	movq	0x1bd8(%rcx), %r11
14009e963:     	xorq	0x170(%rbp), %r11
14009e96a:     	orq	%r10, %r11
14009e96d:     	jne	0x14009ea33 <.text+0x9da33>
14009e973:     	movb	$0x1, %dil
14009e976:     	testq	%r8, %r8
14009e979:     	jne	0x14009eab6 <.text+0x9dab6>
14009e97f:     	movl	$0x1, %r8d
14009e985:     	movl	$0x2, %r9d
14009e98b:     	movl	0x178(%rbp), %edi
14009e991:     	jmp	0x14009ea33 <.text+0x9da33>
14009e996:     	cmpw	%ax, 0x1abc(%rcx)
14009e99d:     	setne	%r11b
14009e9a1:     	cmpl	%r13d, 0x1ab0(%rcx)
14009e9a8:     	setne	%bl
14009e9ab:     	orb	%r11b, %bl
14009e9ae:     	cmpl	%edi, 0x1ab4(%rcx)
14009e9b4:     	setne	%r11b
14009e9b8:     	movzwl	0x17e(%rbp), %edi
14009e9bf:     	cmpw	%di, 0x1ab8(%rcx)
14009e9c6:     	setne	%dil
14009e9ca:     	orb	%r11b, %dil
14009e9cd:     	orb	%bl, %dil
14009e9d0:     	cmpb	%r15b, %r10b
14009e9d3:     	setne	%r11b
14009e9d7:     	movq	0x1aa8(%rcx), %r10
14009e9de:     	xorq	0x170(%rbp), %r10
14009e9e5:     	movq	0x1aa0(%rcx), %rbx
14009e9ec:     	xorq	%r12, %rbx
14009e9ef:     	orq	%r10, %rbx
14009e9f2:     	setne	%r10b
14009e9f6:     	orb	%r11b, %r10b
14009e9f9:     	orb	%dil, %r10b
14009e9fc:     	orb	%r10b, %r9b
14009e9ff:     	testb	%r10b, %r10b
14009ea02:     	movl	$0x1, %r11d
14009ea08:     	cmoveq	%r11, %r8
14009ea0c:     	testb	$0x1, %r9b
14009ea10:     	je	0x14009eab0 <.text+0x9dab0>
14009ea16:     	notb	%r10b
14009ea19:     	movzbl	%r10b, %r9d
14009ea1d:     	andl	$0x1, %r9d
14009ea21:     	movl	0x178(%rbp), %edi
14009ea27:     	cmpl	%edx, 0x1e38(%rcx)
14009ea2d:     	je	0x14009e8fb <.text+0x9d8fb>
14009ea33:     	cmpl	%edx, 0x1e3c(%rcx)
14009ea39:     	jne	0x14009ea47 <.text+0x9da47>
14009ea3b:     	movzbl	0x1d1a(%rcx), %edx
14009ea42:     	cmpb	$0x2, %dl
14009ea45:     	jne	0x14009ea53 <.text+0x9da53>
14009ea47:     	xorl	%edi, %edi
14009ea49:     	testq	%r8, %r8
14009ea4c:     	jne	0x14009eab6 <.text+0x9dab6>
14009ea4e:     	jmp	0x14009eae0 <.text+0x9dae0>
14009ea53:     	cmpb	%r15b, %dl
14009ea56:     	jne	0x14009ea47 <.text+0x9da47>
14009ea58:     	cmpw	%ax, 0x1d1c(%rcx)
14009ea5f:     	jne	0x14009ea47 <.text+0x9da47>
14009ea61:     	cmpl	%r13d, 0x1d10(%rcx)
14009ea68:     	jne	0x14009ea47 <.text+0x9da47>
14009ea6a:     	cmpl	%edi, 0x1d14(%rcx)
14009ea70:     	jne	0x14009ea47 <.text+0x9da47>
14009ea72:     	movzwl	0x17e(%rbp), %edx
14009ea79:     	cmpw	%dx, 0x1d18(%rcx)
14009ea80:     	jne	0x14009ea47 <.text+0x9da47>
14009ea82:     	movq	0x1d00(%rcx), %rdx
14009ea89:     	xorq	%r12, %rdx
14009ea8c:     	movq	0x1d08(%rcx), %r10
14009ea93:     	xorq	0x170(%rbp), %r10
14009ea9a:     	orq	%rdx, %r10
14009ea9d:     	jne	0x14009ea47 <.text+0x9da47>
14009ea9f:     	testq	%r8, %r8
14009eaa2:     	movl	$0x3, %edx
14009eaa7:     	cmoveq	%rdx, %r9
14009eaab:     	movl	%r8d, %edi
14009eaae:     	jmp	0x14009eab6 <.text+0x9dab6>
14009eab0:     	movb	$0x1, %dil
14009eab3:     	xorl	%r9d, %r9d
14009eab6:     	cmpl	$0x0, 0x1e30(%rcx,%r9,4)
14009eabf:     	je	0x14009eae0 <.text+0x9dae0>
14009eac1:     	movl	$0x0, 0x1e30(%rcx,%r9,4)
14009eacd:     	decq	0x1e48(%rcx)
14009ead4:     	imulq	$0x130, %r9, %rdx       # imm = 0x130
14009eadb:     	movb	$0x2, 0x1a(%rsi,%rdx)
14009eae0:     	movl	%r13d, 0x16c(%rbp)
14009eae7:     	movq	%r12, %r13
14009eaea:     	xorps	%xmm0, %xmm0
14009eaed:     	movaps	%xmm0, 0x150(%rbp)
14009eaf4:     	movb	$0x0, 0x132(%rbp)
14009eafb:     	movw	%ax, 0x130(%rbp)
14009eb02:     	leaq	0x133(%rbp), %rdx
14009eb09:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009eb12:     	movq	$0x0, 0x133(%rbp)
14009eb1d:     	movq	$0x8, 0x110(%rbp)
14009eb28:     	movq	$0x0, 0x118(%rbp)
14009eb33:     	movq	$0x1, 0x120(%rbp)
14009eb3e:     	movq	$0x0, 0x128(%rbp)
14009eb49:     	movq	%rdx, 0x30(%rsp)
14009eb4e:     	movw	%ax, 0x28(%rsp)
14009eb53:     	movq	$0x0, 0x58(%rsp)
14009eb5c:     	movq	$0x1, 0x50(%rsp)
14009eb65:     	movq	$0x8, 0x48(%rsp)
14009eb6e:     	movq	$0x8, 0x40(%rsp)
14009eb77:     	movq	$0x0, 0x38(%rsp)
14009eb80:     	movb	$0x0, 0x20(%rsp)
14009eb85:     	leaq	0x140(%rbp), %rax
14009eb8c:     	leaq	0x150(%rbp), %rdx
14009eb93:     	movl	$0x10, %r8d
14009eb99:     	movq	%rcx, %r12
14009eb9c:     	movq	%rax, %rcx
14009eb9f:     	movb	$0x2, %r9b
14009eba2:     	callq	0x140005590 <.text+0x4590>
14009eba7:     	cmpb	$0x0, 0x140(%rbp)
14009ebae:     	jne	0x14009ed44 <.text+0x9dd44>
14009ebb4:     	testb	%dil, %dil
14009ebb7:     	jne	0x14009ed44 <.text+0x9dd44>
14009ebbd:     	movq	0x148(%rbp), %rbx
14009ebc4:     	cmpq	$0x10, %rbx
14009ebc8:     	ja	0x14009ed44 <.text+0x9dd44>
14009ebce:     	movq	%r12, %rax
14009ebd1:     	cmpq	$0x4, 0x1e48(%r12)
14009ebda:     	je	0x14009ed44 <.text+0x9dd44>
14009ebe0:     	movq	0x1e40(%rax), %rdi
14009ebe7:     	cmpq	$0x3, %rdi
14009ebeb:     	ja	0x14009ed5c <.text+0x9dd5c>
14009ebf1:     	cmpl	$0x0, 0x1e30(%rax,%rdi,4)
14009ebf9:     	je	0x14009ec73 <.text+0x9dc73>
14009ebfb:     	leaq	(,%rdi,4), %rdx
14009ec03:     	xorl	%ecx, %ecx
14009ec05:     	cmpl	$0x0, 0x1e30(%rax,%rdx)
14009ec0d:     	je	0x14009ec66 <.text+0x9dc66>
14009ec0f:     	addq	$0x4, %rdx
14009ec13:     	decq	%rcx
14009ec16:     	cmpq	$0x10, %rdx
14009ec1a:     	jne	0x14009ec05 <.text+0x9dc05>
14009ec1c:     	testq	%rdi, %rdi
14009ec1f:     	je	0x14009ed44 <.text+0x9dd44>
14009ec25:     	cmpl	$0x0, 0x1e30(%rax)
14009ec2c:     	je	0x14009ed4b <.text+0x9dd4b>
14009ec32:     	cmpq	$0x1, %rdi
14009ec36:     	je	0x14009ed44 <.text+0x9dd44>
14009ec3c:     	cmpl	$0x0, 0x1e34(%rax)
14009ec43:     	je	0x14009ed52 <.text+0x9dd52>
14009ec49:     	cmpq	$0x2, %rdi
14009ec4d:     	je	0x14009ed44 <.text+0x9dd44>
14009ec53:     	movl	$0x2, %edi
14009ec58:     	cmpl	$0x0, 0x1e38(%rax)
14009ec5f:     	je	0x14009ec69 <.text+0x9dc69>
14009ec61:     	jmp	0x14009ed44 <.text+0x9dd44>
14009ec66:     	subq	%rcx, %rdi
14009ec69:     	cmpq	$0x4, %rdi
14009ec6d:     	jae	0x14009ed72 <.text+0x9dd72>
14009ec73:     	movl	$0x1, 0x1e30(%rax,%rdi,4)
14009ec7e:     	incq	0x1e48(%rax)
14009ec85:     	leaq	0x1(%rdi), %rcx
14009ec89:     	xorl	%edx, %edx
14009ec8b:     	cmpq	$0x4, %rcx
14009ec8f:     	cmovneq	%rcx, %rdx
14009ec93:     	movq	%rdx, 0x1e40(%rax)
14009ec9a:     	movq	0x170(%rbp), %rcx
14009eca1:     	movq	%rcx, -0x18(%rbp)
14009eca5:     	movq	%r13, -0x20(%rbp)
14009eca9:     	movl	0x16c(%rbp), %ecx
14009ecaf:     	movl	%ecx, -0x10(%rbp)
14009ecb2:     	movl	0x178(%rbp), %ecx
14009ecb8:     	movl	%ecx, -0xc(%rbp)
14009ecbb:     	movzwl	0x17e(%rbp), %ecx
14009ecc2:     	movw	%cx, -0x8(%rbp)
14009ecc6:     	movb	%r15b, -0x6(%rbp)
14009ecca:     	movzbl	0x17d(%rbp), %ecx
14009ecd1:     	movb	%cl, -0x5(%rbp)
14009ecd4:     	movss	%xmm6, -0x4(%rbp)
14009ecd9:     	movq	%r14, (%rbp)
14009ecdd:     	testq	%rbx, %rbx
14009ece0:     	je	0x14009ed1c <.text+0x9dd1c>
14009ece2:     	movb	$0x1, 0x8(%rbp)
14009ece6:     	movb	%bl, 0x9(%rbp)
14009ece9:     	leaq	0xa(%rbp), %r14
14009eced:     	movl	$0x80, %r8d
14009ecf3:     	subq	%rbx, %r8
14009ecf6:     	leaq	(%rbx,%rbp), %rcx
14009ecfa:     	addq	$0xa, %rcx
14009ecfe:     	xorl	%edx, %edx
14009ed00:     	callq	0x1402517c2 <.text+0x2507c2>
14009ed05:     	leaq	0x150(%rbp), %rdx
14009ed0c:     	movq	%r14, %rcx
14009ed0f:     	movq	%rbx, %r8
14009ed12:     	callq	0x1402517b0 <.text+0x2507b0>
14009ed17:     	movq	%r12, %rax
14009ed1a:     	jmp	0x14009ed20 <.text+0x9dd20>
14009ed1c:     	movb	$0x0, 0x8(%rbp)
14009ed20:     	movzwl	-0x4(%rbp), %ecx
14009ed24:     	addl	$0x2, %ecx
14009ed27:     	movl	%ecx, 0x1e30(%rax,%rdi,4)
14009ed2e:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009ed35:     	addq	%rax, %rsi
14009ed38:     	leaq	-0x20(%rbp), %rcx
14009ed3c:     	movq	%rsi, %rdx
14009ed3f:     	callq	0x14000b1c0 <.text+0xa1c0>
14009ed44:     	movb	$0x1, %al
14009ed46:     	jmp	0x14009e83d <.text+0x9d83d>
14009ed4b:     	xorl	%edi, %edi
14009ed4d:     	jmp	0x14009ec69 <.text+0x9dc69>
14009ed52:     	movl	$0x1, %edi
14009ed57:     	jmp	0x14009ec69 <.text+0x9dc69>
14009ed5c:     	leaq	0x1ce04d(%rip), %r8     # 0x14026cdb0
14009ed63:     	movl	$0x4, %edx
14009ed68:     	movq	%rdi, %rcx
14009ed6b:     	callq	0x140252033 <.text+0x251033>
14009ed70:     	ud2
14009ed72:     	leaq	0x1ce04f(%rip), %r8     # 0x14026cdc8
14009ed79:     	movl	$0x4, %edx
14009ed7e:     	movq	%rdi, %rcx
14009ed81:     	callq	0x140252033 <.text+0x251033>
14009ed86:     	ud2

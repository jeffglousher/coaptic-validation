from pathlib import Path
import json, subprocess, hashlib, shutil
r = Path(__file__).resolve().parent
prior = Path('D:/CoapticCurrent/short-inline-replay-20261106/borrowed-writer')
repo = Path('C:/Users/jeffg/.t3/worktrees/coaptic/t3-a578955c')
sha = '6760b72a8ed07b6a108cde24eeb36e552a0f076d'
old = 'bf2c37118f1598b5d00ae810b0cb248804678185'
v = json.loads((prior/'source-verification.json').read_text())
v['source'] = sha
fixture = Path(v['fixture_root'])/'coaptic'
for name in v['source_file_hashes']:
    data = subprocess.check_output(['git','-C',str(repo),'show',sha+':'+name]).replace(b'\r\n',b'\n')
    p = fixture/name
    if p.read_bytes() != data: p.write_bytes(data)
    v['source_file_hashes'][name] = hashlib.sha256(data).hexdigest()
patch = subprocess.check_output(['git','-C',str(repo),'diff','--binary',v['baseline'],sha,'--','src','crates','tests','Cargo.toml','Cargo.lock'])
(r/'candidate.patch').write_bytes(patch)
v['patch_sha256'] = hashlib.sha256(patch).hexdigest()
(r/'source-verification.json').write_text(json.dumps(v,indent=2)+'\n')
for name in ['build-preflight.py','build.py','layout.py','inspect.py','measure.py','qualify.py']:
    text = (prior/name).read_text().replace(old,sha)
    if name == 'inspect.py':
        text = text.replace('(?=^\\d+ \\| S_LPROC32)', '(?=^\\s*\\d+ \\| S_LPROC32)')
    (r/name).write_text(text)
(r/'B').mkdir(exist_ok=True)
(r/'layout32').mkdir(exist_ok=True)
for name in ['audit.py','Cargo.toml','Cargo.lock','lib.rs','baseline-build.log','baseline-constants.txt','baseline-layout.txt','baseline-source.json']:
    shutil.copyfile(prior/'layout32'/name,r/'layout32'/name)
shutil.copyfile(prior/'fixture-sha256.json',r/'fixture-sha256.json')
m = json.loads((prior/'METHOD-BEFORE.json').read_text())
m['candidate'] = sha
m['source_hypothesis'] = m['hypothesis'] = 'Short128-byte replay owner reduces initialization/copy work while preserving max256. Pass source metadata and active bytes separately across a four-argument writer boundary to prevent full-row memcpy without a fifth argument frame. Explicit C field order keeps key/deadline/replay tag before payload instead of key at byte272. Require unchanged complete owners and demonstrate selected writer/caller nongrowth; one combined runtime cohort.'
m['tradeoffs'] = 'One internal enum branch and explicit field layout, no unsafe code/capacity cut/allocation. Canonical short/long boundaries128/129, empty and overflow behavior retained. Reclaim/search and full-chunk improvements remain integrated. Static locality/copy evidence does not prove whole-App CPU gains.'
m['preflight_repair'] = 'Untimed80a184c writes128 payload bytes but its five-argument helper expands write_into frame8 to56. Preserve this preflight, do not time it. Untimed bf2c371 restores8-byte caller/helper frames but compiler recovers304-byte memcpy. New explicit active-byte arguments must lower to128-byte payload writes; verify actual32/64-bit sizes before timing.'
(r/'METHOD-BEFORE.json').write_text(json.dumps(m,indent=2)+'\n')
print({'source':sha,'verified_files':len(v['source_file_hashes'])},flush=True)

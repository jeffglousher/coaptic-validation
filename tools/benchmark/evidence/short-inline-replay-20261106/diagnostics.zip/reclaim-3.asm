
D:\CoapticCurrent\short-inline-replay-20261106\active-bytes\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009f4a0:     	pushq	%rbp
14009f4a1:     	pushq	%r15
14009f4a3:     	pushq	%r14
14009f4a5:     	pushq	%r13
14009f4a7:     	pushq	%r12
14009f4a9:     	pushq	%rsi
14009f4aa:     	pushq	%rdi
14009f4ab:     	pushq	%rbx
14009f4ac:     	subq	$0x218, %rsp            # imm = 0x218
14009f4b3:     	leaq	0x80(%rsp), %rbp
14009f4bb:     	movaps	%xmm6, 0x180(%rbp)
14009f4c2:     	leaq	0x326f0(%rcx), %rdx
14009f4c9:     	leaq	0x3f7f0(%rcx), %rsi
14009f4d0:     	leaq	0x443f0(%rcx), %r15
14009f4d7:     	leaq	0x3f818(%rcx), %rax
14009f4de:     	xorl	%r10d, %r10d
14009f4e1:     	movl	$0x1, %r11d
14009f4e7:     	xorl	%r9d, %r9d
14009f4ea:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009f4f1:     	addq	%rax, %rdi
14009f4f4:     	jmp	0x14009f510 <.text+0x9e510>
14009f4f6:     	nopw	%cs:(%rax,%rax)
14009f500:     	incq	%r10
14009f503:     	addq	$0x130, %rdi            # imm = 0x130
14009f50a:     	cmpq	$0x40, %r10
14009f50e:     	je	0x14009f55a <.text+0x9e55a>
14009f510:     	cmpl	$0x0, 0x443f0(%rcx,%r10,4)
14009f519:     	je	0x14009f500 <.text+0x9e500>
14009f51b:     	cmpb	$0x2, -0xe(%rdi)
14009f51f:     	je	0x14009f500 <.text+0x9e500>
14009f521:     	cmpb	$0x3, (%rdi)
14009f524:     	movq	-0x8(%rdi), %rdi
14009f528:     	setne	%bl
14009f52b:     	testq	%rdi, %rdi
14009f52e:     	sete	%r12b
14009f532:     	orb	%bl, %r12b
14009f535:     	cmpq	%r14, %rdi
14009f538:     	setae	%bl
14009f53b:     	andb	%r9b, %bl
14009f53e:     	testb	%r12b, %r12b
14009f541:     	cmoveq	%r11, %r9
14009f545:     	orb	%r12b, %bl
14009f548:     	cmoveq	%r10, %r8
14009f54c:     	cmoveq	%rdi, %r14
14009f550:     	cmpq	$0x3f, %r10
14009f554:     	leaq	0x1(%r10), %r10
14009f558:     	jb	0x14009f4ea <.text+0x9e4ea>
14009f55a:     	xorl	%eax, %eax
14009f55c:     	cmpq	$0x1, %r9
14009f560:     	jne	0x14009f6e0 <.text+0x9e6e0>
14009f566:     	cmpq	$0x40, %r8
14009f56a:     	jae	0x14009f6e0 <.text+0x9e6e0>
14009f570:     	cmpl	$0x0, (%r15,%r8,4)
14009f575:     	je	0x14009f6de <.text+0x9e6de>
14009f57b:     	imulq	$0x130, %r8, %rax       # imm = 0x130
14009f582:     	movzbl	0x1a(%rsi,%rax), %r12d
14009f588:     	cmpb	$0x2, %r12b
14009f58c:     	je	0x14009f6de <.text+0x9e6de>
14009f592:     	addq	%rsi, %rax
14009f595:     	cmpb	$0x3, 0x28(%rax)
14009f599:     	jne	0x14009f6de <.text+0x9e6de>
14009f59f:     	movq	0x30(%rax), %r9
14009f5a3:     	movq	(%rax), %r8
14009f5a6:     	movq	%r8, 0x168(%rbp)
14009f5ad:     	movq	0x8(%rax), %r8
14009f5b1:     	movq	%r8, 0x170(%rbp)
14009f5b8:     	movl	0x10(%rax), %edi
14009f5bb:     	movl	0x14(%rax), %r8d
14009f5bf:     	movl	%r8d, 0x178(%rbp)
14009f5c6:     	movzwl	0x18(%rax), %r8d
14009f5cb:     	movw	%r8w, 0x17c(%rbp)
14009f5d3:     	movzbl	0x1b(%rax), %r8d
14009f5d8:     	movb	%r8b, 0x17f(%rbp)
14009f5df:     	movss	0x1c(%rax), %xmm6
14009f5e4:     	movzwl	0x1c(%rax), %eax
14009f5e8:     	movzwl	%ax, %r8d
14009f5ec:     	cmpq	$0x1f, %r9
14009f5f0:     	ja	0x14009f63e <.text+0x9e63e>
14009f5f2:     	cmpb	$0x1, (%rdx,%r9)
14009f5f7:     	jne	0x14009f63e <.text+0x9e63e>
14009f5f9:     	cmpb	$0x0, 0x32710(%rcx,%r9)
14009f602:     	jne	0x14009f63e <.text+0x9e63e>
14009f604:     	movb	$0x0, 0x326f0(%rcx,%r9)
14009f60d:     	decq	0x32738(%rcx)
14009f614:     	movq	$0x0, 0x3e5c0(%rcx,%r9,8)
14009f620:     	leaq	(%r9,%r9,8), %r10
14009f624:     	leaq	(%r10,%r10,2), %r10
14009f628:     	addq	%r9, %r10
14009f62b:     	movb	$0x2, 0x36a(%rdx,%r10)
14009f634:     	leaq	(%r9,%r9,2), %r9
14009f638:     	movb	$0x2, 0x5d(%rdx,%r9,8)
14009f63e:     	addl	$0x2, %r8d
14009f642:     	leaq	0x3f80c(%rcx), %r9
14009f649:     	xorl	%r10d, %r10d
14009f64c:     	xorl	%edx, %edx
14009f64e:     	jmp	0x14009f667 <.text+0x9e667>
14009f650:     	movq	%r13, %r11
14009f653:     	incq	%r10
14009f656:     	addq	$0x130, %r9             # imm = 0x130
14009f65d:     	cmpq	$0x40, %r10
14009f661:     	je	0x14009f6fb <.text+0x9e6fb>
14009f667:     	movq	%r11, %r13
14009f66a:     	cmpl	%r8d, (%r15,%r10,4)
14009f66e:     	jne	0x14009f650 <.text+0x9e650>
14009f670:     	movzbl	-0x2(%r9), %r11d
14009f675:     	cmpb	$0x2, %r11b
14009f679:     	je	0x14009f650 <.text+0x9e650>
14009f67b:     	cmpb	%r12b, %r11b
14009f67e:     	jne	0x14009f650 <.text+0x9e650>
14009f680:     	cmpw	%ax, (%r9)
14009f684:     	jne	0x14009f650 <.text+0x9e650>
14009f686:     	cmpl	%edi, -0xc(%r9)
14009f68a:     	jne	0x14009f650 <.text+0x9e650>
14009f68c:     	movl	0x178(%rbp), %r11d
14009f693:     	cmpl	%r11d, -0x8(%r9)
14009f697:     	jne	0x14009f650 <.text+0x9e650>
14009f699:     	movzwl	0x17c(%rbp), %r11d
14009f6a1:     	cmpw	%r11w, -0x4(%r9)
14009f6a6:     	jne	0x14009f650 <.text+0x9e650>
14009f6a8:     	movq	-0x1c(%r9), %r11
14009f6ac:     	xorq	0x168(%rbp), %r11
14009f6b3:     	movq	-0x14(%r9), %rbx
14009f6b7:     	xorq	0x170(%rbp), %rbx
14009f6be:     	orq	%r11, %rbx
14009f6c1:     	jne	0x14009f650 <.text+0x9e650>
14009f6c3:     	movq	%r10, %r11
14009f6c6:     	cmpq	$0x1, %rdx
14009f6ca:     	movl	$0x1, %edx
14009f6cf:     	jne	0x14009f653 <.text+0x9e653>
14009f6d1:     	movb	$0x1, %bl
14009f6d3:     	movq	%r13, %r11
14009f6d6:     	cmpq	$0x3f, %r13
14009f6da:     	jbe	0x14009f70a <.text+0x9e70a>
14009f6dc:     	jmp	0x14009f730 <.text+0x9e730>
14009f6de:     	xorl	%eax, %eax
14009f6e0:     	movaps	0x180(%rbp), %xmm6
14009f6e7:     	addq	$0x218, %rsp            # imm = 0x218
14009f6ee:     	popq	%rbx
14009f6ef:     	popq	%rdi
14009f6f0:     	popq	%rsi
14009f6f1:     	popq	%r12
14009f6f3:     	popq	%r13
14009f6f5:     	popq	%r14
14009f6f7:     	popq	%r15
14009f6f9:     	popq	%rbp
14009f6fa:     	retq
14009f6fb:     	cmpq	$0x40, %r11
14009f6ff:     	setb	%r8b
14009f703:     	xorl	%ebx, %ebx
14009f705:     	testb	%r8b, %dl
14009f708:     	je	0x14009f730 <.text+0x9e730>
14009f70a:     	cmpl	$0x0, (%r15,%r11,4)
14009f70f:     	je	0x14009f730 <.text+0x9e730>
14009f711:     	movl	$0x0, 0x443f0(%rcx,%r11,4)
14009f71d:     	decq	0x444f8(%rcx)
14009f724:     	imulq	$0x130, %r11, %rdx      # imm = 0x130
14009f72b:     	movb	$0x2, 0x1a(%rsi,%rdx)
14009f730:     	pxor	%xmm0, %xmm0
14009f734:     	movdqa	%xmm0, 0x150(%rbp)
14009f73c:     	movb	$0x0, 0x132(%rbp)
14009f743:     	movw	%ax, 0x130(%rbp)
14009f74a:     	leaq	0x133(%rbp), %rdx
14009f751:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009f75a:     	movq	$0x0, 0x133(%rbp)
14009f765:     	movq	$0x8, 0x110(%rbp)
14009f770:     	movq	$0x0, 0x118(%rbp)
14009f77b:     	movq	$0x1, 0x120(%rbp)
14009f786:     	movq	$0x0, 0x128(%rbp)
14009f791:     	movq	%rdx, 0x30(%rsp)
14009f796:     	movw	%ax, 0x28(%rsp)
14009f79b:     	movq	$0x0, 0x58(%rsp)
14009f7a4:     	movq	$0x1, 0x50(%rsp)
14009f7ad:     	movq	$0x8, 0x48(%rsp)
14009f7b6:     	movq	$0x8, 0x40(%rsp)
14009f7bf:     	movq	$0x0, 0x38(%rsp)
14009f7c8:     	movb	$0x0, 0x20(%rsp)
14009f7cd:     	leaq	0x140(%rbp), %rax
14009f7d4:     	leaq	0x150(%rbp), %rdx
14009f7db:     	movl	$0x10, %r8d
14009f7e1:     	movq	%rcx, %r13
14009f7e4:     	movq	%rax, %rcx
14009f7e7:     	movb	$0x2, %r9b
14009f7ea:     	callq	0x140005590 <.text+0x4590>
14009f7ef:     	movq	%r13, %rax
14009f7f2:     	movq	0x148(%rbp), %r13
14009f7f9:     	cmpq	$0x11, %r13
14009f7fd:     	setae	%cl
14009f800:     	orb	%bl, %cl
14009f802:     	orb	0x140(%rbp), %cl
14009f808:     	testb	$0x1, %cl
14009f80b:     	jne	0x14009f970 <.text+0x9e970>
14009f811:     	cmpq	$0x40, 0x444f8(%rax)
14009f819:     	je	0x14009f970 <.text+0x9e970>
14009f81f:     	movq	0x444f0(%rax), %rbx
14009f826:     	cmpq	$0x3f, %rbx
14009f82a:     	ja	0x14009fa30 <.text+0x9ea30>
14009f830:     	cmpl	$0x0, (%r15,%rbx,4)
14009f835:     	je	0x14009f8a0 <.text+0x9e8a0>
14009f837:     	leaq	(,%rbx,4), %rdx
14009f83f:     	leaq	(%r15,%rbx,4), %rcx
14009f843:     	xorl	%r8d, %r8d
14009f846:     	movq	%rdx, %r9
14009f849:     	cmpl	$0x0, (%r15,%r9)
14009f84e:     	je	0x14009f893 <.text+0x9e893>
14009f850:     	addq	$0x4, %r9
14009f854:     	decq	%r8
14009f857:     	cmpq	$0x100, %r9             # imm = 0x100
14009f85e:     	jne	0x14009f849 <.text+0x9e849>
14009f860:     	testq	%rbx, %rbx
14009f863:     	je	0x14009f970 <.text+0x9e970>
14009f869:     	addq	$-0x4, %rdx
14009f86d:     	cmpq	$0xc, %rdx
14009f871:     	jae	0x14009f977 <.text+0x9e977>
14009f877:     	xorl	%ebx, %ebx
14009f879:     	movq	%r15, %r9
14009f87c:     	cmpl	$0x0, (%r9)
14009f880:     	je	0x14009f896 <.text+0x9e896>
14009f882:     	addq	$0x4, %r9
14009f886:     	incq	%rbx
14009f889:     	cmpq	%rcx, %r9
14009f88c:     	jne	0x14009f87c <.text+0x9e87c>
14009f88e:     	jmp	0x14009f970 <.text+0x9e970>
14009f893:     	subq	%r8, %rbx
14009f896:     	cmpq	$0x40, %rbx
14009f89a:     	jae	0x14009fa1a <.text+0x9ea1a>
14009f8a0:     	movl	$0x1, 0x443f0(%rax,%rbx,4)
14009f8ab:     	incq	0x444f8(%rax)
14009f8b2:     	leaq	0x1(%rbx), %rcx
14009f8b6:     	xorl	%edx, %edx
14009f8b8:     	cmpq	$0x40, %rcx
14009f8bc:     	cmovneq	%rcx, %rdx
14009f8c0:     	movq	%rdx, 0x444f0(%rax)
14009f8c7:     	movq	0x170(%rbp), %rax
14009f8ce:     	movq	%rax, -0x18(%rbp)
14009f8d2:     	movq	0x168(%rbp), %rax
14009f8d9:     	movq	%rax, -0x20(%rbp)
14009f8dd:     	movl	%edi, -0x10(%rbp)
14009f8e0:     	movl	0x178(%rbp), %eax
14009f8e6:     	movl	%eax, -0xc(%rbp)
14009f8e9:     	movzwl	0x17c(%rbp), %eax
14009f8f0:     	movw	%ax, -0x8(%rbp)
14009f8f4:     	movb	%r12b, -0x6(%rbp)
14009f8f8:     	movzbl	0x17f(%rbp), %eax
14009f8ff:     	movb	%al, -0x5(%rbp)
14009f902:     	movss	%xmm6, -0x4(%rbp)
14009f907:     	movq	%r14, (%rbp)
14009f90b:     	testq	%r13, %r13
14009f90e:     	je	0x14009f94b <.text+0x9e94b>
14009f910:     	movb	$0x1, 0x8(%rbp)
14009f914:     	movb	%r13b, 0x9(%rbp)
14009f918:     	leaq	0xa(%rbp), %r14
14009f91c:     	movl	$0x80, %r8d
14009f922:     	subq	%r13, %r8
14009f925:     	leaq	0xa(,%r13), %rcx
14009f92d:     	addq	%rbp, %rcx
14009f930:     	xorl	%edx, %edx
14009f932:     	callq	0x1402517c2 <.text+0x2507c2>
14009f937:     	leaq	0x150(%rbp), %rdx
14009f93e:     	movq	%r14, %rcx
14009f941:     	movq	%r13, %r8
14009f944:     	callq	0x1402517b0 <.text+0x2507b0>
14009f949:     	jmp	0x14009f94f <.text+0x9e94f>
14009f94b:     	movb	$0x0, 0x8(%rbp)
14009f94f:     	movzwl	-0x4(%rbp), %eax
14009f953:     	addl	$0x2, %eax
14009f956:     	movl	%eax, (%r15,%rbx,4)
14009f95a:     	imulq	$0x130, %rbx, %rax      # imm = 0x130
14009f961:     	addq	%rax, %rsi
14009f964:     	leaq	-0x20(%rbp), %rcx
14009f968:     	movq	%rsi, %rdx
14009f96b:     	callq	0x14000b1c0 <.text+0xa1c0>
14009f970:     	movb	$0x1, %al
14009f972:     	jmp	0x14009f6e0 <.text+0x9e6e0>
14009f977:     	shrq	$0x2, %rdx
14009f97b:     	incq	%rdx
14009f97e:     	movq	%rdx, %rbx
14009f981:     	andq	$-0x4, %rbx
14009f985:     	leaq	(%r15,%rbx,4), %r9
14009f989:     	xorl	%r8d, %r8d
14009f98c:     	pxor	%xmm1, %xmm1
14009f990:     	movdqu	(%r15,%r8,4), %xmm0
14009f996:     	movdqa	%xmm0, %xmm2
14009f99a:     	pcmpeqd	%xmm1, %xmm2
14009f99e:     	movmskps	%xmm2, %r10d
14009f9a2:     	testl	%r10d, %r10d
14009f9a5:     	jne	0x14009f9bb <.text+0x9e9bb>
14009f9a7:     	addq	$0x4, %r8
14009f9ab:     	cmpq	%r8, %rbx
14009f9ae:     	jne	0x14009f990 <.text+0x9e990>
14009f9b0:     	cmpq	%rbx, %rdx
14009f9b3:     	jne	0x14009f87c <.text+0x9e87c>
14009f9b9:     	jmp	0x14009f970 <.text+0x9e970>
14009f9bb:     	pxor	%xmm1, %xmm1
14009f9bf:     	pcmpeqd	%xmm1, %xmm0
14009f9c3:     	pand	0x1c43d5(%rip), %xmm0   # 0x140263da0
14009f9cb:     	movdqa	0x1c22cd(%rip), %xmm1   # 0x140261ca0
14009f9d3:     	movdqa	%xmm0, %xmm2
14009f9d7:     	por	%xmm1, %xmm2
14009f9db:     	pshufd	$0xee, %xmm0, %xmm3     # xmm3 = xmm0[2,3,2,3]
14009f9e0:     	por	%xmm3, %xmm1
14009f9e4:     	pcmpgtd	%xmm1, %xmm2
14009f9e8:     	pand	%xmm2, %xmm0
14009f9ec:     	pandn	%xmm3, %xmm2
14009f9f0:     	por	%xmm0, %xmm2
14009f9f4:     	movd	%xmm2, %ecx
14009f9f8:     	pshufd	$0x55, %xmm2, %xmm0     # xmm0 = xmm2[1,1,1,1]
14009f9fd:     	movd	%xmm0, %edx
14009fa01:     	cmpl	%edx, %ecx
14009fa03:     	cmoval	%ecx, %edx
14009fa06:     	movl	$0x4, %ebx
14009fa0b:     	subl	%edx, %ebx
14009fa0d:     	addq	%r8, %rbx
14009fa10:     	cmpq	$0x40, %rbx
14009fa14:     	jb	0x14009f8a0 <.text+0x9e8a0>
14009fa1a:     	leaq	0x1cd3a7(%rip), %r8     # 0x14026cdc8
14009fa21:     	movl	$0x40, %edx
14009fa26:     	movq	%rbx, %rcx
14009fa29:     	callq	0x140252033 <.text+0x251033>
14009fa2e:     	ud2
14009fa30:     	leaq	0x1cd379(%rip), %r8     # 0x14026cdb0
14009fa37:     	movl	$0x40, %edx
14009fa3c:     	movq	%rbx, %rcx
14009fa3f:     	callq	0x140252033 <.text+0x251033>
14009fa44:     	ud2

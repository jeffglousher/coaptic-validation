
D:\CoapticCurrent\short-inline-replay-20261106\active-bytes\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068620:     	pushq	%rbp
140068621:     	pushq	%r15
140068623:     	pushq	%r14
140068625:     	pushq	%r13
140068627:     	pushq	%r12
140068629:     	pushq	%rsi
14006862a:     	pushq	%rdi
14006862b:     	pushq	%rbx
14006862c:     	subq	$0x4f8, %rsp            # imm = 0x4F8
140068633:     	leaq	0x80(%rsp), %rbp
14006863b:     	movq	0x4f0(%rbp), %r12
140068642:     	movq	0x8(%r12), %rdi
140068647:     	movl	$0x3, %r10d
14006864d:     	cmpq	$0x3, %rdi
140068651:     	ja	0x140068733 <.text+0x67733>
140068657:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
14006865f:     	jne	0x140068733 <.text+0x67733>
140068665:     	movq	0x26700(%rdx,%rdi,8), %rax
14006866d:     	cmpq	$0x4001, %rax           # imm = 0x4001
140068673:     	jae	0x140068905 <.text+0x67905>
140068679:     	movq	0x10(%r12), %r11
14006867e:     	movq	0x18(%r12), %r15
140068683:     	movq	%r15, %rsi
140068686:     	movl	$0xb, %r10d
14006868c:     	addq	%r11, %rsi
14006868f:     	jb	0x140068733 <.text+0x67733>
140068695:     	cmpq	$0x400, %r15            # imm = 0x400
14006869c:     	ja	0x140068733 <.text+0x67733>
1400686a2:     	cmpq	%rax, %rsi
1400686a5:     	ja	0x140068733 <.text+0x67733>
1400686ab:     	movq	%r8, %r13
1400686ae:     	movq	%r9, 0x460(%rbp)
1400686b5:     	movq	%rcx, 0x470(%rbp)
1400686bc:     	movzbl	0x4f8(%rbp), %r14d
1400686c4:     	movq	%rdi, %rax
1400686c7:     	shlq	$0xe, %rax
1400686cb:     	movq	%rdx, %rsi
1400686ce:     	leaq	(%rdx,%rax), %rbx
1400686d2:     	addq	$0x16700, %rbx          # imm = 0x16700
1400686d9:     	addq	%r11, %rbx
1400686dc:     	movl	$0x400, %r8d            # imm = 0x400
1400686e2:     	cmpq	$0x400, %r15            # imm = 0x400
1400686e9:     	je	0x1400686f9 <.text+0x676f9>
1400686eb:     	leaq	-0x10(%rbp), %rcx
1400686ef:     	xorl	%edx, %edx
1400686f1:     	callq	0x1402517c2 <.text+0x2507c2>
1400686f6:     	movq	%r15, %r8
1400686f9:     	leaq	-0x10(%rbp), %rcx
1400686fd:     	movq	%rbx, %rdx
140068700:     	callq	0x1402517b0 <.text+0x2507b0>
140068705:     	testb	%r14b, %r14b
140068708:     	je	0x14006874e <.text+0x6774e>
14006870a:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
140068711:     	movq	%rsi, %rcx
140068714:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
14006871d:     	jne	0x1400688ba <.text+0x678ba>
140068723:     	xorl	%edi, %edi
140068725:     	callq	0x14009b2b0 <.text+0x9a2b0>
14006872a:     	testb	$0x1, %al
14006872c:     	jne	0x140068760 <.text+0x67760>
14006872e:     	jmp	0x1400688e3 <.text+0x678e3>
140068733:     	movb	$0xa, (%rcx)
140068736:     	movq	%r10, 0x8(%rcx)
14006873a:     	addq	$0x4f8, %rsp            # imm = 0x4F8
140068741:     	popq	%rbx
140068742:     	popq	%rdi
140068743:     	popq	%rsi
140068744:     	popq	%r12
140068746:     	popq	%r13
140068748:     	popq	%r14
14006874a:     	popq	%r15
14006874c:     	popq	%rbp
14006874d:     	retq
14006874e:     	xorl	%edi, %edi
140068750:     	movq	%rsi, %rcx
140068753:     	callq	0x14009b2b0 <.text+0x9a2b0>
140068758:     	testb	$0x1, %al
14006875a:     	je	0x1400688e3 <.text+0x678e3>
140068760:     	movq	%rdx, %rbx
140068763:     	movq	0x500(%rbp), %rdx
14006876a:     	movzwl	0x4e8(%rbp), %ecx
140068771:     	movzbl	0x4e0(%rbp), %eax
140068778:     	movq	(%r12), %r8
14006877c:     	movq	%rdi, 0x430(%rbp)
140068783:     	movq	0x468(%rbp), %r9
14006878a:     	movq	%r9, 0x438(%rbp)
140068791:     	movq	%r8, 0x440(%rbp)
140068798:     	movb	%r14b, 0x448(%rbp)
14006879f:     	movups	0x60(%r13), %xmm0
1400687a4:     	movups	0x6c(%r13), %xmm1
1400687a9:     	movups	%xmm1, 0x3fc(%rbp)
1400687b0:     	movaps	%xmm0, 0x3f0(%rbp)
1400687b7:     	leaq	0x8e(%r13), %r8
1400687be:     	movq	0x7e(%r13), %r9
1400687c2:     	movq	0x85(%r13), %r10
1400687c9:     	movq	%r10, 0x457(%rbp)
1400687d0:     	movq	%r9, 0x450(%rbp)
1400687d7:     	leaq	0x450(%rbp), %r9
1400687de:     	movq	%r9, 0x68(%rsp)
1400687e3:     	movq	%rdx, 0x60(%rsp)
1400687e8:     	movq	%r13, 0x58(%rsp)
1400687ed:     	leaq	0x430(%rbp), %rdx
1400687f4:     	movq	%rdx, 0x50(%rsp)
1400687f9:     	movq	%r15, 0x48(%rsp)
1400687fe:     	leaq	-0x10(%rbp), %rdx
140068802:     	movq	%rdx, 0x40(%rsp)
140068807:     	movq	0x460(%rbp), %rdx
14006880e:     	movq	%rdx, 0x38(%rsp)
140068813:     	movq	%r8, 0x30(%rsp)
140068818:     	movw	%cx, 0x28(%rsp)
14006881d:     	movb	%al, 0x20(%rsp)
140068821:     	leaq	0x410(%rbp), %rcx
140068828:     	leaq	0x3f0(%rbp), %r8
14006882f:     	movq	%rsi, %rdx
140068832:     	movq	%rbx, %r9
140068835:     	callq	0x140082aa0 <.text+0x81aa0>
14006883a:     	cmpb	$-0x1, 0x410(%rbp)
140068841:     	je	0x1400688f2 <.text+0x678f2>
140068847:     	cmpb	$0x1, 0x326f0(%rsi,%rbx)
14006884f:     	movq	0x470(%rbp), %rax
140068856:     	jne	0x1400688a0 <.text+0x678a0>
140068858:     	cmpb	$0x0, 0x32710(%rsi,%rbx)
140068860:     	jne	0x1400688a0 <.text+0x678a0>
140068862:     	movb	$0x0, 0x326f0(%rsi,%rbx)
14006886a:     	decq	0x32738(%rsi)
140068871:     	leaq	0x326f0(%rsi), %rcx
140068878:     	movq	$0x0, 0x3e5c0(%rsi,%rbx,8)
140068884:     	leaq	(%rbx,%rbx,8), %rdx
140068888:     	leaq	(%rdx,%rdx,2), %rdx
14006888c:     	addq	%rbx, %rdx
14006888f:     	movb	$0x2, 0x36a(%rcx,%rdx)
140068897:     	leaq	(%rbx,%rbx,2), %rdx
14006889b:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
1400688a0:     	movups	0x410(%rbp), %xmm0
1400688a7:     	movups	0x420(%rbp), %xmm1
1400688ae:     	movups	%xmm1, 0x10(%rax)
1400688b2:     	movups	%xmm0, (%rax)
1400688b5:     	jmp	0x14006873a <.text+0x6773a>
1400688ba:     	addq	%rcx, %rax
1400688bd:     	addq	$0x15c28, %rax          # imm = 0x15C28
1400688c3:     	movq	0x98(%rax), %rax
1400688ca:     	movq	%rax, 0x468(%rbp)
1400688d1:     	movl	$0x1, %edi
1400688d6:     	callq	0x14009b2b0 <.text+0x9a2b0>
1400688db:     	testb	$0x1, %al
1400688dd:     	jne	0x140068760 <.text+0x67760>
1400688e3:     	movq	0x470(%rbp), %rax
1400688ea:     	movb	$0x9, (%rax)
1400688ed:     	jmp	0x14006873a <.text+0x6773a>
1400688f2:     	movq	0x470(%rbp), %rax
1400688f9:     	movq	%rbx, 0x8(%rax)
1400688fd:     	movb	$-0x1, (%rax)
140068900:     	jmp	0x14006873a <.text+0x6773a>
140068905:     	leaq	0x204354(%rip), %r9     # 0x14026cc60
14006890c:     	movl	$0x4000, %r8d           # imm = 0x4000
140068912:     	xorl	%ecx, %ecx
140068914:     	movq	%rax, %rdx
140068917:     	callq	0x140252240 <.text+0x251240>
14006891c:     	ud2


D:\CoapticCurrent\short-inline-replay-20261106\active-bytes\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009fa50:     	pushq	%rbp
14009fa51:     	pushq	%r15
14009fa53:     	pushq	%r14
14009fa55:     	pushq	%r13
14009fa57:     	pushq	%r12
14009fa59:     	pushq	%rsi
14009fa5a:     	pushq	%rdi
14009fa5b:     	pushq	%rbx
14009fa5c:     	subq	$0x218, %rsp            # imm = 0x218
14009fa63:     	leaq	0x80(%rsp), %rbp
14009fa6b:     	movaps	%xmm6, 0x180(%rbp)
14009fa72:     	movq	0xe8(%rcx), %rax
14009fa79:     	testq	%rax, %rax
14009fa7c:     	je	0x14009fd85 <.text+0x9ed85>
14009fa82:     	leaq	0xc0(%rcx), %rsi
14009fa89:     	movq	0xe0(%rcx), %r9
14009fa90:     	movq	0xc8(%rcx), %r10
14009fa97:     	movq	0xd0(%rcx), %r11
14009fa9e:     	addq	$0x28, %r10
14009faa2:     	xorl	%r8d, %r8d
14009faa5:     	movl	$0x1, %edi
14009faaa:     	movq	%rax, %r15
14009faad:     	xorl	%r14d, %r14d
14009fab0:     	imulq	$0x130, %r14, %r12      # imm = 0x130
14009fab7:     	addq	%r10, %r12
14009faba:     	jmp	0x14009facf <.text+0x9eacf>
14009fabc:     	nopl	(%rax)
14009fac0:     	incq	%r14
14009fac3:     	addq	$0x130, %r12            # imm = 0x130
14009faca:     	cmpq	%r14, %r15
14009facd:     	je	0x14009fb2b <.text+0x9eb2b>
14009facf:     	cmpq	%rax, %r14
14009fad2:     	jae	0x14009fac0 <.text+0x9eac0>
14009fad4:     	cmpl	$0x0, (%r9,%r14,4)
14009fad9:     	je	0x14009fac0 <.text+0x9eac0>
14009fadb:     	cmpq	%r11, %r14
14009fade:     	jae	0x14009fac0 <.text+0x9eac0>
14009fae0:     	cmpb	$0x2, -0xe(%r12)
14009fae6:     	je	0x14009fac0 <.text+0x9eac0>
14009fae8:     	movq	-0x8(%r12), %r15
14009faed:     	cmpb	$0x3, (%r12)
14009faf2:     	setne	%r12b
14009faf6:     	testq	%r15, %r15
14009faf9:     	sete	%r13b
14009fafd:     	orb	%r12b, %r13b
14009fb00:     	cmpq	%rbx, %r15
14009fb03:     	setae	%r12b
14009fb07:     	andb	%r8b, %r12b
14009fb0a:     	testb	%r13b, %r13b
14009fb0d:     	cmoveq	%rdi, %r8
14009fb11:     	orb	%r13b, %r12b
14009fb14:     	cmoveq	%r14, %rdx
14009fb18:     	cmoveq	%r15, %rbx
14009fb1c:     	incq	%r14
14009fb1f:     	cmpq	%rax, %r14
14009fb22:     	movq	%rax, %r15
14009fb25:     	cmovaq	%r14, %r15
14009fb29:     	jb	0x14009fab0 <.text+0x9eab0>
14009fb2b:     	testb	$0x1, %r8b
14009fb2f:     	je	0x14009fd85 <.text+0x9ed85>
14009fb35:     	cmpq	%rax, %rdx
14009fb38:     	jae	0x14009fd85 <.text+0x9ed85>
14009fb3e:     	movq	0xe0(%rcx), %r8
14009fb45:     	xorl	%eax, %eax
14009fb47:     	cmpl	$0x0, (%r8,%rdx,4)
14009fb4c:     	je	0x14009fd87 <.text+0x9ed87>
14009fb52:     	cmpq	0xd0(%rcx), %rdx
14009fb59:     	jae	0x14009fd87 <.text+0x9ed87>
14009fb5f:     	movq	0xc8(%rcx), %r9
14009fb66:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009fb6d:     	movzbl	0x1a(%r9,%rax), %r14d
14009fb73:     	cmpb	$0x2, %r14b
14009fb77:     	je	0x14009fd85 <.text+0x9ed85>
14009fb7d:     	addq	%rax, %r9
14009fb80:     	cmpb	$0x3, 0x28(%r9)
14009fb85:     	jne	0x14009fd85 <.text+0x9ed85>
14009fb8b:     	movzbl	0x1b(%r9), %r15d
14009fb90:     	movss	0x1c(%r9), %xmm6
14009fb96:     	movzwl	0x1c(%r9), %eax
14009fb9b:     	movq	0x30(%r9), %r10
14009fb9f:     	movups	(%r9), %xmm0
14009fba3:     	movups	0xa(%r9), %xmm1
14009fba8:     	movups	%xmm1, 0x11a(%rbp)
14009fbaf:     	movaps	%xmm0, 0x110(%rbp)
14009fbb6:     	cmpq	0x88(%rcx), %r10
14009fbbd:     	jae	0x14009fc13 <.text+0x9ec13>
14009fbbf:     	movq	0x80(%rcx), %r11
14009fbc6:     	cmpb	$0x1, (%r11,%r10)
14009fbcb:     	jne	0x14009fc13 <.text+0x9ec13>
14009fbcd:     	cmpq	0xa0(%rcx), %r10
14009fbd4:     	jae	0x14009fbe4 <.text+0x9ebe4>
14009fbd6:     	movq	0x98(%rcx), %rdi
14009fbdd:     	cmpb	$0x0, (%rdi,%r10)
14009fbe2:     	jne	0x14009fc13 <.text+0x9ec13>
14009fbe4:     	movb	$0x0, (%r11,%r10)
14009fbe9:     	decq	0xb0(%rcx)
14009fbf0:     	cmpq	0x70(%rcx), %r10
14009fbf4:     	jae	0x14009fc13 <.text+0x9ec13>
14009fbf6:     	movq	0x68(%rcx), %r11
14009fbfa:     	imulq	$0x58, %r10, %r10
14009fbfe:     	movq	$0x0, 0x30(%r11,%r10)
14009fc07:     	movb	$0x2, 0x52(%r11,%r10)
14009fc0d:     	movb	$0x2, 0x25(%r11,%r10)
14009fc13:     	cmpl	$0x0, (%r8,%rdx,4)
14009fc18:     	je	0x14009fc2e <.text+0x9ec2e>
14009fc1a:     	movl	$0x0, (%r8,%rdx,4)
14009fc22:     	decq	0xf8(%rcx)
14009fc29:     	movb	$0x2, 0x1a(%r9)
14009fc2e:     	movq	%rcx, %r12
14009fc31:     	xorps	%xmm0, %xmm0
14009fc34:     	movaps	%xmm0, 0x170(%rbp)
14009fc3b:     	movb	$0x0, 0x152(%rbp)
14009fc42:     	movw	%ax, 0x150(%rbp)
14009fc49:     	leaq	0x153(%rbp), %rcx
14009fc50:     	movw	$0x200, 0x15b(%rbp)     # imm = 0x200
14009fc59:     	movq	$0x0, 0x153(%rbp)
14009fc64:     	movq	$0x8, 0x130(%rbp)
14009fc6f:     	movq	$0x0, 0x138(%rbp)
14009fc7a:     	movq	$0x1, 0x140(%rbp)
14009fc85:     	movq	$0x0, 0x148(%rbp)
14009fc90:     	movq	%rcx, 0x30(%rsp)
14009fc95:     	movw	%ax, 0x28(%rsp)
14009fc9a:     	movq	$0x0, 0x58(%rsp)
14009fca3:     	movq	$0x1, 0x50(%rsp)
14009fcac:     	movq	$0x8, 0x48(%rsp)
14009fcb5:     	movq	$0x8, 0x40(%rsp)
14009fcbe:     	movq	$0x0, 0x38(%rsp)
14009fcc7:     	movb	$0x0, 0x20(%rsp)
14009fccc:     	leaq	0x160(%rbp), %rcx
14009fcd3:     	leaq	0x170(%rbp), %rdx
14009fcda:     	movl	$0x10, %r8d
14009fce0:     	movb	$0x2, %r9b
14009fce3:     	callq	0x140005590 <.text+0x4590>
14009fce8:     	movq	0x168(%rbp), %rdi
14009fcef:     	cmpq	$0x11, %rdi
14009fcf3:     	setae	%al
14009fcf6:     	orb	0x160(%rbp), %al
14009fcfc:     	jne	0x14009fdb2 <.text+0x9edb2>
14009fd02:     	movq	%r12, %rcx
14009fd05:     	addq	$0xd8, %rcx
14009fd0c:     	callq	0x140219750 <.text+0x218750>
14009fd11:     	cmpq	$0x1, %rax
14009fd15:     	jne	0x14009fdb2 <.text+0x9edb2>
14009fd1b:     	movups	0x11a(%rbp), %xmm0
14009fd22:     	movups	%xmm0, -0x16(%rbp)
14009fd26:     	movaps	0x110(%rbp), %xmm0
14009fd2d:     	movaps	%xmm0, -0x20(%rbp)
14009fd31:     	movb	%r14b, -0x6(%rbp)
14009fd35:     	movb	%r15b, -0x5(%rbp)
14009fd39:     	movss	%xmm6, -0x4(%rbp)
14009fd3e:     	movq	%rbx, (%rbp)
14009fd42:     	testq	%rdi, %rdi
14009fd45:     	je	0x14009fda2 <.text+0x9eda2>
14009fd47:     	movb	$0x1, 0x8(%rbp)
14009fd4b:     	movb	%dil, 0x9(%rbp)
14009fd4f:     	leaq	0xa(%rbp), %rbx
14009fd53:     	movl	$0x80, %r8d
14009fd59:     	subq	%rdi, %r8
14009fd5c:     	leaq	(%rdi,%rbp), %rcx
14009fd60:     	addq	$0xa, %rcx
14009fd64:     	movq	%rdx, %r14
14009fd67:     	xorl	%edx, %edx
14009fd69:     	callq	0x1402517c2 <.text+0x2507c2>
14009fd6e:     	leaq	0x170(%rbp), %rdx
14009fd75:     	movq	%rbx, %rcx
14009fd78:     	movq	%rdi, %r8
14009fd7b:     	callq	0x1402517b0 <.text+0x2507b0>
14009fd80:     	movq	%r14, %rdx
14009fd83:     	jmp	0x14009fda6 <.text+0x9eda6>
14009fd85:     	xorl	%eax, %eax
14009fd87:     	movaps	0x180(%rbp), %xmm6
14009fd8e:     	addq	$0x218, %rsp            # imm = 0x218
14009fd95:     	popq	%rbx
14009fd96:     	popq	%rdi
14009fd97:     	popq	%rsi
14009fd98:     	popq	%r12
14009fd9a:     	popq	%r13
14009fd9c:     	popq	%r14
14009fd9e:     	popq	%r15
14009fda0:     	popq	%rbp
14009fda1:     	retq
14009fda2:     	movb	$0x0, 0x8(%rbp)
14009fda6:     	leaq	-0x20(%rbp), %r8
14009fdaa:     	movq	%rsi, %rcx
14009fdad:     	callq	0x14000b6a0 <.text+0xa6a0>
14009fdb2:     	movb	$0x1, %al
14009fdb4:     	jmp	0x14009fd87 <.text+0x9ed87>

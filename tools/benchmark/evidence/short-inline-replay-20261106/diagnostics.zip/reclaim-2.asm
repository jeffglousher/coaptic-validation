
D:\CoapticCurrent\short-inline-replay-20261106\active-bytes\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009ed90:     	pushq	%rbp
14009ed91:     	pushq	%r15
14009ed93:     	pushq	%r14
14009ed95:     	pushq	%r13
14009ed97:     	pushq	%r12
14009ed99:     	pushq	%rsi
14009ed9a:     	pushq	%rdi
14009ed9b:     	pushq	%rbx
14009ed9c:     	subq	$0x218, %rsp            # imm = 0x218
14009eda3:     	leaq	0x80(%rsp), %rbp
14009edab:     	movaps	%xmm6, 0x180(%rbp)
14009edb2:     	leaq	0x3580(%rcx), %r8
14009edb9:     	leaq	0x3f10(%rcx), %rsi
14009edc0:     	leaq	0x3f38(%rcx), %rax
14009edc7:     	xorl	%r10d, %r10d
14009edca:     	movl	$0x1, %r11d
14009edd0:     	xorl	%r9d, %r9d
14009edd3:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009edda:     	addq	%rax, %rdi
14009eddd:     	jmp	0x14009edf0 <.text+0x9ddf0>
14009eddf:     	nop
14009ede0:     	incq	%r10
14009ede3:     	addq	$0x130, %rdi            # imm = 0x130
14009edea:     	cmpq	$0x4, %r10
14009edee:     	je	0x14009ee3a <.text+0x9de3a>
14009edf0:     	cmpl	$0x0, 0x43d0(%rcx,%r10,4)
14009edf9:     	je	0x14009ede0 <.text+0x9dde0>
14009edfb:     	cmpb	$0x2, -0xe(%rdi)
14009edff:     	je	0x14009ede0 <.text+0x9dde0>
14009ee01:     	cmpb	$0x3, (%rdi)
14009ee04:     	movq	-0x8(%rdi), %rdi
14009ee08:     	setne	%bl
14009ee0b:     	testq	%rdi, %rdi
14009ee0e:     	sete	%r15b
14009ee12:     	orb	%bl, %r15b
14009ee15:     	cmpq	%r14, %rdi
14009ee18:     	setae	%bl
14009ee1b:     	andb	%r9b, %bl
14009ee1e:     	testb	%r15b, %r15b
14009ee21:     	cmoveq	%r11, %r9
14009ee25:     	orb	%r15b, %bl
14009ee28:     	cmoveq	%r10, %rdx
14009ee2c:     	cmoveq	%rdi, %r14
14009ee30:     	cmpq	$0x3, %r10
14009ee34:     	leaq	0x1(%r10), %r10
14009ee38:     	jb	0x14009edd3 <.text+0x9ddd3>
14009ee3a:     	xorl	%eax, %eax
14009ee3c:     	cmpq	$0x1, %r9
14009ee40:     	jne	0x14009ef4d <.text+0x9df4d>
14009ee46:     	cmpq	$0x4, %rdx
14009ee4a:     	jae	0x14009ef4d <.text+0x9df4d>
14009ee50:     	cmpl	$0x0, 0x43d0(%rcx,%rdx,4)
14009ee58:     	je	0x14009ef4b <.text+0x9df4b>
14009ee5e:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009ee65:     	movzbl	0x1a(%rsi,%rax), %r15d
14009ee6b:     	cmpb	$0x2, %r15b
14009ee6f:     	je	0x14009ef4b <.text+0x9df4b>
14009ee75:     	addq	%rsi, %rax
14009ee78:     	cmpb	$0x3, 0x28(%rax)
14009ee7c:     	jne	0x14009ef4b <.text+0x9df4b>
14009ee82:     	movq	0x30(%rax), %r9
14009ee86:     	movq	(%rax), %r12
14009ee89:     	movq	0x8(%rax), %rdx
14009ee8d:     	movq	%rdx, 0x170(%rbp)
14009ee94:     	movl	0x10(%rax), %r13d
14009ee98:     	movl	0x14(%rax), %edi
14009ee9b:     	movzwl	0x18(%rax), %edx
14009ee9f:     	movw	%dx, 0x17e(%rbp)
14009eea6:     	movzbl	0x1b(%rax), %edx
14009eeaa:     	movb	%dl, 0x17d(%rbp)
14009eeb0:     	movss	0x1c(%rax), %xmm6
14009eeb5:     	movzwl	0x1c(%rax), %eax
14009eeb9:     	movzwl	%ax, %edx
14009eebc:     	cmpq	$0x1, %r9
14009eec0:     	ja	0x14009ef15 <.text+0x9df15>
14009eec2:     	cmpb	$0x1, 0x3f08(%rcx,%r9)
14009eecb:     	jne	0x14009ef15 <.text+0x9df15>
14009eecd:     	cmpb	$0x0, 0x3f0a(%rcx,%r9)
14009eed6:     	jne	0x14009ef15 <.text+0x9df15>
14009eed8:     	movb	$0x0, 0x3f08(%rcx,%r9)
14009eee1:     	decq	0x3f00(%rcx)
14009eee8:     	movq	$0x0, 0x3e80(%rcx,%r9,8)
14009eef4:     	leaq	(%r9,%r9,8), %r10
14009eef8:     	leaq	(%r10,%r10,2), %r10
14009eefc:     	addq	%r9, %r10
14009eeff:     	movb	$0x2, 0x95a(%r8,%r10)
14009ef08:     	leaq	(%r9,%r9,2), %r9
14009ef0c:     	movb	$0x2, 0x91d(%r8,%r9,8)
14009ef15:     	addl	$0x2, %edx
14009ef18:     	movb	$0x1, %r9b
14009ef1b:     	cmpl	%edx, 0x43d0(%rcx)
14009ef21:     	jne	0x14009ef31 <.text+0x9df31>
14009ef23:     	movzbl	0x3f2a(%rcx), %r8d
14009ef2b:     	cmpb	$0x2, %r8b
14009ef2f:     	jne	0x14009ef68 <.text+0x9df68>
14009ef31:     	xorl	%r8d, %r8d
14009ef34:     	cmpl	%edx, 0x43d4(%rcx)
14009ef3a:     	movl	%edi, 0x178(%rbp)
14009ef40:     	jne	0x14009effc <.text+0x9dffc>
14009ef46:     	jmp	0x14009efea <.text+0x9dfea>
14009ef4b:     	xorl	%eax, %eax
14009ef4d:     	movaps	0x180(%rbp), %xmm6
14009ef54:     	addq	$0x218, %rsp            # imm = 0x218
14009ef5b:     	popq	%rbx
14009ef5c:     	popq	%rdi
14009ef5d:     	popq	%rsi
14009ef5e:     	popq	%r12
14009ef60:     	popq	%r13
14009ef62:     	popq	%r14
14009ef64:     	popq	%r15
14009ef66:     	popq	%rbp
14009ef67:     	retq
14009ef68:     	cmpw	%ax, 0x3f2c(%rcx)
14009ef6f:     	sete	%r9b
14009ef73:     	cmpl	%r13d, 0x3f20(%rcx)
14009ef7a:     	sete	%r10b
14009ef7e:     	andb	%r9b, %r10b
14009ef81:     	cmpl	%edi, 0x3f24(%rcx)
14009ef87:     	sete	%r9b
14009ef8b:     	movzwl	0x17e(%rbp), %r11d
14009ef93:     	cmpw	%r11w, 0x3f28(%rcx)
14009ef9b:     	sete	%r11b
14009ef9f:     	andb	%r9b, %r11b
14009efa2:     	andb	%r10b, %r11b
14009efa5:     	cmpb	%r15b, %r8b
14009efa8:     	sete	%r8b
14009efac:     	movq	0x3f18(%rcx), %r9
14009efb3:     	xorq	0x170(%rbp), %r9
14009efba:     	movq	0x3f10(%rcx), %r10
14009efc1:     	xorq	%r12, %r10
14009efc4:     	orq	%r9, %r10
14009efc7:     	sete	%r9b
14009efcb:     	andb	%r8b, %r9b
14009efce:     	andb	%r11b, %r9b
14009efd1:     	movzbl	%r9b, %r8d
14009efd5:     	movl	%r8d, %r9d
14009efd8:     	xorb	$0x1, %r9b
14009efdc:     	cmpl	%edx, 0x43d4(%rcx)
14009efe2:     	movl	%edi, 0x178(%rbp)
14009efe8:     	jne	0x14009effc <.text+0x9dffc>
14009efea:     	movzbl	0x405a(%rcx), %r10d
14009eff2:     	cmpb	$0x2, %r10b
14009eff6:     	jne	0x14009f0a6 <.text+0x9e0a6>
14009effc:     	xorl	%r9d, %r9d
14009efff:     	cmpl	%edx, 0x43d8(%rcx)
14009f005:     	jne	0x14009f143 <.text+0x9e143>
14009f00b:     	movzbl	0x418a(%rcx), %r10d
14009f013:     	cmpb	$0x2, %r10b
14009f017:     	je	0x14009f143 <.text+0x9e143>
14009f01d:     	cmpb	%r15b, %r10b
14009f020:     	jne	0x14009f143 <.text+0x9e143>
14009f026:     	cmpw	%ax, 0x418c(%rcx)
14009f02d:     	jne	0x14009f143 <.text+0x9e143>
14009f033:     	cmpl	%r13d, 0x4180(%rcx)
14009f03a:     	jne	0x14009f143 <.text+0x9e143>
14009f040:     	cmpl	%edi, 0x4184(%rcx)
14009f046:     	jne	0x14009f143 <.text+0x9e143>
14009f04c:     	movzwl	0x17e(%rbp), %r10d
14009f054:     	cmpw	%r10w, 0x4188(%rcx)
14009f05c:     	jne	0x14009f143 <.text+0x9e143>
14009f062:     	movq	0x4170(%rcx), %r10
14009f069:     	xorq	%r12, %r10
14009f06c:     	movq	0x4178(%rcx), %r11
14009f073:     	xorq	0x170(%rbp), %r11
14009f07a:     	orq	%r10, %r11
14009f07d:     	jne	0x14009f143 <.text+0x9e143>
14009f083:     	movb	$0x1, %dil
14009f086:     	testq	%r8, %r8
14009f089:     	jne	0x14009f1c6 <.text+0x9e1c6>
14009f08f:     	movl	$0x1, %r8d
14009f095:     	movl	$0x2, %r9d
14009f09b:     	movl	0x178(%rbp), %edi
14009f0a1:     	jmp	0x14009f143 <.text+0x9e143>
14009f0a6:     	cmpw	%ax, 0x405c(%rcx)
14009f0ad:     	setne	%r11b
14009f0b1:     	cmpl	%r13d, 0x4050(%rcx)
14009f0b8:     	setne	%bl
14009f0bb:     	orb	%r11b, %bl
14009f0be:     	cmpl	%edi, 0x4054(%rcx)
14009f0c4:     	setne	%r11b
14009f0c8:     	movzwl	0x17e(%rbp), %edi
14009f0cf:     	cmpw	%di, 0x4058(%rcx)
14009f0d6:     	setne	%dil
14009f0da:     	orb	%r11b, %dil
14009f0dd:     	orb	%bl, %dil
14009f0e0:     	cmpb	%r15b, %r10b
14009f0e3:     	setne	%r11b
14009f0e7:     	movq	0x4048(%rcx), %r10
14009f0ee:     	xorq	0x170(%rbp), %r10
14009f0f5:     	movq	0x4040(%rcx), %rbx
14009f0fc:     	xorq	%r12, %rbx
14009f0ff:     	orq	%r10, %rbx
14009f102:     	setne	%r10b
14009f106:     	orb	%r11b, %r10b
14009f109:     	orb	%dil, %r10b
14009f10c:     	orb	%r10b, %r9b
14009f10f:     	testb	%r10b, %r10b
14009f112:     	movl	$0x1, %r11d
14009f118:     	cmoveq	%r11, %r8
14009f11c:     	testb	$0x1, %r9b
14009f120:     	je	0x14009f1c0 <.text+0x9e1c0>
14009f126:     	notb	%r10b
14009f129:     	movzbl	%r10b, %r9d
14009f12d:     	andl	$0x1, %r9d
14009f131:     	movl	0x178(%rbp), %edi
14009f137:     	cmpl	%edx, 0x43d8(%rcx)
14009f13d:     	je	0x14009f00b <.text+0x9e00b>
14009f143:     	cmpl	%edx, 0x43dc(%rcx)
14009f149:     	jne	0x14009f157 <.text+0x9e157>
14009f14b:     	movzbl	0x42ba(%rcx), %edx
14009f152:     	cmpb	$0x2, %dl
14009f155:     	jne	0x14009f163 <.text+0x9e163>
14009f157:     	xorl	%edi, %edi
14009f159:     	testq	%r8, %r8
14009f15c:     	jne	0x14009f1c6 <.text+0x9e1c6>
14009f15e:     	jmp	0x14009f1f0 <.text+0x9e1f0>
14009f163:     	cmpb	%r15b, %dl
14009f166:     	jne	0x14009f157 <.text+0x9e157>
14009f168:     	cmpw	%ax, 0x42bc(%rcx)
14009f16f:     	jne	0x14009f157 <.text+0x9e157>
14009f171:     	cmpl	%r13d, 0x42b0(%rcx)
14009f178:     	jne	0x14009f157 <.text+0x9e157>
14009f17a:     	cmpl	%edi, 0x42b4(%rcx)
14009f180:     	jne	0x14009f157 <.text+0x9e157>
14009f182:     	movzwl	0x17e(%rbp), %edx
14009f189:     	cmpw	%dx, 0x42b8(%rcx)
14009f190:     	jne	0x14009f157 <.text+0x9e157>
14009f192:     	movq	0x42a0(%rcx), %rdx
14009f199:     	xorq	%r12, %rdx
14009f19c:     	movq	0x42a8(%rcx), %r10
14009f1a3:     	xorq	0x170(%rbp), %r10
14009f1aa:     	orq	%rdx, %r10
14009f1ad:     	jne	0x14009f157 <.text+0x9e157>
14009f1af:     	testq	%r8, %r8
14009f1b2:     	movl	$0x3, %edx
14009f1b7:     	cmoveq	%rdx, %r9
14009f1bb:     	movl	%r8d, %edi
14009f1be:     	jmp	0x14009f1c6 <.text+0x9e1c6>
14009f1c0:     	movb	$0x1, %dil
14009f1c3:     	xorl	%r9d, %r9d
14009f1c6:     	cmpl	$0x0, 0x43d0(%rcx,%r9,4)
14009f1cf:     	je	0x14009f1f0 <.text+0x9e1f0>
14009f1d1:     	movl	$0x0, 0x43d0(%rcx,%r9,4)
14009f1dd:     	decq	0x43e8(%rcx)
14009f1e4:     	imulq	$0x130, %r9, %rdx       # imm = 0x130
14009f1eb:     	movb	$0x2, 0x1a(%rsi,%rdx)
14009f1f0:     	movl	%r13d, 0x16c(%rbp)
14009f1f7:     	movq	%r12, %r13
14009f1fa:     	xorps	%xmm0, %xmm0
14009f1fd:     	movaps	%xmm0, 0x150(%rbp)
14009f204:     	movb	$0x0, 0x132(%rbp)
14009f20b:     	movw	%ax, 0x130(%rbp)
14009f212:     	leaq	0x133(%rbp), %rdx
14009f219:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009f222:     	movq	$0x0, 0x133(%rbp)
14009f22d:     	movq	$0x8, 0x110(%rbp)
14009f238:     	movq	$0x0, 0x118(%rbp)
14009f243:     	movq	$0x1, 0x120(%rbp)
14009f24e:     	movq	$0x0, 0x128(%rbp)
14009f259:     	movq	%rdx, 0x30(%rsp)
14009f25e:     	movw	%ax, 0x28(%rsp)
14009f263:     	movq	$0x0, 0x58(%rsp)
14009f26c:     	movq	$0x1, 0x50(%rsp)
14009f275:     	movq	$0x8, 0x48(%rsp)
14009f27e:     	movq	$0x8, 0x40(%rsp)
14009f287:     	movq	$0x0, 0x38(%rsp)
14009f290:     	movb	$0x0, 0x20(%rsp)
14009f295:     	leaq	0x140(%rbp), %rax
14009f29c:     	leaq	0x150(%rbp), %rdx
14009f2a3:     	movl	$0x10, %r8d
14009f2a9:     	movq	%rcx, %r12
14009f2ac:     	movq	%rax, %rcx
14009f2af:     	movb	$0x2, %r9b
14009f2b2:     	callq	0x140005590 <.text+0x4590>
14009f2b7:     	cmpb	$0x0, 0x140(%rbp)
14009f2be:     	jne	0x14009f454 <.text+0x9e454>
14009f2c4:     	testb	%dil, %dil
14009f2c7:     	jne	0x14009f454 <.text+0x9e454>
14009f2cd:     	movq	0x148(%rbp), %rbx
14009f2d4:     	cmpq	$0x10, %rbx
14009f2d8:     	ja	0x14009f454 <.text+0x9e454>
14009f2de:     	movq	%r12, %rax
14009f2e1:     	cmpq	$0x4, 0x43e8(%r12)
14009f2ea:     	je	0x14009f454 <.text+0x9e454>
14009f2f0:     	movq	0x43e0(%rax), %rdi
14009f2f7:     	cmpq	$0x3, %rdi
14009f2fb:     	ja	0x14009f46c <.text+0x9e46c>
14009f301:     	cmpl	$0x0, 0x43d0(%rax,%rdi,4)
14009f309:     	je	0x14009f383 <.text+0x9e383>
14009f30b:     	leaq	(,%rdi,4), %rdx
14009f313:     	xorl	%ecx, %ecx
14009f315:     	cmpl	$0x0, 0x43d0(%rax,%rdx)
14009f31d:     	je	0x14009f376 <.text+0x9e376>
14009f31f:     	addq	$0x4, %rdx
14009f323:     	decq	%rcx
14009f326:     	cmpq	$0x10, %rdx
14009f32a:     	jne	0x14009f315 <.text+0x9e315>
14009f32c:     	testq	%rdi, %rdi
14009f32f:     	je	0x14009f454 <.text+0x9e454>
14009f335:     	cmpl	$0x0, 0x43d0(%rax)
14009f33c:     	je	0x14009f45b <.text+0x9e45b>
14009f342:     	cmpq	$0x1, %rdi
14009f346:     	je	0x14009f454 <.text+0x9e454>
14009f34c:     	cmpl	$0x0, 0x43d4(%rax)
14009f353:     	je	0x14009f462 <.text+0x9e462>
14009f359:     	cmpq	$0x2, %rdi
14009f35d:     	je	0x14009f454 <.text+0x9e454>
14009f363:     	movl	$0x2, %edi
14009f368:     	cmpl	$0x0, 0x43d8(%rax)
14009f36f:     	je	0x14009f379 <.text+0x9e379>
14009f371:     	jmp	0x14009f454 <.text+0x9e454>
14009f376:     	subq	%rcx, %rdi
14009f379:     	cmpq	$0x4, %rdi
14009f37d:     	jae	0x14009f482 <.text+0x9e482>
14009f383:     	movl	$0x1, 0x43d0(%rax,%rdi,4)
14009f38e:     	incq	0x43e8(%rax)
14009f395:     	leaq	0x1(%rdi), %rcx
14009f399:     	xorl	%edx, %edx
14009f39b:     	cmpq	$0x4, %rcx
14009f39f:     	cmovneq	%rcx, %rdx
14009f3a3:     	movq	%rdx, 0x43e0(%rax)
14009f3aa:     	movq	0x170(%rbp), %rcx
14009f3b1:     	movq	%rcx, -0x18(%rbp)
14009f3b5:     	movq	%r13, -0x20(%rbp)
14009f3b9:     	movl	0x16c(%rbp), %ecx
14009f3bf:     	movl	%ecx, -0x10(%rbp)
14009f3c2:     	movl	0x178(%rbp), %ecx
14009f3c8:     	movl	%ecx, -0xc(%rbp)
14009f3cb:     	movzwl	0x17e(%rbp), %ecx
14009f3d2:     	movw	%cx, -0x8(%rbp)
14009f3d6:     	movb	%r15b, -0x6(%rbp)
14009f3da:     	movzbl	0x17d(%rbp), %ecx
14009f3e1:     	movb	%cl, -0x5(%rbp)
14009f3e4:     	movss	%xmm6, -0x4(%rbp)
14009f3e9:     	movq	%r14, (%rbp)
14009f3ed:     	testq	%rbx, %rbx
14009f3f0:     	je	0x14009f42c <.text+0x9e42c>
14009f3f2:     	movb	$0x1, 0x8(%rbp)
14009f3f6:     	movb	%bl, 0x9(%rbp)
14009f3f9:     	leaq	0xa(%rbp), %r14
14009f3fd:     	movl	$0x80, %r8d
14009f403:     	subq	%rbx, %r8
14009f406:     	leaq	(%rbx,%rbp), %rcx
14009f40a:     	addq	$0xa, %rcx
14009f40e:     	xorl	%edx, %edx
14009f410:     	callq	0x1402517c2 <.text+0x2507c2>
14009f415:     	leaq	0x150(%rbp), %rdx
14009f41c:     	movq	%r14, %rcx
14009f41f:     	movq	%rbx, %r8
14009f422:     	callq	0x1402517b0 <.text+0x2507b0>
14009f427:     	movq	%r12, %rax
14009f42a:     	jmp	0x14009f430 <.text+0x9e430>
14009f42c:     	movb	$0x0, 0x8(%rbp)
14009f430:     	movzwl	-0x4(%rbp), %ecx
14009f434:     	addl	$0x2, %ecx
14009f437:     	movl	%ecx, 0x43d0(%rax,%rdi,4)
14009f43e:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009f445:     	addq	%rax, %rsi
14009f448:     	leaq	-0x20(%rbp), %rcx
14009f44c:     	movq	%rsi, %rdx
14009f44f:     	callq	0x14000b1c0 <.text+0xa1c0>
14009f454:     	movb	$0x1, %al
14009f456:     	jmp	0x14009ef4d <.text+0x9df4d>
14009f45b:     	xorl	%edi, %edi
14009f45d:     	jmp	0x14009f379 <.text+0x9e379>
14009f462:     	movl	$0x1, %edi
14009f467:     	jmp	0x14009f379 <.text+0x9e379>
14009f46c:     	leaq	0x1cd93d(%rip), %r8     # 0x14026cdb0
14009f473:     	movl	$0x4, %edx
14009f478:     	movq	%rdi, %rcx
14009f47b:     	callq	0x140252033 <.text+0x251033>
14009f480:     	ud2
14009f482:     	leaq	0x1cd93f(%rip), %r8     # 0x14026cdc8
14009f489:     	movl	$0x4, %edx
14009f48e:     	movq	%rdi, %rcx
14009f491:     	callq	0x140252033 <.text+0x251033>
14009f496:     	ud2

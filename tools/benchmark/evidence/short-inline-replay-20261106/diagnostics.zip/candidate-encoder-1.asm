
D:\CoapticCurrent\short-inline-replay-20261106\active-bytes\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068310:     	pushq	%rbp
140068311:     	pushq	%r15
140068313:     	pushq	%r14
140068315:     	pushq	%r13
140068317:     	pushq	%r12
140068319:     	pushq	%rsi
14006831a:     	pushq	%rdi
14006831b:     	pushq	%rbx
14006831c:     	subq	$0x508, %rsp            # imm = 0x508
140068323:     	leaq	0x80(%rsp), %rbp
14006832b:     	movq	0x500(%rbp), %r12
140068332:     	movq	0x8(%r12), %rdi
140068337:     	movl	$0x3, %r10d
14006833d:     	cmpq	$0x3, %rdi
140068341:     	ja	0x140068421 <.text+0x67421>
140068347:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
14006834f:     	jne	0x140068421 <.text+0x67421>
140068355:     	movq	0x26700(%rdx,%rdi,8), %rax
14006835d:     	cmpq	$0x4001, %rax           # imm = 0x4001
140068363:     	jae	0x1400685fe <.text+0x675fe>
140068369:     	movq	0x10(%r12), %r11
14006836e:     	movq	0x18(%r12), %r15
140068373:     	movq	%r15, %rsi
140068376:     	movl	$0xb, %r10d
14006837c:     	addq	%r11, %rsi
14006837f:     	jb	0x140068421 <.text+0x67421>
140068385:     	cmpq	$0x400, %r15            # imm = 0x400
14006838c:     	ja	0x140068421 <.text+0x67421>
140068392:     	cmpq	%rax, %rsi
140068395:     	ja	0x140068421 <.text+0x67421>
14006839b:     	movq	%r8, %r13
14006839e:     	movq	%r9, 0x470(%rbp)
1400683a5:     	movq	%rcx, 0x480(%rbp)
1400683ac:     	movzbl	0x508(%rbp), %r14d
1400683b4:     	movq	%rdi, %rax
1400683b7:     	shlq	$0xe, %rax
1400683bb:     	movq	%rdx, %rsi
1400683be:     	leaq	(%rdx,%rax), %rbx
1400683c2:     	addq	$0x16700, %rbx          # imm = 0x16700
1400683c9:     	addq	%r11, %rbx
1400683cc:     	movl	$0x400, %r8d            # imm = 0x400
1400683d2:     	cmpq	$0x400, %r15            # imm = 0x400
1400683d9:     	je	0x1400683e8 <.text+0x673e8>
1400683db:     	movq	%rbp, %rcx
1400683de:     	xorl	%edx, %edx
1400683e0:     	callq	0x1402517c2 <.text+0x2507c2>
1400683e5:     	movq	%r15, %r8
1400683e8:     	movq	%rbp, %rcx
1400683eb:     	movq	%rbx, %rdx
1400683ee:     	callq	0x1402517b0 <.text+0x2507b0>
1400683f3:     	testb	%r14b, %r14b
1400683f6:     	je	0x14006843c <.text+0x6743c>
1400683f8:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
1400683ff:     	movq	%rsi, %rcx
140068402:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
14006840b:     	jne	0x1400685b3 <.text+0x675b3>
140068411:     	xorl	%edi, %edi
140068413:     	callq	0x14009b2b0 <.text+0x9a2b0>
140068418:     	testb	$0x1, %al
14006841a:     	jne	0x14006844e <.text+0x6744e>
14006841c:     	jmp	0x1400685dc <.text+0x675dc>
140068421:     	movb	$0xa, (%rcx)
140068424:     	movq	%r10, 0x8(%rcx)
140068428:     	addq	$0x508, %rsp            # imm = 0x508
14006842f:     	popq	%rbx
140068430:     	popq	%rdi
140068431:     	popq	%rsi
140068432:     	popq	%r12
140068434:     	popq	%r13
140068436:     	popq	%r14
140068438:     	popq	%r15
14006843a:     	popq	%rbp
14006843b:     	retq
14006843c:     	xorl	%edi, %edi
14006843e:     	movq	%rsi, %rcx
140068441:     	callq	0x14009b2b0 <.text+0x9a2b0>
140068446:     	testb	$0x1, %al
140068448:     	je	0x1400685dc <.text+0x675dc>
14006844e:     	movq	%rdx, %rbx
140068451:     	movq	0x518(%rbp), %rdx
140068458:     	movq	0x510(%rbp), %r8
14006845f:     	movzwl	0x4f8(%rbp), %ecx
140068466:     	movzbl	0x4f0(%rbp), %eax
14006846d:     	movq	(%r12), %r9
140068471:     	movq	%rdi, 0x440(%rbp)
140068478:     	movq	0x478(%rbp), %r10
14006847f:     	movq	%r10, 0x448(%rbp)
140068486:     	movq	%r9, 0x450(%rbp)
14006848d:     	movb	%r14b, 0x458(%rbp)
140068494:     	movups	0x60(%r13), %xmm0
140068499:     	movups	0x6c(%r13), %xmm1
14006849e:     	movups	%xmm1, 0x40c(%rbp)
1400684a5:     	movaps	%xmm0, 0x400(%rbp)
1400684ac:     	leaq	0x8e(%r13), %r9
1400684b3:     	movq	0x7e(%r13), %r10
1400684b7:     	movq	0x85(%r13), %r11
1400684be:     	movq	%r11, 0x467(%rbp)
1400684c5:     	movq	%r10, 0x460(%rbp)
1400684cc:     	leaq	0x460(%rbp), %r10
1400684d3:     	movq	%r10, 0x70(%rsp)
1400684d8:     	movq	%rdx, 0x68(%rsp)
1400684dd:     	movq	%r8, 0x60(%rsp)
1400684e2:     	movq	%r13, 0x58(%rsp)
1400684e7:     	leaq	0x440(%rbp), %rdx
1400684ee:     	movq	%rdx, 0x50(%rsp)
1400684f3:     	movq	%r15, 0x48(%rsp)
1400684f8:     	movq	%rbp, %rdx
1400684fb:     	movq	%rdx, 0x40(%rsp)
140068500:     	movq	0x470(%rbp), %rdx
140068507:     	movq	%rdx, 0x38(%rsp)
14006850c:     	movq	%r9, 0x30(%rsp)
140068511:     	movw	%cx, 0x28(%rsp)
140068516:     	movb	%al, 0x20(%rsp)
14006851a:     	leaq	0x420(%rbp), %rcx
140068521:     	leaq	0x400(%rbp), %r8
140068528:     	movq	%rsi, %rdx
14006852b:     	movq	%rbx, %r9
14006852e:     	callq	0x1400812b0 <.text+0x802b0>
140068533:     	cmpb	$-0x1, 0x420(%rbp)
14006853a:     	je	0x1400685eb <.text+0x675eb>
140068540:     	cmpb	$0x1, 0x326f0(%rsi,%rbx)
140068548:     	movq	0x480(%rbp), %rax
14006854f:     	jne	0x140068599 <.text+0x67599>
140068551:     	cmpb	$0x0, 0x32710(%rsi,%rbx)
140068559:     	jne	0x140068599 <.text+0x67599>
14006855b:     	movb	$0x0, 0x326f0(%rsi,%rbx)
140068563:     	decq	0x32738(%rsi)
14006856a:     	leaq	0x326f0(%rsi), %rcx
140068571:     	movq	$0x0, 0x3e5c0(%rsi,%rbx,8)
14006857d:     	leaq	(%rbx,%rbx,8), %rdx
140068581:     	leaq	(%rdx,%rdx,2), %rdx
140068585:     	addq	%rbx, %rdx
140068588:     	movb	$0x2, 0x36a(%rcx,%rdx)
140068590:     	leaq	(%rbx,%rbx,2), %rdx
140068594:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140068599:     	movups	0x420(%rbp), %xmm0
1400685a0:     	movups	0x430(%rbp), %xmm1
1400685a7:     	movups	%xmm1, 0x10(%rax)
1400685ab:     	movups	%xmm0, (%rax)
1400685ae:     	jmp	0x140068428 <.text+0x67428>
1400685b3:     	addq	%rcx, %rax
1400685b6:     	addq	$0x15c28, %rax          # imm = 0x15C28
1400685bc:     	movq	0x98(%rax), %rax
1400685c3:     	movq	%rax, 0x478(%rbp)
1400685ca:     	movl	$0x1, %edi
1400685cf:     	callq	0x14009b2b0 <.text+0x9a2b0>
1400685d4:     	testb	$0x1, %al
1400685d6:     	jne	0x14006844e <.text+0x6744e>
1400685dc:     	movq	0x480(%rbp), %rax
1400685e3:     	movb	$0x9, (%rax)
1400685e6:     	jmp	0x140068428 <.text+0x67428>
1400685eb:     	movq	0x480(%rbp), %rax
1400685f2:     	movq	%rbx, 0x8(%rax)
1400685f6:     	movb	$-0x1, (%rax)
1400685f9:     	jmp	0x140068428 <.text+0x67428>
1400685fe:     	leaq	0x20465b(%rip), %r9     # 0x14026cc60
140068605:     	movl	$0x4000, %r8d           # imm = 0x4000
14006860b:     	xorl	%ecx, %ecx
14006860d:     	movq	%rax, %rdx
140068610:     	callq	0x140252240 <.text+0x251240>
140068615:     	ud2

"""Render the retained borrowed-encoding cohort without executing probes."""
from pathlib import Path
import json, subprocess, sys
out=Path('D:/codex-work/coaptic-validation/tools/benchmark/evidence/short-inline-replay-20261106')
prior=out.parent/'owned-replay-reclaim-20261106'
v=(prior/'render.py').read_text(encoding='utf-8')
v=v.replace('Coaptic owned replay reclaim comparison','Coaptic short replay integration comparison')
v=v.replace('32c32d1','6760b72')
v=v.replace("('owned-replay-reclaim-20261106','Owned reclaim / occupancy fast path')", "('owned-replay-reclaim-20261106','Owned reclaim / occupancy fast path'),('borrowed-reclaim-encoding-20261106','Borrowed reclaim encoding'),('short-inline-replay-20261106','Short replay with active-byte writer')")
v=v.replace('Candidate production code passes 929 library tests','Exact candidate passes 931 library tests')
start=v.index('<p class="bad">Additional emitted reclaim frame check:')
end=v.index('<h2>32-bit layout audit:',start)
v=v[:start]+'''<h2>Selected reclaim frames</h2><table><thead><tr><th>Compiler frame / bytes</th><th>Baseline</th><th>Candidate</th><th>Change</th></tr></thead><tbody><tr><td>SmallDevice</td><td>800</td><td>544</td><td>-256</td></tr><tr><td>Constrained with bodies</td><td>800</td><td>544</td><td>-256</td></tr><tr><td>Service fixed</td><td>784</td><td>544</td><td>-240</td></tr><tr><td>Service allocated</td><td>800</td><td>544</td><td>-256</td></tr></tbody></table><p>Encoding now fills a borrowed 16-byte buffer and returns only its length. Storage constructs the replay row. This removes the preceding candidate's extra 304-byte row-return copy. These selected compiler reservations do not establish peak stack.</p>'''+v[end:]
start=v.index('<p>The preceding occupancy integration failed five CPU bounds.')
end=v.index('<p>Sync and actual async progress',start)
v=v[:start]+'''<p>The preceding owned-reclaim integration failed three fixed-Service 16 KiB CPU bounds and grew its fixed reclaim frame by 32 bytes. Its full-row return boundary introduced an extra emitted 304-byte copy. This candidate replaces that boundary with borrowed encoding and checked length, while retaining the search reduction and immediate-free-cursor acquisition.</p><p>931 library, 11 allocation, 27 retained-transfer and 13 footprint tests pass. General review found no issue. A dedicated regression checks callback invocation count and release-before-encoding; models cover refusal, excessive lengths, zero-length replay, duplicates, failed TX release and slot rotation. One fresh cohort, no replacement samples.</p>'''+v[end:]
(out/'render.py').write_text(v,encoding='utf-8')
subprocess.run([sys.executable,'-B',str(out/'render.py')],check=True)
r=json.loads((out/'measurement.json').read_text())
state='passes the frozen runtime preservation rule; broader qualification and merge remain separate' if r['runtime_accepted'] else 'fails the frozen runtime preservation rule and is rejected'
readme=(prior/'README.md').read_text(encoding='utf-8')
start=readme.index('Exact candidate');end=readme.index('The bounded diagnostic',start)
readme=readme[:start]+f'''Exact candidate `6760b72a8ed07b6a108cde24eeb36e552a0f076d` versus pinned baseline
`bd63199b652193b4c0a882e5840e72d992cf1362` {state}.
All64 pairs across28 workloads are retained; {len(r['failed_point_guards'])} cell
upper bounds exceed1.02. `comparison.html` contains CPU charts and comparable
tables. Earlier failures remain rejected; no unchanged candidate was resampled.

The previous candidate returned a complete replay row across the callback,
introducing an extra304-byte copy. The new callback fills borrowed16-byte scratch
and returns only an optional length. Storage validates the length and constructs
the same-key/deadline replay row. Callbacks returningNone or an excessive length
skip insertion after release/removal. An empty encoding retains the ordinary
empty replay behavior. Public fixed-table duplicate and rotating cursor behavior
are unchanged; allocated unique-key storage still avoids both repeated searches.

'''+readme[end:]
readme=readme.replace('# Owned replay reclaim integration','# Short replay integration')
start=readme.index('Host SmallDevice App');end=readme.index('Run `python -B verify.py`',start)
readme=readme[:start]+'''Host SmallDevice App saves56 bytes; fixed Service App saves832. Allocated
Service saves24 inline bytes plus832 requested pool bytes. Selected complete
futures and encoder frames are unchanged. Selected reclaim frames become544
bytes in all four monomorphizations: baseline800 SmallDevice/Constrained with
bodies/allocated Service and784 fixed Service. The extra304-byte row-return
copy is absent. These reservations are not peak stack.

Actual Thumbv7EM unit-transport App reductions are24/320/16 bytes for SmallDevice,
fixed Service and allocated Service. Startup allocation counts match baseline.
These are exact owners, not peak RAM; heap excludes allocator metadata/rounding.
Static target layout does not establish device execution. Capacities/security
remain matched.

Before timing:931 library,11 allocation/failure-injection,27 retained-Q and13
footprint checks pass. General static review of32c32d1 to6760b72 found no
actionable issue. Dedicated callback order/count checks close the previous
coverage gap; models exercise None, zero and excessive encoding lengths.

'''+readme[end:]
(out/'README.md').write_text(readme,encoding='utf-8')

extra="""
The integrated candidate additionally uses a128-byte short replay variant for
lengths1..128, preserving full256-byte capacity. Key/deadline metadata precedes
the replay payload. The final emitted writer copies128 payload bytes plus metadata,
with8-byte caller and helper frames. Two untimed precursors are retained:
80a184c copied128 payload bytes but grew the caller frame8 to56; bf2c371 restored
8-byte frames but recovered a304-byte whole-row memcpy. Neither was timed.
6760b72 passes active bytes separately across the borrowed boundary. These static
facts motivated the cohort; they are not independent whole-App performance gains.
All lengths0..256,257-byte refusal, canonical long-to-short equality and TX owner
transitions are covered. Compact identity now describes current active replay;
discarded inactive replay bytes do not participate in equality/hash. Hash output
is not a stable serialized format. Startup capacities and security stay unchanged.
"""
with (out/'README.md').open('a',encoding='utf-8') as f:f.write(extra)
p=out/'render.py';s=p.read_text(encoding='utf-8')
s=s.replace('<h2>Selected reclaim frames</h2>','<h2>Short replay writes</h2><p>The final helper copies128 payload bytes plus metadata, with8-byte helper and caller frames. Full256-byte replay capacity remains. Two untimed forms are preserved:80a184c grows caller frame8 to56; bf2c371 restores frames but recovers304-byte memcpy. Final6760b72 passes active bytes separately. Static lowering is not a whole-App gain by itself.</p><h2>Selected reclaim frames</h2>')
p.write_text(s,encoding='utf-8');subprocess.run([sys.executable,'-B',str(p)],check=True)

with (out/'README.md').open('a',encoding='utf-8') as f:
 f.write("\nMeasured binaries are exactly6760b72. Focused checks run formatted0c30dad, whose only change is the exact rustfmt output for the short writer; format-only.patch and format-equivalence.json preserve this distinction. Initial formatting failure was fixed before timing.\n")

p=out/'README.md';s=p.read_text(encoding='utf-8').replace('General static review of32c32d1 to6760b72','General static review of pinned baselinebd63199 to6760b72');p.write_text(s,encoding='utf-8')

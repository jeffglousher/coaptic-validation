
D:\CoapticCurrent\short-inline-replay-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009f120:     	pushq	%rbp
14009f121:     	pushq	%r15
14009f123:     	pushq	%r14
14009f125:     	pushq	%r13
14009f127:     	pushq	%r12
14009f129:     	pushq	%rsi
14009f12a:     	pushq	%rdi
14009f12b:     	pushq	%rbx
14009f12c:     	subq	$0x218, %rsp            # imm = 0x218
14009f133:     	leaq	0x80(%rsp), %rbp
14009f13b:     	movaps	%xmm6, 0x180(%rbp)
14009f142:     	leaq	0x3580(%rcx), %r8
14009f149:     	leaq	0x3f10(%rcx), %rsi
14009f150:     	xorl	%eax, %eax
14009f152:     	movl	$0x1, %r10d
14009f158:     	xorl	%r9d, %r9d
14009f15b:     	imulq	$0x130, %rax, %r11      # imm = 0x130
14009f162:     	addq	%rsi, %r11
14009f165:     	jmp	0x14009f180 <.text+0x9e180>
14009f167:     	nopw	(%rax,%rax)
14009f170:     	incq	%rax
14009f173:     	addq	$0x130, %r11            # imm = 0x130
14009f17a:     	cmpq	$0x4, %rax
14009f17e:     	je	0x14009f1ce <.text+0x9e1ce>
14009f180:     	cmpl	$0x0, 0x4c0(%rsi,%rax,4)
14009f188:     	je	0x14009f170 <.text+0x9e170>
14009f18a:     	cmpb	$0x2, 0x12a(%r11)
14009f192:     	je	0x14009f170 <.text+0x9e170>
14009f194:     	cmpb	$0x3, 0x8(%r11)
14009f199:     	movq	(%r11), %r11
14009f19c:     	setne	%bl
14009f19f:     	testq	%r11, %r11
14009f1a2:     	sete	%dil
14009f1a6:     	orb	%bl, %dil
14009f1a9:     	cmpq	%r14, %r11
14009f1ac:     	setae	%bl
14009f1af:     	andb	%r9b, %bl
14009f1b2:     	testb	%dil, %dil
14009f1b5:     	cmoveq	%r10, %r9
14009f1b9:     	orb	%dil, %bl
14009f1bc:     	cmoveq	%rax, %rdx
14009f1c0:     	cmoveq	%r11, %r14
14009f1c4:     	cmpq	$0x3, %rax
14009f1c8:     	leaq	0x1(%rax), %rax
14009f1cc:     	jb	0x14009f15b <.text+0x9e15b>
14009f1ce:     	xorl	%eax, %eax
14009f1d0:     	cmpq	$0x1, %r9
14009f1d4:     	jne	0x14009f2fd <.text+0x9e2fd>
14009f1da:     	cmpq	$0x4, %rdx
14009f1de:     	jae	0x14009f2fd <.text+0x9e2fd>
14009f1e4:     	cmpl	$0x0, 0x43d0(%rcx,%rdx,4)
14009f1ec:     	je	0x14009f2fb <.text+0x9e2fb>
14009f1f2:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009f1f9:     	movzbl	0x12a(%rsi,%rax), %r15d
14009f202:     	cmpb	$0x2, %r15b
14009f206:     	je	0x14009f2fb <.text+0x9e2fb>
14009f20c:     	addq	%rsi, %rax
14009f20f:     	cmpb	$0x3, 0x8(%rax)
14009f213:     	jne	0x14009f2fb <.text+0x9e2fb>
14009f219:     	movq	0x10(%rax), %r9
14009f21d:     	movq	0x110(%rax), %r12
14009f224:     	movq	0x118(%rax), %rdx
14009f22b:     	movq	%rdx, 0x170(%rbp)
14009f232:     	movl	0x120(%rax), %r13d
14009f239:     	movl	0x124(%rax), %edi
14009f23f:     	movzwl	0x128(%rax), %edx
14009f246:     	movw	%dx, 0x17e(%rbp)
14009f24d:     	movzbl	0x12b(%rax), %edx
14009f254:     	movb	%dl, 0x17d(%rbp)
14009f25a:     	movss	0x12c(%rax), %xmm6
14009f262:     	movzwl	0x12c(%rax), %eax
14009f269:     	movzwl	%ax, %edx
14009f26c:     	cmpq	$0x1, %r9
14009f270:     	ja	0x14009f2c5 <.text+0x9e2c5>
14009f272:     	cmpb	$0x1, 0x3f08(%rcx,%r9)
14009f27b:     	jne	0x14009f2c5 <.text+0x9e2c5>
14009f27d:     	cmpb	$0x0, 0x3f0a(%rcx,%r9)
14009f286:     	jne	0x14009f2c5 <.text+0x9e2c5>
14009f288:     	movb	$0x0, 0x3f08(%rcx,%r9)
14009f291:     	decq	0x3f00(%rcx)
14009f298:     	movq	$0x0, 0x3e80(%rcx,%r9,8)
14009f2a4:     	leaq	(%r9,%r9,8), %r10
14009f2a8:     	leaq	(%r10,%r10,2), %r10
14009f2ac:     	addq	%r9, %r10
14009f2af:     	movb	$0x2, 0x95a(%r8,%r10)
14009f2b8:     	leaq	(%r9,%r9,2), %r9
14009f2bc:     	movb	$0x2, 0x91d(%r8,%r9,8)
14009f2c5:     	addl	$0x2, %edx
14009f2c8:     	movb	$0x1, %r9b
14009f2cb:     	cmpl	%edx, 0x43d0(%rcx)
14009f2d1:     	jne	0x14009f2e1 <.text+0x9e2e1>
14009f2d3:     	movzbl	0x403a(%rcx), %r8d
14009f2db:     	cmpb	$0x2, %r8b
14009f2df:     	jne	0x14009f318 <.text+0x9e318>
14009f2e1:     	xorl	%r8d, %r8d
14009f2e4:     	cmpl	%edx, 0x43d4(%rcx)
14009f2ea:     	movl	%edi, 0x178(%rbp)
14009f2f0:     	jne	0x14009f3ac <.text+0x9e3ac>
14009f2f6:     	jmp	0x14009f39a <.text+0x9e39a>
14009f2fb:     	xorl	%eax, %eax
14009f2fd:     	movaps	0x180(%rbp), %xmm6
14009f304:     	addq	$0x218, %rsp            # imm = 0x218
14009f30b:     	popq	%rbx
14009f30c:     	popq	%rdi
14009f30d:     	popq	%rsi
14009f30e:     	popq	%r12
14009f310:     	popq	%r13
14009f312:     	popq	%r14
14009f314:     	popq	%r15
14009f316:     	popq	%rbp
14009f317:     	retq
14009f318:     	cmpw	%ax, 0x403c(%rcx)
14009f31f:     	sete	%r9b
14009f323:     	cmpl	%r13d, 0x4030(%rcx)
14009f32a:     	sete	%r10b
14009f32e:     	andb	%r9b, %r10b
14009f331:     	cmpl	%edi, 0x4034(%rcx)
14009f337:     	sete	%r9b
14009f33b:     	movzwl	0x17e(%rbp), %r11d
14009f343:     	cmpw	%r11w, 0x4038(%rcx)
14009f34b:     	sete	%r11b
14009f34f:     	andb	%r9b, %r11b
14009f352:     	andb	%r10b, %r11b
14009f355:     	cmpb	%r15b, %r8b
14009f358:     	sete	%r8b
14009f35c:     	movq	0x4028(%rcx), %r9
14009f363:     	xorq	0x170(%rbp), %r9
14009f36a:     	movq	0x4020(%rcx), %r10
14009f371:     	xorq	%r12, %r10
14009f374:     	orq	%r9, %r10
14009f377:     	sete	%r9b
14009f37b:     	andb	%r8b, %r9b
14009f37e:     	andb	%r11b, %r9b
14009f381:     	movzbl	%r9b, %r8d
14009f385:     	movl	%r8d, %r9d
14009f388:     	xorb	$0x1, %r9b
14009f38c:     	cmpl	%edx, 0x43d4(%rcx)
14009f392:     	movl	%edi, 0x178(%rbp)
14009f398:     	jne	0x14009f3ac <.text+0x9e3ac>
14009f39a:     	movzbl	0x416a(%rcx), %r10d
14009f3a2:     	cmpb	$0x2, %r10b
14009f3a6:     	jne	0x14009f456 <.text+0x9e456>
14009f3ac:     	xorl	%r9d, %r9d
14009f3af:     	cmpl	%edx, 0x43d8(%rcx)
14009f3b5:     	jne	0x14009f4f3 <.text+0x9e4f3>
14009f3bb:     	movzbl	0x429a(%rcx), %r10d
14009f3c3:     	cmpb	$0x2, %r10b
14009f3c7:     	je	0x14009f4f3 <.text+0x9e4f3>
14009f3cd:     	cmpb	%r15b, %r10b
14009f3d0:     	jne	0x14009f4f3 <.text+0x9e4f3>
14009f3d6:     	cmpw	%ax, 0x429c(%rcx)
14009f3dd:     	jne	0x14009f4f3 <.text+0x9e4f3>
14009f3e3:     	cmpl	%r13d, 0x4290(%rcx)
14009f3ea:     	jne	0x14009f4f3 <.text+0x9e4f3>
14009f3f0:     	cmpl	%edi, 0x4294(%rcx)
14009f3f6:     	jne	0x14009f4f3 <.text+0x9e4f3>
14009f3fc:     	movzwl	0x17e(%rbp), %r10d
14009f404:     	cmpw	%r10w, 0x4298(%rcx)
14009f40c:     	jne	0x14009f4f3 <.text+0x9e4f3>
14009f412:     	movq	0x4280(%rcx), %r10
14009f419:     	xorq	%r12, %r10
14009f41c:     	movq	0x4288(%rcx), %r11
14009f423:     	xorq	0x170(%rbp), %r11
14009f42a:     	orq	%r10, %r11
14009f42d:     	jne	0x14009f4f3 <.text+0x9e4f3>
14009f433:     	movb	$0x1, %dil
14009f436:     	testq	%r8, %r8
14009f439:     	jne	0x14009f576 <.text+0x9e576>
14009f43f:     	movl	$0x1, %r8d
14009f445:     	movl	$0x2, %r9d
14009f44b:     	movl	0x178(%rbp), %edi
14009f451:     	jmp	0x14009f4f3 <.text+0x9e4f3>
14009f456:     	cmpw	%ax, 0x416c(%rcx)
14009f45d:     	setne	%r11b
14009f461:     	cmpl	%r13d, 0x4160(%rcx)
14009f468:     	setne	%bl
14009f46b:     	orb	%r11b, %bl
14009f46e:     	cmpl	%edi, 0x4164(%rcx)
14009f474:     	setne	%r11b
14009f478:     	movzwl	0x17e(%rbp), %edi
14009f47f:     	cmpw	%di, 0x4168(%rcx)
14009f486:     	setne	%dil
14009f48a:     	orb	%r11b, %dil
14009f48d:     	orb	%bl, %dil
14009f490:     	cmpb	%r15b, %r10b
14009f493:     	setne	%r11b
14009f497:     	movq	0x4158(%rcx), %r10
14009f49e:     	xorq	0x170(%rbp), %r10
14009f4a5:     	movq	0x4150(%rcx), %rbx
14009f4ac:     	xorq	%r12, %rbx
14009f4af:     	orq	%r10, %rbx
14009f4b2:     	setne	%r10b
14009f4b6:     	orb	%r11b, %r10b
14009f4b9:     	orb	%dil, %r10b
14009f4bc:     	orb	%r10b, %r9b
14009f4bf:     	testb	%r10b, %r10b
14009f4c2:     	movl	$0x1, %r11d
14009f4c8:     	cmoveq	%r11, %r8
14009f4cc:     	testb	$0x1, %r9b
14009f4d0:     	je	0x14009f570 <.text+0x9e570>
14009f4d6:     	notb	%r10b
14009f4d9:     	movzbl	%r10b, %r9d
14009f4dd:     	andl	$0x1, %r9d
14009f4e1:     	movl	0x178(%rbp), %edi
14009f4e7:     	cmpl	%edx, 0x43d8(%rcx)
14009f4ed:     	je	0x14009f3bb <.text+0x9e3bb>
14009f4f3:     	cmpl	%edx, 0x43dc(%rcx)
14009f4f9:     	jne	0x14009f507 <.text+0x9e507>
14009f4fb:     	movzbl	0x43ca(%rcx), %edx
14009f502:     	cmpb	$0x2, %dl
14009f505:     	jne	0x14009f513 <.text+0x9e513>
14009f507:     	xorl	%edi, %edi
14009f509:     	testq	%r8, %r8
14009f50c:     	jne	0x14009f576 <.text+0x9e576>
14009f50e:     	jmp	0x14009f5a3 <.text+0x9e5a3>
14009f513:     	cmpb	%r15b, %dl
14009f516:     	jne	0x14009f507 <.text+0x9e507>
14009f518:     	cmpw	%ax, 0x43cc(%rcx)
14009f51f:     	jne	0x14009f507 <.text+0x9e507>
14009f521:     	cmpl	%r13d, 0x43c0(%rcx)
14009f528:     	jne	0x14009f507 <.text+0x9e507>
14009f52a:     	cmpl	%edi, 0x43c4(%rcx)
14009f530:     	jne	0x14009f507 <.text+0x9e507>
14009f532:     	movzwl	0x17e(%rbp), %edx
14009f539:     	cmpw	%dx, 0x43c8(%rcx)
14009f540:     	jne	0x14009f507 <.text+0x9e507>
14009f542:     	movq	0x43b0(%rcx), %rdx
14009f549:     	xorq	%r12, %rdx
14009f54c:     	movq	0x43b8(%rcx), %r10
14009f553:     	xorq	0x170(%rbp), %r10
14009f55a:     	orq	%rdx, %r10
14009f55d:     	jne	0x14009f507 <.text+0x9e507>
14009f55f:     	testq	%r8, %r8
14009f562:     	movl	$0x3, %edx
14009f567:     	cmoveq	%rdx, %r9
14009f56b:     	movl	%r8d, %edi
14009f56e:     	jmp	0x14009f576 <.text+0x9e576>
14009f570:     	movb	$0x1, %dil
14009f573:     	xorl	%r9d, %r9d
14009f576:     	cmpl	$0x0, 0x43d0(%rcx,%r9,4)
14009f57f:     	je	0x14009f5a3 <.text+0x9e5a3>
14009f581:     	movl	$0x0, 0x43d0(%rcx,%r9,4)
14009f58d:     	decq	0x43e8(%rcx)
14009f594:     	imulq	$0x130, %r9, %rdx       # imm = 0x130
14009f59b:     	movb	$0x2, 0x12a(%rsi,%rdx)
14009f5a3:     	movl	%r13d, 0x16c(%rbp)
14009f5aa:     	movq	%r12, %r13
14009f5ad:     	xorps	%xmm0, %xmm0
14009f5b0:     	movaps	%xmm0, 0x150(%rbp)
14009f5b7:     	movb	$0x0, 0x132(%rbp)
14009f5be:     	movw	%ax, 0x130(%rbp)
14009f5c5:     	leaq	0x133(%rbp), %rdx
14009f5cc:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009f5d5:     	movq	$0x0, 0x133(%rbp)
14009f5e0:     	movq	$0x8, 0x110(%rbp)
14009f5eb:     	movq	$0x0, 0x118(%rbp)
14009f5f6:     	movq	$0x1, 0x120(%rbp)
14009f601:     	movq	$0x0, 0x128(%rbp)
14009f60c:     	movq	%rdx, 0x30(%rsp)
14009f611:     	movw	%ax, 0x28(%rsp)
14009f616:     	movq	$0x0, 0x58(%rsp)
14009f61f:     	movq	$0x1, 0x50(%rsp)
14009f628:     	movq	$0x8, 0x48(%rsp)
14009f631:     	movq	$0x8, 0x40(%rsp)
14009f63a:     	movq	$0x0, 0x38(%rsp)
14009f643:     	movb	$0x0, 0x20(%rsp)
14009f648:     	leaq	0x140(%rbp), %rax
14009f64f:     	leaq	0x150(%rbp), %rdx
14009f656:     	movl	$0x10, %r8d
14009f65c:     	movq	%rcx, %r12
14009f65f:     	movq	%rax, %rcx
14009f662:     	movb	$0x2, %r9b
14009f665:     	callq	0x140005590 <.text+0x4590>
14009f66a:     	cmpb	$0x0, 0x140(%rbp)
14009f671:     	jne	0x14009f822 <.text+0x9e822>
14009f677:     	testb	%dil, %dil
14009f67a:     	jne	0x14009f822 <.text+0x9e822>
14009f680:     	movq	0x148(%rbp), %rbx
14009f687:     	cmpq	$0x10, %rbx
14009f68b:     	ja	0x14009f822 <.text+0x9e822>
14009f691:     	movq	%r12, %rax
14009f694:     	cmpq	$0x4, 0x43e8(%r12)
14009f69d:     	je	0x14009f822 <.text+0x9e822>
14009f6a3:     	movq	0x43e0(%rax), %rdi
14009f6aa:     	cmpq	$0x3, %rdi
14009f6ae:     	ja	0x14009f83a <.text+0x9e83a>
14009f6b4:     	cmpl	$0x0, 0x43d0(%rax,%rdi,4)
14009f6bc:     	je	0x14009f736 <.text+0x9e736>
14009f6be:     	leaq	(,%rdi,4), %rdx
14009f6c6:     	xorl	%ecx, %ecx
14009f6c8:     	cmpl	$0x0, 0x43d0(%rax,%rdx)
14009f6d0:     	je	0x14009f729 <.text+0x9e729>
14009f6d2:     	addq	$0x4, %rdx
14009f6d6:     	decq	%rcx
14009f6d9:     	cmpq	$0x10, %rdx
14009f6dd:     	jne	0x14009f6c8 <.text+0x9e6c8>
14009f6df:     	testq	%rdi, %rdi
14009f6e2:     	je	0x14009f822 <.text+0x9e822>
14009f6e8:     	cmpl	$0x0, 0x43d0(%rax)
14009f6ef:     	je	0x14009f829 <.text+0x9e829>
14009f6f5:     	cmpq	$0x1, %rdi
14009f6f9:     	je	0x14009f822 <.text+0x9e822>
14009f6ff:     	cmpl	$0x0, 0x43d4(%rax)
14009f706:     	je	0x14009f830 <.text+0x9e830>
14009f70c:     	cmpq	$0x2, %rdi
14009f710:     	je	0x14009f822 <.text+0x9e822>
14009f716:     	movl	$0x2, %edi
14009f71b:     	cmpl	$0x0, 0x43d8(%rax)
14009f722:     	je	0x14009f72c <.text+0x9e72c>
14009f724:     	jmp	0x14009f822 <.text+0x9e822>
14009f729:     	subq	%rcx, %rdi
14009f72c:     	cmpq	$0x4, %rdi
14009f730:     	jae	0x14009f850 <.text+0x9e850>
14009f736:     	movl	$0x1, 0x43d0(%rax,%rdi,4)
14009f741:     	incq	0x43e8(%rax)
14009f748:     	leaq	0x1(%rdi), %rcx
14009f74c:     	xorl	%edx, %edx
14009f74e:     	cmpq	$0x4, %rcx
14009f752:     	cmovneq	%rcx, %rdx
14009f756:     	movq	%rdx, 0x43e0(%rax)
14009f75d:     	movq	0x170(%rbp), %rcx
14009f764:     	movq	%rcx, 0xf8(%rbp)
14009f76b:     	movq	%r13, 0xf0(%rbp)
14009f772:     	movl	0x16c(%rbp), %ecx
14009f778:     	movl	%ecx, 0x100(%rbp)
14009f77e:     	movl	0x178(%rbp), %ecx
14009f784:     	movl	%ecx, 0x104(%rbp)
14009f78a:     	movzwl	0x17e(%rbp), %ecx
14009f791:     	movw	%cx, 0x108(%rbp)
14009f798:     	movb	%r15b, 0x10a(%rbp)
14009f79f:     	movzbl	0x17d(%rbp), %ecx
14009f7a6:     	movb	%cl, 0x10b(%rbp)
14009f7ac:     	movss	%xmm6, 0x10c(%rbp)
14009f7b4:     	movq	%r14, -0x20(%rbp)
14009f7b8:     	testq	%rbx, %rbx
14009f7bb:     	je	0x14009f7f7 <.text+0x9e7f7>
14009f7bd:     	movb	$0x1, -0x18(%rbp)
14009f7c1:     	movb	%bl, -0x17(%rbp)
14009f7c4:     	leaq	-0x16(%rbp), %r14
14009f7c8:     	movl	$0x80, %r8d
14009f7ce:     	subq	%rbx, %r8
14009f7d1:     	leaq	(%rbx,%rbp), %rcx
14009f7d5:     	addq	$-0x16, %rcx
14009f7d9:     	xorl	%edx, %edx
14009f7db:     	callq	0x140251d02 <.text+0x250d02>
14009f7e0:     	leaq	0x150(%rbp), %rdx
14009f7e7:     	movq	%r14, %rcx
14009f7ea:     	movq	%rbx, %r8
14009f7ed:     	callq	0x140251cf0 <.text+0x250cf0>
14009f7f2:     	movq	%r12, %rax
14009f7f5:     	jmp	0x14009f7fb <.text+0x9e7fb>
14009f7f7:     	movb	$0x0, -0x18(%rbp)
14009f7fb:     	movzwl	0x10c(%rbp), %ecx
14009f802:     	addl	$0x2, %ecx
14009f805:     	movl	%ecx, 0x43d0(%rax,%rdi,4)
14009f80c:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009f813:     	addq	%rax, %rsi
14009f816:     	leaq	-0x20(%rbp), %rcx
14009f81a:     	movq	%rsi, %rdx
14009f81d:     	callq	0x14000b1c0 <.text+0xa1c0>
14009f822:     	movb	$0x1, %al
14009f824:     	jmp	0x14009f2fd <.text+0x9e2fd>
14009f829:     	xorl	%edi, %edi
14009f82b:     	jmp	0x14009f72c <.text+0x9e72c>
14009f830:     	movl	$0x1, %edi
14009f835:     	jmp	0x14009f72c <.text+0x9e72c>
14009f83a:     	leaq	0x1cd56f(%rip), %r8     # 0x14026cdb0
14009f841:     	movl	$0x4, %edx
14009f846:     	movq	%rdi, %rcx
14009f849:     	callq	0x140252573 <.text+0x251573>
14009f84e:     	ud2
14009f850:     	leaq	0x1cd571(%rip), %r8     # 0x14026cdc8
14009f857:     	movl	$0x4, %edx
14009f85c:     	movq	%rdi, %rcx
14009f85f:     	callq	0x140252573 <.text+0x251573>
14009f864:     	ud2


D:\CoapticCurrent\short-inline-replay-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14000b270:     	pushq	%rbp
14000b271:     	movq	%rsp, %rbp
14000b274:     	movzbl	0x30(%rbp), %eax
14000b278:     	movq	%r8, (%rcx)
14000b27b:     	movb	$0x1, 0x8(%rcx)
14000b27f:     	movb	%al, 0x9(%rcx)
14000b282:     	movups	(%r9), %xmm0
14000b286:     	movups	0x10(%r9), %xmm1
14000b28b:     	movups	0x20(%r9), %xmm2
14000b290:     	movups	0x30(%r9), %xmm3
14000b295:     	movups	%xmm0, 0xa(%rcx)
14000b299:     	movups	%xmm1, 0x1a(%rcx)
14000b29d:     	movups	%xmm2, 0x2a(%rcx)
14000b2a1:     	movups	%xmm3, 0x3a(%rcx)
14000b2a5:     	movups	0x40(%r9), %xmm0
14000b2aa:     	movups	%xmm0, 0x4a(%rcx)
14000b2ae:     	movups	0x50(%r9), %xmm0
14000b2b3:     	movups	%xmm0, 0x5a(%rcx)
14000b2b7:     	movups	0x60(%r9), %xmm0
14000b2bc:     	movups	%xmm0, 0x6a(%rcx)
14000b2c0:     	movups	0x70(%r9), %xmm0
14000b2c5:     	movups	%xmm0, 0x7a(%rcx)
14000b2c9:     	movups	(%rdx), %xmm0
14000b2cc:     	movups	0x10(%rdx), %xmm1
14000b2d0:     	movups	%xmm0, 0x110(%rcx)
14000b2d7:     	movups	%xmm1, 0x120(%rcx)
14000b2de:     	popq	%rbp
14000b2df:     	retq


D:\CoapticCurrent\short-inline-replay-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009f870:     	pushq	%rbp
14009f871:     	pushq	%r15
14009f873:     	pushq	%r14
14009f875:     	pushq	%r13
14009f877:     	pushq	%r12
14009f879:     	pushq	%rsi
14009f87a:     	pushq	%rdi
14009f87b:     	pushq	%rbx
14009f87c:     	subq	$0x218, %rsp            # imm = 0x218
14009f883:     	leaq	0x80(%rsp), %rbp
14009f88b:     	movaps	%xmm6, 0x180(%rbp)
14009f892:     	leaq	0x326f0(%rcx), %rdx
14009f899:     	leaq	0x3f7f0(%rcx), %rsi
14009f8a0:     	leaq	0x443f0(%rcx), %r15
14009f8a7:     	xorl	%eax, %eax
14009f8a9:     	movl	$0x1, %r10d
14009f8af:     	xorl	%r9d, %r9d
14009f8b2:     	imulq	$0x130, %rax, %r11      # imm = 0x130
14009f8b9:     	addq	%rsi, %r11
14009f8bc:     	jmp	0x14009f8d0 <.text+0x9e8d0>
14009f8be:     	nop
14009f8c0:     	incq	%rax
14009f8c3:     	addq	$0x130, %r11            # imm = 0x130
14009f8ca:     	cmpq	$0x40, %rax
14009f8ce:     	je	0x14009f91e <.text+0x9e91e>
14009f8d0:     	cmpl	$0x0, 0x4c00(%rsi,%rax,4)
14009f8d8:     	je	0x14009f8c0 <.text+0x9e8c0>
14009f8da:     	cmpb	$0x2, 0x12a(%r11)
14009f8e2:     	je	0x14009f8c0 <.text+0x9e8c0>
14009f8e4:     	cmpb	$0x3, 0x8(%r11)
14009f8e9:     	movq	(%r11), %r11
14009f8ec:     	setne	%bl
14009f8ef:     	testq	%r11, %r11
14009f8f2:     	sete	%dil
14009f8f6:     	orb	%bl, %dil
14009f8f9:     	cmpq	%r14, %r11
14009f8fc:     	setae	%bl
14009f8ff:     	andb	%r9b, %bl
14009f902:     	testb	%dil, %dil
14009f905:     	cmoveq	%r10, %r9
14009f909:     	orb	%dil, %bl
14009f90c:     	cmoveq	%rax, %r8
14009f910:     	cmoveq	%r11, %r14
14009f914:     	cmpq	$0x3f, %rax
14009f918:     	leaq	0x1(%rax), %rax
14009f91c:     	jb	0x14009f8b2 <.text+0x9e8b2>
14009f91e:     	xorl	%eax, %eax
14009f920:     	cmpq	$0x1, %r9
14009f924:     	jne	0x14009fac0 <.text+0x9eac0>
14009f92a:     	cmpq	$0x40, %r8
14009f92e:     	jae	0x14009fac0 <.text+0x9eac0>
14009f934:     	cmpl	$0x0, (%r15,%r8,4)
14009f939:     	je	0x14009fabe <.text+0x9eabe>
14009f93f:     	imulq	$0x130, %r8, %rax       # imm = 0x130
14009f946:     	movzbl	0x12a(%rsi,%rax), %r12d
14009f94f:     	cmpb	$0x2, %r12b
14009f953:     	je	0x14009fabe <.text+0x9eabe>
14009f959:     	addq	%rsi, %rax
14009f95c:     	cmpb	$0x3, 0x8(%rax)
14009f960:     	jne	0x14009fabe <.text+0x9eabe>
14009f966:     	movq	0x10(%rax), %r9
14009f96a:     	movq	0x110(%rax), %r8
14009f971:     	movq	%r8, 0x168(%rbp)
14009f978:     	movq	0x118(%rax), %r8
14009f97f:     	movq	%r8, 0x170(%rbp)
14009f986:     	movl	0x120(%rax), %edi
14009f98c:     	movl	0x124(%rax), %r8d
14009f993:     	movl	%r8d, 0x178(%rbp)
14009f99a:     	movzwl	0x128(%rax), %r8d
14009f9a2:     	movw	%r8w, 0x17c(%rbp)
14009f9aa:     	movzbl	0x12b(%rax), %r8d
14009f9b2:     	movb	%r8b, 0x17f(%rbp)
14009f9b9:     	movss	0x12c(%rax), %xmm6
14009f9c1:     	movzwl	0x12c(%rax), %eax
14009f9c8:     	movzwl	%ax, %r8d
14009f9cc:     	cmpq	$0x1f, %r9
14009f9d0:     	ja	0x14009fa1e <.text+0x9ea1e>
14009f9d2:     	cmpb	$0x1, (%rdx,%r9)
14009f9d7:     	jne	0x14009fa1e <.text+0x9ea1e>
14009f9d9:     	cmpb	$0x0, 0x32710(%rcx,%r9)
14009f9e2:     	jne	0x14009fa1e <.text+0x9ea1e>
14009f9e4:     	movb	$0x0, 0x326f0(%rcx,%r9)
14009f9ed:     	decq	0x32738(%rcx)
14009f9f4:     	movq	$0x0, 0x3e5c0(%rcx,%r9,8)
14009fa00:     	leaq	(%r9,%r9,8), %r10
14009fa04:     	leaq	(%r10,%r10,2), %r10
14009fa08:     	addq	%r9, %r10
14009fa0b:     	movb	$0x2, 0x36a(%rdx,%r10)
14009fa14:     	leaq	(%r9,%r9,2), %r9
14009fa18:     	movb	$0x2, 0x5d(%rdx,%r9,8)
14009fa1e:     	addl	$0x2, %r8d
14009fa22:     	leaq	0x3f91c(%rcx), %r9
14009fa29:     	xorl	%r10d, %r10d
14009fa2c:     	xorl	%edx, %edx
14009fa2e:     	jmp	0x14009fa47 <.text+0x9ea47>
14009fa30:     	movq	%r13, %r11
14009fa33:     	incq	%r10
14009fa36:     	addq	$0x130, %r9             # imm = 0x130
14009fa3d:     	cmpq	$0x40, %r10
14009fa41:     	je	0x14009fadb <.text+0x9eadb>
14009fa47:     	movq	%r11, %r13
14009fa4a:     	cmpl	%r8d, (%r15,%r10,4)
14009fa4e:     	jne	0x14009fa30 <.text+0x9ea30>
14009fa50:     	movzbl	-0x2(%r9), %r11d
14009fa55:     	cmpb	$0x2, %r11b
14009fa59:     	je	0x14009fa30 <.text+0x9ea30>
14009fa5b:     	cmpb	%r12b, %r11b
14009fa5e:     	jne	0x14009fa30 <.text+0x9ea30>
14009fa60:     	cmpw	%ax, (%r9)
14009fa64:     	jne	0x14009fa30 <.text+0x9ea30>
14009fa66:     	cmpl	%edi, -0xc(%r9)
14009fa6a:     	jne	0x14009fa30 <.text+0x9ea30>
14009fa6c:     	movl	0x178(%rbp), %r11d
14009fa73:     	cmpl	%r11d, -0x8(%r9)
14009fa77:     	jne	0x14009fa30 <.text+0x9ea30>
14009fa79:     	movzwl	0x17c(%rbp), %r11d
14009fa81:     	cmpw	%r11w, -0x4(%r9)
14009fa86:     	jne	0x14009fa30 <.text+0x9ea30>
14009fa88:     	movq	-0x1c(%r9), %r11
14009fa8c:     	xorq	0x168(%rbp), %r11
14009fa93:     	movq	-0x14(%r9), %rbx
14009fa97:     	xorq	0x170(%rbp), %rbx
14009fa9e:     	orq	%r11, %rbx
14009faa1:     	jne	0x14009fa30 <.text+0x9ea30>
14009faa3:     	movq	%r10, %r11
14009faa6:     	cmpq	$0x1, %rdx
14009faaa:     	movl	$0x1, %edx
14009faaf:     	jne	0x14009fa33 <.text+0x9ea33>
14009fab1:     	movb	$0x1, %bl
14009fab3:     	movq	%r13, %r11
14009fab6:     	cmpq	$0x3f, %r13
14009faba:     	jbe	0x14009faea <.text+0x9eaea>
14009fabc:     	jmp	0x14009fb13 <.text+0x9eb13>
14009fabe:     	xorl	%eax, %eax
14009fac0:     	movaps	0x180(%rbp), %xmm6
14009fac7:     	addq	$0x218, %rsp            # imm = 0x218
14009face:     	popq	%rbx
14009facf:     	popq	%rdi
14009fad0:     	popq	%rsi
14009fad1:     	popq	%r12
14009fad3:     	popq	%r13
14009fad5:     	popq	%r14
14009fad7:     	popq	%r15
14009fad9:     	popq	%rbp
14009fada:     	retq
14009fadb:     	cmpq	$0x40, %r11
14009fadf:     	setb	%r8b
14009fae3:     	xorl	%ebx, %ebx
14009fae5:     	testb	%r8b, %dl
14009fae8:     	je	0x14009fb13 <.text+0x9eb13>
14009faea:     	cmpl	$0x0, (%r15,%r11,4)
14009faef:     	je	0x14009fb13 <.text+0x9eb13>
14009faf1:     	movl	$0x0, 0x443f0(%rcx,%r11,4)
14009fafd:     	decq	0x444f8(%rcx)
14009fb04:     	imulq	$0x130, %r11, %rdx      # imm = 0x130
14009fb0b:     	movb	$0x2, 0x12a(%rsi,%rdx)
14009fb13:     	pxor	%xmm0, %xmm0
14009fb17:     	movdqa	%xmm0, 0x150(%rbp)
14009fb1f:     	movb	$0x0, 0x132(%rbp)
14009fb26:     	movw	%ax, 0x130(%rbp)
14009fb2d:     	leaq	0x133(%rbp), %rdx
14009fb34:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009fb3d:     	movq	$0x0, 0x133(%rbp)
14009fb48:     	movq	$0x8, 0x110(%rbp)
14009fb53:     	movq	$0x0, 0x118(%rbp)
14009fb5e:     	movq	$0x1, 0x120(%rbp)
14009fb69:     	movq	$0x0, 0x128(%rbp)
14009fb74:     	movq	%rdx, 0x30(%rsp)
14009fb79:     	movw	%ax, 0x28(%rsp)
14009fb7e:     	movq	$0x0, 0x58(%rsp)
14009fb87:     	movq	$0x1, 0x50(%rsp)
14009fb90:     	movq	$0x8, 0x48(%rsp)
14009fb99:     	movq	$0x8, 0x40(%rsp)
14009fba2:     	movq	$0x0, 0x38(%rsp)
14009fbab:     	movb	$0x0, 0x20(%rsp)
14009fbb0:     	leaq	0x140(%rbp), %rax
14009fbb7:     	leaq	0x150(%rbp), %rdx
14009fbbe:     	movl	$0x10, %r8d
14009fbc4:     	movq	%rcx, %r13
14009fbc7:     	movq	%rax, %rcx
14009fbca:     	movb	$0x2, %r9b
14009fbcd:     	callq	0x140005590 <.text+0x4590>
14009fbd2:     	movq	%r13, %rax
14009fbd5:     	movq	0x148(%rbp), %r13
14009fbdc:     	cmpq	$0x11, %r13
14009fbe0:     	setae	%cl
14009fbe3:     	orb	%bl, %cl
14009fbe5:     	orb	0x140(%rbp), %cl
14009fbeb:     	testb	$0x1, %cl
14009fbee:     	jne	0x14009fd6e <.text+0x9ed6e>
14009fbf4:     	cmpq	$0x40, 0x444f8(%rax)
14009fbfc:     	je	0x14009fd6e <.text+0x9ed6e>
14009fc02:     	movq	0x444f0(%rax), %rbx
14009fc09:     	cmpq	$0x3f, %rbx
14009fc0d:     	ja	0x14009fe2e <.text+0x9ee2e>
14009fc13:     	cmpl	$0x0, (%r15,%rbx,4)
14009fc18:     	je	0x14009fc83 <.text+0x9ec83>
14009fc1a:     	leaq	(,%rbx,4), %rdx
14009fc22:     	leaq	(%r15,%rbx,4), %rcx
14009fc26:     	xorl	%r8d, %r8d
14009fc29:     	movq	%rdx, %r9
14009fc2c:     	cmpl	$0x0, (%r15,%r9)
14009fc31:     	je	0x14009fc76 <.text+0x9ec76>
14009fc33:     	addq	$0x4, %r9
14009fc37:     	decq	%r8
14009fc3a:     	cmpq	$0x100, %r9             # imm = 0x100
14009fc41:     	jne	0x14009fc2c <.text+0x9ec2c>
14009fc43:     	testq	%rbx, %rbx
14009fc46:     	je	0x14009fd6e <.text+0x9ed6e>
14009fc4c:     	addq	$-0x4, %rdx
14009fc50:     	cmpq	$0xc, %rdx
14009fc54:     	jae	0x14009fd75 <.text+0x9ed75>
14009fc5a:     	xorl	%ebx, %ebx
14009fc5c:     	movq	%r15, %r9
14009fc5f:     	cmpl	$0x0, (%r9)
14009fc63:     	je	0x14009fc79 <.text+0x9ec79>
14009fc65:     	addq	$0x4, %r9
14009fc69:     	incq	%rbx
14009fc6c:     	cmpq	%rcx, %r9
14009fc6f:     	jne	0x14009fc5f <.text+0x9ec5f>
14009fc71:     	jmp	0x14009fd6e <.text+0x9ed6e>
14009fc76:     	subq	%r8, %rbx
14009fc79:     	cmpq	$0x40, %rbx
14009fc7d:     	jae	0x14009fe18 <.text+0x9ee18>
14009fc83:     	movl	$0x1, 0x443f0(%rax,%rbx,4)
14009fc8e:     	incq	0x444f8(%rax)
14009fc95:     	leaq	0x1(%rbx), %rcx
14009fc99:     	xorl	%edx, %edx
14009fc9b:     	cmpq	$0x40, %rcx
14009fc9f:     	cmovneq	%rcx, %rdx
14009fca3:     	movq	%rdx, 0x444f0(%rax)
14009fcaa:     	movq	0x170(%rbp), %rax
14009fcb1:     	movq	%rax, 0xf8(%rbp)
14009fcb8:     	movq	0x168(%rbp), %rax
14009fcbf:     	movq	%rax, 0xf0(%rbp)
14009fcc6:     	movl	%edi, 0x100(%rbp)
14009fccc:     	movl	0x178(%rbp), %eax
14009fcd2:     	movl	%eax, 0x104(%rbp)
14009fcd8:     	movzwl	0x17c(%rbp), %eax
14009fcdf:     	movw	%ax, 0x108(%rbp)
14009fce6:     	movb	%r12b, 0x10a(%rbp)
14009fced:     	movzbl	0x17f(%rbp), %eax
14009fcf4:     	movb	%al, 0x10b(%rbp)
14009fcfa:     	movss	%xmm6, 0x10c(%rbp)
14009fd02:     	movq	%r14, -0x20(%rbp)
14009fd06:     	testq	%r13, %r13
14009fd09:     	je	0x14009fd46 <.text+0x9ed46>
14009fd0b:     	movb	$0x1, -0x18(%rbp)
14009fd0f:     	movb	%r13b, -0x17(%rbp)
14009fd13:     	leaq	-0x16(%rbp), %r14
14009fd17:     	movl	$0x80, %r8d
14009fd1d:     	subq	%r13, %r8
14009fd20:     	leaq	-0x16(,%r13), %rcx
14009fd28:     	addq	%rbp, %rcx
14009fd2b:     	xorl	%edx, %edx
14009fd2d:     	callq	0x140251d02 <.text+0x250d02>
14009fd32:     	leaq	0x150(%rbp), %rdx
14009fd39:     	movq	%r14, %rcx
14009fd3c:     	movq	%r13, %r8
14009fd3f:     	callq	0x140251cf0 <.text+0x250cf0>
14009fd44:     	jmp	0x14009fd4a <.text+0x9ed4a>
14009fd46:     	movb	$0x0, -0x18(%rbp)
14009fd4a:     	movzwl	0x10c(%rbp), %eax
14009fd51:     	addl	$0x2, %eax
14009fd54:     	movl	%eax, (%r15,%rbx,4)
14009fd58:     	imulq	$0x130, %rbx, %rax      # imm = 0x130
14009fd5f:     	addq	%rax, %rsi
14009fd62:     	leaq	-0x20(%rbp), %rcx
14009fd66:     	movq	%rsi, %rdx
14009fd69:     	callq	0x14000b1c0 <.text+0xa1c0>
14009fd6e:     	movb	$0x1, %al
14009fd70:     	jmp	0x14009fac0 <.text+0x9eac0>
14009fd75:     	shrq	$0x2, %rdx
14009fd79:     	incq	%rdx
14009fd7c:     	movq	%rdx, %rbx
14009fd7f:     	andq	$-0x4, %rbx
14009fd83:     	leaq	(%r15,%rbx,4), %r9
14009fd87:     	xorl	%r8d, %r8d
14009fd8a:     	pxor	%xmm1, %xmm1
14009fd8e:     	movdqu	(%r15,%r8,4), %xmm0
14009fd94:     	movdqa	%xmm0, %xmm2
14009fd98:     	pcmpeqd	%xmm1, %xmm2
14009fd9c:     	movmskps	%xmm2, %r10d
14009fda0:     	testl	%r10d, %r10d
14009fda3:     	jne	0x14009fdb9 <.text+0x9edb9>
14009fda5:     	addq	$0x4, %r8
14009fda9:     	cmpq	%r8, %rbx
14009fdac:     	jne	0x14009fd8e <.text+0x9ed8e>
14009fdae:     	cmpq	%rbx, %rdx
14009fdb1:     	jne	0x14009fc5f <.text+0x9ec5f>
14009fdb7:     	jmp	0x14009fd6e <.text+0x9ed6e>
14009fdb9:     	pxor	%xmm1, %xmm1
14009fdbd:     	pcmpeqd	%xmm1, %xmm0
14009fdc1:     	pand	0x1c3fd7(%rip), %xmm0   # 0x140263da0
14009fdc9:     	movdqa	0x1c1ecf(%rip), %xmm1   # 0x140261ca0
14009fdd1:     	movdqa	%xmm0, %xmm2
14009fdd5:     	por	%xmm1, %xmm2
14009fdd9:     	pshufd	$0xee, %xmm0, %xmm3     # xmm3 = xmm0[2,3,2,3]
14009fdde:     	por	%xmm3, %xmm1
14009fde2:     	pcmpgtd	%xmm1, %xmm2
14009fde6:     	pand	%xmm2, %xmm0
14009fdea:     	pandn	%xmm3, %xmm2
14009fdee:     	por	%xmm0, %xmm2
14009fdf2:     	movd	%xmm2, %ecx
14009fdf6:     	pshufd	$0x55, %xmm2, %xmm0     # xmm0 = xmm2[1,1,1,1]
14009fdfb:     	movd	%xmm0, %edx
14009fdff:     	cmpl	%edx, %ecx
14009fe01:     	cmoval	%ecx, %edx
14009fe04:     	movl	$0x4, %ebx
14009fe09:     	subl	%edx, %ebx
14009fe0b:     	addq	%r8, %rbx
14009fe0e:     	cmpq	$0x40, %rbx
14009fe12:     	jb	0x14009fc83 <.text+0x9ec83>
14009fe18:     	leaq	0x1ccfa9(%rip), %r8     # 0x14026cdc8
14009fe1f:     	movl	$0x40, %edx
14009fe24:     	movq	%rbx, %rcx
14009fe27:     	callq	0x140252573 <.text+0x251573>
14009fe2c:     	ud2
14009fe2e:     	leaq	0x1ccf7b(%rip), %r8     # 0x14026cdb0
14009fe35:     	movl	$0x40, %edx
14009fe3a:     	movq	%rbx, %rcx
14009fe3d:     	callq	0x140252573 <.text+0x251573>
14009fe42:     	ud2

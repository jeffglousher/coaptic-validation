
D:\CoapticCurrent\short-inline-replay-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009fe50:     	pushq	%rbp
14009fe51:     	pushq	%r15
14009fe53:     	pushq	%r14
14009fe55:     	pushq	%r13
14009fe57:     	pushq	%r12
14009fe59:     	pushq	%rsi
14009fe5a:     	pushq	%rdi
14009fe5b:     	pushq	%rbx
14009fe5c:     	subq	$0x218, %rsp            # imm = 0x218
14009fe63:     	leaq	0x80(%rsp), %rbp
14009fe6b:     	movaps	%xmm6, 0x180(%rbp)
14009fe72:     	movq	0xe8(%rcx), %rax
14009fe79:     	testq	%rax, %rax
14009fe7c:     	je	0x1400a01b1 <.text+0x9f1b1>
14009fe82:     	leaq	0xc0(%rcx), %rsi
14009fe89:     	movq	0xe0(%rcx), %r9
14009fe90:     	movq	0xc8(%rcx), %r10
14009fe97:     	movq	0xd0(%rcx), %r11
14009fe9e:     	xorl	%r8d, %r8d
14009fea1:     	movl	$0x1, %edi
14009fea6:     	movq	%rax, %r15
14009fea9:     	xorl	%r14d, %r14d
14009feac:     	imulq	$0x130, %r14, %r12      # imm = 0x130
14009feb3:     	addq	%r10, %r12
14009feb6:     	jmp	0x14009fecf <.text+0x9eecf>
14009feb8:     	nopl	(%rax,%rax)
14009fec0:     	incq	%r14
14009fec3:     	addq	$0x130, %r12            # imm = 0x130
14009feca:     	cmpq	%r14, %r15
14009fecd:     	je	0x14009ff32 <.text+0x9ef32>
14009fecf:     	cmpq	%rax, %r14
14009fed2:     	jae	0x14009fec0 <.text+0x9eec0>
14009fed4:     	cmpl	$0x0, (%r9,%r14,4)
14009fed9:     	je	0x14009fec0 <.text+0x9eec0>
14009fedb:     	cmpq	%r11, %r14
14009fede:     	jae	0x14009fec0 <.text+0x9eec0>
14009fee0:     	cmpb	$0x2, 0x12a(%r12)
14009fee9:     	je	0x14009fec0 <.text+0x9eec0>
14009feeb:     	movq	(%r12), %r15
14009feef:     	cmpb	$0x3, 0x8(%r12)
14009fef5:     	setne	%r12b
14009fef9:     	testq	%r15, %r15
14009fefc:     	sete	%r13b
14009ff00:     	orb	%r12b, %r13b
14009ff03:     	cmpq	%rbx, %r15
14009ff06:     	setae	%r12b
14009ff0a:     	andb	%r8b, %r12b
14009ff0d:     	testb	%r13b, %r13b
14009ff10:     	cmoveq	%rdi, %r8
14009ff14:     	orb	%r13b, %r12b
14009ff17:     	cmoveq	%r14, %rdx
14009ff1b:     	cmoveq	%r15, %rbx
14009ff1f:     	incq	%r14
14009ff22:     	cmpq	%rax, %r14
14009ff25:     	movq	%rax, %r15
14009ff28:     	cmovaq	%r14, %r15
14009ff2c:     	jb	0x14009feac <.text+0x9eeac>
14009ff32:     	testb	$0x1, %r8b
14009ff36:     	je	0x1400a01b1 <.text+0x9f1b1>
14009ff3c:     	cmpq	%rax, %rdx
14009ff3f:     	jae	0x1400a01b1 <.text+0x9f1b1>
14009ff45:     	movq	0xe0(%rcx), %r8
14009ff4c:     	xorl	%eax, %eax
14009ff4e:     	cmpl	$0x0, (%r8,%rdx,4)
14009ff53:     	je	0x1400a01b3 <.text+0x9f1b3>
14009ff59:     	cmpq	0xd0(%rcx), %rdx
14009ff60:     	jae	0x1400a01b3 <.text+0x9f1b3>
14009ff66:     	movq	0xc8(%rcx), %r9
14009ff6d:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009ff74:     	movzbl	0x12a(%r9,%rax), %r14d
14009ff7d:     	cmpb	$0x2, %r14b
14009ff81:     	je	0x1400a01b1 <.text+0x9f1b1>
14009ff87:     	addq	%rax, %r9
14009ff8a:     	cmpb	$0x3, 0x8(%r9)
14009ff8f:     	jne	0x1400a01b1 <.text+0x9f1b1>
14009ff95:     	movzbl	0x12b(%r9), %r15d
14009ff9d:     	movss	0x12c(%r9), %xmm6
14009ffa6:     	movzwl	0x12c(%r9), %eax
14009ffae:     	movq	0x10(%r9), %r10
14009ffb2:     	movups	0x110(%r9), %xmm0
14009ffba:     	movups	0x11a(%r9), %xmm1
14009ffc2:     	movups	%xmm1, 0x11a(%rbp)
14009ffc9:     	movaps	%xmm0, 0x110(%rbp)
14009ffd0:     	cmpq	0x88(%rcx), %r10
14009ffd7:     	jae	0x1400a002d <.text+0x9f02d>
14009ffd9:     	movq	0x80(%rcx), %r11
14009ffe0:     	cmpb	$0x1, (%r11,%r10)
14009ffe5:     	jne	0x1400a002d <.text+0x9f02d>
14009ffe7:     	cmpq	0xa0(%rcx), %r10
14009ffee:     	jae	0x14009fffe <.text+0x9effe>
14009fff0:     	movq	0x98(%rcx), %rdi
14009fff7:     	cmpb	$0x0, (%rdi,%r10)
14009fffc:     	jne	0x1400a002d <.text+0x9f02d>
14009fffe:     	movb	$0x0, (%r11,%r10)
1400a0003:     	decq	0xb0(%rcx)
1400a000a:     	cmpq	0x70(%rcx), %r10
1400a000e:     	jae	0x1400a002d <.text+0x9f02d>
1400a0010:     	movq	0x68(%rcx), %r11
1400a0014:     	imulq	$0x58, %r10, %r10
1400a0018:     	movq	$0x0, 0x30(%r11,%r10)
1400a0021:     	movb	$0x2, 0x52(%r11,%r10)
1400a0027:     	movb	$0x2, 0x25(%r11,%r10)
1400a002d:     	cmpl	$0x0, (%r8,%rdx,4)
1400a0032:     	je	0x1400a004b <.text+0x9f04b>
1400a0034:     	movl	$0x0, (%r8,%rdx,4)
1400a003c:     	decq	0xf8(%rcx)
1400a0043:     	movb	$0x2, 0x12a(%r9)
1400a004b:     	movq	%rcx, %r12
1400a004e:     	xorps	%xmm0, %xmm0
1400a0051:     	movaps	%xmm0, 0x170(%rbp)
1400a0058:     	movb	$0x0, 0x152(%rbp)
1400a005f:     	movw	%ax, 0x150(%rbp)
1400a0066:     	leaq	0x153(%rbp), %rcx
1400a006d:     	movw	$0x200, 0x15b(%rbp)     # imm = 0x200
1400a0076:     	movq	$0x0, 0x153(%rbp)
1400a0081:     	movq	$0x8, 0x130(%rbp)
1400a008c:     	movq	$0x0, 0x138(%rbp)
1400a0097:     	movq	$0x1, 0x140(%rbp)
1400a00a2:     	movq	$0x0, 0x148(%rbp)
1400a00ad:     	movq	%rcx, 0x30(%rsp)
1400a00b2:     	movw	%ax, 0x28(%rsp)
1400a00b7:     	movq	$0x0, 0x58(%rsp)
1400a00c0:     	movq	$0x1, 0x50(%rsp)
1400a00c9:     	movq	$0x8, 0x48(%rsp)
1400a00d2:     	movq	$0x8, 0x40(%rsp)
1400a00db:     	movq	$0x0, 0x38(%rsp)
1400a00e4:     	movb	$0x0, 0x20(%rsp)
1400a00e9:     	leaq	0x160(%rbp), %rcx
1400a00f0:     	leaq	0x170(%rbp), %rdx
1400a00f7:     	movl	$0x10, %r8d
1400a00fd:     	movb	$0x2, %r9b
1400a0100:     	callq	0x140005590 <.text+0x4590>
1400a0105:     	movq	0x168(%rbp), %rdi
1400a010c:     	cmpq	$0x11, %rdi
1400a0110:     	setae	%al
1400a0113:     	orb	0x160(%rbp), %al
1400a0119:     	jne	0x1400a01de <.text+0x9f1de>
1400a011f:     	movq	%r12, %rcx
1400a0122:     	addq	$0xd8, %rcx
1400a0129:     	callq	0x140219c90 <.text+0x218c90>
1400a012e:     	cmpq	$0x1, %rax
1400a0132:     	jne	0x1400a01de <.text+0x9f1de>
1400a0138:     	movups	0x11a(%rbp), %xmm0
1400a013f:     	movups	%xmm0, 0xfa(%rbp)
1400a0146:     	movaps	0x110(%rbp), %xmm0
1400a014d:     	movups	%xmm0, 0xf0(%rbp)
1400a0154:     	movb	%r14b, 0x10a(%rbp)
1400a015b:     	movb	%r15b, 0x10b(%rbp)
1400a0162:     	movss	%xmm6, 0x10c(%rbp)
1400a016a:     	movq	%rbx, -0x20(%rbp)
1400a016e:     	testq	%rdi, %rdi
1400a0171:     	je	0x1400a01ce <.text+0x9f1ce>
1400a0173:     	movb	$0x1, -0x18(%rbp)
1400a0177:     	movb	%dil, -0x17(%rbp)
1400a017b:     	leaq	-0x16(%rbp), %rbx
1400a017f:     	movl	$0x80, %r8d
1400a0185:     	subq	%rdi, %r8
1400a0188:     	leaq	(%rdi,%rbp), %rcx
1400a018c:     	addq	$-0x16, %rcx
1400a0190:     	movq	%rdx, %r14
1400a0193:     	xorl	%edx, %edx
1400a0195:     	callq	0x140251d02 <.text+0x250d02>
1400a019a:     	leaq	0x170(%rbp), %rdx
1400a01a1:     	movq	%rbx, %rcx
1400a01a4:     	movq	%rdi, %r8
1400a01a7:     	callq	0x140251cf0 <.text+0x250cf0>
1400a01ac:     	movq	%r14, %rdx
1400a01af:     	jmp	0x1400a01d2 <.text+0x9f1d2>
1400a01b1:     	xorl	%eax, %eax
1400a01b3:     	movaps	0x180(%rbp), %xmm6
1400a01ba:     	addq	$0x218, %rsp            # imm = 0x218
1400a01c1:     	popq	%rbx
1400a01c2:     	popq	%rdi
1400a01c3:     	popq	%rsi
1400a01c4:     	popq	%r12
1400a01c6:     	popq	%r13
1400a01c8:     	popq	%r14
1400a01ca:     	popq	%r15
1400a01cc:     	popq	%rbp
1400a01cd:     	retq
1400a01ce:     	movb	$0x0, -0x18(%rbp)
1400a01d2:     	leaq	-0x20(%rbp), %r8
1400a01d6:     	movq	%rsi, %rcx
1400a01d9:     	callq	0x14000b6d0 <.text+0xa6d0>
1400a01de:     	movb	$0x1, %al
1400a01e0:     	jmp	0x1400a01b3 <.text+0x9f1b3>

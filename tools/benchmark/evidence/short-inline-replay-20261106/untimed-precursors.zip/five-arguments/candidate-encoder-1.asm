
D:\CoapticCurrent\short-inline-replay-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068380:     	pushq	%rbp
140068381:     	pushq	%r15
140068383:     	pushq	%r14
140068385:     	pushq	%r13
140068387:     	pushq	%r12
140068389:     	pushq	%rsi
14006838a:     	pushq	%rdi
14006838b:     	pushq	%rbx
14006838c:     	subq	$0x508, %rsp            # imm = 0x508
140068393:     	leaq	0x80(%rsp), %rbp
14006839b:     	movq	0x500(%rbp), %r12
1400683a2:     	movq	0x8(%r12), %rdi
1400683a7:     	movl	$0x3, %r10d
1400683ad:     	cmpq	$0x3, %rdi
1400683b1:     	ja	0x140068491 <.text+0x67491>
1400683b7:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
1400683bf:     	jne	0x140068491 <.text+0x67491>
1400683c5:     	movq	0x26700(%rdx,%rdi,8), %rax
1400683cd:     	cmpq	$0x4001, %rax           # imm = 0x4001
1400683d3:     	jae	0x14006866e <.text+0x6766e>
1400683d9:     	movq	0x10(%r12), %r11
1400683de:     	movq	0x18(%r12), %r15
1400683e3:     	movq	%r15, %rsi
1400683e6:     	movl	$0xb, %r10d
1400683ec:     	addq	%r11, %rsi
1400683ef:     	jb	0x140068491 <.text+0x67491>
1400683f5:     	cmpq	$0x400, %r15            # imm = 0x400
1400683fc:     	ja	0x140068491 <.text+0x67491>
140068402:     	cmpq	%rax, %rsi
140068405:     	ja	0x140068491 <.text+0x67491>
14006840b:     	movq	%r8, %r13
14006840e:     	movq	%r9, 0x470(%rbp)
140068415:     	movq	%rcx, 0x480(%rbp)
14006841c:     	movzbl	0x508(%rbp), %r14d
140068424:     	movq	%rdi, %rax
140068427:     	shlq	$0xe, %rax
14006842b:     	movq	%rdx, %rsi
14006842e:     	leaq	(%rdx,%rax), %rbx
140068432:     	addq	$0x16700, %rbx          # imm = 0x16700
140068439:     	addq	%r11, %rbx
14006843c:     	movl	$0x400, %r8d            # imm = 0x400
140068442:     	cmpq	$0x400, %r15            # imm = 0x400
140068449:     	je	0x140068458 <.text+0x67458>
14006844b:     	movq	%rbp, %rcx
14006844e:     	xorl	%edx, %edx
140068450:     	callq	0x140251d02 <.text+0x250d02>
140068455:     	movq	%r15, %r8
140068458:     	movq	%rbp, %rcx
14006845b:     	movq	%rbx, %rdx
14006845e:     	callq	0x140251cf0 <.text+0x250cf0>
140068463:     	testb	%r14b, %r14b
140068466:     	je	0x1400684ac <.text+0x674ac>
140068468:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
14006846f:     	movq	%rsi, %rcx
140068472:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
14006847b:     	jne	0x140068623 <.text+0x67623>
140068481:     	xorl	%edi, %edi
140068483:     	callq	0x14009b600 <.text+0x9a600>
140068488:     	testb	$0x1, %al
14006848a:     	jne	0x1400684be <.text+0x674be>
14006848c:     	jmp	0x14006864c <.text+0x6764c>
140068491:     	movb	$0xa, (%rcx)
140068494:     	movq	%r10, 0x8(%rcx)
140068498:     	addq	$0x508, %rsp            # imm = 0x508
14006849f:     	popq	%rbx
1400684a0:     	popq	%rdi
1400684a1:     	popq	%rsi
1400684a2:     	popq	%r12
1400684a4:     	popq	%r13
1400684a6:     	popq	%r14
1400684a8:     	popq	%r15
1400684aa:     	popq	%rbp
1400684ab:     	retq
1400684ac:     	xorl	%edi, %edi
1400684ae:     	movq	%rsi, %rcx
1400684b1:     	callq	0x14009b600 <.text+0x9a600>
1400684b6:     	testb	$0x1, %al
1400684b8:     	je	0x14006864c <.text+0x6764c>
1400684be:     	movq	%rdx, %rbx
1400684c1:     	movq	0x518(%rbp), %rdx
1400684c8:     	movq	0x510(%rbp), %r8
1400684cf:     	movzwl	0x4f8(%rbp), %ecx
1400684d6:     	movzbl	0x4f0(%rbp), %eax
1400684dd:     	movq	(%r12), %r9
1400684e1:     	movq	%rdi, 0x440(%rbp)
1400684e8:     	movq	0x478(%rbp), %r10
1400684ef:     	movq	%r10, 0x448(%rbp)
1400684f6:     	movq	%r9, 0x450(%rbp)
1400684fd:     	movb	%r14b, 0x458(%rbp)
140068504:     	movups	0x60(%r13), %xmm0
140068509:     	movups	0x6c(%r13), %xmm1
14006850e:     	movups	%xmm1, 0x40c(%rbp)
140068515:     	movaps	%xmm0, 0x400(%rbp)
14006851c:     	leaq	0x8e(%r13), %r9
140068523:     	movq	0x7e(%r13), %r10
140068527:     	movq	0x85(%r13), %r11
14006852e:     	movq	%r11, 0x467(%rbp)
140068535:     	movq	%r10, 0x460(%rbp)
14006853c:     	leaq	0x460(%rbp), %r10
140068543:     	movq	%r10, 0x70(%rsp)
140068548:     	movq	%rdx, 0x68(%rsp)
14006854d:     	movq	%r8, 0x60(%rsp)
140068552:     	movq	%r13, 0x58(%rsp)
140068557:     	leaq	0x440(%rbp), %rdx
14006855e:     	movq	%rdx, 0x50(%rsp)
140068563:     	movq	%r15, 0x48(%rsp)
140068568:     	movq	%rbp, %rdx
14006856b:     	movq	%rdx, 0x40(%rsp)
140068570:     	movq	0x470(%rbp), %rdx
140068577:     	movq	%rdx, 0x38(%rsp)
14006857c:     	movq	%r9, 0x30(%rsp)
140068581:     	movw	%cx, 0x28(%rsp)
140068586:     	movb	%al, 0x20(%rsp)
14006858a:     	leaq	0x420(%rbp), %rcx
140068591:     	leaq	0x400(%rbp), %r8
140068598:     	movq	%rsi, %rdx
14006859b:     	movq	%rbx, %r9
14006859e:     	callq	0x140081380 <.text+0x80380>
1400685a3:     	cmpb	$-0x1, 0x420(%rbp)
1400685aa:     	je	0x14006865b <.text+0x6765b>
1400685b0:     	cmpb	$0x1, 0x326f0(%rsi,%rbx)
1400685b8:     	movq	0x480(%rbp), %rax
1400685bf:     	jne	0x140068609 <.text+0x67609>
1400685c1:     	cmpb	$0x0, 0x32710(%rsi,%rbx)
1400685c9:     	jne	0x140068609 <.text+0x67609>
1400685cb:     	movb	$0x0, 0x326f0(%rsi,%rbx)
1400685d3:     	decq	0x32738(%rsi)
1400685da:     	leaq	0x326f0(%rsi), %rcx
1400685e1:     	movq	$0x0, 0x3e5c0(%rsi,%rbx,8)
1400685ed:     	leaq	(%rbx,%rbx,8), %rdx
1400685f1:     	leaq	(%rdx,%rdx,2), %rdx
1400685f5:     	addq	%rbx, %rdx
1400685f8:     	movb	$0x2, 0x36a(%rcx,%rdx)
140068600:     	leaq	(%rbx,%rbx,2), %rdx
140068604:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140068609:     	movups	0x420(%rbp), %xmm0
140068610:     	movups	0x430(%rbp), %xmm1
140068617:     	movups	%xmm1, 0x10(%rax)
14006861b:     	movups	%xmm0, (%rax)
14006861e:     	jmp	0x140068498 <.text+0x67498>
140068623:     	addq	%rcx, %rax
140068626:     	addq	$0x15c28, %rax          # imm = 0x15C28
14006862c:     	movq	0x98(%rax), %rax
140068633:     	movq	%rax, 0x478(%rbp)
14006863a:     	movl	$0x1, %edi
14006863f:     	callq	0x14009b600 <.text+0x9a600>
140068644:     	testb	$0x1, %al
140068646:     	jne	0x1400684be <.text+0x674be>
14006864c:     	movq	0x480(%rbp), %rax
140068653:     	movb	$0x9, (%rax)
140068656:     	jmp	0x140068498 <.text+0x67498>
14006865b:     	movq	0x480(%rbp), %rax
140068662:     	movq	%rbx, 0x8(%rax)
140068666:     	movb	$-0x1, (%rax)
140068669:     	jmp	0x140068498 <.text+0x67498>
14006866e:     	leaq	0x2045eb(%rip), %r9     # 0x14026cc60
140068675:     	movl	$0x4000, %r8d           # imm = 0x4000
14006867b:     	xorl	%ecx, %ecx
14006867d:     	movq	%rax, %rdx
140068680:     	callq	0x140252780 <.text+0x251780>
140068685:     	ud2

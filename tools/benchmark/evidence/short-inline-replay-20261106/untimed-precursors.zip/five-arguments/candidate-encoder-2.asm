
D:\CoapticCurrent\short-inline-replay-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068690:     	pushq	%rbp
140068691:     	pushq	%r15
140068693:     	pushq	%r14
140068695:     	pushq	%r13
140068697:     	pushq	%r12
140068699:     	pushq	%rsi
14006869a:     	pushq	%rdi
14006869b:     	pushq	%rbx
14006869c:     	subq	$0x4f8, %rsp            # imm = 0x4F8
1400686a3:     	leaq	0x80(%rsp), %rbp
1400686ab:     	movq	0x4f0(%rbp), %r12
1400686b2:     	movq	0x8(%r12), %rdi
1400686b7:     	movl	$0x3, %r10d
1400686bd:     	cmpq	$0x3, %rdi
1400686c1:     	ja	0x1400687a3 <.text+0x677a3>
1400686c7:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
1400686cf:     	jne	0x1400687a3 <.text+0x677a3>
1400686d5:     	movq	0x26700(%rdx,%rdi,8), %rax
1400686dd:     	cmpq	$0x4001, %rax           # imm = 0x4001
1400686e3:     	jae	0x140068975 <.text+0x67975>
1400686e9:     	movq	0x10(%r12), %r11
1400686ee:     	movq	0x18(%r12), %r15
1400686f3:     	movq	%r15, %rsi
1400686f6:     	movl	$0xb, %r10d
1400686fc:     	addq	%r11, %rsi
1400686ff:     	jb	0x1400687a3 <.text+0x677a3>
140068705:     	cmpq	$0x400, %r15            # imm = 0x400
14006870c:     	ja	0x1400687a3 <.text+0x677a3>
140068712:     	cmpq	%rax, %rsi
140068715:     	ja	0x1400687a3 <.text+0x677a3>
14006871b:     	movq	%r8, %r13
14006871e:     	movq	%r9, 0x460(%rbp)
140068725:     	movq	%rcx, 0x470(%rbp)
14006872c:     	movzbl	0x4f8(%rbp), %r14d
140068734:     	movq	%rdi, %rax
140068737:     	shlq	$0xe, %rax
14006873b:     	movq	%rdx, %rsi
14006873e:     	leaq	(%rdx,%rax), %rbx
140068742:     	addq	$0x16700, %rbx          # imm = 0x16700
140068749:     	addq	%r11, %rbx
14006874c:     	movl	$0x400, %r8d            # imm = 0x400
140068752:     	cmpq	$0x400, %r15            # imm = 0x400
140068759:     	je	0x140068769 <.text+0x67769>
14006875b:     	leaq	-0x10(%rbp), %rcx
14006875f:     	xorl	%edx, %edx
140068761:     	callq	0x140251d02 <.text+0x250d02>
140068766:     	movq	%r15, %r8
140068769:     	leaq	-0x10(%rbp), %rcx
14006876d:     	movq	%rbx, %rdx
140068770:     	callq	0x140251cf0 <.text+0x250cf0>
140068775:     	testb	%r14b, %r14b
140068778:     	je	0x1400687be <.text+0x677be>
14006877a:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
140068781:     	movq	%rsi, %rcx
140068784:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
14006878d:     	jne	0x14006892a <.text+0x6792a>
140068793:     	xorl	%edi, %edi
140068795:     	callq	0x14009b600 <.text+0x9a600>
14006879a:     	testb	$0x1, %al
14006879c:     	jne	0x1400687d0 <.text+0x677d0>
14006879e:     	jmp	0x140068953 <.text+0x67953>
1400687a3:     	movb	$0xa, (%rcx)
1400687a6:     	movq	%r10, 0x8(%rcx)
1400687aa:     	addq	$0x4f8, %rsp            # imm = 0x4F8
1400687b1:     	popq	%rbx
1400687b2:     	popq	%rdi
1400687b3:     	popq	%rsi
1400687b4:     	popq	%r12
1400687b6:     	popq	%r13
1400687b8:     	popq	%r14
1400687ba:     	popq	%r15
1400687bc:     	popq	%rbp
1400687bd:     	retq
1400687be:     	xorl	%edi, %edi
1400687c0:     	movq	%rsi, %rcx
1400687c3:     	callq	0x14009b600 <.text+0x9a600>
1400687c8:     	testb	$0x1, %al
1400687ca:     	je	0x140068953 <.text+0x67953>
1400687d0:     	movq	%rdx, %rbx
1400687d3:     	movq	0x500(%rbp), %rdx
1400687da:     	movzwl	0x4e8(%rbp), %ecx
1400687e1:     	movzbl	0x4e0(%rbp), %eax
1400687e8:     	movq	(%r12), %r8
1400687ec:     	movq	%rdi, 0x430(%rbp)
1400687f3:     	movq	0x468(%rbp), %r9
1400687fa:     	movq	%r9, 0x438(%rbp)
140068801:     	movq	%r8, 0x440(%rbp)
140068808:     	movb	%r14b, 0x448(%rbp)
14006880f:     	movups	0x60(%r13), %xmm0
140068814:     	movups	0x6c(%r13), %xmm1
140068819:     	movups	%xmm1, 0x3fc(%rbp)
140068820:     	movaps	%xmm0, 0x3f0(%rbp)
140068827:     	leaq	0x8e(%r13), %r8
14006882e:     	movq	0x7e(%r13), %r9
140068832:     	movq	0x85(%r13), %r10
140068839:     	movq	%r10, 0x457(%rbp)
140068840:     	movq	%r9, 0x450(%rbp)
140068847:     	leaq	0x450(%rbp), %r9
14006884e:     	movq	%r9, 0x68(%rsp)
140068853:     	movq	%rdx, 0x60(%rsp)
140068858:     	movq	%r13, 0x58(%rsp)
14006885d:     	leaq	0x430(%rbp), %rdx
140068864:     	movq	%rdx, 0x50(%rsp)
140068869:     	movq	%r15, 0x48(%rsp)
14006886e:     	leaq	-0x10(%rbp), %rdx
140068872:     	movq	%rdx, 0x40(%rsp)
140068877:     	movq	0x460(%rbp), %rdx
14006887e:     	movq	%rdx, 0x38(%rsp)
140068883:     	movq	%r8, 0x30(%rsp)
140068888:     	movw	%cx, 0x28(%rsp)
14006888d:     	movb	%al, 0x20(%rsp)
140068891:     	leaq	0x410(%rbp), %rcx
140068898:     	leaq	0x3f0(%rbp), %r8
14006889f:     	movq	%rsi, %rdx
1400688a2:     	movq	%rbx, %r9
1400688a5:     	callq	0x140082b70 <.text+0x81b70>
1400688aa:     	cmpb	$-0x1, 0x410(%rbp)
1400688b1:     	je	0x140068962 <.text+0x67962>
1400688b7:     	cmpb	$0x1, 0x326f0(%rsi,%rbx)
1400688bf:     	movq	0x470(%rbp), %rax
1400688c6:     	jne	0x140068910 <.text+0x67910>
1400688c8:     	cmpb	$0x0, 0x32710(%rsi,%rbx)
1400688d0:     	jne	0x140068910 <.text+0x67910>
1400688d2:     	movb	$0x0, 0x326f0(%rsi,%rbx)
1400688da:     	decq	0x32738(%rsi)
1400688e1:     	leaq	0x326f0(%rsi), %rcx
1400688e8:     	movq	$0x0, 0x3e5c0(%rsi,%rbx,8)
1400688f4:     	leaq	(%rbx,%rbx,8), %rdx
1400688f8:     	leaq	(%rdx,%rdx,2), %rdx
1400688fc:     	addq	%rbx, %rdx
1400688ff:     	movb	$0x2, 0x36a(%rcx,%rdx)
140068907:     	leaq	(%rbx,%rbx,2), %rdx
14006890b:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140068910:     	movups	0x410(%rbp), %xmm0
140068917:     	movups	0x420(%rbp), %xmm1
14006891e:     	movups	%xmm1, 0x10(%rax)
140068922:     	movups	%xmm0, (%rax)
140068925:     	jmp	0x1400687aa <.text+0x677aa>
14006892a:     	addq	%rcx, %rax
14006892d:     	addq	$0x15c28, %rax          # imm = 0x15C28
140068933:     	movq	0x98(%rax), %rax
14006893a:     	movq	%rax, 0x468(%rbp)
140068941:     	movl	$0x1, %edi
140068946:     	callq	0x14009b600 <.text+0x9a600>
14006894b:     	testb	$0x1, %al
14006894d:     	jne	0x1400687d0 <.text+0x677d0>
140068953:     	movq	0x470(%rbp), %rax
14006895a:     	movb	$0x9, (%rax)
14006895d:     	jmp	0x1400687aa <.text+0x677aa>
140068962:     	movq	0x470(%rbp), %rax
140068969:     	movq	%rbx, 0x8(%rax)
14006896d:     	movb	$-0x1, (%rax)
140068970:     	jmp	0x1400687aa <.text+0x677aa>
140068975:     	leaq	0x2042e4(%rip), %r9     # 0x14026cc60
14006897c:     	movl	$0x4000, %r8d           # imm = 0x4000
140068982:     	xorl	%ecx, %ecx
140068984:     	movq	%rax, %rdx
140068987:     	callq	0x140252780 <.text+0x251780>
14006898c:     	ud2

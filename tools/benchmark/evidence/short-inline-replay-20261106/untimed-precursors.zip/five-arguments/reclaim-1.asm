
D:\CoapticCurrent\short-inline-replay-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009e9d0:     	pushq	%rbp
14009e9d1:     	pushq	%r15
14009e9d3:     	pushq	%r14
14009e9d5:     	pushq	%r13
14009e9d7:     	pushq	%r12
14009e9d9:     	pushq	%rsi
14009e9da:     	pushq	%rdi
14009e9db:     	pushq	%rbx
14009e9dc:     	subq	$0x218, %rsp            # imm = 0x218
14009e9e3:     	leaq	0x80(%rsp), %rbp
14009e9eb:     	movaps	%xmm6, 0x180(%rbp)
14009e9f2:     	leaq	0xfe0(%rcx), %r8
14009e9f9:     	leaq	0x1970(%rcx), %rsi
14009ea00:     	xorl	%eax, %eax
14009ea02:     	movl	$0x1, %r10d
14009ea08:     	xorl	%r9d, %r9d
14009ea0b:     	imulq	$0x130, %rax, %r11      # imm = 0x130
14009ea12:     	addq	%rsi, %r11
14009ea15:     	jmp	0x14009ea30 <.text+0x9da30>
14009ea17:     	nopw	(%rax,%rax)
14009ea20:     	incq	%rax
14009ea23:     	addq	$0x130, %r11            # imm = 0x130
14009ea2a:     	cmpq	$0x4, %rax
14009ea2e:     	je	0x14009ea7e <.text+0x9da7e>
14009ea30:     	cmpl	$0x0, 0x4c0(%rsi,%rax,4)
14009ea38:     	je	0x14009ea20 <.text+0x9da20>
14009ea3a:     	cmpb	$0x2, 0x12a(%r11)
14009ea42:     	je	0x14009ea20 <.text+0x9da20>
14009ea44:     	cmpb	$0x3, 0x8(%r11)
14009ea49:     	movq	(%r11), %r11
14009ea4c:     	setne	%bl
14009ea4f:     	testq	%r11, %r11
14009ea52:     	sete	%dil
14009ea56:     	orb	%bl, %dil
14009ea59:     	cmpq	%r14, %r11
14009ea5c:     	setae	%bl
14009ea5f:     	andb	%r9b, %bl
14009ea62:     	testb	%dil, %dil
14009ea65:     	cmoveq	%r10, %r9
14009ea69:     	orb	%dil, %bl
14009ea6c:     	cmoveq	%rax, %rdx
14009ea70:     	cmoveq	%r11, %r14
14009ea74:     	cmpq	$0x3, %rax
14009ea78:     	leaq	0x1(%rax), %rax
14009ea7c:     	jb	0x14009ea0b <.text+0x9da0b>
14009ea7e:     	xorl	%eax, %eax
14009ea80:     	cmpq	$0x1, %r9
14009ea84:     	jne	0x14009ebad <.text+0x9dbad>
14009ea8a:     	cmpq	$0x4, %rdx
14009ea8e:     	jae	0x14009ebad <.text+0x9dbad>
14009ea94:     	cmpl	$0x0, 0x1e30(%rcx,%rdx,4)
14009ea9c:     	je	0x14009ebab <.text+0x9dbab>
14009eaa2:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009eaa9:     	movzbl	0x12a(%rsi,%rax), %r15d
14009eab2:     	cmpb	$0x2, %r15b
14009eab6:     	je	0x14009ebab <.text+0x9dbab>
14009eabc:     	addq	%rsi, %rax
14009eabf:     	cmpb	$0x3, 0x8(%rax)
14009eac3:     	jne	0x14009ebab <.text+0x9dbab>
14009eac9:     	movq	0x10(%rax), %r9
14009eacd:     	movq	0x110(%rax), %r12
14009ead4:     	movq	0x118(%rax), %rdx
14009eadb:     	movq	%rdx, 0x170(%rbp)
14009eae2:     	movl	0x120(%rax), %r13d
14009eae9:     	movl	0x124(%rax), %edi
14009eaef:     	movzwl	0x128(%rax), %edx
14009eaf6:     	movw	%dx, 0x17e(%rbp)
14009eafd:     	movzbl	0x12b(%rax), %edx
14009eb04:     	movb	%dl, 0x17d(%rbp)
14009eb0a:     	movss	0x12c(%rax), %xmm6
14009eb12:     	movzwl	0x12c(%rax), %eax
14009eb19:     	movzwl	%ax, %edx
14009eb1c:     	cmpq	$0x1, %r9
14009eb20:     	ja	0x14009eb75 <.text+0x9db75>
14009eb22:     	cmpb	$0x1, 0x1968(%rcx,%r9)
14009eb2b:     	jne	0x14009eb75 <.text+0x9db75>
14009eb2d:     	cmpb	$0x0, 0x196a(%rcx,%r9)
14009eb36:     	jne	0x14009eb75 <.text+0x9db75>
14009eb38:     	movb	$0x0, 0x1968(%rcx,%r9)
14009eb41:     	decq	0x1960(%rcx)
14009eb48:     	movq	$0x0, 0x18e0(%rcx,%r9,8)
14009eb54:     	leaq	(%r9,%r9,8), %r10
14009eb58:     	leaq	(%r10,%r10,2), %r10
14009eb5c:     	addq	%r9, %r10
14009eb5f:     	movb	$0x2, 0x95a(%r8,%r10)
14009eb68:     	leaq	(%r9,%r9,2), %r9
14009eb6c:     	movb	$0x2, 0x91d(%r8,%r9,8)
14009eb75:     	addl	$0x2, %edx
14009eb78:     	movb	$0x1, %r9b
14009eb7b:     	cmpl	%edx, 0x1e30(%rcx)
14009eb81:     	jne	0x14009eb91 <.text+0x9db91>
14009eb83:     	movzbl	0x1a9a(%rcx), %r8d
14009eb8b:     	cmpb	$0x2, %r8b
14009eb8f:     	jne	0x14009ebc8 <.text+0x9dbc8>
14009eb91:     	xorl	%r8d, %r8d
14009eb94:     	cmpl	%edx, 0x1e34(%rcx)
14009eb9a:     	movl	%edi, 0x178(%rbp)
14009eba0:     	jne	0x14009ec5c <.text+0x9dc5c>
14009eba6:     	jmp	0x14009ec4a <.text+0x9dc4a>
14009ebab:     	xorl	%eax, %eax
14009ebad:     	movaps	0x180(%rbp), %xmm6
14009ebb4:     	addq	$0x218, %rsp            # imm = 0x218
14009ebbb:     	popq	%rbx
14009ebbc:     	popq	%rdi
14009ebbd:     	popq	%rsi
14009ebbe:     	popq	%r12
14009ebc0:     	popq	%r13
14009ebc2:     	popq	%r14
14009ebc4:     	popq	%r15
14009ebc6:     	popq	%rbp
14009ebc7:     	retq
14009ebc8:     	cmpw	%ax, 0x1a9c(%rcx)
14009ebcf:     	sete	%r9b
14009ebd3:     	cmpl	%r13d, 0x1a90(%rcx)
14009ebda:     	sete	%r10b
14009ebde:     	andb	%r9b, %r10b
14009ebe1:     	cmpl	%edi, 0x1a94(%rcx)
14009ebe7:     	sete	%r9b
14009ebeb:     	movzwl	0x17e(%rbp), %r11d
14009ebf3:     	cmpw	%r11w, 0x1a98(%rcx)
14009ebfb:     	sete	%r11b
14009ebff:     	andb	%r9b, %r11b
14009ec02:     	andb	%r10b, %r11b
14009ec05:     	cmpb	%r15b, %r8b
14009ec08:     	sete	%r8b
14009ec0c:     	movq	0x1a88(%rcx), %r9
14009ec13:     	xorq	0x170(%rbp), %r9
14009ec1a:     	movq	0x1a80(%rcx), %r10
14009ec21:     	xorq	%r12, %r10
14009ec24:     	orq	%r9, %r10
14009ec27:     	sete	%r9b
14009ec2b:     	andb	%r8b, %r9b
14009ec2e:     	andb	%r11b, %r9b
14009ec31:     	movzbl	%r9b, %r8d
14009ec35:     	movl	%r8d, %r9d
14009ec38:     	xorb	$0x1, %r9b
14009ec3c:     	cmpl	%edx, 0x1e34(%rcx)
14009ec42:     	movl	%edi, 0x178(%rbp)
14009ec48:     	jne	0x14009ec5c <.text+0x9dc5c>
14009ec4a:     	movzbl	0x1bca(%rcx), %r10d
14009ec52:     	cmpb	$0x2, %r10b
14009ec56:     	jne	0x14009ed06 <.text+0x9dd06>
14009ec5c:     	xorl	%r9d, %r9d
14009ec5f:     	cmpl	%edx, 0x1e38(%rcx)
14009ec65:     	jne	0x14009eda3 <.text+0x9dda3>
14009ec6b:     	movzbl	0x1cfa(%rcx), %r10d
14009ec73:     	cmpb	$0x2, %r10b
14009ec77:     	je	0x14009eda3 <.text+0x9dda3>
14009ec7d:     	cmpb	%r15b, %r10b
14009ec80:     	jne	0x14009eda3 <.text+0x9dda3>
14009ec86:     	cmpw	%ax, 0x1cfc(%rcx)
14009ec8d:     	jne	0x14009eda3 <.text+0x9dda3>
14009ec93:     	cmpl	%r13d, 0x1cf0(%rcx)
14009ec9a:     	jne	0x14009eda3 <.text+0x9dda3>
14009eca0:     	cmpl	%edi, 0x1cf4(%rcx)
14009eca6:     	jne	0x14009eda3 <.text+0x9dda3>
14009ecac:     	movzwl	0x17e(%rbp), %r10d
14009ecb4:     	cmpw	%r10w, 0x1cf8(%rcx)
14009ecbc:     	jne	0x14009eda3 <.text+0x9dda3>
14009ecc2:     	movq	0x1ce0(%rcx), %r10
14009ecc9:     	xorq	%r12, %r10
14009eccc:     	movq	0x1ce8(%rcx), %r11
14009ecd3:     	xorq	0x170(%rbp), %r11
14009ecda:     	orq	%r10, %r11
14009ecdd:     	jne	0x14009eda3 <.text+0x9dda3>
14009ece3:     	movb	$0x1, %dil
14009ece6:     	testq	%r8, %r8
14009ece9:     	jne	0x14009ee26 <.text+0x9de26>
14009ecef:     	movl	$0x1, %r8d
14009ecf5:     	movl	$0x2, %r9d
14009ecfb:     	movl	0x178(%rbp), %edi
14009ed01:     	jmp	0x14009eda3 <.text+0x9dda3>
14009ed06:     	cmpw	%ax, 0x1bcc(%rcx)
14009ed0d:     	setne	%r11b
14009ed11:     	cmpl	%r13d, 0x1bc0(%rcx)
14009ed18:     	setne	%bl
14009ed1b:     	orb	%r11b, %bl
14009ed1e:     	cmpl	%edi, 0x1bc4(%rcx)
14009ed24:     	setne	%r11b
14009ed28:     	movzwl	0x17e(%rbp), %edi
14009ed2f:     	cmpw	%di, 0x1bc8(%rcx)
14009ed36:     	setne	%dil
14009ed3a:     	orb	%r11b, %dil
14009ed3d:     	orb	%bl, %dil
14009ed40:     	cmpb	%r15b, %r10b
14009ed43:     	setne	%r11b
14009ed47:     	movq	0x1bb8(%rcx), %r10
14009ed4e:     	xorq	0x170(%rbp), %r10
14009ed55:     	movq	0x1bb0(%rcx), %rbx
14009ed5c:     	xorq	%r12, %rbx
14009ed5f:     	orq	%r10, %rbx
14009ed62:     	setne	%r10b
14009ed66:     	orb	%r11b, %r10b
14009ed69:     	orb	%dil, %r10b
14009ed6c:     	orb	%r10b, %r9b
14009ed6f:     	testb	%r10b, %r10b
14009ed72:     	movl	$0x1, %r11d
14009ed78:     	cmoveq	%r11, %r8
14009ed7c:     	testb	$0x1, %r9b
14009ed80:     	je	0x14009ee20 <.text+0x9de20>
14009ed86:     	notb	%r10b
14009ed89:     	movzbl	%r10b, %r9d
14009ed8d:     	andl	$0x1, %r9d
14009ed91:     	movl	0x178(%rbp), %edi
14009ed97:     	cmpl	%edx, 0x1e38(%rcx)
14009ed9d:     	je	0x14009ec6b <.text+0x9dc6b>
14009eda3:     	cmpl	%edx, 0x1e3c(%rcx)
14009eda9:     	jne	0x14009edb7 <.text+0x9ddb7>
14009edab:     	movzbl	0x1e2a(%rcx), %edx
14009edb2:     	cmpb	$0x2, %dl
14009edb5:     	jne	0x14009edc3 <.text+0x9ddc3>
14009edb7:     	xorl	%edi, %edi
14009edb9:     	testq	%r8, %r8
14009edbc:     	jne	0x14009ee26 <.text+0x9de26>
14009edbe:     	jmp	0x14009ee53 <.text+0x9de53>
14009edc3:     	cmpb	%r15b, %dl
14009edc6:     	jne	0x14009edb7 <.text+0x9ddb7>
14009edc8:     	cmpw	%ax, 0x1e2c(%rcx)
14009edcf:     	jne	0x14009edb7 <.text+0x9ddb7>
14009edd1:     	cmpl	%r13d, 0x1e20(%rcx)
14009edd8:     	jne	0x14009edb7 <.text+0x9ddb7>
14009edda:     	cmpl	%edi, 0x1e24(%rcx)
14009ede0:     	jne	0x14009edb7 <.text+0x9ddb7>
14009ede2:     	movzwl	0x17e(%rbp), %edx
14009ede9:     	cmpw	%dx, 0x1e28(%rcx)
14009edf0:     	jne	0x14009edb7 <.text+0x9ddb7>
14009edf2:     	movq	0x1e10(%rcx), %rdx
14009edf9:     	xorq	%r12, %rdx
14009edfc:     	movq	0x1e18(%rcx), %r10
14009ee03:     	xorq	0x170(%rbp), %r10
14009ee0a:     	orq	%rdx, %r10
14009ee0d:     	jne	0x14009edb7 <.text+0x9ddb7>
14009ee0f:     	testq	%r8, %r8
14009ee12:     	movl	$0x3, %edx
14009ee17:     	cmoveq	%rdx, %r9
14009ee1b:     	movl	%r8d, %edi
14009ee1e:     	jmp	0x14009ee26 <.text+0x9de26>
14009ee20:     	movb	$0x1, %dil
14009ee23:     	xorl	%r9d, %r9d
14009ee26:     	cmpl	$0x0, 0x1e30(%rcx,%r9,4)
14009ee2f:     	je	0x14009ee53 <.text+0x9de53>
14009ee31:     	movl	$0x0, 0x1e30(%rcx,%r9,4)
14009ee3d:     	decq	0x1e48(%rcx)
14009ee44:     	imulq	$0x130, %r9, %rdx       # imm = 0x130
14009ee4b:     	movb	$0x2, 0x12a(%rsi,%rdx)
14009ee53:     	movl	%r13d, 0x16c(%rbp)
14009ee5a:     	movq	%r12, %r13
14009ee5d:     	xorps	%xmm0, %xmm0
14009ee60:     	movaps	%xmm0, 0x150(%rbp)
14009ee67:     	movb	$0x0, 0x132(%rbp)
14009ee6e:     	movw	%ax, 0x130(%rbp)
14009ee75:     	leaq	0x133(%rbp), %rdx
14009ee7c:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009ee85:     	movq	$0x0, 0x133(%rbp)
14009ee90:     	movq	$0x8, 0x110(%rbp)
14009ee9b:     	movq	$0x0, 0x118(%rbp)
14009eea6:     	movq	$0x1, 0x120(%rbp)
14009eeb1:     	movq	$0x0, 0x128(%rbp)
14009eebc:     	movq	%rdx, 0x30(%rsp)
14009eec1:     	movw	%ax, 0x28(%rsp)
14009eec6:     	movq	$0x0, 0x58(%rsp)
14009eecf:     	movq	$0x1, 0x50(%rsp)
14009eed8:     	movq	$0x8, 0x48(%rsp)
14009eee1:     	movq	$0x8, 0x40(%rsp)
14009eeea:     	movq	$0x0, 0x38(%rsp)
14009eef3:     	movb	$0x0, 0x20(%rsp)
14009eef8:     	leaq	0x140(%rbp), %rax
14009eeff:     	leaq	0x150(%rbp), %rdx
14009ef06:     	movl	$0x10, %r8d
14009ef0c:     	movq	%rcx, %r12
14009ef0f:     	movq	%rax, %rcx
14009ef12:     	movb	$0x2, %r9b
14009ef15:     	callq	0x140005590 <.text+0x4590>
14009ef1a:     	cmpb	$0x0, 0x140(%rbp)
14009ef21:     	jne	0x14009f0d2 <.text+0x9e0d2>
14009ef27:     	testb	%dil, %dil
14009ef2a:     	jne	0x14009f0d2 <.text+0x9e0d2>
14009ef30:     	movq	0x148(%rbp), %rbx
14009ef37:     	cmpq	$0x10, %rbx
14009ef3b:     	ja	0x14009f0d2 <.text+0x9e0d2>
14009ef41:     	movq	%r12, %rax
14009ef44:     	cmpq	$0x4, 0x1e48(%r12)
14009ef4d:     	je	0x14009f0d2 <.text+0x9e0d2>
14009ef53:     	movq	0x1e40(%rax), %rdi
14009ef5a:     	cmpq	$0x3, %rdi
14009ef5e:     	ja	0x14009f0ea <.text+0x9e0ea>
14009ef64:     	cmpl	$0x0, 0x1e30(%rax,%rdi,4)
14009ef6c:     	je	0x14009efe6 <.text+0x9dfe6>
14009ef6e:     	leaq	(,%rdi,4), %rdx
14009ef76:     	xorl	%ecx, %ecx
14009ef78:     	cmpl	$0x0, 0x1e30(%rax,%rdx)
14009ef80:     	je	0x14009efd9 <.text+0x9dfd9>
14009ef82:     	addq	$0x4, %rdx
14009ef86:     	decq	%rcx
14009ef89:     	cmpq	$0x10, %rdx
14009ef8d:     	jne	0x14009ef78 <.text+0x9df78>
14009ef8f:     	testq	%rdi, %rdi
14009ef92:     	je	0x14009f0d2 <.text+0x9e0d2>
14009ef98:     	cmpl	$0x0, 0x1e30(%rax)
14009ef9f:     	je	0x14009f0d9 <.text+0x9e0d9>
14009efa5:     	cmpq	$0x1, %rdi
14009efa9:     	je	0x14009f0d2 <.text+0x9e0d2>
14009efaf:     	cmpl	$0x0, 0x1e34(%rax)
14009efb6:     	je	0x14009f0e0 <.text+0x9e0e0>
14009efbc:     	cmpq	$0x2, %rdi
14009efc0:     	je	0x14009f0d2 <.text+0x9e0d2>
14009efc6:     	movl	$0x2, %edi
14009efcb:     	cmpl	$0x0, 0x1e38(%rax)
14009efd2:     	je	0x14009efdc <.text+0x9dfdc>
14009efd4:     	jmp	0x14009f0d2 <.text+0x9e0d2>
14009efd9:     	subq	%rcx, %rdi
14009efdc:     	cmpq	$0x4, %rdi
14009efe0:     	jae	0x14009f100 <.text+0x9e100>
14009efe6:     	movl	$0x1, 0x1e30(%rax,%rdi,4)
14009eff1:     	incq	0x1e48(%rax)
14009eff8:     	leaq	0x1(%rdi), %rcx
14009effc:     	xorl	%edx, %edx
14009effe:     	cmpq	$0x4, %rcx
14009f002:     	cmovneq	%rcx, %rdx
14009f006:     	movq	%rdx, 0x1e40(%rax)
14009f00d:     	movq	0x170(%rbp), %rcx
14009f014:     	movq	%rcx, 0xf8(%rbp)
14009f01b:     	movq	%r13, 0xf0(%rbp)
14009f022:     	movl	0x16c(%rbp), %ecx
14009f028:     	movl	%ecx, 0x100(%rbp)
14009f02e:     	movl	0x178(%rbp), %ecx
14009f034:     	movl	%ecx, 0x104(%rbp)
14009f03a:     	movzwl	0x17e(%rbp), %ecx
14009f041:     	movw	%cx, 0x108(%rbp)
14009f048:     	movb	%r15b, 0x10a(%rbp)
14009f04f:     	movzbl	0x17d(%rbp), %ecx
14009f056:     	movb	%cl, 0x10b(%rbp)
14009f05c:     	movss	%xmm6, 0x10c(%rbp)
14009f064:     	movq	%r14, -0x20(%rbp)
14009f068:     	testq	%rbx, %rbx
14009f06b:     	je	0x14009f0a7 <.text+0x9e0a7>
14009f06d:     	movb	$0x1, -0x18(%rbp)
14009f071:     	movb	%bl, -0x17(%rbp)
14009f074:     	leaq	-0x16(%rbp), %r14
14009f078:     	movl	$0x80, %r8d
14009f07e:     	subq	%rbx, %r8
14009f081:     	leaq	(%rbx,%rbp), %rcx
14009f085:     	addq	$-0x16, %rcx
14009f089:     	xorl	%edx, %edx
14009f08b:     	callq	0x140251d02 <.text+0x250d02>
14009f090:     	leaq	0x150(%rbp), %rdx
14009f097:     	movq	%r14, %rcx
14009f09a:     	movq	%rbx, %r8
14009f09d:     	callq	0x140251cf0 <.text+0x250cf0>
14009f0a2:     	movq	%r12, %rax
14009f0a5:     	jmp	0x14009f0ab <.text+0x9e0ab>
14009f0a7:     	movb	$0x0, -0x18(%rbp)
14009f0ab:     	movzwl	0x10c(%rbp), %ecx
14009f0b2:     	addl	$0x2, %ecx
14009f0b5:     	movl	%ecx, 0x1e30(%rax,%rdi,4)
14009f0bc:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009f0c3:     	addq	%rax, %rsi
14009f0c6:     	leaq	-0x20(%rbp), %rcx
14009f0ca:     	movq	%rsi, %rdx
14009f0cd:     	callq	0x14000b1c0 <.text+0xa1c0>
14009f0d2:     	movb	$0x1, %al
14009f0d4:     	jmp	0x14009ebad <.text+0x9dbad>
14009f0d9:     	xorl	%edi, %edi
14009f0db:     	jmp	0x14009efdc <.text+0x9dfdc>
14009f0e0:     	movl	$0x1, %edi
14009f0e5:     	jmp	0x14009efdc <.text+0x9dfdc>
14009f0ea:     	leaq	0x1cdcbf(%rip), %r8     # 0x14026cdb0
14009f0f1:     	movl	$0x4, %edx
14009f0f6:     	movq	%rdi, %rcx
14009f0f9:     	callq	0x140252573 <.text+0x251573>
14009f0fe:     	ud2
14009f100:     	leaq	0x1cdcc1(%rip), %r8     # 0x14026cdc8
14009f107:     	movl	$0x4, %edx
14009f10c:     	movq	%rdi, %rcx
14009f10f:     	callq	0x140252573 <.text+0x251573>
14009f114:     	ud2


D:\CoapticCurrent\short-inline-replay-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14000b1c0:     	pushq	%rbp
14000b1c1:     	subq	$0x30, %rsp
14000b1c5:     	leaq	0x30(%rsp), %rbp
14000b1ca:     	movzbl	0x8(%rcx), %eax
14000b1ce:     	leaq	0x256693(%rip), %r8     # 0x140261868
14000b1d5:     	movslq	(%r8,%rax,4), %rax
14000b1d9:     	addq	%r8, %rax
14000b1dc:     	jmpq	*%rax
14000b1de:     	movb	$0x0, 0x8(%rdx)
14000b1e2:     	movups	0x110(%rcx), %xmm0
14000b1e9:     	movups	0x120(%rcx), %xmm1
14000b1f0:     	movups	%xmm0, 0x110(%rdx)
14000b1f7:     	movups	%xmm1, 0x120(%rdx)
14000b1fe:     	movq	(%rcx), %rax
14000b201:     	movq	%rax, (%rdx)
14000b204:     	addq	$0x30, %rsp
14000b208:     	popq	%rbp
14000b209:     	retq
14000b20a:     	movl	$0x130, %r8d            # imm = 0x130
14000b210:     	movq	%rcx, %rax
14000b213:     	movq	%rdx, %rcx
14000b216:     	movq	%rax, %rdx
14000b219:     	addq	$0x30, %rsp
14000b21d:     	popq	%rbp
14000b21e:     	jmp	0x140251cf0 <.text+0x250cf0>
14000b223:     	leaq	0x110(%rcx), %rax
14000b22a:     	movq	(%rcx), %r8
14000b22d:     	movq	0x10(%rcx), %r9
14000b231:     	movq	%rdx, %rcx
14000b234:     	movq	%rax, %rdx
14000b237:     	addq	$0x30, %rsp
14000b23b:     	popq	%rbp
14000b23c:     	jmp	0x14000b370 <.text+0xa370>
14000b241:     	leaq	0xa(%rcx), %r9
14000b245:     	leaq	0x110(%rcx), %rax
14000b24c:     	movq	(%rcx), %r8
14000b24f:     	movzbl	0x9(%rcx), %ecx
14000b253:     	movb	%cl, 0x20(%rsp)
14000b257:     	movq	%rdx, %rcx
14000b25a:     	movq	%rax, %rdx
14000b25d:     	callq	0x14000b270 <.text+0xa270>
14000b262:     	nop
14000b263:     	addq	$0x30, %rsp
14000b267:     	popq	%rbp
14000b268:     	retq

from pathlib import Path
import json, subprocess, hashlib, shutil
r = Path(__file__).resolve().parent
prior = Path('D:/CoapticCurrent/borrowed-reclaim-encoding-20261106')
repo = Path('C:/Users/jeffg/.t3/worktrees/coaptic/t3-a578955c')
sha = '80a184c75f631a3cdd25a8279778eee3d7473b92'
old = '40e195ab66a839f19df5949a3fff9d0c2e35336c'
v = json.loads((prior/'source-verification.json').read_text())
v['source'] = sha
fixture = Path(v['fixture_root'])/'coaptic'
for name in v['source_file_hashes']:
    data = subprocess.check_output(['git','-C',str(repo),'show',sha+':'+name]).replace(b'\r\n',b'\n')
    p = fixture/name
    if p.read_bytes() != data: p.write_bytes(data)
    v['source_file_hashes'][name] = hashlib.sha256(data).hexdigest()
patch = subprocess.check_output(['git','-C',str(repo),'diff','--binary',v['baseline'],sha,'--','src','crates','tests','Cargo.toml','Cargo.lock'])
(r/'candidate.patch').write_bytes(patch)
v['patch_sha256'] = hashlib.sha256(patch).hexdigest()
(r/'source-verification.json').write_text(json.dumps(v,indent=2)+'\n')
for name in ['build-preflight.py','build.py','layout.py','inspect.py','measure.py','qualify.py']:
    text = (prior/name).read_text().replace(old,sha)
    if name == 'inspect.py':
        text = text.replace('(?=^\\d+ \\| S_LPROC32)', '(?=^\\s*\\d+ \\| S_LPROC32)')
    (r/name).write_text(text)
(r/'B').mkdir(exist_ok=True)
(r/'layout32').mkdir(exist_ok=True)
for name in ['audit.py','Cargo.toml','Cargo.lock','lib.rs','baseline-build.log','baseline-constants.txt','baseline-layout.txt','baseline-source.json']:
    shutil.copyfile(prior/'layout32'/name,r/'layout32'/name)
shutil.copyfile(prior/'fixture-sha256.json',r/'fixture-sha256.json')
m = json.loads((prior/'METHOD-BEFORE.json').read_text())
m['candidate'] = sha
m['source_hypothesis'] = m['hypothesis'] = 'Short inline replay owner128 bytes avoids initializing/copying all256 payload bytes for short responses and reclaimed ACKs. A separate destination writer must avoid the full304-byte row memcpy observed in40e195a. Full256-byte replay capacity and long-row behavior are retained. Keep compact occupancy, owned reclaim, borrowed encoding and full-chunk initialization integrated.'
m['tradeoffs'] = 'Adds one internal enum branch, no pool/capacity cut and no unsafe code. Canonical lengths1..128 useShort,129..256 useInline, empty clears and oversize preserves prior owner. Public active-owner equality semantics remain. Require wholeApp/future/selectedframes nongrowth and retain initialization/copy counts separately from runtime.'
m['preflight_repair'] = 'Prior40e195a passes memory checks but fails5CPU bounds, including SmallDevice that never reclaims TX. Inspectable inline writer stillcopies304B per shortreply. This is a distinct cost/ownership reduction, not unchanged resampling.'
(r/'METHOD-BEFORE.json').write_text(json.dumps(m,indent=2)+'\n')
print({'source':sha,'verified_files':len(v['source_file_hashes'])},flush=True)

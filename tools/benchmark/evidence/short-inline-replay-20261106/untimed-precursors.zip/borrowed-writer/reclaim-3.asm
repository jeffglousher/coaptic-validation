
D:\CoapticCurrent\short-inline-replay-20261106\borrowed-writer\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009f400:     	pushq	%rbp
14009f401:     	pushq	%r15
14009f403:     	pushq	%r14
14009f405:     	pushq	%r13
14009f407:     	pushq	%r12
14009f409:     	pushq	%rsi
14009f40a:     	pushq	%rdi
14009f40b:     	pushq	%rbx
14009f40c:     	subq	$0x218, %rsp            # imm = 0x218
14009f413:     	leaq	0x80(%rsp), %rbp
14009f41b:     	movaps	%xmm6, 0x180(%rbp)
14009f422:     	leaq	0x326f0(%rcx), %rdx
14009f429:     	leaq	0x3f7f0(%rcx), %rsi
14009f430:     	leaq	0x443f0(%rcx), %r15
14009f437:     	leaq	0x3f818(%rcx), %rax
14009f43e:     	xorl	%r10d, %r10d
14009f441:     	movl	$0x1, %r11d
14009f447:     	xorl	%r9d, %r9d
14009f44a:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009f451:     	addq	%rax, %rdi
14009f454:     	jmp	0x14009f470 <.text+0x9e470>
14009f456:     	nopw	%cs:(%rax,%rax)
14009f460:     	incq	%r10
14009f463:     	addq	$0x130, %rdi            # imm = 0x130
14009f46a:     	cmpq	$0x40, %r10
14009f46e:     	je	0x14009f4ba <.text+0x9e4ba>
14009f470:     	cmpl	$0x0, 0x443f0(%rcx,%r10,4)
14009f479:     	je	0x14009f460 <.text+0x9e460>
14009f47b:     	cmpb	$0x2, -0xe(%rdi)
14009f47f:     	je	0x14009f460 <.text+0x9e460>
14009f481:     	cmpb	$0x3, (%rdi)
14009f484:     	movq	-0x8(%rdi), %rdi
14009f488:     	setne	%bl
14009f48b:     	testq	%rdi, %rdi
14009f48e:     	sete	%r12b
14009f492:     	orb	%bl, %r12b
14009f495:     	cmpq	%r14, %rdi
14009f498:     	setae	%bl
14009f49b:     	andb	%r9b, %bl
14009f49e:     	testb	%r12b, %r12b
14009f4a1:     	cmoveq	%r11, %r9
14009f4a5:     	orb	%r12b, %bl
14009f4a8:     	cmoveq	%r10, %r8
14009f4ac:     	cmoveq	%rdi, %r14
14009f4b0:     	cmpq	$0x3f, %r10
14009f4b4:     	leaq	0x1(%r10), %r10
14009f4b8:     	jb	0x14009f44a <.text+0x9e44a>
14009f4ba:     	xorl	%eax, %eax
14009f4bc:     	cmpq	$0x1, %r9
14009f4c0:     	jne	0x14009f640 <.text+0x9e640>
14009f4c6:     	cmpq	$0x40, %r8
14009f4ca:     	jae	0x14009f640 <.text+0x9e640>
14009f4d0:     	cmpl	$0x0, (%r15,%r8,4)
14009f4d5:     	je	0x14009f63e <.text+0x9e63e>
14009f4db:     	imulq	$0x130, %r8, %rax       # imm = 0x130
14009f4e2:     	movzbl	0x1a(%rsi,%rax), %r12d
14009f4e8:     	cmpb	$0x2, %r12b
14009f4ec:     	je	0x14009f63e <.text+0x9e63e>
14009f4f2:     	addq	%rsi, %rax
14009f4f5:     	cmpb	$0x3, 0x28(%rax)
14009f4f9:     	jne	0x14009f63e <.text+0x9e63e>
14009f4ff:     	movq	0x30(%rax), %r9
14009f503:     	movq	(%rax), %r8
14009f506:     	movq	%r8, 0x168(%rbp)
14009f50d:     	movq	0x8(%rax), %r8
14009f511:     	movq	%r8, 0x170(%rbp)
14009f518:     	movl	0x10(%rax), %edi
14009f51b:     	movl	0x14(%rax), %r8d
14009f51f:     	movl	%r8d, 0x178(%rbp)
14009f526:     	movzwl	0x18(%rax), %r8d
14009f52b:     	movw	%r8w, 0x17c(%rbp)
14009f533:     	movzbl	0x1b(%rax), %r8d
14009f538:     	movb	%r8b, 0x17f(%rbp)
14009f53f:     	movss	0x1c(%rax), %xmm6
14009f544:     	movzwl	0x1c(%rax), %eax
14009f548:     	movzwl	%ax, %r8d
14009f54c:     	cmpq	$0x1f, %r9
14009f550:     	ja	0x14009f59e <.text+0x9e59e>
14009f552:     	cmpb	$0x1, (%rdx,%r9)
14009f557:     	jne	0x14009f59e <.text+0x9e59e>
14009f559:     	cmpb	$0x0, 0x32710(%rcx,%r9)
14009f562:     	jne	0x14009f59e <.text+0x9e59e>
14009f564:     	movb	$0x0, 0x326f0(%rcx,%r9)
14009f56d:     	decq	0x32738(%rcx)
14009f574:     	movq	$0x0, 0x3e5c0(%rcx,%r9,8)
14009f580:     	leaq	(%r9,%r9,8), %r10
14009f584:     	leaq	(%r10,%r10,2), %r10
14009f588:     	addq	%r9, %r10
14009f58b:     	movb	$0x2, 0x36a(%rdx,%r10)
14009f594:     	leaq	(%r9,%r9,2), %r9
14009f598:     	movb	$0x2, 0x5d(%rdx,%r9,8)
14009f59e:     	addl	$0x2, %r8d
14009f5a2:     	leaq	0x3f80c(%rcx), %r9
14009f5a9:     	xorl	%r10d, %r10d
14009f5ac:     	xorl	%edx, %edx
14009f5ae:     	jmp	0x14009f5c7 <.text+0x9e5c7>
14009f5b0:     	movq	%r13, %r11
14009f5b3:     	incq	%r10
14009f5b6:     	addq	$0x130, %r9             # imm = 0x130
14009f5bd:     	cmpq	$0x40, %r10
14009f5c1:     	je	0x14009f65b <.text+0x9e65b>
14009f5c7:     	movq	%r11, %r13
14009f5ca:     	cmpl	%r8d, (%r15,%r10,4)
14009f5ce:     	jne	0x14009f5b0 <.text+0x9e5b0>
14009f5d0:     	movzbl	-0x2(%r9), %r11d
14009f5d5:     	cmpb	$0x2, %r11b
14009f5d9:     	je	0x14009f5b0 <.text+0x9e5b0>
14009f5db:     	cmpb	%r12b, %r11b
14009f5de:     	jne	0x14009f5b0 <.text+0x9e5b0>
14009f5e0:     	cmpw	%ax, (%r9)
14009f5e4:     	jne	0x14009f5b0 <.text+0x9e5b0>
14009f5e6:     	cmpl	%edi, -0xc(%r9)
14009f5ea:     	jne	0x14009f5b0 <.text+0x9e5b0>
14009f5ec:     	movl	0x178(%rbp), %r11d
14009f5f3:     	cmpl	%r11d, -0x8(%r9)
14009f5f7:     	jne	0x14009f5b0 <.text+0x9e5b0>
14009f5f9:     	movzwl	0x17c(%rbp), %r11d
14009f601:     	cmpw	%r11w, -0x4(%r9)
14009f606:     	jne	0x14009f5b0 <.text+0x9e5b0>
14009f608:     	movq	-0x1c(%r9), %r11
14009f60c:     	xorq	0x168(%rbp), %r11
14009f613:     	movq	-0x14(%r9), %rbx
14009f617:     	xorq	0x170(%rbp), %rbx
14009f61e:     	orq	%r11, %rbx
14009f621:     	jne	0x14009f5b0 <.text+0x9e5b0>
14009f623:     	movq	%r10, %r11
14009f626:     	cmpq	$0x1, %rdx
14009f62a:     	movl	$0x1, %edx
14009f62f:     	jne	0x14009f5b3 <.text+0x9e5b3>
14009f631:     	movb	$0x1, %bl
14009f633:     	movq	%r13, %r11
14009f636:     	cmpq	$0x3f, %r13
14009f63a:     	jbe	0x14009f66a <.text+0x9e66a>
14009f63c:     	jmp	0x14009f690 <.text+0x9e690>
14009f63e:     	xorl	%eax, %eax
14009f640:     	movaps	0x180(%rbp), %xmm6
14009f647:     	addq	$0x218, %rsp            # imm = 0x218
14009f64e:     	popq	%rbx
14009f64f:     	popq	%rdi
14009f650:     	popq	%rsi
14009f651:     	popq	%r12
14009f653:     	popq	%r13
14009f655:     	popq	%r14
14009f657:     	popq	%r15
14009f659:     	popq	%rbp
14009f65a:     	retq
14009f65b:     	cmpq	$0x40, %r11
14009f65f:     	setb	%r8b
14009f663:     	xorl	%ebx, %ebx
14009f665:     	testb	%r8b, %dl
14009f668:     	je	0x14009f690 <.text+0x9e690>
14009f66a:     	cmpl	$0x0, (%r15,%r11,4)
14009f66f:     	je	0x14009f690 <.text+0x9e690>
14009f671:     	movl	$0x0, 0x443f0(%rcx,%r11,4)
14009f67d:     	decq	0x444f8(%rcx)
14009f684:     	imulq	$0x130, %r11, %rdx      # imm = 0x130
14009f68b:     	movb	$0x2, 0x1a(%rsi,%rdx)
14009f690:     	pxor	%xmm0, %xmm0
14009f694:     	movdqa	%xmm0, 0x150(%rbp)
14009f69c:     	movb	$0x0, 0x132(%rbp)
14009f6a3:     	movw	%ax, 0x130(%rbp)
14009f6aa:     	leaq	0x133(%rbp), %rdx
14009f6b1:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009f6ba:     	movq	$0x0, 0x133(%rbp)
14009f6c5:     	movq	$0x8, 0x110(%rbp)
14009f6d0:     	movq	$0x0, 0x118(%rbp)
14009f6db:     	movq	$0x1, 0x120(%rbp)
14009f6e6:     	movq	$0x0, 0x128(%rbp)
14009f6f1:     	movq	%rdx, 0x30(%rsp)
14009f6f6:     	movw	%ax, 0x28(%rsp)
14009f6fb:     	movq	$0x0, 0x58(%rsp)
14009f704:     	movq	$0x1, 0x50(%rsp)
14009f70d:     	movq	$0x8, 0x48(%rsp)
14009f716:     	movq	$0x8, 0x40(%rsp)
14009f71f:     	movq	$0x0, 0x38(%rsp)
14009f728:     	movb	$0x0, 0x20(%rsp)
14009f72d:     	leaq	0x140(%rbp), %rax
14009f734:     	leaq	0x150(%rbp), %rdx
14009f73b:     	movl	$0x10, %r8d
14009f741:     	movq	%rcx, %r13
14009f744:     	movq	%rax, %rcx
14009f747:     	movb	$0x2, %r9b
14009f74a:     	callq	0x140005590 <.text+0x4590>
14009f74f:     	movq	%r13, %rax
14009f752:     	movq	0x148(%rbp), %r13
14009f759:     	cmpq	$0x11, %r13
14009f75d:     	setae	%cl
14009f760:     	orb	%bl, %cl
14009f762:     	orb	0x140(%rbp), %cl
14009f768:     	testb	$0x1, %cl
14009f76b:     	jne	0x14009f8d0 <.text+0x9e8d0>
14009f771:     	cmpq	$0x40, 0x444f8(%rax)
14009f779:     	je	0x14009f8d0 <.text+0x9e8d0>
14009f77f:     	movq	0x444f0(%rax), %rbx
14009f786:     	cmpq	$0x3f, %rbx
14009f78a:     	ja	0x14009f990 <.text+0x9e990>
14009f790:     	cmpl	$0x0, (%r15,%rbx,4)
14009f795:     	je	0x14009f800 <.text+0x9e800>
14009f797:     	leaq	(,%rbx,4), %rdx
14009f79f:     	leaq	(%r15,%rbx,4), %rcx
14009f7a3:     	xorl	%r8d, %r8d
14009f7a6:     	movq	%rdx, %r9
14009f7a9:     	cmpl	$0x0, (%r15,%r9)
14009f7ae:     	je	0x14009f7f3 <.text+0x9e7f3>
14009f7b0:     	addq	$0x4, %r9
14009f7b4:     	decq	%r8
14009f7b7:     	cmpq	$0x100, %r9             # imm = 0x100
14009f7be:     	jne	0x14009f7a9 <.text+0x9e7a9>
14009f7c0:     	testq	%rbx, %rbx
14009f7c3:     	je	0x14009f8d0 <.text+0x9e8d0>
14009f7c9:     	addq	$-0x4, %rdx
14009f7cd:     	cmpq	$0xc, %rdx
14009f7d1:     	jae	0x14009f8d7 <.text+0x9e8d7>
14009f7d7:     	xorl	%ebx, %ebx
14009f7d9:     	movq	%r15, %r9
14009f7dc:     	cmpl	$0x0, (%r9)
14009f7e0:     	je	0x14009f7f6 <.text+0x9e7f6>
14009f7e2:     	addq	$0x4, %r9
14009f7e6:     	incq	%rbx
14009f7e9:     	cmpq	%rcx, %r9
14009f7ec:     	jne	0x14009f7dc <.text+0x9e7dc>
14009f7ee:     	jmp	0x14009f8d0 <.text+0x9e8d0>
14009f7f3:     	subq	%r8, %rbx
14009f7f6:     	cmpq	$0x40, %rbx
14009f7fa:     	jae	0x14009f97a <.text+0x9e97a>
14009f800:     	movl	$0x1, 0x443f0(%rax,%rbx,4)
14009f80b:     	incq	0x444f8(%rax)
14009f812:     	leaq	0x1(%rbx), %rcx
14009f816:     	xorl	%edx, %edx
14009f818:     	cmpq	$0x40, %rcx
14009f81c:     	cmovneq	%rcx, %rdx
14009f820:     	movq	%rdx, 0x444f0(%rax)
14009f827:     	movq	0x170(%rbp), %rax
14009f82e:     	movq	%rax, -0x18(%rbp)
14009f832:     	movq	0x168(%rbp), %rax
14009f839:     	movq	%rax, -0x20(%rbp)
14009f83d:     	movl	%edi, -0x10(%rbp)
14009f840:     	movl	0x178(%rbp), %eax
14009f846:     	movl	%eax, -0xc(%rbp)
14009f849:     	movzwl	0x17c(%rbp), %eax
14009f850:     	movw	%ax, -0x8(%rbp)
14009f854:     	movb	%r12b, -0x6(%rbp)
14009f858:     	movzbl	0x17f(%rbp), %eax
14009f85f:     	movb	%al, -0x5(%rbp)
14009f862:     	movss	%xmm6, -0x4(%rbp)
14009f867:     	movq	%r14, (%rbp)
14009f86b:     	testq	%r13, %r13
14009f86e:     	je	0x14009f8ab <.text+0x9e8ab>
14009f870:     	movb	$0x1, 0x8(%rbp)
14009f874:     	movb	%r13b, 0x9(%rbp)
14009f878:     	leaq	0xa(%rbp), %r14
14009f87c:     	movl	$0x80, %r8d
14009f882:     	subq	%r13, %r8
14009f885:     	leaq	0xa(,%r13), %rcx
14009f88d:     	addq	%rbp, %rcx
14009f890:     	xorl	%edx, %edx
14009f892:     	callq	0x140251722 <.text+0x250722>
14009f897:     	leaq	0x150(%rbp), %rdx
14009f89e:     	movq	%r14, %rcx
14009f8a1:     	movq	%r13, %r8
14009f8a4:     	callq	0x140251710 <.text+0x250710>
14009f8a9:     	jmp	0x14009f8af <.text+0x9e8af>
14009f8ab:     	movb	$0x0, 0x8(%rbp)
14009f8af:     	movzwl	-0x4(%rbp), %eax
14009f8b3:     	addl	$0x2, %eax
14009f8b6:     	movl	%eax, (%r15,%rbx,4)
14009f8ba:     	imulq	$0x130, %rbx, %rax      # imm = 0x130
14009f8c1:     	addq	%rax, %rsi
14009f8c4:     	leaq	-0x20(%rbp), %rcx
14009f8c8:     	movq	%rsi, %rdx
14009f8cb:     	callq	0x14000b1c0 <.text+0xa1c0>
14009f8d0:     	movb	$0x1, %al
14009f8d2:     	jmp	0x14009f640 <.text+0x9e640>
14009f8d7:     	shrq	$0x2, %rdx
14009f8db:     	incq	%rdx
14009f8de:     	movq	%rdx, %rbx
14009f8e1:     	andq	$-0x4, %rbx
14009f8e5:     	leaq	(%r15,%rbx,4), %r9
14009f8e9:     	xorl	%r8d, %r8d
14009f8ec:     	pxor	%xmm1, %xmm1
14009f8f0:     	movdqu	(%r15,%r8,4), %xmm0
14009f8f6:     	movdqa	%xmm0, %xmm2
14009f8fa:     	pcmpeqd	%xmm1, %xmm2
14009f8fe:     	movmskps	%xmm2, %r10d
14009f902:     	testl	%r10d, %r10d
14009f905:     	jne	0x14009f91b <.text+0x9e91b>
14009f907:     	addq	$0x4, %r8
14009f90b:     	cmpq	%r8, %rbx
14009f90e:     	jne	0x14009f8f0 <.text+0x9e8f0>
14009f910:     	cmpq	%rbx, %rdx
14009f913:     	jne	0x14009f7dc <.text+0x9e7dc>
14009f919:     	jmp	0x14009f8d0 <.text+0x9e8d0>
14009f91b:     	pxor	%xmm1, %xmm1
14009f91f:     	pcmpeqd	%xmm1, %xmm0
14009f923:     	pand	0x1c4475(%rip), %xmm0   # 0x140263da0
14009f92b:     	movdqa	0x1c236d(%rip), %xmm1   # 0x140261ca0
14009f933:     	movdqa	%xmm0, %xmm2
14009f937:     	por	%xmm1, %xmm2
14009f93b:     	pshufd	$0xee, %xmm0, %xmm3     # xmm3 = xmm0[2,3,2,3]
14009f940:     	por	%xmm3, %xmm1
14009f944:     	pcmpgtd	%xmm1, %xmm2
14009f948:     	pand	%xmm2, %xmm0
14009f94c:     	pandn	%xmm3, %xmm2
14009f950:     	por	%xmm0, %xmm2
14009f954:     	movd	%xmm2, %ecx
14009f958:     	pshufd	$0x55, %xmm2, %xmm0     # xmm0 = xmm2[1,1,1,1]
14009f95d:     	movd	%xmm0, %edx
14009f961:     	cmpl	%edx, %ecx
14009f963:     	cmoval	%ecx, %edx
14009f966:     	movl	$0x4, %ebx
14009f96b:     	subl	%edx, %ebx
14009f96d:     	addq	%r8, %rbx
14009f970:     	cmpq	$0x40, %rbx
14009f974:     	jb	0x14009f800 <.text+0x9e800>
14009f97a:     	leaq	0x1cd447(%rip), %r8     # 0x14026cdc8
14009f981:     	movl	$0x40, %edx
14009f986:     	movq	%rbx, %rcx
14009f989:     	callq	0x140251f93 <.text+0x250f93>
14009f98e:     	ud2
14009f990:     	leaq	0x1cd419(%rip), %r8     # 0x14026cdb0
14009f997:     	movl	$0x40, %edx
14009f99c:     	movq	%rbx, %rcx
14009f99f:     	callq	0x140251f93 <.text+0x250f93>
14009f9a4:     	ud2

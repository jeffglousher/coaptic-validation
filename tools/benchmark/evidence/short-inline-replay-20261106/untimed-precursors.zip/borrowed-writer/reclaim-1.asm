
D:\CoapticCurrent\short-inline-replay-20261106\borrowed-writer\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009e5e0:     	pushq	%rbp
14009e5e1:     	pushq	%r15
14009e5e3:     	pushq	%r14
14009e5e5:     	pushq	%r13
14009e5e7:     	pushq	%r12
14009e5e9:     	pushq	%rsi
14009e5ea:     	pushq	%rdi
14009e5eb:     	pushq	%rbx
14009e5ec:     	subq	$0x218, %rsp            # imm = 0x218
14009e5f3:     	leaq	0x80(%rsp), %rbp
14009e5fb:     	movaps	%xmm6, 0x180(%rbp)
14009e602:     	leaq	0xfe0(%rcx), %r8
14009e609:     	leaq	0x1970(%rcx), %rsi
14009e610:     	leaq	0x1998(%rcx), %rax
14009e617:     	xorl	%r10d, %r10d
14009e61a:     	movl	$0x1, %r11d
14009e620:     	xorl	%r9d, %r9d
14009e623:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009e62a:     	addq	%rax, %rdi
14009e62d:     	jmp	0x14009e640 <.text+0x9d640>
14009e62f:     	nop
14009e630:     	incq	%r10
14009e633:     	addq	$0x130, %rdi            # imm = 0x130
14009e63a:     	cmpq	$0x4, %r10
14009e63e:     	je	0x14009e68a <.text+0x9d68a>
14009e640:     	cmpl	$0x0, 0x1e30(%rcx,%r10,4)
14009e649:     	je	0x14009e630 <.text+0x9d630>
14009e64b:     	cmpb	$0x2, -0xe(%rdi)
14009e64f:     	je	0x14009e630 <.text+0x9d630>
14009e651:     	cmpb	$0x3, (%rdi)
14009e654:     	movq	-0x8(%rdi), %rdi
14009e658:     	setne	%bl
14009e65b:     	testq	%rdi, %rdi
14009e65e:     	sete	%r15b
14009e662:     	orb	%bl, %r15b
14009e665:     	cmpq	%r14, %rdi
14009e668:     	setae	%bl
14009e66b:     	andb	%r9b, %bl
14009e66e:     	testb	%r15b, %r15b
14009e671:     	cmoveq	%r11, %r9
14009e675:     	orb	%r15b, %bl
14009e678:     	cmoveq	%r10, %rdx
14009e67c:     	cmoveq	%rdi, %r14
14009e680:     	cmpq	$0x3, %r10
14009e684:     	leaq	0x1(%r10), %r10
14009e688:     	jb	0x14009e623 <.text+0x9d623>
14009e68a:     	xorl	%eax, %eax
14009e68c:     	cmpq	$0x1, %r9
14009e690:     	jne	0x14009e79d <.text+0x9d79d>
14009e696:     	cmpq	$0x4, %rdx
14009e69a:     	jae	0x14009e79d <.text+0x9d79d>
14009e6a0:     	cmpl	$0x0, 0x1e30(%rcx,%rdx,4)
14009e6a8:     	je	0x14009e79b <.text+0x9d79b>
14009e6ae:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009e6b5:     	movzbl	0x1a(%rsi,%rax), %r15d
14009e6bb:     	cmpb	$0x2, %r15b
14009e6bf:     	je	0x14009e79b <.text+0x9d79b>
14009e6c5:     	addq	%rsi, %rax
14009e6c8:     	cmpb	$0x3, 0x28(%rax)
14009e6cc:     	jne	0x14009e79b <.text+0x9d79b>
14009e6d2:     	movq	0x30(%rax), %r9
14009e6d6:     	movq	(%rax), %r12
14009e6d9:     	movq	0x8(%rax), %rdx
14009e6dd:     	movq	%rdx, 0x170(%rbp)
14009e6e4:     	movl	0x10(%rax), %r13d
14009e6e8:     	movl	0x14(%rax), %edi
14009e6eb:     	movzwl	0x18(%rax), %edx
14009e6ef:     	movw	%dx, 0x17e(%rbp)
14009e6f6:     	movzbl	0x1b(%rax), %edx
14009e6fa:     	movb	%dl, 0x17d(%rbp)
14009e700:     	movss	0x1c(%rax), %xmm6
14009e705:     	movzwl	0x1c(%rax), %eax
14009e709:     	movzwl	%ax, %edx
14009e70c:     	cmpq	$0x1, %r9
14009e710:     	ja	0x14009e765 <.text+0x9d765>
14009e712:     	cmpb	$0x1, 0x1968(%rcx,%r9)
14009e71b:     	jne	0x14009e765 <.text+0x9d765>
14009e71d:     	cmpb	$0x0, 0x196a(%rcx,%r9)
14009e726:     	jne	0x14009e765 <.text+0x9d765>
14009e728:     	movb	$0x0, 0x1968(%rcx,%r9)
14009e731:     	decq	0x1960(%rcx)
14009e738:     	movq	$0x0, 0x18e0(%rcx,%r9,8)
14009e744:     	leaq	(%r9,%r9,8), %r10
14009e748:     	leaq	(%r10,%r10,2), %r10
14009e74c:     	addq	%r9, %r10
14009e74f:     	movb	$0x2, 0x95a(%r8,%r10)
14009e758:     	leaq	(%r9,%r9,2), %r9
14009e75c:     	movb	$0x2, 0x91d(%r8,%r9,8)
14009e765:     	addl	$0x2, %edx
14009e768:     	movb	$0x1, %r9b
14009e76b:     	cmpl	%edx, 0x1e30(%rcx)
14009e771:     	jne	0x14009e781 <.text+0x9d781>
14009e773:     	movzbl	0x198a(%rcx), %r8d
14009e77b:     	cmpb	$0x2, %r8b
14009e77f:     	jne	0x14009e7b8 <.text+0x9d7b8>
14009e781:     	xorl	%r8d, %r8d
14009e784:     	cmpl	%edx, 0x1e34(%rcx)
14009e78a:     	movl	%edi, 0x178(%rbp)
14009e790:     	jne	0x14009e84c <.text+0x9d84c>
14009e796:     	jmp	0x14009e83a <.text+0x9d83a>
14009e79b:     	xorl	%eax, %eax
14009e79d:     	movaps	0x180(%rbp), %xmm6
14009e7a4:     	addq	$0x218, %rsp            # imm = 0x218
14009e7ab:     	popq	%rbx
14009e7ac:     	popq	%rdi
14009e7ad:     	popq	%rsi
14009e7ae:     	popq	%r12
14009e7b0:     	popq	%r13
14009e7b2:     	popq	%r14
14009e7b4:     	popq	%r15
14009e7b6:     	popq	%rbp
14009e7b7:     	retq
14009e7b8:     	cmpw	%ax, 0x198c(%rcx)
14009e7bf:     	sete	%r9b
14009e7c3:     	cmpl	%r13d, 0x1980(%rcx)
14009e7ca:     	sete	%r10b
14009e7ce:     	andb	%r9b, %r10b
14009e7d1:     	cmpl	%edi, 0x1984(%rcx)
14009e7d7:     	sete	%r9b
14009e7db:     	movzwl	0x17e(%rbp), %r11d
14009e7e3:     	cmpw	%r11w, 0x1988(%rcx)
14009e7eb:     	sete	%r11b
14009e7ef:     	andb	%r9b, %r11b
14009e7f2:     	andb	%r10b, %r11b
14009e7f5:     	cmpb	%r15b, %r8b
14009e7f8:     	sete	%r8b
14009e7fc:     	movq	0x1978(%rcx), %r9
14009e803:     	xorq	0x170(%rbp), %r9
14009e80a:     	movq	0x1970(%rcx), %r10
14009e811:     	xorq	%r12, %r10
14009e814:     	orq	%r9, %r10
14009e817:     	sete	%r9b
14009e81b:     	andb	%r8b, %r9b
14009e81e:     	andb	%r11b, %r9b
14009e821:     	movzbl	%r9b, %r8d
14009e825:     	movl	%r8d, %r9d
14009e828:     	xorb	$0x1, %r9b
14009e82c:     	cmpl	%edx, 0x1e34(%rcx)
14009e832:     	movl	%edi, 0x178(%rbp)
14009e838:     	jne	0x14009e84c <.text+0x9d84c>
14009e83a:     	movzbl	0x1aba(%rcx), %r10d
14009e842:     	cmpb	$0x2, %r10b
14009e846:     	jne	0x14009e8f6 <.text+0x9d8f6>
14009e84c:     	xorl	%r9d, %r9d
14009e84f:     	cmpl	%edx, 0x1e38(%rcx)
14009e855:     	jne	0x14009e993 <.text+0x9d993>
14009e85b:     	movzbl	0x1bea(%rcx), %r10d
14009e863:     	cmpb	$0x2, %r10b
14009e867:     	je	0x14009e993 <.text+0x9d993>
14009e86d:     	cmpb	%r15b, %r10b
14009e870:     	jne	0x14009e993 <.text+0x9d993>
14009e876:     	cmpw	%ax, 0x1bec(%rcx)
14009e87d:     	jne	0x14009e993 <.text+0x9d993>
14009e883:     	cmpl	%r13d, 0x1be0(%rcx)
14009e88a:     	jne	0x14009e993 <.text+0x9d993>
14009e890:     	cmpl	%edi, 0x1be4(%rcx)
14009e896:     	jne	0x14009e993 <.text+0x9d993>
14009e89c:     	movzwl	0x17e(%rbp), %r10d
14009e8a4:     	cmpw	%r10w, 0x1be8(%rcx)
14009e8ac:     	jne	0x14009e993 <.text+0x9d993>
14009e8b2:     	movq	0x1bd0(%rcx), %r10
14009e8b9:     	xorq	%r12, %r10
14009e8bc:     	movq	0x1bd8(%rcx), %r11
14009e8c3:     	xorq	0x170(%rbp), %r11
14009e8ca:     	orq	%r10, %r11
14009e8cd:     	jne	0x14009e993 <.text+0x9d993>
14009e8d3:     	movb	$0x1, %dil
14009e8d6:     	testq	%r8, %r8
14009e8d9:     	jne	0x14009ea16 <.text+0x9da16>
14009e8df:     	movl	$0x1, %r8d
14009e8e5:     	movl	$0x2, %r9d
14009e8eb:     	movl	0x178(%rbp), %edi
14009e8f1:     	jmp	0x14009e993 <.text+0x9d993>
14009e8f6:     	cmpw	%ax, 0x1abc(%rcx)
14009e8fd:     	setne	%r11b
14009e901:     	cmpl	%r13d, 0x1ab0(%rcx)
14009e908:     	setne	%bl
14009e90b:     	orb	%r11b, %bl
14009e90e:     	cmpl	%edi, 0x1ab4(%rcx)
14009e914:     	setne	%r11b
14009e918:     	movzwl	0x17e(%rbp), %edi
14009e91f:     	cmpw	%di, 0x1ab8(%rcx)
14009e926:     	setne	%dil
14009e92a:     	orb	%r11b, %dil
14009e92d:     	orb	%bl, %dil
14009e930:     	cmpb	%r15b, %r10b
14009e933:     	setne	%r11b
14009e937:     	movq	0x1aa8(%rcx), %r10
14009e93e:     	xorq	0x170(%rbp), %r10
14009e945:     	movq	0x1aa0(%rcx), %rbx
14009e94c:     	xorq	%r12, %rbx
14009e94f:     	orq	%r10, %rbx
14009e952:     	setne	%r10b
14009e956:     	orb	%r11b, %r10b
14009e959:     	orb	%dil, %r10b
14009e95c:     	orb	%r10b, %r9b
14009e95f:     	testb	%r10b, %r10b
14009e962:     	movl	$0x1, %r11d
14009e968:     	cmoveq	%r11, %r8
14009e96c:     	testb	$0x1, %r9b
14009e970:     	je	0x14009ea10 <.text+0x9da10>
14009e976:     	notb	%r10b
14009e979:     	movzbl	%r10b, %r9d
14009e97d:     	andl	$0x1, %r9d
14009e981:     	movl	0x178(%rbp), %edi
14009e987:     	cmpl	%edx, 0x1e38(%rcx)
14009e98d:     	je	0x14009e85b <.text+0x9d85b>
14009e993:     	cmpl	%edx, 0x1e3c(%rcx)
14009e999:     	jne	0x14009e9a7 <.text+0x9d9a7>
14009e99b:     	movzbl	0x1d1a(%rcx), %edx
14009e9a2:     	cmpb	$0x2, %dl
14009e9a5:     	jne	0x14009e9b3 <.text+0x9d9b3>
14009e9a7:     	xorl	%edi, %edi
14009e9a9:     	testq	%r8, %r8
14009e9ac:     	jne	0x14009ea16 <.text+0x9da16>
14009e9ae:     	jmp	0x14009ea40 <.text+0x9da40>
14009e9b3:     	cmpb	%r15b, %dl
14009e9b6:     	jne	0x14009e9a7 <.text+0x9d9a7>
14009e9b8:     	cmpw	%ax, 0x1d1c(%rcx)
14009e9bf:     	jne	0x14009e9a7 <.text+0x9d9a7>
14009e9c1:     	cmpl	%r13d, 0x1d10(%rcx)
14009e9c8:     	jne	0x14009e9a7 <.text+0x9d9a7>
14009e9ca:     	cmpl	%edi, 0x1d14(%rcx)
14009e9d0:     	jne	0x14009e9a7 <.text+0x9d9a7>
14009e9d2:     	movzwl	0x17e(%rbp), %edx
14009e9d9:     	cmpw	%dx, 0x1d18(%rcx)
14009e9e0:     	jne	0x14009e9a7 <.text+0x9d9a7>
14009e9e2:     	movq	0x1d00(%rcx), %rdx
14009e9e9:     	xorq	%r12, %rdx
14009e9ec:     	movq	0x1d08(%rcx), %r10
14009e9f3:     	xorq	0x170(%rbp), %r10
14009e9fa:     	orq	%rdx, %r10
14009e9fd:     	jne	0x14009e9a7 <.text+0x9d9a7>
14009e9ff:     	testq	%r8, %r8
14009ea02:     	movl	$0x3, %edx
14009ea07:     	cmoveq	%rdx, %r9
14009ea0b:     	movl	%r8d, %edi
14009ea0e:     	jmp	0x14009ea16 <.text+0x9da16>
14009ea10:     	movb	$0x1, %dil
14009ea13:     	xorl	%r9d, %r9d
14009ea16:     	cmpl	$0x0, 0x1e30(%rcx,%r9,4)
14009ea1f:     	je	0x14009ea40 <.text+0x9da40>
14009ea21:     	movl	$0x0, 0x1e30(%rcx,%r9,4)
14009ea2d:     	decq	0x1e48(%rcx)
14009ea34:     	imulq	$0x130, %r9, %rdx       # imm = 0x130
14009ea3b:     	movb	$0x2, 0x1a(%rsi,%rdx)
14009ea40:     	movl	%r13d, 0x16c(%rbp)
14009ea47:     	movq	%r12, %r13
14009ea4a:     	xorps	%xmm0, %xmm0
14009ea4d:     	movaps	%xmm0, 0x150(%rbp)
14009ea54:     	movb	$0x0, 0x132(%rbp)
14009ea5b:     	movw	%ax, 0x130(%rbp)
14009ea62:     	leaq	0x133(%rbp), %rdx
14009ea69:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009ea72:     	movq	$0x0, 0x133(%rbp)
14009ea7d:     	movq	$0x8, 0x110(%rbp)
14009ea88:     	movq	$0x0, 0x118(%rbp)
14009ea93:     	movq	$0x1, 0x120(%rbp)
14009ea9e:     	movq	$0x0, 0x128(%rbp)
14009eaa9:     	movq	%rdx, 0x30(%rsp)
14009eaae:     	movw	%ax, 0x28(%rsp)
14009eab3:     	movq	$0x0, 0x58(%rsp)
14009eabc:     	movq	$0x1, 0x50(%rsp)
14009eac5:     	movq	$0x8, 0x48(%rsp)
14009eace:     	movq	$0x8, 0x40(%rsp)
14009ead7:     	movq	$0x0, 0x38(%rsp)
14009eae0:     	movb	$0x0, 0x20(%rsp)
14009eae5:     	leaq	0x140(%rbp), %rax
14009eaec:     	leaq	0x150(%rbp), %rdx
14009eaf3:     	movl	$0x10, %r8d
14009eaf9:     	movq	%rcx, %r12
14009eafc:     	movq	%rax, %rcx
14009eaff:     	movb	$0x2, %r9b
14009eb02:     	callq	0x140005590 <.text+0x4590>
14009eb07:     	cmpb	$0x0, 0x140(%rbp)
14009eb0e:     	jne	0x14009eca4 <.text+0x9dca4>
14009eb14:     	testb	%dil, %dil
14009eb17:     	jne	0x14009eca4 <.text+0x9dca4>
14009eb1d:     	movq	0x148(%rbp), %rbx
14009eb24:     	cmpq	$0x10, %rbx
14009eb28:     	ja	0x14009eca4 <.text+0x9dca4>
14009eb2e:     	movq	%r12, %rax
14009eb31:     	cmpq	$0x4, 0x1e48(%r12)
14009eb3a:     	je	0x14009eca4 <.text+0x9dca4>
14009eb40:     	movq	0x1e40(%rax), %rdi
14009eb47:     	cmpq	$0x3, %rdi
14009eb4b:     	ja	0x14009ecbc <.text+0x9dcbc>
14009eb51:     	cmpl	$0x0, 0x1e30(%rax,%rdi,4)
14009eb59:     	je	0x14009ebd3 <.text+0x9dbd3>
14009eb5b:     	leaq	(,%rdi,4), %rdx
14009eb63:     	xorl	%ecx, %ecx
14009eb65:     	cmpl	$0x0, 0x1e30(%rax,%rdx)
14009eb6d:     	je	0x14009ebc6 <.text+0x9dbc6>
14009eb6f:     	addq	$0x4, %rdx
14009eb73:     	decq	%rcx
14009eb76:     	cmpq	$0x10, %rdx
14009eb7a:     	jne	0x14009eb65 <.text+0x9db65>
14009eb7c:     	testq	%rdi, %rdi
14009eb7f:     	je	0x14009eca4 <.text+0x9dca4>
14009eb85:     	cmpl	$0x0, 0x1e30(%rax)
14009eb8c:     	je	0x14009ecab <.text+0x9dcab>
14009eb92:     	cmpq	$0x1, %rdi
14009eb96:     	je	0x14009eca4 <.text+0x9dca4>
14009eb9c:     	cmpl	$0x0, 0x1e34(%rax)
14009eba3:     	je	0x14009ecb2 <.text+0x9dcb2>
14009eba9:     	cmpq	$0x2, %rdi
14009ebad:     	je	0x14009eca4 <.text+0x9dca4>
14009ebb3:     	movl	$0x2, %edi
14009ebb8:     	cmpl	$0x0, 0x1e38(%rax)
14009ebbf:     	je	0x14009ebc9 <.text+0x9dbc9>
14009ebc1:     	jmp	0x14009eca4 <.text+0x9dca4>
14009ebc6:     	subq	%rcx, %rdi
14009ebc9:     	cmpq	$0x4, %rdi
14009ebcd:     	jae	0x14009ecd2 <.text+0x9dcd2>
14009ebd3:     	movl	$0x1, 0x1e30(%rax,%rdi,4)
14009ebde:     	incq	0x1e48(%rax)
14009ebe5:     	leaq	0x1(%rdi), %rcx
14009ebe9:     	xorl	%edx, %edx
14009ebeb:     	cmpq	$0x4, %rcx
14009ebef:     	cmovneq	%rcx, %rdx
14009ebf3:     	movq	%rdx, 0x1e40(%rax)
14009ebfa:     	movq	0x170(%rbp), %rcx
14009ec01:     	movq	%rcx, -0x18(%rbp)
14009ec05:     	movq	%r13, -0x20(%rbp)
14009ec09:     	movl	0x16c(%rbp), %ecx
14009ec0f:     	movl	%ecx, -0x10(%rbp)
14009ec12:     	movl	0x178(%rbp), %ecx
14009ec18:     	movl	%ecx, -0xc(%rbp)
14009ec1b:     	movzwl	0x17e(%rbp), %ecx
14009ec22:     	movw	%cx, -0x8(%rbp)
14009ec26:     	movb	%r15b, -0x6(%rbp)
14009ec2a:     	movzbl	0x17d(%rbp), %ecx
14009ec31:     	movb	%cl, -0x5(%rbp)
14009ec34:     	movss	%xmm6, -0x4(%rbp)
14009ec39:     	movq	%r14, (%rbp)
14009ec3d:     	testq	%rbx, %rbx
14009ec40:     	je	0x14009ec7c <.text+0x9dc7c>
14009ec42:     	movb	$0x1, 0x8(%rbp)
14009ec46:     	movb	%bl, 0x9(%rbp)
14009ec49:     	leaq	0xa(%rbp), %r14
14009ec4d:     	movl	$0x80, %r8d
14009ec53:     	subq	%rbx, %r8
14009ec56:     	leaq	(%rbx,%rbp), %rcx
14009ec5a:     	addq	$0xa, %rcx
14009ec5e:     	xorl	%edx, %edx
14009ec60:     	callq	0x140251722 <.text+0x250722>
14009ec65:     	leaq	0x150(%rbp), %rdx
14009ec6c:     	movq	%r14, %rcx
14009ec6f:     	movq	%rbx, %r8
14009ec72:     	callq	0x140251710 <.text+0x250710>
14009ec77:     	movq	%r12, %rax
14009ec7a:     	jmp	0x14009ec80 <.text+0x9dc80>
14009ec7c:     	movb	$0x0, 0x8(%rbp)
14009ec80:     	movzwl	-0x4(%rbp), %ecx
14009ec84:     	addl	$0x2, %ecx
14009ec87:     	movl	%ecx, 0x1e30(%rax,%rdi,4)
14009ec8e:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009ec95:     	addq	%rax, %rsi
14009ec98:     	leaq	-0x20(%rbp), %rcx
14009ec9c:     	movq	%rsi, %rdx
14009ec9f:     	callq	0x14000b1c0 <.text+0xa1c0>
14009eca4:     	movb	$0x1, %al
14009eca6:     	jmp	0x14009e79d <.text+0x9d79d>
14009ecab:     	xorl	%edi, %edi
14009ecad:     	jmp	0x14009ebc9 <.text+0x9dbc9>
14009ecb2:     	movl	$0x1, %edi
14009ecb7:     	jmp	0x14009ebc9 <.text+0x9dbc9>
14009ecbc:     	leaq	0x1ce0ed(%rip), %r8     # 0x14026cdb0
14009ecc3:     	movl	$0x4, %edx
14009ecc8:     	movq	%rdi, %rcx
14009eccb:     	callq	0x140251f93 <.text+0x250f93>
14009ecd0:     	ud2
14009ecd2:     	leaq	0x1ce0ef(%rip), %r8     # 0x14026cdc8
14009ecd9:     	movl	$0x4, %edx
14009ecde:     	movq	%rdi, %rcx
14009ece1:     	callq	0x140251f93 <.text+0x250f93>
14009ece6:     	ud2

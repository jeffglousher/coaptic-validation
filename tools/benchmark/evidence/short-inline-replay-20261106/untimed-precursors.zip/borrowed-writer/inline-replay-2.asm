
D:\CoapticCurrent\short-inline-replay-20261106\borrowed-writer\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14000b230:     	pushq	%rbp
14000b231:     	movq	%rsp, %rbp
14000b234:     	cmpb	$0x1, 0x28(%rdx)
14000b238:     	jne	0x14000b246 <.text+0xa246>
14000b23a:     	movl	$0x130, %r8d            # imm = 0x130
14000b240:     	popq	%rbp
14000b241:     	jmp	0x140251710 <.text+0x250710>
14000b246:     	popq	%rbp
14000b247:     	retq


D:\CoapticCurrent\short-inline-replay-20261106\borrowed-writer\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009f9b0:     	pushq	%rbp
14009f9b1:     	pushq	%r15
14009f9b3:     	pushq	%r14
14009f9b5:     	pushq	%r13
14009f9b7:     	pushq	%r12
14009f9b9:     	pushq	%rsi
14009f9ba:     	pushq	%rdi
14009f9bb:     	pushq	%rbx
14009f9bc:     	subq	$0x218, %rsp            # imm = 0x218
14009f9c3:     	leaq	0x80(%rsp), %rbp
14009f9cb:     	movaps	%xmm6, 0x180(%rbp)
14009f9d2:     	movq	0xe8(%rcx), %rax
14009f9d9:     	testq	%rax, %rax
14009f9dc:     	je	0x14009fce5 <.text+0x9ece5>
14009f9e2:     	leaq	0xc0(%rcx), %rsi
14009f9e9:     	movq	0xe0(%rcx), %r9
14009f9f0:     	movq	0xc8(%rcx), %r10
14009f9f7:     	movq	0xd0(%rcx), %r11
14009f9fe:     	addq	$0x28, %r10
14009fa02:     	xorl	%r8d, %r8d
14009fa05:     	movl	$0x1, %edi
14009fa0a:     	movq	%rax, %r15
14009fa0d:     	xorl	%r14d, %r14d
14009fa10:     	imulq	$0x130, %r14, %r12      # imm = 0x130
14009fa17:     	addq	%r10, %r12
14009fa1a:     	jmp	0x14009fa2f <.text+0x9ea2f>
14009fa1c:     	nopl	(%rax)
14009fa20:     	incq	%r14
14009fa23:     	addq	$0x130, %r12            # imm = 0x130
14009fa2a:     	cmpq	%r14, %r15
14009fa2d:     	je	0x14009fa8b <.text+0x9ea8b>
14009fa2f:     	cmpq	%rax, %r14
14009fa32:     	jae	0x14009fa20 <.text+0x9ea20>
14009fa34:     	cmpl	$0x0, (%r9,%r14,4)
14009fa39:     	je	0x14009fa20 <.text+0x9ea20>
14009fa3b:     	cmpq	%r11, %r14
14009fa3e:     	jae	0x14009fa20 <.text+0x9ea20>
14009fa40:     	cmpb	$0x2, -0xe(%r12)
14009fa46:     	je	0x14009fa20 <.text+0x9ea20>
14009fa48:     	movq	-0x8(%r12), %r15
14009fa4d:     	cmpb	$0x3, (%r12)
14009fa52:     	setne	%r12b
14009fa56:     	testq	%r15, %r15
14009fa59:     	sete	%r13b
14009fa5d:     	orb	%r12b, %r13b
14009fa60:     	cmpq	%rbx, %r15
14009fa63:     	setae	%r12b
14009fa67:     	andb	%r8b, %r12b
14009fa6a:     	testb	%r13b, %r13b
14009fa6d:     	cmoveq	%rdi, %r8
14009fa71:     	orb	%r13b, %r12b
14009fa74:     	cmoveq	%r14, %rdx
14009fa78:     	cmoveq	%r15, %rbx
14009fa7c:     	incq	%r14
14009fa7f:     	cmpq	%rax, %r14
14009fa82:     	movq	%rax, %r15
14009fa85:     	cmovaq	%r14, %r15
14009fa89:     	jb	0x14009fa10 <.text+0x9ea10>
14009fa8b:     	testb	$0x1, %r8b
14009fa8f:     	je	0x14009fce5 <.text+0x9ece5>
14009fa95:     	cmpq	%rax, %rdx
14009fa98:     	jae	0x14009fce5 <.text+0x9ece5>
14009fa9e:     	movq	0xe0(%rcx), %r8
14009faa5:     	xorl	%eax, %eax
14009faa7:     	cmpl	$0x0, (%r8,%rdx,4)
14009faac:     	je	0x14009fce7 <.text+0x9ece7>
14009fab2:     	cmpq	0xd0(%rcx), %rdx
14009fab9:     	jae	0x14009fce7 <.text+0x9ece7>
14009fabf:     	movq	0xc8(%rcx), %r9
14009fac6:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009facd:     	movzbl	0x1a(%r9,%rax), %r14d
14009fad3:     	cmpb	$0x2, %r14b
14009fad7:     	je	0x14009fce5 <.text+0x9ece5>
14009fadd:     	addq	%rax, %r9
14009fae0:     	cmpb	$0x3, 0x28(%r9)
14009fae5:     	jne	0x14009fce5 <.text+0x9ece5>
14009faeb:     	movzbl	0x1b(%r9), %r15d
14009faf0:     	movss	0x1c(%r9), %xmm6
14009faf6:     	movzwl	0x1c(%r9), %eax
14009fafb:     	movq	0x30(%r9), %r10
14009faff:     	movups	(%r9), %xmm0
14009fb03:     	movups	0xa(%r9), %xmm1
14009fb08:     	movups	%xmm1, 0x11a(%rbp)
14009fb0f:     	movaps	%xmm0, 0x110(%rbp)
14009fb16:     	cmpq	0x88(%rcx), %r10
14009fb1d:     	jae	0x14009fb73 <.text+0x9eb73>
14009fb1f:     	movq	0x80(%rcx), %r11
14009fb26:     	cmpb	$0x1, (%r11,%r10)
14009fb2b:     	jne	0x14009fb73 <.text+0x9eb73>
14009fb2d:     	cmpq	0xa0(%rcx), %r10
14009fb34:     	jae	0x14009fb44 <.text+0x9eb44>
14009fb36:     	movq	0x98(%rcx), %rdi
14009fb3d:     	cmpb	$0x0, (%rdi,%r10)
14009fb42:     	jne	0x14009fb73 <.text+0x9eb73>
14009fb44:     	movb	$0x0, (%r11,%r10)
14009fb49:     	decq	0xb0(%rcx)
14009fb50:     	cmpq	0x70(%rcx), %r10
14009fb54:     	jae	0x14009fb73 <.text+0x9eb73>
14009fb56:     	movq	0x68(%rcx), %r11
14009fb5a:     	imulq	$0x58, %r10, %r10
14009fb5e:     	movq	$0x0, 0x30(%r11,%r10)
14009fb67:     	movb	$0x2, 0x52(%r11,%r10)
14009fb6d:     	movb	$0x2, 0x25(%r11,%r10)
14009fb73:     	cmpl	$0x0, (%r8,%rdx,4)
14009fb78:     	je	0x14009fb8e <.text+0x9eb8e>
14009fb7a:     	movl	$0x0, (%r8,%rdx,4)
14009fb82:     	decq	0xf8(%rcx)
14009fb89:     	movb	$0x2, 0x1a(%r9)
14009fb8e:     	movq	%rcx, %r12
14009fb91:     	xorps	%xmm0, %xmm0
14009fb94:     	movaps	%xmm0, 0x170(%rbp)
14009fb9b:     	movb	$0x0, 0x152(%rbp)
14009fba2:     	movw	%ax, 0x150(%rbp)
14009fba9:     	leaq	0x153(%rbp), %rcx
14009fbb0:     	movw	$0x200, 0x15b(%rbp)     # imm = 0x200
14009fbb9:     	movq	$0x0, 0x153(%rbp)
14009fbc4:     	movq	$0x8, 0x130(%rbp)
14009fbcf:     	movq	$0x0, 0x138(%rbp)
14009fbda:     	movq	$0x1, 0x140(%rbp)
14009fbe5:     	movq	$0x0, 0x148(%rbp)
14009fbf0:     	movq	%rcx, 0x30(%rsp)
14009fbf5:     	movw	%ax, 0x28(%rsp)
14009fbfa:     	movq	$0x0, 0x58(%rsp)
14009fc03:     	movq	$0x1, 0x50(%rsp)
14009fc0c:     	movq	$0x8, 0x48(%rsp)
14009fc15:     	movq	$0x8, 0x40(%rsp)
14009fc1e:     	movq	$0x0, 0x38(%rsp)
14009fc27:     	movb	$0x0, 0x20(%rsp)
14009fc2c:     	leaq	0x160(%rbp), %rcx
14009fc33:     	leaq	0x170(%rbp), %rdx
14009fc3a:     	movl	$0x10, %r8d
14009fc40:     	movb	$0x2, %r9b
14009fc43:     	callq	0x140005590 <.text+0x4590>
14009fc48:     	movq	0x168(%rbp), %rdi
14009fc4f:     	cmpq	$0x11, %rdi
14009fc53:     	setae	%al
14009fc56:     	orb	0x160(%rbp), %al
14009fc5c:     	jne	0x14009fd12 <.text+0x9ed12>
14009fc62:     	movq	%r12, %rcx
14009fc65:     	addq	$0xd8, %rcx
14009fc6c:     	callq	0x1402196b0 <.text+0x2186b0>
14009fc71:     	cmpq	$0x1, %rax
14009fc75:     	jne	0x14009fd12 <.text+0x9ed12>
14009fc7b:     	movups	0x11a(%rbp), %xmm0
14009fc82:     	movups	%xmm0, -0x16(%rbp)
14009fc86:     	movaps	0x110(%rbp), %xmm0
14009fc8d:     	movaps	%xmm0, -0x20(%rbp)
14009fc91:     	movb	%r14b, -0x6(%rbp)
14009fc95:     	movb	%r15b, -0x5(%rbp)
14009fc99:     	movss	%xmm6, -0x4(%rbp)
14009fc9e:     	movq	%rbx, (%rbp)
14009fca2:     	testq	%rdi, %rdi
14009fca5:     	je	0x14009fd02 <.text+0x9ed02>
14009fca7:     	movb	$0x1, 0x8(%rbp)
14009fcab:     	movb	%dil, 0x9(%rbp)
14009fcaf:     	leaq	0xa(%rbp), %rbx
14009fcb3:     	movl	$0x80, %r8d
14009fcb9:     	subq	%rdi, %r8
14009fcbc:     	leaq	(%rdi,%rbp), %rcx
14009fcc0:     	addq	$0xa, %rcx
14009fcc4:     	movq	%rdx, %r14
14009fcc7:     	xorl	%edx, %edx
14009fcc9:     	callq	0x140251722 <.text+0x250722>
14009fcce:     	leaq	0x170(%rbp), %rdx
14009fcd5:     	movq	%rbx, %rcx
14009fcd8:     	movq	%rdi, %r8
14009fcdb:     	callq	0x140251710 <.text+0x250710>
14009fce0:     	movq	%r14, %rdx
14009fce3:     	jmp	0x14009fd06 <.text+0x9ed06>
14009fce5:     	xorl	%eax, %eax
14009fce7:     	movaps	0x180(%rbp), %xmm6
14009fcee:     	addq	$0x218, %rsp            # imm = 0x218
14009fcf5:     	popq	%rbx
14009fcf6:     	popq	%rdi
14009fcf7:     	popq	%rsi
14009fcf8:     	popq	%r12
14009fcfa:     	popq	%r13
14009fcfc:     	popq	%r14
14009fcfe:     	popq	%r15
14009fd00:     	popq	%rbp
14009fd01:     	retq
14009fd02:     	movb	$0x0, 0x8(%rbp)
14009fd06:     	leaq	-0x20(%rbp), %r8
14009fd0a:     	movq	%rsi, %rcx
14009fd0d:     	callq	0x14000b630 <.text+0xa630>
14009fd12:     	movb	$0x1, %al
14009fd14:     	jmp	0x14009fce7 <.text+0x9ece7>

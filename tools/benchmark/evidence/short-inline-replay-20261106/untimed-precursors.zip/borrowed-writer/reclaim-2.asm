
D:\CoapticCurrent\short-inline-replay-20261106\borrowed-writer\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009ecf0:     	pushq	%rbp
14009ecf1:     	pushq	%r15
14009ecf3:     	pushq	%r14
14009ecf5:     	pushq	%r13
14009ecf7:     	pushq	%r12
14009ecf9:     	pushq	%rsi
14009ecfa:     	pushq	%rdi
14009ecfb:     	pushq	%rbx
14009ecfc:     	subq	$0x218, %rsp            # imm = 0x218
14009ed03:     	leaq	0x80(%rsp), %rbp
14009ed0b:     	movaps	%xmm6, 0x180(%rbp)
14009ed12:     	leaq	0x3580(%rcx), %r8
14009ed19:     	leaq	0x3f10(%rcx), %rsi
14009ed20:     	leaq	0x3f38(%rcx), %rax
14009ed27:     	xorl	%r10d, %r10d
14009ed2a:     	movl	$0x1, %r11d
14009ed30:     	xorl	%r9d, %r9d
14009ed33:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009ed3a:     	addq	%rax, %rdi
14009ed3d:     	jmp	0x14009ed50 <.text+0x9dd50>
14009ed3f:     	nop
14009ed40:     	incq	%r10
14009ed43:     	addq	$0x130, %rdi            # imm = 0x130
14009ed4a:     	cmpq	$0x4, %r10
14009ed4e:     	je	0x14009ed9a <.text+0x9dd9a>
14009ed50:     	cmpl	$0x0, 0x43d0(%rcx,%r10,4)
14009ed59:     	je	0x14009ed40 <.text+0x9dd40>
14009ed5b:     	cmpb	$0x2, -0xe(%rdi)
14009ed5f:     	je	0x14009ed40 <.text+0x9dd40>
14009ed61:     	cmpb	$0x3, (%rdi)
14009ed64:     	movq	-0x8(%rdi), %rdi
14009ed68:     	setne	%bl
14009ed6b:     	testq	%rdi, %rdi
14009ed6e:     	sete	%r15b
14009ed72:     	orb	%bl, %r15b
14009ed75:     	cmpq	%r14, %rdi
14009ed78:     	setae	%bl
14009ed7b:     	andb	%r9b, %bl
14009ed7e:     	testb	%r15b, %r15b
14009ed81:     	cmoveq	%r11, %r9
14009ed85:     	orb	%r15b, %bl
14009ed88:     	cmoveq	%r10, %rdx
14009ed8c:     	cmoveq	%rdi, %r14
14009ed90:     	cmpq	$0x3, %r10
14009ed94:     	leaq	0x1(%r10), %r10
14009ed98:     	jb	0x14009ed33 <.text+0x9dd33>
14009ed9a:     	xorl	%eax, %eax
14009ed9c:     	cmpq	$0x1, %r9
14009eda0:     	jne	0x14009eead <.text+0x9dead>
14009eda6:     	cmpq	$0x4, %rdx
14009edaa:     	jae	0x14009eead <.text+0x9dead>
14009edb0:     	cmpl	$0x0, 0x43d0(%rcx,%rdx,4)
14009edb8:     	je	0x14009eeab <.text+0x9deab>
14009edbe:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009edc5:     	movzbl	0x1a(%rsi,%rax), %r15d
14009edcb:     	cmpb	$0x2, %r15b
14009edcf:     	je	0x14009eeab <.text+0x9deab>
14009edd5:     	addq	%rsi, %rax
14009edd8:     	cmpb	$0x3, 0x28(%rax)
14009eddc:     	jne	0x14009eeab <.text+0x9deab>
14009ede2:     	movq	0x30(%rax), %r9
14009ede6:     	movq	(%rax), %r12
14009ede9:     	movq	0x8(%rax), %rdx
14009eded:     	movq	%rdx, 0x170(%rbp)
14009edf4:     	movl	0x10(%rax), %r13d
14009edf8:     	movl	0x14(%rax), %edi
14009edfb:     	movzwl	0x18(%rax), %edx
14009edff:     	movw	%dx, 0x17e(%rbp)
14009ee06:     	movzbl	0x1b(%rax), %edx
14009ee0a:     	movb	%dl, 0x17d(%rbp)
14009ee10:     	movss	0x1c(%rax), %xmm6
14009ee15:     	movzwl	0x1c(%rax), %eax
14009ee19:     	movzwl	%ax, %edx
14009ee1c:     	cmpq	$0x1, %r9
14009ee20:     	ja	0x14009ee75 <.text+0x9de75>
14009ee22:     	cmpb	$0x1, 0x3f08(%rcx,%r9)
14009ee2b:     	jne	0x14009ee75 <.text+0x9de75>
14009ee2d:     	cmpb	$0x0, 0x3f0a(%rcx,%r9)
14009ee36:     	jne	0x14009ee75 <.text+0x9de75>
14009ee38:     	movb	$0x0, 0x3f08(%rcx,%r9)
14009ee41:     	decq	0x3f00(%rcx)
14009ee48:     	movq	$0x0, 0x3e80(%rcx,%r9,8)
14009ee54:     	leaq	(%r9,%r9,8), %r10
14009ee58:     	leaq	(%r10,%r10,2), %r10
14009ee5c:     	addq	%r9, %r10
14009ee5f:     	movb	$0x2, 0x95a(%r8,%r10)
14009ee68:     	leaq	(%r9,%r9,2), %r9
14009ee6c:     	movb	$0x2, 0x91d(%r8,%r9,8)
14009ee75:     	addl	$0x2, %edx
14009ee78:     	movb	$0x1, %r9b
14009ee7b:     	cmpl	%edx, 0x43d0(%rcx)
14009ee81:     	jne	0x14009ee91 <.text+0x9de91>
14009ee83:     	movzbl	0x3f2a(%rcx), %r8d
14009ee8b:     	cmpb	$0x2, %r8b
14009ee8f:     	jne	0x14009eec8 <.text+0x9dec8>
14009ee91:     	xorl	%r8d, %r8d
14009ee94:     	cmpl	%edx, 0x43d4(%rcx)
14009ee9a:     	movl	%edi, 0x178(%rbp)
14009eea0:     	jne	0x14009ef5c <.text+0x9df5c>
14009eea6:     	jmp	0x14009ef4a <.text+0x9df4a>
14009eeab:     	xorl	%eax, %eax
14009eead:     	movaps	0x180(%rbp), %xmm6
14009eeb4:     	addq	$0x218, %rsp            # imm = 0x218
14009eebb:     	popq	%rbx
14009eebc:     	popq	%rdi
14009eebd:     	popq	%rsi
14009eebe:     	popq	%r12
14009eec0:     	popq	%r13
14009eec2:     	popq	%r14
14009eec4:     	popq	%r15
14009eec6:     	popq	%rbp
14009eec7:     	retq
14009eec8:     	cmpw	%ax, 0x3f2c(%rcx)
14009eecf:     	sete	%r9b
14009eed3:     	cmpl	%r13d, 0x3f20(%rcx)
14009eeda:     	sete	%r10b
14009eede:     	andb	%r9b, %r10b
14009eee1:     	cmpl	%edi, 0x3f24(%rcx)
14009eee7:     	sete	%r9b
14009eeeb:     	movzwl	0x17e(%rbp), %r11d
14009eef3:     	cmpw	%r11w, 0x3f28(%rcx)
14009eefb:     	sete	%r11b
14009eeff:     	andb	%r9b, %r11b
14009ef02:     	andb	%r10b, %r11b
14009ef05:     	cmpb	%r15b, %r8b
14009ef08:     	sete	%r8b
14009ef0c:     	movq	0x3f18(%rcx), %r9
14009ef13:     	xorq	0x170(%rbp), %r9
14009ef1a:     	movq	0x3f10(%rcx), %r10
14009ef21:     	xorq	%r12, %r10
14009ef24:     	orq	%r9, %r10
14009ef27:     	sete	%r9b
14009ef2b:     	andb	%r8b, %r9b
14009ef2e:     	andb	%r11b, %r9b
14009ef31:     	movzbl	%r9b, %r8d
14009ef35:     	movl	%r8d, %r9d
14009ef38:     	xorb	$0x1, %r9b
14009ef3c:     	cmpl	%edx, 0x43d4(%rcx)
14009ef42:     	movl	%edi, 0x178(%rbp)
14009ef48:     	jne	0x14009ef5c <.text+0x9df5c>
14009ef4a:     	movzbl	0x405a(%rcx), %r10d
14009ef52:     	cmpb	$0x2, %r10b
14009ef56:     	jne	0x14009f006 <.text+0x9e006>
14009ef5c:     	xorl	%r9d, %r9d
14009ef5f:     	cmpl	%edx, 0x43d8(%rcx)
14009ef65:     	jne	0x14009f0a3 <.text+0x9e0a3>
14009ef6b:     	movzbl	0x418a(%rcx), %r10d
14009ef73:     	cmpb	$0x2, %r10b
14009ef77:     	je	0x14009f0a3 <.text+0x9e0a3>
14009ef7d:     	cmpb	%r15b, %r10b
14009ef80:     	jne	0x14009f0a3 <.text+0x9e0a3>
14009ef86:     	cmpw	%ax, 0x418c(%rcx)
14009ef8d:     	jne	0x14009f0a3 <.text+0x9e0a3>
14009ef93:     	cmpl	%r13d, 0x4180(%rcx)
14009ef9a:     	jne	0x14009f0a3 <.text+0x9e0a3>
14009efa0:     	cmpl	%edi, 0x4184(%rcx)
14009efa6:     	jne	0x14009f0a3 <.text+0x9e0a3>
14009efac:     	movzwl	0x17e(%rbp), %r10d
14009efb4:     	cmpw	%r10w, 0x4188(%rcx)
14009efbc:     	jne	0x14009f0a3 <.text+0x9e0a3>
14009efc2:     	movq	0x4170(%rcx), %r10
14009efc9:     	xorq	%r12, %r10
14009efcc:     	movq	0x4178(%rcx), %r11
14009efd3:     	xorq	0x170(%rbp), %r11
14009efda:     	orq	%r10, %r11
14009efdd:     	jne	0x14009f0a3 <.text+0x9e0a3>
14009efe3:     	movb	$0x1, %dil
14009efe6:     	testq	%r8, %r8
14009efe9:     	jne	0x14009f126 <.text+0x9e126>
14009efef:     	movl	$0x1, %r8d
14009eff5:     	movl	$0x2, %r9d
14009effb:     	movl	0x178(%rbp), %edi
14009f001:     	jmp	0x14009f0a3 <.text+0x9e0a3>
14009f006:     	cmpw	%ax, 0x405c(%rcx)
14009f00d:     	setne	%r11b
14009f011:     	cmpl	%r13d, 0x4050(%rcx)
14009f018:     	setne	%bl
14009f01b:     	orb	%r11b, %bl
14009f01e:     	cmpl	%edi, 0x4054(%rcx)
14009f024:     	setne	%r11b
14009f028:     	movzwl	0x17e(%rbp), %edi
14009f02f:     	cmpw	%di, 0x4058(%rcx)
14009f036:     	setne	%dil
14009f03a:     	orb	%r11b, %dil
14009f03d:     	orb	%bl, %dil
14009f040:     	cmpb	%r15b, %r10b
14009f043:     	setne	%r11b
14009f047:     	movq	0x4048(%rcx), %r10
14009f04e:     	xorq	0x170(%rbp), %r10
14009f055:     	movq	0x4040(%rcx), %rbx
14009f05c:     	xorq	%r12, %rbx
14009f05f:     	orq	%r10, %rbx
14009f062:     	setne	%r10b
14009f066:     	orb	%r11b, %r10b
14009f069:     	orb	%dil, %r10b
14009f06c:     	orb	%r10b, %r9b
14009f06f:     	testb	%r10b, %r10b
14009f072:     	movl	$0x1, %r11d
14009f078:     	cmoveq	%r11, %r8
14009f07c:     	testb	$0x1, %r9b
14009f080:     	je	0x14009f120 <.text+0x9e120>
14009f086:     	notb	%r10b
14009f089:     	movzbl	%r10b, %r9d
14009f08d:     	andl	$0x1, %r9d
14009f091:     	movl	0x178(%rbp), %edi
14009f097:     	cmpl	%edx, 0x43d8(%rcx)
14009f09d:     	je	0x14009ef6b <.text+0x9df6b>
14009f0a3:     	cmpl	%edx, 0x43dc(%rcx)
14009f0a9:     	jne	0x14009f0b7 <.text+0x9e0b7>
14009f0ab:     	movzbl	0x42ba(%rcx), %edx
14009f0b2:     	cmpb	$0x2, %dl
14009f0b5:     	jne	0x14009f0c3 <.text+0x9e0c3>
14009f0b7:     	xorl	%edi, %edi
14009f0b9:     	testq	%r8, %r8
14009f0bc:     	jne	0x14009f126 <.text+0x9e126>
14009f0be:     	jmp	0x14009f150 <.text+0x9e150>
14009f0c3:     	cmpb	%r15b, %dl
14009f0c6:     	jne	0x14009f0b7 <.text+0x9e0b7>
14009f0c8:     	cmpw	%ax, 0x42bc(%rcx)
14009f0cf:     	jne	0x14009f0b7 <.text+0x9e0b7>
14009f0d1:     	cmpl	%r13d, 0x42b0(%rcx)
14009f0d8:     	jne	0x14009f0b7 <.text+0x9e0b7>
14009f0da:     	cmpl	%edi, 0x42b4(%rcx)
14009f0e0:     	jne	0x14009f0b7 <.text+0x9e0b7>
14009f0e2:     	movzwl	0x17e(%rbp), %edx
14009f0e9:     	cmpw	%dx, 0x42b8(%rcx)
14009f0f0:     	jne	0x14009f0b7 <.text+0x9e0b7>
14009f0f2:     	movq	0x42a0(%rcx), %rdx
14009f0f9:     	xorq	%r12, %rdx
14009f0fc:     	movq	0x42a8(%rcx), %r10
14009f103:     	xorq	0x170(%rbp), %r10
14009f10a:     	orq	%rdx, %r10
14009f10d:     	jne	0x14009f0b7 <.text+0x9e0b7>
14009f10f:     	testq	%r8, %r8
14009f112:     	movl	$0x3, %edx
14009f117:     	cmoveq	%rdx, %r9
14009f11b:     	movl	%r8d, %edi
14009f11e:     	jmp	0x14009f126 <.text+0x9e126>
14009f120:     	movb	$0x1, %dil
14009f123:     	xorl	%r9d, %r9d
14009f126:     	cmpl	$0x0, 0x43d0(%rcx,%r9,4)
14009f12f:     	je	0x14009f150 <.text+0x9e150>
14009f131:     	movl	$0x0, 0x43d0(%rcx,%r9,4)
14009f13d:     	decq	0x43e8(%rcx)
14009f144:     	imulq	$0x130, %r9, %rdx       # imm = 0x130
14009f14b:     	movb	$0x2, 0x1a(%rsi,%rdx)
14009f150:     	movl	%r13d, 0x16c(%rbp)
14009f157:     	movq	%r12, %r13
14009f15a:     	xorps	%xmm0, %xmm0
14009f15d:     	movaps	%xmm0, 0x150(%rbp)
14009f164:     	movb	$0x0, 0x132(%rbp)
14009f16b:     	movw	%ax, 0x130(%rbp)
14009f172:     	leaq	0x133(%rbp), %rdx
14009f179:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009f182:     	movq	$0x0, 0x133(%rbp)
14009f18d:     	movq	$0x8, 0x110(%rbp)
14009f198:     	movq	$0x0, 0x118(%rbp)
14009f1a3:     	movq	$0x1, 0x120(%rbp)
14009f1ae:     	movq	$0x0, 0x128(%rbp)
14009f1b9:     	movq	%rdx, 0x30(%rsp)
14009f1be:     	movw	%ax, 0x28(%rsp)
14009f1c3:     	movq	$0x0, 0x58(%rsp)
14009f1cc:     	movq	$0x1, 0x50(%rsp)
14009f1d5:     	movq	$0x8, 0x48(%rsp)
14009f1de:     	movq	$0x8, 0x40(%rsp)
14009f1e7:     	movq	$0x0, 0x38(%rsp)
14009f1f0:     	movb	$0x0, 0x20(%rsp)
14009f1f5:     	leaq	0x140(%rbp), %rax
14009f1fc:     	leaq	0x150(%rbp), %rdx
14009f203:     	movl	$0x10, %r8d
14009f209:     	movq	%rcx, %r12
14009f20c:     	movq	%rax, %rcx
14009f20f:     	movb	$0x2, %r9b
14009f212:     	callq	0x140005590 <.text+0x4590>
14009f217:     	cmpb	$0x0, 0x140(%rbp)
14009f21e:     	jne	0x14009f3b4 <.text+0x9e3b4>
14009f224:     	testb	%dil, %dil
14009f227:     	jne	0x14009f3b4 <.text+0x9e3b4>
14009f22d:     	movq	0x148(%rbp), %rbx
14009f234:     	cmpq	$0x10, %rbx
14009f238:     	ja	0x14009f3b4 <.text+0x9e3b4>
14009f23e:     	movq	%r12, %rax
14009f241:     	cmpq	$0x4, 0x43e8(%r12)
14009f24a:     	je	0x14009f3b4 <.text+0x9e3b4>
14009f250:     	movq	0x43e0(%rax), %rdi
14009f257:     	cmpq	$0x3, %rdi
14009f25b:     	ja	0x14009f3cc <.text+0x9e3cc>
14009f261:     	cmpl	$0x0, 0x43d0(%rax,%rdi,4)
14009f269:     	je	0x14009f2e3 <.text+0x9e2e3>
14009f26b:     	leaq	(,%rdi,4), %rdx
14009f273:     	xorl	%ecx, %ecx
14009f275:     	cmpl	$0x0, 0x43d0(%rax,%rdx)
14009f27d:     	je	0x14009f2d6 <.text+0x9e2d6>
14009f27f:     	addq	$0x4, %rdx
14009f283:     	decq	%rcx
14009f286:     	cmpq	$0x10, %rdx
14009f28a:     	jne	0x14009f275 <.text+0x9e275>
14009f28c:     	testq	%rdi, %rdi
14009f28f:     	je	0x14009f3b4 <.text+0x9e3b4>
14009f295:     	cmpl	$0x0, 0x43d0(%rax)
14009f29c:     	je	0x14009f3bb <.text+0x9e3bb>
14009f2a2:     	cmpq	$0x1, %rdi
14009f2a6:     	je	0x14009f3b4 <.text+0x9e3b4>
14009f2ac:     	cmpl	$0x0, 0x43d4(%rax)
14009f2b3:     	je	0x14009f3c2 <.text+0x9e3c2>
14009f2b9:     	cmpq	$0x2, %rdi
14009f2bd:     	je	0x14009f3b4 <.text+0x9e3b4>
14009f2c3:     	movl	$0x2, %edi
14009f2c8:     	cmpl	$0x0, 0x43d8(%rax)
14009f2cf:     	je	0x14009f2d9 <.text+0x9e2d9>
14009f2d1:     	jmp	0x14009f3b4 <.text+0x9e3b4>
14009f2d6:     	subq	%rcx, %rdi
14009f2d9:     	cmpq	$0x4, %rdi
14009f2dd:     	jae	0x14009f3e2 <.text+0x9e3e2>
14009f2e3:     	movl	$0x1, 0x43d0(%rax,%rdi,4)
14009f2ee:     	incq	0x43e8(%rax)
14009f2f5:     	leaq	0x1(%rdi), %rcx
14009f2f9:     	xorl	%edx, %edx
14009f2fb:     	cmpq	$0x4, %rcx
14009f2ff:     	cmovneq	%rcx, %rdx
14009f303:     	movq	%rdx, 0x43e0(%rax)
14009f30a:     	movq	0x170(%rbp), %rcx
14009f311:     	movq	%rcx, -0x18(%rbp)
14009f315:     	movq	%r13, -0x20(%rbp)
14009f319:     	movl	0x16c(%rbp), %ecx
14009f31f:     	movl	%ecx, -0x10(%rbp)
14009f322:     	movl	0x178(%rbp), %ecx
14009f328:     	movl	%ecx, -0xc(%rbp)
14009f32b:     	movzwl	0x17e(%rbp), %ecx
14009f332:     	movw	%cx, -0x8(%rbp)
14009f336:     	movb	%r15b, -0x6(%rbp)
14009f33a:     	movzbl	0x17d(%rbp), %ecx
14009f341:     	movb	%cl, -0x5(%rbp)
14009f344:     	movss	%xmm6, -0x4(%rbp)
14009f349:     	movq	%r14, (%rbp)
14009f34d:     	testq	%rbx, %rbx
14009f350:     	je	0x14009f38c <.text+0x9e38c>
14009f352:     	movb	$0x1, 0x8(%rbp)
14009f356:     	movb	%bl, 0x9(%rbp)
14009f359:     	leaq	0xa(%rbp), %r14
14009f35d:     	movl	$0x80, %r8d
14009f363:     	subq	%rbx, %r8
14009f366:     	leaq	(%rbx,%rbp), %rcx
14009f36a:     	addq	$0xa, %rcx
14009f36e:     	xorl	%edx, %edx
14009f370:     	callq	0x140251722 <.text+0x250722>
14009f375:     	leaq	0x150(%rbp), %rdx
14009f37c:     	movq	%r14, %rcx
14009f37f:     	movq	%rbx, %r8
14009f382:     	callq	0x140251710 <.text+0x250710>
14009f387:     	movq	%r12, %rax
14009f38a:     	jmp	0x14009f390 <.text+0x9e390>
14009f38c:     	movb	$0x0, 0x8(%rbp)
14009f390:     	movzwl	-0x4(%rbp), %ecx
14009f394:     	addl	$0x2, %ecx
14009f397:     	movl	%ecx, 0x43d0(%rax,%rdi,4)
14009f39e:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009f3a5:     	addq	%rax, %rsi
14009f3a8:     	leaq	-0x20(%rbp), %rcx
14009f3ac:     	movq	%rsi, %rdx
14009f3af:     	callq	0x14000b1c0 <.text+0xa1c0>
14009f3b4:     	movb	$0x1, %al
14009f3b6:     	jmp	0x14009eead <.text+0x9dead>
14009f3bb:     	xorl	%edi, %edi
14009f3bd:     	jmp	0x14009f2d9 <.text+0x9e2d9>
14009f3c2:     	movl	$0x1, %edi
14009f3c7:     	jmp	0x14009f2d9 <.text+0x9e2d9>
14009f3cc:     	leaq	0x1cd9dd(%rip), %r8     # 0x14026cdb0
14009f3d3:     	movl	$0x4, %edx
14009f3d8:     	movq	%rdi, %rcx
14009f3db:     	callq	0x140251f93 <.text+0x250f93>
14009f3e0:     	ud2
14009f3e2:     	leaq	0x1cd9df(%rip), %r8     # 0x14026cdc8
14009f3e9:     	movl	$0x4, %edx
14009f3ee:     	movq	%rdi, %rcx
14009f3f1:     	callq	0x140251f93 <.text+0x250f93>
14009f3f6:     	ud2

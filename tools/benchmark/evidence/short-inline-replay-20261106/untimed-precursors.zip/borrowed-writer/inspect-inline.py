from pathlib import Path
import subprocess, re, json, hashlib
r=Path(__file__).resolve().parent
p=subprocess.Popen(['llvm-pdbutil','dump','--symbols',str(r/'B/dispatch-probe.pdb')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace')
lines=[];keep=0
for line in p.stdout:
    if ('S_GPROC32' in line or 'S_LPROC32' in line) and any(s in line for s in ['DedupEntry::write_into','DedupEntry::write_short']):keep=7
    if keep:lines.append(line);keep-=1
assert p.wait()==0
s=''.join(lines);(r/'inline-replay-symbols.txt').write_text(s)
records=[]
for i,chunk in enumerate(re.split(r'(?m)(?=^\s*\d+ \| S_[GL]PROC32)',s)):
    m=re.search(r'addr = 0001:(\d+), code size = (\d+)',chunk)
    if not m:continue
    start=0x140001000+int(m[1]);cmd=['llvm-objdump','-d','--no-show-raw-insn',f'--start-address={hex(start)}',f'--stop-address={hex(start+int(m[2]))}',str(r/'B/dispatch-probe.exe')]
    data=subprocess.check_output(cmd);name=f'inline-replay-{i}.asm';(r/name).write_bytes(data)
    row={'symbol':chunk.splitlines()[0],'frame':int(re.search(r'\n +size = (\d+)',chunk)[1]),'code_bytes':int(m[2]),'assembly':name,'command':cmd,'sha256':hashlib.sha256(data).hexdigest()};records.append(row)
(r/'inline-replay.json').write_text(json.dumps(records,indent=2)+'\n')
assert len(records)==2
print(json.dumps(records,indent=2))

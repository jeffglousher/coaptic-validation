﻿from pathlib import Path
import subprocess,json,re,sys
r=Path(__file__).resolve().parent
python='D:/CoapticCurrent/esphome-venv/Scripts/python.exe'
subprocess.run([python,'-B',str(r/'layout32/audit.py')],check=True)
rows=[]
for label,pattern in [('SmallDevice App','coaptic::App<coaptic::profiles::Constrained,'),('Service fixed App','coaptic::App<coaptic::profiles::Service, (), 32, true, coaptic::storage::Memory<'),('Service allocated App','coaptic::App<coaptic::profiles::Service, (), 32, true, coaptic::storage::AllocMemory,'),('Replay table4','coaptic::storage::DedupTable<4>'),('Replay table64','coaptic::storage::DedupTable<64>')]:
 row={'owner':label}
 for arm in ['baseline','candidate']:
  line=next(s for s in (r/'layout32'/(arm+'-layout.txt')).read_text().splitlines() if s.startswith('print-type-size type: `'+pattern));row[arm]=int(re.search(r'`: (\d+) bytes',line)[1])
 rows.append(row)
x={'target':'thumbv7em-none-eabi','baseline_reused_from':'D:/CoapticCurrent/replay-layout32-20261106','baseline':'bd63199b652193b4c0a882e5840e72d992cf1362','candidate':'bf2c37118f1598b5d00ae810b0cb248804678185','rows':rows,'nongrowth':all(x['candidate']<=x['baseline'] for x in rows)}
(r/'layout32/preflight.json').write_text(json.dumps(x,indent=2)+'\n');print(x,flush=True);assert x['nongrowth']
subprocess.run([python,'-B',str(r/'build.py')],check=True)

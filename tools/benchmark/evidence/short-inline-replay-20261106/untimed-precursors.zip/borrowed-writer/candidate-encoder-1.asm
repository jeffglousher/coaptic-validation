
D:\CoapticCurrent\short-inline-replay-20261106\borrowed-writer\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400682a0:     	pushq	%rbp
1400682a1:     	pushq	%r15
1400682a3:     	pushq	%r14
1400682a5:     	pushq	%r13
1400682a7:     	pushq	%r12
1400682a9:     	pushq	%rsi
1400682aa:     	pushq	%rdi
1400682ab:     	pushq	%rbx
1400682ac:     	subq	$0x508, %rsp            # imm = 0x508
1400682b3:     	leaq	0x80(%rsp), %rbp
1400682bb:     	movq	0x500(%rbp), %r12
1400682c2:     	movq	0x8(%r12), %rdi
1400682c7:     	movl	$0x3, %r10d
1400682cd:     	cmpq	$0x3, %rdi
1400682d1:     	ja	0x1400683b1 <.text+0x673b1>
1400682d7:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
1400682df:     	jne	0x1400683b1 <.text+0x673b1>
1400682e5:     	movq	0x26700(%rdx,%rdi,8), %rax
1400682ed:     	cmpq	$0x4001, %rax           # imm = 0x4001
1400682f3:     	jae	0x14006858e <.text+0x6758e>
1400682f9:     	movq	0x10(%r12), %r11
1400682fe:     	movq	0x18(%r12), %r15
140068303:     	movq	%r15, %rsi
140068306:     	movl	$0xb, %r10d
14006830c:     	addq	%r11, %rsi
14006830f:     	jb	0x1400683b1 <.text+0x673b1>
140068315:     	cmpq	$0x400, %r15            # imm = 0x400
14006831c:     	ja	0x1400683b1 <.text+0x673b1>
140068322:     	cmpq	%rax, %rsi
140068325:     	ja	0x1400683b1 <.text+0x673b1>
14006832b:     	movq	%r8, %r13
14006832e:     	movq	%r9, 0x470(%rbp)
140068335:     	movq	%rcx, 0x480(%rbp)
14006833c:     	movzbl	0x508(%rbp), %r14d
140068344:     	movq	%rdi, %rax
140068347:     	shlq	$0xe, %rax
14006834b:     	movq	%rdx, %rsi
14006834e:     	leaq	(%rdx,%rax), %rbx
140068352:     	addq	$0x16700, %rbx          # imm = 0x16700
140068359:     	addq	%r11, %rbx
14006835c:     	movl	$0x400, %r8d            # imm = 0x400
140068362:     	cmpq	$0x400, %r15            # imm = 0x400
140068369:     	je	0x140068378 <.text+0x67378>
14006836b:     	movq	%rbp, %rcx
14006836e:     	xorl	%edx, %edx
140068370:     	callq	0x140251722 <.text+0x250722>
140068375:     	movq	%r15, %r8
140068378:     	movq	%rbp, %rcx
14006837b:     	movq	%rbx, %rdx
14006837e:     	callq	0x140251710 <.text+0x250710>
140068383:     	testb	%r14b, %r14b
140068386:     	je	0x1400683cc <.text+0x673cc>
140068388:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
14006838f:     	movq	%rsi, %rcx
140068392:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
14006839b:     	jne	0x140068543 <.text+0x67543>
1400683a1:     	xorl	%edi, %edi
1400683a3:     	callq	0x14009b210 <.text+0x9a210>
1400683a8:     	testb	$0x1, %al
1400683aa:     	jne	0x1400683de <.text+0x673de>
1400683ac:     	jmp	0x14006856c <.text+0x6756c>
1400683b1:     	movb	$0xa, (%rcx)
1400683b4:     	movq	%r10, 0x8(%rcx)
1400683b8:     	addq	$0x508, %rsp            # imm = 0x508
1400683bf:     	popq	%rbx
1400683c0:     	popq	%rdi
1400683c1:     	popq	%rsi
1400683c2:     	popq	%r12
1400683c4:     	popq	%r13
1400683c6:     	popq	%r14
1400683c8:     	popq	%r15
1400683ca:     	popq	%rbp
1400683cb:     	retq
1400683cc:     	xorl	%edi, %edi
1400683ce:     	movq	%rsi, %rcx
1400683d1:     	callq	0x14009b210 <.text+0x9a210>
1400683d6:     	testb	$0x1, %al
1400683d8:     	je	0x14006856c <.text+0x6756c>
1400683de:     	movq	%rdx, %rbx
1400683e1:     	movq	0x518(%rbp), %rdx
1400683e8:     	movq	0x510(%rbp), %r8
1400683ef:     	movzwl	0x4f8(%rbp), %ecx
1400683f6:     	movzbl	0x4f0(%rbp), %eax
1400683fd:     	movq	(%r12), %r9
140068401:     	movq	%rdi, 0x440(%rbp)
140068408:     	movq	0x478(%rbp), %r10
14006840f:     	movq	%r10, 0x448(%rbp)
140068416:     	movq	%r9, 0x450(%rbp)
14006841d:     	movb	%r14b, 0x458(%rbp)
140068424:     	movups	0x60(%r13), %xmm0
140068429:     	movups	0x6c(%r13), %xmm1
14006842e:     	movups	%xmm1, 0x40c(%rbp)
140068435:     	movaps	%xmm0, 0x400(%rbp)
14006843c:     	leaq	0x8e(%r13), %r9
140068443:     	movq	0x7e(%r13), %r10
140068447:     	movq	0x85(%r13), %r11
14006844e:     	movq	%r11, 0x467(%rbp)
140068455:     	movq	%r10, 0x460(%rbp)
14006845c:     	leaq	0x460(%rbp), %r10
140068463:     	movq	%r10, 0x70(%rsp)
140068468:     	movq	%rdx, 0x68(%rsp)
14006846d:     	movq	%r8, 0x60(%rsp)
140068472:     	movq	%r13, 0x58(%rsp)
140068477:     	leaq	0x440(%rbp), %rdx
14006847e:     	movq	%rdx, 0x50(%rsp)
140068483:     	movq	%r15, 0x48(%rsp)
140068488:     	movq	%rbp, %rdx
14006848b:     	movq	%rdx, 0x40(%rsp)
140068490:     	movq	0x470(%rbp), %rdx
140068497:     	movq	%rdx, 0x38(%rsp)
14006849c:     	movq	%r9, 0x30(%rsp)
1400684a1:     	movw	%cx, 0x28(%rsp)
1400684a6:     	movb	%al, 0x20(%rsp)
1400684aa:     	leaq	0x420(%rbp), %rcx
1400684b1:     	leaq	0x400(%rbp), %r8
1400684b8:     	movq	%rsi, %rdx
1400684bb:     	movq	%rbx, %r9
1400684be:     	callq	0x140081240 <.text+0x80240>
1400684c3:     	cmpb	$-0x1, 0x420(%rbp)
1400684ca:     	je	0x14006857b <.text+0x6757b>
1400684d0:     	cmpb	$0x1, 0x326f0(%rsi,%rbx)
1400684d8:     	movq	0x480(%rbp), %rax
1400684df:     	jne	0x140068529 <.text+0x67529>
1400684e1:     	cmpb	$0x0, 0x32710(%rsi,%rbx)
1400684e9:     	jne	0x140068529 <.text+0x67529>
1400684eb:     	movb	$0x0, 0x326f0(%rsi,%rbx)
1400684f3:     	decq	0x32738(%rsi)
1400684fa:     	leaq	0x326f0(%rsi), %rcx
140068501:     	movq	$0x0, 0x3e5c0(%rsi,%rbx,8)
14006850d:     	leaq	(%rbx,%rbx,8), %rdx
140068511:     	leaq	(%rdx,%rdx,2), %rdx
140068515:     	addq	%rbx, %rdx
140068518:     	movb	$0x2, 0x36a(%rcx,%rdx)
140068520:     	leaq	(%rbx,%rbx,2), %rdx
140068524:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140068529:     	movups	0x420(%rbp), %xmm0
140068530:     	movups	0x430(%rbp), %xmm1
140068537:     	movups	%xmm1, 0x10(%rax)
14006853b:     	movups	%xmm0, (%rax)
14006853e:     	jmp	0x1400683b8 <.text+0x673b8>
140068543:     	addq	%rcx, %rax
140068546:     	addq	$0x15c28, %rax          # imm = 0x15C28
14006854c:     	movq	0x98(%rax), %rax
140068553:     	movq	%rax, 0x478(%rbp)
14006855a:     	movl	$0x1, %edi
14006855f:     	callq	0x14009b210 <.text+0x9a210>
140068564:     	testb	$0x1, %al
140068566:     	jne	0x1400683de <.text+0x673de>
14006856c:     	movq	0x480(%rbp), %rax
140068573:     	movb	$0x9, (%rax)
140068576:     	jmp	0x1400683b8 <.text+0x673b8>
14006857b:     	movq	0x480(%rbp), %rax
140068582:     	movq	%rbx, 0x8(%rax)
140068586:     	movb	$-0x1, (%rax)
140068589:     	jmp	0x1400683b8 <.text+0x673b8>
14006858e:     	leaq	0x2046cb(%rip), %r9     # 0x14026cc60
140068595:     	movl	$0x4000, %r8d           # imm = 0x4000
14006859b:     	xorl	%ecx, %ecx
14006859d:     	movq	%rax, %rdx
1400685a0:     	callq	0x1402521a0 <.text+0x2511a0>
1400685a5:     	ud2

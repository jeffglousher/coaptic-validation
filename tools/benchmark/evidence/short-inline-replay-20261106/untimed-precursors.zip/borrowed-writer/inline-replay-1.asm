
D:\CoapticCurrent\short-inline-replay-20261106\borrowed-writer\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14000b1c0:     	pushq	%rbp
14000b1c1:     	movq	%rsp, %rbp
14000b1c4:     	movq	%rcx, %rax
14000b1c7:     	movzbl	0x28(%rcx), %ecx
14000b1cb:     	leaq	0x256696(%rip), %r8     # 0x140261868
14000b1d2:     	movslq	(%r8,%rcx,4), %rcx
14000b1d6:     	addq	%r8, %rcx
14000b1d9:     	jmpq	*%rcx
14000b1db:     	movups	(%rax), %xmm0
14000b1de:     	movups	0x10(%rax), %xmm1
14000b1e2:     	movups	%xmm1, 0x10(%rdx)
14000b1e6:     	movups	%xmm0, (%rdx)
14000b1e9:     	movb	$0x0, 0x28(%rdx)
14000b1ed:     	movq	0x20(%rax), %rax
14000b1f1:     	movq	%rax, 0x20(%rdx)
14000b1f5:     	popq	%rbp
14000b1f6:     	retq
14000b1f7:     	movl	$0x130, %r8d            # imm = 0x130
14000b1fd:     	movq	%rdx, %rcx
14000b200:     	movq	%rax, %rdx
14000b203:     	popq	%rbp
14000b204:     	jmp	0x140251710 <.text+0x250710>
14000b209:     	movq	0x20(%rax), %r8
14000b20d:     	movq	0x30(%rax), %r9
14000b211:     	movq	%rdx, %rcx
14000b214:     	movq	%rax, %rdx
14000b217:     	popq	%rbp
14000b218:     	jmp	0x14000b2e0 <.text+0xa2e0>
14000b21d:     	movq	%rdx, %rcx
14000b220:     	movq	%rax, %rdx
14000b223:     	popq	%rbp
14000b224:     	jmp	0x14000b230 <.text+0xa230>

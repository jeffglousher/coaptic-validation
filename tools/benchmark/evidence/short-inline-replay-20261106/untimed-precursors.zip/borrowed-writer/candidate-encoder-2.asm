
D:\CoapticCurrent\short-inline-replay-20261106\borrowed-writer\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400685b0:     	pushq	%rbp
1400685b1:     	pushq	%r15
1400685b3:     	pushq	%r14
1400685b5:     	pushq	%r13
1400685b7:     	pushq	%r12
1400685b9:     	pushq	%rsi
1400685ba:     	pushq	%rdi
1400685bb:     	pushq	%rbx
1400685bc:     	subq	$0x4f8, %rsp            # imm = 0x4F8
1400685c3:     	leaq	0x80(%rsp), %rbp
1400685cb:     	movq	0x4f0(%rbp), %r12
1400685d2:     	movq	0x8(%r12), %rdi
1400685d7:     	movl	$0x3, %r10d
1400685dd:     	cmpq	$0x3, %rdi
1400685e1:     	ja	0x1400686c3 <.text+0x676c3>
1400685e7:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
1400685ef:     	jne	0x1400686c3 <.text+0x676c3>
1400685f5:     	movq	0x26700(%rdx,%rdi,8), %rax
1400685fd:     	cmpq	$0x4001, %rax           # imm = 0x4001
140068603:     	jae	0x140068895 <.text+0x67895>
140068609:     	movq	0x10(%r12), %r11
14006860e:     	movq	0x18(%r12), %r15
140068613:     	movq	%r15, %rsi
140068616:     	movl	$0xb, %r10d
14006861c:     	addq	%r11, %rsi
14006861f:     	jb	0x1400686c3 <.text+0x676c3>
140068625:     	cmpq	$0x400, %r15            # imm = 0x400
14006862c:     	ja	0x1400686c3 <.text+0x676c3>
140068632:     	cmpq	%rax, %rsi
140068635:     	ja	0x1400686c3 <.text+0x676c3>
14006863b:     	movq	%r8, %r13
14006863e:     	movq	%r9, 0x460(%rbp)
140068645:     	movq	%rcx, 0x470(%rbp)
14006864c:     	movzbl	0x4f8(%rbp), %r14d
140068654:     	movq	%rdi, %rax
140068657:     	shlq	$0xe, %rax
14006865b:     	movq	%rdx, %rsi
14006865e:     	leaq	(%rdx,%rax), %rbx
140068662:     	addq	$0x16700, %rbx          # imm = 0x16700
140068669:     	addq	%r11, %rbx
14006866c:     	movl	$0x400, %r8d            # imm = 0x400
140068672:     	cmpq	$0x400, %r15            # imm = 0x400
140068679:     	je	0x140068689 <.text+0x67689>
14006867b:     	leaq	-0x10(%rbp), %rcx
14006867f:     	xorl	%edx, %edx
140068681:     	callq	0x140251722 <.text+0x250722>
140068686:     	movq	%r15, %r8
140068689:     	leaq	-0x10(%rbp), %rcx
14006868d:     	movq	%rbx, %rdx
140068690:     	callq	0x140251710 <.text+0x250710>
140068695:     	testb	%r14b, %r14b
140068698:     	je	0x1400686de <.text+0x676de>
14006869a:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
1400686a1:     	movq	%rsi, %rcx
1400686a4:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
1400686ad:     	jne	0x14006884a <.text+0x6784a>
1400686b3:     	xorl	%edi, %edi
1400686b5:     	callq	0x14009b210 <.text+0x9a210>
1400686ba:     	testb	$0x1, %al
1400686bc:     	jne	0x1400686f0 <.text+0x676f0>
1400686be:     	jmp	0x140068873 <.text+0x67873>
1400686c3:     	movb	$0xa, (%rcx)
1400686c6:     	movq	%r10, 0x8(%rcx)
1400686ca:     	addq	$0x4f8, %rsp            # imm = 0x4F8
1400686d1:     	popq	%rbx
1400686d2:     	popq	%rdi
1400686d3:     	popq	%rsi
1400686d4:     	popq	%r12
1400686d6:     	popq	%r13
1400686d8:     	popq	%r14
1400686da:     	popq	%r15
1400686dc:     	popq	%rbp
1400686dd:     	retq
1400686de:     	xorl	%edi, %edi
1400686e0:     	movq	%rsi, %rcx
1400686e3:     	callq	0x14009b210 <.text+0x9a210>
1400686e8:     	testb	$0x1, %al
1400686ea:     	je	0x140068873 <.text+0x67873>
1400686f0:     	movq	%rdx, %rbx
1400686f3:     	movq	0x500(%rbp), %rdx
1400686fa:     	movzwl	0x4e8(%rbp), %ecx
140068701:     	movzbl	0x4e0(%rbp), %eax
140068708:     	movq	(%r12), %r8
14006870c:     	movq	%rdi, 0x430(%rbp)
140068713:     	movq	0x468(%rbp), %r9
14006871a:     	movq	%r9, 0x438(%rbp)
140068721:     	movq	%r8, 0x440(%rbp)
140068728:     	movb	%r14b, 0x448(%rbp)
14006872f:     	movups	0x60(%r13), %xmm0
140068734:     	movups	0x6c(%r13), %xmm1
140068739:     	movups	%xmm1, 0x3fc(%rbp)
140068740:     	movaps	%xmm0, 0x3f0(%rbp)
140068747:     	leaq	0x8e(%r13), %r8
14006874e:     	movq	0x7e(%r13), %r9
140068752:     	movq	0x85(%r13), %r10
140068759:     	movq	%r10, 0x457(%rbp)
140068760:     	movq	%r9, 0x450(%rbp)
140068767:     	leaq	0x450(%rbp), %r9
14006876e:     	movq	%r9, 0x68(%rsp)
140068773:     	movq	%rdx, 0x60(%rsp)
140068778:     	movq	%r13, 0x58(%rsp)
14006877d:     	leaq	0x430(%rbp), %rdx
140068784:     	movq	%rdx, 0x50(%rsp)
140068789:     	movq	%r15, 0x48(%rsp)
14006878e:     	leaq	-0x10(%rbp), %rdx
140068792:     	movq	%rdx, 0x40(%rsp)
140068797:     	movq	0x460(%rbp), %rdx
14006879e:     	movq	%rdx, 0x38(%rsp)
1400687a3:     	movq	%r8, 0x30(%rsp)
1400687a8:     	movw	%cx, 0x28(%rsp)
1400687ad:     	movb	%al, 0x20(%rsp)
1400687b1:     	leaq	0x410(%rbp), %rcx
1400687b8:     	leaq	0x3f0(%rbp), %r8
1400687bf:     	movq	%rsi, %rdx
1400687c2:     	movq	%rbx, %r9
1400687c5:     	callq	0x140082a30 <.text+0x81a30>
1400687ca:     	cmpb	$-0x1, 0x410(%rbp)
1400687d1:     	je	0x140068882 <.text+0x67882>
1400687d7:     	cmpb	$0x1, 0x326f0(%rsi,%rbx)
1400687df:     	movq	0x470(%rbp), %rax
1400687e6:     	jne	0x140068830 <.text+0x67830>
1400687e8:     	cmpb	$0x0, 0x32710(%rsi,%rbx)
1400687f0:     	jne	0x140068830 <.text+0x67830>
1400687f2:     	movb	$0x0, 0x326f0(%rsi,%rbx)
1400687fa:     	decq	0x32738(%rsi)
140068801:     	leaq	0x326f0(%rsi), %rcx
140068808:     	movq	$0x0, 0x3e5c0(%rsi,%rbx,8)
140068814:     	leaq	(%rbx,%rbx,8), %rdx
140068818:     	leaq	(%rdx,%rdx,2), %rdx
14006881c:     	addq	%rbx, %rdx
14006881f:     	movb	$0x2, 0x36a(%rcx,%rdx)
140068827:     	leaq	(%rbx,%rbx,2), %rdx
14006882b:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140068830:     	movups	0x410(%rbp), %xmm0
140068837:     	movups	0x420(%rbp), %xmm1
14006883e:     	movups	%xmm1, 0x10(%rax)
140068842:     	movups	%xmm0, (%rax)
140068845:     	jmp	0x1400686ca <.text+0x676ca>
14006884a:     	addq	%rcx, %rax
14006884d:     	addq	$0x15c28, %rax          # imm = 0x15C28
140068853:     	movq	0x98(%rax), %rax
14006885a:     	movq	%rax, 0x468(%rbp)
140068861:     	movl	$0x1, %edi
140068866:     	callq	0x14009b210 <.text+0x9a210>
14006886b:     	testb	$0x1, %al
14006886d:     	jne	0x1400686f0 <.text+0x676f0>
140068873:     	movq	0x470(%rbp), %rax
14006887a:     	movb	$0x9, (%rax)
14006887d:     	jmp	0x1400686ca <.text+0x676ca>
140068882:     	movq	0x470(%rbp), %rax
140068889:     	movq	%rbx, 0x8(%rax)
14006888d:     	movb	$-0x1, (%rax)
140068890:     	jmp	0x1400686ca <.text+0x676ca>
140068895:     	leaq	0x2043c4(%rip), %r9     # 0x14026cc60
14006889c:     	movl	$0x4000, %r8d           # imm = 0x4000
1400688a2:     	xorl	%ecx, %ecx
1400688a4:     	movq	%rax, %rdx
1400688a7:     	callq	0x1402521a0 <.text+0x2511a0>
1400688ac:     	ud2


D:\CoapticCurrent\packet-live-ranges-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009ba60:     	pushq	%rbp
14009ba61:     	pushq	%r15
14009ba63:     	pushq	%r14
14009ba65:     	pushq	%r13
14009ba67:     	pushq	%r12
14009ba69:     	pushq	%rsi
14009ba6a:     	pushq	%rdi
14009ba6b:     	pushq	%rbx
14009ba6c:     	subq	$0x318, %rsp            # imm = 0x318
14009ba73:     	leaq	0x80(%rsp), %rbp
14009ba7b:     	movaps	%xmm7, 0x280(%rbp)
14009ba82:     	movaps	%xmm6, 0x270(%rbp)
14009ba89:     	leaq	0x30(%rcx), %rdx
14009ba8d:     	xorl	%r8d, %r8d
14009ba90:     	xorl	%r11d, %r11d
14009ba93:     	leaq	(%r11,%r11,4), %r10
14009ba97:     	shlq	$0x6, %r10
14009ba9b:     	addq	%rdx, %r10
14009ba9e:     	movq	%r11, %r9
14009baa1:     	jmp	0x14009bac4 <.text+0x9aac4>
14009baa3:     	nopw	%cs:(%rax,%rax)
14009bab0:     	incq	%r9
14009bab3:     	addq	$0x140, %r10            # imm = 0x140
14009baba:     	cmpq	$0x4, %r9
14009babe:     	je	0x14009bb4e <.text+0x9ab4e>
14009bac4:     	cmpb	$0x1, 0x510(%rcx,%r9)
14009bacd:     	jne	0x14009bab0 <.text+0x9aab0>
14009bacf:     	movq	-0x30(%r10), %rsi
14009bad3:     	cmpq	$0x2, %rsi
14009bad7:     	je	0x14009bab0 <.text+0x9aab0>
14009bad9:     	movq	(%r10), %r11
14009badc:     	cmpl	$0x1, %esi
14009badf:     	setne	%bl
14009bae2:     	testq	%r11, %r11
14009bae5:     	sete	%sil
14009bae9:     	orb	%bl, %sil
14009baec:     	cmpb	$0x1, %sil
14009baf0:     	je	0x14009bab0 <.text+0x9aab0>
14009baf2:     	movq	0x268(%rbp), %rsi
14009baf9:     	cmpq	%rsi, %r11
14009bafc:     	setae	%bl
14009baff:     	testb	%bl, %r8b
14009bb02:     	jne	0x14009bb34 <.text+0x9ab34>
14009bb04:     	movq	-0x28(%r10), %rax
14009bb08:     	movd	-0x4(%r10), %xmm6
14009bb0e:     	movzbl	-0x5(%r10), %edi
14009bb13:     	movzbl	-0x6(%r10), %r15d
14009bb18:     	movzwl	-0x8(%r10), %r12d
14009bb1d:     	movl	-0xc(%r10), %r13d
14009bb21:     	movl	-0x10(%r10), %r14d
14009bb25:     	movups	-0x20(%r10), %xmm0
14009bb2a:     	movaps	%xmm0, 0x240(%rbp)
14009bb31:     	movq	%r11, %rsi
14009bb34:     	movq	%rsi, 0x268(%rbp)
14009bb3b:     	leaq	0x1(%r9), %r11
14009bb3f:     	movb	$0x1, %r8b
14009bb42:     	cmpq	$0x3, %r9
14009bb46:     	jb	0x14009ba93 <.text+0x9aa93>
14009bb4c:     	jmp	0x14009bb58 <.text+0x9ab58>
14009bb4e:     	testb	$0x1, %r8b
14009bb52:     	je	0x14009bd98 <.text+0x9ad98>
14009bb58:     	cmpq	$0x1, %rax
14009bb5c:     	ja	0x14009bbb4 <.text+0x9abb4>
14009bb5e:     	cmpb	$0x1, 0x1e80(%rcx,%rax)
14009bb66:     	jne	0x14009bbb4 <.text+0x9abb4>
14009bb68:     	cmpb	$0x0, 0x1e82(%rcx,%rax)
14009bb70:     	jne	0x14009bbb4 <.text+0x9abb4>
14009bb72:     	movb	$0x0, 0x1e80(%rcx,%rax)
14009bb7a:     	decq	0x1e78(%rcx)
14009bb81:     	leaq	0x14f8(%rcx), %rdx
14009bb88:     	movq	$0x0, 0x1df8(%rcx,%rax,8)
14009bb94:     	leaq	(%rax,%rax,8), %r8
14009bb98:     	leaq	(%r8,%r8,2), %r8
14009bb9c:     	addq	%rax, %r8
14009bb9f:     	movb	$0x2, 0x95a(%rdx,%r8)
14009bba8:     	leaq	(%rax,%rax,2), %rax
14009bbac:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009bbb4:     	movaps	0x240(%rbp), %xmm0
14009bbbb:     	movaps	%xmm0, -0x60(%rbp)
14009bbbf:     	movl	%r14d, %esi
14009bbc2:     	movl	%r14d, -0x50(%rbp)
14009bbc6:     	movl	%r13d, %r14d
14009bbc9:     	movl	%r13d, -0x4c(%rbp)
14009bbcd:     	movl	%r12d, %r13d
14009bbd0:     	movw	%r12w, -0x48(%rbp)
14009bbd5:     	movl	%r15d, %r12d
14009bbd8:     	movb	%r15b, -0x46(%rbp)
14009bbdc:     	movl	%edi, %r15d
14009bbdf:     	movb	%dil, -0x45(%rbp)
14009bbe3:     	movd	%xmm6, %edi
14009bbe7:     	movd	%xmm6, -0x44(%rbp)
14009bbec:     	leaq	-0x60(%rbp), %rdx
14009bbf0:     	movq	%rcx, 0x260(%rbp)
14009bbf7:     	callq	0x1402120f0 <.text+0x2110f0>
14009bbfc:     	xorps	%xmm7, %xmm7
14009bbff:     	movaps	%xmm7, 0x250(%rbp)
14009bc06:     	movb	$0x0, 0x222(%rbp)
14009bc0d:     	movw	%di, 0x220(%rbp)
14009bc14:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009bc1d:     	movq	$0x0, 0x223(%rbp)
14009bc28:     	movq	$0x8, 0x200(%rbp)
14009bc33:     	movq	$0x0, 0x208(%rbp)
14009bc3e:     	movq	$0x1, 0x210(%rbp)
14009bc49:     	movq	$0x0, 0x218(%rbp)
14009bc54:     	leaq	0x230(%rbp), %rcx
14009bc5b:     	leaq	0x200(%rbp), %rdx
14009bc62:     	leaq	0x250(%rbp), %r8
14009bc69:     	movl	$0x10, %r9d
14009bc6f:     	callq	0x14010e720 <.text+0x10d720>
14009bc74:     	cmpb	$0x0, 0x230(%rbp)
14009bc7b:     	jne	0x14009bd94 <.text+0x9ad94>
14009bc81:     	movq	0x238(%rbp), %rdi
14009bc88:     	movaps	%xmm7, 0xe0(%rbp)
14009bc8f:     	movaps	%xmm7, 0xf0(%rbp)
14009bc96:     	movaps	%xmm7, 0x100(%rbp)
14009bc9d:     	movaps	%xmm7, 0x110(%rbp)
14009bca4:     	movaps	%xmm7, 0x120(%rbp)
14009bcab:     	movaps	%xmm7, 0x130(%rbp)
14009bcb2:     	movaps	%xmm7, 0x140(%rbp)
14009bcb9:     	movaps	%xmm7, 0x150(%rbp)
14009bcc0:     	movaps	%xmm7, 0x160(%rbp)
14009bcc7:     	movaps	%xmm7, 0x170(%rbp)
14009bcce:     	movaps	%xmm7, 0x180(%rbp)
14009bcd5:     	movaps	%xmm7, 0x190(%rbp)
14009bcdc:     	movaps	%xmm7, 0x1a0(%rbp)
14009bce3:     	movaps	%xmm7, 0x1b0(%rbp)
14009bcea:     	movaps	%xmm7, 0x1c0(%rbp)
14009bcf1:     	movaps	%xmm7, 0x1d0(%rbp)
14009bcf8:     	movaps	0x240(%rbp), %xmm0
14009bcff:     	movups	%xmm0, 0x1f0(%rbp)
14009bd06:     	cmpq	$0x11, %rdi
14009bd0a:     	jae	0x14009bdbc <.text+0x9adbc>
14009bd10:     	leaq	0xe0(%rbp), %rbx
14009bd17:     	leaq	0x250(%rbp), %rdx
14009bd1e:     	movq	%rbx, %rcx
14009bd21:     	movq	%rdi, %r8
14009bd24:     	callq	0x14024cc60 <.text+0x24bc60>
14009bd29:     	movw	%di, 0x1e0(%rbp)
14009bd30:     	movq	$0x0, -0x60(%rbp)
14009bd38:     	movups	0x1e8(%rbp), %xmm0
14009bd3f:     	movups	%xmm0, -0x58(%rbp)
14009bd43:     	movq	0x1f8(%rbp), %rax
14009bd4a:     	movq	%rax, -0x48(%rbp)
14009bd4e:     	movl	%esi, -0x40(%rbp)
14009bd51:     	movl	%r14d, -0x3c(%rbp)
14009bd55:     	movw	%r13w, -0x38(%rbp)
14009bd5a:     	movb	%r12b, -0x36(%rbp)
14009bd5e:     	movb	%r15b, -0x35(%rbp)
14009bd62:     	movd	%xmm6, -0x34(%rbp)
14009bd67:     	movq	0x268(%rbp), %rax
14009bd6e:     	movq	%rax, -0x30(%rbp)
14009bd72:     	leaq	-0x28(%rbp), %rcx
14009bd76:     	movl	$0x108, %r8d            # imm = 0x108
14009bd7c:     	movq	%rbx, %rdx
14009bd7f:     	callq	0x14024cc60 <.text+0x24bc60>
14009bd84:     	leaq	-0x60(%rbp), %rdx
14009bd88:     	movq	0x260(%rbp), %rcx
14009bd8f:     	callq	0x140211e60 <.text+0x210e60>
14009bd94:     	movb	$0x1, %al
14009bd96:     	jmp	0x14009bd9a <.text+0x9ad9a>
14009bd98:     	xorl	%eax, %eax
14009bd9a:     	movaps	0x270(%rbp), %xmm6
14009bda1:     	movaps	0x280(%rbp), %xmm7
14009bda8:     	addq	$0x318, %rsp            # imm = 0x318
14009bdaf:     	popq	%rbx
14009bdb0:     	popq	%rdi
14009bdb1:     	popq	%rsi
14009bdb2:     	popq	%r12
14009bdb4:     	popq	%r13
14009bdb6:     	popq	%r14
14009bdb8:     	popq	%r15
14009bdba:     	popq	%rbp
14009bdbb:     	retq
14009bdbc:     	leaq	0x1c8d95(%rip), %r9     # 0x140264b58
14009bdc3:     	movl	$0x10, %r8d
14009bdc9:     	xorl	%ecx, %ecx
14009bdcb:     	movq	%rdi, %rdx
14009bdce:     	callq	0x14024d6b0 <.text+0x24c6b0>
14009bdd3:     	ud2

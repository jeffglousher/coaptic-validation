
D:\CoapticCurrent\packet-live-ranges-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009c160:     	pushq	%rbp
14009c161:     	pushq	%r15
14009c163:     	pushq	%r14
14009c165:     	pushq	%r13
14009c167:     	pushq	%r12
14009c169:     	pushq	%rsi
14009c16a:     	pushq	%rdi
14009c16b:     	pushq	%rbx
14009c16c:     	subq	$0x308, %rsp            # imm = 0x308
14009c173:     	leaq	0x80(%rsp), %rbp
14009c17b:     	movaps	%xmm7, 0x270(%rbp)
14009c182:     	movaps	%xmm6, 0x260(%rbp)
14009c189:     	leaq	0x5000(%rcx), %rax
14009c190:     	leaq	0x30(%rcx), %r8
14009c194:     	xorl	%r9d, %r9d
14009c197:     	xorl	%esi, %esi
14009c199:     	leaq	(%rsi,%rsi,4), %r11
14009c19d:     	shlq	$0x6, %r11
14009c1a1:     	addq	%r8, %r11
14009c1a4:     	movq	%rsi, %r10
14009c1a7:     	jmp	0x14009c1c4 <.text+0x9b1c4>
14009c1a9:     	nopl	(%rax)
14009c1b0:     	incq	%r10
14009c1b3:     	addq	$0x140, %r11            # imm = 0x140
14009c1ba:     	cmpq	$0x40, %r10
14009c1be:     	je	0x14009c25e <.text+0x9b25e>
14009c1c4:     	cmpb	$0x1, 0x5000(%rcx,%r10)
14009c1cd:     	jne	0x14009c1b0 <.text+0x9b1b0>
14009c1cf:     	movq	-0x30(%r11), %rdi
14009c1d3:     	cmpq	$0x2, %rdi
14009c1d7:     	je	0x14009c1b0 <.text+0x9b1b0>
14009c1d9:     	movq	(%r11), %rsi
14009c1dc:     	cmpl	$0x1, %edi
14009c1df:     	setne	%bl
14009c1e2:     	testq	%rsi, %rsi
14009c1e5:     	sete	%dil
14009c1e9:     	orb	%bl, %dil
14009c1ec:     	cmpb	$0x1, %dil
14009c1f0:     	je	0x14009c1b0 <.text+0x9b1b0>
14009c1f2:     	movq	0x250(%rbp), %rdi
14009c1f9:     	cmpq	%rdi, %rsi
14009c1fc:     	setae	%bl
14009c1ff:     	testb	%bl, %r9b
14009c202:     	jne	0x14009c244 <.text+0x9b244>
14009c204:     	movd	-0x4(%r11), %xmm6
14009c20a:     	movzbl	-0x5(%r11), %edx
14009c20f:     	movb	%dl, 0x25f(%rbp)
14009c215:     	movzbl	-0x6(%r11), %r15d
14009c21a:     	movzwl	-0x8(%r11), %r12d
14009c21f:     	movl	-0xc(%r11), %r13d
14009c223:     	movl	-0x10(%r11), %r14d
14009c227:     	movq	-0x18(%r11), %rdx
14009c22b:     	movq	%rdx, 0x248(%rbp)
14009c232:     	movq	-0x28(%r11), %rdx
14009c236:     	movq	-0x20(%r11), %r9
14009c23a:     	movq	%r9, 0x240(%rbp)
14009c241:     	movq	%rsi, %rdi
14009c244:     	movq	%rdi, 0x250(%rbp)
14009c24b:     	leaq	0x1(%r10), %rsi
14009c24f:     	movb	$0x1, %r9b
14009c252:     	cmpq	$0x3f, %r10
14009c256:     	jb	0x14009c199 <.text+0x9b199>
14009c25c:     	jmp	0x14009c268 <.text+0x9b268>
14009c25e:     	testb	$0x1, %r9b
14009c262:     	je	0x14009c4e0 <.text+0x9b4e0>
14009c268:     	cmpq	$0x1f, %rdx
14009c26c:     	ja	0x14009c2bf <.text+0x9b2bf>
14009c26e:     	leaq	0x37740(%rcx), %r8
14009c275:     	cmpb	$0x1, (%r8,%rdx)
14009c27a:     	jne	0x14009c2bf <.text+0x9b2bf>
14009c27c:     	cmpb	$0x0, 0x37760(%rcx,%rdx)
14009c284:     	jne	0x14009c2bf <.text+0x9b2bf>
14009c286:     	movb	$0x0, 0x37740(%rcx,%rdx)
14009c28e:     	decq	0x37788(%rcx)
14009c295:     	movq	$0x0, 0x43610(%rcx,%rdx,8)
14009c2a1:     	leaq	(%rdx,%rdx,8), %r9
14009c2a5:     	leaq	(%r9,%r9,2), %r9
14009c2a9:     	addq	%rdx, %r9
14009c2ac:     	movb	$0x2, 0x36a(%r8,%r9)
14009c2b5:     	leaq	(%rdx,%rdx,2), %rdx
14009c2b9:     	movb	$0x2, 0x5d(%r8,%rdx,8)
14009c2bf:     	movd	%xmm6, %edx
14009c2c3:     	movl	$0x2c, %r8d
14009c2c9:     	movq	0x240(%rbp), %r11
14009c2d0:     	movq	0x248(%rbp), %rsi
14009c2d7:     	jmp	0x14009c2f3 <.text+0x9b2f3>
14009c2d9:     	nopl	(%rax)
14009c2e0:     	incq	%rax
14009c2e3:     	addq	$0x140, %r8             # imm = 0x140
14009c2ea:     	cmpq	$0x502c, %r8            # imm = 0x502C
14009c2f1:     	je	0x14009c34c <.text+0x9b34c>
14009c2f3:     	cmpb	$0x1, (%rax)
14009c2f6:     	jne	0x14009c2e0 <.text+0x9b2e0>
14009c2f8:     	cmpl	$0x2, -0x2c(%rcx,%r8)
14009c2fe:     	je	0x14009c2e0 <.text+0x9b2e0>
14009c300:     	cmpw	%dx, (%rcx,%r8)
14009c305:     	jne	0x14009c2e0 <.text+0x9b2e0>
14009c307:     	cmpl	%r14d, -0xc(%rcx,%r8)
14009c30c:     	jne	0x14009c2e0 <.text+0x9b2e0>
14009c30e:     	cmpl	%r13d, -0x8(%rcx,%r8)
14009c313:     	jne	0x14009c2e0 <.text+0x9b2e0>
14009c315:     	cmpw	%r12w, -0x4(%rcx,%r8)
14009c31b:     	jne	0x14009c2e0 <.text+0x9b2e0>
14009c31d:     	cmpb	%r15b, -0x2(%rcx,%r8)
14009c322:     	jne	0x14009c2e0 <.text+0x9b2e0>
14009c324:     	movq	-0x1c(%rcx,%r8), %r9
14009c329:     	xorq	%r11, %r9
14009c32c:     	movq	-0x14(%rcx,%r8), %r10
14009c331:     	xorq	%rsi, %r10
14009c334:     	orq	%r9, %r10
14009c337:     	jne	0x14009c2e0 <.text+0x9b2e0>
14009c339:     	movb	$0x0, (%rax)
14009c33c:     	decq	0x5048(%rcx)
14009c343:     	movq	$0x2, -0x2c(%rcx,%r8)
14009c34c:     	movq	%rcx, %rsi
14009c34f:     	xorps	%xmm7, %xmm7
14009c352:     	movaps	%xmm7, 0x230(%rbp)
14009c359:     	movb	$0x0, 0x212(%rbp)
14009c360:     	movw	%dx, 0x210(%rbp)
14009c367:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
14009c370:     	movq	$0x0, 0x213(%rbp)
14009c37b:     	movq	$0x8, 0x1f0(%rbp)
14009c386:     	movq	$0x0, 0x1f8(%rbp)
14009c391:     	movq	$0x1, 0x200(%rbp)
14009c39c:     	movq	$0x0, 0x208(%rbp)
14009c3a7:     	leaq	0x220(%rbp), %rcx
14009c3ae:     	leaq	0x1f0(%rbp), %rdx
14009c3b5:     	leaq	0x230(%rbp), %r8
14009c3bc:     	movl	$0x10, %r9d
14009c3c2:     	callq	0x14010e720 <.text+0x10d720>
14009c3c7:     	cmpb	$0x0, 0x220(%rbp)
14009c3ce:     	jne	0x14009c4dc <.text+0x9b4dc>
14009c3d4:     	movq	0x228(%rbp), %rdi
14009c3db:     	movaps	%xmm7, 0xe0(%rbp)
14009c3e2:     	movaps	%xmm7, 0xf0(%rbp)
14009c3e9:     	movaps	%xmm7, 0x100(%rbp)
14009c3f0:     	movaps	%xmm7, 0x110(%rbp)
14009c3f7:     	movaps	%xmm7, 0x120(%rbp)
14009c3fe:     	movaps	%xmm7, 0x130(%rbp)
14009c405:     	movaps	%xmm7, 0x140(%rbp)
14009c40c:     	movaps	%xmm7, 0x150(%rbp)
14009c413:     	movaps	%xmm7, 0x160(%rbp)
14009c41a:     	movaps	%xmm7, 0x170(%rbp)
14009c421:     	movaps	%xmm7, 0x180(%rbp)
14009c428:     	movaps	%xmm7, 0x190(%rbp)
14009c42f:     	movaps	%xmm7, 0x1a0(%rbp)
14009c436:     	movaps	%xmm7, 0x1b0(%rbp)
14009c43d:     	movaps	%xmm7, 0x1c0(%rbp)
14009c444:     	movaps	%xmm7, 0x1d0(%rbp)
14009c44b:     	cmpq	$0x11, %rdi
14009c44f:     	jae	0x14009c504 <.text+0x9b504>
14009c455:     	leaq	0xe0(%rbp), %rbx
14009c45c:     	leaq	0x230(%rbp), %rdx
14009c463:     	movq	%rbx, %rcx
14009c466:     	movq	%rdi, %r8
14009c469:     	callq	0x14024cc60 <.text+0x24bc60>
14009c46e:     	movw	%di, 0x1e0(%rbp)
14009c475:     	movq	$0x0, -0x60(%rbp)
14009c47d:     	movq	0x248(%rbp), %rax
14009c484:     	movq	%rax, -0x48(%rbp)
14009c488:     	movq	0x240(%rbp), %rax
14009c48f:     	movq	%rax, -0x50(%rbp)
14009c493:     	movl	%r14d, -0x40(%rbp)
14009c497:     	movl	%r13d, -0x3c(%rbp)
14009c49b:     	movw	%r12w, -0x38(%rbp)
14009c4a0:     	movb	%r15b, -0x36(%rbp)
14009c4a4:     	movzbl	0x25f(%rbp), %eax
14009c4ab:     	movb	%al, -0x35(%rbp)
14009c4ae:     	movd	%xmm6, -0x34(%rbp)
14009c4b3:     	movq	0x250(%rbp), %rax
14009c4ba:     	movq	%rax, -0x30(%rbp)
14009c4be:     	leaq	-0x28(%rbp), %rcx
14009c4c2:     	movl	$0x108, %r8d            # imm = 0x108
14009c4c8:     	movq	%rbx, %rdx
14009c4cb:     	callq	0x14024cc60 <.text+0x24bc60>
14009c4d0:     	leaq	-0x60(%rbp), %rdx
14009c4d4:     	movq	%rsi, %rcx
14009c4d7:     	callq	0x140211cc0 <.text+0x210cc0>
14009c4dc:     	movb	$0x1, %al
14009c4de:     	jmp	0x14009c4e2 <.text+0x9b4e2>
14009c4e0:     	xorl	%eax, %eax
14009c4e2:     	movaps	0x260(%rbp), %xmm6
14009c4e9:     	movaps	0x270(%rbp), %xmm7
14009c4f0:     	addq	$0x308, %rsp            # imm = 0x308
14009c4f7:     	popq	%rbx
14009c4f8:     	popq	%rdi
14009c4f9:     	popq	%rsi
14009c4fa:     	popq	%r12
14009c4fc:     	popq	%r13
14009c4fe:     	popq	%r14
14009c500:     	popq	%r15
14009c502:     	popq	%rbp
14009c503:     	retq
14009c504:     	leaq	0x1c864d(%rip), %r9     # 0x140264b58
14009c50b:     	movl	$0x10, %r8d
14009c511:     	xorl	%ecx, %ecx
14009c513:     	movq	%rdi, %rdx
14009c516:     	callq	0x14024d6b0 <.text+0x24c6b0>
14009c51b:     	ud2

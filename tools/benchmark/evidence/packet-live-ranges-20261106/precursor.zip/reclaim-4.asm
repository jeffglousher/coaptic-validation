
D:\CoapticCurrent\packet-live-ranges-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009c520:     	pushq	%rbp
14009c521:     	pushq	%r15
14009c523:     	pushq	%r14
14009c525:     	pushq	%r13
14009c527:     	pushq	%r12
14009c529:     	pushq	%rsi
14009c52a:     	pushq	%rdi
14009c52b:     	pushq	%rbx
14009c52c:     	subq	$0x318, %rsp            # imm = 0x318
14009c533:     	leaq	0x80(%rsp), %rbp
14009c53b:     	movaps	%xmm7, 0x280(%rbp)
14009c542:     	movdqa	%xmm6, 0x270(%rbp)
14009c54a:     	movq	0xe8(%rcx), %r8
14009c551:     	testq	%r8, %r8
14009c554:     	je	0x14009c934 <.text+0x9b934>
14009c55a:     	movq	0x88(%rcx), %r11
14009c561:     	movq	0xe0(%rcx), %rdx
14009c568:     	movq	0xc8(%rcx), %rax
14009c56f:     	movq	0xd0(%rcx), %r9
14009c576:     	leaq	0x30(%rax), %rsi
14009c57a:     	xorl	%ebx, %ebx
14009c57c:     	xorl	%edi, %edi
14009c57e:     	leaq	(%rdi,%rdi,4), %r12
14009c582:     	shlq	$0x6, %r12
14009c586:     	addq	%rsi, %r12
14009c589:     	jmp	0x14009c5a3 <.text+0x9b5a3>
14009c58b:     	nopl	(%rax,%rax)
14009c590:     	incq	%rdi
14009c593:     	addq	$0x140, %r12            # imm = 0x140
14009c59a:     	cmpq	%r8, %rdi
14009c59d:     	jae	0x14009c66c <.text+0x9b66c>
14009c5a3:     	cmpq	%r9, %rdi
14009c5a6:     	setb	%r15b
14009c5aa:     	andb	(%rdx,%rdi), %r15b
14009c5ae:     	cmpb	$0x1, %r15b
14009c5b2:     	jne	0x14009c590 <.text+0x9b590>
14009c5b4:     	movq	-0x30(%r12), %r15
14009c5b9:     	cmpq	$0x2, %r15
14009c5bd:     	je	0x14009c590 <.text+0x9b590>
14009c5bf:     	movq	(%r12), %r13
14009c5c3:     	cmpl	$0x1, %r15d
14009c5c7:     	setne	%r15b
14009c5cb:     	testq	%r13, %r13
14009c5ce:     	sete	%r10b
14009c5d2:     	orb	%r15b, %r10b
14009c5d5:     	cmpb	$0x1, %r10b
14009c5d9:     	je	0x14009c590 <.text+0x9b590>
14009c5db:     	movq	0x260(%rbp), %r15
14009c5e2:     	cmpq	%r15, %r13
14009c5e5:     	setae	%r10b
14009c5e9:     	testb	%r10b, %bl
14009c5ec:     	jne	0x14009c655 <.text+0x9b655>
14009c5ee:     	movq	-0x28(%r12), %r10
14009c5f3:     	movq	%r10, 0x250(%rbp)
14009c5fa:     	movq	-0x20(%r12), %r10
14009c5ff:     	movq	%r10, 0x248(%rbp)
14009c606:     	movd	-0x4(%r12), %xmm6
14009c60d:     	movzbl	-0x5(%r12), %r10d
14009c613:     	movb	%r10b, 0x26e(%rbp)
14009c61a:     	movzbl	-0x6(%r12), %r10d
14009c620:     	movb	%r10b, 0x26f(%rbp)
14009c627:     	movzwl	-0x8(%r12), %r10d
14009c62d:     	movw	%r10w, 0x26c(%rbp)
14009c635:     	movl	-0xc(%r12), %r10d
14009c63a:     	movl	%r10d, 0x268(%rbp)
14009c641:     	movl	-0x10(%r12), %r14d
14009c646:     	movq	-0x18(%r12), %r10
14009c64b:     	movq	%r10, 0x258(%rbp)
14009c652:     	movq	%r13, %r15
14009c655:     	movq	%r15, 0x260(%rbp)
14009c65c:     	incq	%rdi
14009c65f:     	movb	$0x1, %bl
14009c661:     	cmpq	%r8, %rdi
14009c664:     	jb	0x14009c57e <.text+0x9b57e>
14009c66a:     	jmp	0x14009c675 <.text+0x9b675>
14009c66c:     	testb	$0x1, %bl
14009c66f:     	je	0x14009c934 <.text+0x9b934>
14009c675:     	movq	0x250(%rbp), %r10
14009c67c:     	cmpq	%r11, %r10
14009c67f:     	jae	0x14009c6d5 <.text+0x9b6d5>
14009c681:     	movq	0x80(%rcx), %r11
14009c688:     	cmpb	$0x1, (%r11,%r10)
14009c68d:     	jne	0x14009c6d5 <.text+0x9b6d5>
14009c68f:     	cmpq	0xa0(%rcx), %r10
14009c696:     	jae	0x14009c6a6 <.text+0x9b6a6>
14009c698:     	movq	0x98(%rcx), %rsi
14009c69f:     	cmpb	$0x0, (%rsi,%r10)
14009c6a4:     	jne	0x14009c6d5 <.text+0x9b6d5>
14009c6a6:     	movb	$0x0, (%r11,%r10)
14009c6ab:     	decq	0xb0(%rcx)
14009c6b2:     	cmpq	0x70(%rcx), %r10
14009c6b6:     	jae	0x14009c6d5 <.text+0x9b6d5>
14009c6b8:     	movq	0x68(%rcx), %r11
14009c6bc:     	imulq	$0x58, %r10, %r10
14009c6c0:     	movq	$0x0, 0x30(%r11,%r10)
14009c6c9:     	movb	$0x2, 0x52(%r11,%r10)
14009c6cf:     	movb	$0x2, 0x25(%r11,%r10)
14009c6d5:     	leaq	0xc0(%rcx), %rsi
14009c6dc:     	movd	%xmm6, %r10d
14009c6e1:     	addq	$0x2c, %rax
14009c6e5:     	xorl	%r11d, %r11d
14009c6e8:     	movq	0x248(%rbp), %r15
14009c6ef:     	movzbl	0x26e(%rbp), %r12d
14009c6f7:     	jmp	0x14009c712 <.text+0x9b712>
14009c6f9:     	nopl	(%rax)
14009c700:     	incq	%r11
14009c703:     	addq	$0x140, %rax            # imm = 0x140
14009c709:     	cmpq	%r11, %r8
14009c70c:     	je	0x14009c79e <.text+0x9b79e>
14009c712:     	cmpq	%r9, %r11
14009c715:     	setb	%bl
14009c718:     	andb	(%rdx,%r11), %bl
14009c71c:     	cmpb	$0x1, %bl
14009c71f:     	jne	0x14009c700 <.text+0x9b700>
14009c721:     	cmpl	$0x2, -0x2c(%rax)
14009c725:     	je	0x14009c700 <.text+0x9b700>
14009c727:     	cmpw	%r10w, (%rax)
14009c72b:     	jne	0x14009c700 <.text+0x9b700>
14009c72d:     	cmpl	%r14d, -0xc(%rax)
14009c731:     	jne	0x14009c700 <.text+0x9b700>
14009c733:     	movl	0x268(%rbp), %edi
14009c739:     	cmpl	%edi, -0x8(%rax)
14009c73c:     	jne	0x14009c700 <.text+0x9b700>
14009c73e:     	movzwl	0x26c(%rbp), %edi
14009c745:     	cmpw	%di, -0x4(%rax)
14009c749:     	jne	0x14009c700 <.text+0x9b700>
14009c74b:     	movzbl	0x26f(%rbp), %ebx
14009c752:     	cmpb	%bl, -0x2(%rax)
14009c755:     	jne	0x14009c700 <.text+0x9b700>
14009c757:     	movq	-0x1c(%rax), %rdi
14009c75b:     	xorq	%r15, %rdi
14009c75e:     	movq	-0x14(%rax), %rbx
14009c762:     	xorq	0x258(%rbp), %rbx
14009c769:     	orq	%rdi, %rbx
14009c76c:     	jne	0x14009c700 <.text+0x9b700>
14009c76e:     	cmpq	%r8, %r11
14009c771:     	jae	0x14009c79e <.text+0x9b79e>
14009c773:     	cmpq	0x100(%rcx), %r11
14009c77a:     	jae	0x14009c78a <.text+0x9b78a>
14009c77c:     	movq	0xf8(%rcx), %r8
14009c783:     	cmpb	$0x0, (%r8,%r11)
14009c788:     	jne	0x14009c79e <.text+0x9b79e>
14009c78a:     	movb	$0x0, (%rdx,%r11)
14009c78f:     	decq	0x110(%rcx)
14009c796:     	movq	$0x2, -0x2c(%rax)
14009c79e:     	xorps	%xmm7, %xmm7
14009c7a1:     	movaps	%xmm7, 0x230(%rbp)
14009c7a8:     	movb	$0x0, 0x212(%rbp)
14009c7af:     	movw	%r10w, 0x210(%rbp)
14009c7b7:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
14009c7c0:     	movq	$0x0, 0x213(%rbp)
14009c7cb:     	movq	$0x8, 0x1f0(%rbp)
14009c7d6:     	movq	$0x0, 0x1f8(%rbp)
14009c7e1:     	movq	$0x1, 0x200(%rbp)
14009c7ec:     	movq	$0x0, 0x208(%rbp)
14009c7f7:     	leaq	0x220(%rbp), %rcx
14009c7fe:     	leaq	0x1f0(%rbp), %rdx
14009c805:     	leaq	0x230(%rbp), %r8
14009c80c:     	movl	$0x10, %r9d
14009c812:     	callq	0x14010e720 <.text+0x10d720>
14009c817:     	cmpb	$0x0, 0x220(%rbp)
14009c81e:     	jne	0x14009c930 <.text+0x9b930>
14009c824:     	movq	0x228(%rbp), %rdi
14009c82b:     	movaps	%xmm7, 0xe0(%rbp)
14009c832:     	movaps	%xmm7, 0xf0(%rbp)
14009c839:     	movaps	%xmm7, 0x100(%rbp)
14009c840:     	movaps	%xmm7, 0x110(%rbp)
14009c847:     	movaps	%xmm7, 0x120(%rbp)
14009c84e:     	movaps	%xmm7, 0x130(%rbp)
14009c855:     	movaps	%xmm7, 0x140(%rbp)
14009c85c:     	movaps	%xmm7, 0x150(%rbp)
14009c863:     	movaps	%xmm7, 0x160(%rbp)
14009c86a:     	movaps	%xmm7, 0x170(%rbp)
14009c871:     	movaps	%xmm7, 0x180(%rbp)
14009c878:     	movaps	%xmm7, 0x190(%rbp)
14009c87f:     	movaps	%xmm7, 0x1a0(%rbp)
14009c886:     	movaps	%xmm7, 0x1b0(%rbp)
14009c88d:     	movaps	%xmm7, 0x1c0(%rbp)
14009c894:     	movaps	%xmm7, 0x1d0(%rbp)
14009c89b:     	cmpq	$0x11, %rdi
14009c89f:     	jae	0x14009c958 <.text+0x9b958>
14009c8a5:     	leaq	0xe0(%rbp), %rbx
14009c8ac:     	leaq	0x230(%rbp), %rdx
14009c8b3:     	movq	%rbx, %rcx
14009c8b6:     	movq	%rdi, %r8
14009c8b9:     	callq	0x14024cc60 <.text+0x24bc60>
14009c8be:     	movw	%di, 0x1e0(%rbp)
14009c8c5:     	movq	$0x0, -0x60(%rbp)
14009c8cd:     	movq	0x258(%rbp), %rax
14009c8d4:     	movq	%rax, -0x48(%rbp)
14009c8d8:     	movq	%r15, -0x50(%rbp)
14009c8dc:     	movl	%r14d, -0x40(%rbp)
14009c8e0:     	movl	0x268(%rbp), %eax
14009c8e6:     	movl	%eax, -0x3c(%rbp)
14009c8e9:     	movzwl	0x26c(%rbp), %eax
14009c8f0:     	movw	%ax, -0x38(%rbp)
14009c8f4:     	movzbl	0x26f(%rbp), %eax
14009c8fb:     	movb	%al, -0x36(%rbp)
14009c8fe:     	movb	%r12b, -0x35(%rbp)
14009c902:     	movd	%xmm6, -0x34(%rbp)
14009c907:     	movq	0x260(%rbp), %rax
14009c90e:     	movq	%rax, -0x30(%rbp)
14009c912:     	leaq	-0x28(%rbp), %rcx
14009c916:     	movl	$0x108, %r8d            # imm = 0x108
14009c91c:     	movq	%rbx, %rdx
14009c91f:     	callq	0x14024cc60 <.text+0x24bc60>
14009c924:     	leaq	-0x60(%rbp), %rdx
14009c928:     	movq	%rsi, %rcx
14009c92b:     	callq	0x1400116e0 <.text+0x106e0>
14009c930:     	movb	$0x1, %al
14009c932:     	jmp	0x14009c936 <.text+0x9b936>
14009c934:     	xorl	%eax, %eax
14009c936:     	movaps	0x270(%rbp), %xmm6
14009c93d:     	movaps	0x280(%rbp), %xmm7
14009c944:     	addq	$0x318, %rsp            # imm = 0x318
14009c94b:     	popq	%rbx
14009c94c:     	popq	%rdi
14009c94d:     	popq	%rsi
14009c94e:     	popq	%r12
14009c950:     	popq	%r13
14009c952:     	popq	%r14
14009c954:     	popq	%r15
14009c956:     	popq	%rbp
14009c957:     	retq
14009c958:     	leaq	0x1c81f9(%rip), %r9     # 0x140264b58
14009c95f:     	movl	$0x10, %r8d
14009c965:     	xorl	%ecx, %ecx
14009c967:     	movq	%rdi, %rdx
14009c96a:     	callq	0x14024d6b0 <.text+0x24c6b0>
14009c96f:     	ud2


D:\CoapticCurrent\packet-live-ranges-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068000:     	pushq	%rbp
140068001:     	pushq	%r15
140068003:     	pushq	%r14
140068005:     	pushq	%r13
140068007:     	pushq	%r12
140068009:     	pushq	%rsi
14006800a:     	pushq	%rdi
14006800b:     	pushq	%rbx
14006800c:     	subq	$0x508, %rsp            # imm = 0x508
140068013:     	leaq	0x80(%rsp), %rbp
14006801b:     	movq	%r9, %rbx
14006801e:     	movq	%r8, %r14
140068021:     	movq	%rdx, %rdi
140068024:     	movq	%rcx, %rsi
140068027:     	movq	0x500(%rbp), %r12
14006802e:     	movq	%rbp, %rcx
140068031:     	movl	$0x400, %r8d            # imm = 0x400
140068037:     	xorl	%edx, %edx
140068039:     	callq	0x14024cc72 <.text+0x24bc72>
14006803e:     	movq	0x8(%r12), %r13
140068043:     	movl	$0x3, %eax
140068048:     	cmpq	$0x3, %r13
14006804c:     	ja	0x14006826f <.text+0x6726f>
140068052:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
14006805b:     	jne	0x14006826f <.text+0x6726f>
140068061:     	movq	0x2b750(%rdi,%r13,8), %rdx
140068069:     	cmpq	$0x4001, %rdx           # imm = 0x4001
140068070:     	jae	0x1400682cb <.text+0x672cb>
140068076:     	movq	0x10(%r12), %rcx
14006807b:     	movq	0x18(%r12), %r15
140068080:     	movq	%r15, %r8
140068083:     	movl	$0xb, %eax
140068088:     	addq	%rcx, %r8
14006808b:     	jb	0x14006826f <.text+0x6726f>
140068091:     	cmpq	$0x400, %r15            # imm = 0x400
140068098:     	ja	0x14006826f <.text+0x6726f>
14006809e:     	cmpq	%rdx, %r8
1400680a1:     	ja	0x14006826f <.text+0x6726f>
1400680a7:     	movq	%r13, %rax
1400680aa:     	shlq	$0xe, %rax
1400680ae:     	leaq	(%rdi,%rax), %rdx
1400680b2:     	addq	$0x1b750, %rdx          # imm = 0x1B750
1400680b9:     	addq	%rcx, %rdx
1400680bc:     	movq	%rbp, %rcx
1400680bf:     	movq	%r15, %r8
1400680c2:     	callq	0x14024cc60 <.text+0x24bc60>
1400680c7:     	cmpb	$0x0, 0x508(%rbp)
1400680ce:     	je	0x1400680e6 <.text+0x670e6>
1400680d0:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
1400680d7:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
1400680e0:     	jne	0x14006828a <.text+0x6728a>
1400680e6:     	movq	$0x0, 0x480(%rbp)
1400680f1:     	movq	%rdi, %rcx
1400680f4:     	callq	0x140098670 <.text+0x97670>
1400680f9:     	testb	$0x1, %al
1400680fb:     	je	0x1400682bd <.text+0x672bd>
140068101:     	movq	%rdx, %r13
140068104:     	movq	0x518(%rbp), %rdx
14006810b:     	movq	0x510(%rbp), %r8
140068112:     	movzwl	0x4f8(%rbp), %ecx
140068119:     	movzbl	0x4f0(%rbp), %eax
140068120:     	movq	(%r12), %r9
140068124:     	movq	0x480(%rbp), %r10
14006812b:     	movq	%r10, 0x448(%rbp)
140068132:     	movq	0x478(%rbp), %r10
140068139:     	movq	%r10, 0x450(%rbp)
140068140:     	movq	%r9, 0x458(%rbp)
140068147:     	movzbl	0x508(%rbp), %r9d
14006814f:     	movb	%r9b, 0x460(%rbp)
140068156:     	movups	0x40(%r14), %xmm0
14006815b:     	movups	0x4c(%r14), %xmm1
140068160:     	movups	%xmm1, 0x40c(%rbp)
140068167:     	movaps	%xmm0, 0x400(%rbp)
14006816e:     	leaq	0x6e(%r14), %r9
140068172:     	movq	0x5e(%r14), %r10
140068176:     	movq	0x65(%r14), %r11
14006817a:     	movq	%r11, 0x46f(%rbp)
140068181:     	movq	%r10, 0x468(%rbp)
140068188:     	leaq	0x468(%rbp), %r10
14006818f:     	movq	%r10, 0x70(%rsp)
140068194:     	movq	%rdx, 0x68(%rsp)
140068199:     	movq	%r8, 0x60(%rsp)
14006819e:     	movq	%r14, 0x58(%rsp)
1400681a3:     	leaq	0x448(%rbp), %rdx
1400681aa:     	movq	%rdx, 0x50(%rsp)
1400681af:     	movq	%r15, 0x48(%rsp)
1400681b4:     	movq	%rbp, %rdx
1400681b7:     	movq	%rdx, 0x40(%rsp)
1400681bc:     	movq	%rbx, 0x38(%rsp)
1400681c1:     	movq	%r9, 0x30(%rsp)
1400681c6:     	movw	%cx, 0x28(%rsp)
1400681cb:     	movb	%al, 0x20(%rsp)
1400681cf:     	leaq	0x428(%rbp), %rcx
1400681d6:     	leaq	0x400(%rbp), %r8
1400681dd:     	movq	%rdi, %rdx
1400681e0:     	movq	%r13, %r9
1400681e3:     	callq	0x14007f210 <.text+0x7e210>
1400681e8:     	cmpb	$-0x1, 0x428(%rbp)
1400681ef:     	je	0x1400682c2 <.text+0x672c2>
1400681f5:     	cmpb	$0x1, 0x37740(%rdi,%r13)
1400681fe:     	jne	0x140068258 <.text+0x67258>
140068200:     	cmpb	$0x0, 0x37760(%rdi,%r13)
140068209:     	jne	0x140068258 <.text+0x67258>
14006820b:     	movb	$0x0, 0x37740(%rdi,%r13)
140068214:     	decq	0x37788(%rdi)
14006821b:     	leaq	0x37740(%rdi), %rax
140068222:     	movq	$0x0, 0x43610(%rdi,%r13,8)
14006822e:     	leaq	(,%r13,8), %rcx
140068236:     	addq	%r13, %rcx
140068239:     	leaq	(%rcx,%rcx,2), %rcx
14006823d:     	addq	%r13, %rcx
140068240:     	movb	$0x2, 0x36a(%rax,%rcx)
140068248:     	leaq	(,%r13,2), %rcx
140068250:     	addq	%r13, %rcx
140068253:     	movb	$0x2, 0x5d(%rax,%rcx,8)
140068258:     	movups	0x428(%rbp), %xmm0
14006825f:     	movups	0x438(%rbp), %xmm1
140068266:     	movups	%xmm1, 0x10(%rsi)
14006826a:     	movups	%xmm0, (%rsi)
14006826d:     	jmp	0x140068276 <.text+0x67276>
14006826f:     	movb	$0xa, (%rsi)
140068272:     	movq	%rax, 0x8(%rsi)
140068276:     	addq	$0x508, %rsp            # imm = 0x508
14006827d:     	popq	%rbx
14006827e:     	popq	%rdi
14006827f:     	popq	%rsi
140068280:     	popq	%r12
140068282:     	popq	%r13
140068284:     	popq	%r14
140068286:     	popq	%r15
140068288:     	popq	%rbp
140068289:     	retq
14006828a:     	addq	%rdi, %rax
14006828d:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
140068293:     	movq	0x98(%rax), %rax
14006829a:     	movq	%rax, 0x478(%rbp)
1400682a1:     	movl	$0x1, %eax
1400682a6:     	movq	%rax, 0x480(%rbp)
1400682ad:     	movq	%rdi, %rcx
1400682b0:     	callq	0x140098670 <.text+0x97670>
1400682b5:     	testb	$0x1, %al
1400682b7:     	jne	0x140068101 <.text+0x67101>
1400682bd:     	movb	$0x9, (%rsi)
1400682c0:     	jmp	0x140068276 <.text+0x67276>
1400682c2:     	movq	%r13, 0x8(%rsi)
1400682c6:     	movb	$-0x1, (%rsi)
1400682c9:     	jmp	0x140068276 <.text+0x67276>
1400682cb:     	leaq	0x1ff95e(%rip), %r9     # 0x140267c30
1400682d2:     	movl	$0x4000, %r8d           # imm = 0x4000
1400682d8:     	xorl	%ecx, %ecx
1400682da:     	callq	0x14024d6b0 <.text+0x24c6b0>
1400682df:     	ud2

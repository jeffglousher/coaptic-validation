from pathlib import Path
import os,subprocess
root=Path(__file__).resolve().parent
fixture=Path('D:/CoapticCurrent/replay-active-copy-20261105/fixture/probe')
output=root/'owner-layout-2.txt'
assert not output.exists()
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',RUSTFLAGS='-Cforce-frame-pointers=yes',RUSTC_BOOTSTRAP='1')
cmd=[str(Path.home()/'.cargo/bin/agent-resources.exe'),'run','--id','coaptic-core-reusable','--directory',str(fixture),'--','cargo','rustc','--locked','--offline','--release','--bin','dispatch-probe','--','-Zprint-type-sizes']
size=0;keep=False
with output.open('w',encoding='utf-8') as out,(root/'layout-build-2.log').open('w') as errors:
 p=subprocess.Popen(cmd,cwd=fixture,env=env,stdout=subprocess.PIPE,stderr=errors,text=True)
 for line in p.stdout:
  if line.startswith('print-type-size type:'):
   keep = line.startswith('print-type-size type: `coaptic::') and any(t in line for t in ['`coaptic::App<', '::Memory<', '::Response<', '::Received<', '::Engine<', '::BodyPool<', '::DatagramPool<', '::DedupEntry`', '::DedupTable<', '::ClientInbox<', '::ClientLives<', '::DatagramScratch<', '::DedupIndex`', '::HeapOccupancy<']) or (line.startswith('print-type-size type: `{async fn body of coaptic::app::async_server::<impl coaptic::App<') and '::progress_async<' in line)
  if line.startswith('print-type-size type:') and (('async fn body' in line and 'coaptic::app::' in line and 'Service' in line) or '`coaptic::app::SendResponse' in line):keep=True
  if keep:
   size+=len(line.encode())
   if size<=2*1024*1024:out.write(line)
 code=p.wait()
assert size<=2*1024*1024,'Retained prefix incomplete'
print({'exit_code':code,'bytes':size,'source':'572036f9d6af2c3d48e957ea531974edeb137bc8','scope':'selected owner/compiler layout, not native timing or peak stack'})
raise SystemExit(code)

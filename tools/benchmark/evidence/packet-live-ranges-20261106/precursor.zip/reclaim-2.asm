
D:\CoapticCurrent\packet-live-ranges-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009bde0:     	pushq	%rbp
14009bde1:     	pushq	%r15
14009bde3:     	pushq	%r14
14009bde5:     	pushq	%r13
14009bde7:     	pushq	%r12
14009bde9:     	pushq	%rsi
14009bdea:     	pushq	%rdi
14009bdeb:     	pushq	%rbx
14009bdec:     	subq	$0x318, %rsp            # imm = 0x318
14009bdf3:     	leaq	0x80(%rsp), %rbp
14009bdfb:     	movaps	%xmm7, 0x280(%rbp)
14009be02:     	movaps	%xmm6, 0x270(%rbp)
14009be09:     	leaq	0x30(%rcx), %rdx
14009be0d:     	xorl	%r8d, %r8d
14009be10:     	xorl	%r11d, %r11d
14009be13:     	leaq	(%r11,%r11,4), %r10
14009be17:     	shlq	$0x6, %r10
14009be1b:     	addq	%rdx, %r10
14009be1e:     	movq	%r11, %r9
14009be21:     	jmp	0x14009be44 <.text+0x9ae44>
14009be23:     	nopw	%cs:(%rax,%rax)
14009be30:     	incq	%r9
14009be33:     	addq	$0x140, %r10            # imm = 0x140
14009be3a:     	cmpq	$0x4, %r9
14009be3e:     	je	0x14009bece <.text+0x9aece>
14009be44:     	cmpb	$0x1, 0x510(%rcx,%r9)
14009be4d:     	jne	0x14009be30 <.text+0x9ae30>
14009be4f:     	movq	-0x30(%r10), %rsi
14009be53:     	cmpq	$0x2, %rsi
14009be57:     	je	0x14009be30 <.text+0x9ae30>
14009be59:     	movq	(%r10), %r11
14009be5c:     	cmpl	$0x1, %esi
14009be5f:     	setne	%bl
14009be62:     	testq	%r11, %r11
14009be65:     	sete	%sil
14009be69:     	orb	%bl, %sil
14009be6c:     	cmpb	$0x1, %sil
14009be70:     	je	0x14009be30 <.text+0x9ae30>
14009be72:     	movq	0x268(%rbp), %rsi
14009be79:     	cmpq	%rsi, %r11
14009be7c:     	setae	%bl
14009be7f:     	testb	%bl, %r8b
14009be82:     	jne	0x14009beb4 <.text+0x9aeb4>
14009be84:     	movq	-0x28(%r10), %rax
14009be88:     	movd	-0x4(%r10), %xmm6
14009be8e:     	movzbl	-0x5(%r10), %edi
14009be93:     	movzbl	-0x6(%r10), %r15d
14009be98:     	movzwl	-0x8(%r10), %r12d
14009be9d:     	movl	-0xc(%r10), %r13d
14009bea1:     	movl	-0x10(%r10), %r14d
14009bea5:     	movups	-0x20(%r10), %xmm0
14009beaa:     	movaps	%xmm0, 0x240(%rbp)
14009beb1:     	movq	%r11, %rsi
14009beb4:     	movq	%rsi, 0x268(%rbp)
14009bebb:     	leaq	0x1(%r9), %r11
14009bebf:     	movb	$0x1, %r8b
14009bec2:     	cmpq	$0x3, %r9
14009bec6:     	jb	0x14009be13 <.text+0x9ae13>
14009becc:     	jmp	0x14009bed8 <.text+0x9aed8>
14009bece:     	testb	$0x1, %r8b
14009bed2:     	je	0x14009c118 <.text+0x9b118>
14009bed8:     	cmpq	$0x1, %rax
14009bedc:     	ja	0x14009bf34 <.text+0x9af34>
14009bede:     	cmpb	$0x1, 0x4420(%rcx,%rax)
14009bee6:     	jne	0x14009bf34 <.text+0x9af34>
14009bee8:     	cmpb	$0x0, 0x4422(%rcx,%rax)
14009bef0:     	jne	0x14009bf34 <.text+0x9af34>
14009bef2:     	movb	$0x0, 0x4420(%rcx,%rax)
14009befa:     	decq	0x4418(%rcx)
14009bf01:     	leaq	0x3a98(%rcx), %rdx
14009bf08:     	movq	$0x0, 0x4398(%rcx,%rax,8)
14009bf14:     	leaq	(%rax,%rax,8), %r8
14009bf18:     	leaq	(%r8,%r8,2), %r8
14009bf1c:     	addq	%rax, %r8
14009bf1f:     	movb	$0x2, 0x95a(%rdx,%r8)
14009bf28:     	leaq	(%rax,%rax,2), %rax
14009bf2c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009bf34:     	movaps	0x240(%rbp), %xmm0
14009bf3b:     	movaps	%xmm0, -0x60(%rbp)
14009bf3f:     	movl	%r14d, %esi
14009bf42:     	movl	%r14d, -0x50(%rbp)
14009bf46:     	movl	%r13d, %r14d
14009bf49:     	movl	%r13d, -0x4c(%rbp)
14009bf4d:     	movl	%r12d, %r13d
14009bf50:     	movw	%r12w, -0x48(%rbp)
14009bf55:     	movl	%r15d, %r12d
14009bf58:     	movb	%r15b, -0x46(%rbp)
14009bf5c:     	movl	%edi, %r15d
14009bf5f:     	movb	%dil, -0x45(%rbp)
14009bf63:     	movd	%xmm6, %edi
14009bf67:     	movd	%xmm6, -0x44(%rbp)
14009bf6c:     	leaq	-0x60(%rbp), %rdx
14009bf70:     	movq	%rcx, 0x260(%rbp)
14009bf77:     	callq	0x1402120f0 <.text+0x2110f0>
14009bf7c:     	xorps	%xmm7, %xmm7
14009bf7f:     	movaps	%xmm7, 0x250(%rbp)
14009bf86:     	movb	$0x0, 0x222(%rbp)
14009bf8d:     	movw	%di, 0x220(%rbp)
14009bf94:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009bf9d:     	movq	$0x0, 0x223(%rbp)
14009bfa8:     	movq	$0x8, 0x200(%rbp)
14009bfb3:     	movq	$0x0, 0x208(%rbp)
14009bfbe:     	movq	$0x1, 0x210(%rbp)
14009bfc9:     	movq	$0x0, 0x218(%rbp)
14009bfd4:     	leaq	0x230(%rbp), %rcx
14009bfdb:     	leaq	0x200(%rbp), %rdx
14009bfe2:     	leaq	0x250(%rbp), %r8
14009bfe9:     	movl	$0x10, %r9d
14009bfef:     	callq	0x14010e720 <.text+0x10d720>
14009bff4:     	cmpb	$0x0, 0x230(%rbp)
14009bffb:     	jne	0x14009c114 <.text+0x9b114>
14009c001:     	movq	0x238(%rbp), %rdi
14009c008:     	movaps	%xmm7, 0xe0(%rbp)
14009c00f:     	movaps	%xmm7, 0xf0(%rbp)
14009c016:     	movaps	%xmm7, 0x100(%rbp)
14009c01d:     	movaps	%xmm7, 0x110(%rbp)
14009c024:     	movaps	%xmm7, 0x120(%rbp)
14009c02b:     	movaps	%xmm7, 0x130(%rbp)
14009c032:     	movaps	%xmm7, 0x140(%rbp)
14009c039:     	movaps	%xmm7, 0x150(%rbp)
14009c040:     	movaps	%xmm7, 0x160(%rbp)
14009c047:     	movaps	%xmm7, 0x170(%rbp)
14009c04e:     	movaps	%xmm7, 0x180(%rbp)
14009c055:     	movaps	%xmm7, 0x190(%rbp)
14009c05c:     	movaps	%xmm7, 0x1a0(%rbp)
14009c063:     	movaps	%xmm7, 0x1b0(%rbp)
14009c06a:     	movaps	%xmm7, 0x1c0(%rbp)
14009c071:     	movaps	%xmm7, 0x1d0(%rbp)
14009c078:     	movaps	0x240(%rbp), %xmm0
14009c07f:     	movups	%xmm0, 0x1f0(%rbp)
14009c086:     	cmpq	$0x11, %rdi
14009c08a:     	jae	0x14009c13c <.text+0x9b13c>
14009c090:     	leaq	0xe0(%rbp), %rbx
14009c097:     	leaq	0x250(%rbp), %rdx
14009c09e:     	movq	%rbx, %rcx
14009c0a1:     	movq	%rdi, %r8
14009c0a4:     	callq	0x14024cc60 <.text+0x24bc60>
14009c0a9:     	movw	%di, 0x1e0(%rbp)
14009c0b0:     	movq	$0x0, -0x60(%rbp)
14009c0b8:     	movups	0x1e8(%rbp), %xmm0
14009c0bf:     	movups	%xmm0, -0x58(%rbp)
14009c0c3:     	movq	0x1f8(%rbp), %rax
14009c0ca:     	movq	%rax, -0x48(%rbp)
14009c0ce:     	movl	%esi, -0x40(%rbp)
14009c0d1:     	movl	%r14d, -0x3c(%rbp)
14009c0d5:     	movw	%r13w, -0x38(%rbp)
14009c0da:     	movb	%r12b, -0x36(%rbp)
14009c0de:     	movb	%r15b, -0x35(%rbp)
14009c0e2:     	movd	%xmm6, -0x34(%rbp)
14009c0e7:     	movq	0x268(%rbp), %rax
14009c0ee:     	movq	%rax, -0x30(%rbp)
14009c0f2:     	leaq	-0x28(%rbp), %rcx
14009c0f6:     	movl	$0x108, %r8d            # imm = 0x108
14009c0fc:     	movq	%rbx, %rdx
14009c0ff:     	callq	0x14024cc60 <.text+0x24bc60>
14009c104:     	leaq	-0x60(%rbp), %rdx
14009c108:     	movq	0x260(%rbp), %rcx
14009c10f:     	callq	0x140211e60 <.text+0x210e60>
14009c114:     	movb	$0x1, %al
14009c116:     	jmp	0x14009c11a <.text+0x9b11a>
14009c118:     	xorl	%eax, %eax
14009c11a:     	movaps	0x270(%rbp), %xmm6
14009c121:     	movaps	0x280(%rbp), %xmm7
14009c128:     	addq	$0x318, %rsp            # imm = 0x318
14009c12f:     	popq	%rbx
14009c130:     	popq	%rdi
14009c131:     	popq	%rsi
14009c132:     	popq	%r12
14009c134:     	popq	%r13
14009c136:     	popq	%r14
14009c138:     	popq	%r15
14009c13a:     	popq	%rbp
14009c13b:     	retq
14009c13c:     	leaq	0x1c8a15(%rip), %r9     # 0x140264b58
14009c143:     	movl	$0x10, %r8d
14009c149:     	xorl	%ecx, %ecx
14009c14b:     	movq	%rdi, %rdx
14009c14e:     	callq	0x14024d6b0 <.text+0x24c6b0>
14009c153:     	ud2

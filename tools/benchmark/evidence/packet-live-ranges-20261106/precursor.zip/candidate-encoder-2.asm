
D:\CoapticCurrent\packet-live-ranges-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400682f0:     	pushq	%rbp
1400682f1:     	pushq	%r15
1400682f3:     	pushq	%r14
1400682f5:     	pushq	%r13
1400682f7:     	pushq	%r12
1400682f9:     	pushq	%rsi
1400682fa:     	pushq	%rdi
1400682fb:     	pushq	%rbx
1400682fc:     	subq	$0x4f8, %rsp            # imm = 0x4F8
140068303:     	leaq	0x80(%rsp), %rbp
14006830b:     	movq	%r9, %rbx
14006830e:     	movq	%r8, %r14
140068311:     	movq	%rdx, %rdi
140068314:     	movq	%rcx, %rsi
140068317:     	movq	0x4f0(%rbp), %r12
14006831e:     	leaq	-0x10(%rbp), %rcx
140068322:     	movl	$0x400, %r8d            # imm = 0x400
140068328:     	xorl	%edx, %edx
14006832a:     	callq	0x14024cc72 <.text+0x24bc72>
14006832f:     	movq	0x8(%r12), %r13
140068334:     	movl	$0x3, %eax
140068339:     	cmpq	$0x3, %r13
14006833d:     	ja	0x140068556 <.text+0x67556>
140068343:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
14006834c:     	jne	0x140068556 <.text+0x67556>
140068352:     	movq	0x2b750(%rdi,%r13,8), %rdx
14006835a:     	cmpq	$0x4001, %rdx           # imm = 0x4001
140068361:     	jae	0x1400685b2 <.text+0x675b2>
140068367:     	movq	0x10(%r12), %rcx
14006836c:     	movq	0x18(%r12), %r15
140068371:     	movq	%r15, %r8
140068374:     	movl	$0xb, %eax
140068379:     	addq	%rcx, %r8
14006837c:     	jb	0x140068556 <.text+0x67556>
140068382:     	cmpq	$0x400, %r15            # imm = 0x400
140068389:     	ja	0x140068556 <.text+0x67556>
14006838f:     	cmpq	%rdx, %r8
140068392:     	ja	0x140068556 <.text+0x67556>
140068398:     	movq	%r13, %rax
14006839b:     	shlq	$0xe, %rax
14006839f:     	leaq	(%rdi,%rax), %rdx
1400683a3:     	addq	$0x1b750, %rdx          # imm = 0x1B750
1400683aa:     	addq	%rcx, %rdx
1400683ad:     	leaq	-0x10(%rbp), %rcx
1400683b1:     	movq	%r15, %r8
1400683b4:     	callq	0x14024cc60 <.text+0x24bc60>
1400683b9:     	cmpb	$0x0, 0x4f8(%rbp)
1400683c0:     	je	0x1400683d8 <.text+0x673d8>
1400683c2:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
1400683c9:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
1400683d2:     	jne	0x140068571 <.text+0x67571>
1400683d8:     	movq	$0x0, 0x470(%rbp)
1400683e3:     	movq	%rdi, %rcx
1400683e6:     	callq	0x140098670 <.text+0x97670>
1400683eb:     	testb	$0x1, %al
1400683ed:     	je	0x1400685a4 <.text+0x675a4>
1400683f3:     	movq	%rdx, %r13
1400683f6:     	movq	0x500(%rbp), %rdx
1400683fd:     	movzwl	0x4e8(%rbp), %ecx
140068404:     	movzbl	0x4e0(%rbp), %eax
14006840b:     	movq	(%r12), %r8
14006840f:     	movq	0x470(%rbp), %r9
140068416:     	movq	%r9, 0x438(%rbp)
14006841d:     	movq	0x468(%rbp), %r9
140068424:     	movq	%r9, 0x440(%rbp)
14006842b:     	movq	%r8, 0x448(%rbp)
140068432:     	movzbl	0x4f8(%rbp), %r8d
14006843a:     	movb	%r8b, 0x450(%rbp)
140068441:     	movups	0x40(%r14), %xmm0
140068446:     	movups	0x4c(%r14), %xmm1
14006844b:     	movups	%xmm1, 0x3fc(%rbp)
140068452:     	movaps	%xmm0, 0x3f0(%rbp)
140068459:     	leaq	0x6e(%r14), %r8
14006845d:     	movq	0x5e(%r14), %r9
140068461:     	movq	0x65(%r14), %r10
140068465:     	movq	%r10, 0x45f(%rbp)
14006846c:     	movq	%r9, 0x458(%rbp)
140068473:     	leaq	0x458(%rbp), %r9
14006847a:     	movq	%r9, 0x68(%rsp)
14006847f:     	movq	%rdx, 0x60(%rsp)
140068484:     	movq	%r14, 0x58(%rsp)
140068489:     	leaq	0x438(%rbp), %rdx
140068490:     	movq	%rdx, 0x50(%rsp)
140068495:     	movq	%r15, 0x48(%rsp)
14006849a:     	leaq	-0x10(%rbp), %rdx
14006849e:     	movq	%rdx, 0x40(%rsp)
1400684a3:     	movq	%rbx, 0x38(%rsp)
1400684a8:     	movq	%r8, 0x30(%rsp)
1400684ad:     	movw	%cx, 0x28(%rsp)
1400684b2:     	movb	%al, 0x20(%rsp)
1400684b6:     	leaq	0x418(%rbp), %rcx
1400684bd:     	leaq	0x3f0(%rbp), %r8
1400684c4:     	movq	%rdi, %rdx
1400684c7:     	movq	%r13, %r9
1400684ca:     	callq	0x140080a00 <.text+0x7fa00>
1400684cf:     	cmpb	$-0x1, 0x418(%rbp)
1400684d6:     	je	0x1400685a9 <.text+0x675a9>
1400684dc:     	cmpb	$0x1, 0x37740(%rdi,%r13)
1400684e5:     	jne	0x14006853f <.text+0x6753f>
1400684e7:     	cmpb	$0x0, 0x37760(%rdi,%r13)
1400684f0:     	jne	0x14006853f <.text+0x6753f>
1400684f2:     	movb	$0x0, 0x37740(%rdi,%r13)
1400684fb:     	decq	0x37788(%rdi)
140068502:     	leaq	0x37740(%rdi), %rax
140068509:     	movq	$0x0, 0x43610(%rdi,%r13,8)
140068515:     	leaq	(,%r13,8), %rcx
14006851d:     	addq	%r13, %rcx
140068520:     	leaq	(%rcx,%rcx,2), %rcx
140068524:     	addq	%r13, %rcx
140068527:     	movb	$0x2, 0x36a(%rax,%rcx)
14006852f:     	leaq	(,%r13,2), %rcx
140068537:     	addq	%r13, %rcx
14006853a:     	movb	$0x2, 0x5d(%rax,%rcx,8)
14006853f:     	movups	0x418(%rbp), %xmm0
140068546:     	movups	0x428(%rbp), %xmm1
14006854d:     	movups	%xmm1, 0x10(%rsi)
140068551:     	movups	%xmm0, (%rsi)
140068554:     	jmp	0x14006855d <.text+0x6755d>
140068556:     	movb	$0xa, (%rsi)
140068559:     	movq	%rax, 0x8(%rsi)
14006855d:     	addq	$0x4f8, %rsp            # imm = 0x4F8
140068564:     	popq	%rbx
140068565:     	popq	%rdi
140068566:     	popq	%rsi
140068567:     	popq	%r12
140068569:     	popq	%r13
14006856b:     	popq	%r14
14006856d:     	popq	%r15
14006856f:     	popq	%rbp
140068570:     	retq
140068571:     	addq	%rdi, %rax
140068574:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
14006857a:     	movq	0x98(%rax), %rax
140068581:     	movq	%rax, 0x468(%rbp)
140068588:     	movl	$0x1, %eax
14006858d:     	movq	%rax, 0x470(%rbp)
140068594:     	movq	%rdi, %rcx
140068597:     	callq	0x140098670 <.text+0x97670>
14006859c:     	testb	$0x1, %al
14006859e:     	jne	0x1400683f3 <.text+0x673f3>
1400685a4:     	movb	$0x9, (%rsi)
1400685a7:     	jmp	0x14006855d <.text+0x6755d>
1400685a9:     	movq	%r13, 0x8(%rsi)
1400685ad:     	movb	$-0x1, (%rsi)
1400685b0:     	jmp	0x14006855d <.text+0x6755d>
1400685b2:     	leaq	0x1ff677(%rip), %r9     # 0x140267c30
1400685b9:     	movl	$0x4000, %r8d           # imm = 0x4000
1400685bf:     	xorl	%ecx, %ecx
1400685c1:     	callq	0x14024d6b0 <.text+0x24c6b0>
1400685c6:     	ud2

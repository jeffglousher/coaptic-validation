
D:\CoapticCurrent\packet-selection-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009bec0:     	pushq	%rbp
14009bec1:     	pushq	%r15
14009bec3:     	pushq	%r14
14009bec5:     	pushq	%r13
14009bec7:     	pushq	%r12
14009bec9:     	pushq	%rsi
14009beca:     	pushq	%rdi
14009becb:     	pushq	%rbx
14009becc:     	subq	$0x308, %rsp            # imm = 0x308
14009bed3:     	leaq	0x80(%rsp), %rbp
14009bedb:     	movaps	%xmm7, 0x270(%rbp)
14009bee2:     	movaps	%xmm6, 0x260(%rbp)
14009bee9:     	leaq	0x5000(%rcx), %rax
14009bef0:     	leaq	0x30(%rcx), %r8
14009bef4:     	xorl	%r9d, %r9d
14009bef7:     	xorl	%esi, %esi
14009bef9:     	leaq	(%rsi,%rsi,4), %r11
14009befd:     	shlq	$0x6, %r11
14009bf01:     	addq	%r8, %r11
14009bf04:     	movq	%rsi, %r10
14009bf07:     	jmp	0x14009bf24 <.text+0x9af24>
14009bf09:     	nopl	(%rax)
14009bf10:     	incq	%r10
14009bf13:     	addq	$0x140, %r11            # imm = 0x140
14009bf1a:     	cmpq	$0x40, %r10
14009bf1e:     	je	0x14009bfbe <.text+0x9afbe>
14009bf24:     	cmpb	$0x1, 0x5000(%rcx,%r10)
14009bf2d:     	jne	0x14009bf10 <.text+0x9af10>
14009bf2f:     	movq	-0x30(%r11), %rdi
14009bf33:     	cmpq	$0x2, %rdi
14009bf37:     	je	0x14009bf10 <.text+0x9af10>
14009bf39:     	movq	(%r11), %rsi
14009bf3c:     	cmpl	$0x1, %edi
14009bf3f:     	setne	%bl
14009bf42:     	testq	%rsi, %rsi
14009bf45:     	sete	%dil
14009bf49:     	orb	%bl, %dil
14009bf4c:     	cmpb	$0x1, %dil
14009bf50:     	je	0x14009bf10 <.text+0x9af10>
14009bf52:     	movq	0x250(%rbp), %rdi
14009bf59:     	cmpq	%rdi, %rsi
14009bf5c:     	setae	%bl
14009bf5f:     	testb	%bl, %r9b
14009bf62:     	jne	0x14009bfa4 <.text+0x9afa4>
14009bf64:     	movd	-0x4(%r11), %xmm6
14009bf6a:     	movzbl	-0x5(%r11), %edx
14009bf6f:     	movb	%dl, 0x25f(%rbp)
14009bf75:     	movzbl	-0x6(%r11), %r15d
14009bf7a:     	movzwl	-0x8(%r11), %r12d
14009bf7f:     	movl	-0xc(%r11), %r13d
14009bf83:     	movl	-0x10(%r11), %r14d
14009bf87:     	movq	-0x18(%r11), %rdx
14009bf8b:     	movq	%rdx, 0x248(%rbp)
14009bf92:     	movq	-0x28(%r11), %rdx
14009bf96:     	movq	-0x20(%r11), %r9
14009bf9a:     	movq	%r9, 0x240(%rbp)
14009bfa1:     	movq	%rsi, %rdi
14009bfa4:     	movq	%rdi, 0x250(%rbp)
14009bfab:     	leaq	0x1(%r10), %rsi
14009bfaf:     	movb	$0x1, %r9b
14009bfb2:     	cmpq	$0x3f, %r10
14009bfb6:     	jb	0x14009bef9 <.text+0x9aef9>
14009bfbc:     	jmp	0x14009bfc8 <.text+0x9afc8>
14009bfbe:     	testb	$0x1, %r9b
14009bfc2:     	je	0x14009c240 <.text+0x9b240>
14009bfc8:     	cmpq	$0x1f, %rdx
14009bfcc:     	ja	0x14009c01f <.text+0x9b01f>
14009bfce:     	leaq	0x37740(%rcx), %r8
14009bfd5:     	cmpb	$0x1, (%r8,%rdx)
14009bfda:     	jne	0x14009c01f <.text+0x9b01f>
14009bfdc:     	cmpb	$0x0, 0x37760(%rcx,%rdx)
14009bfe4:     	jne	0x14009c01f <.text+0x9b01f>
14009bfe6:     	movb	$0x0, 0x37740(%rcx,%rdx)
14009bfee:     	decq	0x37788(%rcx)
14009bff5:     	movq	$0x0, 0x43610(%rcx,%rdx,8)
14009c001:     	leaq	(%rdx,%rdx,8), %r9
14009c005:     	leaq	(%r9,%r9,2), %r9
14009c009:     	addq	%rdx, %r9
14009c00c:     	movb	$0x2, 0x36a(%r8,%r9)
14009c015:     	leaq	(%rdx,%rdx,2), %rdx
14009c019:     	movb	$0x2, 0x5d(%r8,%rdx,8)
14009c01f:     	movd	%xmm6, %edx
14009c023:     	movl	$0x2c, %r8d
14009c029:     	movq	0x240(%rbp), %r11
14009c030:     	movq	0x248(%rbp), %rsi
14009c037:     	jmp	0x14009c053 <.text+0x9b053>
14009c039:     	nopl	(%rax)
14009c040:     	incq	%rax
14009c043:     	addq	$0x140, %r8             # imm = 0x140
14009c04a:     	cmpq	$0x502c, %r8            # imm = 0x502C
14009c051:     	je	0x14009c0ac <.text+0x9b0ac>
14009c053:     	cmpb	$0x1, (%rax)
14009c056:     	jne	0x14009c040 <.text+0x9b040>
14009c058:     	cmpl	$0x2, -0x2c(%rcx,%r8)
14009c05e:     	je	0x14009c040 <.text+0x9b040>
14009c060:     	cmpw	%dx, (%rcx,%r8)
14009c065:     	jne	0x14009c040 <.text+0x9b040>
14009c067:     	cmpl	%r14d, -0xc(%rcx,%r8)
14009c06c:     	jne	0x14009c040 <.text+0x9b040>
14009c06e:     	cmpl	%r13d, -0x8(%rcx,%r8)
14009c073:     	jne	0x14009c040 <.text+0x9b040>
14009c075:     	cmpw	%r12w, -0x4(%rcx,%r8)
14009c07b:     	jne	0x14009c040 <.text+0x9b040>
14009c07d:     	cmpb	%r15b, -0x2(%rcx,%r8)
14009c082:     	jne	0x14009c040 <.text+0x9b040>
14009c084:     	movq	-0x1c(%rcx,%r8), %r9
14009c089:     	xorq	%r11, %r9
14009c08c:     	movq	-0x14(%rcx,%r8), %r10
14009c091:     	xorq	%rsi, %r10
14009c094:     	orq	%r9, %r10
14009c097:     	jne	0x14009c040 <.text+0x9b040>
14009c099:     	movb	$0x0, (%rax)
14009c09c:     	decq	0x5048(%rcx)
14009c0a3:     	movq	$0x2, -0x2c(%rcx,%r8)
14009c0ac:     	movq	%rcx, %rsi
14009c0af:     	xorps	%xmm7, %xmm7
14009c0b2:     	movaps	%xmm7, 0x230(%rbp)
14009c0b9:     	movb	$0x0, 0x212(%rbp)
14009c0c0:     	movw	%dx, 0x210(%rbp)
14009c0c7:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
14009c0d0:     	movq	$0x0, 0x213(%rbp)
14009c0db:     	movq	$0x8, 0x1f0(%rbp)
14009c0e6:     	movq	$0x0, 0x1f8(%rbp)
14009c0f1:     	movq	$0x1, 0x200(%rbp)
14009c0fc:     	movq	$0x0, 0x208(%rbp)
14009c107:     	leaq	0x220(%rbp), %rcx
14009c10e:     	leaq	0x1f0(%rbp), %rdx
14009c115:     	leaq	0x230(%rbp), %r8
14009c11c:     	movl	$0x10, %r9d
14009c122:     	callq	0x14010e750 <.text+0x10d750>
14009c127:     	cmpb	$0x0, 0x220(%rbp)
14009c12e:     	jne	0x14009c23c <.text+0x9b23c>
14009c134:     	movq	0x228(%rbp), %rdi
14009c13b:     	movaps	%xmm7, 0xe0(%rbp)
14009c142:     	movaps	%xmm7, 0xf0(%rbp)
14009c149:     	movaps	%xmm7, 0x100(%rbp)
14009c150:     	movaps	%xmm7, 0x110(%rbp)
14009c157:     	movaps	%xmm7, 0x120(%rbp)
14009c15e:     	movaps	%xmm7, 0x130(%rbp)
14009c165:     	movaps	%xmm7, 0x140(%rbp)
14009c16c:     	movaps	%xmm7, 0x150(%rbp)
14009c173:     	movaps	%xmm7, 0x160(%rbp)
14009c17a:     	movaps	%xmm7, 0x170(%rbp)
14009c181:     	movaps	%xmm7, 0x180(%rbp)
14009c188:     	movaps	%xmm7, 0x190(%rbp)
14009c18f:     	movaps	%xmm7, 0x1a0(%rbp)
14009c196:     	movaps	%xmm7, 0x1b0(%rbp)
14009c19d:     	movaps	%xmm7, 0x1c0(%rbp)
14009c1a4:     	movaps	%xmm7, 0x1d0(%rbp)
14009c1ab:     	cmpq	$0x11, %rdi
14009c1af:     	jae	0x14009c264 <.text+0x9b264>
14009c1b5:     	leaq	0xe0(%rbp), %rbx
14009c1bc:     	leaq	0x230(%rbp), %rdx
14009c1c3:     	movq	%rbx, %rcx
14009c1c6:     	movq	%rdi, %r8
14009c1c9:     	callq	0x14024be30 <.text+0x24ae30>
14009c1ce:     	movw	%di, 0x1e0(%rbp)
14009c1d5:     	movq	$0x0, -0x60(%rbp)
14009c1dd:     	movq	0x248(%rbp), %rax
14009c1e4:     	movq	%rax, -0x48(%rbp)
14009c1e8:     	movq	0x240(%rbp), %rax
14009c1ef:     	movq	%rax, -0x50(%rbp)
14009c1f3:     	movl	%r14d, -0x40(%rbp)
14009c1f7:     	movl	%r13d, -0x3c(%rbp)
14009c1fb:     	movw	%r12w, -0x38(%rbp)
14009c200:     	movb	%r15b, -0x36(%rbp)
14009c204:     	movzbl	0x25f(%rbp), %eax
14009c20b:     	movb	%al, -0x35(%rbp)
14009c20e:     	movd	%xmm6, -0x34(%rbp)
14009c213:     	movq	0x250(%rbp), %rax
14009c21a:     	movq	%rax, -0x30(%rbp)
14009c21e:     	leaq	-0x28(%rbp), %rcx
14009c222:     	movl	$0x108, %r8d            # imm = 0x108
14009c228:     	movq	%rbx, %rdx
14009c22b:     	callq	0x14024be30 <.text+0x24ae30>
14009c230:     	leaq	-0x60(%rbp), %rdx
14009c234:     	movq	%rsi, %rcx
14009c237:     	callq	0x140210e90 <.text+0x20fe90>
14009c23c:     	movb	$0x1, %al
14009c23e:     	jmp	0x14009c242 <.text+0x9b242>
14009c240:     	xorl	%eax, %eax
14009c242:     	movaps	0x260(%rbp), %xmm6
14009c249:     	movaps	0x270(%rbp), %xmm7
14009c250:     	addq	$0x308, %rsp            # imm = 0x308
14009c257:     	popq	%rbx
14009c258:     	popq	%rdi
14009c259:     	popq	%rsi
14009c25a:     	popq	%r12
14009c25c:     	popq	%r13
14009c25e:     	popq	%r14
14009c260:     	popq	%r15
14009c262:     	popq	%rbp
14009c263:     	retq
14009c264:     	leaq	0x1c88ed(%rip), %r9     # 0x140264b58
14009c26b:     	movl	$0x10, %r8d
14009c271:     	xorl	%ecx, %ecx
14009c273:     	movq	%rdi, %rdx
14009c276:     	callq	0x14024c880 <.text+0x24b880>
14009c27b:     	ud2

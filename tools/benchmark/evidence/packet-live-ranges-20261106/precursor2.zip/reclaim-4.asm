
D:\CoapticCurrent\packet-selection-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009c280:     	pushq	%rbp
14009c281:     	pushq	%r15
14009c283:     	pushq	%r14
14009c285:     	pushq	%r13
14009c287:     	pushq	%r12
14009c289:     	pushq	%rsi
14009c28a:     	pushq	%rdi
14009c28b:     	pushq	%rbx
14009c28c:     	subq	$0x318, %rsp            # imm = 0x318
14009c293:     	leaq	0x80(%rsp), %rbp
14009c29b:     	movaps	%xmm7, 0x280(%rbp)
14009c2a2:     	movdqa	%xmm6, 0x270(%rbp)
14009c2aa:     	movq	0xe8(%rcx), %r8
14009c2b1:     	testq	%r8, %r8
14009c2b4:     	je	0x14009c694 <.text+0x9b694>
14009c2ba:     	movq	0x88(%rcx), %r11
14009c2c1:     	movq	0xe0(%rcx), %rdx
14009c2c8:     	movq	0xc8(%rcx), %rax
14009c2cf:     	movq	0xd0(%rcx), %r9
14009c2d6:     	leaq	0x30(%rax), %rsi
14009c2da:     	xorl	%ebx, %ebx
14009c2dc:     	xorl	%edi, %edi
14009c2de:     	leaq	(%rdi,%rdi,4), %r12
14009c2e2:     	shlq	$0x6, %r12
14009c2e6:     	addq	%rsi, %r12
14009c2e9:     	jmp	0x14009c303 <.text+0x9b303>
14009c2eb:     	nopl	(%rax,%rax)
14009c2f0:     	incq	%rdi
14009c2f3:     	addq	$0x140, %r12            # imm = 0x140
14009c2fa:     	cmpq	%r8, %rdi
14009c2fd:     	jae	0x14009c3cc <.text+0x9b3cc>
14009c303:     	cmpq	%r9, %rdi
14009c306:     	setb	%r15b
14009c30a:     	andb	(%rdx,%rdi), %r15b
14009c30e:     	cmpb	$0x1, %r15b
14009c312:     	jne	0x14009c2f0 <.text+0x9b2f0>
14009c314:     	movq	-0x30(%r12), %r15
14009c319:     	cmpq	$0x2, %r15
14009c31d:     	je	0x14009c2f0 <.text+0x9b2f0>
14009c31f:     	movq	(%r12), %r13
14009c323:     	cmpl	$0x1, %r15d
14009c327:     	setne	%r15b
14009c32b:     	testq	%r13, %r13
14009c32e:     	sete	%r10b
14009c332:     	orb	%r15b, %r10b
14009c335:     	cmpb	$0x1, %r10b
14009c339:     	je	0x14009c2f0 <.text+0x9b2f0>
14009c33b:     	movq	0x260(%rbp), %r15
14009c342:     	cmpq	%r15, %r13
14009c345:     	setae	%r10b
14009c349:     	testb	%r10b, %bl
14009c34c:     	jne	0x14009c3b5 <.text+0x9b3b5>
14009c34e:     	movq	-0x28(%r12), %r10
14009c353:     	movq	%r10, 0x250(%rbp)
14009c35a:     	movq	-0x20(%r12), %r10
14009c35f:     	movq	%r10, 0x248(%rbp)
14009c366:     	movd	-0x4(%r12), %xmm6
14009c36d:     	movzbl	-0x5(%r12), %r10d
14009c373:     	movb	%r10b, 0x26e(%rbp)
14009c37a:     	movzbl	-0x6(%r12), %r10d
14009c380:     	movb	%r10b, 0x26f(%rbp)
14009c387:     	movzwl	-0x8(%r12), %r10d
14009c38d:     	movw	%r10w, 0x26c(%rbp)
14009c395:     	movl	-0xc(%r12), %r10d
14009c39a:     	movl	%r10d, 0x268(%rbp)
14009c3a1:     	movl	-0x10(%r12), %r14d
14009c3a6:     	movq	-0x18(%r12), %r10
14009c3ab:     	movq	%r10, 0x258(%rbp)
14009c3b2:     	movq	%r13, %r15
14009c3b5:     	movq	%r15, 0x260(%rbp)
14009c3bc:     	incq	%rdi
14009c3bf:     	movb	$0x1, %bl
14009c3c1:     	cmpq	%r8, %rdi
14009c3c4:     	jb	0x14009c2de <.text+0x9b2de>
14009c3ca:     	jmp	0x14009c3d5 <.text+0x9b3d5>
14009c3cc:     	testb	$0x1, %bl
14009c3cf:     	je	0x14009c694 <.text+0x9b694>
14009c3d5:     	movq	0x250(%rbp), %r10
14009c3dc:     	cmpq	%r11, %r10
14009c3df:     	jae	0x14009c435 <.text+0x9b435>
14009c3e1:     	movq	0x80(%rcx), %r11
14009c3e8:     	cmpb	$0x1, (%r11,%r10)
14009c3ed:     	jne	0x14009c435 <.text+0x9b435>
14009c3ef:     	cmpq	0xa0(%rcx), %r10
14009c3f6:     	jae	0x14009c406 <.text+0x9b406>
14009c3f8:     	movq	0x98(%rcx), %rsi
14009c3ff:     	cmpb	$0x0, (%rsi,%r10)
14009c404:     	jne	0x14009c435 <.text+0x9b435>
14009c406:     	movb	$0x0, (%r11,%r10)
14009c40b:     	decq	0xb0(%rcx)
14009c412:     	cmpq	0x70(%rcx), %r10
14009c416:     	jae	0x14009c435 <.text+0x9b435>
14009c418:     	movq	0x68(%rcx), %r11
14009c41c:     	imulq	$0x58, %r10, %r10
14009c420:     	movq	$0x0, 0x30(%r11,%r10)
14009c429:     	movb	$0x2, 0x52(%r11,%r10)
14009c42f:     	movb	$0x2, 0x25(%r11,%r10)
14009c435:     	leaq	0xc0(%rcx), %rsi
14009c43c:     	movd	%xmm6, %r10d
14009c441:     	addq	$0x2c, %rax
14009c445:     	xorl	%r11d, %r11d
14009c448:     	movq	0x248(%rbp), %r15
14009c44f:     	movzbl	0x26e(%rbp), %r12d
14009c457:     	jmp	0x14009c472 <.text+0x9b472>
14009c459:     	nopl	(%rax)
14009c460:     	incq	%r11
14009c463:     	addq	$0x140, %rax            # imm = 0x140
14009c469:     	cmpq	%r11, %r8
14009c46c:     	je	0x14009c4fe <.text+0x9b4fe>
14009c472:     	cmpq	%r9, %r11
14009c475:     	setb	%bl
14009c478:     	andb	(%rdx,%r11), %bl
14009c47c:     	cmpb	$0x1, %bl
14009c47f:     	jne	0x14009c460 <.text+0x9b460>
14009c481:     	cmpl	$0x2, -0x2c(%rax)
14009c485:     	je	0x14009c460 <.text+0x9b460>
14009c487:     	cmpw	%r10w, (%rax)
14009c48b:     	jne	0x14009c460 <.text+0x9b460>
14009c48d:     	cmpl	%r14d, -0xc(%rax)
14009c491:     	jne	0x14009c460 <.text+0x9b460>
14009c493:     	movl	0x268(%rbp), %edi
14009c499:     	cmpl	%edi, -0x8(%rax)
14009c49c:     	jne	0x14009c460 <.text+0x9b460>
14009c49e:     	movzwl	0x26c(%rbp), %edi
14009c4a5:     	cmpw	%di, -0x4(%rax)
14009c4a9:     	jne	0x14009c460 <.text+0x9b460>
14009c4ab:     	movzbl	0x26f(%rbp), %ebx
14009c4b2:     	cmpb	%bl, -0x2(%rax)
14009c4b5:     	jne	0x14009c460 <.text+0x9b460>
14009c4b7:     	movq	-0x1c(%rax), %rdi
14009c4bb:     	xorq	%r15, %rdi
14009c4be:     	movq	-0x14(%rax), %rbx
14009c4c2:     	xorq	0x258(%rbp), %rbx
14009c4c9:     	orq	%rdi, %rbx
14009c4cc:     	jne	0x14009c460 <.text+0x9b460>
14009c4ce:     	cmpq	%r8, %r11
14009c4d1:     	jae	0x14009c4fe <.text+0x9b4fe>
14009c4d3:     	cmpq	0x100(%rcx), %r11
14009c4da:     	jae	0x14009c4ea <.text+0x9b4ea>
14009c4dc:     	movq	0xf8(%rcx), %r8
14009c4e3:     	cmpb	$0x0, (%r8,%r11)
14009c4e8:     	jne	0x14009c4fe <.text+0x9b4fe>
14009c4ea:     	movb	$0x0, (%rdx,%r11)
14009c4ef:     	decq	0x110(%rcx)
14009c4f6:     	movq	$0x2, -0x2c(%rax)
14009c4fe:     	xorps	%xmm7, %xmm7
14009c501:     	movaps	%xmm7, 0x230(%rbp)
14009c508:     	movb	$0x0, 0x212(%rbp)
14009c50f:     	movw	%r10w, 0x210(%rbp)
14009c517:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
14009c520:     	movq	$0x0, 0x213(%rbp)
14009c52b:     	movq	$0x8, 0x1f0(%rbp)
14009c536:     	movq	$0x0, 0x1f8(%rbp)
14009c541:     	movq	$0x1, 0x200(%rbp)
14009c54c:     	movq	$0x0, 0x208(%rbp)
14009c557:     	leaq	0x220(%rbp), %rcx
14009c55e:     	leaq	0x1f0(%rbp), %rdx
14009c565:     	leaq	0x230(%rbp), %r8
14009c56c:     	movl	$0x10, %r9d
14009c572:     	callq	0x14010e750 <.text+0x10d750>
14009c577:     	cmpb	$0x0, 0x220(%rbp)
14009c57e:     	jne	0x14009c690 <.text+0x9b690>
14009c584:     	movq	0x228(%rbp), %rdi
14009c58b:     	movaps	%xmm7, 0xe0(%rbp)
14009c592:     	movaps	%xmm7, 0xf0(%rbp)
14009c599:     	movaps	%xmm7, 0x100(%rbp)
14009c5a0:     	movaps	%xmm7, 0x110(%rbp)
14009c5a7:     	movaps	%xmm7, 0x120(%rbp)
14009c5ae:     	movaps	%xmm7, 0x130(%rbp)
14009c5b5:     	movaps	%xmm7, 0x140(%rbp)
14009c5bc:     	movaps	%xmm7, 0x150(%rbp)
14009c5c3:     	movaps	%xmm7, 0x160(%rbp)
14009c5ca:     	movaps	%xmm7, 0x170(%rbp)
14009c5d1:     	movaps	%xmm7, 0x180(%rbp)
14009c5d8:     	movaps	%xmm7, 0x190(%rbp)
14009c5df:     	movaps	%xmm7, 0x1a0(%rbp)
14009c5e6:     	movaps	%xmm7, 0x1b0(%rbp)
14009c5ed:     	movaps	%xmm7, 0x1c0(%rbp)
14009c5f4:     	movaps	%xmm7, 0x1d0(%rbp)
14009c5fb:     	cmpq	$0x11, %rdi
14009c5ff:     	jae	0x14009c6b8 <.text+0x9b6b8>
14009c605:     	leaq	0xe0(%rbp), %rbx
14009c60c:     	leaq	0x230(%rbp), %rdx
14009c613:     	movq	%rbx, %rcx
14009c616:     	movq	%rdi, %r8
14009c619:     	callq	0x14024be30 <.text+0x24ae30>
14009c61e:     	movw	%di, 0x1e0(%rbp)
14009c625:     	movq	$0x0, -0x60(%rbp)
14009c62d:     	movq	0x258(%rbp), %rax
14009c634:     	movq	%rax, -0x48(%rbp)
14009c638:     	movq	%r15, -0x50(%rbp)
14009c63c:     	movl	%r14d, -0x40(%rbp)
14009c640:     	movl	0x268(%rbp), %eax
14009c646:     	movl	%eax, -0x3c(%rbp)
14009c649:     	movzwl	0x26c(%rbp), %eax
14009c650:     	movw	%ax, -0x38(%rbp)
14009c654:     	movzbl	0x26f(%rbp), %eax
14009c65b:     	movb	%al, -0x36(%rbp)
14009c65e:     	movb	%r12b, -0x35(%rbp)
14009c662:     	movd	%xmm6, -0x34(%rbp)
14009c667:     	movq	0x260(%rbp), %rax
14009c66e:     	movq	%rax, -0x30(%rbp)
14009c672:     	leaq	-0x28(%rbp), %rcx
14009c676:     	movl	$0x108, %r8d            # imm = 0x108
14009c67c:     	movq	%rbx, %rdx
14009c67f:     	callq	0x14024be30 <.text+0x24ae30>
14009c684:     	leaq	-0x60(%rbp), %rdx
14009c688:     	movq	%rsi, %rcx
14009c68b:     	callq	0x1400116e0 <.text+0x106e0>
14009c690:     	movb	$0x1, %al
14009c692:     	jmp	0x14009c696 <.text+0x9b696>
14009c694:     	xorl	%eax, %eax
14009c696:     	movaps	0x270(%rbp), %xmm6
14009c69d:     	movaps	0x280(%rbp), %xmm7
14009c6a4:     	addq	$0x318, %rsp            # imm = 0x318
14009c6ab:     	popq	%rbx
14009c6ac:     	popq	%rdi
14009c6ad:     	popq	%rsi
14009c6ae:     	popq	%r12
14009c6b0:     	popq	%r13
14009c6b2:     	popq	%r14
14009c6b4:     	popq	%r15
14009c6b6:     	popq	%rbp
14009c6b7:     	retq
14009c6b8:     	leaq	0x1c8499(%rip), %r9     # 0x140264b58
14009c6bf:     	movl	$0x10, %r8d
14009c6c5:     	xorl	%ecx, %ecx
14009c6c7:     	movq	%rdi, %rdx
14009c6ca:     	callq	0x14024c880 <.text+0x24b880>
14009c6cf:     	ud2

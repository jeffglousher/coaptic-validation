
D:\CoapticCurrent\packet-selection-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140067f50:     	pushq	%rbp
140067f51:     	pushq	%r15
140067f53:     	pushq	%r14
140067f55:     	pushq	%r13
140067f57:     	pushq	%r12
140067f59:     	pushq	%rsi
140067f5a:     	pushq	%rdi
140067f5b:     	pushq	%rbx
140067f5c:     	subq	$0x4f8, %rsp            # imm = 0x4F8
140067f63:     	leaq	0x80(%rsp), %rbp
140067f6b:     	movq	%r9, %rbx
140067f6e:     	movq	%r8, %r14
140067f71:     	movq	%rdx, %rdi
140067f74:     	movq	%rcx, %rsi
140067f77:     	movq	0x4f0(%rbp), %r12
140067f7e:     	leaq	-0x10(%rbp), %rcx
140067f82:     	movl	$0x400, %r8d            # imm = 0x400
140067f88:     	xorl	%edx, %edx
140067f8a:     	callq	0x14024be42 <.text+0x24ae42>
140067f8f:     	movq	0x8(%r12), %r13
140067f94:     	movl	$0x3, %eax
140067f99:     	cmpq	$0x3, %r13
140067f9d:     	ja	0x1400681b6 <.text+0x671b6>
140067fa3:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
140067fac:     	jne	0x1400681b6 <.text+0x671b6>
140067fb2:     	movq	0x2b750(%rdi,%r13,8), %rdx
140067fba:     	cmpq	$0x4001, %rdx           # imm = 0x4001
140067fc1:     	jae	0x140068212 <.text+0x67212>
140067fc7:     	movq	0x10(%r12), %rcx
140067fcc:     	movq	0x18(%r12), %r15
140067fd1:     	movq	%r15, %r8
140067fd4:     	movl	$0xb, %eax
140067fd9:     	addq	%rcx, %r8
140067fdc:     	jb	0x1400681b6 <.text+0x671b6>
140067fe2:     	cmpq	$0x400, %r15            # imm = 0x400
140067fe9:     	ja	0x1400681b6 <.text+0x671b6>
140067fef:     	cmpq	%rdx, %r8
140067ff2:     	ja	0x1400681b6 <.text+0x671b6>
140067ff8:     	movq	%r13, %rax
140067ffb:     	shlq	$0xe, %rax
140067fff:     	leaq	(%rdi,%rax), %rdx
140068003:     	addq	$0x1b750, %rdx          # imm = 0x1B750
14006800a:     	addq	%rcx, %rdx
14006800d:     	leaq	-0x10(%rbp), %rcx
140068011:     	movq	%r15, %r8
140068014:     	callq	0x14024be30 <.text+0x24ae30>
140068019:     	cmpb	$0x0, 0x4f8(%rbp)
140068020:     	je	0x140068038 <.text+0x67038>
140068022:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
140068029:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
140068032:     	jne	0x1400681d1 <.text+0x671d1>
140068038:     	movq	$0x0, 0x470(%rbp)
140068043:     	movq	%rdi, %rcx
140068046:     	callq	0x1400983d0 <.text+0x973d0>
14006804b:     	testb	$0x1, %al
14006804d:     	je	0x140068204 <.text+0x67204>
140068053:     	movq	%rdx, %r13
140068056:     	movq	0x500(%rbp), %rdx
14006805d:     	movzwl	0x4e8(%rbp), %ecx
140068064:     	movzbl	0x4e0(%rbp), %eax
14006806b:     	movq	(%r12), %r8
14006806f:     	movq	0x470(%rbp), %r9
140068076:     	movq	%r9, 0x438(%rbp)
14006807d:     	movq	0x468(%rbp), %r9
140068084:     	movq	%r9, 0x440(%rbp)
14006808b:     	movq	%r8, 0x448(%rbp)
140068092:     	movzbl	0x4f8(%rbp), %r8d
14006809a:     	movb	%r8b, 0x450(%rbp)
1400680a1:     	movups	0x40(%r14), %xmm0
1400680a6:     	movups	0x4c(%r14), %xmm1
1400680ab:     	movups	%xmm1, 0x3fc(%rbp)
1400680b2:     	movaps	%xmm0, 0x3f0(%rbp)
1400680b9:     	leaq	0x6e(%r14), %r8
1400680bd:     	movq	0x5e(%r14), %r9
1400680c1:     	movq	0x65(%r14), %r10
1400680c5:     	movq	%r10, 0x45f(%rbp)
1400680cc:     	movq	%r9, 0x458(%rbp)
1400680d3:     	leaq	0x458(%rbp), %r9
1400680da:     	movq	%r9, 0x68(%rsp)
1400680df:     	movq	%rdx, 0x60(%rsp)
1400680e4:     	movq	%r14, 0x58(%rsp)
1400680e9:     	leaq	0x438(%rbp), %rdx
1400680f0:     	movq	%rdx, 0x50(%rsp)
1400680f5:     	movq	%r15, 0x48(%rsp)
1400680fa:     	leaq	-0x10(%rbp), %rdx
1400680fe:     	movq	%rdx, 0x40(%rsp)
140068103:     	movq	%rbx, 0x38(%rsp)
140068108:     	movq	%r8, 0x30(%rsp)
14006810d:     	movw	%cx, 0x28(%rsp)
140068112:     	movb	%al, 0x20(%rsp)
140068116:     	leaq	0x418(%rbp), %rcx
14006811d:     	leaq	0x3f0(%rbp), %r8
140068124:     	movq	%rdi, %rdx
140068127:     	movq	%r13, %r9
14006812a:     	callq	0x140080760 <.text+0x7f760>
14006812f:     	cmpb	$-0x1, 0x418(%rbp)
140068136:     	je	0x140068209 <.text+0x67209>
14006813c:     	cmpb	$0x1, 0x37740(%rdi,%r13)
140068145:     	jne	0x14006819f <.text+0x6719f>
140068147:     	cmpb	$0x0, 0x37760(%rdi,%r13)
140068150:     	jne	0x14006819f <.text+0x6719f>
140068152:     	movb	$0x0, 0x37740(%rdi,%r13)
14006815b:     	decq	0x37788(%rdi)
140068162:     	leaq	0x37740(%rdi), %rax
140068169:     	movq	$0x0, 0x43610(%rdi,%r13,8)
140068175:     	leaq	(,%r13,8), %rcx
14006817d:     	addq	%r13, %rcx
140068180:     	leaq	(%rcx,%rcx,2), %rcx
140068184:     	addq	%r13, %rcx
140068187:     	movb	$0x2, 0x36a(%rax,%rcx)
14006818f:     	leaq	(,%r13,2), %rcx
140068197:     	addq	%r13, %rcx
14006819a:     	movb	$0x2, 0x5d(%rax,%rcx,8)
14006819f:     	movups	0x418(%rbp), %xmm0
1400681a6:     	movups	0x428(%rbp), %xmm1
1400681ad:     	movups	%xmm1, 0x10(%rsi)
1400681b1:     	movups	%xmm0, (%rsi)
1400681b4:     	jmp	0x1400681bd <.text+0x671bd>
1400681b6:     	movb	$0xa, (%rsi)
1400681b9:     	movq	%rax, 0x8(%rsi)
1400681bd:     	addq	$0x4f8, %rsp            # imm = 0x4F8
1400681c4:     	popq	%rbx
1400681c5:     	popq	%rdi
1400681c6:     	popq	%rsi
1400681c7:     	popq	%r12
1400681c9:     	popq	%r13
1400681cb:     	popq	%r14
1400681cd:     	popq	%r15
1400681cf:     	popq	%rbp
1400681d0:     	retq
1400681d1:     	addq	%rdi, %rax
1400681d4:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
1400681da:     	movq	0x98(%rax), %rax
1400681e1:     	movq	%rax, 0x468(%rbp)
1400681e8:     	movl	$0x1, %eax
1400681ed:     	movq	%rax, 0x470(%rbp)
1400681f4:     	movq	%rdi, %rcx
1400681f7:     	callq	0x1400983d0 <.text+0x973d0>
1400681fc:     	testb	$0x1, %al
1400681fe:     	jne	0x140068053 <.text+0x67053>
140068204:     	movb	$0x9, (%rsi)
140068207:     	jmp	0x1400681bd <.text+0x671bd>
140068209:     	movq	%r13, 0x8(%rsi)
14006820d:     	movb	$-0x1, (%rsi)
140068210:     	jmp	0x1400681bd <.text+0x671bd>
140068212:     	leaq	0x1ffa17(%rip), %r9     # 0x140267c30
140068219:     	movl	$0x4000, %r8d           # imm = 0x4000
14006821f:     	xorl	%ecx, %ecx
140068221:     	callq	0x14024c880 <.text+0x24b880>
140068226:     	ud2


D:\CoapticCurrent\packet-selection-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140067c60:     	pushq	%rbp
140067c61:     	pushq	%r15
140067c63:     	pushq	%r14
140067c65:     	pushq	%r13
140067c67:     	pushq	%r12
140067c69:     	pushq	%rsi
140067c6a:     	pushq	%rdi
140067c6b:     	pushq	%rbx
140067c6c:     	subq	$0x508, %rsp            # imm = 0x508
140067c73:     	leaq	0x80(%rsp), %rbp
140067c7b:     	movq	%r9, %rbx
140067c7e:     	movq	%r8, %r14
140067c81:     	movq	%rdx, %rdi
140067c84:     	movq	%rcx, %rsi
140067c87:     	movq	0x500(%rbp), %r12
140067c8e:     	movq	%rbp, %rcx
140067c91:     	movl	$0x400, %r8d            # imm = 0x400
140067c97:     	xorl	%edx, %edx
140067c99:     	callq	0x14024be42 <.text+0x24ae42>
140067c9e:     	movq	0x8(%r12), %r13
140067ca3:     	movl	$0x3, %eax
140067ca8:     	cmpq	$0x3, %r13
140067cac:     	ja	0x140067ecf <.text+0x66ecf>
140067cb2:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
140067cbb:     	jne	0x140067ecf <.text+0x66ecf>
140067cc1:     	movq	0x2b750(%rdi,%r13,8), %rdx
140067cc9:     	cmpq	$0x4001, %rdx           # imm = 0x4001
140067cd0:     	jae	0x140067f2b <.text+0x66f2b>
140067cd6:     	movq	0x10(%r12), %rcx
140067cdb:     	movq	0x18(%r12), %r15
140067ce0:     	movq	%r15, %r8
140067ce3:     	movl	$0xb, %eax
140067ce8:     	addq	%rcx, %r8
140067ceb:     	jb	0x140067ecf <.text+0x66ecf>
140067cf1:     	cmpq	$0x400, %r15            # imm = 0x400
140067cf8:     	ja	0x140067ecf <.text+0x66ecf>
140067cfe:     	cmpq	%rdx, %r8
140067d01:     	ja	0x140067ecf <.text+0x66ecf>
140067d07:     	movq	%r13, %rax
140067d0a:     	shlq	$0xe, %rax
140067d0e:     	leaq	(%rdi,%rax), %rdx
140067d12:     	addq	$0x1b750, %rdx          # imm = 0x1B750
140067d19:     	addq	%rcx, %rdx
140067d1c:     	movq	%rbp, %rcx
140067d1f:     	movq	%r15, %r8
140067d22:     	callq	0x14024be30 <.text+0x24ae30>
140067d27:     	cmpb	$0x0, 0x508(%rbp)
140067d2e:     	je	0x140067d46 <.text+0x66d46>
140067d30:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
140067d37:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
140067d40:     	jne	0x140067eea <.text+0x66eea>
140067d46:     	movq	$0x0, 0x480(%rbp)
140067d51:     	movq	%rdi, %rcx
140067d54:     	callq	0x1400983d0 <.text+0x973d0>
140067d59:     	testb	$0x1, %al
140067d5b:     	je	0x140067f1d <.text+0x66f1d>
140067d61:     	movq	%rdx, %r13
140067d64:     	movq	0x518(%rbp), %rdx
140067d6b:     	movq	0x510(%rbp), %r8
140067d72:     	movzwl	0x4f8(%rbp), %ecx
140067d79:     	movzbl	0x4f0(%rbp), %eax
140067d80:     	movq	(%r12), %r9
140067d84:     	movq	0x480(%rbp), %r10
140067d8b:     	movq	%r10, 0x448(%rbp)
140067d92:     	movq	0x478(%rbp), %r10
140067d99:     	movq	%r10, 0x450(%rbp)
140067da0:     	movq	%r9, 0x458(%rbp)
140067da7:     	movzbl	0x508(%rbp), %r9d
140067daf:     	movb	%r9b, 0x460(%rbp)
140067db6:     	movups	0x40(%r14), %xmm0
140067dbb:     	movups	0x4c(%r14), %xmm1
140067dc0:     	movups	%xmm1, 0x40c(%rbp)
140067dc7:     	movaps	%xmm0, 0x400(%rbp)
140067dce:     	leaq	0x6e(%r14), %r9
140067dd2:     	movq	0x5e(%r14), %r10
140067dd6:     	movq	0x65(%r14), %r11
140067dda:     	movq	%r11, 0x46f(%rbp)
140067de1:     	movq	%r10, 0x468(%rbp)
140067de8:     	leaq	0x468(%rbp), %r10
140067def:     	movq	%r10, 0x70(%rsp)
140067df4:     	movq	%rdx, 0x68(%rsp)
140067df9:     	movq	%r8, 0x60(%rsp)
140067dfe:     	movq	%r14, 0x58(%rsp)
140067e03:     	leaq	0x448(%rbp), %rdx
140067e0a:     	movq	%rdx, 0x50(%rsp)
140067e0f:     	movq	%r15, 0x48(%rsp)
140067e14:     	movq	%rbp, %rdx
140067e17:     	movq	%rdx, 0x40(%rsp)
140067e1c:     	movq	%rbx, 0x38(%rsp)
140067e21:     	movq	%r9, 0x30(%rsp)
140067e26:     	movw	%cx, 0x28(%rsp)
140067e2b:     	movb	%al, 0x20(%rsp)
140067e2f:     	leaq	0x428(%rbp), %rcx
140067e36:     	leaq	0x400(%rbp), %r8
140067e3d:     	movq	%rdi, %rdx
140067e40:     	movq	%r13, %r9
140067e43:     	callq	0x14007ef70 <.text+0x7df70>
140067e48:     	cmpb	$-0x1, 0x428(%rbp)
140067e4f:     	je	0x140067f22 <.text+0x66f22>
140067e55:     	cmpb	$0x1, 0x37740(%rdi,%r13)
140067e5e:     	jne	0x140067eb8 <.text+0x66eb8>
140067e60:     	cmpb	$0x0, 0x37760(%rdi,%r13)
140067e69:     	jne	0x140067eb8 <.text+0x66eb8>
140067e6b:     	movb	$0x0, 0x37740(%rdi,%r13)
140067e74:     	decq	0x37788(%rdi)
140067e7b:     	leaq	0x37740(%rdi), %rax
140067e82:     	movq	$0x0, 0x43610(%rdi,%r13,8)
140067e8e:     	leaq	(,%r13,8), %rcx
140067e96:     	addq	%r13, %rcx
140067e99:     	leaq	(%rcx,%rcx,2), %rcx
140067e9d:     	addq	%r13, %rcx
140067ea0:     	movb	$0x2, 0x36a(%rax,%rcx)
140067ea8:     	leaq	(,%r13,2), %rcx
140067eb0:     	addq	%r13, %rcx
140067eb3:     	movb	$0x2, 0x5d(%rax,%rcx,8)
140067eb8:     	movups	0x428(%rbp), %xmm0
140067ebf:     	movups	0x438(%rbp), %xmm1
140067ec6:     	movups	%xmm1, 0x10(%rsi)
140067eca:     	movups	%xmm0, (%rsi)
140067ecd:     	jmp	0x140067ed6 <.text+0x66ed6>
140067ecf:     	movb	$0xa, (%rsi)
140067ed2:     	movq	%rax, 0x8(%rsi)
140067ed6:     	addq	$0x508, %rsp            # imm = 0x508
140067edd:     	popq	%rbx
140067ede:     	popq	%rdi
140067edf:     	popq	%rsi
140067ee0:     	popq	%r12
140067ee2:     	popq	%r13
140067ee4:     	popq	%r14
140067ee6:     	popq	%r15
140067ee8:     	popq	%rbp
140067ee9:     	retq
140067eea:     	addq	%rdi, %rax
140067eed:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
140067ef3:     	movq	0x98(%rax), %rax
140067efa:     	movq	%rax, 0x478(%rbp)
140067f01:     	movl	$0x1, %eax
140067f06:     	movq	%rax, 0x480(%rbp)
140067f0d:     	movq	%rdi, %rcx
140067f10:     	callq	0x1400983d0 <.text+0x973d0>
140067f15:     	testb	$0x1, %al
140067f17:     	jne	0x140067d61 <.text+0x66d61>
140067f1d:     	movb	$0x9, (%rsi)
140067f20:     	jmp	0x140067ed6 <.text+0x66ed6>
140067f22:     	movq	%r13, 0x8(%rsi)
140067f26:     	movb	$-0x1, (%rsi)
140067f29:     	jmp	0x140067ed6 <.text+0x66ed6>
140067f2b:     	leaq	0x1ffcfe(%rip), %r9     # 0x140267c30
140067f32:     	movl	$0x4000, %r8d           # imm = 0x4000
140067f38:     	xorl	%ecx, %ecx
140067f3a:     	callq	0x14024c880 <.text+0x24b880>
140067f3f:     	ud2

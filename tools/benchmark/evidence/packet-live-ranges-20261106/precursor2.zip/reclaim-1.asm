
D:\CoapticCurrent\packet-selection-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009b7c0:     	pushq	%rbp
14009b7c1:     	pushq	%r15
14009b7c3:     	pushq	%r14
14009b7c5:     	pushq	%r13
14009b7c7:     	pushq	%r12
14009b7c9:     	pushq	%rsi
14009b7ca:     	pushq	%rdi
14009b7cb:     	pushq	%rbx
14009b7cc:     	subq	$0x318, %rsp            # imm = 0x318
14009b7d3:     	leaq	0x80(%rsp), %rbp
14009b7db:     	movaps	%xmm7, 0x280(%rbp)
14009b7e2:     	movaps	%xmm6, 0x270(%rbp)
14009b7e9:     	leaq	0x30(%rcx), %rdx
14009b7ed:     	xorl	%r8d, %r8d
14009b7f0:     	xorl	%r11d, %r11d
14009b7f3:     	leaq	(%r11,%r11,4), %r10
14009b7f7:     	shlq	$0x6, %r10
14009b7fb:     	addq	%rdx, %r10
14009b7fe:     	movq	%r11, %r9
14009b801:     	jmp	0x14009b824 <.text+0x9a824>
14009b803:     	nopw	%cs:(%rax,%rax)
14009b810:     	incq	%r9
14009b813:     	addq	$0x140, %r10            # imm = 0x140
14009b81a:     	cmpq	$0x4, %r9
14009b81e:     	je	0x14009b8ae <.text+0x9a8ae>
14009b824:     	cmpb	$0x1, 0x510(%rcx,%r9)
14009b82d:     	jne	0x14009b810 <.text+0x9a810>
14009b82f:     	movq	-0x30(%r10), %rsi
14009b833:     	cmpq	$0x2, %rsi
14009b837:     	je	0x14009b810 <.text+0x9a810>
14009b839:     	movq	(%r10), %r11
14009b83c:     	cmpl	$0x1, %esi
14009b83f:     	setne	%bl
14009b842:     	testq	%r11, %r11
14009b845:     	sete	%sil
14009b849:     	orb	%bl, %sil
14009b84c:     	cmpb	$0x1, %sil
14009b850:     	je	0x14009b810 <.text+0x9a810>
14009b852:     	movq	0x268(%rbp), %rsi
14009b859:     	cmpq	%rsi, %r11
14009b85c:     	setae	%bl
14009b85f:     	testb	%bl, %r8b
14009b862:     	jne	0x14009b894 <.text+0x9a894>
14009b864:     	movq	-0x28(%r10), %rax
14009b868:     	movd	-0x4(%r10), %xmm6
14009b86e:     	movzbl	-0x5(%r10), %edi
14009b873:     	movzbl	-0x6(%r10), %r15d
14009b878:     	movzwl	-0x8(%r10), %r12d
14009b87d:     	movl	-0xc(%r10), %r13d
14009b881:     	movl	-0x10(%r10), %r14d
14009b885:     	movups	-0x20(%r10), %xmm0
14009b88a:     	movaps	%xmm0, 0x240(%rbp)
14009b891:     	movq	%r11, %rsi
14009b894:     	movq	%rsi, 0x268(%rbp)
14009b89b:     	leaq	0x1(%r9), %r11
14009b89f:     	movb	$0x1, %r8b
14009b8a2:     	cmpq	$0x3, %r9
14009b8a6:     	jb	0x14009b7f3 <.text+0x9a7f3>
14009b8ac:     	jmp	0x14009b8b8 <.text+0x9a8b8>
14009b8ae:     	testb	$0x1, %r8b
14009b8b2:     	je	0x14009baf8 <.text+0x9aaf8>
14009b8b8:     	cmpq	$0x1, %rax
14009b8bc:     	ja	0x14009b914 <.text+0x9a914>
14009b8be:     	cmpb	$0x1, 0x1e80(%rcx,%rax)
14009b8c6:     	jne	0x14009b914 <.text+0x9a914>
14009b8c8:     	cmpb	$0x0, 0x1e82(%rcx,%rax)
14009b8d0:     	jne	0x14009b914 <.text+0x9a914>
14009b8d2:     	movb	$0x0, 0x1e80(%rcx,%rax)
14009b8da:     	decq	0x1e78(%rcx)
14009b8e1:     	leaq	0x14f8(%rcx), %rdx
14009b8e8:     	movq	$0x0, 0x1df8(%rcx,%rax,8)
14009b8f4:     	leaq	(%rax,%rax,8), %r8
14009b8f8:     	leaq	(%r8,%r8,2), %r8
14009b8fc:     	addq	%rax, %r8
14009b8ff:     	movb	$0x2, 0x95a(%rdx,%r8)
14009b908:     	leaq	(%rax,%rax,2), %rax
14009b90c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009b914:     	movaps	0x240(%rbp), %xmm0
14009b91b:     	movaps	%xmm0, -0x60(%rbp)
14009b91f:     	movl	%r14d, %esi
14009b922:     	movl	%r14d, -0x50(%rbp)
14009b926:     	movl	%r13d, %r14d
14009b929:     	movl	%r13d, -0x4c(%rbp)
14009b92d:     	movl	%r12d, %r13d
14009b930:     	movw	%r12w, -0x48(%rbp)
14009b935:     	movl	%r15d, %r12d
14009b938:     	movb	%r15b, -0x46(%rbp)
14009b93c:     	movl	%edi, %r15d
14009b93f:     	movb	%dil, -0x45(%rbp)
14009b943:     	movd	%xmm6, %edi
14009b947:     	movd	%xmm6, -0x44(%rbp)
14009b94c:     	leaq	-0x60(%rbp), %rdx
14009b950:     	movq	%rcx, 0x260(%rbp)
14009b957:     	callq	0x1402112c0 <.text+0x2102c0>
14009b95c:     	xorps	%xmm7, %xmm7
14009b95f:     	movaps	%xmm7, 0x250(%rbp)
14009b966:     	movb	$0x0, 0x222(%rbp)
14009b96d:     	movw	%di, 0x220(%rbp)
14009b974:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009b97d:     	movq	$0x0, 0x223(%rbp)
14009b988:     	movq	$0x8, 0x200(%rbp)
14009b993:     	movq	$0x0, 0x208(%rbp)
14009b99e:     	movq	$0x1, 0x210(%rbp)
14009b9a9:     	movq	$0x0, 0x218(%rbp)
14009b9b4:     	leaq	0x230(%rbp), %rcx
14009b9bb:     	leaq	0x200(%rbp), %rdx
14009b9c2:     	leaq	0x250(%rbp), %r8
14009b9c9:     	movl	$0x10, %r9d
14009b9cf:     	callq	0x14010e750 <.text+0x10d750>
14009b9d4:     	cmpb	$0x0, 0x230(%rbp)
14009b9db:     	jne	0x14009baf4 <.text+0x9aaf4>
14009b9e1:     	movq	0x238(%rbp), %rdi
14009b9e8:     	movaps	%xmm7, 0xe0(%rbp)
14009b9ef:     	movaps	%xmm7, 0xf0(%rbp)
14009b9f6:     	movaps	%xmm7, 0x100(%rbp)
14009b9fd:     	movaps	%xmm7, 0x110(%rbp)
14009ba04:     	movaps	%xmm7, 0x120(%rbp)
14009ba0b:     	movaps	%xmm7, 0x130(%rbp)
14009ba12:     	movaps	%xmm7, 0x140(%rbp)
14009ba19:     	movaps	%xmm7, 0x150(%rbp)
14009ba20:     	movaps	%xmm7, 0x160(%rbp)
14009ba27:     	movaps	%xmm7, 0x170(%rbp)
14009ba2e:     	movaps	%xmm7, 0x180(%rbp)
14009ba35:     	movaps	%xmm7, 0x190(%rbp)
14009ba3c:     	movaps	%xmm7, 0x1a0(%rbp)
14009ba43:     	movaps	%xmm7, 0x1b0(%rbp)
14009ba4a:     	movaps	%xmm7, 0x1c0(%rbp)
14009ba51:     	movaps	%xmm7, 0x1d0(%rbp)
14009ba58:     	movaps	0x240(%rbp), %xmm0
14009ba5f:     	movups	%xmm0, 0x1f0(%rbp)
14009ba66:     	cmpq	$0x11, %rdi
14009ba6a:     	jae	0x14009bb1c <.text+0x9ab1c>
14009ba70:     	leaq	0xe0(%rbp), %rbx
14009ba77:     	leaq	0x250(%rbp), %rdx
14009ba7e:     	movq	%rbx, %rcx
14009ba81:     	movq	%rdi, %r8
14009ba84:     	callq	0x14024be30 <.text+0x24ae30>
14009ba89:     	movw	%di, 0x1e0(%rbp)
14009ba90:     	movq	$0x0, -0x60(%rbp)
14009ba98:     	movups	0x1e8(%rbp), %xmm0
14009ba9f:     	movups	%xmm0, -0x58(%rbp)
14009baa3:     	movq	0x1f8(%rbp), %rax
14009baaa:     	movq	%rax, -0x48(%rbp)
14009baae:     	movl	%esi, -0x40(%rbp)
14009bab1:     	movl	%r14d, -0x3c(%rbp)
14009bab5:     	movw	%r13w, -0x38(%rbp)
14009baba:     	movb	%r12b, -0x36(%rbp)
14009babe:     	movb	%r15b, -0x35(%rbp)
14009bac2:     	movd	%xmm6, -0x34(%rbp)
14009bac7:     	movq	0x268(%rbp), %rax
14009bace:     	movq	%rax, -0x30(%rbp)
14009bad2:     	leaq	-0x28(%rbp), %rcx
14009bad6:     	movl	$0x108, %r8d            # imm = 0x108
14009badc:     	movq	%rbx, %rdx
14009badf:     	callq	0x14024be30 <.text+0x24ae30>
14009bae4:     	leaq	-0x60(%rbp), %rdx
14009bae8:     	movq	0x260(%rbp), %rcx
14009baef:     	callq	0x140211030 <.text+0x210030>
14009baf4:     	movb	$0x1, %al
14009baf6:     	jmp	0x14009bafa <.text+0x9aafa>
14009baf8:     	xorl	%eax, %eax
14009bafa:     	movaps	0x270(%rbp), %xmm6
14009bb01:     	movaps	0x280(%rbp), %xmm7
14009bb08:     	addq	$0x318, %rsp            # imm = 0x318
14009bb0f:     	popq	%rbx
14009bb10:     	popq	%rdi
14009bb11:     	popq	%rsi
14009bb12:     	popq	%r12
14009bb14:     	popq	%r13
14009bb16:     	popq	%r14
14009bb18:     	popq	%r15
14009bb1a:     	popq	%rbp
14009bb1b:     	retq
14009bb1c:     	leaq	0x1c9035(%rip), %r9     # 0x140264b58
14009bb23:     	movl	$0x10, %r8d
14009bb29:     	xorl	%ecx, %ecx
14009bb2b:     	movq	%rdi, %rdx
14009bb2e:     	callq	0x14024c880 <.text+0x24b880>
14009bb33:     	ud2

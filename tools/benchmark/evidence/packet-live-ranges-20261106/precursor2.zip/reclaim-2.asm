
D:\CoapticCurrent\packet-selection-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009bb40:     	pushq	%rbp
14009bb41:     	pushq	%r15
14009bb43:     	pushq	%r14
14009bb45:     	pushq	%r13
14009bb47:     	pushq	%r12
14009bb49:     	pushq	%rsi
14009bb4a:     	pushq	%rdi
14009bb4b:     	pushq	%rbx
14009bb4c:     	subq	$0x318, %rsp            # imm = 0x318
14009bb53:     	leaq	0x80(%rsp), %rbp
14009bb5b:     	movaps	%xmm7, 0x280(%rbp)
14009bb62:     	movaps	%xmm6, 0x270(%rbp)
14009bb69:     	leaq	0x30(%rcx), %rdx
14009bb6d:     	xorl	%r8d, %r8d
14009bb70:     	xorl	%r11d, %r11d
14009bb73:     	leaq	(%r11,%r11,4), %r10
14009bb77:     	shlq	$0x6, %r10
14009bb7b:     	addq	%rdx, %r10
14009bb7e:     	movq	%r11, %r9
14009bb81:     	jmp	0x14009bba4 <.text+0x9aba4>
14009bb83:     	nopw	%cs:(%rax,%rax)
14009bb90:     	incq	%r9
14009bb93:     	addq	$0x140, %r10            # imm = 0x140
14009bb9a:     	cmpq	$0x4, %r9
14009bb9e:     	je	0x14009bc2e <.text+0x9ac2e>
14009bba4:     	cmpb	$0x1, 0x510(%rcx,%r9)
14009bbad:     	jne	0x14009bb90 <.text+0x9ab90>
14009bbaf:     	movq	-0x30(%r10), %rsi
14009bbb3:     	cmpq	$0x2, %rsi
14009bbb7:     	je	0x14009bb90 <.text+0x9ab90>
14009bbb9:     	movq	(%r10), %r11
14009bbbc:     	cmpl	$0x1, %esi
14009bbbf:     	setne	%bl
14009bbc2:     	testq	%r11, %r11
14009bbc5:     	sete	%sil
14009bbc9:     	orb	%bl, %sil
14009bbcc:     	cmpb	$0x1, %sil
14009bbd0:     	je	0x14009bb90 <.text+0x9ab90>
14009bbd2:     	movq	0x268(%rbp), %rsi
14009bbd9:     	cmpq	%rsi, %r11
14009bbdc:     	setae	%bl
14009bbdf:     	testb	%bl, %r8b
14009bbe2:     	jne	0x14009bc14 <.text+0x9ac14>
14009bbe4:     	movq	-0x28(%r10), %rax
14009bbe8:     	movd	-0x4(%r10), %xmm6
14009bbee:     	movzbl	-0x5(%r10), %edi
14009bbf3:     	movzbl	-0x6(%r10), %r15d
14009bbf8:     	movzwl	-0x8(%r10), %r12d
14009bbfd:     	movl	-0xc(%r10), %r13d
14009bc01:     	movl	-0x10(%r10), %r14d
14009bc05:     	movups	-0x20(%r10), %xmm0
14009bc0a:     	movaps	%xmm0, 0x240(%rbp)
14009bc11:     	movq	%r11, %rsi
14009bc14:     	movq	%rsi, 0x268(%rbp)
14009bc1b:     	leaq	0x1(%r9), %r11
14009bc1f:     	movb	$0x1, %r8b
14009bc22:     	cmpq	$0x3, %r9
14009bc26:     	jb	0x14009bb73 <.text+0x9ab73>
14009bc2c:     	jmp	0x14009bc38 <.text+0x9ac38>
14009bc2e:     	testb	$0x1, %r8b
14009bc32:     	je	0x14009be78 <.text+0x9ae78>
14009bc38:     	cmpq	$0x1, %rax
14009bc3c:     	ja	0x14009bc94 <.text+0x9ac94>
14009bc3e:     	cmpb	$0x1, 0x4420(%rcx,%rax)
14009bc46:     	jne	0x14009bc94 <.text+0x9ac94>
14009bc48:     	cmpb	$0x0, 0x4422(%rcx,%rax)
14009bc50:     	jne	0x14009bc94 <.text+0x9ac94>
14009bc52:     	movb	$0x0, 0x4420(%rcx,%rax)
14009bc5a:     	decq	0x4418(%rcx)
14009bc61:     	leaq	0x3a98(%rcx), %rdx
14009bc68:     	movq	$0x0, 0x4398(%rcx,%rax,8)
14009bc74:     	leaq	(%rax,%rax,8), %r8
14009bc78:     	leaq	(%r8,%r8,2), %r8
14009bc7c:     	addq	%rax, %r8
14009bc7f:     	movb	$0x2, 0x95a(%rdx,%r8)
14009bc88:     	leaq	(%rax,%rax,2), %rax
14009bc8c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009bc94:     	movaps	0x240(%rbp), %xmm0
14009bc9b:     	movaps	%xmm0, -0x60(%rbp)
14009bc9f:     	movl	%r14d, %esi
14009bca2:     	movl	%r14d, -0x50(%rbp)
14009bca6:     	movl	%r13d, %r14d
14009bca9:     	movl	%r13d, -0x4c(%rbp)
14009bcad:     	movl	%r12d, %r13d
14009bcb0:     	movw	%r12w, -0x48(%rbp)
14009bcb5:     	movl	%r15d, %r12d
14009bcb8:     	movb	%r15b, -0x46(%rbp)
14009bcbc:     	movl	%edi, %r15d
14009bcbf:     	movb	%dil, -0x45(%rbp)
14009bcc3:     	movd	%xmm6, %edi
14009bcc7:     	movd	%xmm6, -0x44(%rbp)
14009bccc:     	leaq	-0x60(%rbp), %rdx
14009bcd0:     	movq	%rcx, 0x260(%rbp)
14009bcd7:     	callq	0x1402112c0 <.text+0x2102c0>
14009bcdc:     	xorps	%xmm7, %xmm7
14009bcdf:     	movaps	%xmm7, 0x250(%rbp)
14009bce6:     	movb	$0x0, 0x222(%rbp)
14009bced:     	movw	%di, 0x220(%rbp)
14009bcf4:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009bcfd:     	movq	$0x0, 0x223(%rbp)
14009bd08:     	movq	$0x8, 0x200(%rbp)
14009bd13:     	movq	$0x0, 0x208(%rbp)
14009bd1e:     	movq	$0x1, 0x210(%rbp)
14009bd29:     	movq	$0x0, 0x218(%rbp)
14009bd34:     	leaq	0x230(%rbp), %rcx
14009bd3b:     	leaq	0x200(%rbp), %rdx
14009bd42:     	leaq	0x250(%rbp), %r8
14009bd49:     	movl	$0x10, %r9d
14009bd4f:     	callq	0x14010e750 <.text+0x10d750>
14009bd54:     	cmpb	$0x0, 0x230(%rbp)
14009bd5b:     	jne	0x14009be74 <.text+0x9ae74>
14009bd61:     	movq	0x238(%rbp), %rdi
14009bd68:     	movaps	%xmm7, 0xe0(%rbp)
14009bd6f:     	movaps	%xmm7, 0xf0(%rbp)
14009bd76:     	movaps	%xmm7, 0x100(%rbp)
14009bd7d:     	movaps	%xmm7, 0x110(%rbp)
14009bd84:     	movaps	%xmm7, 0x120(%rbp)
14009bd8b:     	movaps	%xmm7, 0x130(%rbp)
14009bd92:     	movaps	%xmm7, 0x140(%rbp)
14009bd99:     	movaps	%xmm7, 0x150(%rbp)
14009bda0:     	movaps	%xmm7, 0x160(%rbp)
14009bda7:     	movaps	%xmm7, 0x170(%rbp)
14009bdae:     	movaps	%xmm7, 0x180(%rbp)
14009bdb5:     	movaps	%xmm7, 0x190(%rbp)
14009bdbc:     	movaps	%xmm7, 0x1a0(%rbp)
14009bdc3:     	movaps	%xmm7, 0x1b0(%rbp)
14009bdca:     	movaps	%xmm7, 0x1c0(%rbp)
14009bdd1:     	movaps	%xmm7, 0x1d0(%rbp)
14009bdd8:     	movaps	0x240(%rbp), %xmm0
14009bddf:     	movups	%xmm0, 0x1f0(%rbp)
14009bde6:     	cmpq	$0x11, %rdi
14009bdea:     	jae	0x14009be9c <.text+0x9ae9c>
14009bdf0:     	leaq	0xe0(%rbp), %rbx
14009bdf7:     	leaq	0x250(%rbp), %rdx
14009bdfe:     	movq	%rbx, %rcx
14009be01:     	movq	%rdi, %r8
14009be04:     	callq	0x14024be30 <.text+0x24ae30>
14009be09:     	movw	%di, 0x1e0(%rbp)
14009be10:     	movq	$0x0, -0x60(%rbp)
14009be18:     	movups	0x1e8(%rbp), %xmm0
14009be1f:     	movups	%xmm0, -0x58(%rbp)
14009be23:     	movq	0x1f8(%rbp), %rax
14009be2a:     	movq	%rax, -0x48(%rbp)
14009be2e:     	movl	%esi, -0x40(%rbp)
14009be31:     	movl	%r14d, -0x3c(%rbp)
14009be35:     	movw	%r13w, -0x38(%rbp)
14009be3a:     	movb	%r12b, -0x36(%rbp)
14009be3e:     	movb	%r15b, -0x35(%rbp)
14009be42:     	movd	%xmm6, -0x34(%rbp)
14009be47:     	movq	0x268(%rbp), %rax
14009be4e:     	movq	%rax, -0x30(%rbp)
14009be52:     	leaq	-0x28(%rbp), %rcx
14009be56:     	movl	$0x108, %r8d            # imm = 0x108
14009be5c:     	movq	%rbx, %rdx
14009be5f:     	callq	0x14024be30 <.text+0x24ae30>
14009be64:     	leaq	-0x60(%rbp), %rdx
14009be68:     	movq	0x260(%rbp), %rcx
14009be6f:     	callq	0x140211030 <.text+0x210030>
14009be74:     	movb	$0x1, %al
14009be76:     	jmp	0x14009be7a <.text+0x9ae7a>
14009be78:     	xorl	%eax, %eax
14009be7a:     	movaps	0x270(%rbp), %xmm6
14009be81:     	movaps	0x280(%rbp), %xmm7
14009be88:     	addq	$0x318, %rsp            # imm = 0x318
14009be8f:     	popq	%rbx
14009be90:     	popq	%rdi
14009be91:     	popq	%rsi
14009be92:     	popq	%r12
14009be94:     	popq	%r13
14009be96:     	popq	%r14
14009be98:     	popq	%r15
14009be9a:     	popq	%rbp
14009be9b:     	retq
14009be9c:     	leaq	0x1c8cb5(%rip), %r9     # 0x140264b58
14009bea3:     	movl	$0x10, %r8d
14009bea9:     	xorl	%ecx, %ecx
14009beab:     	movq	%rdi, %rdx
14009beae:     	callq	0x14024c880 <.text+0x24b880>
14009beb3:     	ud2


D:\CoapticCurrent\packet-static-body-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009cee0:     	pushq	%rbp
14009cee1:     	pushq	%r15
14009cee3:     	pushq	%r14
14009cee5:     	pushq	%r13
14009cee7:     	pushq	%r12
14009cee9:     	pushq	%rsi
14009ceea:     	pushq	%rdi
14009ceeb:     	pushq	%rbx
14009ceec:     	subq	$0x308, %rsp            # imm = 0x308
14009cef3:     	leaq	0x80(%rsp), %rbp
14009cefb:     	movaps	%xmm7, 0x270(%rbp)
14009cf02:     	movaps	%xmm6, 0x260(%rbp)
14009cf09:     	leaq	0x5000(%rcx), %rax
14009cf10:     	leaq	0x30(%rcx), %r8
14009cf14:     	xorl	%r9d, %r9d
14009cf17:     	xorl	%esi, %esi
14009cf19:     	leaq	(%rsi,%rsi,4), %r11
14009cf1d:     	shlq	$0x6, %r11
14009cf21:     	addq	%r8, %r11
14009cf24:     	movq	%rsi, %r10
14009cf27:     	jmp	0x14009cf44 <.text+0x9bf44>
14009cf29:     	nopl	(%rax)
14009cf30:     	incq	%r10
14009cf33:     	addq	$0x140, %r11            # imm = 0x140
14009cf3a:     	cmpq	$0x40, %r10
14009cf3e:     	je	0x14009cfde <.text+0x9bfde>
14009cf44:     	cmpb	$0x1, 0x5000(%rcx,%r10)
14009cf4d:     	jne	0x14009cf30 <.text+0x9bf30>
14009cf4f:     	movq	-0x30(%r11), %rdi
14009cf53:     	cmpq	$0x2, %rdi
14009cf57:     	je	0x14009cf30 <.text+0x9bf30>
14009cf59:     	movq	(%r11), %rsi
14009cf5c:     	cmpl	$0x1, %edi
14009cf5f:     	setne	%bl
14009cf62:     	testq	%rsi, %rsi
14009cf65:     	sete	%dil
14009cf69:     	orb	%bl, %dil
14009cf6c:     	cmpb	$0x1, %dil
14009cf70:     	je	0x14009cf30 <.text+0x9bf30>
14009cf72:     	movq	0x250(%rbp), %rdi
14009cf79:     	cmpq	%rdi, %rsi
14009cf7c:     	setae	%bl
14009cf7f:     	testb	%bl, %r9b
14009cf82:     	jne	0x14009cfc4 <.text+0x9bfc4>
14009cf84:     	movd	-0x4(%r11), %xmm6
14009cf8a:     	movzbl	-0x5(%r11), %edx
14009cf8f:     	movb	%dl, 0x25f(%rbp)
14009cf95:     	movzbl	-0x6(%r11), %r15d
14009cf9a:     	movzwl	-0x8(%r11), %r12d
14009cf9f:     	movl	-0xc(%r11), %r13d
14009cfa3:     	movl	-0x10(%r11), %r14d
14009cfa7:     	movq	-0x18(%r11), %rdx
14009cfab:     	movq	%rdx, 0x248(%rbp)
14009cfb2:     	movq	-0x28(%r11), %rdx
14009cfb6:     	movq	-0x20(%r11), %r9
14009cfba:     	movq	%r9, 0x240(%rbp)
14009cfc1:     	movq	%rsi, %rdi
14009cfc4:     	movq	%rdi, 0x250(%rbp)
14009cfcb:     	leaq	0x1(%r10), %rsi
14009cfcf:     	movb	$0x1, %r9b
14009cfd2:     	cmpq	$0x3f, %r10
14009cfd6:     	jb	0x14009cf19 <.text+0x9bf19>
14009cfdc:     	jmp	0x14009cfe8 <.text+0x9bfe8>
14009cfde:     	testb	$0x1, %r9b
14009cfe2:     	je	0x14009d260 <.text+0x9c260>
14009cfe8:     	cmpq	$0x1f, %rdx
14009cfec:     	ja	0x14009d03f <.text+0x9c03f>
14009cfee:     	leaq	0x37740(%rcx), %r8
14009cff5:     	cmpb	$0x1, (%r8,%rdx)
14009cffa:     	jne	0x14009d03f <.text+0x9c03f>
14009cffc:     	cmpb	$0x0, 0x37760(%rcx,%rdx)
14009d004:     	jne	0x14009d03f <.text+0x9c03f>
14009d006:     	movb	$0x0, 0x37740(%rcx,%rdx)
14009d00e:     	decq	0x37788(%rcx)
14009d015:     	movq	$0x0, 0x43610(%rcx,%rdx,8)
14009d021:     	leaq	(%rdx,%rdx,8), %r9
14009d025:     	leaq	(%r9,%r9,2), %r9
14009d029:     	addq	%rdx, %r9
14009d02c:     	movb	$0x2, 0x36a(%r8,%r9)
14009d035:     	leaq	(%rdx,%rdx,2), %rdx
14009d039:     	movb	$0x2, 0x5d(%r8,%rdx,8)
14009d03f:     	movd	%xmm6, %edx
14009d043:     	movl	$0x2c, %r8d
14009d049:     	movq	0x240(%rbp), %r11
14009d050:     	movq	0x248(%rbp), %rsi
14009d057:     	jmp	0x14009d073 <.text+0x9c073>
14009d059:     	nopl	(%rax)
14009d060:     	incq	%rax
14009d063:     	addq	$0x140, %r8             # imm = 0x140
14009d06a:     	cmpq	$0x502c, %r8            # imm = 0x502C
14009d071:     	je	0x14009d0cc <.text+0x9c0cc>
14009d073:     	cmpb	$0x1, (%rax)
14009d076:     	jne	0x14009d060 <.text+0x9c060>
14009d078:     	cmpl	$0x2, -0x2c(%rcx,%r8)
14009d07e:     	je	0x14009d060 <.text+0x9c060>
14009d080:     	cmpw	%dx, (%rcx,%r8)
14009d085:     	jne	0x14009d060 <.text+0x9c060>
14009d087:     	cmpl	%r14d, -0xc(%rcx,%r8)
14009d08c:     	jne	0x14009d060 <.text+0x9c060>
14009d08e:     	cmpl	%r13d, -0x8(%rcx,%r8)
14009d093:     	jne	0x14009d060 <.text+0x9c060>
14009d095:     	cmpw	%r12w, -0x4(%rcx,%r8)
14009d09b:     	jne	0x14009d060 <.text+0x9c060>
14009d09d:     	cmpb	%r15b, -0x2(%rcx,%r8)
14009d0a2:     	jne	0x14009d060 <.text+0x9c060>
14009d0a4:     	movq	-0x1c(%rcx,%r8), %r9
14009d0a9:     	xorq	%r11, %r9
14009d0ac:     	movq	-0x14(%rcx,%r8), %r10
14009d0b1:     	xorq	%rsi, %r10
14009d0b4:     	orq	%r9, %r10
14009d0b7:     	jne	0x14009d060 <.text+0x9c060>
14009d0b9:     	movb	$0x0, (%rax)
14009d0bc:     	decq	0x5048(%rcx)
14009d0c3:     	movq	$0x2, -0x2c(%rcx,%r8)
14009d0cc:     	movq	%rcx, %rsi
14009d0cf:     	xorps	%xmm7, %xmm7
14009d0d2:     	movaps	%xmm7, 0x230(%rbp)
14009d0d9:     	movb	$0x0, 0x212(%rbp)
14009d0e0:     	movw	%dx, 0x210(%rbp)
14009d0e7:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
14009d0f0:     	movq	$0x0, 0x213(%rbp)
14009d0fb:     	movq	$0x8, 0x1f0(%rbp)
14009d106:     	movq	$0x0, 0x1f8(%rbp)
14009d111:     	movq	$0x1, 0x200(%rbp)
14009d11c:     	movq	$0x0, 0x208(%rbp)
14009d127:     	leaq	0x220(%rbp), %rcx
14009d12e:     	leaq	0x1f0(%rbp), %rdx
14009d135:     	leaq	0x230(%rbp), %r8
14009d13c:     	movl	$0x10, %r9d
14009d142:     	callq	0x14010dd10 <.text+0x10cd10>
14009d147:     	cmpb	$0x0, 0x220(%rbp)
14009d14e:     	jne	0x14009d25c <.text+0x9c25c>
14009d154:     	movq	0x228(%rbp), %rdi
14009d15b:     	movaps	%xmm7, 0xe0(%rbp)
14009d162:     	movaps	%xmm7, 0xf0(%rbp)
14009d169:     	movaps	%xmm7, 0x100(%rbp)
14009d170:     	movaps	%xmm7, 0x110(%rbp)
14009d177:     	movaps	%xmm7, 0x120(%rbp)
14009d17e:     	movaps	%xmm7, 0x130(%rbp)
14009d185:     	movaps	%xmm7, 0x140(%rbp)
14009d18c:     	movaps	%xmm7, 0x150(%rbp)
14009d193:     	movaps	%xmm7, 0x160(%rbp)
14009d19a:     	movaps	%xmm7, 0x170(%rbp)
14009d1a1:     	movaps	%xmm7, 0x180(%rbp)
14009d1a8:     	movaps	%xmm7, 0x190(%rbp)
14009d1af:     	movaps	%xmm7, 0x1a0(%rbp)
14009d1b6:     	movaps	%xmm7, 0x1b0(%rbp)
14009d1bd:     	movaps	%xmm7, 0x1c0(%rbp)
14009d1c4:     	movaps	%xmm7, 0x1d0(%rbp)
14009d1cb:     	cmpq	$0x11, %rdi
14009d1cf:     	jae	0x14009d284 <.text+0x9c284>
14009d1d5:     	leaq	0xe0(%rbp), %rbx
14009d1dc:     	leaq	0x230(%rbp), %rdx
14009d1e3:     	movq	%rbx, %rcx
14009d1e6:     	movq	%rdi, %r8
14009d1e9:     	callq	0x140240fc0 <.text+0x23ffc0>
14009d1ee:     	movw	%di, 0x1e0(%rbp)
14009d1f5:     	movq	$0x0, -0x60(%rbp)
14009d1fd:     	movq	0x248(%rbp), %rax
14009d204:     	movq	%rax, -0x48(%rbp)
14009d208:     	movq	0x240(%rbp), %rax
14009d20f:     	movq	%rax, -0x50(%rbp)
14009d213:     	movl	%r14d, -0x40(%rbp)
14009d217:     	movl	%r13d, -0x3c(%rbp)
14009d21b:     	movw	%r12w, -0x38(%rbp)
14009d220:     	movb	%r15b, -0x36(%rbp)
14009d224:     	movzbl	0x25f(%rbp), %eax
14009d22b:     	movb	%al, -0x35(%rbp)
14009d22e:     	movd	%xmm6, -0x34(%rbp)
14009d233:     	movq	0x250(%rbp), %rax
14009d23a:     	movq	%rax, -0x30(%rbp)
14009d23e:     	leaq	-0x28(%rbp), %rcx
14009d242:     	movl	$0x108, %r8d            # imm = 0x108
14009d248:     	movq	%rbx, %rdx
14009d24b:     	callq	0x140240fc0 <.text+0x23ffc0>
14009d250:     	leaq	-0x60(%rbp), %rdx
14009d254:     	movq	%rsi, %rcx
14009d257:     	callq	0x140204e00 <.text+0x203e00>
14009d25c:     	movb	$0x1, %al
14009d25e:     	jmp	0x14009d262 <.text+0x9c262>
14009d260:     	xorl	%eax, %eax
14009d262:     	movaps	0x260(%rbp), %xmm6
14009d269:     	movaps	0x270(%rbp), %xmm7
14009d270:     	addq	$0x308, %rsp            # imm = 0x308
14009d277:     	popq	%rbx
14009d278:     	popq	%rdi
14009d279:     	popq	%rsi
14009d27a:     	popq	%r12
14009d27c:     	popq	%r13
14009d27e:     	popq	%r14
14009d280:     	popq	%r15
14009d282:     	popq	%rbp
14009d283:     	retq
14009d284:     	leaq	0x1bc8dd(%rip), %r9     # 0x140259b68
14009d28b:     	movl	$0x10, %r8d
14009d291:     	xorl	%ecx, %ecx
14009d293:     	movq	%rdi, %rdx
14009d296:     	callq	0x140241a10 <.text+0x240a10>
14009d29b:     	ud2


D:\CoapticCurrent\packet-static-body-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009cb60:     	pushq	%rbp
14009cb61:     	pushq	%r15
14009cb63:     	pushq	%r14
14009cb65:     	pushq	%r13
14009cb67:     	pushq	%r12
14009cb69:     	pushq	%rsi
14009cb6a:     	pushq	%rdi
14009cb6b:     	pushq	%rbx
14009cb6c:     	subq	$0x318, %rsp            # imm = 0x318
14009cb73:     	leaq	0x80(%rsp), %rbp
14009cb7b:     	movaps	%xmm7, 0x280(%rbp)
14009cb82:     	movaps	%xmm6, 0x270(%rbp)
14009cb89:     	leaq	0x30(%rcx), %rdx
14009cb8d:     	xorl	%r8d, %r8d
14009cb90:     	xorl	%r11d, %r11d
14009cb93:     	leaq	(%r11,%r11,4), %r10
14009cb97:     	shlq	$0x6, %r10
14009cb9b:     	addq	%rdx, %r10
14009cb9e:     	movq	%r11, %r9
14009cba1:     	jmp	0x14009cbc4 <.text+0x9bbc4>
14009cba3:     	nopw	%cs:(%rax,%rax)
14009cbb0:     	incq	%r9
14009cbb3:     	addq	$0x140, %r10            # imm = 0x140
14009cbba:     	cmpq	$0x4, %r9
14009cbbe:     	je	0x14009cc4e <.text+0x9bc4e>
14009cbc4:     	cmpb	$0x1, 0x510(%rcx,%r9)
14009cbcd:     	jne	0x14009cbb0 <.text+0x9bbb0>
14009cbcf:     	movq	-0x30(%r10), %rsi
14009cbd3:     	cmpq	$0x2, %rsi
14009cbd7:     	je	0x14009cbb0 <.text+0x9bbb0>
14009cbd9:     	movq	(%r10), %r11
14009cbdc:     	cmpl	$0x1, %esi
14009cbdf:     	setne	%bl
14009cbe2:     	testq	%r11, %r11
14009cbe5:     	sete	%sil
14009cbe9:     	orb	%bl, %sil
14009cbec:     	cmpb	$0x1, %sil
14009cbf0:     	je	0x14009cbb0 <.text+0x9bbb0>
14009cbf2:     	movq	0x268(%rbp), %rsi
14009cbf9:     	cmpq	%rsi, %r11
14009cbfc:     	setae	%bl
14009cbff:     	testb	%bl, %r8b
14009cc02:     	jne	0x14009cc34 <.text+0x9bc34>
14009cc04:     	movq	-0x28(%r10), %rax
14009cc08:     	movd	-0x4(%r10), %xmm6
14009cc0e:     	movzbl	-0x5(%r10), %edi
14009cc13:     	movzbl	-0x6(%r10), %r15d
14009cc18:     	movzwl	-0x8(%r10), %r12d
14009cc1d:     	movl	-0xc(%r10), %r13d
14009cc21:     	movl	-0x10(%r10), %r14d
14009cc25:     	movups	-0x20(%r10), %xmm0
14009cc2a:     	movaps	%xmm0, 0x240(%rbp)
14009cc31:     	movq	%r11, %rsi
14009cc34:     	movq	%rsi, 0x268(%rbp)
14009cc3b:     	leaq	0x1(%r9), %r11
14009cc3f:     	movb	$0x1, %r8b
14009cc42:     	cmpq	$0x3, %r9
14009cc46:     	jb	0x14009cb93 <.text+0x9bb93>
14009cc4c:     	jmp	0x14009cc58 <.text+0x9bc58>
14009cc4e:     	testb	$0x1, %r8b
14009cc52:     	je	0x14009ce98 <.text+0x9be98>
14009cc58:     	cmpq	$0x1, %rax
14009cc5c:     	ja	0x14009ccb4 <.text+0x9bcb4>
14009cc5e:     	cmpb	$0x1, 0x4420(%rcx,%rax)
14009cc66:     	jne	0x14009ccb4 <.text+0x9bcb4>
14009cc68:     	cmpb	$0x0, 0x4422(%rcx,%rax)
14009cc70:     	jne	0x14009ccb4 <.text+0x9bcb4>
14009cc72:     	movb	$0x0, 0x4420(%rcx,%rax)
14009cc7a:     	decq	0x4418(%rcx)
14009cc81:     	leaq	0x3a98(%rcx), %rdx
14009cc88:     	movq	$0x0, 0x4398(%rcx,%rax,8)
14009cc94:     	leaq	(%rax,%rax,8), %r8
14009cc98:     	leaq	(%r8,%r8,2), %r8
14009cc9c:     	addq	%rax, %r8
14009cc9f:     	movb	$0x2, 0x95a(%rdx,%r8)
14009cca8:     	leaq	(%rax,%rax,2), %rax
14009ccac:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009ccb4:     	movaps	0x240(%rbp), %xmm0
14009ccbb:     	movaps	%xmm0, -0x60(%rbp)
14009ccbf:     	movl	%r14d, %esi
14009ccc2:     	movl	%r14d, -0x50(%rbp)
14009ccc6:     	movl	%r13d, %r14d
14009ccc9:     	movl	%r13d, -0x4c(%rbp)
14009cccd:     	movl	%r12d, %r13d
14009ccd0:     	movw	%r12w, -0x48(%rbp)
14009ccd5:     	movl	%r15d, %r12d
14009ccd8:     	movb	%r15b, -0x46(%rbp)
14009ccdc:     	movl	%edi, %r15d
14009ccdf:     	movb	%dil, -0x45(%rbp)
14009cce3:     	movd	%xmm6, %edi
14009cce7:     	movd	%xmm6, -0x44(%rbp)
14009ccec:     	leaq	-0x60(%rbp), %rdx
14009ccf0:     	movq	%rcx, 0x260(%rbp)
14009ccf7:     	callq	0x140205230 <.text+0x204230>
14009ccfc:     	xorps	%xmm7, %xmm7
14009ccff:     	movaps	%xmm7, 0x250(%rbp)
14009cd06:     	movb	$0x0, 0x222(%rbp)
14009cd0d:     	movw	%di, 0x220(%rbp)
14009cd14:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009cd1d:     	movq	$0x0, 0x223(%rbp)
14009cd28:     	movq	$0x8, 0x200(%rbp)
14009cd33:     	movq	$0x0, 0x208(%rbp)
14009cd3e:     	movq	$0x1, 0x210(%rbp)
14009cd49:     	movq	$0x0, 0x218(%rbp)
14009cd54:     	leaq	0x230(%rbp), %rcx
14009cd5b:     	leaq	0x200(%rbp), %rdx
14009cd62:     	leaq	0x250(%rbp), %r8
14009cd69:     	movl	$0x10, %r9d
14009cd6f:     	callq	0x14010dd10 <.text+0x10cd10>
14009cd74:     	cmpb	$0x0, 0x230(%rbp)
14009cd7b:     	jne	0x14009ce94 <.text+0x9be94>
14009cd81:     	movq	0x238(%rbp), %rdi
14009cd88:     	movaps	%xmm7, 0xe0(%rbp)
14009cd8f:     	movaps	%xmm7, 0xf0(%rbp)
14009cd96:     	movaps	%xmm7, 0x100(%rbp)
14009cd9d:     	movaps	%xmm7, 0x110(%rbp)
14009cda4:     	movaps	%xmm7, 0x120(%rbp)
14009cdab:     	movaps	%xmm7, 0x130(%rbp)
14009cdb2:     	movaps	%xmm7, 0x140(%rbp)
14009cdb9:     	movaps	%xmm7, 0x150(%rbp)
14009cdc0:     	movaps	%xmm7, 0x160(%rbp)
14009cdc7:     	movaps	%xmm7, 0x170(%rbp)
14009cdce:     	movaps	%xmm7, 0x180(%rbp)
14009cdd5:     	movaps	%xmm7, 0x190(%rbp)
14009cddc:     	movaps	%xmm7, 0x1a0(%rbp)
14009cde3:     	movaps	%xmm7, 0x1b0(%rbp)
14009cdea:     	movaps	%xmm7, 0x1c0(%rbp)
14009cdf1:     	movaps	%xmm7, 0x1d0(%rbp)
14009cdf8:     	movaps	0x240(%rbp), %xmm0
14009cdff:     	movups	%xmm0, 0x1f0(%rbp)
14009ce06:     	cmpq	$0x11, %rdi
14009ce0a:     	jae	0x14009cebc <.text+0x9bebc>
14009ce10:     	leaq	0xe0(%rbp), %rbx
14009ce17:     	leaq	0x250(%rbp), %rdx
14009ce1e:     	movq	%rbx, %rcx
14009ce21:     	movq	%rdi, %r8
14009ce24:     	callq	0x140240fc0 <.text+0x23ffc0>
14009ce29:     	movw	%di, 0x1e0(%rbp)
14009ce30:     	movq	$0x0, -0x60(%rbp)
14009ce38:     	movups	0x1e8(%rbp), %xmm0
14009ce3f:     	movups	%xmm0, -0x58(%rbp)
14009ce43:     	movq	0x1f8(%rbp), %rax
14009ce4a:     	movq	%rax, -0x48(%rbp)
14009ce4e:     	movl	%esi, -0x40(%rbp)
14009ce51:     	movl	%r14d, -0x3c(%rbp)
14009ce55:     	movw	%r13w, -0x38(%rbp)
14009ce5a:     	movb	%r12b, -0x36(%rbp)
14009ce5e:     	movb	%r15b, -0x35(%rbp)
14009ce62:     	movd	%xmm6, -0x34(%rbp)
14009ce67:     	movq	0x268(%rbp), %rax
14009ce6e:     	movq	%rax, -0x30(%rbp)
14009ce72:     	leaq	-0x28(%rbp), %rcx
14009ce76:     	movl	$0x108, %r8d            # imm = 0x108
14009ce7c:     	movq	%rbx, %rdx
14009ce7f:     	callq	0x140240fc0 <.text+0x23ffc0>
14009ce84:     	leaq	-0x60(%rbp), %rdx
14009ce88:     	movq	0x260(%rbp), %rcx
14009ce8f:     	callq	0x140204fa0 <.text+0x203fa0>
14009ce94:     	movb	$0x1, %al
14009ce96:     	jmp	0x14009ce9a <.text+0x9be9a>
14009ce98:     	xorl	%eax, %eax
14009ce9a:     	movaps	0x270(%rbp), %xmm6
14009cea1:     	movaps	0x280(%rbp), %xmm7
14009cea8:     	addq	$0x318, %rsp            # imm = 0x318
14009ceaf:     	popq	%rbx
14009ceb0:     	popq	%rdi
14009ceb1:     	popq	%rsi
14009ceb2:     	popq	%r12
14009ceb4:     	popq	%r13
14009ceb6:     	popq	%r14
14009ceb8:     	popq	%r15
14009ceba:     	popq	%rbp
14009cebb:     	retq
14009cebc:     	leaq	0x1bcca5(%rip), %r9     # 0x140259b68
14009cec3:     	movl	$0x10, %r8d
14009cec9:     	xorl	%ecx, %ecx
14009cecb:     	movq	%rdi, %rdx
14009cece:     	callq	0x140241a10 <.text+0x240a10>
14009ced3:     	ud2

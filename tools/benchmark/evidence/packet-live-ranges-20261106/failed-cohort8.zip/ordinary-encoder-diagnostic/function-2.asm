
D:\CoapticCurrent\packet-static-body-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401dbf10:     	pushq	%rbp
1401dbf11:     	movq	%rsp, %rbp
1401dbf14:     	movq	%rcx, %rax
1401dbf17:     	movl	$0x0, (%rcx)
1401dbf1d:     	movl	$0x0, 0x8(%rcx)
1401dbf24:     	movw	$0x1, 0x10(%rcx)
1401dbf2a:     	leaq	0x77f1f(%rip), %rcx     # 0x140253e50
1401dbf31:     	movq	%rcx, 0x18(%rax)
1401dbf35:     	movq	$0x400, 0x20(%rax)      # imm = 0x400
1401dbf3d:     	movb	$-0x1, 0xb5(%rax)
1401dbf44:     	movabsq	$0x65727574786966, %rcx # imm = 0x65727574786966
1401dbf4e:     	movq	%rcx, 0xc0(%rax)
1401dbf55:     	movq	$0x0, 0xc8(%rax)
1401dbf60:     	movq	$0x0, 0xd8(%rax)
1401dbf6b:     	movq	$0x0, 0x158(%rax)
1401dbf76:     	movq	$0x400, 0x1d8(%rax)     # imm = 0x400
1401dbf81:     	movl	$0x2a0001, 0x1e0(%rax)  # imm = 0x2A0001
1401dbf8b:     	movb	$0x0, 0x1e4(%rax)
1401dbf92:     	movabsq	$0x745ff000000, %rcx    # imm = 0x745FF000000
1401dbf9c:     	movq	%rcx, 0x20e(%rax)
1401dbfa3:     	popq	%rbp
1401dbfa4:     	retq

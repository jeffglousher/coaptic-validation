from pathlib import Path
import json,os,subprocess
root=Path(__file__).resolve().parent
repo=Path("C:/Users/jeffg/.t3/worktrees/coaptic/t3-a578955c")
source=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
assert not subprocess.check_output(["git","status","--porcelain"],cwd=repo)
wrapper=str(Path.home()/".cargo/bin/agent-resources.exe")
env=dict(os.environ,CARGO_INCREMENTAL="0",CARGO_BUILD_JOBS="1",CARGO_TARGET_DIR="D:/coaptic-batch-interop-target",TMP="D:/CoapticCurrent/replay-scratch-original-inbox-20261106/tmp",TEMP="D:/CoapticCurrent/replay-scratch-original-inbox-20261106/tmp")
env.pop("RUSTFLAGS",None);env.pop("RUSTC_BOOTSTRAP",None)
checks=[("tests-all-lib",["test","--locked","--offline","--all-features","--lib"]),("clippy-all",["clippy","--locked","--offline","--all-targets","--all-features","--","-D","warnings"]),("clippy-no-default",["clippy","--locked","--offline","--all-targets","--no-default-features","--","-D","warnings"])]
results=[]
for name,args in checks:
 cmd=[wrapper,"run","--id","coaptic-core-reusable","--directory",str(repo),"--","cargo",*args]
 with (root/(name+".log")).open("wb") as log:p=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=cmd,exit_code=p.returncode))
 (root/"prequalification.json").write_text(json.dumps(dict(source=source,checks=results),indent=2)+"\n")
 print(dict(name=name,exit_code=p.returncode),flush=True)
 if p.returncode:raise SystemExit(p.returncode)


D:\CoapticCurrent\packet-static-body-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009c7e0:     	pushq	%rbp
14009c7e1:     	pushq	%r15
14009c7e3:     	pushq	%r14
14009c7e5:     	pushq	%r13
14009c7e7:     	pushq	%r12
14009c7e9:     	pushq	%rsi
14009c7ea:     	pushq	%rdi
14009c7eb:     	pushq	%rbx
14009c7ec:     	subq	$0x318, %rsp            # imm = 0x318
14009c7f3:     	leaq	0x80(%rsp), %rbp
14009c7fb:     	movaps	%xmm7, 0x280(%rbp)
14009c802:     	movaps	%xmm6, 0x270(%rbp)
14009c809:     	leaq	0x30(%rcx), %rdx
14009c80d:     	xorl	%r8d, %r8d
14009c810:     	xorl	%r11d, %r11d
14009c813:     	leaq	(%r11,%r11,4), %r10
14009c817:     	shlq	$0x6, %r10
14009c81b:     	addq	%rdx, %r10
14009c81e:     	movq	%r11, %r9
14009c821:     	jmp	0x14009c844 <.text+0x9b844>
14009c823:     	nopw	%cs:(%rax,%rax)
14009c830:     	incq	%r9
14009c833:     	addq	$0x140, %r10            # imm = 0x140
14009c83a:     	cmpq	$0x4, %r9
14009c83e:     	je	0x14009c8ce <.text+0x9b8ce>
14009c844:     	cmpb	$0x1, 0x510(%rcx,%r9)
14009c84d:     	jne	0x14009c830 <.text+0x9b830>
14009c84f:     	movq	-0x30(%r10), %rsi
14009c853:     	cmpq	$0x2, %rsi
14009c857:     	je	0x14009c830 <.text+0x9b830>
14009c859:     	movq	(%r10), %r11
14009c85c:     	cmpl	$0x1, %esi
14009c85f:     	setne	%bl
14009c862:     	testq	%r11, %r11
14009c865:     	sete	%sil
14009c869:     	orb	%bl, %sil
14009c86c:     	cmpb	$0x1, %sil
14009c870:     	je	0x14009c830 <.text+0x9b830>
14009c872:     	movq	0x268(%rbp), %rsi
14009c879:     	cmpq	%rsi, %r11
14009c87c:     	setae	%bl
14009c87f:     	testb	%bl, %r8b
14009c882:     	jne	0x14009c8b4 <.text+0x9b8b4>
14009c884:     	movq	-0x28(%r10), %rax
14009c888:     	movd	-0x4(%r10), %xmm6
14009c88e:     	movzbl	-0x5(%r10), %edi
14009c893:     	movzbl	-0x6(%r10), %r15d
14009c898:     	movzwl	-0x8(%r10), %r12d
14009c89d:     	movl	-0xc(%r10), %r13d
14009c8a1:     	movl	-0x10(%r10), %r14d
14009c8a5:     	movups	-0x20(%r10), %xmm0
14009c8aa:     	movaps	%xmm0, 0x240(%rbp)
14009c8b1:     	movq	%r11, %rsi
14009c8b4:     	movq	%rsi, 0x268(%rbp)
14009c8bb:     	leaq	0x1(%r9), %r11
14009c8bf:     	movb	$0x1, %r8b
14009c8c2:     	cmpq	$0x3, %r9
14009c8c6:     	jb	0x14009c813 <.text+0x9b813>
14009c8cc:     	jmp	0x14009c8d8 <.text+0x9b8d8>
14009c8ce:     	testb	$0x1, %r8b
14009c8d2:     	je	0x14009cb18 <.text+0x9bb18>
14009c8d8:     	cmpq	$0x1, %rax
14009c8dc:     	ja	0x14009c934 <.text+0x9b934>
14009c8de:     	cmpb	$0x1, 0x1e80(%rcx,%rax)
14009c8e6:     	jne	0x14009c934 <.text+0x9b934>
14009c8e8:     	cmpb	$0x0, 0x1e82(%rcx,%rax)
14009c8f0:     	jne	0x14009c934 <.text+0x9b934>
14009c8f2:     	movb	$0x0, 0x1e80(%rcx,%rax)
14009c8fa:     	decq	0x1e78(%rcx)
14009c901:     	leaq	0x14f8(%rcx), %rdx
14009c908:     	movq	$0x0, 0x1df8(%rcx,%rax,8)
14009c914:     	leaq	(%rax,%rax,8), %r8
14009c918:     	leaq	(%r8,%r8,2), %r8
14009c91c:     	addq	%rax, %r8
14009c91f:     	movb	$0x2, 0x95a(%rdx,%r8)
14009c928:     	leaq	(%rax,%rax,2), %rax
14009c92c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009c934:     	movaps	0x240(%rbp), %xmm0
14009c93b:     	movaps	%xmm0, -0x60(%rbp)
14009c93f:     	movl	%r14d, %esi
14009c942:     	movl	%r14d, -0x50(%rbp)
14009c946:     	movl	%r13d, %r14d
14009c949:     	movl	%r13d, -0x4c(%rbp)
14009c94d:     	movl	%r12d, %r13d
14009c950:     	movw	%r12w, -0x48(%rbp)
14009c955:     	movl	%r15d, %r12d
14009c958:     	movb	%r15b, -0x46(%rbp)
14009c95c:     	movl	%edi, %r15d
14009c95f:     	movb	%dil, -0x45(%rbp)
14009c963:     	movd	%xmm6, %edi
14009c967:     	movd	%xmm6, -0x44(%rbp)
14009c96c:     	leaq	-0x60(%rbp), %rdx
14009c970:     	movq	%rcx, 0x260(%rbp)
14009c977:     	callq	0x140205230 <.text+0x204230>
14009c97c:     	xorps	%xmm7, %xmm7
14009c97f:     	movaps	%xmm7, 0x250(%rbp)
14009c986:     	movb	$0x0, 0x222(%rbp)
14009c98d:     	movw	%di, 0x220(%rbp)
14009c994:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009c99d:     	movq	$0x0, 0x223(%rbp)
14009c9a8:     	movq	$0x8, 0x200(%rbp)
14009c9b3:     	movq	$0x0, 0x208(%rbp)
14009c9be:     	movq	$0x1, 0x210(%rbp)
14009c9c9:     	movq	$0x0, 0x218(%rbp)
14009c9d4:     	leaq	0x230(%rbp), %rcx
14009c9db:     	leaq	0x200(%rbp), %rdx
14009c9e2:     	leaq	0x250(%rbp), %r8
14009c9e9:     	movl	$0x10, %r9d
14009c9ef:     	callq	0x14010dd10 <.text+0x10cd10>
14009c9f4:     	cmpb	$0x0, 0x230(%rbp)
14009c9fb:     	jne	0x14009cb14 <.text+0x9bb14>
14009ca01:     	movq	0x238(%rbp), %rdi
14009ca08:     	movaps	%xmm7, 0xe0(%rbp)
14009ca0f:     	movaps	%xmm7, 0xf0(%rbp)
14009ca16:     	movaps	%xmm7, 0x100(%rbp)
14009ca1d:     	movaps	%xmm7, 0x110(%rbp)
14009ca24:     	movaps	%xmm7, 0x120(%rbp)
14009ca2b:     	movaps	%xmm7, 0x130(%rbp)
14009ca32:     	movaps	%xmm7, 0x140(%rbp)
14009ca39:     	movaps	%xmm7, 0x150(%rbp)
14009ca40:     	movaps	%xmm7, 0x160(%rbp)
14009ca47:     	movaps	%xmm7, 0x170(%rbp)
14009ca4e:     	movaps	%xmm7, 0x180(%rbp)
14009ca55:     	movaps	%xmm7, 0x190(%rbp)
14009ca5c:     	movaps	%xmm7, 0x1a0(%rbp)
14009ca63:     	movaps	%xmm7, 0x1b0(%rbp)
14009ca6a:     	movaps	%xmm7, 0x1c0(%rbp)
14009ca71:     	movaps	%xmm7, 0x1d0(%rbp)
14009ca78:     	movaps	0x240(%rbp), %xmm0
14009ca7f:     	movups	%xmm0, 0x1f0(%rbp)
14009ca86:     	cmpq	$0x11, %rdi
14009ca8a:     	jae	0x14009cb3c <.text+0x9bb3c>
14009ca90:     	leaq	0xe0(%rbp), %rbx
14009ca97:     	leaq	0x250(%rbp), %rdx
14009ca9e:     	movq	%rbx, %rcx
14009caa1:     	movq	%rdi, %r8
14009caa4:     	callq	0x140240fc0 <.text+0x23ffc0>
14009caa9:     	movw	%di, 0x1e0(%rbp)
14009cab0:     	movq	$0x0, -0x60(%rbp)
14009cab8:     	movups	0x1e8(%rbp), %xmm0
14009cabf:     	movups	%xmm0, -0x58(%rbp)
14009cac3:     	movq	0x1f8(%rbp), %rax
14009caca:     	movq	%rax, -0x48(%rbp)
14009cace:     	movl	%esi, -0x40(%rbp)
14009cad1:     	movl	%r14d, -0x3c(%rbp)
14009cad5:     	movw	%r13w, -0x38(%rbp)
14009cada:     	movb	%r12b, -0x36(%rbp)
14009cade:     	movb	%r15b, -0x35(%rbp)
14009cae2:     	movd	%xmm6, -0x34(%rbp)
14009cae7:     	movq	0x268(%rbp), %rax
14009caee:     	movq	%rax, -0x30(%rbp)
14009caf2:     	leaq	-0x28(%rbp), %rcx
14009caf6:     	movl	$0x108, %r8d            # imm = 0x108
14009cafc:     	movq	%rbx, %rdx
14009caff:     	callq	0x140240fc0 <.text+0x23ffc0>
14009cb04:     	leaq	-0x60(%rbp), %rdx
14009cb08:     	movq	0x260(%rbp), %rcx
14009cb0f:     	callq	0x140204fa0 <.text+0x203fa0>
14009cb14:     	movb	$0x1, %al
14009cb16:     	jmp	0x14009cb1a <.text+0x9bb1a>
14009cb18:     	xorl	%eax, %eax
14009cb1a:     	movaps	0x270(%rbp), %xmm6
14009cb21:     	movaps	0x280(%rbp), %xmm7
14009cb28:     	addq	$0x318, %rsp            # imm = 0x318
14009cb2f:     	popq	%rbx
14009cb30:     	popq	%rdi
14009cb31:     	popq	%rsi
14009cb32:     	popq	%r12
14009cb34:     	popq	%r13
14009cb36:     	popq	%r14
14009cb38:     	popq	%r15
14009cb3a:     	popq	%rbp
14009cb3b:     	retq
14009cb3c:     	leaq	0x1bd025(%rip), %r9     # 0x140259b68
14009cb43:     	movl	$0x10, %r8d
14009cb49:     	xorl	%ecx, %ecx
14009cb4b:     	movq	%rdi, %rdx
14009cb4e:     	callq	0x140241a10 <.text+0x240a10>
14009cb53:     	ud2

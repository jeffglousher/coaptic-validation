
D:\CoapticCurrent\packet-static-body-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009d2a0:     	pushq	%rbp
14009d2a1:     	pushq	%r15
14009d2a3:     	pushq	%r14
14009d2a5:     	pushq	%r13
14009d2a7:     	pushq	%r12
14009d2a9:     	pushq	%rsi
14009d2aa:     	pushq	%rdi
14009d2ab:     	pushq	%rbx
14009d2ac:     	subq	$0x318, %rsp            # imm = 0x318
14009d2b3:     	leaq	0x80(%rsp), %rbp
14009d2bb:     	movaps	%xmm7, 0x280(%rbp)
14009d2c2:     	movdqa	%xmm6, 0x270(%rbp)
14009d2ca:     	movq	0xe8(%rcx), %r8
14009d2d1:     	testq	%r8, %r8
14009d2d4:     	je	0x14009d6b4 <.text+0x9c6b4>
14009d2da:     	movq	0x88(%rcx), %r11
14009d2e1:     	movq	0xe0(%rcx), %rdx
14009d2e8:     	movq	0xc8(%rcx), %rax
14009d2ef:     	movq	0xd0(%rcx), %r9
14009d2f6:     	leaq	0x30(%rax), %rsi
14009d2fa:     	xorl	%ebx, %ebx
14009d2fc:     	xorl	%edi, %edi
14009d2fe:     	leaq	(%rdi,%rdi,4), %r12
14009d302:     	shlq	$0x6, %r12
14009d306:     	addq	%rsi, %r12
14009d309:     	jmp	0x14009d323 <.text+0x9c323>
14009d30b:     	nopl	(%rax,%rax)
14009d310:     	incq	%rdi
14009d313:     	addq	$0x140, %r12            # imm = 0x140
14009d31a:     	cmpq	%r8, %rdi
14009d31d:     	jae	0x14009d3ec <.text+0x9c3ec>
14009d323:     	cmpq	%r9, %rdi
14009d326:     	setb	%r15b
14009d32a:     	andb	(%rdx,%rdi), %r15b
14009d32e:     	cmpb	$0x1, %r15b
14009d332:     	jne	0x14009d310 <.text+0x9c310>
14009d334:     	movq	-0x30(%r12), %r15
14009d339:     	cmpq	$0x2, %r15
14009d33d:     	je	0x14009d310 <.text+0x9c310>
14009d33f:     	movq	(%r12), %r13
14009d343:     	cmpl	$0x1, %r15d
14009d347:     	setne	%r15b
14009d34b:     	testq	%r13, %r13
14009d34e:     	sete	%r10b
14009d352:     	orb	%r15b, %r10b
14009d355:     	cmpb	$0x1, %r10b
14009d359:     	je	0x14009d310 <.text+0x9c310>
14009d35b:     	movq	0x260(%rbp), %r15
14009d362:     	cmpq	%r15, %r13
14009d365:     	setae	%r10b
14009d369:     	testb	%r10b, %bl
14009d36c:     	jne	0x14009d3d5 <.text+0x9c3d5>
14009d36e:     	movq	-0x28(%r12), %r10
14009d373:     	movq	%r10, 0x250(%rbp)
14009d37a:     	movq	-0x20(%r12), %r10
14009d37f:     	movq	%r10, 0x248(%rbp)
14009d386:     	movd	-0x4(%r12), %xmm6
14009d38d:     	movzbl	-0x5(%r12), %r10d
14009d393:     	movb	%r10b, 0x26e(%rbp)
14009d39a:     	movzbl	-0x6(%r12), %r10d
14009d3a0:     	movb	%r10b, 0x26f(%rbp)
14009d3a7:     	movzwl	-0x8(%r12), %r10d
14009d3ad:     	movw	%r10w, 0x26c(%rbp)
14009d3b5:     	movl	-0xc(%r12), %r10d
14009d3ba:     	movl	%r10d, 0x268(%rbp)
14009d3c1:     	movl	-0x10(%r12), %r14d
14009d3c6:     	movq	-0x18(%r12), %r10
14009d3cb:     	movq	%r10, 0x258(%rbp)
14009d3d2:     	movq	%r13, %r15
14009d3d5:     	movq	%r15, 0x260(%rbp)
14009d3dc:     	incq	%rdi
14009d3df:     	movb	$0x1, %bl
14009d3e1:     	cmpq	%r8, %rdi
14009d3e4:     	jb	0x14009d2fe <.text+0x9c2fe>
14009d3ea:     	jmp	0x14009d3f5 <.text+0x9c3f5>
14009d3ec:     	testb	$0x1, %bl
14009d3ef:     	je	0x14009d6b4 <.text+0x9c6b4>
14009d3f5:     	movq	0x250(%rbp), %r10
14009d3fc:     	cmpq	%r11, %r10
14009d3ff:     	jae	0x14009d455 <.text+0x9c455>
14009d401:     	movq	0x80(%rcx), %r11
14009d408:     	cmpb	$0x1, (%r11,%r10)
14009d40d:     	jne	0x14009d455 <.text+0x9c455>
14009d40f:     	cmpq	0xa0(%rcx), %r10
14009d416:     	jae	0x14009d426 <.text+0x9c426>
14009d418:     	movq	0x98(%rcx), %rsi
14009d41f:     	cmpb	$0x0, (%rsi,%r10)
14009d424:     	jne	0x14009d455 <.text+0x9c455>
14009d426:     	movb	$0x0, (%r11,%r10)
14009d42b:     	decq	0xb0(%rcx)
14009d432:     	cmpq	0x70(%rcx), %r10
14009d436:     	jae	0x14009d455 <.text+0x9c455>
14009d438:     	movq	0x68(%rcx), %r11
14009d43c:     	imulq	$0x58, %r10, %r10
14009d440:     	movq	$0x0, 0x30(%r11,%r10)
14009d449:     	movb	$0x2, 0x52(%r11,%r10)
14009d44f:     	movb	$0x2, 0x25(%r11,%r10)
14009d455:     	leaq	0xc0(%rcx), %rsi
14009d45c:     	movd	%xmm6, %r10d
14009d461:     	addq	$0x2c, %rax
14009d465:     	xorl	%r11d, %r11d
14009d468:     	movq	0x248(%rbp), %r15
14009d46f:     	movzbl	0x26e(%rbp), %r12d
14009d477:     	jmp	0x14009d492 <.text+0x9c492>
14009d479:     	nopl	(%rax)
14009d480:     	incq	%r11
14009d483:     	addq	$0x140, %rax            # imm = 0x140
14009d489:     	cmpq	%r11, %r8
14009d48c:     	je	0x14009d51e <.text+0x9c51e>
14009d492:     	cmpq	%r9, %r11
14009d495:     	setb	%bl
14009d498:     	andb	(%rdx,%r11), %bl
14009d49c:     	cmpb	$0x1, %bl
14009d49f:     	jne	0x14009d480 <.text+0x9c480>
14009d4a1:     	cmpl	$0x2, -0x2c(%rax)
14009d4a5:     	je	0x14009d480 <.text+0x9c480>
14009d4a7:     	cmpw	%r10w, (%rax)
14009d4ab:     	jne	0x14009d480 <.text+0x9c480>
14009d4ad:     	cmpl	%r14d, -0xc(%rax)
14009d4b1:     	jne	0x14009d480 <.text+0x9c480>
14009d4b3:     	movl	0x268(%rbp), %edi
14009d4b9:     	cmpl	%edi, -0x8(%rax)
14009d4bc:     	jne	0x14009d480 <.text+0x9c480>
14009d4be:     	movzwl	0x26c(%rbp), %edi
14009d4c5:     	cmpw	%di, -0x4(%rax)
14009d4c9:     	jne	0x14009d480 <.text+0x9c480>
14009d4cb:     	movzbl	0x26f(%rbp), %ebx
14009d4d2:     	cmpb	%bl, -0x2(%rax)
14009d4d5:     	jne	0x14009d480 <.text+0x9c480>
14009d4d7:     	movq	-0x1c(%rax), %rdi
14009d4db:     	xorq	%r15, %rdi
14009d4de:     	movq	-0x14(%rax), %rbx
14009d4e2:     	xorq	0x258(%rbp), %rbx
14009d4e9:     	orq	%rdi, %rbx
14009d4ec:     	jne	0x14009d480 <.text+0x9c480>
14009d4ee:     	cmpq	%r8, %r11
14009d4f1:     	jae	0x14009d51e <.text+0x9c51e>
14009d4f3:     	cmpq	0x100(%rcx), %r11
14009d4fa:     	jae	0x14009d50a <.text+0x9c50a>
14009d4fc:     	movq	0xf8(%rcx), %r8
14009d503:     	cmpb	$0x0, (%r8,%r11)
14009d508:     	jne	0x14009d51e <.text+0x9c51e>
14009d50a:     	movb	$0x0, (%rdx,%r11)
14009d50f:     	decq	0x110(%rcx)
14009d516:     	movq	$0x2, -0x2c(%rax)
14009d51e:     	xorps	%xmm7, %xmm7
14009d521:     	movaps	%xmm7, 0x230(%rbp)
14009d528:     	movb	$0x0, 0x212(%rbp)
14009d52f:     	movw	%r10w, 0x210(%rbp)
14009d537:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
14009d540:     	movq	$0x0, 0x213(%rbp)
14009d54b:     	movq	$0x8, 0x1f0(%rbp)
14009d556:     	movq	$0x0, 0x1f8(%rbp)
14009d561:     	movq	$0x1, 0x200(%rbp)
14009d56c:     	movq	$0x0, 0x208(%rbp)
14009d577:     	leaq	0x220(%rbp), %rcx
14009d57e:     	leaq	0x1f0(%rbp), %rdx
14009d585:     	leaq	0x230(%rbp), %r8
14009d58c:     	movl	$0x10, %r9d
14009d592:     	callq	0x14010dd10 <.text+0x10cd10>
14009d597:     	cmpb	$0x0, 0x220(%rbp)
14009d59e:     	jne	0x14009d6b0 <.text+0x9c6b0>
14009d5a4:     	movq	0x228(%rbp), %rdi
14009d5ab:     	movaps	%xmm7, 0xe0(%rbp)
14009d5b2:     	movaps	%xmm7, 0xf0(%rbp)
14009d5b9:     	movaps	%xmm7, 0x100(%rbp)
14009d5c0:     	movaps	%xmm7, 0x110(%rbp)
14009d5c7:     	movaps	%xmm7, 0x120(%rbp)
14009d5ce:     	movaps	%xmm7, 0x130(%rbp)
14009d5d5:     	movaps	%xmm7, 0x140(%rbp)
14009d5dc:     	movaps	%xmm7, 0x150(%rbp)
14009d5e3:     	movaps	%xmm7, 0x160(%rbp)
14009d5ea:     	movaps	%xmm7, 0x170(%rbp)
14009d5f1:     	movaps	%xmm7, 0x180(%rbp)
14009d5f8:     	movaps	%xmm7, 0x190(%rbp)
14009d5ff:     	movaps	%xmm7, 0x1a0(%rbp)
14009d606:     	movaps	%xmm7, 0x1b0(%rbp)
14009d60d:     	movaps	%xmm7, 0x1c0(%rbp)
14009d614:     	movaps	%xmm7, 0x1d0(%rbp)
14009d61b:     	cmpq	$0x11, %rdi
14009d61f:     	jae	0x14009d6d8 <.text+0x9c6d8>
14009d625:     	leaq	0xe0(%rbp), %rbx
14009d62c:     	leaq	0x230(%rbp), %rdx
14009d633:     	movq	%rbx, %rcx
14009d636:     	movq	%rdi, %r8
14009d639:     	callq	0x140240fc0 <.text+0x23ffc0>
14009d63e:     	movw	%di, 0x1e0(%rbp)
14009d645:     	movq	$0x0, -0x60(%rbp)
14009d64d:     	movq	0x258(%rbp), %rax
14009d654:     	movq	%rax, -0x48(%rbp)
14009d658:     	movq	%r15, -0x50(%rbp)
14009d65c:     	movl	%r14d, -0x40(%rbp)
14009d660:     	movl	0x268(%rbp), %eax
14009d666:     	movl	%eax, -0x3c(%rbp)
14009d669:     	movzwl	0x26c(%rbp), %eax
14009d670:     	movw	%ax, -0x38(%rbp)
14009d674:     	movzbl	0x26f(%rbp), %eax
14009d67b:     	movb	%al, -0x36(%rbp)
14009d67e:     	movb	%r12b, -0x35(%rbp)
14009d682:     	movd	%xmm6, -0x34(%rbp)
14009d687:     	movq	0x260(%rbp), %rax
14009d68e:     	movq	%rax, -0x30(%rbp)
14009d692:     	leaq	-0x28(%rbp), %rcx
14009d696:     	movl	$0x108, %r8d            # imm = 0x108
14009d69c:     	movq	%rbx, %rdx
14009d69f:     	callq	0x140240fc0 <.text+0x23ffc0>
14009d6a4:     	leaq	-0x60(%rbp), %rdx
14009d6a8:     	movq	%rsi, %rcx
14009d6ab:     	callq	0x1400116e0 <.text+0x106e0>
14009d6b0:     	movb	$0x1, %al
14009d6b2:     	jmp	0x14009d6b6 <.text+0x9c6b6>
14009d6b4:     	xorl	%eax, %eax
14009d6b6:     	movaps	0x270(%rbp), %xmm6
14009d6bd:     	movaps	0x280(%rbp), %xmm7
14009d6c4:     	addq	$0x318, %rsp            # imm = 0x318
14009d6cb:     	popq	%rbx
14009d6cc:     	popq	%rdi
14009d6cd:     	popq	%rsi
14009d6ce:     	popq	%r12
14009d6d0:     	popq	%r13
14009d6d2:     	popq	%r14
14009d6d4:     	popq	%r15
14009d6d6:     	popq	%rbp
14009d6d7:     	retq
14009d6d8:     	leaq	0x1bc489(%rip), %r9     # 0x140259b68
14009d6df:     	movl	$0x10, %r8d
14009d6e5:     	xorl	%ecx, %ecx
14009d6e7:     	movq	%rdi, %rdx
14009d6ea:     	callq	0x140241a10 <.text+0x240a10>
14009d6ef:     	ud2

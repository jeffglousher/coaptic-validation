
D:\CoapticCurrent\packet-lazy-location-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401df630:     	pushq	%rbp
1401df631:     	movq	%rsp, %rbp
1401df634:     	movq	%rcx, %rax
1401df637:     	movl	$0x0, (%rcx)
1401df63d:     	movl	$0x0, 0x8(%rcx)
1401df644:     	movw	$0x1, 0x10(%rcx)
1401df64a:     	leaq	0x847ff(%rip), %rcx     # 0x140263e50
1401df651:     	movq	%rcx, 0x18(%rax)
1401df655:     	movq	$0x400, 0x20(%rax)      # imm = 0x400
1401df65d:     	movb	$-0x1, 0xb5(%rax)
1401df664:     	movabsq	$0x65727574786966, %rcx # imm = 0x65727574786966
1401df66e:     	movq	%rcx, 0xc0(%rax)
1401df675:     	movq	$0x0, 0xc8(%rax)
1401df680:     	movq	$0x0, 0xd8(%rax)
1401df68b:     	movq	$0x0, 0x158(%rax)
1401df696:     	movq	$0x400, 0x1d8(%rax)     # imm = 0x400
1401df6a1:     	movl	$0x2a0001, 0x1e0(%rax)  # imm = 0x2A0001
1401df6ab:     	movb	$0x0, 0x1e4(%rax)
1401df6b2:     	movabsq	$0x745ff000000, %rcx    # imm = 0x745FF000000
1401df6bc:     	movq	%rcx, 0x20e(%rax)
1401df6c3:     	popq	%rbp
1401df6c4:     	retq

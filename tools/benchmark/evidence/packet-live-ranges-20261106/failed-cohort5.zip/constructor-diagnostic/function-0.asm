
D:\CoapticCurrent\packet-lazy-location-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401a0ef0:     	pushq	%rbp
1401a0ef1:     	pushq	%r15
1401a0ef3:     	pushq	%r14
1401a0ef5:     	pushq	%r13
1401a0ef7:     	pushq	%r12
1401a0ef9:     	pushq	%rsi
1401a0efa:     	pushq	%rdi
1401a0efb:     	pushq	%rbx
1401a0efc:     	subq	$0x128, %rsp            # imm = 0x128
1401a0f03:     	leaq	0x80(%rsp), %rbp
1401a0f0b:     	movq	$-0x2, 0xa0(%rbp)
1401a0f16:     	movq	%r9, %rdi
1401a0f19:     	movq	%r8, %r14
1401a0f1c:     	movq	%rcx, %rsi
1401a0f1f:     	movzbl	0x138(%rbp), %r15d
1401a0f27:     	movq	0x110(%rbp), %r8
1401a0f2e:     	movq	(%rdx), %rax
1401a0f31:     	movq	0x8(%rdx), %r12
1401a0f35:     	movq	(%rax), %rbx
1401a0f38:     	movq	0x10(%rdx), %r13
1401a0f3c:     	movb	%r15b, 0x9f(%rbp)
1401a0f43:     	movq	%r9, %rcx
1401a0f46:     	callq	*0x50(%r8)
1401a0f4a:     	movq	%r13, %rcx
1401a0f4d:     	subq	%r12, %rcx
1401a0f50:     	setb	%dl
1401a0f53:     	cmpq	$0x401, %rcx            # imm = 0x401
1401a0f5a:     	setae	%r8b
1401a0f5e:     	orb	%dl, %r8b
1401a0f61:     	je	0x1401a0f73 <.text+0x19ff73>
1401a0f63:     	movb	$0xa, (%rsi)
1401a0f66:     	movq	$0xb, 0x8(%rsi)
1401a0f6e:     	jmp	0x1401a10c8 <.text+0x1a00c8>
1401a0f73:     	cmpq	$-0x1, 0x230(%r14)
1401a0f7b:     	je	0x1401a10be <.text+0x1a00be>
1401a0f81:     	cmpq	0x258(%r14), %rbx
1401a0f88:     	jae	0x1401a10be <.text+0x1a00be>
1401a0f8e:     	movq	0x120(%rbp), %r9
1401a0f95:     	cmpq	0x88(%r14), %r9
1401a0f9c:     	jae	0x1401a10be <.text+0x1a00be>
1401a0fa2:     	movq	0x250(%r14), %rdx
1401a0fa9:     	movb	$0x1, %r10b
1401a0fac:     	cmpb	$0x1, (%rdx,%rbx)
1401a0fb0:     	jne	0x1401a10c1 <.text+0x1a00c1>
1401a0fb6:     	cmpq	0x240(%r14), %rbx
1401a0fbd:     	jae	0x1401a10c1 <.text+0x1a00c1>
1401a0fc3:     	movq	0x238(%r14), %r11
1401a0fca:     	imulq	$0x2d0, %rbx, %rbx      # imm = 0x2D0
1401a0fd1:     	movq	0x2c0(%r11,%rbx), %r8
1401a0fd9:     	movq	0x2c8(%r11,%rbx), %rdx
1401a0fe1:     	cmpq	%r8, %rdx
1401a0fe4:     	ja	0x1401a120d <.text+0x1a020d>
1401a0fea:     	movq	0x80(%r14), %r8
1401a0ff1:     	cmpb	$0x1, (%r8,%r9)
1401a0ff6:     	jne	0x1401a10c1 <.text+0x1a00c1>
1401a0ffc:     	cmpq	0xa0(%r14), %r9
1401a1003:     	jae	0x1401a10be <.text+0x1a00be>
1401a1009:     	movq	0x98(%r14), %r8
1401a1010:     	movb	$0x3, %r10b
1401a1013:     	cmpb	$0x0, (%r8,%r9)
1401a1018:     	jne	0x1401a10c1 <.text+0x1a00c1>
1401a101e:     	addq	%rbx, %r11
1401a1021:     	movq	0x2b8(%r11), %r10
1401a1028:     	addq	%r9, %r8
1401a102b:     	movb	$0x1, (%r8)
1401a102f:     	cmpq	0x70(%r14), %r9
1401a1033:     	jae	0x1401a10be <.text+0x1a00be>
1401a1039:     	movq	%r10, 0x50(%rbp)
1401a103d:     	movq	0x68(%r14), %r11
1401a1041:     	imulq	$0x58, %r9, %r10
1401a1045:     	movq	0x8(%r11,%r10), %rbx
1401a104a:     	movq	%rbx, 0x48(%rbp)
1401a104e:     	movq	0x10(%r11,%r10), %rbx
1401a1053:     	addq	%r10, %r11
1401a1056:     	addq	$0x30, %r11
1401a105a:     	movb	%bl, 0x90(%rbp)
1401a1060:     	movq	%rbx, %r10
1401a1063:     	shrq	$0x8, %r10
1401a1067:     	movq	%rbx, %r14
1401a106a:     	shrq	$0x38, %r14
1401a106e:     	movb	%r14b, 0x2f(%rbp)
1401a1072:     	shrq	$0x28, %rbx
1401a1076:     	movw	%bx, 0x2d(%rbp)
1401a107a:     	movl	%r10d, 0x29(%rbp)
1401a107e:     	movq	%r11, 0x88(%rbp)
1401a1085:     	movq	%r11, 0x30(%rbp)
1401a1089:     	movq	%r8, 0x38(%rbp)
1401a108d:     	movq	%r9, 0x40(%rbp)
1401a1091:     	movq	0x48(%rbp), %r9
1401a1095:     	movq	%r9, %r11
1401a1098:     	movq	%r9, 0x20(%rbp)
1401a109c:     	movzbl	0x90(%rbp), %r9d
1401a10a4:     	movb	%r9b, 0x28(%rbp)
1401a10a8:     	cmpq	%rdx, %r13
1401a10ab:     	jbe	0x1401a10dc <.text+0x1a00dc>
1401a10ad:     	movb	$0xa, (%rsi)
1401a10b0:     	movq	$0xb, 0x8(%rsi)
1401a10b8:     	movb	$0x0, (%r8)
1401a10bc:     	jmp	0x1401a10c8 <.text+0x1a00c8>
1401a10be:     	xorl	%r10d, %r10d
1401a10c1:     	movb	$0x7, (%rsi)
1401a10c4:     	movb	%r10b, 0x1(%rsi)
1401a10c8:     	addq	$0x128, %rsp            # imm = 0x128
1401a10cf:     	popq	%rbx
1401a10d0:     	popq	%rdi
1401a10d1:     	popq	%rsi
1401a10d2:     	popq	%r12
1401a10d4:     	popq	%r13
1401a10d6:     	popq	%r14
1401a10d8:     	popq	%r15
1401a10da:     	popq	%rbp
1401a10db:     	retq
1401a10dc:     	movq	%r8, 0x90(%rbp)
1401a10e3:     	movq	0x130(%rbp), %rdx
1401a10ea:     	movq	0x128(%rbp), %r13
1401a10f1:     	movq	0x118(%rbp), %r9
1401a10f8:     	movq	0x50(%rbp), %r8
1401a10fc:     	addq	%r12, %r8
1401a10ff:     	movzbl	0x2c(%rdx), %r10d
1401a1104:     	movzbl	0x22(%rdx), %ebx
1401a1108:     	movzwl	0x20(%rdx), %r14d
1401a110d:     	movzbl	0x2b(%rdx), %r12d
1401a1112:     	movb	%r12b, 0x1b(%rbp)
1401a1116:     	movq	0x23(%rdx), %r12
1401a111a:     	movq	%r12, 0x13(%rbp)
1401a111e:     	movups	(%rdx), %xmm0
1401a1121:     	movups	%xmm0, -0x10(%rbp)
1401a1125:     	movq	%r8, (%rbp)
1401a1129:     	movq	%rcx, 0x8(%rbp)
1401a112d:     	movw	%r14w, 0x10(%rbp)
1401a1132:     	movb	%bl, 0x12(%rbp)
1401a1135:     	movb	%r10b, 0x1c(%rbp)
1401a1139:     	movq	0x28(%rbp), %r14
1401a113d:     	movq	%r14, %r8
1401a1140:     	testb	%al, %al
1401a1142:     	je	0x1401a1171 <.text+0x1a0171>
1401a1144:     	cmpq	$0x5c0, %r14            # imm = 0x5C0
1401a114b:     	movl	$0x5c0, %r8d            # imm = 0x5C0
1401a1151:     	cmovbq	%r14, %r8
1401a1155:     	movq	0x88(%rbp), %rax
1401a115c:     	movq	(%rax), %rdx
1401a115f:     	cmpq	%r14, %rdx
1401a1162:     	ja	0x1401a121d <.text+0x1a021d>
1401a1168:     	testq	%rdx, %rdx
1401a116b:     	jne	0x1401a1231 <.text+0x1a0231>
1401a1171:     	movl	0x14(%r9), %r9d
1401a1175:     	movq	%r8, 0x40(%rsp)
1401a117a:     	movq	%r11, 0x38(%rsp)
1401a117f:     	movb	%r15b, 0x30(%rsp)
1401a1184:     	leaq	-0x10(%rbp), %rax
1401a1188:     	movq	%rax, 0x28(%rsp)
1401a118d:     	movq	%r13, 0x20(%rsp)
1401a1192:     	leaq	0x58(%rbp), %rcx
1401a1196:     	movq	%rdi, %rdx
1401a1199:     	movq	0x110(%rbp), %r8
1401a11a0:     	callq	0x140103ee0 <.text+0x102ee0>
1401a11a5:     	nop
1401a11a6:     	movzbl	0x58(%rbp), %eax
1401a11aa:     	cmpb	$-0x1, %al
1401a11ac:     	je	0x1401a11db <.text+0x1a01db>
1401a11ae:     	movl	0x59(%rbp), %ecx
1401a11b1:     	movl	0x5c(%rbp), %edx
1401a11b4:     	movl	%edx, 0x4(%rsi)
1401a11b7:     	movl	%ecx, 0x1(%rsi)
1401a11ba:     	movq	0x60(%rbp), %rcx
1401a11be:     	movups	0x68(%rbp), %xmm0
1401a11c2:     	movups	%xmm0, 0x10(%rsi)
1401a11c6:     	movb	%al, (%rsi)
1401a11c8:     	movq	%rcx, 0x8(%rsi)
1401a11cc:     	movq	0x90(%rbp), %rax
1401a11d3:     	movb	$0x0, (%rax)
1401a11d6:     	jmp	0x1401a10c8 <.text+0x1a00c8>
1401a11db:     	movq	0x60(%rbp), %rax
1401a11df:     	cmpq	%r14, %rax
1401a11e2:     	movq	0x90(%rbp), %rcx
1401a11e9:     	jbe	0x1401a11f8 <.text+0x1a01f8>
1401a11eb:     	movw	$0x207, (%rsi)          # imm = 0x207
1401a11f0:     	movb	$0x0, (%rcx)
1401a11f3:     	jmp	0x1401a10c8 <.text+0x1a00c8>
1401a11f8:     	movq	0x88(%rbp), %rdx
1401a11ff:     	movq	%rax, (%rdx)
1401a1202:     	movb	$0x0, (%rcx)
1401a1205:     	movb	$-0x1, (%rsi)
1401a1208:     	jmp	0x1401a10c8 <.text+0x1a00c8>
1401a120d:     	leaq	0xcbbc4(%rip), %r9      # 0x14026cdd8
1401a1214:     	xorl	%ecx, %ecx
1401a1216:     	callq	0x140248670 <.text+0x247670>
1401a121b:     	ud2
1401a121d:     	leaq	0xbef84(%rip), %r9      # 0x1402601a8
1401a1224:     	xorl	%ecx, %ecx
1401a1226:     	movq	%r14, %r8
1401a1229:     	callq	0x140248670 <.text+0x247670>
1401a122e:     	nop
1401a122f:     	ud2
1401a1231:     	movq	%rdi, 0x58(%rbp)
1401a1235:     	movq	0x110(%rbp), %rax
1401a123c:     	movq	%rax, 0x60(%rbp)
1401a1240:     	movq	%r9, 0x68(%rbp)
1401a1244:     	movq	%r13, 0x70(%rbp)
1401a1248:     	leaq	-0x10(%rbp), %rax
1401a124c:     	movq	%rax, 0x78(%rbp)
1401a1250:     	leaq	0x9f(%rbp), %rax
1401a1257:     	movq	%rax, 0x80(%rbp)
1401a125e:     	leaq	-0x30(%rbp), %rcx
1401a1262:     	leaq	0x20(%rbp), %rdx
1401a1266:     	leaq	0x58(%rbp), %r9
1401a126a:     	callq	0x14025d460 <.text+0x25c460>
1401a126f:     	nop
1401a1270:     	cmpb	$-0x1, -0x30(%rbp)
1401a1274:     	je	0x1401a128a <.text+0x1a028a>
1401a1276:     	movups	-0x30(%rbp), %xmm0
1401a127a:     	movups	-0x20(%rbp), %xmm1
1401a127e:     	movups	%xmm1, 0x10(%rsi)
1401a1282:     	movups	%xmm0, (%rsi)
1401a1285:     	jmp	0x1401a11cc <.text+0x1a01cc>
1401a128a:     	movq	0x90(%rbp), %rcx
1401a1291:     	jmp	0x1401a1202 <.text+0x1a0202>
1401a1296:     	nopw	%cs:(%rax,%rax)
1401a12a0:     	movq	%rdx, 0x10(%rsp)
1401a12a5:     	pushq	%rbp
1401a12a6:     	pushq	%r15
1401a12a8:     	pushq	%r14
1401a12aa:     	pushq	%r13
1401a12ac:     	pushq	%r12
1401a12ae:     	pushq	%rsi
1401a12af:     	pushq	%rdi
1401a12b0:     	pushq	%rbx
1401a12b1:     	subq	$0x48, %rsp
1401a12b5:     	leaq	0x80(%rdx), %rbp
1401a12bc:     	movq	0x90(%rbp), %rax
1401a12c3:     	movb	$0x0, (%rax)
1401a12c6:     	addq	$0x48, %rsp
1401a12ca:     	popq	%rbx
1401a12cb:     	popq	%rdi
1401a12cc:     	popq	%rsi
1401a12cd:     	popq	%r12
1401a12cf:     	popq	%r13
1401a12d1:     	popq	%r14
1401a12d3:     	popq	%r15
1401a12d5:     	popq	%rbp
1401a12d6:     	retq

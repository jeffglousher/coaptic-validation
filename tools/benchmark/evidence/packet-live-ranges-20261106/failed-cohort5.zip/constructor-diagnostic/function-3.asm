
D:\CoapticCurrent\packet-lazy-location-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401df740:     	pushq	%rbp
1401df741:     	movq	%rsp, %rbp
1401df744:     	movq	%rcx, %rax
1401df747:     	movl	$0x0, (%rcx)
1401df74d:     	movl	$0x0, 0x8(%rcx)
1401df754:     	movw	$0x1, 0x10(%rcx)
1401df75a:     	leaq	0x846ef(%rip), %rcx     # 0x140263e50
1401df761:     	movq	%rcx, 0x18(%rax)
1401df765:     	movq	$0x4000, 0x20(%rax)     # imm = 0x4000
1401df76d:     	movb	$-0x1, 0xb5(%rax)
1401df774:     	movabsq	$0x65727574786966, %rcx # imm = 0x65727574786966
1401df77e:     	movq	%rcx, 0xc0(%rax)
1401df785:     	movq	$0x0, 0xc8(%rax)
1401df790:     	movq	$0x0, 0xd8(%rax)
1401df79b:     	movq	$0x0, 0x158(%rax)
1401df7a6:     	movq	$0x4000, 0x1d8(%rax)    # imm = 0x4000
1401df7b1:     	movl	$0x2a0001, 0x1e0(%rax)  # imm = 0x2A0001
1401df7bb:     	movb	$0x0, 0x1e4(%rax)
1401df7c2:     	movabsq	$0x745ff000000, %rcx    # imm = 0x745FF000000
1401df7cc:     	movq	%rcx, 0x20e(%rax)
1401df7d3:     	popq	%rbp
1401df7d4:     	retq

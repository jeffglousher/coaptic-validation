
D:\CoapticCurrent\packet-lazy-location-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401a12e0:     	pushq	%rbp
1401a12e1:     	pushq	%r15
1401a12e3:     	pushq	%r14
1401a12e5:     	pushq	%r13
1401a12e7:     	pushq	%r12
1401a12e9:     	pushq	%rsi
1401a12ea:     	pushq	%rdi
1401a12eb:     	pushq	%rbx
1401a12ec:     	subq	$0x118, %rsp            # imm = 0x118
1401a12f3:     	leaq	0x80(%rsp), %rbp
1401a12fb:     	movq	$-0x2, 0x90(%rbp)
1401a1306:     	movzbl	0x120(%rbp), %r10d
1401a130e:     	movq	(%rdx), %rax
1401a1311:     	movq	(%rax), %rax
1401a1314:     	movb	%r10b, 0x8e(%rbp)
1401a131b:     	cmpl	$0x0, 0x1c0(%r9)
1401a1323:     	movq	0x8(%rdx), %rdi
1401a1327:     	setne	%r11b
1401a132b:     	cmpq	$-0x1, (%r9)
1401a132f:     	movq	0x10(%rdx), %r15
1401a1333:     	setne	%r14b
1401a1337:     	movq	%r15, %rsi
1401a133a:     	subq	%rdi, %rsi
1401a133d:     	setb	%dl
1401a1340:     	cmpq	$0x401, %rsi            # imm = 0x401
1401a1347:     	setae	%bl
1401a134a:     	orb	%dl, %bl
1401a134c:     	je	0x1401a135e <.text+0x1a035e>
1401a134e:     	movb	$0xa, (%rcx)
1401a1351:     	movq	$0xb, 0x8(%rcx)
1401a1359:     	jmp	0x1401a14cb <.text+0x1a04cb>
1401a135e:     	cmpq	$-0x1, 0x230(%r8)
1401a1366:     	je	0x1401a14c3 <.text+0x1a04c3>
1401a136c:     	cmpq	0x258(%r8), %rax
1401a1373:     	jae	0x1401a14c3 <.text+0x1a04c3>
1401a1379:     	movq	0x108(%rbp), %rdx
1401a1380:     	cmpq	0x88(%r8), %rdx
1401a1387:     	jae	0x1401a14c3 <.text+0x1a04c3>
1401a138d:     	movq	0x250(%r8), %rdx
1401a1394:     	movb	$0x1, %bl
1401a1396:     	cmpb	$0x1, (%rdx,%rax)
1401a139a:     	jne	0x1401a14c5 <.text+0x1a04c5>
1401a13a0:     	cmpq	0x240(%r8), %rax
1401a13a7:     	jae	0x1401a14c5 <.text+0x1a04c5>
1401a13ad:     	movq	0x238(%r8), %r12
1401a13b4:     	imulq	$0x2d0, %rax, %rax      # imm = 0x2D0
1401a13bb:     	movq	0x2c0(%r12,%rax), %rdx
1401a13c3:     	movq	0x2c8(%r12,%rax), %r13
1401a13cb:     	movq	%r13, 0x78(%rbp)
1401a13cf:     	cmpq	%rdx, %r13
1401a13d2:     	ja	0x1401a1608 <.text+0x1a0608>
1401a13d8:     	movq	0x80(%r8), %r13
1401a13df:     	movq	0x108(%rbp), %rdx
1401a13e6:     	cmpb	$0x1, (%r13,%rdx)
1401a13ec:     	jne	0x1401a14c5 <.text+0x1a04c5>
1401a13f2:     	cmpq	0xa0(%r8), %rdx
1401a13f9:     	jae	0x1401a14c3 <.text+0x1a04c3>
1401a13ff:     	movq	0x98(%r8), %r13
1401a1406:     	movb	$0x3, %bl
1401a1408:     	cmpb	$0x0, (%r13,%rdx)
1401a140e:     	jne	0x1401a14c5 <.text+0x1a04c5>
1401a1414:     	addq	%rax, %r12
1401a1417:     	movq	0x2b8(%r12), %rdx
1401a141f:     	movq	0x108(%rbp), %rax
1401a1426:     	addq	%rax, %r13
1401a1429:     	movb	$0x1, (%r13)
1401a142e:     	cmpq	0x70(%r8), %rax
1401a1432:     	jae	0x1401a14c3 <.text+0x1a04c3>
1401a1438:     	movq	0x68(%r8), %r8
1401a143c:     	imulq	$0x58, %rax, %r12
1401a1440:     	movq	0x8(%r8,%r12), %rax
1401a1445:     	movq	0x10(%r8,%r12), %rbx
1401a144a:     	addq	%r12, %r8
1401a144d:     	addq	$0x30, %r8
1401a1451:     	movb	%bl, 0x8f(%rbp)
1401a1457:     	movq	%rbx, %r12
1401a145a:     	shrq	$0x8, %r12
1401a145e:     	movq	%r13, 0x80(%rbp)
1401a1465:     	movq	%rbx, %r13
1401a1468:     	shrq	$0x38, %r13
1401a146c:     	movb	%r13b, 0x27(%rbp)
1401a1470:     	movq	0x80(%rbp), %r13
1401a1477:     	shrq	$0x28, %rbx
1401a147b:     	movw	%bx, 0x25(%rbp)
1401a147f:     	movl	%r12d, 0x21(%rbp)
1401a1483:     	movq	%r8, %r12
1401a1486:     	movq	%r8, 0x28(%rbp)
1401a148a:     	movq	%r13, 0x30(%rbp)
1401a148e:     	movq	0x108(%rbp), %r8
1401a1495:     	movq	%r8, 0x38(%rbp)
1401a1499:     	movq	%rax, 0x40(%rbp)
1401a149d:     	movq	%rax, 0x18(%rbp)
1401a14a1:     	movzbl	0x8f(%rbp), %eax
1401a14a8:     	movb	%al, 0x20(%rbp)
1401a14ab:     	cmpq	0x78(%rbp), %r15
1401a14af:     	jbe	0x1401a14df <.text+0x1a04df>
1401a14b1:     	movb	$0xa, (%rcx)
1401a14b4:     	movq	$0xb, 0x8(%rcx)
1401a14bc:     	movb	$0x0, (%r13)
1401a14c1:     	jmp	0x1401a14cb <.text+0x1a04cb>
1401a14c3:     	xorl	%ebx, %ebx
1401a14c5:     	movb	$0x7, (%rcx)
1401a14c8:     	movb	%bl, 0x1(%rcx)
1401a14cb:     	addq	$0x118, %rsp            # imm = 0x118
1401a14d2:     	popq	%rbx
1401a14d3:     	popq	%rdi
1401a14d4:     	popq	%rsi
1401a14d5:     	popq	%r12
1401a14d7:     	popq	%r13
1401a14d9:     	popq	%r14
1401a14db:     	popq	%r15
1401a14dd:     	popq	%rbp
1401a14de:     	retq
1401a14df:     	movq	%rdx, %rax
1401a14e2:     	movq	0x118(%rbp), %rdx
1401a14e9:     	movq	0x110(%rbp), %r15
1401a14f0:     	movq	0x100(%rbp), %r13
1401a14f7:     	orb	%r14b, %r11b
1401a14fa:     	addq	%rdi, %rax
1401a14fd:     	movzbl	0x2c(%rdx), %r8d
1401a1502:     	movzbl	0x22(%rdx), %ebx
1401a1506:     	movzwl	0x20(%rdx), %edi
1401a150a:     	movzbl	0x2b(%rdx), %r14d
1401a150f:     	movb	%r14b, 0x13(%rbp)
1401a1513:     	movq	0x23(%rdx), %r14
1401a1517:     	movq	%r14, 0xb(%rbp)
1401a151b:     	movups	(%rdx), %xmm0
1401a151e:     	movups	%xmm0, -0x18(%rbp)
1401a1522:     	movq	%rax, -0x8(%rbp)
1401a1526:     	movq	%rsi, (%rbp)
1401a152a:     	movw	%di, 0x8(%rbp)
1401a152e:     	movb	%bl, 0xa(%rbp)
1401a1531:     	movb	%r8b, 0x14(%rbp)
1401a1535:     	movq	0x20(%rbp), %rsi
1401a1539:     	movq	%rsi, %r8
1401a153c:     	testb	%r11b, %r11b
1401a153f:     	je	0x1401a1568 <.text+0x1a0568>
1401a1541:     	cmpq	$0x5c0, %rsi            # imm = 0x5C0
1401a1548:     	movl	$0x5c0, %r8d            # imm = 0x5C0
1401a154e:     	cmovbq	%rsi, %r8
1401a1552:     	movq	(%r12), %rdx
1401a1556:     	cmpq	%rsi, %rdx
1401a1559:     	ja	0x1401a1622 <.text+0x1a0622>
1401a155f:     	testq	%rdx, %rdx
1401a1562:     	jne	0x1401a1636 <.text+0x1a0636>
1401a1568:     	movq	%rcx, %rdi
1401a156b:     	movl	0x14(%r13), %eax
1401a156f:     	movq	%r8, 0x40(%rsp)
1401a1574:     	movq	0x40(%rbp), %rcx
1401a1578:     	movq	%rcx, 0x38(%rsp)
1401a157d:     	movb	%r10b, 0x30(%rsp)
1401a1582:     	leaq	-0x18(%rbp), %rcx
1401a1586:     	movq	%rcx, 0x28(%rsp)
1401a158b:     	movq	%r15, 0x20(%rsp)
1401a1590:     	leaq	0xc85b9(%rip), %r8      # 0x140269b50
1401a1597:     	leaq	0x48(%rbp), %rcx
1401a159b:     	movq	%r9, %rdx
1401a159e:     	movl	%eax, %r9d
1401a15a1:     	callq	0x140103ee0 <.text+0x102ee0>
1401a15a6:     	nop
1401a15a7:     	movzbl	0x48(%rbp), %eax
1401a15ab:     	cmpb	$-0x1, %al
1401a15ad:     	je	0x1401a15dc <.text+0x1a05dc>
1401a15af:     	movl	0x49(%rbp), %ecx
1401a15b2:     	movl	0x4c(%rbp), %edx
1401a15b5:     	movl	%edx, 0x4(%rdi)
1401a15b8:     	movl	%ecx, 0x1(%rdi)
1401a15bb:     	movq	0x50(%rbp), %rcx
1401a15bf:     	movups	0x58(%rbp), %xmm0
1401a15c3:     	movups	%xmm0, 0x10(%rdi)
1401a15c7:     	movb	%al, (%rdi)
1401a15c9:     	movq	%rcx, 0x8(%rdi)
1401a15cd:     	movq	0x80(%rbp), %rax
1401a15d4:     	movb	$0x0, (%rax)
1401a15d7:     	jmp	0x1401a14cb <.text+0x1a04cb>
1401a15dc:     	movq	0x50(%rbp), %rax
1401a15e0:     	cmpq	%rsi, %rax
1401a15e3:     	movq	0x80(%rbp), %rcx
1401a15ea:     	jbe	0x1401a15f9 <.text+0x1a05f9>
1401a15ec:     	movw	$0x207, (%rdi)          # imm = 0x207
1401a15f1:     	movb	$0x0, (%rcx)
1401a15f4:     	jmp	0x1401a14cb <.text+0x1a04cb>
1401a15f9:     	movq	%rax, (%r12)
1401a15fd:     	movb	$0x0, (%rcx)
1401a1600:     	movb	$-0x1, (%rdi)
1401a1603:     	jmp	0x1401a14cb <.text+0x1a04cb>
1401a1608:     	movq	%rdx, %r13
1401a160b:     	leaq	0xcb7c6(%rip), %r9      # 0x14026cdd8
1401a1612:     	xorl	%ecx, %ecx
1401a1614:     	movq	0x78(%rbp), %rdx
1401a1618:     	movq	%r13, %r8
1401a161b:     	callq	0x140248670 <.text+0x247670>
1401a1620:     	ud2
1401a1622:     	leaq	0xbeb7f(%rip), %r9      # 0x1402601a8
1401a1629:     	xorl	%ecx, %ecx
1401a162b:     	movq	%rsi, %r8
1401a162e:     	callq	0x140248670 <.text+0x247670>
1401a1633:     	nop
1401a1634:     	ud2
1401a1636:     	movq	%rcx, %rsi
1401a1639:     	movq	%r9, 0x48(%rbp)
1401a163d:     	leaq	0xc850c(%rip), %rax     # 0x140269b50
1401a1644:     	movq	%rax, 0x50(%rbp)
1401a1648:     	movq	%r13, 0x58(%rbp)
1401a164c:     	movq	%r15, 0x60(%rbp)
1401a1650:     	leaq	-0x18(%rbp), %rax
1401a1654:     	movq	%rax, 0x68(%rbp)
1401a1658:     	leaq	0x8e(%rbp), %rax
1401a165f:     	movq	%rax, 0x70(%rbp)
1401a1663:     	leaq	-0x38(%rbp), %rcx
1401a1667:     	leaq	0x18(%rbp), %rdx
1401a166b:     	leaq	0x48(%rbp), %r9
1401a166f:     	callq	0x14025d460 <.text+0x25c460>
1401a1674:     	nop
1401a1675:     	cmpb	$-0x1, -0x38(%rbp)
1401a1679:     	je	0x1401a168f <.text+0x1a068f>
1401a167b:     	movups	-0x38(%rbp), %xmm0
1401a167f:     	movups	-0x28(%rbp), %xmm1
1401a1683:     	movups	%xmm1, 0x10(%rsi)
1401a1687:     	movups	%xmm0, (%rsi)
1401a168a:     	jmp	0x1401a15cd <.text+0x1a05cd>
1401a168f:     	movq	%rsi, %rdi
1401a1692:     	movq	0x80(%rbp), %rcx
1401a1699:     	jmp	0x1401a15fd <.text+0x1a05fd>
1401a169e:     	nop
1401a16a0:     	movq	%rdx, 0x10(%rsp)
1401a16a5:     	pushq	%rbp
1401a16a6:     	pushq	%r15
1401a16a8:     	pushq	%r14
1401a16aa:     	pushq	%r13
1401a16ac:     	pushq	%r12
1401a16ae:     	pushq	%rsi
1401a16af:     	pushq	%rdi
1401a16b0:     	pushq	%rbx
1401a16b1:     	subq	$0x48, %rsp
1401a16b5:     	leaq	0x80(%rdx), %rbp
1401a16bc:     	movq	0x80(%rbp), %rax
1401a16c3:     	movb	$0x0, (%rax)
1401a16c6:     	addq	$0x48, %rsp
1401a16ca:     	popq	%rbx
1401a16cb:     	popq	%rdi
1401a16cc:     	popq	%rsi
1401a16cd:     	popq	%r12
1401a16cf:     	popq	%r13
1401a16d1:     	popq	%r14
1401a16d3:     	popq	%r15
1401a16d5:     	popq	%rbp
1401a16d6:     	retq


D:\CoapticCurrent\packet-lazy-location-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401e6150:     	pushq	%rbp
1401e6151:     	movq	%rsp, %rbp
1401e6154:     	movq	%rcx, %rax
1401e6157:     	movl	$0x0, (%rcx)
1401e615d:     	movl	$0x0, 0x8(%rcx)
1401e6164:     	movw	$0x1, 0x10(%rcx)
1401e616a:     	leaq	0x85dcc(%rip), %rcx     # 0x14026bf3d
1401e6171:     	movq	%rcx, 0x18(%rax)
1401e6175:     	movq	$0x20, 0x20(%rax)
1401e617d:     	movb	$-0x1, 0xb5(%rax)
1401e6184:     	movabsq	$0x65727574786966, %rcx # imm = 0x65727574786966
1401e618e:     	movq	%rcx, 0xc0(%rax)
1401e6195:     	movq	$0x0, 0xc8(%rax)
1401e61a0:     	movq	$0x0, 0xd8(%rax)
1401e61ab:     	movq	$0x0, 0x158(%rax)
1401e61b6:     	movq	$0x20, 0x1d8(%rax)
1401e61c1:     	movl	$0x2a0001, 0x1e0(%rax)  # imm = 0x2A0001
1401e61cb:     	movb	$0x0, 0x1e4(%rax)
1401e61d2:     	movabsq	$0x745ff000000, %rcx    # imm = 0x745FF000000
1401e61dc:     	movq	%rcx, 0x20e(%rax)
1401e61e3:     	popq	%rbp
1401e61e4:     	retq

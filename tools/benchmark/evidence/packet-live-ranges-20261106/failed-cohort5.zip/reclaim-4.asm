
D:\CoapticCurrent\packet-lazy-location-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009a7e0:     	pushq	%rbp
14009a7e1:     	pushq	%r15
14009a7e3:     	pushq	%r14
14009a7e5:     	pushq	%r13
14009a7e7:     	pushq	%r12
14009a7e9:     	pushq	%rsi
14009a7ea:     	pushq	%rdi
14009a7eb:     	pushq	%rbx
14009a7ec:     	subq	$0x318, %rsp            # imm = 0x318
14009a7f3:     	leaq	0x80(%rsp), %rbp
14009a7fb:     	movaps	%xmm7, 0x280(%rbp)
14009a802:     	movdqa	%xmm6, 0x270(%rbp)
14009a80a:     	movq	0xe8(%rcx), %r8
14009a811:     	testq	%r8, %r8
14009a814:     	je	0x14009abf4 <.text+0x99bf4>
14009a81a:     	movq	0x88(%rcx), %r11
14009a821:     	movq	0xe0(%rcx), %rdx
14009a828:     	movq	0xc8(%rcx), %rax
14009a82f:     	movq	0xd0(%rcx), %r9
14009a836:     	leaq	0x30(%rax), %rsi
14009a83a:     	xorl	%ebx, %ebx
14009a83c:     	xorl	%edi, %edi
14009a83e:     	leaq	(%rdi,%rdi,4), %r12
14009a842:     	shlq	$0x6, %r12
14009a846:     	addq	%rsi, %r12
14009a849:     	jmp	0x14009a863 <.text+0x99863>
14009a84b:     	nopl	(%rax,%rax)
14009a850:     	incq	%rdi
14009a853:     	addq	$0x140, %r12            # imm = 0x140
14009a85a:     	cmpq	%r8, %rdi
14009a85d:     	jae	0x14009a92c <.text+0x9992c>
14009a863:     	cmpq	%r9, %rdi
14009a866:     	setb	%r15b
14009a86a:     	andb	(%rdx,%rdi), %r15b
14009a86e:     	cmpb	$0x1, %r15b
14009a872:     	jne	0x14009a850 <.text+0x99850>
14009a874:     	movq	-0x30(%r12), %r15
14009a879:     	cmpq	$0x2, %r15
14009a87d:     	je	0x14009a850 <.text+0x99850>
14009a87f:     	movq	(%r12), %r13
14009a883:     	cmpl	$0x1, %r15d
14009a887:     	setne	%r15b
14009a88b:     	testq	%r13, %r13
14009a88e:     	sete	%r10b
14009a892:     	orb	%r15b, %r10b
14009a895:     	cmpb	$0x1, %r10b
14009a899:     	je	0x14009a850 <.text+0x99850>
14009a89b:     	movq	0x260(%rbp), %r15
14009a8a2:     	cmpq	%r15, %r13
14009a8a5:     	setae	%r10b
14009a8a9:     	testb	%r10b, %bl
14009a8ac:     	jne	0x14009a915 <.text+0x99915>
14009a8ae:     	movq	-0x28(%r12), %r10
14009a8b3:     	movq	%r10, 0x250(%rbp)
14009a8ba:     	movq	-0x20(%r12), %r10
14009a8bf:     	movq	%r10, 0x248(%rbp)
14009a8c6:     	movd	-0x4(%r12), %xmm6
14009a8cd:     	movzbl	-0x5(%r12), %r10d
14009a8d3:     	movb	%r10b, 0x26e(%rbp)
14009a8da:     	movzbl	-0x6(%r12), %r10d
14009a8e0:     	movb	%r10b, 0x26f(%rbp)
14009a8e7:     	movzwl	-0x8(%r12), %r10d
14009a8ed:     	movw	%r10w, 0x26c(%rbp)
14009a8f5:     	movl	-0xc(%r12), %r10d
14009a8fa:     	movl	%r10d, 0x268(%rbp)
14009a901:     	movl	-0x10(%r12), %r14d
14009a906:     	movq	-0x18(%r12), %r10
14009a90b:     	movq	%r10, 0x258(%rbp)
14009a912:     	movq	%r13, %r15
14009a915:     	movq	%r15, 0x260(%rbp)
14009a91c:     	incq	%rdi
14009a91f:     	movb	$0x1, %bl
14009a921:     	cmpq	%r8, %rdi
14009a924:     	jb	0x14009a83e <.text+0x9983e>
14009a92a:     	jmp	0x14009a935 <.text+0x99935>
14009a92c:     	testb	$0x1, %bl
14009a92f:     	je	0x14009abf4 <.text+0x99bf4>
14009a935:     	movq	0x250(%rbp), %r10
14009a93c:     	cmpq	%r11, %r10
14009a93f:     	jae	0x14009a995 <.text+0x99995>
14009a941:     	movq	0x80(%rcx), %r11
14009a948:     	cmpb	$0x1, (%r11,%r10)
14009a94d:     	jne	0x14009a995 <.text+0x99995>
14009a94f:     	cmpq	0xa0(%rcx), %r10
14009a956:     	jae	0x14009a966 <.text+0x99966>
14009a958:     	movq	0x98(%rcx), %rsi
14009a95f:     	cmpb	$0x0, (%rsi,%r10)
14009a964:     	jne	0x14009a995 <.text+0x99995>
14009a966:     	movb	$0x0, (%r11,%r10)
14009a96b:     	decq	0xb0(%rcx)
14009a972:     	cmpq	0x70(%rcx), %r10
14009a976:     	jae	0x14009a995 <.text+0x99995>
14009a978:     	movq	0x68(%rcx), %r11
14009a97c:     	imulq	$0x58, %r10, %r10
14009a980:     	movq	$0x0, 0x30(%r11,%r10)
14009a989:     	movb	$0x2, 0x52(%r11,%r10)
14009a98f:     	movb	$0x2, 0x25(%r11,%r10)
14009a995:     	leaq	0xc0(%rcx), %rsi
14009a99c:     	movd	%xmm6, %r10d
14009a9a1:     	addq	$0x2c, %rax
14009a9a5:     	xorl	%r11d, %r11d
14009a9a8:     	movq	0x248(%rbp), %r15
14009a9af:     	movzbl	0x26e(%rbp), %r12d
14009a9b7:     	jmp	0x14009a9d2 <.text+0x999d2>
14009a9b9:     	nopl	(%rax)
14009a9c0:     	incq	%r11
14009a9c3:     	addq	$0x140, %rax            # imm = 0x140
14009a9c9:     	cmpq	%r11, %r8
14009a9cc:     	je	0x14009aa5e <.text+0x99a5e>
14009a9d2:     	cmpq	%r9, %r11
14009a9d5:     	setb	%bl
14009a9d8:     	andb	(%rdx,%r11), %bl
14009a9dc:     	cmpb	$0x1, %bl
14009a9df:     	jne	0x14009a9c0 <.text+0x999c0>
14009a9e1:     	cmpl	$0x2, -0x2c(%rax)
14009a9e5:     	je	0x14009a9c0 <.text+0x999c0>
14009a9e7:     	cmpw	%r10w, (%rax)
14009a9eb:     	jne	0x14009a9c0 <.text+0x999c0>
14009a9ed:     	cmpl	%r14d, -0xc(%rax)
14009a9f1:     	jne	0x14009a9c0 <.text+0x999c0>
14009a9f3:     	movl	0x268(%rbp), %edi
14009a9f9:     	cmpl	%edi, -0x8(%rax)
14009a9fc:     	jne	0x14009a9c0 <.text+0x999c0>
14009a9fe:     	movzwl	0x26c(%rbp), %edi
14009aa05:     	cmpw	%di, -0x4(%rax)
14009aa09:     	jne	0x14009a9c0 <.text+0x999c0>
14009aa0b:     	movzbl	0x26f(%rbp), %ebx
14009aa12:     	cmpb	%bl, -0x2(%rax)
14009aa15:     	jne	0x14009a9c0 <.text+0x999c0>
14009aa17:     	movq	-0x1c(%rax), %rdi
14009aa1b:     	xorq	%r15, %rdi
14009aa1e:     	movq	-0x14(%rax), %rbx
14009aa22:     	xorq	0x258(%rbp), %rbx
14009aa29:     	orq	%rdi, %rbx
14009aa2c:     	jne	0x14009a9c0 <.text+0x999c0>
14009aa2e:     	cmpq	%r8, %r11
14009aa31:     	jae	0x14009aa5e <.text+0x99a5e>
14009aa33:     	cmpq	0x100(%rcx), %r11
14009aa3a:     	jae	0x14009aa4a <.text+0x99a4a>
14009aa3c:     	movq	0xf8(%rcx), %r8
14009aa43:     	cmpb	$0x0, (%r8,%r11)
14009aa48:     	jne	0x14009aa5e <.text+0x99a5e>
14009aa4a:     	movb	$0x0, (%rdx,%r11)
14009aa4f:     	decq	0x110(%rcx)
14009aa56:     	movq	$0x2, -0x2c(%rax)
14009aa5e:     	xorps	%xmm7, %xmm7
14009aa61:     	movaps	%xmm7, 0x230(%rbp)
14009aa68:     	movb	$0x0, 0x212(%rbp)
14009aa6f:     	movw	%r10w, 0x210(%rbp)
14009aa77:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
14009aa80:     	movq	$0x0, 0x213(%rbp)
14009aa8b:     	movq	$0x8, 0x1f0(%rbp)
14009aa96:     	movq	$0x0, 0x1f8(%rbp)
14009aaa1:     	movq	$0x1, 0x200(%rbp)
14009aaac:     	movq	$0x0, 0x208(%rbp)
14009aab7:     	leaq	0x220(%rbp), %rcx
14009aabe:     	leaq	0x1f0(%rbp), %rdx
14009aac5:     	leaq	0x230(%rbp), %r8
14009aacc:     	movl	$0x10, %r9d
14009aad2:     	callq	0x140112090 <.text+0x111090>
14009aad7:     	cmpb	$0x0, 0x220(%rbp)
14009aade:     	jne	0x14009abf0 <.text+0x99bf0>
14009aae4:     	movq	0x228(%rbp), %rdi
14009aaeb:     	movaps	%xmm7, 0xe0(%rbp)
14009aaf2:     	movaps	%xmm7, 0xf0(%rbp)
14009aaf9:     	movaps	%xmm7, 0x100(%rbp)
14009ab00:     	movaps	%xmm7, 0x110(%rbp)
14009ab07:     	movaps	%xmm7, 0x120(%rbp)
14009ab0e:     	movaps	%xmm7, 0x130(%rbp)
14009ab15:     	movaps	%xmm7, 0x140(%rbp)
14009ab1c:     	movaps	%xmm7, 0x150(%rbp)
14009ab23:     	movaps	%xmm7, 0x160(%rbp)
14009ab2a:     	movaps	%xmm7, 0x170(%rbp)
14009ab31:     	movaps	%xmm7, 0x180(%rbp)
14009ab38:     	movaps	%xmm7, 0x190(%rbp)
14009ab3f:     	movaps	%xmm7, 0x1a0(%rbp)
14009ab46:     	movaps	%xmm7, 0x1b0(%rbp)
14009ab4d:     	movaps	%xmm7, 0x1c0(%rbp)
14009ab54:     	movaps	%xmm7, 0x1d0(%rbp)
14009ab5b:     	cmpq	$0x11, %rdi
14009ab5f:     	jae	0x14009ac18 <.text+0x99c18>
14009ab65:     	leaq	0xe0(%rbp), %rbx
14009ab6c:     	leaq	0x230(%rbp), %rdx
14009ab73:     	movq	%rbx, %rcx
14009ab76:     	movq	%rdi, %r8
14009ab79:     	callq	0x140247c20 <.text+0x246c20>
14009ab7e:     	movw	%di, 0x1e0(%rbp)
14009ab85:     	movq	$0x0, -0x60(%rbp)
14009ab8d:     	movq	0x258(%rbp), %rax
14009ab94:     	movq	%rax, -0x48(%rbp)
14009ab98:     	movq	%r15, -0x50(%rbp)
14009ab9c:     	movl	%r14d, -0x40(%rbp)
14009aba0:     	movl	0x268(%rbp), %eax
14009aba6:     	movl	%eax, -0x3c(%rbp)
14009aba9:     	movzwl	0x26c(%rbp), %eax
14009abb0:     	movw	%ax, -0x38(%rbp)
14009abb4:     	movzbl	0x26f(%rbp), %eax
14009abbb:     	movb	%al, -0x36(%rbp)
14009abbe:     	movb	%r12b, -0x35(%rbp)
14009abc2:     	movd	%xmm6, -0x34(%rbp)
14009abc7:     	movq	0x260(%rbp), %rax
14009abce:     	movq	%rax, -0x30(%rbp)
14009abd2:     	leaq	-0x28(%rbp), %rcx
14009abd6:     	movl	$0x108, %r8d            # imm = 0x108
14009abdc:     	movq	%rbx, %rdx
14009abdf:     	callq	0x140247c20 <.text+0x246c20>
14009abe4:     	leaq	-0x60(%rbp), %rdx
14009abe8:     	movq	%rsi, %rcx
14009abeb:     	callq	0x140011760 <.text+0x10760>
14009abf0:     	movb	$0x1, %al
14009abf2:     	jmp	0x14009abf6 <.text+0x99bf6>
14009abf4:     	xorl	%eax, %eax
14009abf6:     	movaps	0x270(%rbp), %xmm6
14009abfd:     	movaps	0x280(%rbp), %xmm7
14009ac04:     	addq	$0x318, %rsp            # imm = 0x318
14009ac0b:     	popq	%rbx
14009ac0c:     	popq	%rdi
14009ac0d:     	popq	%rsi
14009ac0e:     	popq	%r12
14009ac10:     	popq	%r13
14009ac12:     	popq	%r14
14009ac14:     	popq	%r15
14009ac16:     	popq	%rbp
14009ac17:     	retq
14009ac18:     	leaq	0x1cef19(%rip), %r9     # 0x140269b38
14009ac1f:     	movl	$0x10, %r8d
14009ac25:     	xorl	%ecx, %ecx
14009ac27:     	movq	%rdi, %rdx
14009ac2a:     	callq	0x140248670 <.text+0x247670>
14009ac2f:     	ud2

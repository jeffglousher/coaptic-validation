
D:\CoapticCurrent\packet-lazy-location-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140065e40:     	pushq	%rbp
140065e41:     	pushq	%r15
140065e43:     	pushq	%r14
140065e45:     	pushq	%r13
140065e47:     	pushq	%r12
140065e49:     	pushq	%rsi
140065e4a:     	pushq	%rdi
140065e4b:     	pushq	%rbx
140065e4c:     	subq	$0xd8, %rsp
140065e53:     	leaq	0x80(%rsp), %rbp
140065e5b:     	movq	0xd0(%rbp), %r15
140065e62:     	movq	0x8(%r15), %rbx
140065e66:     	movl	$0x3, %r10d
140065e6c:     	cmpq	$0x3, %rbx
140065e70:     	ja	0x140065ee0 <.text+0x64ee0>
140065e72:     	cmpb	$0x1, 0x1b748(%rdx,%rbx)
140065e7a:     	jne	0x140065ee0 <.text+0x64ee0>
140065e7c:     	movq	0x2b750(%rdx,%rbx,8), %rax
140065e84:     	cmpq	$0x4001, %rax           # imm = 0x4001
140065e8a:     	jae	0x140066048 <.text+0x65048>
140065e90:     	movq	0x10(%r15), %r14
140065e94:     	movq	0x18(%r15), %r11
140065e98:     	movq	%r11, %r12
140065e9b:     	movl	$0xb, %r10d
140065ea1:     	addq	%r14, %r12
140065ea4:     	jb	0x140065ee0 <.text+0x64ee0>
140065ea6:     	cmpq	$0x400, %r11            # imm = 0x400
140065ead:     	ja	0x140065ee0 <.text+0x64ee0>
140065eaf:     	cmpq	%rax, %r12
140065eb2:     	ja	0x140065ee0 <.text+0x64ee0>
140065eb4:     	cmpb	$0x0, 0xd8(%rbp)
140065ebb:     	movq	%r9, 0x38(%rbp)
140065ebf:     	movq	%rcx, 0x50(%rbp)
140065ec3:     	movq	%r8, 0x40(%rbp)
140065ec7:     	je	0x140065edb <.text+0x64edb>
140065ec9:     	imulq	$0x2b0, %rbx, %rax      # imm = 0x2B0
140065ed0:     	cmpq	$0x2, 0x1ac78(%rdx,%rax)
140065ed9:     	jne	0x140065efb <.text+0x64efb>
140065edb:     	xorl	%r13d, %r13d
140065ede:     	jmp	0x140065f15 <.text+0x64f15>
140065ee0:     	movb	$0xa, (%rcx)
140065ee3:     	movq	%r10, 0x8(%rcx)
140065ee7:     	addq	$0xd8, %rsp
140065eee:     	popq	%rbx
140065eef:     	popq	%rdi
140065ef0:     	popq	%rsi
140065ef1:     	popq	%r12
140065ef3:     	popq	%r13
140065ef5:     	popq	%r14
140065ef7:     	popq	%r15
140065ef9:     	popq	%rbp
140065efa:     	retq
140065efb:     	addq	%rdx, %rax
140065efe:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
140065f04:     	movq	0x98(%rax), %rax
140065f0b:     	movq	%rax, 0x48(%rbp)
140065f0f:     	movl	$0x1, %r13d
140065f15:     	movq	%rdx, %rdi
140065f18:     	movq	%rdx, %rcx
140065f1b:     	callq	0x140096930 <.text+0x95930>
140065f20:     	testb	$0x1, %al
140065f22:     	je	0x14006602c <.text+0x6502c>
140065f28:     	movq	%rdx, %rsi
140065f2b:     	movq	0xe0(%rbp), %rax
140065f32:     	movzwl	0xc8(%rbp), %ecx
140065f39:     	movzbl	0xc0(%rbp), %edx
140065f40:     	movq	(%r15), %r8
140065f43:     	movq	%r13, 0x18(%rbp)
140065f47:     	movq	0x48(%rbp), %r9
140065f4b:     	movq	%r9, 0x20(%rbp)
140065f4f:     	movq	%r8, 0x28(%rbp)
140065f53:     	movzbl	0xd8(%rbp), %r8d
140065f5b:     	movb	%r8b, 0x30(%rbp)
140065f5f:     	movq	0x40(%rbp), %r9
140065f63:     	leaq	0x38(%r9), %r8
140065f67:     	leaq	0x66(%r9), %r10
140065f6b:     	leaq	0x56(%r9), %r11
140065f6f:     	movq	%r11, 0x70(%rsp)
140065f74:     	movq	%rax, 0x68(%rsp)
140065f79:     	movq	%r9, 0x60(%rsp)
140065f7e:     	leaq	0x18(%rbp), %rax
140065f82:     	movq	%rax, 0x58(%rsp)
140065f87:     	movq	%r12, 0x50(%rsp)
140065f8c:     	movq	%r14, 0x48(%rsp)
140065f91:     	movq	%rbx, 0x40(%rsp)
140065f96:     	movq	0x38(%rbp), %rax
140065f9a:     	movq	%rax, 0x38(%rsp)
140065f9f:     	movq	%r10, 0x30(%rsp)
140065fa4:     	movw	%cx, 0x28(%rsp)
140065fa9:     	movb	%dl, 0x20(%rsp)
140065fad:     	leaq	-0x8(%rbp), %rcx
140065fb1:     	movq	%rdi, %rdx
140065fb4:     	movq	%rsi, %r9
140065fb7:     	callq	0x14009f9f0 <.text+0x9e9f0>
140065fbc:     	cmpb	$-0x1, -0x8(%rbp)
140065fc0:     	je	0x140066038 <.text+0x65038>
140065fc2:     	cmpb	$0x1, 0x37740(%rdi,%rsi)
140065fca:     	movq	0x50(%rbp), %rax
140065fce:     	jne	0x140066018 <.text+0x65018>
140065fd0:     	cmpb	$0x0, 0x37760(%rdi,%rsi)
140065fd8:     	jne	0x140066018 <.text+0x65018>
140065fda:     	movb	$0x0, 0x37740(%rdi,%rsi)
140065fe2:     	decq	0x37788(%rdi)
140065fe9:     	leaq	0x37740(%rdi), %rcx
140065ff0:     	movq	$0x0, 0x43610(%rdi,%rsi,8)
140065ffc:     	leaq	(%rsi,%rsi,8), %rdx
140066000:     	leaq	(%rdx,%rdx,2), %rdx
140066004:     	addq	%rsi, %rdx
140066007:     	movb	$0x2, 0x36a(%rcx,%rdx)
14006600f:     	leaq	(%rsi,%rsi,2), %rdx
140066013:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140066018:     	movups	-0x8(%rbp), %xmm0
14006601c:     	movups	0x8(%rbp), %xmm1
140066020:     	movups	%xmm1, 0x10(%rax)
140066024:     	movups	%xmm0, (%rax)
140066027:     	jmp	0x140065ee7 <.text+0x64ee7>
14006602c:     	movq	0x50(%rbp), %rax
140066030:     	movb	$0x9, (%rax)
140066033:     	jmp	0x140065ee7 <.text+0x64ee7>
140066038:     	movq	0x50(%rbp), %rax
14006603c:     	movq	%rsi, 0x8(%rax)
140066040:     	movb	$-0x1, (%rax)
140066043:     	jmp	0x140065ee7 <.text+0x64ee7>
140066048:     	leaq	0x206bc9(%rip), %r9     # 0x14026cc18
14006604f:     	movl	$0x4000, %r8d           # imm = 0x4000
140066055:     	xorl	%ecx, %ecx
140066057:     	movq	%rax, %rdx
14006605a:     	callq	0x140248670 <.text+0x247670>
14006605f:     	ud2

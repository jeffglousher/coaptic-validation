
D:\CoapticCurrent\packet-lazy-location-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140065c10:     	pushq	%rbp
140065c11:     	pushq	%r15
140065c13:     	pushq	%r14
140065c15:     	pushq	%r13
140065c17:     	pushq	%r12
140065c19:     	pushq	%rsi
140065c1a:     	pushq	%rdi
140065c1b:     	pushq	%rbx
140065c1c:     	subq	$0xe8, %rsp
140065c23:     	leaq	0x80(%rsp), %rbp
140065c2b:     	movq	0xe0(%rbp), %r15
140065c32:     	movq	0x8(%r15), %rbx
140065c36:     	movl	$0x3, %r10d
140065c3c:     	cmpq	$0x3, %rbx
140065c40:     	ja	0x140065cb0 <.text+0x64cb0>
140065c42:     	cmpb	$0x1, 0x1b748(%rdx,%rbx)
140065c4a:     	jne	0x140065cb0 <.text+0x64cb0>
140065c4c:     	movq	0x2b750(%rdx,%rbx,8), %rax
140065c54:     	cmpq	$0x4001, %rax           # imm = 0x4001
140065c5a:     	jae	0x140065e26 <.text+0x64e26>
140065c60:     	movq	0x10(%r15), %r14
140065c64:     	movq	0x18(%r15), %r11
140065c68:     	movq	%r11, %r12
140065c6b:     	movl	$0xb, %r10d
140065c71:     	addq	%r14, %r12
140065c74:     	jb	0x140065cb0 <.text+0x64cb0>
140065c76:     	cmpq	$0x400, %r11            # imm = 0x400
140065c7d:     	ja	0x140065cb0 <.text+0x64cb0>
140065c7f:     	cmpq	%rax, %r12
140065c82:     	ja	0x140065cb0 <.text+0x64cb0>
140065c84:     	cmpb	$0x0, 0xe8(%rbp)
140065c8b:     	movq	%r9, 0x48(%rbp)
140065c8f:     	movq	%rcx, 0x60(%rbp)
140065c93:     	movq	%r8, 0x50(%rbp)
140065c97:     	je	0x140065cab <.text+0x64cab>
140065c99:     	imulq	$0x2b0, %rbx, %rax      # imm = 0x2B0
140065ca0:     	cmpq	$0x2, 0x1ac78(%rdx,%rax)
140065ca9:     	jne	0x140065ccb <.text+0x64ccb>
140065cab:     	xorl	%r13d, %r13d
140065cae:     	jmp	0x140065ce5 <.text+0x64ce5>
140065cb0:     	movb	$0xa, (%rcx)
140065cb3:     	movq	%r10, 0x8(%rcx)
140065cb7:     	addq	$0xe8, %rsp
140065cbe:     	popq	%rbx
140065cbf:     	popq	%rdi
140065cc0:     	popq	%rsi
140065cc1:     	popq	%r12
140065cc3:     	popq	%r13
140065cc5:     	popq	%r14
140065cc7:     	popq	%r15
140065cc9:     	popq	%rbp
140065cca:     	retq
140065ccb:     	addq	%rdx, %rax
140065cce:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
140065cd4:     	movq	0x98(%rax), %rax
140065cdb:     	movq	%rax, 0x58(%rbp)
140065cdf:     	movl	$0x1, %r13d
140065ce5:     	movq	%rdx, %rdi
140065ce8:     	movq	%rdx, %rcx
140065ceb:     	callq	0x140096930 <.text+0x95930>
140065cf0:     	testb	$0x1, %al
140065cf2:     	je	0x140065e0a <.text+0x64e0a>
140065cf8:     	movq	%rdx, %rsi
140065cfb:     	movq	0xf8(%rbp), %rax
140065d02:     	movq	0xf0(%rbp), %rcx
140065d09:     	movzwl	0xd8(%rbp), %edx
140065d10:     	movzbl	0xd0(%rbp), %r9d
140065d18:     	movq	(%r15), %r8
140065d1b:     	movq	%r13, 0x28(%rbp)
140065d1f:     	movq	0x58(%rbp), %r10
140065d23:     	movq	%r10, 0x30(%rbp)
140065d27:     	movq	%r8, 0x38(%rbp)
140065d2b:     	movzbl	0xe8(%rbp), %r8d
140065d33:     	movb	%r8b, 0x40(%rbp)
140065d37:     	movq	0x50(%rbp), %r10
140065d3b:     	leaq	0x38(%r10), %r8
140065d3f:     	leaq	0x66(%r10), %r11
140065d43:     	leaq	0x56(%r10), %r15
140065d47:     	movq	%r15, 0x78(%rsp)
140065d4c:     	movq	%rax, 0x70(%rsp)
140065d51:     	movq	%rcx, 0x68(%rsp)
140065d56:     	movq	%r10, 0x60(%rsp)
140065d5b:     	leaq	0x28(%rbp), %rax
140065d5f:     	movq	%rax, 0x58(%rsp)
140065d64:     	movq	%r12, 0x50(%rsp)
140065d69:     	movq	%r14, 0x48(%rsp)
140065d6e:     	movq	%rbx, 0x40(%rsp)
140065d73:     	movq	0x48(%rbp), %rax
140065d77:     	movq	%rax, 0x38(%rsp)
140065d7c:     	movq	%r11, 0x30(%rsp)
140065d81:     	movw	%dx, 0x28(%rsp)
140065d86:     	movb	%r9b, 0x20(%rsp)
140065d8b:     	leaq	0x8(%rbp), %rcx
140065d8f:     	movq	%rdi, %rdx
140065d92:     	movq	%rsi, %r9
140065d95:     	callq	0x14009dbb0 <.text+0x9cbb0>
140065d9a:     	cmpb	$-0x1, 0x8(%rbp)
140065d9e:     	je	0x140065e16 <.text+0x64e16>
140065da0:     	cmpb	$0x1, 0x37740(%rdi,%rsi)
140065da8:     	movq	0x60(%rbp), %rax
140065dac:     	jne	0x140065df6 <.text+0x64df6>
140065dae:     	cmpb	$0x0, 0x37760(%rdi,%rsi)
140065db6:     	jne	0x140065df6 <.text+0x64df6>
140065db8:     	movb	$0x0, 0x37740(%rdi,%rsi)
140065dc0:     	decq	0x37788(%rdi)
140065dc7:     	leaq	0x37740(%rdi), %rcx
140065dce:     	movq	$0x0, 0x43610(%rdi,%rsi,8)
140065dda:     	leaq	(%rsi,%rsi,8), %rdx
140065dde:     	leaq	(%rdx,%rdx,2), %rdx
140065de2:     	addq	%rsi, %rdx
140065de5:     	movb	$0x2, 0x36a(%rcx,%rdx)
140065ded:     	leaq	(%rsi,%rsi,2), %rdx
140065df1:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140065df6:     	movups	0x8(%rbp), %xmm0
140065dfa:     	movups	0x18(%rbp), %xmm1
140065dfe:     	movups	%xmm1, 0x10(%rax)
140065e02:     	movups	%xmm0, (%rax)
140065e05:     	jmp	0x140065cb7 <.text+0x64cb7>
140065e0a:     	movq	0x60(%rbp), %rax
140065e0e:     	movb	$0x9, (%rax)
140065e11:     	jmp	0x140065cb7 <.text+0x64cb7>
140065e16:     	movq	0x60(%rbp), %rax
140065e1a:     	movq	%rsi, 0x8(%rax)
140065e1e:     	movb	$-0x1, (%rax)
140065e21:     	jmp	0x140065cb7 <.text+0x64cb7>
140065e26:     	leaq	0x206deb(%rip), %r9     # 0x14026cc18
140065e2d:     	movl	$0x4000, %r8d           # imm = 0x4000
140065e33:     	xorl	%ecx, %ecx
140065e35:     	movq	%rax, %rdx
140065e38:     	callq	0x140248670 <.text+0x247670>
140065e3d:     	ud2

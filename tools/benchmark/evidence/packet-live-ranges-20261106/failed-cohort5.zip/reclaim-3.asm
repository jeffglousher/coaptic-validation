
D:\CoapticCurrent\packet-lazy-location-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009a420:     	pushq	%rbp
14009a421:     	pushq	%r15
14009a423:     	pushq	%r14
14009a425:     	pushq	%r13
14009a427:     	pushq	%r12
14009a429:     	pushq	%rsi
14009a42a:     	pushq	%rdi
14009a42b:     	pushq	%rbx
14009a42c:     	subq	$0x308, %rsp            # imm = 0x308
14009a433:     	leaq	0x80(%rsp), %rbp
14009a43b:     	movaps	%xmm7, 0x270(%rbp)
14009a442:     	movaps	%xmm6, 0x260(%rbp)
14009a449:     	leaq	0x5000(%rcx), %rax
14009a450:     	leaq	0x30(%rcx), %r8
14009a454:     	xorl	%r9d, %r9d
14009a457:     	xorl	%esi, %esi
14009a459:     	leaq	(%rsi,%rsi,4), %r11
14009a45d:     	shlq	$0x6, %r11
14009a461:     	addq	%r8, %r11
14009a464:     	movq	%rsi, %r10
14009a467:     	jmp	0x14009a484 <.text+0x99484>
14009a469:     	nopl	(%rax)
14009a470:     	incq	%r10
14009a473:     	addq	$0x140, %r11            # imm = 0x140
14009a47a:     	cmpq	$0x40, %r10
14009a47e:     	je	0x14009a51e <.text+0x9951e>
14009a484:     	cmpb	$0x1, 0x5000(%rcx,%r10)
14009a48d:     	jne	0x14009a470 <.text+0x99470>
14009a48f:     	movq	-0x30(%r11), %rdi
14009a493:     	cmpq	$0x2, %rdi
14009a497:     	je	0x14009a470 <.text+0x99470>
14009a499:     	movq	(%r11), %rsi
14009a49c:     	cmpl	$0x1, %edi
14009a49f:     	setne	%bl
14009a4a2:     	testq	%rsi, %rsi
14009a4a5:     	sete	%dil
14009a4a9:     	orb	%bl, %dil
14009a4ac:     	cmpb	$0x1, %dil
14009a4b0:     	je	0x14009a470 <.text+0x99470>
14009a4b2:     	movq	0x250(%rbp), %rdi
14009a4b9:     	cmpq	%rdi, %rsi
14009a4bc:     	setae	%bl
14009a4bf:     	testb	%bl, %r9b
14009a4c2:     	jne	0x14009a504 <.text+0x99504>
14009a4c4:     	movd	-0x4(%r11), %xmm6
14009a4ca:     	movzbl	-0x5(%r11), %edx
14009a4cf:     	movb	%dl, 0x25f(%rbp)
14009a4d5:     	movzbl	-0x6(%r11), %r15d
14009a4da:     	movzwl	-0x8(%r11), %r12d
14009a4df:     	movl	-0xc(%r11), %r13d
14009a4e3:     	movl	-0x10(%r11), %r14d
14009a4e7:     	movq	-0x18(%r11), %rdx
14009a4eb:     	movq	%rdx, 0x248(%rbp)
14009a4f2:     	movq	-0x28(%r11), %rdx
14009a4f6:     	movq	-0x20(%r11), %r9
14009a4fa:     	movq	%r9, 0x240(%rbp)
14009a501:     	movq	%rsi, %rdi
14009a504:     	movq	%rdi, 0x250(%rbp)
14009a50b:     	leaq	0x1(%r10), %rsi
14009a50f:     	movb	$0x1, %r9b
14009a512:     	cmpq	$0x3f, %r10
14009a516:     	jb	0x14009a459 <.text+0x99459>
14009a51c:     	jmp	0x14009a528 <.text+0x99528>
14009a51e:     	testb	$0x1, %r9b
14009a522:     	je	0x14009a7a0 <.text+0x997a0>
14009a528:     	cmpq	$0x1f, %rdx
14009a52c:     	ja	0x14009a57f <.text+0x9957f>
14009a52e:     	leaq	0x37740(%rcx), %r8
14009a535:     	cmpb	$0x1, (%r8,%rdx)
14009a53a:     	jne	0x14009a57f <.text+0x9957f>
14009a53c:     	cmpb	$0x0, 0x37760(%rcx,%rdx)
14009a544:     	jne	0x14009a57f <.text+0x9957f>
14009a546:     	movb	$0x0, 0x37740(%rcx,%rdx)
14009a54e:     	decq	0x37788(%rcx)
14009a555:     	movq	$0x0, 0x43610(%rcx,%rdx,8)
14009a561:     	leaq	(%rdx,%rdx,8), %r9
14009a565:     	leaq	(%r9,%r9,2), %r9
14009a569:     	addq	%rdx, %r9
14009a56c:     	movb	$0x2, 0x36a(%r8,%r9)
14009a575:     	leaq	(%rdx,%rdx,2), %rdx
14009a579:     	movb	$0x2, 0x5d(%r8,%rdx,8)
14009a57f:     	movd	%xmm6, %edx
14009a583:     	movl	$0x2c, %r8d
14009a589:     	movq	0x240(%rbp), %r11
14009a590:     	movq	0x248(%rbp), %rsi
14009a597:     	jmp	0x14009a5b3 <.text+0x995b3>
14009a599:     	nopl	(%rax)
14009a5a0:     	incq	%rax
14009a5a3:     	addq	$0x140, %r8             # imm = 0x140
14009a5aa:     	cmpq	$0x502c, %r8            # imm = 0x502C
14009a5b1:     	je	0x14009a60c <.text+0x9960c>
14009a5b3:     	cmpb	$0x1, (%rax)
14009a5b6:     	jne	0x14009a5a0 <.text+0x995a0>
14009a5b8:     	cmpl	$0x2, -0x2c(%rcx,%r8)
14009a5be:     	je	0x14009a5a0 <.text+0x995a0>
14009a5c0:     	cmpw	%dx, (%rcx,%r8)
14009a5c5:     	jne	0x14009a5a0 <.text+0x995a0>
14009a5c7:     	cmpl	%r14d, -0xc(%rcx,%r8)
14009a5cc:     	jne	0x14009a5a0 <.text+0x995a0>
14009a5ce:     	cmpl	%r13d, -0x8(%rcx,%r8)
14009a5d3:     	jne	0x14009a5a0 <.text+0x995a0>
14009a5d5:     	cmpw	%r12w, -0x4(%rcx,%r8)
14009a5db:     	jne	0x14009a5a0 <.text+0x995a0>
14009a5dd:     	cmpb	%r15b, -0x2(%rcx,%r8)
14009a5e2:     	jne	0x14009a5a0 <.text+0x995a0>
14009a5e4:     	movq	-0x1c(%rcx,%r8), %r9
14009a5e9:     	xorq	%r11, %r9
14009a5ec:     	movq	-0x14(%rcx,%r8), %r10
14009a5f1:     	xorq	%rsi, %r10
14009a5f4:     	orq	%r9, %r10
14009a5f7:     	jne	0x14009a5a0 <.text+0x995a0>
14009a5f9:     	movb	$0x0, (%rax)
14009a5fc:     	decq	0x5048(%rcx)
14009a603:     	movq	$0x2, -0x2c(%rcx,%r8)
14009a60c:     	movq	%rcx, %rsi
14009a60f:     	xorps	%xmm7, %xmm7
14009a612:     	movaps	%xmm7, 0x230(%rbp)
14009a619:     	movb	$0x0, 0x212(%rbp)
14009a620:     	movw	%dx, 0x210(%rbp)
14009a627:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
14009a630:     	movq	$0x0, 0x213(%rbp)
14009a63b:     	movq	$0x8, 0x1f0(%rbp)
14009a646:     	movq	$0x0, 0x1f8(%rbp)
14009a651:     	movq	$0x1, 0x200(%rbp)
14009a65c:     	movq	$0x0, 0x208(%rbp)
14009a667:     	leaq	0x220(%rbp), %rcx
14009a66e:     	leaq	0x1f0(%rbp), %rdx
14009a675:     	leaq	0x230(%rbp), %r8
14009a67c:     	movl	$0x10, %r9d
14009a682:     	callq	0x140112090 <.text+0x111090>
14009a687:     	cmpb	$0x0, 0x220(%rbp)
14009a68e:     	jne	0x14009a79c <.text+0x9979c>
14009a694:     	movq	0x228(%rbp), %rdi
14009a69b:     	movaps	%xmm7, 0xe0(%rbp)
14009a6a2:     	movaps	%xmm7, 0xf0(%rbp)
14009a6a9:     	movaps	%xmm7, 0x100(%rbp)
14009a6b0:     	movaps	%xmm7, 0x110(%rbp)
14009a6b7:     	movaps	%xmm7, 0x120(%rbp)
14009a6be:     	movaps	%xmm7, 0x130(%rbp)
14009a6c5:     	movaps	%xmm7, 0x140(%rbp)
14009a6cc:     	movaps	%xmm7, 0x150(%rbp)
14009a6d3:     	movaps	%xmm7, 0x160(%rbp)
14009a6da:     	movaps	%xmm7, 0x170(%rbp)
14009a6e1:     	movaps	%xmm7, 0x180(%rbp)
14009a6e8:     	movaps	%xmm7, 0x190(%rbp)
14009a6ef:     	movaps	%xmm7, 0x1a0(%rbp)
14009a6f6:     	movaps	%xmm7, 0x1b0(%rbp)
14009a6fd:     	movaps	%xmm7, 0x1c0(%rbp)
14009a704:     	movaps	%xmm7, 0x1d0(%rbp)
14009a70b:     	cmpq	$0x11, %rdi
14009a70f:     	jae	0x14009a7c4 <.text+0x997c4>
14009a715:     	leaq	0xe0(%rbp), %rbx
14009a71c:     	leaq	0x230(%rbp), %rdx
14009a723:     	movq	%rbx, %rcx
14009a726:     	movq	%rdi, %r8
14009a729:     	callq	0x140247c20 <.text+0x246c20>
14009a72e:     	movw	%di, 0x1e0(%rbp)
14009a735:     	movq	$0x0, -0x60(%rbp)
14009a73d:     	movq	0x248(%rbp), %rax
14009a744:     	movq	%rax, -0x48(%rbp)
14009a748:     	movq	0x240(%rbp), %rax
14009a74f:     	movq	%rax, -0x50(%rbp)
14009a753:     	movl	%r14d, -0x40(%rbp)
14009a757:     	movl	%r13d, -0x3c(%rbp)
14009a75b:     	movw	%r12w, -0x38(%rbp)
14009a760:     	movb	%r15b, -0x36(%rbp)
14009a764:     	movzbl	0x25f(%rbp), %eax
14009a76b:     	movb	%al, -0x35(%rbp)
14009a76e:     	movd	%xmm6, -0x34(%rbp)
14009a773:     	movq	0x250(%rbp), %rax
14009a77a:     	movq	%rax, -0x30(%rbp)
14009a77e:     	leaq	-0x28(%rbp), %rcx
14009a782:     	movl	$0x108, %r8d            # imm = 0x108
14009a788:     	movq	%rbx, %rdx
14009a78b:     	callq	0x140247c20 <.text+0x246c20>
14009a790:     	leaq	-0x60(%rbp), %rdx
14009a794:     	movq	%rsi, %rcx
14009a797:     	callq	0x14020d790 <.text+0x20c790>
14009a79c:     	movb	$0x1, %al
14009a79e:     	jmp	0x14009a7a2 <.text+0x997a2>
14009a7a0:     	xorl	%eax, %eax
14009a7a2:     	movaps	0x260(%rbp), %xmm6
14009a7a9:     	movaps	0x270(%rbp), %xmm7
14009a7b0:     	addq	$0x308, %rsp            # imm = 0x308
14009a7b7:     	popq	%rbx
14009a7b8:     	popq	%rdi
14009a7b9:     	popq	%rsi
14009a7ba:     	popq	%r12
14009a7bc:     	popq	%r13
14009a7be:     	popq	%r14
14009a7c0:     	popq	%r15
14009a7c2:     	popq	%rbp
14009a7c3:     	retq
14009a7c4:     	leaq	0x1cf36d(%rip), %r9     # 0x140269b38
14009a7cb:     	movl	$0x10, %r8d
14009a7d1:     	xorl	%ecx, %ecx
14009a7d3:     	movq	%rdi, %rdx
14009a7d6:     	callq	0x140248670 <.text+0x247670>
14009a7db:     	ud2

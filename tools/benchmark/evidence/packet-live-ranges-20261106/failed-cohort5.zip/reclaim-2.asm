
D:\CoapticCurrent\packet-lazy-location-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009a0a0:     	pushq	%rbp
14009a0a1:     	pushq	%r15
14009a0a3:     	pushq	%r14
14009a0a5:     	pushq	%r13
14009a0a7:     	pushq	%r12
14009a0a9:     	pushq	%rsi
14009a0aa:     	pushq	%rdi
14009a0ab:     	pushq	%rbx
14009a0ac:     	subq	$0x318, %rsp            # imm = 0x318
14009a0b3:     	leaq	0x80(%rsp), %rbp
14009a0bb:     	movaps	%xmm7, 0x280(%rbp)
14009a0c2:     	movaps	%xmm6, 0x270(%rbp)
14009a0c9:     	leaq	0x30(%rcx), %rdx
14009a0cd:     	xorl	%r8d, %r8d
14009a0d0:     	xorl	%r11d, %r11d
14009a0d3:     	leaq	(%r11,%r11,4), %r10
14009a0d7:     	shlq	$0x6, %r10
14009a0db:     	addq	%rdx, %r10
14009a0de:     	movq	%r11, %r9
14009a0e1:     	jmp	0x14009a104 <.text+0x99104>
14009a0e3:     	nopw	%cs:(%rax,%rax)
14009a0f0:     	incq	%r9
14009a0f3:     	addq	$0x140, %r10            # imm = 0x140
14009a0fa:     	cmpq	$0x4, %r9
14009a0fe:     	je	0x14009a18e <.text+0x9918e>
14009a104:     	cmpb	$0x1, 0x510(%rcx,%r9)
14009a10d:     	jne	0x14009a0f0 <.text+0x990f0>
14009a10f:     	movq	-0x30(%r10), %rsi
14009a113:     	cmpq	$0x2, %rsi
14009a117:     	je	0x14009a0f0 <.text+0x990f0>
14009a119:     	movq	(%r10), %r11
14009a11c:     	cmpl	$0x1, %esi
14009a11f:     	setne	%bl
14009a122:     	testq	%r11, %r11
14009a125:     	sete	%sil
14009a129:     	orb	%bl, %sil
14009a12c:     	cmpb	$0x1, %sil
14009a130:     	je	0x14009a0f0 <.text+0x990f0>
14009a132:     	movq	0x268(%rbp), %rsi
14009a139:     	cmpq	%rsi, %r11
14009a13c:     	setae	%bl
14009a13f:     	testb	%bl, %r8b
14009a142:     	jne	0x14009a174 <.text+0x99174>
14009a144:     	movq	-0x28(%r10), %rax
14009a148:     	movd	-0x4(%r10), %xmm6
14009a14e:     	movzbl	-0x5(%r10), %edi
14009a153:     	movzbl	-0x6(%r10), %r15d
14009a158:     	movzwl	-0x8(%r10), %r12d
14009a15d:     	movl	-0xc(%r10), %r13d
14009a161:     	movl	-0x10(%r10), %r14d
14009a165:     	movups	-0x20(%r10), %xmm0
14009a16a:     	movaps	%xmm0, 0x240(%rbp)
14009a171:     	movq	%r11, %rsi
14009a174:     	movq	%rsi, 0x268(%rbp)
14009a17b:     	leaq	0x1(%r9), %r11
14009a17f:     	movb	$0x1, %r8b
14009a182:     	cmpq	$0x3, %r9
14009a186:     	jb	0x14009a0d3 <.text+0x990d3>
14009a18c:     	jmp	0x14009a198 <.text+0x99198>
14009a18e:     	testb	$0x1, %r8b
14009a192:     	je	0x14009a3d8 <.text+0x993d8>
14009a198:     	cmpq	$0x1, %rax
14009a19c:     	ja	0x14009a1f4 <.text+0x991f4>
14009a19e:     	cmpb	$0x1, 0x4420(%rcx,%rax)
14009a1a6:     	jne	0x14009a1f4 <.text+0x991f4>
14009a1a8:     	cmpb	$0x0, 0x4422(%rcx,%rax)
14009a1b0:     	jne	0x14009a1f4 <.text+0x991f4>
14009a1b2:     	movb	$0x0, 0x4420(%rcx,%rax)
14009a1ba:     	decq	0x4418(%rcx)
14009a1c1:     	leaq	0x3a98(%rcx), %rdx
14009a1c8:     	movq	$0x0, 0x4398(%rcx,%rax,8)
14009a1d4:     	leaq	(%rax,%rax,8), %r8
14009a1d8:     	leaq	(%r8,%r8,2), %r8
14009a1dc:     	addq	%rax, %r8
14009a1df:     	movb	$0x2, 0x95a(%rdx,%r8)
14009a1e8:     	leaq	(%rax,%rax,2), %rax
14009a1ec:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009a1f4:     	movaps	0x240(%rbp), %xmm0
14009a1fb:     	movaps	%xmm0, -0x60(%rbp)
14009a1ff:     	movl	%r14d, %esi
14009a202:     	movl	%r14d, -0x50(%rbp)
14009a206:     	movl	%r13d, %r14d
14009a209:     	movl	%r13d, -0x4c(%rbp)
14009a20d:     	movl	%r12d, %r13d
14009a210:     	movw	%r12w, -0x48(%rbp)
14009a215:     	movl	%r15d, %r12d
14009a218:     	movb	%r15b, -0x46(%rbp)
14009a21c:     	movl	%edi, %r15d
14009a21f:     	movb	%dil, -0x45(%rbp)
14009a223:     	movd	%xmm6, %edi
14009a227:     	movd	%xmm6, -0x44(%rbp)
14009a22c:     	leaq	-0x60(%rbp), %rdx
14009a230:     	movq	%rcx, 0x260(%rbp)
14009a237:     	callq	0x14020dbc0 <.text+0x20cbc0>
14009a23c:     	xorps	%xmm7, %xmm7
14009a23f:     	movaps	%xmm7, 0x250(%rbp)
14009a246:     	movb	$0x0, 0x222(%rbp)
14009a24d:     	movw	%di, 0x220(%rbp)
14009a254:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009a25d:     	movq	$0x0, 0x223(%rbp)
14009a268:     	movq	$0x8, 0x200(%rbp)
14009a273:     	movq	$0x0, 0x208(%rbp)
14009a27e:     	movq	$0x1, 0x210(%rbp)
14009a289:     	movq	$0x0, 0x218(%rbp)
14009a294:     	leaq	0x230(%rbp), %rcx
14009a29b:     	leaq	0x200(%rbp), %rdx
14009a2a2:     	leaq	0x250(%rbp), %r8
14009a2a9:     	movl	$0x10, %r9d
14009a2af:     	callq	0x140112090 <.text+0x111090>
14009a2b4:     	cmpb	$0x0, 0x230(%rbp)
14009a2bb:     	jne	0x14009a3d4 <.text+0x993d4>
14009a2c1:     	movq	0x238(%rbp), %rdi
14009a2c8:     	movaps	%xmm7, 0xe0(%rbp)
14009a2cf:     	movaps	%xmm7, 0xf0(%rbp)
14009a2d6:     	movaps	%xmm7, 0x100(%rbp)
14009a2dd:     	movaps	%xmm7, 0x110(%rbp)
14009a2e4:     	movaps	%xmm7, 0x120(%rbp)
14009a2eb:     	movaps	%xmm7, 0x130(%rbp)
14009a2f2:     	movaps	%xmm7, 0x140(%rbp)
14009a2f9:     	movaps	%xmm7, 0x150(%rbp)
14009a300:     	movaps	%xmm7, 0x160(%rbp)
14009a307:     	movaps	%xmm7, 0x170(%rbp)
14009a30e:     	movaps	%xmm7, 0x180(%rbp)
14009a315:     	movaps	%xmm7, 0x190(%rbp)
14009a31c:     	movaps	%xmm7, 0x1a0(%rbp)
14009a323:     	movaps	%xmm7, 0x1b0(%rbp)
14009a32a:     	movaps	%xmm7, 0x1c0(%rbp)
14009a331:     	movaps	%xmm7, 0x1d0(%rbp)
14009a338:     	movaps	0x240(%rbp), %xmm0
14009a33f:     	movups	%xmm0, 0x1f0(%rbp)
14009a346:     	cmpq	$0x11, %rdi
14009a34a:     	jae	0x14009a3fc <.text+0x993fc>
14009a350:     	leaq	0xe0(%rbp), %rbx
14009a357:     	leaq	0x250(%rbp), %rdx
14009a35e:     	movq	%rbx, %rcx
14009a361:     	movq	%rdi, %r8
14009a364:     	callq	0x140247c20 <.text+0x246c20>
14009a369:     	movw	%di, 0x1e0(%rbp)
14009a370:     	movq	$0x0, -0x60(%rbp)
14009a378:     	movups	0x1e8(%rbp), %xmm0
14009a37f:     	movups	%xmm0, -0x58(%rbp)
14009a383:     	movq	0x1f8(%rbp), %rax
14009a38a:     	movq	%rax, -0x48(%rbp)
14009a38e:     	movl	%esi, -0x40(%rbp)
14009a391:     	movl	%r14d, -0x3c(%rbp)
14009a395:     	movw	%r13w, -0x38(%rbp)
14009a39a:     	movb	%r12b, -0x36(%rbp)
14009a39e:     	movb	%r15b, -0x35(%rbp)
14009a3a2:     	movd	%xmm6, -0x34(%rbp)
14009a3a7:     	movq	0x268(%rbp), %rax
14009a3ae:     	movq	%rax, -0x30(%rbp)
14009a3b2:     	leaq	-0x28(%rbp), %rcx
14009a3b6:     	movl	$0x108, %r8d            # imm = 0x108
14009a3bc:     	movq	%rbx, %rdx
14009a3bf:     	callq	0x140247c20 <.text+0x246c20>
14009a3c4:     	leaq	-0x60(%rbp), %rdx
14009a3c8:     	movq	0x260(%rbp), %rcx
14009a3cf:     	callq	0x14020d930 <.text+0x20c930>
14009a3d4:     	movb	$0x1, %al
14009a3d6:     	jmp	0x14009a3da <.text+0x993da>
14009a3d8:     	xorl	%eax, %eax
14009a3da:     	movaps	0x270(%rbp), %xmm6
14009a3e1:     	movaps	0x280(%rbp), %xmm7
14009a3e8:     	addq	$0x318, %rsp            # imm = 0x318
14009a3ef:     	popq	%rbx
14009a3f0:     	popq	%rdi
14009a3f1:     	popq	%rsi
14009a3f2:     	popq	%r12
14009a3f4:     	popq	%r13
14009a3f6:     	popq	%r14
14009a3f8:     	popq	%r15
14009a3fa:     	popq	%rbp
14009a3fb:     	retq
14009a3fc:     	leaq	0x1cf735(%rip), %r9     # 0x140269b38
14009a403:     	movl	$0x10, %r8d
14009a409:     	xorl	%ecx, %ecx
14009a40b:     	movq	%rdi, %rdx
14009a40e:     	callq	0x140248670 <.text+0x247670>
14009a413:     	ud2

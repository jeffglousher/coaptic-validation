
D:\CoapticCurrent\packet-lazy-location-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140099d20:     	pushq	%rbp
140099d21:     	pushq	%r15
140099d23:     	pushq	%r14
140099d25:     	pushq	%r13
140099d27:     	pushq	%r12
140099d29:     	pushq	%rsi
140099d2a:     	pushq	%rdi
140099d2b:     	pushq	%rbx
140099d2c:     	subq	$0x318, %rsp            # imm = 0x318
140099d33:     	leaq	0x80(%rsp), %rbp
140099d3b:     	movaps	%xmm7, 0x280(%rbp)
140099d42:     	movaps	%xmm6, 0x270(%rbp)
140099d49:     	leaq	0x30(%rcx), %rdx
140099d4d:     	xorl	%r8d, %r8d
140099d50:     	xorl	%r11d, %r11d
140099d53:     	leaq	(%r11,%r11,4), %r10
140099d57:     	shlq	$0x6, %r10
140099d5b:     	addq	%rdx, %r10
140099d5e:     	movq	%r11, %r9
140099d61:     	jmp	0x140099d84 <.text+0x98d84>
140099d63:     	nopw	%cs:(%rax,%rax)
140099d70:     	incq	%r9
140099d73:     	addq	$0x140, %r10            # imm = 0x140
140099d7a:     	cmpq	$0x4, %r9
140099d7e:     	je	0x140099e0e <.text+0x98e0e>
140099d84:     	cmpb	$0x1, 0x510(%rcx,%r9)
140099d8d:     	jne	0x140099d70 <.text+0x98d70>
140099d8f:     	movq	-0x30(%r10), %rsi
140099d93:     	cmpq	$0x2, %rsi
140099d97:     	je	0x140099d70 <.text+0x98d70>
140099d99:     	movq	(%r10), %r11
140099d9c:     	cmpl	$0x1, %esi
140099d9f:     	setne	%bl
140099da2:     	testq	%r11, %r11
140099da5:     	sete	%sil
140099da9:     	orb	%bl, %sil
140099dac:     	cmpb	$0x1, %sil
140099db0:     	je	0x140099d70 <.text+0x98d70>
140099db2:     	movq	0x268(%rbp), %rsi
140099db9:     	cmpq	%rsi, %r11
140099dbc:     	setae	%bl
140099dbf:     	testb	%bl, %r8b
140099dc2:     	jne	0x140099df4 <.text+0x98df4>
140099dc4:     	movq	-0x28(%r10), %rax
140099dc8:     	movd	-0x4(%r10), %xmm6
140099dce:     	movzbl	-0x5(%r10), %edi
140099dd3:     	movzbl	-0x6(%r10), %r15d
140099dd8:     	movzwl	-0x8(%r10), %r12d
140099ddd:     	movl	-0xc(%r10), %r13d
140099de1:     	movl	-0x10(%r10), %r14d
140099de5:     	movups	-0x20(%r10), %xmm0
140099dea:     	movaps	%xmm0, 0x240(%rbp)
140099df1:     	movq	%r11, %rsi
140099df4:     	movq	%rsi, 0x268(%rbp)
140099dfb:     	leaq	0x1(%r9), %r11
140099dff:     	movb	$0x1, %r8b
140099e02:     	cmpq	$0x3, %r9
140099e06:     	jb	0x140099d53 <.text+0x98d53>
140099e0c:     	jmp	0x140099e18 <.text+0x98e18>
140099e0e:     	testb	$0x1, %r8b
140099e12:     	je	0x14009a058 <.text+0x99058>
140099e18:     	cmpq	$0x1, %rax
140099e1c:     	ja	0x140099e74 <.text+0x98e74>
140099e1e:     	cmpb	$0x1, 0x1e80(%rcx,%rax)
140099e26:     	jne	0x140099e74 <.text+0x98e74>
140099e28:     	cmpb	$0x0, 0x1e82(%rcx,%rax)
140099e30:     	jne	0x140099e74 <.text+0x98e74>
140099e32:     	movb	$0x0, 0x1e80(%rcx,%rax)
140099e3a:     	decq	0x1e78(%rcx)
140099e41:     	leaq	0x14f8(%rcx), %rdx
140099e48:     	movq	$0x0, 0x1df8(%rcx,%rax,8)
140099e54:     	leaq	(%rax,%rax,8), %r8
140099e58:     	leaq	(%r8,%r8,2), %r8
140099e5c:     	addq	%rax, %r8
140099e5f:     	movb	$0x2, 0x95a(%rdx,%r8)
140099e68:     	leaq	(%rax,%rax,2), %rax
140099e6c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
140099e74:     	movaps	0x240(%rbp), %xmm0
140099e7b:     	movaps	%xmm0, -0x60(%rbp)
140099e7f:     	movl	%r14d, %esi
140099e82:     	movl	%r14d, -0x50(%rbp)
140099e86:     	movl	%r13d, %r14d
140099e89:     	movl	%r13d, -0x4c(%rbp)
140099e8d:     	movl	%r12d, %r13d
140099e90:     	movw	%r12w, -0x48(%rbp)
140099e95:     	movl	%r15d, %r12d
140099e98:     	movb	%r15b, -0x46(%rbp)
140099e9c:     	movl	%edi, %r15d
140099e9f:     	movb	%dil, -0x45(%rbp)
140099ea3:     	movd	%xmm6, %edi
140099ea7:     	movd	%xmm6, -0x44(%rbp)
140099eac:     	leaq	-0x60(%rbp), %rdx
140099eb0:     	movq	%rcx, 0x260(%rbp)
140099eb7:     	callq	0x14020dbc0 <.text+0x20cbc0>
140099ebc:     	xorps	%xmm7, %xmm7
140099ebf:     	movaps	%xmm7, 0x250(%rbp)
140099ec6:     	movb	$0x0, 0x222(%rbp)
140099ecd:     	movw	%di, 0x220(%rbp)
140099ed4:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
140099edd:     	movq	$0x0, 0x223(%rbp)
140099ee8:     	movq	$0x8, 0x200(%rbp)
140099ef3:     	movq	$0x0, 0x208(%rbp)
140099efe:     	movq	$0x1, 0x210(%rbp)
140099f09:     	movq	$0x0, 0x218(%rbp)
140099f14:     	leaq	0x230(%rbp), %rcx
140099f1b:     	leaq	0x200(%rbp), %rdx
140099f22:     	leaq	0x250(%rbp), %r8
140099f29:     	movl	$0x10, %r9d
140099f2f:     	callq	0x140112090 <.text+0x111090>
140099f34:     	cmpb	$0x0, 0x230(%rbp)
140099f3b:     	jne	0x14009a054 <.text+0x99054>
140099f41:     	movq	0x238(%rbp), %rdi
140099f48:     	movaps	%xmm7, 0xe0(%rbp)
140099f4f:     	movaps	%xmm7, 0xf0(%rbp)
140099f56:     	movaps	%xmm7, 0x100(%rbp)
140099f5d:     	movaps	%xmm7, 0x110(%rbp)
140099f64:     	movaps	%xmm7, 0x120(%rbp)
140099f6b:     	movaps	%xmm7, 0x130(%rbp)
140099f72:     	movaps	%xmm7, 0x140(%rbp)
140099f79:     	movaps	%xmm7, 0x150(%rbp)
140099f80:     	movaps	%xmm7, 0x160(%rbp)
140099f87:     	movaps	%xmm7, 0x170(%rbp)
140099f8e:     	movaps	%xmm7, 0x180(%rbp)
140099f95:     	movaps	%xmm7, 0x190(%rbp)
140099f9c:     	movaps	%xmm7, 0x1a0(%rbp)
140099fa3:     	movaps	%xmm7, 0x1b0(%rbp)
140099faa:     	movaps	%xmm7, 0x1c0(%rbp)
140099fb1:     	movaps	%xmm7, 0x1d0(%rbp)
140099fb8:     	movaps	0x240(%rbp), %xmm0
140099fbf:     	movups	%xmm0, 0x1f0(%rbp)
140099fc6:     	cmpq	$0x11, %rdi
140099fca:     	jae	0x14009a07c <.text+0x9907c>
140099fd0:     	leaq	0xe0(%rbp), %rbx
140099fd7:     	leaq	0x250(%rbp), %rdx
140099fde:     	movq	%rbx, %rcx
140099fe1:     	movq	%rdi, %r8
140099fe4:     	callq	0x140247c20 <.text+0x246c20>
140099fe9:     	movw	%di, 0x1e0(%rbp)
140099ff0:     	movq	$0x0, -0x60(%rbp)
140099ff8:     	movups	0x1e8(%rbp), %xmm0
140099fff:     	movups	%xmm0, -0x58(%rbp)
14009a003:     	movq	0x1f8(%rbp), %rax
14009a00a:     	movq	%rax, -0x48(%rbp)
14009a00e:     	movl	%esi, -0x40(%rbp)
14009a011:     	movl	%r14d, -0x3c(%rbp)
14009a015:     	movw	%r13w, -0x38(%rbp)
14009a01a:     	movb	%r12b, -0x36(%rbp)
14009a01e:     	movb	%r15b, -0x35(%rbp)
14009a022:     	movd	%xmm6, -0x34(%rbp)
14009a027:     	movq	0x268(%rbp), %rax
14009a02e:     	movq	%rax, -0x30(%rbp)
14009a032:     	leaq	-0x28(%rbp), %rcx
14009a036:     	movl	$0x108, %r8d            # imm = 0x108
14009a03c:     	movq	%rbx, %rdx
14009a03f:     	callq	0x140247c20 <.text+0x246c20>
14009a044:     	leaq	-0x60(%rbp), %rdx
14009a048:     	movq	0x260(%rbp), %rcx
14009a04f:     	callq	0x14020d930 <.text+0x20c930>
14009a054:     	movb	$0x1, %al
14009a056:     	jmp	0x14009a05a <.text+0x9905a>
14009a058:     	xorl	%eax, %eax
14009a05a:     	movaps	0x270(%rbp), %xmm6
14009a061:     	movaps	0x280(%rbp), %xmm7
14009a068:     	addq	$0x318, %rsp            # imm = 0x318
14009a06f:     	popq	%rbx
14009a070:     	popq	%rdi
14009a071:     	popq	%rsi
14009a072:     	popq	%r12
14009a074:     	popq	%r13
14009a076:     	popq	%r14
14009a078:     	popq	%r15
14009a07a:     	popq	%rbp
14009a07b:     	retq
14009a07c:     	leaq	0x1cfab5(%rip), %r9     # 0x140269b38
14009a083:     	movl	$0x10, %r8d
14009a089:     	xorl	%ecx, %ecx
14009a08b:     	movq	%rdi, %rdx
14009a08e:     	callq	0x140248670 <.text+0x247670>
14009a093:     	ud2

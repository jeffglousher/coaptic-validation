
D:\CoapticCurrent\packet-basic-response-20261107\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140069470:     	pushq	%rbp
140069471:     	pushq	%r15
140069473:     	pushq	%r14
140069475:     	pushq	%r13
140069477:     	pushq	%r12
140069479:     	pushq	%rsi
14006947a:     	pushq	%rdi
14006947b:     	pushq	%rbx
14006947c:     	subq	$0x508, %rsp            # imm = 0x508
140069483:     	leaq	0x80(%rsp), %rbp
14006948b:     	movq	%r9, %rbx
14006948e:     	movq	%r8, %r14
140069491:     	movq	%rdx, %rdi
140069494:     	movq	%rcx, %rsi
140069497:     	movq	0x500(%rbp), %r13
14006949e:     	movq	%rbp, %rcx
1400694a1:     	movl	$0x400, %r8d            # imm = 0x400
1400694a7:     	xorl	%edx, %edx
1400694a9:     	callq	0x140243402 <.text+0x242402>
1400694ae:     	movq	0x8(%r13), %rax
1400694b2:     	movl	$0x3, %ecx
1400694b7:     	cmpq	$0x3, %rax
1400694bb:     	ja	0x140069591 <.text+0x68591>
1400694c1:     	movq	%rbx, 0x478(%rbp)
1400694c8:     	cmpb	$0x1, 0x1b748(%rdi,%rax)
1400694d0:     	jne	0x140069591 <.text+0x68591>
1400694d6:     	leaq	0x1ac78(%rdi), %rcx
1400694dd:     	imulq	$0x2b0, %rax, %rdx      # imm = 0x2B0
1400694e4:     	leaq	(%rcx,%rdx), %r12
1400694e8:     	movq	(%rcx,%rdx), %rbx
1400694ec:     	cmpq	$0x2, %rbx
1400694f0:     	jne	0x1400694fe <.text+0x684fe>
1400694f2:     	movq	0x8(%r12), %rdx
1400694f7:     	movq	0x10(%r12), %r8
1400694fc:     	jmp	0x140069516 <.text+0x68516>
1400694fe:     	movq	%rax, %rcx
140069501:     	shlq	$0xe, %rcx
140069505:     	leaq	(%rdi,%rcx), %rdx
140069509:     	addq	$0x1b750, %rdx          # imm = 0x1B750
140069510:     	movl	$0x4000, %r8d           # imm = 0x4000
140069516:     	movq	0x2b750(%rdi,%rax,8), %rax
14006951e:     	cmpq	%r8, %rax
140069521:     	ja	0x140069725 <.text+0x68725>
140069527:     	movq	0x10(%r13), %r8
14006952b:     	movq	0x18(%r13), %r15
14006952f:     	movq	%r15, %r9
140069532:     	movl	$0xb, %ecx
140069537:     	addq	%r8, %r9
14006953a:     	jb	0x140069591 <.text+0x68591>
14006953c:     	cmpq	$0x400, %r15            # imm = 0x400
140069543:     	ja	0x140069591 <.text+0x68591>
140069545:     	cmpq	%rax, %r9
140069548:     	ja	0x140069591 <.text+0x68591>
14006954a:     	addq	%r8, %rdx
14006954d:     	movq	%rbp, %rcx
140069550:     	movq	%r15, %r8
140069553:     	callq	0x1402433f0 <.text+0x2423f0>
140069558:     	cmpl	$-0x1, %ebx
14006955b:     	sete	%al
14006955e:     	movzbl	0x508(%rbp), %ecx
140069565:     	xorb	$0x1, %cl
140069568:     	orb	%al, %cl
14006956a:     	jne	0x1400695ac <.text+0x685ac>
14006956c:     	movq	0x98(%r12), %rax
140069574:     	movq	%rax, 0x480(%rbp)
14006957b:     	movl	$0x1, %ebx
140069580:     	movq	%rdi, %rcx
140069583:     	callq	0x14009b820 <.text+0x9a820>
140069588:     	testb	$0x1, %al
14006958a:     	jne	0x1400695ba <.text+0x685ba>
14006958c:     	movb	$0x9, (%rsi)
14006958f:     	jmp	0x140069598 <.text+0x68598>
140069591:     	movb	$0xa, (%rsi)
140069594:     	movq	%rcx, 0x8(%rsi)
140069598:     	addq	$0x508, %rsp            # imm = 0x508
14006959f:     	popq	%rbx
1400695a0:     	popq	%rdi
1400695a1:     	popq	%rsi
1400695a2:     	popq	%r12
1400695a4:     	popq	%r13
1400695a6:     	popq	%r14
1400695a8:     	popq	%r15
1400695aa:     	popq	%rbp
1400695ab:     	retq
1400695ac:     	xorl	%ebx, %ebx
1400695ae:     	movq	%rdi, %rcx
1400695b1:     	callq	0x14009b820 <.text+0x9a820>
1400695b6:     	testb	$0x1, %al
1400695b8:     	je	0x14006958c <.text+0x6858c>
1400695ba:     	movq	%rdx, %r12
1400695bd:     	movq	0x518(%rbp), %rdx
1400695c4:     	movq	0x510(%rbp), %r8
1400695cb:     	movzwl	0x4f8(%rbp), %ecx
1400695d2:     	movzbl	0x4f0(%rbp), %eax
1400695d9:     	movq	(%r13), %r9
1400695dd:     	movq	%rbx, 0x448(%rbp)
1400695e4:     	movq	0x480(%rbp), %r10
1400695eb:     	movq	%r10, 0x450(%rbp)
1400695f2:     	movq	%r9, 0x458(%rbp)
1400695f9:     	movzbl	0x508(%rbp), %r9d
140069601:     	movb	%r9b, 0x460(%rbp)
140069608:     	movups	0x38(%r14), %xmm0
14006960d:     	movups	0x44(%r14), %xmm1
140069612:     	movups	%xmm1, 0x40c(%rbp)
140069619:     	movaps	%xmm0, 0x400(%rbp)
140069620:     	leaq	0x66(%r14), %r9
140069624:     	movq	0x56(%r14), %r10
140069628:     	movq	0x5d(%r14), %r11
14006962c:     	movq	%r11, 0x46f(%rbp)
140069633:     	movq	%r10, 0x468(%rbp)
14006963a:     	leaq	0x468(%rbp), %r10
140069641:     	movq	%r10, 0x70(%rsp)
140069646:     	movq	%rdx, 0x68(%rsp)
14006964b:     	movq	%r8, 0x60(%rsp)
140069650:     	movq	%r14, 0x58(%rsp)
140069655:     	leaq	0x448(%rbp), %rdx
14006965c:     	movq	%rdx, 0x50(%rsp)
140069661:     	movq	%r15, 0x48(%rsp)
140069666:     	movq	%rbp, %rdx
140069669:     	movq	%rdx, 0x40(%rsp)
14006966e:     	movq	0x478(%rbp), %rdx
140069675:     	movq	%rdx, 0x38(%rsp)
14006967a:     	movq	%r9, 0x30(%rsp)
14006967f:     	movw	%cx, 0x28(%rsp)
140069684:     	movb	%al, 0x20(%rsp)
140069688:     	leaq	0x428(%rbp), %rcx
14006968f:     	leaq	0x400(%rbp), %r8
140069696:     	movq	%rdi, %rdx
140069699:     	movq	%r12, %r9
14006969c:     	callq	0x1400829a0 <.text+0x819a0>
1400696a1:     	cmpb	$-0x1, 0x428(%rbp)
1400696a8:     	je	0x140069719 <.text+0x68719>
1400696aa:     	cmpb	$0x1, 0x37740(%rdi,%r12)
1400696b3:     	jne	0x1400696ff <.text+0x686ff>
1400696b5:     	cmpb	$0x0, 0x37760(%rdi,%r12)
1400696be:     	jne	0x1400696ff <.text+0x686ff>
1400696c0:     	movb	$0x0, 0x37740(%rdi,%r12)
1400696c9:     	decq	0x37788(%rdi)
1400696d0:     	leaq	0x37740(%rdi), %rax
1400696d7:     	movq	$0x0, 0x43610(%rdi,%r12,8)
1400696e3:     	leaq	(%r12,%r12,8), %rcx
1400696e7:     	leaq	(%rcx,%rcx,2), %rcx
1400696eb:     	addq	%r12, %rcx
1400696ee:     	movb	$0x2, 0x36a(%rax,%rcx)
1400696f6:     	leaq	(%r12,%r12,2), %rcx
1400696fa:     	movb	$0x2, 0x5d(%rax,%rcx,8)
1400696ff:     	movups	0x428(%rbp), %xmm0
140069706:     	movups	0x438(%rbp), %xmm1
14006970d:     	movups	%xmm1, 0x10(%rsi)
140069711:     	movups	%xmm0, (%rsi)
140069714:     	jmp	0x140069598 <.text+0x68598>
140069719:     	movq	%r12, 0x8(%rsi)
14006971d:     	movb	$-0x1, (%rsi)
140069720:     	jmp	0x140069598 <.text+0x68598>
140069725:     	leaq	0x1f554c(%rip), %r9     # 0x14025ec78
14006972c:     	xorl	%ecx, %ecx
14006972e:     	movq	%rax, %rdx
140069731:     	callq	0x140243e40 <.text+0x242e40>
140069736:     	ud2

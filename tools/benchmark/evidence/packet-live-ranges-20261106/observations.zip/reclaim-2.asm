
D:\CoapticCurrent\packet-basic-response-20261107\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009ef90:     	pushq	%rbp
14009ef91:     	pushq	%r15
14009ef93:     	pushq	%r14
14009ef95:     	pushq	%r13
14009ef97:     	pushq	%r12
14009ef99:     	pushq	%rsi
14009ef9a:     	pushq	%rdi
14009ef9b:     	pushq	%rbx
14009ef9c:     	subq	$0x318, %rsp            # imm = 0x318
14009efa3:     	leaq	0x80(%rsp), %rbp
14009efab:     	movaps	%xmm7, 0x280(%rbp)
14009efb2:     	movaps	%xmm6, 0x270(%rbp)
14009efb9:     	leaq	0x30(%rcx), %rdx
14009efbd:     	xorl	%r8d, %r8d
14009efc0:     	xorl	%r11d, %r11d
14009efc3:     	leaq	(%r11,%r11,4), %r10
14009efc7:     	shlq	$0x6, %r10
14009efcb:     	addq	%rdx, %r10
14009efce:     	movq	%r11, %r9
14009efd1:     	jmp	0x14009eff4 <.text+0x9dff4>
14009efd3:     	nopw	%cs:(%rax,%rax)
14009efe0:     	incq	%r9
14009efe3:     	addq	$0x140, %r10            # imm = 0x140
14009efea:     	cmpq	$0x4, %r9
14009efee:     	je	0x14009f07e <.text+0x9e07e>
14009eff4:     	cmpb	$0x1, 0x510(%rcx,%r9)
14009effd:     	jne	0x14009efe0 <.text+0x9dfe0>
14009efff:     	movq	-0x30(%r10), %rsi
14009f003:     	cmpq	$0x2, %rsi
14009f007:     	je	0x14009efe0 <.text+0x9dfe0>
14009f009:     	movq	(%r10), %r11
14009f00c:     	cmpl	$0x1, %esi
14009f00f:     	setne	%bl
14009f012:     	testq	%r11, %r11
14009f015:     	sete	%sil
14009f019:     	orb	%bl, %sil
14009f01c:     	cmpb	$0x1, %sil
14009f020:     	je	0x14009efe0 <.text+0x9dfe0>
14009f022:     	movq	0x268(%rbp), %rsi
14009f029:     	cmpq	%rsi, %r11
14009f02c:     	setae	%bl
14009f02f:     	testb	%bl, %r8b
14009f032:     	jne	0x14009f064 <.text+0x9e064>
14009f034:     	movq	-0x28(%r10), %rax
14009f038:     	movd	-0x4(%r10), %xmm6
14009f03e:     	movzbl	-0x5(%r10), %edi
14009f043:     	movzbl	-0x6(%r10), %r15d
14009f048:     	movzwl	-0x8(%r10), %r12d
14009f04d:     	movl	-0xc(%r10), %r13d
14009f051:     	movl	-0x10(%r10), %r14d
14009f055:     	movups	-0x20(%r10), %xmm0
14009f05a:     	movaps	%xmm0, 0x240(%rbp)
14009f061:     	movq	%r11, %rsi
14009f064:     	movq	%rsi, 0x268(%rbp)
14009f06b:     	leaq	0x1(%r9), %r11
14009f06f:     	movb	$0x1, %r8b
14009f072:     	cmpq	$0x3, %r9
14009f076:     	jb	0x14009efc3 <.text+0x9dfc3>
14009f07c:     	jmp	0x14009f088 <.text+0x9e088>
14009f07e:     	testb	$0x1, %r8b
14009f082:     	je	0x14009f2c8 <.text+0x9e2c8>
14009f088:     	cmpq	$0x1, %rax
14009f08c:     	ja	0x14009f0e4 <.text+0x9e0e4>
14009f08e:     	cmpb	$0x1, 0x4420(%rcx,%rax)
14009f096:     	jne	0x14009f0e4 <.text+0x9e0e4>
14009f098:     	cmpb	$0x0, 0x4422(%rcx,%rax)
14009f0a0:     	jne	0x14009f0e4 <.text+0x9e0e4>
14009f0a2:     	movb	$0x0, 0x4420(%rcx,%rax)
14009f0aa:     	decq	0x4418(%rcx)
14009f0b1:     	leaq	0x3a98(%rcx), %rdx
14009f0b8:     	movq	$0x0, 0x4398(%rcx,%rax,8)
14009f0c4:     	leaq	(%rax,%rax,8), %r8
14009f0c8:     	leaq	(%r8,%r8,2), %r8
14009f0cc:     	addq	%rax, %r8
14009f0cf:     	movb	$0x2, 0x95a(%rdx,%r8)
14009f0d8:     	leaq	(%rax,%rax,2), %rax
14009f0dc:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009f0e4:     	movaps	0x240(%rbp), %xmm0
14009f0eb:     	movaps	%xmm0, -0x60(%rbp)
14009f0ef:     	movl	%r14d, %esi
14009f0f2:     	movl	%r14d, -0x50(%rbp)
14009f0f6:     	movl	%r13d, %r14d
14009f0f9:     	movl	%r13d, -0x4c(%rbp)
14009f0fd:     	movl	%r12d, %r13d
14009f100:     	movw	%r12w, -0x48(%rbp)
14009f105:     	movl	%r15d, %r12d
14009f108:     	movb	%r15b, -0x46(%rbp)
14009f10c:     	movl	%edi, %r15d
14009f10f:     	movb	%dil, -0x45(%rbp)
14009f113:     	movd	%xmm6, %edi
14009f117:     	movd	%xmm6, -0x44(%rbp)
14009f11c:     	leaq	-0x60(%rbp), %rdx
14009f120:     	movq	%rcx, 0x260(%rbp)
14009f127:     	callq	0x140207660 <.text+0x206660>
14009f12c:     	xorps	%xmm7, %xmm7
14009f12f:     	movaps	%xmm7, 0x250(%rbp)
14009f136:     	movb	$0x0, 0x222(%rbp)
14009f13d:     	movw	%di, 0x220(%rbp)
14009f144:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009f14d:     	movq	$0x0, 0x223(%rbp)
14009f158:     	movq	$0x8, 0x200(%rbp)
14009f163:     	movq	$0x0, 0x208(%rbp)
14009f16e:     	movq	$0x1, 0x210(%rbp)
14009f179:     	movq	$0x0, 0x218(%rbp)
14009f184:     	leaq	0x230(%rbp), %rcx
14009f18b:     	leaq	0x200(%rbp), %rdx
14009f192:     	leaq	0x250(%rbp), %r8
14009f199:     	movl	$0x10, %r9d
14009f19f:     	callq	0x140110140 <.text+0x10f140>
14009f1a4:     	cmpb	$0x0, 0x230(%rbp)
14009f1ab:     	jne	0x14009f2c4 <.text+0x9e2c4>
14009f1b1:     	movq	0x238(%rbp), %rdi
14009f1b8:     	movaps	%xmm7, 0xe0(%rbp)
14009f1bf:     	movaps	%xmm7, 0xf0(%rbp)
14009f1c6:     	movaps	%xmm7, 0x100(%rbp)
14009f1cd:     	movaps	%xmm7, 0x110(%rbp)
14009f1d4:     	movaps	%xmm7, 0x120(%rbp)
14009f1db:     	movaps	%xmm7, 0x130(%rbp)
14009f1e2:     	movaps	%xmm7, 0x140(%rbp)
14009f1e9:     	movaps	%xmm7, 0x150(%rbp)
14009f1f0:     	movaps	%xmm7, 0x160(%rbp)
14009f1f7:     	movaps	%xmm7, 0x170(%rbp)
14009f1fe:     	movaps	%xmm7, 0x180(%rbp)
14009f205:     	movaps	%xmm7, 0x190(%rbp)
14009f20c:     	movaps	%xmm7, 0x1a0(%rbp)
14009f213:     	movaps	%xmm7, 0x1b0(%rbp)
14009f21a:     	movaps	%xmm7, 0x1c0(%rbp)
14009f221:     	movaps	%xmm7, 0x1d0(%rbp)
14009f228:     	movaps	0x240(%rbp), %xmm0
14009f22f:     	movups	%xmm0, 0x1f0(%rbp)
14009f236:     	cmpq	$0x11, %rdi
14009f23a:     	jae	0x14009f2ec <.text+0x9e2ec>
14009f240:     	leaq	0xe0(%rbp), %rbx
14009f247:     	leaq	0x250(%rbp), %rdx
14009f24e:     	movq	%rbx, %rcx
14009f251:     	movq	%rdi, %r8
14009f254:     	callq	0x1402433f0 <.text+0x2423f0>
14009f259:     	movw	%di, 0x1e0(%rbp)
14009f260:     	movq	$0x0, -0x60(%rbp)
14009f268:     	movups	0x1e8(%rbp), %xmm0
14009f26f:     	movups	%xmm0, -0x58(%rbp)
14009f273:     	movq	0x1f8(%rbp), %rax
14009f27a:     	movq	%rax, -0x48(%rbp)
14009f27e:     	movl	%esi, -0x40(%rbp)
14009f281:     	movl	%r14d, -0x3c(%rbp)
14009f285:     	movw	%r13w, -0x38(%rbp)
14009f28a:     	movb	%r12b, -0x36(%rbp)
14009f28e:     	movb	%r15b, -0x35(%rbp)
14009f292:     	movd	%xmm6, -0x34(%rbp)
14009f297:     	movq	0x268(%rbp), %rax
14009f29e:     	movq	%rax, -0x30(%rbp)
14009f2a2:     	leaq	-0x28(%rbp), %rcx
14009f2a6:     	movl	$0x108, %r8d            # imm = 0x108
14009f2ac:     	movq	%rbx, %rdx
14009f2af:     	callq	0x1402433f0 <.text+0x2423f0>
14009f2b4:     	leaq	-0x60(%rbp), %rdx
14009f2b8:     	movq	0x260(%rbp), %rcx
14009f2bf:     	callq	0x1402073d0 <.text+0x2063d0>
14009f2c4:     	movb	$0x1, %al
14009f2c6:     	jmp	0x14009f2ca <.text+0x9e2ca>
14009f2c8:     	xorl	%eax, %eax
14009f2ca:     	movaps	0x270(%rbp), %xmm6
14009f2d1:     	movaps	0x280(%rbp), %xmm7
14009f2d8:     	addq	$0x318, %rsp            # imm = 0x318
14009f2df:     	popq	%rbx
14009f2e0:     	popq	%rdi
14009f2e1:     	popq	%rsi
14009f2e2:     	popq	%r12
14009f2e4:     	popq	%r13
14009f2e6:     	popq	%r14
14009f2e8:     	popq	%r15
14009f2ea:     	popq	%rbp
14009f2eb:     	retq
14009f2ec:     	leaq	0x1bc875(%rip), %r9     # 0x14025bb68
14009f2f3:     	movl	$0x10, %r8d
14009f2f9:     	xorl	%ecx, %ecx
14009f2fb:     	movq	%rdi, %rdx
14009f2fe:     	callq	0x140243e40 <.text+0x242e40>
14009f303:     	ud2

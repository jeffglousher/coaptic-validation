
D:\CoapticCurrent\packet-basic-response-20261107\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140069740:     	pushq	%rbp
140069741:     	pushq	%r15
140069743:     	pushq	%r14
140069745:     	pushq	%r13
140069747:     	pushq	%r12
140069749:     	pushq	%rsi
14006974a:     	pushq	%rdi
14006974b:     	pushq	%rbx
14006974c:     	subq	$0x4f8, %rsp            # imm = 0x4F8
140069753:     	leaq	0x80(%rsp), %rbp
14006975b:     	movq	%r9, %rbx
14006975e:     	movq	%r8, %r14
140069761:     	movq	%rdx, %rdi
140069764:     	movq	%rcx, %rsi
140069767:     	movq	0x4f0(%rbp), %r13
14006976e:     	leaq	-0x10(%rbp), %rcx
140069772:     	movl	$0x400, %r8d            # imm = 0x400
140069778:     	xorl	%edx, %edx
14006977a:     	callq	0x140243402 <.text+0x242402>
14006977f:     	movq	0x8(%r13), %rax
140069783:     	movl	$0x3, %ecx
140069788:     	cmpq	$0x3, %rax
14006978c:     	ja	0x140069863 <.text+0x68863>
140069792:     	movq	%rbx, 0x468(%rbp)
140069799:     	cmpb	$0x1, 0x1b748(%rdi,%rax)
1400697a1:     	jne	0x140069863 <.text+0x68863>
1400697a7:     	leaq	0x1ac78(%rdi), %rcx
1400697ae:     	imulq	$0x2b0, %rax, %rdx      # imm = 0x2B0
1400697b5:     	leaq	(%rcx,%rdx), %r12
1400697b9:     	movq	(%rcx,%rdx), %rbx
1400697bd:     	cmpq	$0x2, %rbx
1400697c1:     	jne	0x1400697cf <.text+0x687cf>
1400697c3:     	movq	0x8(%r12), %rdx
1400697c8:     	movq	0x10(%r12), %r8
1400697cd:     	jmp	0x1400697e7 <.text+0x687e7>
1400697cf:     	movq	%rax, %rcx
1400697d2:     	shlq	$0xe, %rcx
1400697d6:     	leaq	(%rdi,%rcx), %rdx
1400697da:     	addq	$0x1b750, %rdx          # imm = 0x1B750
1400697e1:     	movl	$0x4000, %r8d           # imm = 0x4000
1400697e7:     	movq	0x2b750(%rdi,%rax,8), %rax
1400697ef:     	cmpq	%r8, %rax
1400697f2:     	ja	0x1400699ec <.text+0x689ec>
1400697f8:     	movq	0x10(%r13), %r8
1400697fc:     	movq	0x18(%r13), %r15
140069800:     	movq	%r15, %r9
140069803:     	movl	$0xb, %ecx
140069808:     	addq	%r8, %r9
14006980b:     	jb	0x140069863 <.text+0x68863>
14006980d:     	cmpq	$0x400, %r15            # imm = 0x400
140069814:     	ja	0x140069863 <.text+0x68863>
140069816:     	cmpq	%rax, %r9
140069819:     	ja	0x140069863 <.text+0x68863>
14006981b:     	addq	%r8, %rdx
14006981e:     	leaq	-0x10(%rbp), %rcx
140069822:     	movq	%r15, %r8
140069825:     	callq	0x1402433f0 <.text+0x2423f0>
14006982a:     	cmpl	$-0x1, %ebx
14006982d:     	sete	%al
140069830:     	movzbl	0x4f8(%rbp), %ecx
140069837:     	xorb	$0x1, %cl
14006983a:     	orb	%al, %cl
14006983c:     	jne	0x14006987e <.text+0x6887e>
14006983e:     	movq	0x98(%r12), %rax
140069846:     	movq	%rax, 0x470(%rbp)
14006984d:     	movl	$0x1, %ebx
140069852:     	movq	%rdi, %rcx
140069855:     	callq	0x14009b820 <.text+0x9a820>
14006985a:     	testb	$0x1, %al
14006985c:     	jne	0x14006988c <.text+0x6888c>
14006985e:     	movb	$0x9, (%rsi)
140069861:     	jmp	0x14006986a <.text+0x6886a>
140069863:     	movb	$0xa, (%rsi)
140069866:     	movq	%rcx, 0x8(%rsi)
14006986a:     	addq	$0x4f8, %rsp            # imm = 0x4F8
140069871:     	popq	%rbx
140069872:     	popq	%rdi
140069873:     	popq	%rsi
140069874:     	popq	%r12
140069876:     	popq	%r13
140069878:     	popq	%r14
14006987a:     	popq	%r15
14006987c:     	popq	%rbp
14006987d:     	retq
14006987e:     	xorl	%ebx, %ebx
140069880:     	movq	%rdi, %rcx
140069883:     	callq	0x14009b820 <.text+0x9a820>
140069888:     	testb	$0x1, %al
14006988a:     	je	0x14006985e <.text+0x6885e>
14006988c:     	movq	%rdx, %r12
14006988f:     	movq	0x500(%rbp), %rdx
140069896:     	movzwl	0x4e8(%rbp), %ecx
14006989d:     	movzbl	0x4e0(%rbp), %eax
1400698a4:     	movq	(%r13), %r8
1400698a8:     	movq	%rbx, 0x438(%rbp)
1400698af:     	movq	0x470(%rbp), %r9
1400698b6:     	movq	%r9, 0x440(%rbp)
1400698bd:     	movq	%r8, 0x448(%rbp)
1400698c4:     	movzbl	0x4f8(%rbp), %r8d
1400698cc:     	movb	%r8b, 0x450(%rbp)
1400698d3:     	movups	0x38(%r14), %xmm0
1400698d8:     	movups	0x44(%r14), %xmm1
1400698dd:     	movups	%xmm1, 0x3fc(%rbp)
1400698e4:     	movaps	%xmm0, 0x3f0(%rbp)
1400698eb:     	leaq	0x66(%r14), %r8
1400698ef:     	movq	0x56(%r14), %r9
1400698f3:     	movq	0x5d(%r14), %r10
1400698f7:     	movq	%r10, 0x45f(%rbp)
1400698fe:     	movq	%r9, 0x458(%rbp)
140069905:     	leaq	0x458(%rbp), %r9
14006990c:     	movq	%r9, 0x68(%rsp)
140069911:     	movq	%rdx, 0x60(%rsp)
140069916:     	movq	%r14, 0x58(%rsp)
14006991b:     	leaq	0x438(%rbp), %rdx
140069922:     	movq	%rdx, 0x50(%rsp)
140069927:     	movq	%r15, 0x48(%rsp)
14006992c:     	leaq	-0x10(%rbp), %rdx
140069930:     	movq	%rdx, 0x40(%rsp)
140069935:     	movq	0x468(%rbp), %rdx
14006993c:     	movq	%rdx, 0x38(%rsp)
140069941:     	movq	%r8, 0x30(%rsp)
140069946:     	movw	%cx, 0x28(%rsp)
14006994b:     	movb	%al, 0x20(%rsp)
14006994f:     	leaq	0x418(%rbp), %rcx
140069956:     	leaq	0x3f0(%rbp), %r8
14006995d:     	movq	%rdi, %rdx
140069960:     	movq	%r12, %r9
140069963:     	callq	0x1400846e0 <.text+0x836e0>
140069968:     	cmpb	$-0x1, 0x418(%rbp)
14006996f:     	je	0x1400699e0 <.text+0x689e0>
140069971:     	cmpb	$0x1, 0x37740(%rdi,%r12)
14006997a:     	jne	0x1400699c6 <.text+0x689c6>
14006997c:     	cmpb	$0x0, 0x37760(%rdi,%r12)
140069985:     	jne	0x1400699c6 <.text+0x689c6>
140069987:     	movb	$0x0, 0x37740(%rdi,%r12)
140069990:     	decq	0x37788(%rdi)
140069997:     	leaq	0x37740(%rdi), %rax
14006999e:     	movq	$0x0, 0x43610(%rdi,%r12,8)
1400699aa:     	leaq	(%r12,%r12,8), %rcx
1400699ae:     	leaq	(%rcx,%rcx,2), %rcx
1400699b2:     	addq	%r12, %rcx
1400699b5:     	movb	$0x2, 0x36a(%rax,%rcx)
1400699bd:     	leaq	(%r12,%r12,2), %rcx
1400699c1:     	movb	$0x2, 0x5d(%rax,%rcx,8)
1400699c6:     	movups	0x418(%rbp), %xmm0
1400699cd:     	movups	0x428(%rbp), %xmm1
1400699d4:     	movups	%xmm1, 0x10(%rsi)
1400699d8:     	movups	%xmm0, (%rsi)
1400699db:     	jmp	0x14006986a <.text+0x6886a>
1400699e0:     	movq	%r12, 0x8(%rsi)
1400699e4:     	movb	$-0x1, (%rsi)
1400699e7:     	jmp	0x14006986a <.text+0x6886a>
1400699ec:     	leaq	0x1f5285(%rip), %r9     # 0x14025ec78
1400699f3:     	xorl	%ecx, %ecx
1400699f5:     	movq	%rax, %rdx
1400699f8:     	callq	0x140243e40 <.text+0x242e40>
1400699fd:     	ud2

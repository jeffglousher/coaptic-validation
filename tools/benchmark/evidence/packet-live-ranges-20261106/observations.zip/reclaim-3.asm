
D:\CoapticCurrent\packet-basic-response-20261107\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009f310:     	pushq	%rbp
14009f311:     	pushq	%r15
14009f313:     	pushq	%r14
14009f315:     	pushq	%r13
14009f317:     	pushq	%r12
14009f319:     	pushq	%rsi
14009f31a:     	pushq	%rdi
14009f31b:     	pushq	%rbx
14009f31c:     	subq	$0x308, %rsp            # imm = 0x308
14009f323:     	leaq	0x80(%rsp), %rbp
14009f32b:     	movaps	%xmm7, 0x270(%rbp)
14009f332:     	movaps	%xmm6, 0x260(%rbp)
14009f339:     	leaq	0x5000(%rcx), %rax
14009f340:     	leaq	0x30(%rcx), %r8
14009f344:     	xorl	%r9d, %r9d
14009f347:     	xorl	%esi, %esi
14009f349:     	leaq	(%rsi,%rsi,4), %r11
14009f34d:     	shlq	$0x6, %r11
14009f351:     	addq	%r8, %r11
14009f354:     	movq	%rsi, %r10
14009f357:     	jmp	0x14009f374 <.text+0x9e374>
14009f359:     	nopl	(%rax)
14009f360:     	incq	%r10
14009f363:     	addq	$0x140, %r11            # imm = 0x140
14009f36a:     	cmpq	$0x40, %r10
14009f36e:     	je	0x14009f40e <.text+0x9e40e>
14009f374:     	cmpb	$0x1, 0x5000(%rcx,%r10)
14009f37d:     	jne	0x14009f360 <.text+0x9e360>
14009f37f:     	movq	-0x30(%r11), %rdi
14009f383:     	cmpq	$0x2, %rdi
14009f387:     	je	0x14009f360 <.text+0x9e360>
14009f389:     	movq	(%r11), %rsi
14009f38c:     	cmpl	$0x1, %edi
14009f38f:     	setne	%bl
14009f392:     	testq	%rsi, %rsi
14009f395:     	sete	%dil
14009f399:     	orb	%bl, %dil
14009f39c:     	cmpb	$0x1, %dil
14009f3a0:     	je	0x14009f360 <.text+0x9e360>
14009f3a2:     	movq	0x250(%rbp), %rdi
14009f3a9:     	cmpq	%rdi, %rsi
14009f3ac:     	setae	%bl
14009f3af:     	testb	%bl, %r9b
14009f3b2:     	jne	0x14009f3f4 <.text+0x9e3f4>
14009f3b4:     	movd	-0x4(%r11), %xmm6
14009f3ba:     	movzbl	-0x5(%r11), %edx
14009f3bf:     	movb	%dl, 0x25f(%rbp)
14009f3c5:     	movzbl	-0x6(%r11), %r15d
14009f3ca:     	movzwl	-0x8(%r11), %r12d
14009f3cf:     	movl	-0xc(%r11), %r13d
14009f3d3:     	movl	-0x10(%r11), %r14d
14009f3d7:     	movq	-0x18(%r11), %rdx
14009f3db:     	movq	%rdx, 0x248(%rbp)
14009f3e2:     	movq	-0x28(%r11), %rdx
14009f3e6:     	movq	-0x20(%r11), %r9
14009f3ea:     	movq	%r9, 0x240(%rbp)
14009f3f1:     	movq	%rsi, %rdi
14009f3f4:     	movq	%rdi, 0x250(%rbp)
14009f3fb:     	leaq	0x1(%r10), %rsi
14009f3ff:     	movb	$0x1, %r9b
14009f402:     	cmpq	$0x3f, %r10
14009f406:     	jb	0x14009f349 <.text+0x9e349>
14009f40c:     	jmp	0x14009f418 <.text+0x9e418>
14009f40e:     	testb	$0x1, %r9b
14009f412:     	je	0x14009f690 <.text+0x9e690>
14009f418:     	cmpq	$0x1f, %rdx
14009f41c:     	ja	0x14009f46f <.text+0x9e46f>
14009f41e:     	leaq	0x37740(%rcx), %r8
14009f425:     	cmpb	$0x1, (%r8,%rdx)
14009f42a:     	jne	0x14009f46f <.text+0x9e46f>
14009f42c:     	cmpb	$0x0, 0x37760(%rcx,%rdx)
14009f434:     	jne	0x14009f46f <.text+0x9e46f>
14009f436:     	movb	$0x0, 0x37740(%rcx,%rdx)
14009f43e:     	decq	0x37788(%rcx)
14009f445:     	movq	$0x0, 0x43610(%rcx,%rdx,8)
14009f451:     	leaq	(%rdx,%rdx,8), %r9
14009f455:     	leaq	(%r9,%r9,2), %r9
14009f459:     	addq	%rdx, %r9
14009f45c:     	movb	$0x2, 0x36a(%r8,%r9)
14009f465:     	leaq	(%rdx,%rdx,2), %rdx
14009f469:     	movb	$0x2, 0x5d(%r8,%rdx,8)
14009f46f:     	movd	%xmm6, %edx
14009f473:     	movl	$0x2c, %r8d
14009f479:     	movq	0x240(%rbp), %r11
14009f480:     	movq	0x248(%rbp), %rsi
14009f487:     	jmp	0x14009f4a3 <.text+0x9e4a3>
14009f489:     	nopl	(%rax)
14009f490:     	incq	%rax
14009f493:     	addq	$0x140, %r8             # imm = 0x140
14009f49a:     	cmpq	$0x502c, %r8            # imm = 0x502C
14009f4a1:     	je	0x14009f4fc <.text+0x9e4fc>
14009f4a3:     	cmpb	$0x1, (%rax)
14009f4a6:     	jne	0x14009f490 <.text+0x9e490>
14009f4a8:     	cmpl	$0x2, -0x2c(%rcx,%r8)
14009f4ae:     	je	0x14009f490 <.text+0x9e490>
14009f4b0:     	cmpw	%dx, (%rcx,%r8)
14009f4b5:     	jne	0x14009f490 <.text+0x9e490>
14009f4b7:     	cmpl	%r14d, -0xc(%rcx,%r8)
14009f4bc:     	jne	0x14009f490 <.text+0x9e490>
14009f4be:     	cmpl	%r13d, -0x8(%rcx,%r8)
14009f4c3:     	jne	0x14009f490 <.text+0x9e490>
14009f4c5:     	cmpw	%r12w, -0x4(%rcx,%r8)
14009f4cb:     	jne	0x14009f490 <.text+0x9e490>
14009f4cd:     	cmpb	%r15b, -0x2(%rcx,%r8)
14009f4d2:     	jne	0x14009f490 <.text+0x9e490>
14009f4d4:     	movq	-0x1c(%rcx,%r8), %r9
14009f4d9:     	xorq	%r11, %r9
14009f4dc:     	movq	-0x14(%rcx,%r8), %r10
14009f4e1:     	xorq	%rsi, %r10
14009f4e4:     	orq	%r9, %r10
14009f4e7:     	jne	0x14009f490 <.text+0x9e490>
14009f4e9:     	movb	$0x0, (%rax)
14009f4ec:     	decq	0x5048(%rcx)
14009f4f3:     	movq	$0x2, -0x2c(%rcx,%r8)
14009f4fc:     	movq	%rcx, %rsi
14009f4ff:     	xorps	%xmm7, %xmm7
14009f502:     	movaps	%xmm7, 0x230(%rbp)
14009f509:     	movb	$0x0, 0x212(%rbp)
14009f510:     	movw	%dx, 0x210(%rbp)
14009f517:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
14009f520:     	movq	$0x0, 0x213(%rbp)
14009f52b:     	movq	$0x8, 0x1f0(%rbp)
14009f536:     	movq	$0x0, 0x1f8(%rbp)
14009f541:     	movq	$0x1, 0x200(%rbp)
14009f54c:     	movq	$0x0, 0x208(%rbp)
14009f557:     	leaq	0x220(%rbp), %rcx
14009f55e:     	leaq	0x1f0(%rbp), %rdx
14009f565:     	leaq	0x230(%rbp), %r8
14009f56c:     	movl	$0x10, %r9d
14009f572:     	callq	0x140110140 <.text+0x10f140>
14009f577:     	cmpb	$0x0, 0x220(%rbp)
14009f57e:     	jne	0x14009f68c <.text+0x9e68c>
14009f584:     	movq	0x228(%rbp), %rdi
14009f58b:     	movaps	%xmm7, 0xe0(%rbp)
14009f592:     	movaps	%xmm7, 0xf0(%rbp)
14009f599:     	movaps	%xmm7, 0x100(%rbp)
14009f5a0:     	movaps	%xmm7, 0x110(%rbp)
14009f5a7:     	movaps	%xmm7, 0x120(%rbp)
14009f5ae:     	movaps	%xmm7, 0x130(%rbp)
14009f5b5:     	movaps	%xmm7, 0x140(%rbp)
14009f5bc:     	movaps	%xmm7, 0x150(%rbp)
14009f5c3:     	movaps	%xmm7, 0x160(%rbp)
14009f5ca:     	movaps	%xmm7, 0x170(%rbp)
14009f5d1:     	movaps	%xmm7, 0x180(%rbp)
14009f5d8:     	movaps	%xmm7, 0x190(%rbp)
14009f5df:     	movaps	%xmm7, 0x1a0(%rbp)
14009f5e6:     	movaps	%xmm7, 0x1b0(%rbp)
14009f5ed:     	movaps	%xmm7, 0x1c0(%rbp)
14009f5f4:     	movaps	%xmm7, 0x1d0(%rbp)
14009f5fb:     	cmpq	$0x11, %rdi
14009f5ff:     	jae	0x14009f6b4 <.text+0x9e6b4>
14009f605:     	leaq	0xe0(%rbp), %rbx
14009f60c:     	leaq	0x230(%rbp), %rdx
14009f613:     	movq	%rbx, %rcx
14009f616:     	movq	%rdi, %r8
14009f619:     	callq	0x1402433f0 <.text+0x2423f0>
14009f61e:     	movw	%di, 0x1e0(%rbp)
14009f625:     	movq	$0x0, -0x60(%rbp)
14009f62d:     	movq	0x248(%rbp), %rax
14009f634:     	movq	%rax, -0x48(%rbp)
14009f638:     	movq	0x240(%rbp), %rax
14009f63f:     	movq	%rax, -0x50(%rbp)
14009f643:     	movl	%r14d, -0x40(%rbp)
14009f647:     	movl	%r13d, -0x3c(%rbp)
14009f64b:     	movw	%r12w, -0x38(%rbp)
14009f650:     	movb	%r15b, -0x36(%rbp)
14009f654:     	movzbl	0x25f(%rbp), %eax
14009f65b:     	movb	%al, -0x35(%rbp)
14009f65e:     	movd	%xmm6, -0x34(%rbp)
14009f663:     	movq	0x250(%rbp), %rax
14009f66a:     	movq	%rax, -0x30(%rbp)
14009f66e:     	leaq	-0x28(%rbp), %rcx
14009f672:     	movl	$0x108, %r8d            # imm = 0x108
14009f678:     	movq	%rbx, %rdx
14009f67b:     	callq	0x1402433f0 <.text+0x2423f0>
14009f680:     	leaq	-0x60(%rbp), %rdx
14009f684:     	movq	%rsi, %rcx
14009f687:     	callq	0x140207230 <.text+0x206230>
14009f68c:     	movb	$0x1, %al
14009f68e:     	jmp	0x14009f692 <.text+0x9e692>
14009f690:     	xorl	%eax, %eax
14009f692:     	movaps	0x260(%rbp), %xmm6
14009f699:     	movaps	0x270(%rbp), %xmm7
14009f6a0:     	addq	$0x308, %rsp            # imm = 0x308
14009f6a7:     	popq	%rbx
14009f6a8:     	popq	%rdi
14009f6a9:     	popq	%rsi
14009f6aa:     	popq	%r12
14009f6ac:     	popq	%r13
14009f6ae:     	popq	%r14
14009f6b0:     	popq	%r15
14009f6b2:     	popq	%rbp
14009f6b3:     	retq
14009f6b4:     	leaq	0x1bc4ad(%rip), %r9     # 0x14025bb68
14009f6bb:     	movl	$0x10, %r8d
14009f6c1:     	xorl	%ecx, %ecx
14009f6c3:     	movq	%rdi, %rdx
14009f6c6:     	callq	0x140243e40 <.text+0x242e40>
14009f6cb:     	ud2

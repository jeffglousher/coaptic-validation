
D:\CoapticCurrent\packet-basic-response-20261107\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009ec10:     	pushq	%rbp
14009ec11:     	pushq	%r15
14009ec13:     	pushq	%r14
14009ec15:     	pushq	%r13
14009ec17:     	pushq	%r12
14009ec19:     	pushq	%rsi
14009ec1a:     	pushq	%rdi
14009ec1b:     	pushq	%rbx
14009ec1c:     	subq	$0x318, %rsp            # imm = 0x318
14009ec23:     	leaq	0x80(%rsp), %rbp
14009ec2b:     	movaps	%xmm7, 0x280(%rbp)
14009ec32:     	movaps	%xmm6, 0x270(%rbp)
14009ec39:     	leaq	0x30(%rcx), %rdx
14009ec3d:     	xorl	%r8d, %r8d
14009ec40:     	xorl	%r11d, %r11d
14009ec43:     	leaq	(%r11,%r11,4), %r10
14009ec47:     	shlq	$0x6, %r10
14009ec4b:     	addq	%rdx, %r10
14009ec4e:     	movq	%r11, %r9
14009ec51:     	jmp	0x14009ec74 <.text+0x9dc74>
14009ec53:     	nopw	%cs:(%rax,%rax)
14009ec60:     	incq	%r9
14009ec63:     	addq	$0x140, %r10            # imm = 0x140
14009ec6a:     	cmpq	$0x4, %r9
14009ec6e:     	je	0x14009ecfe <.text+0x9dcfe>
14009ec74:     	cmpb	$0x1, 0x510(%rcx,%r9)
14009ec7d:     	jne	0x14009ec60 <.text+0x9dc60>
14009ec7f:     	movq	-0x30(%r10), %rsi
14009ec83:     	cmpq	$0x2, %rsi
14009ec87:     	je	0x14009ec60 <.text+0x9dc60>
14009ec89:     	movq	(%r10), %r11
14009ec8c:     	cmpl	$0x1, %esi
14009ec8f:     	setne	%bl
14009ec92:     	testq	%r11, %r11
14009ec95:     	sete	%sil
14009ec99:     	orb	%bl, %sil
14009ec9c:     	cmpb	$0x1, %sil
14009eca0:     	je	0x14009ec60 <.text+0x9dc60>
14009eca2:     	movq	0x268(%rbp), %rsi
14009eca9:     	cmpq	%rsi, %r11
14009ecac:     	setae	%bl
14009ecaf:     	testb	%bl, %r8b
14009ecb2:     	jne	0x14009ece4 <.text+0x9dce4>
14009ecb4:     	movq	-0x28(%r10), %rax
14009ecb8:     	movd	-0x4(%r10), %xmm6
14009ecbe:     	movzbl	-0x5(%r10), %edi
14009ecc3:     	movzbl	-0x6(%r10), %r15d
14009ecc8:     	movzwl	-0x8(%r10), %r12d
14009eccd:     	movl	-0xc(%r10), %r13d
14009ecd1:     	movl	-0x10(%r10), %r14d
14009ecd5:     	movups	-0x20(%r10), %xmm0
14009ecda:     	movaps	%xmm0, 0x240(%rbp)
14009ece1:     	movq	%r11, %rsi
14009ece4:     	movq	%rsi, 0x268(%rbp)
14009eceb:     	leaq	0x1(%r9), %r11
14009ecef:     	movb	$0x1, %r8b
14009ecf2:     	cmpq	$0x3, %r9
14009ecf6:     	jb	0x14009ec43 <.text+0x9dc43>
14009ecfc:     	jmp	0x14009ed08 <.text+0x9dd08>
14009ecfe:     	testb	$0x1, %r8b
14009ed02:     	je	0x14009ef48 <.text+0x9df48>
14009ed08:     	cmpq	$0x1, %rax
14009ed0c:     	ja	0x14009ed64 <.text+0x9dd64>
14009ed0e:     	cmpb	$0x1, 0x1e80(%rcx,%rax)
14009ed16:     	jne	0x14009ed64 <.text+0x9dd64>
14009ed18:     	cmpb	$0x0, 0x1e82(%rcx,%rax)
14009ed20:     	jne	0x14009ed64 <.text+0x9dd64>
14009ed22:     	movb	$0x0, 0x1e80(%rcx,%rax)
14009ed2a:     	decq	0x1e78(%rcx)
14009ed31:     	leaq	0x14f8(%rcx), %rdx
14009ed38:     	movq	$0x0, 0x1df8(%rcx,%rax,8)
14009ed44:     	leaq	(%rax,%rax,8), %r8
14009ed48:     	leaq	(%r8,%r8,2), %r8
14009ed4c:     	addq	%rax, %r8
14009ed4f:     	movb	$0x2, 0x95a(%rdx,%r8)
14009ed58:     	leaq	(%rax,%rax,2), %rax
14009ed5c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009ed64:     	movaps	0x240(%rbp), %xmm0
14009ed6b:     	movaps	%xmm0, -0x60(%rbp)
14009ed6f:     	movl	%r14d, %esi
14009ed72:     	movl	%r14d, -0x50(%rbp)
14009ed76:     	movl	%r13d, %r14d
14009ed79:     	movl	%r13d, -0x4c(%rbp)
14009ed7d:     	movl	%r12d, %r13d
14009ed80:     	movw	%r12w, -0x48(%rbp)
14009ed85:     	movl	%r15d, %r12d
14009ed88:     	movb	%r15b, -0x46(%rbp)
14009ed8c:     	movl	%edi, %r15d
14009ed8f:     	movb	%dil, -0x45(%rbp)
14009ed93:     	movd	%xmm6, %edi
14009ed97:     	movd	%xmm6, -0x44(%rbp)
14009ed9c:     	leaq	-0x60(%rbp), %rdx
14009eda0:     	movq	%rcx, 0x260(%rbp)
14009eda7:     	callq	0x140207660 <.text+0x206660>
14009edac:     	xorps	%xmm7, %xmm7
14009edaf:     	movaps	%xmm7, 0x250(%rbp)
14009edb6:     	movb	$0x0, 0x222(%rbp)
14009edbd:     	movw	%di, 0x220(%rbp)
14009edc4:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009edcd:     	movq	$0x0, 0x223(%rbp)
14009edd8:     	movq	$0x8, 0x200(%rbp)
14009ede3:     	movq	$0x0, 0x208(%rbp)
14009edee:     	movq	$0x1, 0x210(%rbp)
14009edf9:     	movq	$0x0, 0x218(%rbp)
14009ee04:     	leaq	0x230(%rbp), %rcx
14009ee0b:     	leaq	0x200(%rbp), %rdx
14009ee12:     	leaq	0x250(%rbp), %r8
14009ee19:     	movl	$0x10, %r9d
14009ee1f:     	callq	0x140110140 <.text+0x10f140>
14009ee24:     	cmpb	$0x0, 0x230(%rbp)
14009ee2b:     	jne	0x14009ef44 <.text+0x9df44>
14009ee31:     	movq	0x238(%rbp), %rdi
14009ee38:     	movaps	%xmm7, 0xe0(%rbp)
14009ee3f:     	movaps	%xmm7, 0xf0(%rbp)
14009ee46:     	movaps	%xmm7, 0x100(%rbp)
14009ee4d:     	movaps	%xmm7, 0x110(%rbp)
14009ee54:     	movaps	%xmm7, 0x120(%rbp)
14009ee5b:     	movaps	%xmm7, 0x130(%rbp)
14009ee62:     	movaps	%xmm7, 0x140(%rbp)
14009ee69:     	movaps	%xmm7, 0x150(%rbp)
14009ee70:     	movaps	%xmm7, 0x160(%rbp)
14009ee77:     	movaps	%xmm7, 0x170(%rbp)
14009ee7e:     	movaps	%xmm7, 0x180(%rbp)
14009ee85:     	movaps	%xmm7, 0x190(%rbp)
14009ee8c:     	movaps	%xmm7, 0x1a0(%rbp)
14009ee93:     	movaps	%xmm7, 0x1b0(%rbp)
14009ee9a:     	movaps	%xmm7, 0x1c0(%rbp)
14009eea1:     	movaps	%xmm7, 0x1d0(%rbp)
14009eea8:     	movaps	0x240(%rbp), %xmm0
14009eeaf:     	movups	%xmm0, 0x1f0(%rbp)
14009eeb6:     	cmpq	$0x11, %rdi
14009eeba:     	jae	0x14009ef6c <.text+0x9df6c>
14009eec0:     	leaq	0xe0(%rbp), %rbx
14009eec7:     	leaq	0x250(%rbp), %rdx
14009eece:     	movq	%rbx, %rcx
14009eed1:     	movq	%rdi, %r8
14009eed4:     	callq	0x1402433f0 <.text+0x2423f0>
14009eed9:     	movw	%di, 0x1e0(%rbp)
14009eee0:     	movq	$0x0, -0x60(%rbp)
14009eee8:     	movups	0x1e8(%rbp), %xmm0
14009eeef:     	movups	%xmm0, -0x58(%rbp)
14009eef3:     	movq	0x1f8(%rbp), %rax
14009eefa:     	movq	%rax, -0x48(%rbp)
14009eefe:     	movl	%esi, -0x40(%rbp)
14009ef01:     	movl	%r14d, -0x3c(%rbp)
14009ef05:     	movw	%r13w, -0x38(%rbp)
14009ef0a:     	movb	%r12b, -0x36(%rbp)
14009ef0e:     	movb	%r15b, -0x35(%rbp)
14009ef12:     	movd	%xmm6, -0x34(%rbp)
14009ef17:     	movq	0x268(%rbp), %rax
14009ef1e:     	movq	%rax, -0x30(%rbp)
14009ef22:     	leaq	-0x28(%rbp), %rcx
14009ef26:     	movl	$0x108, %r8d            # imm = 0x108
14009ef2c:     	movq	%rbx, %rdx
14009ef2f:     	callq	0x1402433f0 <.text+0x2423f0>
14009ef34:     	leaq	-0x60(%rbp), %rdx
14009ef38:     	movq	0x260(%rbp), %rcx
14009ef3f:     	callq	0x1402073d0 <.text+0x2063d0>
14009ef44:     	movb	$0x1, %al
14009ef46:     	jmp	0x14009ef4a <.text+0x9df4a>
14009ef48:     	xorl	%eax, %eax
14009ef4a:     	movaps	0x270(%rbp), %xmm6
14009ef51:     	movaps	0x280(%rbp), %xmm7
14009ef58:     	addq	$0x318, %rsp            # imm = 0x318
14009ef5f:     	popq	%rbx
14009ef60:     	popq	%rdi
14009ef61:     	popq	%rsi
14009ef62:     	popq	%r12
14009ef64:     	popq	%r13
14009ef66:     	popq	%r14
14009ef68:     	popq	%r15
14009ef6a:     	popq	%rbp
14009ef6b:     	retq
14009ef6c:     	leaq	0x1bcbf5(%rip), %r9     # 0x14025bb68
14009ef73:     	movl	$0x10, %r8d
14009ef79:     	xorl	%ecx, %ecx
14009ef7b:     	movq	%rdi, %rdx
14009ef7e:     	callq	0x140243e40 <.text+0x242e40>
14009ef83:     	ud2

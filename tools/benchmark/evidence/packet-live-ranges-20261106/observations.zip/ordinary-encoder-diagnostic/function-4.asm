
D:\CoapticCurrent\packet-basic-response-20261107\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401de340:     	pushq	%rbp
1401de341:     	movq	%rsp, %rbp
1401de344:     	movq	%rcx, %rax
1401de347:     	movl	$0x0, (%rcx)
1401de34d:     	movl	$0x0, 0x8(%rcx)
1401de354:     	movw	$0x1, 0x10(%rcx)
1401de35a:     	leaq	0x77aef(%rip), %rcx     # 0x140255e50
1401de361:     	movq	%rcx, 0x18(%rax)
1401de365:     	movq	$0x400, 0x20(%rax)      # imm = 0x400
1401de36d:     	movb	$-0x1, 0xb5(%rax)
1401de374:     	movabsq	$0x65727574786966, %rcx # imm = 0x65727574786966
1401de37e:     	movq	%rcx, 0xc0(%rax)
1401de385:     	movq	$0x0, 0xc8(%rax)
1401de390:     	movq	$0x0, 0xd8(%rax)
1401de39b:     	movq	$0x0, 0x158(%rax)
1401de3a6:     	movq	$0x400, 0x1d8(%rax)     # imm = 0x400
1401de3b1:     	movl	$0x2a0001, 0x1e0(%rax)  # imm = 0x2A0001
1401de3bb:     	movb	$0x0, 0x1e4(%rax)
1401de3c2:     	movabsq	$0x745ff000000, %rcx    # imm = 0x745FF000000
1401de3cc:     	movq	%rcx, 0x20e(%rax)
1401de3d3:     	popq	%rbp
1401de3d4:     	retq

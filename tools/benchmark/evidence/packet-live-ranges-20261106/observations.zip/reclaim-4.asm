
D:\CoapticCurrent\packet-basic-response-20261107\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009f6d0:     	pushq	%rbp
14009f6d1:     	pushq	%r15
14009f6d3:     	pushq	%r14
14009f6d5:     	pushq	%r13
14009f6d7:     	pushq	%r12
14009f6d9:     	pushq	%rsi
14009f6da:     	pushq	%rdi
14009f6db:     	pushq	%rbx
14009f6dc:     	subq	$0x318, %rsp            # imm = 0x318
14009f6e3:     	leaq	0x80(%rsp), %rbp
14009f6eb:     	movaps	%xmm7, 0x280(%rbp)
14009f6f2:     	movdqa	%xmm6, 0x270(%rbp)
14009f6fa:     	movq	0xe8(%rcx), %r8
14009f701:     	testq	%r8, %r8
14009f704:     	je	0x14009fae4 <.text+0x9eae4>
14009f70a:     	movq	0x88(%rcx), %r11
14009f711:     	movq	0xe0(%rcx), %rdx
14009f718:     	movq	0xc8(%rcx), %rax
14009f71f:     	movq	0xd0(%rcx), %r9
14009f726:     	leaq	0x30(%rax), %rsi
14009f72a:     	xorl	%ebx, %ebx
14009f72c:     	xorl	%edi, %edi
14009f72e:     	leaq	(%rdi,%rdi,4), %r12
14009f732:     	shlq	$0x6, %r12
14009f736:     	addq	%rsi, %r12
14009f739:     	jmp	0x14009f753 <.text+0x9e753>
14009f73b:     	nopl	(%rax,%rax)
14009f740:     	incq	%rdi
14009f743:     	addq	$0x140, %r12            # imm = 0x140
14009f74a:     	cmpq	%r8, %rdi
14009f74d:     	jae	0x14009f81c <.text+0x9e81c>
14009f753:     	cmpq	%r9, %rdi
14009f756:     	setb	%r15b
14009f75a:     	andb	(%rdx,%rdi), %r15b
14009f75e:     	cmpb	$0x1, %r15b
14009f762:     	jne	0x14009f740 <.text+0x9e740>
14009f764:     	movq	-0x30(%r12), %r15
14009f769:     	cmpq	$0x2, %r15
14009f76d:     	je	0x14009f740 <.text+0x9e740>
14009f76f:     	movq	(%r12), %r13
14009f773:     	cmpl	$0x1, %r15d
14009f777:     	setne	%r15b
14009f77b:     	testq	%r13, %r13
14009f77e:     	sete	%r10b
14009f782:     	orb	%r15b, %r10b
14009f785:     	cmpb	$0x1, %r10b
14009f789:     	je	0x14009f740 <.text+0x9e740>
14009f78b:     	movq	0x260(%rbp), %r15
14009f792:     	cmpq	%r15, %r13
14009f795:     	setae	%r10b
14009f799:     	testb	%r10b, %bl
14009f79c:     	jne	0x14009f805 <.text+0x9e805>
14009f79e:     	movq	-0x28(%r12), %r10
14009f7a3:     	movq	%r10, 0x250(%rbp)
14009f7aa:     	movq	-0x20(%r12), %r10
14009f7af:     	movq	%r10, 0x248(%rbp)
14009f7b6:     	movd	-0x4(%r12), %xmm6
14009f7bd:     	movzbl	-0x5(%r12), %r10d
14009f7c3:     	movb	%r10b, 0x26e(%rbp)
14009f7ca:     	movzbl	-0x6(%r12), %r10d
14009f7d0:     	movb	%r10b, 0x26f(%rbp)
14009f7d7:     	movzwl	-0x8(%r12), %r10d
14009f7dd:     	movw	%r10w, 0x26c(%rbp)
14009f7e5:     	movl	-0xc(%r12), %r10d
14009f7ea:     	movl	%r10d, 0x268(%rbp)
14009f7f1:     	movl	-0x10(%r12), %r14d
14009f7f6:     	movq	-0x18(%r12), %r10
14009f7fb:     	movq	%r10, 0x258(%rbp)
14009f802:     	movq	%r13, %r15
14009f805:     	movq	%r15, 0x260(%rbp)
14009f80c:     	incq	%rdi
14009f80f:     	movb	$0x1, %bl
14009f811:     	cmpq	%r8, %rdi
14009f814:     	jb	0x14009f72e <.text+0x9e72e>
14009f81a:     	jmp	0x14009f825 <.text+0x9e825>
14009f81c:     	testb	$0x1, %bl
14009f81f:     	je	0x14009fae4 <.text+0x9eae4>
14009f825:     	movq	0x250(%rbp), %r10
14009f82c:     	cmpq	%r11, %r10
14009f82f:     	jae	0x14009f885 <.text+0x9e885>
14009f831:     	movq	0x80(%rcx), %r11
14009f838:     	cmpb	$0x1, (%r11,%r10)
14009f83d:     	jne	0x14009f885 <.text+0x9e885>
14009f83f:     	cmpq	0xa0(%rcx), %r10
14009f846:     	jae	0x14009f856 <.text+0x9e856>
14009f848:     	movq	0x98(%rcx), %rsi
14009f84f:     	cmpb	$0x0, (%rsi,%r10)
14009f854:     	jne	0x14009f885 <.text+0x9e885>
14009f856:     	movb	$0x0, (%r11,%r10)
14009f85b:     	decq	0xb0(%rcx)
14009f862:     	cmpq	0x70(%rcx), %r10
14009f866:     	jae	0x14009f885 <.text+0x9e885>
14009f868:     	movq	0x68(%rcx), %r11
14009f86c:     	imulq	$0x58, %r10, %r10
14009f870:     	movq	$0x0, 0x30(%r11,%r10)
14009f879:     	movb	$0x2, 0x52(%r11,%r10)
14009f87f:     	movb	$0x2, 0x25(%r11,%r10)
14009f885:     	leaq	0xc0(%rcx), %rsi
14009f88c:     	movd	%xmm6, %r10d
14009f891:     	addq	$0x2c, %rax
14009f895:     	xorl	%r11d, %r11d
14009f898:     	movq	0x248(%rbp), %r15
14009f89f:     	movzbl	0x26e(%rbp), %r12d
14009f8a7:     	jmp	0x14009f8c2 <.text+0x9e8c2>
14009f8a9:     	nopl	(%rax)
14009f8b0:     	incq	%r11
14009f8b3:     	addq	$0x140, %rax            # imm = 0x140
14009f8b9:     	cmpq	%r11, %r8
14009f8bc:     	je	0x14009f94e <.text+0x9e94e>
14009f8c2:     	cmpq	%r9, %r11
14009f8c5:     	setb	%bl
14009f8c8:     	andb	(%rdx,%r11), %bl
14009f8cc:     	cmpb	$0x1, %bl
14009f8cf:     	jne	0x14009f8b0 <.text+0x9e8b0>
14009f8d1:     	cmpl	$0x2, -0x2c(%rax)
14009f8d5:     	je	0x14009f8b0 <.text+0x9e8b0>
14009f8d7:     	cmpw	%r10w, (%rax)
14009f8db:     	jne	0x14009f8b0 <.text+0x9e8b0>
14009f8dd:     	cmpl	%r14d, -0xc(%rax)
14009f8e1:     	jne	0x14009f8b0 <.text+0x9e8b0>
14009f8e3:     	movl	0x268(%rbp), %edi
14009f8e9:     	cmpl	%edi, -0x8(%rax)
14009f8ec:     	jne	0x14009f8b0 <.text+0x9e8b0>
14009f8ee:     	movzwl	0x26c(%rbp), %edi
14009f8f5:     	cmpw	%di, -0x4(%rax)
14009f8f9:     	jne	0x14009f8b0 <.text+0x9e8b0>
14009f8fb:     	movzbl	0x26f(%rbp), %ebx
14009f902:     	cmpb	%bl, -0x2(%rax)
14009f905:     	jne	0x14009f8b0 <.text+0x9e8b0>
14009f907:     	movq	-0x1c(%rax), %rdi
14009f90b:     	xorq	%r15, %rdi
14009f90e:     	movq	-0x14(%rax), %rbx
14009f912:     	xorq	0x258(%rbp), %rbx
14009f919:     	orq	%rdi, %rbx
14009f91c:     	jne	0x14009f8b0 <.text+0x9e8b0>
14009f91e:     	cmpq	%r8, %r11
14009f921:     	jae	0x14009f94e <.text+0x9e94e>
14009f923:     	cmpq	0x100(%rcx), %r11
14009f92a:     	jae	0x14009f93a <.text+0x9e93a>
14009f92c:     	movq	0xf8(%rcx), %r8
14009f933:     	cmpb	$0x0, (%r8,%r11)
14009f938:     	jne	0x14009f94e <.text+0x9e94e>
14009f93a:     	movb	$0x0, (%rdx,%r11)
14009f93f:     	decq	0x110(%rcx)
14009f946:     	movq	$0x2, -0x2c(%rax)
14009f94e:     	xorps	%xmm7, %xmm7
14009f951:     	movaps	%xmm7, 0x230(%rbp)
14009f958:     	movb	$0x0, 0x212(%rbp)
14009f95f:     	movw	%r10w, 0x210(%rbp)
14009f967:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
14009f970:     	movq	$0x0, 0x213(%rbp)
14009f97b:     	movq	$0x8, 0x1f0(%rbp)
14009f986:     	movq	$0x0, 0x1f8(%rbp)
14009f991:     	movq	$0x1, 0x200(%rbp)
14009f99c:     	movq	$0x0, 0x208(%rbp)
14009f9a7:     	leaq	0x220(%rbp), %rcx
14009f9ae:     	leaq	0x1f0(%rbp), %rdx
14009f9b5:     	leaq	0x230(%rbp), %r8
14009f9bc:     	movl	$0x10, %r9d
14009f9c2:     	callq	0x140110140 <.text+0x10f140>
14009f9c7:     	cmpb	$0x0, 0x220(%rbp)
14009f9ce:     	jne	0x14009fae0 <.text+0x9eae0>
14009f9d4:     	movq	0x228(%rbp), %rdi
14009f9db:     	movaps	%xmm7, 0xe0(%rbp)
14009f9e2:     	movaps	%xmm7, 0xf0(%rbp)
14009f9e9:     	movaps	%xmm7, 0x100(%rbp)
14009f9f0:     	movaps	%xmm7, 0x110(%rbp)
14009f9f7:     	movaps	%xmm7, 0x120(%rbp)
14009f9fe:     	movaps	%xmm7, 0x130(%rbp)
14009fa05:     	movaps	%xmm7, 0x140(%rbp)
14009fa0c:     	movaps	%xmm7, 0x150(%rbp)
14009fa13:     	movaps	%xmm7, 0x160(%rbp)
14009fa1a:     	movaps	%xmm7, 0x170(%rbp)
14009fa21:     	movaps	%xmm7, 0x180(%rbp)
14009fa28:     	movaps	%xmm7, 0x190(%rbp)
14009fa2f:     	movaps	%xmm7, 0x1a0(%rbp)
14009fa36:     	movaps	%xmm7, 0x1b0(%rbp)
14009fa3d:     	movaps	%xmm7, 0x1c0(%rbp)
14009fa44:     	movaps	%xmm7, 0x1d0(%rbp)
14009fa4b:     	cmpq	$0x11, %rdi
14009fa4f:     	jae	0x14009fb08 <.text+0x9eb08>
14009fa55:     	leaq	0xe0(%rbp), %rbx
14009fa5c:     	leaq	0x230(%rbp), %rdx
14009fa63:     	movq	%rbx, %rcx
14009fa66:     	movq	%rdi, %r8
14009fa69:     	callq	0x1402433f0 <.text+0x2423f0>
14009fa6e:     	movw	%di, 0x1e0(%rbp)
14009fa75:     	movq	$0x0, -0x60(%rbp)
14009fa7d:     	movq	0x258(%rbp), %rax
14009fa84:     	movq	%rax, -0x48(%rbp)
14009fa88:     	movq	%r15, -0x50(%rbp)
14009fa8c:     	movl	%r14d, -0x40(%rbp)
14009fa90:     	movl	0x268(%rbp), %eax
14009fa96:     	movl	%eax, -0x3c(%rbp)
14009fa99:     	movzwl	0x26c(%rbp), %eax
14009faa0:     	movw	%ax, -0x38(%rbp)
14009faa4:     	movzbl	0x26f(%rbp), %eax
14009faab:     	movb	%al, -0x36(%rbp)
14009faae:     	movb	%r12b, -0x35(%rbp)
14009fab2:     	movd	%xmm6, -0x34(%rbp)
14009fab7:     	movq	0x260(%rbp), %rax
14009fabe:     	movq	%rax, -0x30(%rbp)
14009fac2:     	leaq	-0x28(%rbp), %rcx
14009fac6:     	movl	$0x108, %r8d            # imm = 0x108
14009facc:     	movq	%rbx, %rdx
14009facf:     	callq	0x1402433f0 <.text+0x2423f0>
14009fad4:     	leaq	-0x60(%rbp), %rdx
14009fad8:     	movq	%rsi, %rcx
14009fadb:     	callq	0x1400116e0 <.text+0x106e0>
14009fae0:     	movb	$0x1, %al
14009fae2:     	jmp	0x14009fae6 <.text+0x9eae6>
14009fae4:     	xorl	%eax, %eax
14009fae6:     	movaps	0x270(%rbp), %xmm6
14009faed:     	movaps	0x280(%rbp), %xmm7
14009faf4:     	addq	$0x318, %rsp            # imm = 0x318
14009fafb:     	popq	%rbx
14009fafc:     	popq	%rdi
14009fafd:     	popq	%rsi
14009fafe:     	popq	%r12
14009fb00:     	popq	%r13
14009fb02:     	popq	%r14
14009fb04:     	popq	%r15
14009fb06:     	popq	%rbp
14009fb07:     	retq
14009fb08:     	leaq	0x1bc059(%rip), %r9     # 0x14025bb68
14009fb0f:     	movl	$0x10, %r8d
14009fb15:     	xorl	%ecx, %ecx
14009fb17:     	movq	%rdi, %rdx
14009fb1a:     	callq	0x140243e40 <.text+0x242e40>
14009fb1f:     	ud2

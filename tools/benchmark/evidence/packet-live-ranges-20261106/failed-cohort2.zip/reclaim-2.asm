
D:\CoapticCurrent\packet-response-origin-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140099070:     	pushq	%rbp
140099071:     	pushq	%r15
140099073:     	pushq	%r14
140099075:     	pushq	%r13
140099077:     	pushq	%r12
140099079:     	pushq	%rsi
14009907a:     	pushq	%rdi
14009907b:     	pushq	%rbx
14009907c:     	subq	$0x318, %rsp            # imm = 0x318
140099083:     	leaq	0x80(%rsp), %rbp
14009908b:     	movaps	%xmm7, 0x280(%rbp)
140099092:     	movaps	%xmm6, 0x270(%rbp)
140099099:     	leaq	0x30(%rcx), %rdx
14009909d:     	xorl	%r8d, %r8d
1400990a0:     	xorl	%r11d, %r11d
1400990a3:     	leaq	(%r11,%r11,4), %r10
1400990a7:     	shlq	$0x6, %r10
1400990ab:     	addq	%rdx, %r10
1400990ae:     	movq	%r11, %r9
1400990b1:     	jmp	0x1400990d4 <.text+0x980d4>
1400990b3:     	nopw	%cs:(%rax,%rax)
1400990c0:     	incq	%r9
1400990c3:     	addq	$0x140, %r10            # imm = 0x140
1400990ca:     	cmpq	$0x4, %r9
1400990ce:     	je	0x14009915e <.text+0x9815e>
1400990d4:     	cmpb	$0x1, 0x510(%rcx,%r9)
1400990dd:     	jne	0x1400990c0 <.text+0x980c0>
1400990df:     	movq	-0x30(%r10), %rsi
1400990e3:     	cmpq	$0x2, %rsi
1400990e7:     	je	0x1400990c0 <.text+0x980c0>
1400990e9:     	movq	(%r10), %r11
1400990ec:     	cmpl	$0x1, %esi
1400990ef:     	setne	%bl
1400990f2:     	testq	%r11, %r11
1400990f5:     	sete	%sil
1400990f9:     	orb	%bl, %sil
1400990fc:     	cmpb	$0x1, %sil
140099100:     	je	0x1400990c0 <.text+0x980c0>
140099102:     	movq	0x268(%rbp), %rsi
140099109:     	cmpq	%rsi, %r11
14009910c:     	setae	%bl
14009910f:     	testb	%bl, %r8b
140099112:     	jne	0x140099144 <.text+0x98144>
140099114:     	movq	-0x28(%r10), %rax
140099118:     	movd	-0x4(%r10), %xmm6
14009911e:     	movzbl	-0x5(%r10), %edi
140099123:     	movzbl	-0x6(%r10), %r15d
140099128:     	movzwl	-0x8(%r10), %r12d
14009912d:     	movl	-0xc(%r10), %r13d
140099131:     	movl	-0x10(%r10), %r14d
140099135:     	movups	-0x20(%r10), %xmm0
14009913a:     	movaps	%xmm0, 0x240(%rbp)
140099141:     	movq	%r11, %rsi
140099144:     	movq	%rsi, 0x268(%rbp)
14009914b:     	leaq	0x1(%r9), %r11
14009914f:     	movb	$0x1, %r8b
140099152:     	cmpq	$0x3, %r9
140099156:     	jb	0x1400990a3 <.text+0x980a3>
14009915c:     	jmp	0x140099168 <.text+0x98168>
14009915e:     	testb	$0x1, %r8b
140099162:     	je	0x1400993a8 <.text+0x983a8>
140099168:     	cmpq	$0x1, %rax
14009916c:     	ja	0x1400991c4 <.text+0x981c4>
14009916e:     	cmpb	$0x1, 0x4420(%rcx,%rax)
140099176:     	jne	0x1400991c4 <.text+0x981c4>
140099178:     	cmpb	$0x0, 0x4422(%rcx,%rax)
140099180:     	jne	0x1400991c4 <.text+0x981c4>
140099182:     	movb	$0x0, 0x4420(%rcx,%rax)
14009918a:     	decq	0x4418(%rcx)
140099191:     	leaq	0x3a98(%rcx), %rdx
140099198:     	movq	$0x0, 0x4398(%rcx,%rax,8)
1400991a4:     	leaq	(%rax,%rax,8), %r8
1400991a8:     	leaq	(%r8,%r8,2), %r8
1400991ac:     	addq	%rax, %r8
1400991af:     	movb	$0x2, 0x95a(%rdx,%r8)
1400991b8:     	leaq	(%rax,%rax,2), %rax
1400991bc:     	movb	$0x2, 0x91d(%rdx,%rax,8)
1400991c4:     	movaps	0x240(%rbp), %xmm0
1400991cb:     	movaps	%xmm0, -0x60(%rbp)
1400991cf:     	movl	%r14d, %esi
1400991d2:     	movl	%r14d, -0x50(%rbp)
1400991d6:     	movl	%r13d, %r14d
1400991d9:     	movl	%r13d, -0x4c(%rbp)
1400991dd:     	movl	%r12d, %r13d
1400991e0:     	movw	%r12w, -0x48(%rbp)
1400991e5:     	movl	%r15d, %r12d
1400991e8:     	movb	%r15b, -0x46(%rbp)
1400991ec:     	movl	%edi, %r15d
1400991ef:     	movb	%dil, -0x45(%rbp)
1400991f3:     	movd	%xmm6, %edi
1400991f7:     	movd	%xmm6, -0x44(%rbp)
1400991fc:     	leaq	-0x60(%rbp), %rdx
140099200:     	movq	%rcx, 0x260(%rbp)
140099207:     	callq	0x14020d140 <.text+0x20c140>
14009920c:     	xorps	%xmm7, %xmm7
14009920f:     	movaps	%xmm7, 0x250(%rbp)
140099216:     	movb	$0x0, 0x222(%rbp)
14009921d:     	movw	%di, 0x220(%rbp)
140099224:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009922d:     	movq	$0x0, 0x223(%rbp)
140099238:     	movq	$0x8, 0x200(%rbp)
140099243:     	movq	$0x0, 0x208(%rbp)
14009924e:     	movq	$0x1, 0x210(%rbp)
140099259:     	movq	$0x0, 0x218(%rbp)
140099264:     	leaq	0x230(%rbp), %rcx
14009926b:     	leaq	0x200(%rbp), %rdx
140099272:     	leaq	0x250(%rbp), %r8
140099279:     	movl	$0x10, %r9d
14009927f:     	callq	0x14010b560 <.text+0x10a560>
140099284:     	cmpb	$0x0, 0x230(%rbp)
14009928b:     	jne	0x1400993a4 <.text+0x983a4>
140099291:     	movq	0x238(%rbp), %rdi
140099298:     	movaps	%xmm7, 0xe0(%rbp)
14009929f:     	movaps	%xmm7, 0xf0(%rbp)
1400992a6:     	movaps	%xmm7, 0x100(%rbp)
1400992ad:     	movaps	%xmm7, 0x110(%rbp)
1400992b4:     	movaps	%xmm7, 0x120(%rbp)
1400992bb:     	movaps	%xmm7, 0x130(%rbp)
1400992c2:     	movaps	%xmm7, 0x140(%rbp)
1400992c9:     	movaps	%xmm7, 0x150(%rbp)
1400992d0:     	movaps	%xmm7, 0x160(%rbp)
1400992d7:     	movaps	%xmm7, 0x170(%rbp)
1400992de:     	movaps	%xmm7, 0x180(%rbp)
1400992e5:     	movaps	%xmm7, 0x190(%rbp)
1400992ec:     	movaps	%xmm7, 0x1a0(%rbp)
1400992f3:     	movaps	%xmm7, 0x1b0(%rbp)
1400992fa:     	movaps	%xmm7, 0x1c0(%rbp)
140099301:     	movaps	%xmm7, 0x1d0(%rbp)
140099308:     	movaps	0x240(%rbp), %xmm0
14009930f:     	movups	%xmm0, 0x1f0(%rbp)
140099316:     	cmpq	$0x11, %rdi
14009931a:     	jae	0x1400993cc <.text+0x983cc>
140099320:     	leaq	0xe0(%rbp), %rbx
140099327:     	leaq	0x250(%rbp), %rdx
14009932e:     	movq	%rbx, %rcx
140099331:     	movq	%rdi, %r8
140099334:     	callq	0x140247b40 <.text+0x246b40>
140099339:     	movw	%di, 0x1e0(%rbp)
140099340:     	movq	$0x0, -0x60(%rbp)
140099348:     	movups	0x1e8(%rbp), %xmm0
14009934f:     	movups	%xmm0, -0x58(%rbp)
140099353:     	movq	0x1f8(%rbp), %rax
14009935a:     	movq	%rax, -0x48(%rbp)
14009935e:     	movl	%esi, -0x40(%rbp)
140099361:     	movl	%r14d, -0x3c(%rbp)
140099365:     	movw	%r13w, -0x38(%rbp)
14009936a:     	movb	%r12b, -0x36(%rbp)
14009936e:     	movb	%r15b, -0x35(%rbp)
140099372:     	movd	%xmm6, -0x34(%rbp)
140099377:     	movq	0x268(%rbp), %rax
14009937e:     	movq	%rax, -0x30(%rbp)
140099382:     	leaq	-0x28(%rbp), %rcx
140099386:     	movl	$0x108, %r8d            # imm = 0x108
14009938c:     	movq	%rbx, %rdx
14009938f:     	callq	0x140247b40 <.text+0x246b40>
140099394:     	leaq	-0x60(%rbp), %rdx
140099398:     	movq	0x260(%rbp), %rcx
14009939f:     	callq	0x14020ceb0 <.text+0x20beb0>
1400993a4:     	movb	$0x1, %al
1400993a6:     	jmp	0x1400993aa <.text+0x983aa>
1400993a8:     	xorl	%eax, %eax
1400993aa:     	movaps	0x270(%rbp), %xmm6
1400993b1:     	movaps	0x280(%rbp), %xmm7
1400993b8:     	addq	$0x318, %rsp            # imm = 0x318
1400993bf:     	popq	%rbx
1400993c0:     	popq	%rdi
1400993c1:     	popq	%rsi
1400993c2:     	popq	%r12
1400993c4:     	popq	%r13
1400993c6:     	popq	%r14
1400993c8:     	popq	%r15
1400993ca:     	popq	%rbp
1400993cb:     	retq
1400993cc:     	leaq	0x1c6795(%rip), %r9     # 0x14025fb68
1400993d3:     	movl	$0x10, %r8d
1400993d9:     	xorl	%ecx, %ecx
1400993db:     	movq	%rdi, %rdx
1400993de:     	callq	0x140248590 <.text+0x247590>
1400993e3:     	ud2

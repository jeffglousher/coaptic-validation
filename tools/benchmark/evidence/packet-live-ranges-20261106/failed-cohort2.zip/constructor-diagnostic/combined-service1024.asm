
D:\CoapticCurrent\packet-response-origin-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401deec0:     	pushq	%rbp
1401deec1:     	movq	%rsp, %rbp
1401deec4:     	movq	%rcx, %rax
1401deec7:     	movl	$0x0, (%rcx)
1401deecd:     	movl	$0x0, 0x8(%rcx)
1401deed4:     	movw	$0x1, 0x10(%rcx)
1401deeda:     	leaq	0x7af6f(%rip), %rcx     # 0x140259e50
1401deee1:     	movq	%rcx, 0x18(%rax)
1401deee5:     	movq	$0x400, 0x20(%rax)      # imm = 0x400
1401deeed:     	movb	$-0x1, 0xb5(%rax)
1401deef4:     	movq	$0x1, 0xc0(%rax)
1401deeff:     	movq	$0x0, 0xc8(%rax)
1401def0a:     	movq	$0x1, 0xd0(%rax)
1401def15:     	movq	$0x0, 0xd8(%rax)
1401def20:     	movq	$0x1, 0xe0(%rax)
1401def2b:     	movq	$0x0, 0xe8(%rax)
1401def36:     	movq	$0x1, 0xf0(%rax)
1401def41:     	movq	$0x0, 0xf8(%rax)
1401def4c:     	movq	$0x1, 0x100(%rax)
1401def57:     	movq	$0x0, 0x108(%rax)
1401def62:     	movq	$0x1, 0x110(%rax)
1401def6d:     	movq	$0x0, 0x118(%rax)
1401def78:     	movq	$0x1, 0x120(%rax)
1401def83:     	movq	$0x0, 0x128(%rax)
1401def8e:     	movq	$0x1, 0x130(%rax)
1401def99:     	movq	$0x0, 0x138(%rax)
1401defa4:     	movq	$0x1, 0x140(%rax)
1401defaf:     	movq	$0x0, 0x148(%rax)
1401defba:     	movq	$0x1, 0x150(%rax)
1401defc5:     	movq	$0x0, 0x158(%rax)
1401defd0:     	movq	$0x1, 0x160(%rax)
1401defdb:     	movq	$0x0, 0x168(%rax)
1401defe6:     	movq	$0x1, 0x170(%rax)
1401deff1:     	movq	$0x0, 0x178(%rax)
1401deffc:     	movq	$0x1, 0x180(%rax)
1401df007:     	movq	$0x0, 0x188(%rax)
1401df012:     	movq	$0x1, 0x190(%rax)
1401df01d:     	movq	$0x0, 0x198(%rax)
1401df028:     	movq	$0x1, 0x1a0(%rax)
1401df033:     	movq	$0x0, 0x1a8(%rax)
1401df03e:     	movq	$0x1, 0x1b0(%rax)
1401df049:     	movq	$0x0, 0x1b8(%rax)
1401df054:     	movabsq	$0x65727574786966, %rcx # imm = 0x65727574786966
1401df05e:     	movq	%rcx, 0x1c0(%rax)
1401df065:     	movq	$0x0, 0x1c8(%rax)
1401df070:     	movq	$0x400, 0x1d8(%rax)     # imm = 0x400
1401df07b:     	movl	$0x2a0001, 0x1e0(%rax)  # imm = 0x2A0001
1401df085:     	movb	$0x0, 0x1e4(%rax)
1401df08c:     	movabsq	$0x745ff000000, %rcx    # imm = 0x745FF000000
1401df096:     	movq	%rcx, 0x20e(%rax)
1401df09d:     	popq	%rbp
1401df09e:     	retq

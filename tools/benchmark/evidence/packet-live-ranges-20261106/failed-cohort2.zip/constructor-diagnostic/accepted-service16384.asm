
D:\CoapticCurrent\phase-sharing-static-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401e5f10:     	pushq	%rbp
1401e5f11:     	movq	%rsp, %rbp
1401e5f14:     	movq	%rcx, %rax
1401e5f17:     	movq	$0x0, (%rcx)
1401e5f1e:     	movl	$0x0, 0x10(%rcx)
1401e5f25:     	movl	$0x0, 0x18(%rcx)
1401e5f2c:     	movw	$0x1, 0x20(%rcx)
1401e5f32:     	leaq	0x7bf17(%rip), %rcx     # 0x140261e50
1401e5f39:     	movq	%rcx, 0x28(%rax)
1401e5f3d:     	movq	$0x4000, 0x30(%rax)     # imm = 0x4000
1401e5f45:     	movb	$-0x1, 0xcd(%rax)
1401e5f4c:     	movq	$0x1, 0xd8(%rax)
1401e5f57:     	movq	$0x0, 0xe0(%rax)
1401e5f62:     	movq	$0x1, 0xe8(%rax)
1401e5f6d:     	movq	$0x0, 0xf0(%rax)
1401e5f78:     	movq	$0x1, 0xf8(%rax)
1401e5f83:     	movq	$0x0, 0x100(%rax)
1401e5f8e:     	movq	$0x1, 0x108(%rax)
1401e5f99:     	movq	$0x0, 0x110(%rax)
1401e5fa4:     	movq	$0x1, 0x118(%rax)
1401e5faf:     	movq	$0x0, 0x120(%rax)
1401e5fba:     	movq	$0x1, 0x128(%rax)
1401e5fc5:     	movq	$0x0, 0x130(%rax)
1401e5fd0:     	movq	$0x1, 0x138(%rax)
1401e5fdb:     	movq	$0x0, 0x140(%rax)
1401e5fe6:     	movq	$0x1, 0x148(%rax)
1401e5ff1:     	movq	$0x0, 0x150(%rax)
1401e5ffc:     	movq	$0x1, 0x158(%rax)
1401e6007:     	movq	$0x0, 0x160(%rax)
1401e6012:     	movq	$0x1, 0x168(%rax)
1401e601d:     	movq	$0x0, 0x170(%rax)
1401e6028:     	movq	$0x1, 0x178(%rax)
1401e6033:     	movq	$0x0, 0x180(%rax)
1401e603e:     	movq	$0x1, 0x188(%rax)
1401e6049:     	movq	$0x0, 0x190(%rax)
1401e6054:     	movq	$0x1, 0x198(%rax)
1401e605f:     	movq	$0x0, 0x1a0(%rax)
1401e606a:     	movq	$0x1, 0x1a8(%rax)
1401e6075:     	movq	$0x0, 0x1b0(%rax)
1401e6080:     	movq	$0x1, 0x1b8(%rax)
1401e608b:     	movq	$0x0, 0x1c0(%rax)
1401e6096:     	movq	$0x1, 0x1c8(%rax)
1401e60a1:     	movq	$0x0, 0x1d0(%rax)
1401e60ac:     	movabsq	$0x65727574786966, %rcx # imm = 0x65727574786966
1401e60b6:     	movq	%rcx, 0x1d8(%rax)
1401e60bd:     	movq	$0x0, 0x1e0(%rax)
1401e60c8:     	movq	$0x4000, 0x1f0(%rax)    # imm = 0x4000
1401e60d3:     	movl	$0x2a0001, 0x1f8(%rax)  # imm = 0x2A0001
1401e60dd:     	movw	$0x0, 0x1fc(%rax)
1401e60e6:     	movb	$0x2, 0x21a(%rax)
1401e60ed:     	movb	$0x0, 0x21c(%rax)
1401e60f4:     	movb	$0x0, 0x226(%rax)
1401e60fb:     	movabsq	$0x745ffff000000, %rcx  # imm = 0x745FFFF000000
1401e6105:     	movq	%rcx, 0x250(%rax)
1401e610c:     	movb	$0x0, 0x258(%rax)
1401e6113:     	popq	%rbp
1401e6114:     	retq


D:\CoapticCurrent\phase-sharing-static-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401e5c90:     	pushq	%rbp
1401e5c91:     	movq	%rsp, %rbp
1401e5c94:     	movq	%rcx, %rax
1401e5c97:     	movq	$0x0, (%rcx)
1401e5c9e:     	movl	$0x0, 0x10(%rcx)
1401e5ca5:     	movl	$0x0, 0x18(%rcx)
1401e5cac:     	movw	$0x1, 0x20(%rcx)
1401e5cb2:     	leaq	0x7c197(%rip), %rcx     # 0x140261e50
1401e5cb9:     	movq	%rcx, 0x28(%rax)
1401e5cbd:     	movq	$0x400, 0x30(%rax)      # imm = 0x400
1401e5cc5:     	movb	$-0x1, 0xcd(%rax)
1401e5ccc:     	movq	$0x1, 0xd8(%rax)
1401e5cd7:     	movq	$0x0, 0xe0(%rax)
1401e5ce2:     	movq	$0x1, 0xe8(%rax)
1401e5ced:     	movq	$0x0, 0xf0(%rax)
1401e5cf8:     	movq	$0x1, 0xf8(%rax)
1401e5d03:     	movq	$0x0, 0x100(%rax)
1401e5d0e:     	movq	$0x1, 0x108(%rax)
1401e5d19:     	movq	$0x0, 0x110(%rax)
1401e5d24:     	movq	$0x1, 0x118(%rax)
1401e5d2f:     	movq	$0x0, 0x120(%rax)
1401e5d3a:     	movq	$0x1, 0x128(%rax)
1401e5d45:     	movq	$0x0, 0x130(%rax)
1401e5d50:     	movq	$0x1, 0x138(%rax)
1401e5d5b:     	movq	$0x0, 0x140(%rax)
1401e5d66:     	movq	$0x1, 0x148(%rax)
1401e5d71:     	movq	$0x0, 0x150(%rax)
1401e5d7c:     	movq	$0x1, 0x158(%rax)
1401e5d87:     	movq	$0x0, 0x160(%rax)
1401e5d92:     	movq	$0x1, 0x168(%rax)
1401e5d9d:     	movq	$0x0, 0x170(%rax)
1401e5da8:     	movq	$0x1, 0x178(%rax)
1401e5db3:     	movq	$0x0, 0x180(%rax)
1401e5dbe:     	movq	$0x1, 0x188(%rax)
1401e5dc9:     	movq	$0x0, 0x190(%rax)
1401e5dd4:     	movq	$0x1, 0x198(%rax)
1401e5ddf:     	movq	$0x0, 0x1a0(%rax)
1401e5dea:     	movq	$0x1, 0x1a8(%rax)
1401e5df5:     	movq	$0x0, 0x1b0(%rax)
1401e5e00:     	movq	$0x1, 0x1b8(%rax)
1401e5e0b:     	movq	$0x0, 0x1c0(%rax)
1401e5e16:     	movq	$0x1, 0x1c8(%rax)
1401e5e21:     	movq	$0x0, 0x1d0(%rax)
1401e5e2c:     	movabsq	$0x65727574786966, %rcx # imm = 0x65727574786966
1401e5e36:     	movq	%rcx, 0x1d8(%rax)
1401e5e3d:     	movq	$0x0, 0x1e0(%rax)
1401e5e48:     	movq	$0x400, 0x1f0(%rax)     # imm = 0x400
1401e5e53:     	movl	$0x2a0001, 0x1f8(%rax)  # imm = 0x2A0001
1401e5e5d:     	movw	$0x0, 0x1fc(%rax)
1401e5e66:     	movb	$0x2, 0x21a(%rax)
1401e5e6d:     	movb	$0x0, 0x21c(%rax)
1401e5e74:     	movb	$0x0, 0x226(%rax)
1401e5e7b:     	movabsq	$0x745ffff000000, %rcx  # imm = 0x745FFFF000000
1401e5e85:     	movq	%rcx, 0x250(%rax)
1401e5e8c:     	movb	$0x0, 0x258(%rax)
1401e5e93:     	popq	%rbp
1401e5e94:     	retq

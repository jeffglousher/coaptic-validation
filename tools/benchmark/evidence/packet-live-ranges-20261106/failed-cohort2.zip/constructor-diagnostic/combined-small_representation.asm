
D:\CoapticCurrent\packet-response-origin-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401e6ea0:     	pushq	%rbp
1401e6ea1:     	movq	%rsp, %rbp
1401e6ea4:     	movq	%rcx, %rax
1401e6ea7:     	movl	$0x0, (%rcx)
1401e6ead:     	movl	$0x0, 0x8(%rcx)
1401e6eb4:     	movw	$0x1, 0x10(%rcx)
1401e6eba:     	leaq	0x7b0ac(%rip), %rcx     # 0x140261f6d
1401e6ec1:     	movq	%rcx, 0x18(%rax)
1401e6ec5:     	movq	$0x20, 0x20(%rax)
1401e6ecd:     	movb	$-0x1, 0xb5(%rax)
1401e6ed4:     	movq	$0x1, 0xc0(%rax)
1401e6edf:     	movq	$0x0, 0xc8(%rax)
1401e6eea:     	movq	$0x1, 0xd0(%rax)
1401e6ef5:     	movq	$0x0, 0xd8(%rax)
1401e6f00:     	movq	$0x1, 0xe0(%rax)
1401e6f0b:     	movq	$0x0, 0xe8(%rax)
1401e6f16:     	movq	$0x1, 0xf0(%rax)
1401e6f21:     	movq	$0x0, 0xf8(%rax)
1401e6f2c:     	movq	$0x1, 0x100(%rax)
1401e6f37:     	movq	$0x0, 0x108(%rax)
1401e6f42:     	movq	$0x1, 0x110(%rax)
1401e6f4d:     	movq	$0x0, 0x118(%rax)
1401e6f58:     	movq	$0x1, 0x120(%rax)
1401e6f63:     	movq	$0x0, 0x128(%rax)
1401e6f6e:     	movq	$0x1, 0x130(%rax)
1401e6f79:     	movq	$0x0, 0x138(%rax)
1401e6f84:     	movq	$0x1, 0x140(%rax)
1401e6f8f:     	movq	$0x0, 0x148(%rax)
1401e6f9a:     	movq	$0x1, 0x150(%rax)
1401e6fa5:     	movq	$0x0, 0x158(%rax)
1401e6fb0:     	movq	$0x1, 0x160(%rax)
1401e6fbb:     	movq	$0x0, 0x168(%rax)
1401e6fc6:     	movq	$0x1, 0x170(%rax)
1401e6fd1:     	movq	$0x0, 0x178(%rax)
1401e6fdc:     	movq	$0x1, 0x180(%rax)
1401e6fe7:     	movq	$0x0, 0x188(%rax)
1401e6ff2:     	movq	$0x1, 0x190(%rax)
1401e6ffd:     	movq	$0x0, 0x198(%rax)
1401e7008:     	movq	$0x1, 0x1a0(%rax)
1401e7013:     	movq	$0x0, 0x1a8(%rax)
1401e701e:     	movq	$0x1, 0x1b0(%rax)
1401e7029:     	movq	$0x0, 0x1b8(%rax)
1401e7034:     	movabsq	$0x65727574786966, %rcx # imm = 0x65727574786966
1401e703e:     	movq	%rcx, 0x1c0(%rax)
1401e7045:     	movq	$0x0, 0x1c8(%rax)
1401e7050:     	movq	$0x20, 0x1d8(%rax)
1401e705b:     	movl	$0x2a0001, 0x1e0(%rax)  # imm = 0x2A0001
1401e7065:     	movb	$0x0, 0x1e4(%rax)
1401e706c:     	movabsq	$0x745ff000000, %rcx    # imm = 0x745FF000000
1401e7076:     	movq	%rcx, 0x20e(%rax)
1401e707d:     	popq	%rbp
1401e707e:     	retq

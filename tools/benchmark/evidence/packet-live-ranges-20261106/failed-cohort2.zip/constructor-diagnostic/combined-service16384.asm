
D:\CoapticCurrent\packet-response-origin-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401df110:     	pushq	%rbp
1401df111:     	movq	%rsp, %rbp
1401df114:     	movq	%rcx, %rax
1401df117:     	movl	$0x0, (%rcx)
1401df11d:     	movl	$0x0, 0x8(%rcx)
1401df124:     	movw	$0x1, 0x10(%rcx)
1401df12a:     	leaq	0x7ad1f(%rip), %rcx     # 0x140259e50
1401df131:     	movq	%rcx, 0x18(%rax)
1401df135:     	movq	$0x4000, 0x20(%rax)     # imm = 0x4000
1401df13d:     	movb	$-0x1, 0xb5(%rax)
1401df144:     	movq	$0x1, 0xc0(%rax)
1401df14f:     	movq	$0x0, 0xc8(%rax)
1401df15a:     	movq	$0x1, 0xd0(%rax)
1401df165:     	movq	$0x0, 0xd8(%rax)
1401df170:     	movq	$0x1, 0xe0(%rax)
1401df17b:     	movq	$0x0, 0xe8(%rax)
1401df186:     	movq	$0x1, 0xf0(%rax)
1401df191:     	movq	$0x0, 0xf8(%rax)
1401df19c:     	movq	$0x1, 0x100(%rax)
1401df1a7:     	movq	$0x0, 0x108(%rax)
1401df1b2:     	movq	$0x1, 0x110(%rax)
1401df1bd:     	movq	$0x0, 0x118(%rax)
1401df1c8:     	movq	$0x1, 0x120(%rax)
1401df1d3:     	movq	$0x0, 0x128(%rax)
1401df1de:     	movq	$0x1, 0x130(%rax)
1401df1e9:     	movq	$0x0, 0x138(%rax)
1401df1f4:     	movq	$0x1, 0x140(%rax)
1401df1ff:     	movq	$0x0, 0x148(%rax)
1401df20a:     	movq	$0x1, 0x150(%rax)
1401df215:     	movq	$0x0, 0x158(%rax)
1401df220:     	movq	$0x1, 0x160(%rax)
1401df22b:     	movq	$0x0, 0x168(%rax)
1401df236:     	movq	$0x1, 0x170(%rax)
1401df241:     	movq	$0x0, 0x178(%rax)
1401df24c:     	movq	$0x1, 0x180(%rax)
1401df257:     	movq	$0x0, 0x188(%rax)
1401df262:     	movq	$0x1, 0x190(%rax)
1401df26d:     	movq	$0x0, 0x198(%rax)
1401df278:     	movq	$0x1, 0x1a0(%rax)
1401df283:     	movq	$0x0, 0x1a8(%rax)
1401df28e:     	movq	$0x1, 0x1b0(%rax)
1401df299:     	movq	$0x0, 0x1b8(%rax)
1401df2a4:     	movabsq	$0x65727574786966, %rcx # imm = 0x65727574786966
1401df2ae:     	movq	%rcx, 0x1c0(%rax)
1401df2b5:     	movq	$0x0, 0x1c8(%rax)
1401df2c0:     	movq	$0x4000, 0x1d8(%rax)    # imm = 0x4000
1401df2cb:     	movl	$0x2a0001, 0x1e0(%rax)  # imm = 0x2A0001
1401df2d5:     	movb	$0x0, 0x1e4(%rax)
1401df2dc:     	movabsq	$0x745ff000000, %rcx    # imm = 0x745FF000000
1401df2e6:     	movq	%rcx, 0x20e(%rax)
1401df2ed:     	popq	%rbp
1401df2ee:     	retq

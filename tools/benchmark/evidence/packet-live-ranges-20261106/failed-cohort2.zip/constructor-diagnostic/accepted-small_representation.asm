
D:\CoapticCurrent\phase-sharing-static-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401edd30:     	pushq	%rbp
1401edd31:     	movq	%rsp, %rbp
1401edd34:     	movq	%rcx, %rax
1401edd37:     	movq	$0x0, (%rcx)
1401edd3e:     	movl	$0x0, 0x10(%rcx)
1401edd45:     	movl	$0x0, 0x18(%rcx)
1401edd4c:     	movw	$0x1, 0x20(%rcx)
1401edd52:     	leaq	0x7c214(%rip), %rcx     # 0x140269f6d
1401edd59:     	movq	%rcx, 0x28(%rax)
1401edd5d:     	movq	$0x20, 0x30(%rax)
1401edd65:     	movb	$-0x1, 0xcd(%rax)
1401edd6c:     	movq	$0x1, 0xd8(%rax)
1401edd77:     	movq	$0x0, 0xe0(%rax)
1401edd82:     	movq	$0x1, 0xe8(%rax)
1401edd8d:     	movq	$0x0, 0xf0(%rax)
1401edd98:     	movq	$0x1, 0xf8(%rax)
1401edda3:     	movq	$0x0, 0x100(%rax)
1401eddae:     	movq	$0x1, 0x108(%rax)
1401eddb9:     	movq	$0x0, 0x110(%rax)
1401eddc4:     	movq	$0x1, 0x118(%rax)
1401eddcf:     	movq	$0x0, 0x120(%rax)
1401eddda:     	movq	$0x1, 0x128(%rax)
1401edde5:     	movq	$0x0, 0x130(%rax)
1401eddf0:     	movq	$0x1, 0x138(%rax)
1401eddfb:     	movq	$0x0, 0x140(%rax)
1401ede06:     	movq	$0x1, 0x148(%rax)
1401ede11:     	movq	$0x0, 0x150(%rax)
1401ede1c:     	movq	$0x1, 0x158(%rax)
1401ede27:     	movq	$0x0, 0x160(%rax)
1401ede32:     	movq	$0x1, 0x168(%rax)
1401ede3d:     	movq	$0x0, 0x170(%rax)
1401ede48:     	movq	$0x1, 0x178(%rax)
1401ede53:     	movq	$0x0, 0x180(%rax)
1401ede5e:     	movq	$0x1, 0x188(%rax)
1401ede69:     	movq	$0x0, 0x190(%rax)
1401ede74:     	movq	$0x1, 0x198(%rax)
1401ede7f:     	movq	$0x0, 0x1a0(%rax)
1401ede8a:     	movq	$0x1, 0x1a8(%rax)
1401ede95:     	movq	$0x0, 0x1b0(%rax)
1401edea0:     	movq	$0x1, 0x1b8(%rax)
1401edeab:     	movq	$0x0, 0x1c0(%rax)
1401edeb6:     	movq	$0x1, 0x1c8(%rax)
1401edec1:     	movq	$0x0, 0x1d0(%rax)
1401edecc:     	movabsq	$0x65727574786966, %rcx # imm = 0x65727574786966
1401eded6:     	movq	%rcx, 0x1d8(%rax)
1401ededd:     	movq	$0x0, 0x1e0(%rax)
1401edee8:     	movq	$0x20, 0x1f0(%rax)
1401edef3:     	movl	$0x2a0001, 0x1f8(%rax)  # imm = 0x2A0001
1401edefd:     	movw	$0x0, 0x1fc(%rax)
1401edf06:     	movb	$0x2, 0x21a(%rax)
1401edf0d:     	movb	$0x0, 0x21c(%rax)
1401edf14:     	movb	$0x0, 0x226(%rax)
1401edf1b:     	movabsq	$0x745ffff000000, %rcx  # imm = 0x745FFFF000000
1401edf25:     	movq	%rcx, 0x250(%rax)
1401edf2c:     	movb	$0x0, 0x258(%rax)
1401edf33:     	popq	%rbp
1401edf34:     	retq

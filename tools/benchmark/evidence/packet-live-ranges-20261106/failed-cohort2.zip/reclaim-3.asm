
D:\CoapticCurrent\packet-response-origin-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400993f0:     	pushq	%rbp
1400993f1:     	pushq	%r15
1400993f3:     	pushq	%r14
1400993f5:     	pushq	%r13
1400993f7:     	pushq	%r12
1400993f9:     	pushq	%rsi
1400993fa:     	pushq	%rdi
1400993fb:     	pushq	%rbx
1400993fc:     	subq	$0x308, %rsp            # imm = 0x308
140099403:     	leaq	0x80(%rsp), %rbp
14009940b:     	movaps	%xmm7, 0x270(%rbp)
140099412:     	movaps	%xmm6, 0x260(%rbp)
140099419:     	leaq	0x5000(%rcx), %rax
140099420:     	leaq	0x30(%rcx), %r8
140099424:     	xorl	%r9d, %r9d
140099427:     	xorl	%esi, %esi
140099429:     	leaq	(%rsi,%rsi,4), %r11
14009942d:     	shlq	$0x6, %r11
140099431:     	addq	%r8, %r11
140099434:     	movq	%rsi, %r10
140099437:     	jmp	0x140099454 <.text+0x98454>
140099439:     	nopl	(%rax)
140099440:     	incq	%r10
140099443:     	addq	$0x140, %r11            # imm = 0x140
14009944a:     	cmpq	$0x40, %r10
14009944e:     	je	0x1400994ee <.text+0x984ee>
140099454:     	cmpb	$0x1, 0x5000(%rcx,%r10)
14009945d:     	jne	0x140099440 <.text+0x98440>
14009945f:     	movq	-0x30(%r11), %rdi
140099463:     	cmpq	$0x2, %rdi
140099467:     	je	0x140099440 <.text+0x98440>
140099469:     	movq	(%r11), %rsi
14009946c:     	cmpl	$0x1, %edi
14009946f:     	setne	%bl
140099472:     	testq	%rsi, %rsi
140099475:     	sete	%dil
140099479:     	orb	%bl, %dil
14009947c:     	cmpb	$0x1, %dil
140099480:     	je	0x140099440 <.text+0x98440>
140099482:     	movq	0x250(%rbp), %rdi
140099489:     	cmpq	%rdi, %rsi
14009948c:     	setae	%bl
14009948f:     	testb	%bl, %r9b
140099492:     	jne	0x1400994d4 <.text+0x984d4>
140099494:     	movd	-0x4(%r11), %xmm6
14009949a:     	movzbl	-0x5(%r11), %edx
14009949f:     	movb	%dl, 0x25f(%rbp)
1400994a5:     	movzbl	-0x6(%r11), %r15d
1400994aa:     	movzwl	-0x8(%r11), %r12d
1400994af:     	movl	-0xc(%r11), %r13d
1400994b3:     	movl	-0x10(%r11), %r14d
1400994b7:     	movq	-0x18(%r11), %rdx
1400994bb:     	movq	%rdx, 0x248(%rbp)
1400994c2:     	movq	-0x28(%r11), %rdx
1400994c6:     	movq	-0x20(%r11), %r9
1400994ca:     	movq	%r9, 0x240(%rbp)
1400994d1:     	movq	%rsi, %rdi
1400994d4:     	movq	%rdi, 0x250(%rbp)
1400994db:     	leaq	0x1(%r10), %rsi
1400994df:     	movb	$0x1, %r9b
1400994e2:     	cmpq	$0x3f, %r10
1400994e6:     	jb	0x140099429 <.text+0x98429>
1400994ec:     	jmp	0x1400994f8 <.text+0x984f8>
1400994ee:     	testb	$0x1, %r9b
1400994f2:     	je	0x140099770 <.text+0x98770>
1400994f8:     	cmpq	$0x1f, %rdx
1400994fc:     	ja	0x14009954f <.text+0x9854f>
1400994fe:     	leaq	0x37740(%rcx), %r8
140099505:     	cmpb	$0x1, (%r8,%rdx)
14009950a:     	jne	0x14009954f <.text+0x9854f>
14009950c:     	cmpb	$0x0, 0x37760(%rcx,%rdx)
140099514:     	jne	0x14009954f <.text+0x9854f>
140099516:     	movb	$0x0, 0x37740(%rcx,%rdx)
14009951e:     	decq	0x37788(%rcx)
140099525:     	movq	$0x0, 0x43610(%rcx,%rdx,8)
140099531:     	leaq	(%rdx,%rdx,8), %r9
140099535:     	leaq	(%r9,%r9,2), %r9
140099539:     	addq	%rdx, %r9
14009953c:     	movb	$0x2, 0x36a(%r8,%r9)
140099545:     	leaq	(%rdx,%rdx,2), %rdx
140099549:     	movb	$0x2, 0x5d(%r8,%rdx,8)
14009954f:     	movd	%xmm6, %edx
140099553:     	movl	$0x2c, %r8d
140099559:     	movq	0x240(%rbp), %r11
140099560:     	movq	0x248(%rbp), %rsi
140099567:     	jmp	0x140099583 <.text+0x98583>
140099569:     	nopl	(%rax)
140099570:     	incq	%rax
140099573:     	addq	$0x140, %r8             # imm = 0x140
14009957a:     	cmpq	$0x502c, %r8            # imm = 0x502C
140099581:     	je	0x1400995dc <.text+0x985dc>
140099583:     	cmpb	$0x1, (%rax)
140099586:     	jne	0x140099570 <.text+0x98570>
140099588:     	cmpl	$0x2, -0x2c(%rcx,%r8)
14009958e:     	je	0x140099570 <.text+0x98570>
140099590:     	cmpw	%dx, (%rcx,%r8)
140099595:     	jne	0x140099570 <.text+0x98570>
140099597:     	cmpl	%r14d, -0xc(%rcx,%r8)
14009959c:     	jne	0x140099570 <.text+0x98570>
14009959e:     	cmpl	%r13d, -0x8(%rcx,%r8)
1400995a3:     	jne	0x140099570 <.text+0x98570>
1400995a5:     	cmpw	%r12w, -0x4(%rcx,%r8)
1400995ab:     	jne	0x140099570 <.text+0x98570>
1400995ad:     	cmpb	%r15b, -0x2(%rcx,%r8)
1400995b2:     	jne	0x140099570 <.text+0x98570>
1400995b4:     	movq	-0x1c(%rcx,%r8), %r9
1400995b9:     	xorq	%r11, %r9
1400995bc:     	movq	-0x14(%rcx,%r8), %r10
1400995c1:     	xorq	%rsi, %r10
1400995c4:     	orq	%r9, %r10
1400995c7:     	jne	0x140099570 <.text+0x98570>
1400995c9:     	movb	$0x0, (%rax)
1400995cc:     	decq	0x5048(%rcx)
1400995d3:     	movq	$0x2, -0x2c(%rcx,%r8)
1400995dc:     	movq	%rcx, %rsi
1400995df:     	xorps	%xmm7, %xmm7
1400995e2:     	movaps	%xmm7, 0x230(%rbp)
1400995e9:     	movb	$0x0, 0x212(%rbp)
1400995f0:     	movw	%dx, 0x210(%rbp)
1400995f7:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
140099600:     	movq	$0x0, 0x213(%rbp)
14009960b:     	movq	$0x8, 0x1f0(%rbp)
140099616:     	movq	$0x0, 0x1f8(%rbp)
140099621:     	movq	$0x1, 0x200(%rbp)
14009962c:     	movq	$0x0, 0x208(%rbp)
140099637:     	leaq	0x220(%rbp), %rcx
14009963e:     	leaq	0x1f0(%rbp), %rdx
140099645:     	leaq	0x230(%rbp), %r8
14009964c:     	movl	$0x10, %r9d
140099652:     	callq	0x14010b560 <.text+0x10a560>
140099657:     	cmpb	$0x0, 0x220(%rbp)
14009965e:     	jne	0x14009976c <.text+0x9876c>
140099664:     	movq	0x228(%rbp), %rdi
14009966b:     	movaps	%xmm7, 0xe0(%rbp)
140099672:     	movaps	%xmm7, 0xf0(%rbp)
140099679:     	movaps	%xmm7, 0x100(%rbp)
140099680:     	movaps	%xmm7, 0x110(%rbp)
140099687:     	movaps	%xmm7, 0x120(%rbp)
14009968e:     	movaps	%xmm7, 0x130(%rbp)
140099695:     	movaps	%xmm7, 0x140(%rbp)
14009969c:     	movaps	%xmm7, 0x150(%rbp)
1400996a3:     	movaps	%xmm7, 0x160(%rbp)
1400996aa:     	movaps	%xmm7, 0x170(%rbp)
1400996b1:     	movaps	%xmm7, 0x180(%rbp)
1400996b8:     	movaps	%xmm7, 0x190(%rbp)
1400996bf:     	movaps	%xmm7, 0x1a0(%rbp)
1400996c6:     	movaps	%xmm7, 0x1b0(%rbp)
1400996cd:     	movaps	%xmm7, 0x1c0(%rbp)
1400996d4:     	movaps	%xmm7, 0x1d0(%rbp)
1400996db:     	cmpq	$0x11, %rdi
1400996df:     	jae	0x140099794 <.text+0x98794>
1400996e5:     	leaq	0xe0(%rbp), %rbx
1400996ec:     	leaq	0x230(%rbp), %rdx
1400996f3:     	movq	%rbx, %rcx
1400996f6:     	movq	%rdi, %r8
1400996f9:     	callq	0x140247b40 <.text+0x246b40>
1400996fe:     	movw	%di, 0x1e0(%rbp)
140099705:     	movq	$0x0, -0x60(%rbp)
14009970d:     	movq	0x248(%rbp), %rax
140099714:     	movq	%rax, -0x48(%rbp)
140099718:     	movq	0x240(%rbp), %rax
14009971f:     	movq	%rax, -0x50(%rbp)
140099723:     	movl	%r14d, -0x40(%rbp)
140099727:     	movl	%r13d, -0x3c(%rbp)
14009972b:     	movw	%r12w, -0x38(%rbp)
140099730:     	movb	%r15b, -0x36(%rbp)
140099734:     	movzbl	0x25f(%rbp), %eax
14009973b:     	movb	%al, -0x35(%rbp)
14009973e:     	movd	%xmm6, -0x34(%rbp)
140099743:     	movq	0x250(%rbp), %rax
14009974a:     	movq	%rax, -0x30(%rbp)
14009974e:     	leaq	-0x28(%rbp), %rcx
140099752:     	movl	$0x108, %r8d            # imm = 0x108
140099758:     	movq	%rbx, %rdx
14009975b:     	callq	0x140247b40 <.text+0x246b40>
140099760:     	leaq	-0x60(%rbp), %rdx
140099764:     	movq	%rsi, %rcx
140099767:     	callq	0x14020cd10 <.text+0x20bd10>
14009976c:     	movb	$0x1, %al
14009976e:     	jmp	0x140099772 <.text+0x98772>
140099770:     	xorl	%eax, %eax
140099772:     	movaps	0x260(%rbp), %xmm6
140099779:     	movaps	0x270(%rbp), %xmm7
140099780:     	addq	$0x308, %rsp            # imm = 0x308
140099787:     	popq	%rbx
140099788:     	popq	%rdi
140099789:     	popq	%rsi
14009978a:     	popq	%r12
14009978c:     	popq	%r13
14009978e:     	popq	%r14
140099790:     	popq	%r15
140099792:     	popq	%rbp
140099793:     	retq
140099794:     	leaq	0x1c63cd(%rip), %r9     # 0x14025fb68
14009979b:     	movl	$0x10, %r8d
1400997a1:     	xorl	%ecx, %ecx
1400997a3:     	movq	%rdi, %rdx
1400997a6:     	callq	0x140248590 <.text+0x247590>
1400997ab:     	ud2

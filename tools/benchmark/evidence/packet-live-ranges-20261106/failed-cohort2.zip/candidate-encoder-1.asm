
D:\CoapticCurrent\packet-response-origin-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140066130:     	pushq	%rbp
140066131:     	pushq	%r15
140066133:     	pushq	%r14
140066135:     	pushq	%r13
140066137:     	pushq	%r12
140066139:     	pushq	%rsi
14006613a:     	pushq	%rdi
14006613b:     	pushq	%rbx
14006613c:     	subq	$0x508, %rsp            # imm = 0x508
140066143:     	leaq	0x80(%rsp), %rbp
14006614b:     	movq	%r9, %rbx
14006614e:     	movq	%r8, %r14
140066151:     	movq	%rdx, %rdi
140066154:     	movq	%rcx, %rsi
140066157:     	movq	0x500(%rbp), %r12
14006615e:     	movq	%rbp, %rcx
140066161:     	movl	$0x400, %r8d            # imm = 0x400
140066167:     	xorl	%edx, %edx
140066169:     	callq	0x140247b52 <.text+0x246b52>
14006616e:     	movq	0x8(%r12), %r13
140066173:     	movl	$0x3, %eax
140066178:     	cmpq	$0x3, %r13
14006617c:     	ja	0x14006639f <.text+0x6539f>
140066182:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
14006618b:     	jne	0x14006639f <.text+0x6539f>
140066191:     	movq	0x2b750(%rdi,%r13,8), %rdx
140066199:     	cmpq	$0x4001, %rdx           # imm = 0x4001
1400661a0:     	jae	0x1400663fb <.text+0x653fb>
1400661a6:     	movq	0x10(%r12), %rcx
1400661ab:     	movq	0x18(%r12), %r15
1400661b0:     	movq	%r15, %r8
1400661b3:     	movl	$0xb, %eax
1400661b8:     	addq	%rcx, %r8
1400661bb:     	jb	0x14006639f <.text+0x6539f>
1400661c1:     	cmpq	$0x400, %r15            # imm = 0x400
1400661c8:     	ja	0x14006639f <.text+0x6539f>
1400661ce:     	cmpq	%rdx, %r8
1400661d1:     	ja	0x14006639f <.text+0x6539f>
1400661d7:     	movq	%r13, %rax
1400661da:     	shlq	$0xe, %rax
1400661de:     	leaq	(%rdi,%rax), %rdx
1400661e2:     	addq	$0x1b750, %rdx          # imm = 0x1B750
1400661e9:     	addq	%rcx, %rdx
1400661ec:     	movq	%rbp, %rcx
1400661ef:     	movq	%r15, %r8
1400661f2:     	callq	0x140247b40 <.text+0x246b40>
1400661f7:     	cmpb	$0x0, 0x508(%rbp)
1400661fe:     	je	0x140066216 <.text+0x65216>
140066200:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
140066207:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
140066210:     	jne	0x1400663ba <.text+0x653ba>
140066216:     	movq	$0x0, 0x480(%rbp)
140066221:     	movq	%rdi, %rcx
140066224:     	callq	0x140095900 <.text+0x94900>
140066229:     	testb	$0x1, %al
14006622b:     	je	0x1400663ed <.text+0x653ed>
140066231:     	movq	%rdx, %r13
140066234:     	movq	0x518(%rbp), %rdx
14006623b:     	movq	0x510(%rbp), %r8
140066242:     	movzwl	0x4f8(%rbp), %ecx
140066249:     	movzbl	0x4f0(%rbp), %eax
140066250:     	movq	(%r12), %r9
140066254:     	movq	0x480(%rbp), %r10
14006625b:     	movq	%r10, 0x448(%rbp)
140066262:     	movq	0x478(%rbp), %r10
140066269:     	movq	%r10, 0x450(%rbp)
140066270:     	movq	%r9, 0x458(%rbp)
140066277:     	movzbl	0x508(%rbp), %r9d
14006627f:     	movb	%r9b, 0x460(%rbp)
140066286:     	movups	0x38(%r14), %xmm0
14006628b:     	movups	0x44(%r14), %xmm1
140066290:     	movups	%xmm1, 0x40c(%rbp)
140066297:     	movaps	%xmm0, 0x400(%rbp)
14006629e:     	leaq	0x66(%r14), %r9
1400662a2:     	movq	0x56(%r14), %r10
1400662a6:     	movq	0x5d(%r14), %r11
1400662aa:     	movq	%r11, 0x46f(%rbp)
1400662b1:     	movq	%r10, 0x468(%rbp)
1400662b8:     	leaq	0x468(%rbp), %r10
1400662bf:     	movq	%r10, 0x70(%rsp)
1400662c4:     	movq	%rdx, 0x68(%rsp)
1400662c9:     	movq	%r8, 0x60(%rsp)
1400662ce:     	movq	%r14, 0x58(%rsp)
1400662d3:     	leaq	0x448(%rbp), %rdx
1400662da:     	movq	%rdx, 0x50(%rsp)
1400662df:     	movq	%r15, 0x48(%rsp)
1400662e4:     	movq	%rbp, %rdx
1400662e7:     	movq	%rdx, 0x40(%rsp)
1400662ec:     	movq	%rbx, 0x38(%rsp)
1400662f1:     	movq	%r9, 0x30(%rsp)
1400662f6:     	movw	%cx, 0x28(%rsp)
1400662fb:     	movb	%al, 0x20(%rsp)
1400662ff:     	leaq	0x428(%rbp), %rcx
140066306:     	leaq	0x400(%rbp), %r8
14006630d:     	movq	%rdi, %rdx
140066310:     	movq	%r13, %r9
140066313:     	callq	0x14007d2b0 <.text+0x7c2b0>
140066318:     	cmpb	$-0x1, 0x428(%rbp)
14006631f:     	je	0x1400663f2 <.text+0x653f2>
140066325:     	cmpb	$0x1, 0x37740(%rdi,%r13)
14006632e:     	jne	0x140066388 <.text+0x65388>
140066330:     	cmpb	$0x0, 0x37760(%rdi,%r13)
140066339:     	jne	0x140066388 <.text+0x65388>
14006633b:     	movb	$0x0, 0x37740(%rdi,%r13)
140066344:     	decq	0x37788(%rdi)
14006634b:     	leaq	0x37740(%rdi), %rax
140066352:     	movq	$0x0, 0x43610(%rdi,%r13,8)
14006635e:     	leaq	(,%r13,8), %rcx
140066366:     	addq	%r13, %rcx
140066369:     	leaq	(%rcx,%rcx,2), %rcx
14006636d:     	addq	%r13, %rcx
140066370:     	movb	$0x2, 0x36a(%rax,%rcx)
140066378:     	leaq	(,%r13,2), %rcx
140066380:     	addq	%r13, %rcx
140066383:     	movb	$0x2, 0x5d(%rax,%rcx,8)
140066388:     	movups	0x428(%rbp), %xmm0
14006638f:     	movups	0x438(%rbp), %xmm1
140066396:     	movups	%xmm1, 0x10(%rsi)
14006639a:     	movups	%xmm0, (%rsi)
14006639d:     	jmp	0x1400663a6 <.text+0x653a6>
14006639f:     	movb	$0xa, (%rsi)
1400663a2:     	movq	%rax, 0x8(%rsi)
1400663a6:     	addq	$0x508, %rsp            # imm = 0x508
1400663ad:     	popq	%rbx
1400663ae:     	popq	%rdi
1400663af:     	popq	%rsi
1400663b0:     	popq	%r12
1400663b2:     	popq	%r13
1400663b4:     	popq	%r14
1400663b6:     	popq	%r15
1400663b8:     	popq	%rbp
1400663b9:     	retq
1400663ba:     	addq	%rdi, %rax
1400663bd:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
1400663c3:     	movq	0x98(%rax), %rax
1400663ca:     	movq	%rax, 0x478(%rbp)
1400663d1:     	movl	$0x1, %eax
1400663d6:     	movq	%rax, 0x480(%rbp)
1400663dd:     	movq	%rdi, %rcx
1400663e0:     	callq	0x140095900 <.text+0x94900>
1400663e5:     	testb	$0x1, %al
1400663e7:     	jne	0x140066231 <.text+0x65231>
1400663ed:     	movb	$0x9, (%rsi)
1400663f0:     	jmp	0x1400663a6 <.text+0x653a6>
1400663f2:     	movq	%r13, 0x8(%rsi)
1400663f6:     	movb	$-0x1, (%rsi)
1400663f9:     	jmp	0x1400663a6 <.text+0x653a6>
1400663fb:     	leaq	0x1fc846(%rip), %r9     # 0x140262c48
140066402:     	movl	$0x4000, %r8d           # imm = 0x4000
140066408:     	xorl	%ecx, %ecx
14006640a:     	callq	0x140248590 <.text+0x247590>
14006640f:     	ud2


D:\CoapticCurrent\packet-response-origin-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140098cf0:     	pushq	%rbp
140098cf1:     	pushq	%r15
140098cf3:     	pushq	%r14
140098cf5:     	pushq	%r13
140098cf7:     	pushq	%r12
140098cf9:     	pushq	%rsi
140098cfa:     	pushq	%rdi
140098cfb:     	pushq	%rbx
140098cfc:     	subq	$0x318, %rsp            # imm = 0x318
140098d03:     	leaq	0x80(%rsp), %rbp
140098d0b:     	movaps	%xmm7, 0x280(%rbp)
140098d12:     	movaps	%xmm6, 0x270(%rbp)
140098d19:     	leaq	0x30(%rcx), %rdx
140098d1d:     	xorl	%r8d, %r8d
140098d20:     	xorl	%r11d, %r11d
140098d23:     	leaq	(%r11,%r11,4), %r10
140098d27:     	shlq	$0x6, %r10
140098d2b:     	addq	%rdx, %r10
140098d2e:     	movq	%r11, %r9
140098d31:     	jmp	0x140098d54 <.text+0x97d54>
140098d33:     	nopw	%cs:(%rax,%rax)
140098d40:     	incq	%r9
140098d43:     	addq	$0x140, %r10            # imm = 0x140
140098d4a:     	cmpq	$0x4, %r9
140098d4e:     	je	0x140098dde <.text+0x97dde>
140098d54:     	cmpb	$0x1, 0x510(%rcx,%r9)
140098d5d:     	jne	0x140098d40 <.text+0x97d40>
140098d5f:     	movq	-0x30(%r10), %rsi
140098d63:     	cmpq	$0x2, %rsi
140098d67:     	je	0x140098d40 <.text+0x97d40>
140098d69:     	movq	(%r10), %r11
140098d6c:     	cmpl	$0x1, %esi
140098d6f:     	setne	%bl
140098d72:     	testq	%r11, %r11
140098d75:     	sete	%sil
140098d79:     	orb	%bl, %sil
140098d7c:     	cmpb	$0x1, %sil
140098d80:     	je	0x140098d40 <.text+0x97d40>
140098d82:     	movq	0x268(%rbp), %rsi
140098d89:     	cmpq	%rsi, %r11
140098d8c:     	setae	%bl
140098d8f:     	testb	%bl, %r8b
140098d92:     	jne	0x140098dc4 <.text+0x97dc4>
140098d94:     	movq	-0x28(%r10), %rax
140098d98:     	movd	-0x4(%r10), %xmm6
140098d9e:     	movzbl	-0x5(%r10), %edi
140098da3:     	movzbl	-0x6(%r10), %r15d
140098da8:     	movzwl	-0x8(%r10), %r12d
140098dad:     	movl	-0xc(%r10), %r13d
140098db1:     	movl	-0x10(%r10), %r14d
140098db5:     	movups	-0x20(%r10), %xmm0
140098dba:     	movaps	%xmm0, 0x240(%rbp)
140098dc1:     	movq	%r11, %rsi
140098dc4:     	movq	%rsi, 0x268(%rbp)
140098dcb:     	leaq	0x1(%r9), %r11
140098dcf:     	movb	$0x1, %r8b
140098dd2:     	cmpq	$0x3, %r9
140098dd6:     	jb	0x140098d23 <.text+0x97d23>
140098ddc:     	jmp	0x140098de8 <.text+0x97de8>
140098dde:     	testb	$0x1, %r8b
140098de2:     	je	0x140099028 <.text+0x98028>
140098de8:     	cmpq	$0x1, %rax
140098dec:     	ja	0x140098e44 <.text+0x97e44>
140098dee:     	cmpb	$0x1, 0x1e80(%rcx,%rax)
140098df6:     	jne	0x140098e44 <.text+0x97e44>
140098df8:     	cmpb	$0x0, 0x1e82(%rcx,%rax)
140098e00:     	jne	0x140098e44 <.text+0x97e44>
140098e02:     	movb	$0x0, 0x1e80(%rcx,%rax)
140098e0a:     	decq	0x1e78(%rcx)
140098e11:     	leaq	0x14f8(%rcx), %rdx
140098e18:     	movq	$0x0, 0x1df8(%rcx,%rax,8)
140098e24:     	leaq	(%rax,%rax,8), %r8
140098e28:     	leaq	(%r8,%r8,2), %r8
140098e2c:     	addq	%rax, %r8
140098e2f:     	movb	$0x2, 0x95a(%rdx,%r8)
140098e38:     	leaq	(%rax,%rax,2), %rax
140098e3c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
140098e44:     	movaps	0x240(%rbp), %xmm0
140098e4b:     	movaps	%xmm0, -0x60(%rbp)
140098e4f:     	movl	%r14d, %esi
140098e52:     	movl	%r14d, -0x50(%rbp)
140098e56:     	movl	%r13d, %r14d
140098e59:     	movl	%r13d, -0x4c(%rbp)
140098e5d:     	movl	%r12d, %r13d
140098e60:     	movw	%r12w, -0x48(%rbp)
140098e65:     	movl	%r15d, %r12d
140098e68:     	movb	%r15b, -0x46(%rbp)
140098e6c:     	movl	%edi, %r15d
140098e6f:     	movb	%dil, -0x45(%rbp)
140098e73:     	movd	%xmm6, %edi
140098e77:     	movd	%xmm6, -0x44(%rbp)
140098e7c:     	leaq	-0x60(%rbp), %rdx
140098e80:     	movq	%rcx, 0x260(%rbp)
140098e87:     	callq	0x14020d140 <.text+0x20c140>
140098e8c:     	xorps	%xmm7, %xmm7
140098e8f:     	movaps	%xmm7, 0x250(%rbp)
140098e96:     	movb	$0x0, 0x222(%rbp)
140098e9d:     	movw	%di, 0x220(%rbp)
140098ea4:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
140098ead:     	movq	$0x0, 0x223(%rbp)
140098eb8:     	movq	$0x8, 0x200(%rbp)
140098ec3:     	movq	$0x0, 0x208(%rbp)
140098ece:     	movq	$0x1, 0x210(%rbp)
140098ed9:     	movq	$0x0, 0x218(%rbp)
140098ee4:     	leaq	0x230(%rbp), %rcx
140098eeb:     	leaq	0x200(%rbp), %rdx
140098ef2:     	leaq	0x250(%rbp), %r8
140098ef9:     	movl	$0x10, %r9d
140098eff:     	callq	0x14010b560 <.text+0x10a560>
140098f04:     	cmpb	$0x0, 0x230(%rbp)
140098f0b:     	jne	0x140099024 <.text+0x98024>
140098f11:     	movq	0x238(%rbp), %rdi
140098f18:     	movaps	%xmm7, 0xe0(%rbp)
140098f1f:     	movaps	%xmm7, 0xf0(%rbp)
140098f26:     	movaps	%xmm7, 0x100(%rbp)
140098f2d:     	movaps	%xmm7, 0x110(%rbp)
140098f34:     	movaps	%xmm7, 0x120(%rbp)
140098f3b:     	movaps	%xmm7, 0x130(%rbp)
140098f42:     	movaps	%xmm7, 0x140(%rbp)
140098f49:     	movaps	%xmm7, 0x150(%rbp)
140098f50:     	movaps	%xmm7, 0x160(%rbp)
140098f57:     	movaps	%xmm7, 0x170(%rbp)
140098f5e:     	movaps	%xmm7, 0x180(%rbp)
140098f65:     	movaps	%xmm7, 0x190(%rbp)
140098f6c:     	movaps	%xmm7, 0x1a0(%rbp)
140098f73:     	movaps	%xmm7, 0x1b0(%rbp)
140098f7a:     	movaps	%xmm7, 0x1c0(%rbp)
140098f81:     	movaps	%xmm7, 0x1d0(%rbp)
140098f88:     	movaps	0x240(%rbp), %xmm0
140098f8f:     	movups	%xmm0, 0x1f0(%rbp)
140098f96:     	cmpq	$0x11, %rdi
140098f9a:     	jae	0x14009904c <.text+0x9804c>
140098fa0:     	leaq	0xe0(%rbp), %rbx
140098fa7:     	leaq	0x250(%rbp), %rdx
140098fae:     	movq	%rbx, %rcx
140098fb1:     	movq	%rdi, %r8
140098fb4:     	callq	0x140247b40 <.text+0x246b40>
140098fb9:     	movw	%di, 0x1e0(%rbp)
140098fc0:     	movq	$0x0, -0x60(%rbp)
140098fc8:     	movups	0x1e8(%rbp), %xmm0
140098fcf:     	movups	%xmm0, -0x58(%rbp)
140098fd3:     	movq	0x1f8(%rbp), %rax
140098fda:     	movq	%rax, -0x48(%rbp)
140098fde:     	movl	%esi, -0x40(%rbp)
140098fe1:     	movl	%r14d, -0x3c(%rbp)
140098fe5:     	movw	%r13w, -0x38(%rbp)
140098fea:     	movb	%r12b, -0x36(%rbp)
140098fee:     	movb	%r15b, -0x35(%rbp)
140098ff2:     	movd	%xmm6, -0x34(%rbp)
140098ff7:     	movq	0x268(%rbp), %rax
140098ffe:     	movq	%rax, -0x30(%rbp)
140099002:     	leaq	-0x28(%rbp), %rcx
140099006:     	movl	$0x108, %r8d            # imm = 0x108
14009900c:     	movq	%rbx, %rdx
14009900f:     	callq	0x140247b40 <.text+0x246b40>
140099014:     	leaq	-0x60(%rbp), %rdx
140099018:     	movq	0x260(%rbp), %rcx
14009901f:     	callq	0x14020ceb0 <.text+0x20beb0>
140099024:     	movb	$0x1, %al
140099026:     	jmp	0x14009902a <.text+0x9802a>
140099028:     	xorl	%eax, %eax
14009902a:     	movaps	0x270(%rbp), %xmm6
140099031:     	movaps	0x280(%rbp), %xmm7
140099038:     	addq	$0x318, %rsp            # imm = 0x318
14009903f:     	popq	%rbx
140099040:     	popq	%rdi
140099041:     	popq	%rsi
140099042:     	popq	%r12
140099044:     	popq	%r13
140099046:     	popq	%r14
140099048:     	popq	%r15
14009904a:     	popq	%rbp
14009904b:     	retq
14009904c:     	leaq	0x1c6b15(%rip), %r9     # 0x14025fb68
140099053:     	movl	$0x10, %r8d
140099059:     	xorl	%ecx, %ecx
14009905b:     	movq	%rdi, %rdx
14009905e:     	callq	0x140248590 <.text+0x247590>
140099063:     	ud2

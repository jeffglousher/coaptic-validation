
D:\CoapticCurrent\packet-response-origin-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400997b0:     	pushq	%rbp
1400997b1:     	pushq	%r15
1400997b3:     	pushq	%r14
1400997b5:     	pushq	%r13
1400997b7:     	pushq	%r12
1400997b9:     	pushq	%rsi
1400997ba:     	pushq	%rdi
1400997bb:     	pushq	%rbx
1400997bc:     	subq	$0x318, %rsp            # imm = 0x318
1400997c3:     	leaq	0x80(%rsp), %rbp
1400997cb:     	movaps	%xmm7, 0x280(%rbp)
1400997d2:     	movdqa	%xmm6, 0x270(%rbp)
1400997da:     	movq	0xe8(%rcx), %r8
1400997e1:     	testq	%r8, %r8
1400997e4:     	je	0x140099bc4 <.text+0x98bc4>
1400997ea:     	movq	0x88(%rcx), %r11
1400997f1:     	movq	0xe0(%rcx), %rdx
1400997f8:     	movq	0xc8(%rcx), %rax
1400997ff:     	movq	0xd0(%rcx), %r9
140099806:     	leaq	0x30(%rax), %rsi
14009980a:     	xorl	%ebx, %ebx
14009980c:     	xorl	%edi, %edi
14009980e:     	leaq	(%rdi,%rdi,4), %r12
140099812:     	shlq	$0x6, %r12
140099816:     	addq	%rsi, %r12
140099819:     	jmp	0x140099833 <.text+0x98833>
14009981b:     	nopl	(%rax,%rax)
140099820:     	incq	%rdi
140099823:     	addq	$0x140, %r12            # imm = 0x140
14009982a:     	cmpq	%r8, %rdi
14009982d:     	jae	0x1400998fc <.text+0x988fc>
140099833:     	cmpq	%r9, %rdi
140099836:     	setb	%r15b
14009983a:     	andb	(%rdx,%rdi), %r15b
14009983e:     	cmpb	$0x1, %r15b
140099842:     	jne	0x140099820 <.text+0x98820>
140099844:     	movq	-0x30(%r12), %r15
140099849:     	cmpq	$0x2, %r15
14009984d:     	je	0x140099820 <.text+0x98820>
14009984f:     	movq	(%r12), %r13
140099853:     	cmpl	$0x1, %r15d
140099857:     	setne	%r15b
14009985b:     	testq	%r13, %r13
14009985e:     	sete	%r10b
140099862:     	orb	%r15b, %r10b
140099865:     	cmpb	$0x1, %r10b
140099869:     	je	0x140099820 <.text+0x98820>
14009986b:     	movq	0x260(%rbp), %r15
140099872:     	cmpq	%r15, %r13
140099875:     	setae	%r10b
140099879:     	testb	%r10b, %bl
14009987c:     	jne	0x1400998e5 <.text+0x988e5>
14009987e:     	movq	-0x28(%r12), %r10
140099883:     	movq	%r10, 0x250(%rbp)
14009988a:     	movq	-0x20(%r12), %r10
14009988f:     	movq	%r10, 0x248(%rbp)
140099896:     	movd	-0x4(%r12), %xmm6
14009989d:     	movzbl	-0x5(%r12), %r10d
1400998a3:     	movb	%r10b, 0x26e(%rbp)
1400998aa:     	movzbl	-0x6(%r12), %r10d
1400998b0:     	movb	%r10b, 0x26f(%rbp)
1400998b7:     	movzwl	-0x8(%r12), %r10d
1400998bd:     	movw	%r10w, 0x26c(%rbp)
1400998c5:     	movl	-0xc(%r12), %r10d
1400998ca:     	movl	%r10d, 0x268(%rbp)
1400998d1:     	movl	-0x10(%r12), %r14d
1400998d6:     	movq	-0x18(%r12), %r10
1400998db:     	movq	%r10, 0x258(%rbp)
1400998e2:     	movq	%r13, %r15
1400998e5:     	movq	%r15, 0x260(%rbp)
1400998ec:     	incq	%rdi
1400998ef:     	movb	$0x1, %bl
1400998f1:     	cmpq	%r8, %rdi
1400998f4:     	jb	0x14009980e <.text+0x9880e>
1400998fa:     	jmp	0x140099905 <.text+0x98905>
1400998fc:     	testb	$0x1, %bl
1400998ff:     	je	0x140099bc4 <.text+0x98bc4>
140099905:     	movq	0x250(%rbp), %r10
14009990c:     	cmpq	%r11, %r10
14009990f:     	jae	0x140099965 <.text+0x98965>
140099911:     	movq	0x80(%rcx), %r11
140099918:     	cmpb	$0x1, (%r11,%r10)
14009991d:     	jne	0x140099965 <.text+0x98965>
14009991f:     	cmpq	0xa0(%rcx), %r10
140099926:     	jae	0x140099936 <.text+0x98936>
140099928:     	movq	0x98(%rcx), %rsi
14009992f:     	cmpb	$0x0, (%rsi,%r10)
140099934:     	jne	0x140099965 <.text+0x98965>
140099936:     	movb	$0x0, (%r11,%r10)
14009993b:     	decq	0xb0(%rcx)
140099942:     	cmpq	0x70(%rcx), %r10
140099946:     	jae	0x140099965 <.text+0x98965>
140099948:     	movq	0x68(%rcx), %r11
14009994c:     	imulq	$0x58, %r10, %r10
140099950:     	movq	$0x0, 0x30(%r11,%r10)
140099959:     	movb	$0x2, 0x52(%r11,%r10)
14009995f:     	movb	$0x2, 0x25(%r11,%r10)
140099965:     	leaq	0xc0(%rcx), %rsi
14009996c:     	movd	%xmm6, %r10d
140099971:     	addq	$0x2c, %rax
140099975:     	xorl	%r11d, %r11d
140099978:     	movq	0x248(%rbp), %r15
14009997f:     	movzbl	0x26e(%rbp), %r12d
140099987:     	jmp	0x1400999a2 <.text+0x989a2>
140099989:     	nopl	(%rax)
140099990:     	incq	%r11
140099993:     	addq	$0x140, %rax            # imm = 0x140
140099999:     	cmpq	%r11, %r8
14009999c:     	je	0x140099a2e <.text+0x98a2e>
1400999a2:     	cmpq	%r9, %r11
1400999a5:     	setb	%bl
1400999a8:     	andb	(%rdx,%r11), %bl
1400999ac:     	cmpb	$0x1, %bl
1400999af:     	jne	0x140099990 <.text+0x98990>
1400999b1:     	cmpl	$0x2, -0x2c(%rax)
1400999b5:     	je	0x140099990 <.text+0x98990>
1400999b7:     	cmpw	%r10w, (%rax)
1400999bb:     	jne	0x140099990 <.text+0x98990>
1400999bd:     	cmpl	%r14d, -0xc(%rax)
1400999c1:     	jne	0x140099990 <.text+0x98990>
1400999c3:     	movl	0x268(%rbp), %edi
1400999c9:     	cmpl	%edi, -0x8(%rax)
1400999cc:     	jne	0x140099990 <.text+0x98990>
1400999ce:     	movzwl	0x26c(%rbp), %edi
1400999d5:     	cmpw	%di, -0x4(%rax)
1400999d9:     	jne	0x140099990 <.text+0x98990>
1400999db:     	movzbl	0x26f(%rbp), %ebx
1400999e2:     	cmpb	%bl, -0x2(%rax)
1400999e5:     	jne	0x140099990 <.text+0x98990>
1400999e7:     	movq	-0x1c(%rax), %rdi
1400999eb:     	xorq	%r15, %rdi
1400999ee:     	movq	-0x14(%rax), %rbx
1400999f2:     	xorq	0x258(%rbp), %rbx
1400999f9:     	orq	%rdi, %rbx
1400999fc:     	jne	0x140099990 <.text+0x98990>
1400999fe:     	cmpq	%r8, %r11
140099a01:     	jae	0x140099a2e <.text+0x98a2e>
140099a03:     	cmpq	0x100(%rcx), %r11
140099a0a:     	jae	0x140099a1a <.text+0x98a1a>
140099a0c:     	movq	0xf8(%rcx), %r8
140099a13:     	cmpb	$0x0, (%r8,%r11)
140099a18:     	jne	0x140099a2e <.text+0x98a2e>
140099a1a:     	movb	$0x0, (%rdx,%r11)
140099a1f:     	decq	0x110(%rcx)
140099a26:     	movq	$0x2, -0x2c(%rax)
140099a2e:     	xorps	%xmm7, %xmm7
140099a31:     	movaps	%xmm7, 0x230(%rbp)
140099a38:     	movb	$0x0, 0x212(%rbp)
140099a3f:     	movw	%r10w, 0x210(%rbp)
140099a47:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
140099a50:     	movq	$0x0, 0x213(%rbp)
140099a5b:     	movq	$0x8, 0x1f0(%rbp)
140099a66:     	movq	$0x0, 0x1f8(%rbp)
140099a71:     	movq	$0x1, 0x200(%rbp)
140099a7c:     	movq	$0x0, 0x208(%rbp)
140099a87:     	leaq	0x220(%rbp), %rcx
140099a8e:     	leaq	0x1f0(%rbp), %rdx
140099a95:     	leaq	0x230(%rbp), %r8
140099a9c:     	movl	$0x10, %r9d
140099aa2:     	callq	0x14010b560 <.text+0x10a560>
140099aa7:     	cmpb	$0x0, 0x220(%rbp)
140099aae:     	jne	0x140099bc0 <.text+0x98bc0>
140099ab4:     	movq	0x228(%rbp), %rdi
140099abb:     	movaps	%xmm7, 0xe0(%rbp)
140099ac2:     	movaps	%xmm7, 0xf0(%rbp)
140099ac9:     	movaps	%xmm7, 0x100(%rbp)
140099ad0:     	movaps	%xmm7, 0x110(%rbp)
140099ad7:     	movaps	%xmm7, 0x120(%rbp)
140099ade:     	movaps	%xmm7, 0x130(%rbp)
140099ae5:     	movaps	%xmm7, 0x140(%rbp)
140099aec:     	movaps	%xmm7, 0x150(%rbp)
140099af3:     	movaps	%xmm7, 0x160(%rbp)
140099afa:     	movaps	%xmm7, 0x170(%rbp)
140099b01:     	movaps	%xmm7, 0x180(%rbp)
140099b08:     	movaps	%xmm7, 0x190(%rbp)
140099b0f:     	movaps	%xmm7, 0x1a0(%rbp)
140099b16:     	movaps	%xmm7, 0x1b0(%rbp)
140099b1d:     	movaps	%xmm7, 0x1c0(%rbp)
140099b24:     	movaps	%xmm7, 0x1d0(%rbp)
140099b2b:     	cmpq	$0x11, %rdi
140099b2f:     	jae	0x140099be8 <.text+0x98be8>
140099b35:     	leaq	0xe0(%rbp), %rbx
140099b3c:     	leaq	0x230(%rbp), %rdx
140099b43:     	movq	%rbx, %rcx
140099b46:     	movq	%rdi, %r8
140099b49:     	callq	0x140247b40 <.text+0x246b40>
140099b4e:     	movw	%di, 0x1e0(%rbp)
140099b55:     	movq	$0x0, -0x60(%rbp)
140099b5d:     	movq	0x258(%rbp), %rax
140099b64:     	movq	%rax, -0x48(%rbp)
140099b68:     	movq	%r15, -0x50(%rbp)
140099b6c:     	movl	%r14d, -0x40(%rbp)
140099b70:     	movl	0x268(%rbp), %eax
140099b76:     	movl	%eax, -0x3c(%rbp)
140099b79:     	movzwl	0x26c(%rbp), %eax
140099b80:     	movw	%ax, -0x38(%rbp)
140099b84:     	movzbl	0x26f(%rbp), %eax
140099b8b:     	movb	%al, -0x36(%rbp)
140099b8e:     	movb	%r12b, -0x35(%rbp)
140099b92:     	movd	%xmm6, -0x34(%rbp)
140099b97:     	movq	0x260(%rbp), %rax
140099b9e:     	movq	%rax, -0x30(%rbp)
140099ba2:     	leaq	-0x28(%rbp), %rcx
140099ba6:     	movl	$0x108, %r8d            # imm = 0x108
140099bac:     	movq	%rbx, %rdx
140099baf:     	callq	0x140247b40 <.text+0x246b40>
140099bb4:     	leaq	-0x60(%rbp), %rdx
140099bb8:     	movq	%rsi, %rcx
140099bbb:     	callq	0x1400116e0 <.text+0x106e0>
140099bc0:     	movb	$0x1, %al
140099bc2:     	jmp	0x140099bc6 <.text+0x98bc6>
140099bc4:     	xorl	%eax, %eax
140099bc6:     	movaps	0x270(%rbp), %xmm6
140099bcd:     	movaps	0x280(%rbp), %xmm7
140099bd4:     	addq	$0x318, %rsp            # imm = 0x318
140099bdb:     	popq	%rbx
140099bdc:     	popq	%rdi
140099bdd:     	popq	%rsi
140099bde:     	popq	%r12
140099be0:     	popq	%r13
140099be2:     	popq	%r14
140099be4:     	popq	%r15
140099be6:     	popq	%rbp
140099be7:     	retq
140099be8:     	leaq	0x1c5f79(%rip), %r9     # 0x14025fb68
140099bef:     	movl	$0x10, %r8d
140099bf5:     	xorl	%ecx, %ecx
140099bf7:     	movq	%rdi, %rdx
140099bfa:     	callq	0x140248590 <.text+0x247590>
140099bff:     	ud2

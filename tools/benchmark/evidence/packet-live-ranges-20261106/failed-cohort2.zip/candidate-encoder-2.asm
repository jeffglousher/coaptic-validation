
D:\CoapticCurrent\packet-response-origin-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140066420:     	pushq	%rbp
140066421:     	pushq	%r15
140066423:     	pushq	%r14
140066425:     	pushq	%r13
140066427:     	pushq	%r12
140066429:     	pushq	%rsi
14006642a:     	pushq	%rdi
14006642b:     	pushq	%rbx
14006642c:     	subq	$0x4f8, %rsp            # imm = 0x4F8
140066433:     	leaq	0x80(%rsp), %rbp
14006643b:     	movq	%r9, %rbx
14006643e:     	movq	%r8, %r14
140066441:     	movq	%rdx, %rdi
140066444:     	movq	%rcx, %rsi
140066447:     	movq	0x4f0(%rbp), %r12
14006644e:     	leaq	-0x10(%rbp), %rcx
140066452:     	movl	$0x400, %r8d            # imm = 0x400
140066458:     	xorl	%edx, %edx
14006645a:     	callq	0x140247b52 <.text+0x246b52>
14006645f:     	movq	0x8(%r12), %r13
140066464:     	movl	$0x3, %eax
140066469:     	cmpq	$0x3, %r13
14006646d:     	ja	0x140066686 <.text+0x65686>
140066473:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
14006647c:     	jne	0x140066686 <.text+0x65686>
140066482:     	movq	0x2b750(%rdi,%r13,8), %rdx
14006648a:     	cmpq	$0x4001, %rdx           # imm = 0x4001
140066491:     	jae	0x1400666e2 <.text+0x656e2>
140066497:     	movq	0x10(%r12), %rcx
14006649c:     	movq	0x18(%r12), %r15
1400664a1:     	movq	%r15, %r8
1400664a4:     	movl	$0xb, %eax
1400664a9:     	addq	%rcx, %r8
1400664ac:     	jb	0x140066686 <.text+0x65686>
1400664b2:     	cmpq	$0x400, %r15            # imm = 0x400
1400664b9:     	ja	0x140066686 <.text+0x65686>
1400664bf:     	cmpq	%rdx, %r8
1400664c2:     	ja	0x140066686 <.text+0x65686>
1400664c8:     	movq	%r13, %rax
1400664cb:     	shlq	$0xe, %rax
1400664cf:     	leaq	(%rdi,%rax), %rdx
1400664d3:     	addq	$0x1b750, %rdx          # imm = 0x1B750
1400664da:     	addq	%rcx, %rdx
1400664dd:     	leaq	-0x10(%rbp), %rcx
1400664e1:     	movq	%r15, %r8
1400664e4:     	callq	0x140247b40 <.text+0x246b40>
1400664e9:     	cmpb	$0x0, 0x4f8(%rbp)
1400664f0:     	je	0x140066508 <.text+0x65508>
1400664f2:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
1400664f9:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
140066502:     	jne	0x1400666a1 <.text+0x656a1>
140066508:     	movq	$0x0, 0x470(%rbp)
140066513:     	movq	%rdi, %rcx
140066516:     	callq	0x140095900 <.text+0x94900>
14006651b:     	testb	$0x1, %al
14006651d:     	je	0x1400666d4 <.text+0x656d4>
140066523:     	movq	%rdx, %r13
140066526:     	movq	0x500(%rbp), %rdx
14006652d:     	movzwl	0x4e8(%rbp), %ecx
140066534:     	movzbl	0x4e0(%rbp), %eax
14006653b:     	movq	(%r12), %r8
14006653f:     	movq	0x470(%rbp), %r9
140066546:     	movq	%r9, 0x438(%rbp)
14006654d:     	movq	0x468(%rbp), %r9
140066554:     	movq	%r9, 0x440(%rbp)
14006655b:     	movq	%r8, 0x448(%rbp)
140066562:     	movzbl	0x4f8(%rbp), %r8d
14006656a:     	movb	%r8b, 0x450(%rbp)
140066571:     	movups	0x38(%r14), %xmm0
140066576:     	movups	0x44(%r14), %xmm1
14006657b:     	movups	%xmm1, 0x3fc(%rbp)
140066582:     	movaps	%xmm0, 0x3f0(%rbp)
140066589:     	leaq	0x66(%r14), %r8
14006658d:     	movq	0x56(%r14), %r9
140066591:     	movq	0x5d(%r14), %r10
140066595:     	movq	%r10, 0x45f(%rbp)
14006659c:     	movq	%r9, 0x458(%rbp)
1400665a3:     	leaq	0x458(%rbp), %r9
1400665aa:     	movq	%r9, 0x68(%rsp)
1400665af:     	movq	%rdx, 0x60(%rsp)
1400665b4:     	movq	%r14, 0x58(%rsp)
1400665b9:     	leaq	0x438(%rbp), %rdx
1400665c0:     	movq	%rdx, 0x50(%rsp)
1400665c5:     	movq	%r15, 0x48(%rsp)
1400665ca:     	leaq	-0x10(%rbp), %rdx
1400665ce:     	movq	%rdx, 0x40(%rsp)
1400665d3:     	movq	%rbx, 0x38(%rsp)
1400665d8:     	movq	%r8, 0x30(%rsp)
1400665dd:     	movw	%cx, 0x28(%rsp)
1400665e2:     	movb	%al, 0x20(%rsp)
1400665e6:     	leaq	0x418(%rbp), %rcx
1400665ed:     	leaq	0x3f0(%rbp), %r8
1400665f4:     	movq	%rdi, %rdx
1400665f7:     	movq	%r13, %r9
1400665fa:     	callq	0x14007eaa0 <.text+0x7daa0>
1400665ff:     	cmpb	$-0x1, 0x418(%rbp)
140066606:     	je	0x1400666d9 <.text+0x656d9>
14006660c:     	cmpb	$0x1, 0x37740(%rdi,%r13)
140066615:     	jne	0x14006666f <.text+0x6566f>
140066617:     	cmpb	$0x0, 0x37760(%rdi,%r13)
140066620:     	jne	0x14006666f <.text+0x6566f>
140066622:     	movb	$0x0, 0x37740(%rdi,%r13)
14006662b:     	decq	0x37788(%rdi)
140066632:     	leaq	0x37740(%rdi), %rax
140066639:     	movq	$0x0, 0x43610(%rdi,%r13,8)
140066645:     	leaq	(,%r13,8), %rcx
14006664d:     	addq	%r13, %rcx
140066650:     	leaq	(%rcx,%rcx,2), %rcx
140066654:     	addq	%r13, %rcx
140066657:     	movb	$0x2, 0x36a(%rax,%rcx)
14006665f:     	leaq	(,%r13,2), %rcx
140066667:     	addq	%r13, %rcx
14006666a:     	movb	$0x2, 0x5d(%rax,%rcx,8)
14006666f:     	movups	0x418(%rbp), %xmm0
140066676:     	movups	0x428(%rbp), %xmm1
14006667d:     	movups	%xmm1, 0x10(%rsi)
140066681:     	movups	%xmm0, (%rsi)
140066684:     	jmp	0x14006668d <.text+0x6568d>
140066686:     	movb	$0xa, (%rsi)
140066689:     	movq	%rax, 0x8(%rsi)
14006668d:     	addq	$0x4f8, %rsp            # imm = 0x4F8
140066694:     	popq	%rbx
140066695:     	popq	%rdi
140066696:     	popq	%rsi
140066697:     	popq	%r12
140066699:     	popq	%r13
14006669b:     	popq	%r14
14006669d:     	popq	%r15
14006669f:     	popq	%rbp
1400666a0:     	retq
1400666a1:     	addq	%rdi, %rax
1400666a4:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
1400666aa:     	movq	0x98(%rax), %rax
1400666b1:     	movq	%rax, 0x468(%rbp)
1400666b8:     	movl	$0x1, %eax
1400666bd:     	movq	%rax, 0x470(%rbp)
1400666c4:     	movq	%rdi, %rcx
1400666c7:     	callq	0x140095900 <.text+0x94900>
1400666cc:     	testb	$0x1, %al
1400666ce:     	jne	0x140066523 <.text+0x65523>
1400666d4:     	movb	$0x9, (%rsi)
1400666d7:     	jmp	0x14006668d <.text+0x6568d>
1400666d9:     	movq	%r13, 0x8(%rsi)
1400666dd:     	movb	$-0x1, (%rsi)
1400666e0:     	jmp	0x14006668d <.text+0x6568d>
1400666e2:     	leaq	0x1fc55f(%rip), %r9     # 0x140262c48
1400666e9:     	movl	$0x4000, %r8d           # imm = 0x4000
1400666ef:     	xorl	%ecx, %ecx
1400666f1:     	callq	0x140248590 <.text+0x247590>
1400666f6:     	ud2

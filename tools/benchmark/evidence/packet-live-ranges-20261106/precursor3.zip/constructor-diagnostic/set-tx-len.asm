
D:\CoapticCurrent\packet-body-borrow-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140230fc0:     	pushq	%rbp
140230fc1:     	subq	$0x20, %rsp
140230fc5:     	leaq	0x20(%rsp), %rbp
140230fca:     	movq	0x88(%rcx), %rax
140230fd1:     	cmpq	%rax, %rdx
140230fd4:     	jae	0x14023100d <.text+0x23000d>
140230fd6:     	movq	0x80(%rcx), %r9
140230fdd:     	cmpb	$0x0, (%r9,%rdx)
140230fe2:     	je	0x14023100d <.text+0x23000d>
140230fe4:     	movb	$0x2, %al
140230fe6:     	cmpq	0xb8(%rcx), %r8
140230fed:     	ja	0x140231007 <.text+0x230007>
140230fef:     	movq	0x70(%rcx), %rax
140230ff3:     	cmpq	%rax, %rdx
140230ff6:     	jae	0x140231019 <.text+0x230019>
140230ff8:     	movq	0x68(%rcx), %rax
140230ffc:     	imulq	$0x58, %rdx, %rcx
140231000:     	movq	%r8, 0x30(%rax,%rcx)
140231005:     	movb	$-0x1, %al
140231007:     	addq	$0x20, %rsp
14023100b:     	popq	%rbp
14023100c:     	retq
14023100d:     	cmpq	%rax, %rdx
140231010:     	setb	%al
140231013:     	addq	$0x20, %rsp
140231017:     	popq	%rbp
140231018:     	retq
140231019:     	leaq	0x418f0(%rip), %r8      # 0x140272910
140231020:     	movq	%rdx, %rcx
140231023:     	movq	%rax, %rdx
140231026:     	callq	0x14024ede3 <.text+0x24dde3>
14023102b:     	ud2

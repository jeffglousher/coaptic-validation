
D:\CoapticCurrent\packet-body-borrow-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401a6930:     	pushq	%rbp
1401a6931:     	pushq	%r15
1401a6933:     	pushq	%r14
1401a6935:     	pushq	%r13
1401a6937:     	pushq	%r12
1401a6939:     	pushq	%rsi
1401a693a:     	pushq	%rdi
1401a693b:     	pushq	%rbx
1401a693c:     	subq	$0x118, %rsp            # imm = 0x118
1401a6943:     	leaq	0x80(%rsp), %rbp
1401a694b:     	movq	0x108(%rbp), %rax
1401a6952:     	movq	(%rdx), %r10
1401a6955:     	movups	(%r10), %xmm0
1401a6959:     	movups	0xc(%r10), %xmm1
1401a695e:     	movups	%xmm1, -0x14(%rbp)
1401a6962:     	movaps	%xmm0, -0x20(%rbp)
1401a6966:     	movq	0x8(%rdx), %r10
1401a696a:     	movq	(%r10), %r11
1401a696d:     	movq	0x7(%r10), %r10
1401a6971:     	movq	%r10, 0x6f(%rbp)
1401a6975:     	movq	%r11, 0x68(%rbp)
1401a6979:     	movq	0x10(%rdx), %r10
1401a697d:     	movq	(%r10), %rsi
1401a6980:     	movups	(%rax), %xmm0
1401a6983:     	movups	0x10(%rax), %xmm1
1401a6987:     	movups	0x20(%rax), %xmm2
1401a698b:     	movaps	%xmm2, 0x20(%rbp)
1401a698f:     	movaps	%xmm1, 0x10(%rbp)
1401a6993:     	movaps	%xmm0, (%rbp)
1401a6997:     	cmpq	0x88(%r8), %rsi
1401a699e:     	jae	0x1401a6a1c <.text+0x1a5a1c>
1401a69a0:     	movq	0x80(%r8), %rbx
1401a69a7:     	cmpb	$0x1, (%rbx,%rsi)
1401a69ab:     	jne	0x1401a6a1c <.text+0x1a5a1c>
1401a69ad:     	cmpq	0x70(%r8), %rsi
1401a69b1:     	jae	0x1401a6a1c <.text+0x1a5a1c>
1401a69b3:     	movq	0x68(%r8), %r12
1401a69b7:     	imulq	$0x58, %rsi, %r13
1401a69bb:     	movq	0x10(%r12,%r13), %r10
1401a69c0:     	movq	0x30(%r12,%r13), %rax
1401a69c5:     	cmpq	%r10, %rax
1401a69c8:     	ja	0x1401a6c1d <.text+0x1a5c1d>
1401a69ce:     	movzbl	0x110(%rbp), %r14d
1401a69d6:     	movq	0x100(%rbp), %r11
1401a69dd:     	movq	0x18(%rdx), %r10
1401a69e1:     	movq	0x20(%rdx), %rdi
1401a69e5:     	movq	%rdi, 0x88(%rbp)
1401a69ec:     	movq	(%r10), %r15
1401a69ef:     	movq	0x28(%rdx), %rdi
1401a69f3:     	testq	%rax, %rax
1401a69f6:     	jne	0x1401a6c33 <.text+0x1a5c33>
1401a69fc:     	movq	0xa0(%r8), %r14
1401a6a03:     	cmpq	%r14, %rsi
1401a6a06:     	jae	0x1401a6a35 <.text+0x1a5a35>
1401a6a08:     	movq	0x98(%r8), %rax
1401a6a0f:     	cmpb	$0x0, (%rax,%rsi)
1401a6a13:     	je	0x1401a6a35 <.text+0x1a5a35>
1401a6a15:     	movw	$0x307, (%rcx)          # imm = 0x307
1401a6a1a:     	jmp	0x1401a6a21 <.text+0x1a5a21>
1401a6a1c:     	movw	$0x107, (%rcx)          # imm = 0x107
1401a6a21:     	addq	$0x118, %rsp            # imm = 0x118
1401a6a28:     	popq	%rbx
1401a6a29:     	popq	%rdi
1401a6a2a:     	popq	%rsi
1401a6a2b:     	popq	%r12
1401a6a2d:     	popq	%r13
1401a6a2f:     	popq	%r14
1401a6a31:     	popq	%r15
1401a6a33:     	popq	%rbp
1401a6a34:     	retq
1401a6a35:     	movq	%r8, 0x78(%rbp)
1401a6a39:     	movq	%rcx, 0x90(%rbp)
1401a6a40:     	movq	%r9, 0x58(%rbp)
1401a6a44:     	movq	%r9, %rcx
1401a6a47:     	callq	*0x50(%r11)
1401a6a4b:     	movq	%rdi, %r9
1401a6a4e:     	subq	0x88(%rbp), %r9
1401a6a55:     	setb	%cl
1401a6a58:     	cmpq	$0x401, %r9             # imm = 0x401
1401a6a5f:     	setae	%dl
1401a6a62:     	orb	%cl, %dl
1401a6a64:     	je	0x1401a6a7a <.text+0x1a5a7a>
1401a6a66:     	movq	0x90(%rbp), %rax
1401a6a6d:     	movb	$0xa, (%rax)
1401a6a70:     	movq	$0xb, 0x8(%rax)
1401a6a78:     	jmp	0x1401a6a21 <.text+0x1a5a21>
1401a6a7a:     	movq	0x78(%rbp), %r10
1401a6a7e:     	cmpq	$-0x1, 0x230(%r10)
1401a6a86:     	movq	0x90(%rbp), %rcx
1401a6a8d:     	je	0x1401a6b33 <.text+0x1a5b33>
1401a6a93:     	cmpq	0x258(%r10), %r15
1401a6a9a:     	jae	0x1401a6b33 <.text+0x1a5b33>
1401a6aa0:     	movq	0x250(%r10), %rdx
1401a6aa7:     	movb	$0x1, %r11b
1401a6aaa:     	cmpb	$0x1, (%rdx,%r15)
1401a6aaf:     	jne	0x1401a6b36 <.text+0x1a5b36>
1401a6ab5:     	cmpq	0x240(%r10), %r15
1401a6abc:     	jae	0x1401a6b36 <.text+0x1a5b36>
1401a6abe:     	movq	0x238(%r10), %rdx
1401a6ac5:     	imulq	$0x2d0, %r15, %r15      # imm = 0x2D0
1401a6acc:     	movq	0x2c0(%rdx,%r15), %r8
1401a6ad4:     	movq	%r15, 0x60(%rbp)
1401a6ad8:     	movq	0x2c8(%rdx,%r15), %r15
1401a6ae0:     	movq	%r15, 0x80(%rbp)
1401a6ae7:     	cmpq	%r8, %r15
1401a6aea:     	ja	0x1401a6c80 <.text+0x1a5c80>
1401a6af0:     	cmpb	$0x1, (%rbx,%rsi)
1401a6af4:     	movq	0x58(%rbp), %rbx
1401a6af8:     	jne	0x1401a6b36 <.text+0x1a5b36>
1401a6afa:     	addq	0x60(%rbp), %rdx
1401a6afe:     	movq	0x2b8(%rdx), %r8
1401a6b05:     	cmpq	%r14, %rsi
1401a6b08:     	jae	0x1401a6b1a <.text+0x1a5b1a>
1401a6b0a:     	movq	0x98(%r10), %rdx
1401a6b11:     	movb	$0x3, %r11b
1401a6b14:     	cmpb	$0x0, (%rdx,%rsi)
1401a6b18:     	jne	0x1401a6b36 <.text+0x1a5b36>
1401a6b1a:     	cmpq	0x80(%rbp), %rdi
1401a6b21:     	jbe	0x1401a6b42 <.text+0x1a5b42>
1401a6b23:     	movb	$0xa, (%rcx)
1401a6b26:     	movq	$0xb, 0x8(%rcx)
1401a6b2e:     	jmp	0x1401a6a21 <.text+0x1a5a21>
1401a6b33:     	xorl	%r11d, %r11d
1401a6b36:     	movb	$0x7, (%rcx)
1401a6b39:     	movb	%r11b, 0x1(%rcx)
1401a6b3d:     	jmp	0x1401a6a21 <.text+0x1a5a21>
1401a6b42:     	addq	%r13, %r12
1401a6b45:     	movq	0x8(%r12), %rcx
1401a6b4a:     	movq	0x10(%r12), %rdx
1401a6b4f:     	addq	0x88(%rbp), %r8
1401a6b56:     	movq	%r8, 0x10(%rbp)
1401a6b5a:     	movq	%r9, 0x18(%rbp)
1401a6b5e:     	cmpq	$0x5c0, %rdx            # imm = 0x5C0
1401a6b65:     	movl	$0x5c0, %r8d            # imm = 0x5C0
1401a6b6b:     	cmovbq	%rdx, %r8
1401a6b6f:     	testb	%al, %al
1401a6b71:     	cmoveq	%rdx, %r8
1401a6b75:     	movl	-0xc(%rbp), %r9d
1401a6b79:     	movq	%r8, 0x40(%rsp)
1401a6b7e:     	movq	%rcx, 0x38(%rsp)
1401a6b83:     	movzbl	0x110(%rbp), %eax
1401a6b8a:     	movb	%al, 0x30(%rsp)
1401a6b8e:     	movq	%rbp, %rax
1401a6b91:     	movq	%rax, 0x28(%rsp)
1401a6b96:     	leaq	0x68(%rbp), %rax
1401a6b9a:     	movq	%rax, 0x20(%rsp)
1401a6b9f:     	leaq	0x38(%rbp), %rcx
1401a6ba3:     	movq	%rbx, %rdx
1401a6ba6:     	movq	0x100(%rbp), %r8
1401a6bad:     	callq	0x140101cd0 <.text+0x100cd0>
1401a6bb2:     	movzbl	0x38(%rbp), %eax
1401a6bb6:     	cmpb	$-0x1, %al
1401a6bb8:     	je	0x1401a6be8 <.text+0x1a5be8>
1401a6bba:     	movl	0x39(%rbp), %ecx
1401a6bbd:     	movl	0x3c(%rbp), %edx
1401a6bc0:     	movq	0x90(%rbp), %r8
1401a6bc7:     	movl	%edx, 0x4(%r8)
1401a6bcb:     	movl	%ecx, 0x1(%r8)
1401a6bcf:     	movq	0x40(%rbp), %rcx
1401a6bd3:     	movups	0x48(%rbp), %xmm0
1401a6bd7:     	movups	%xmm0, 0x10(%r8)
1401a6bdc:     	movb	%al, (%r8)
1401a6bdf:     	movq	%rcx, 0x8(%r8)
1401a6be3:     	jmp	0x1401a6a21 <.text+0x1a5a21>
1401a6be8:     	movq	0x40(%rbp), %r8
1401a6bec:     	movq	0x78(%rbp), %rcx
1401a6bf0:     	movq	%rsi, %rdx
1401a6bf3:     	callq	0x140230fc0 <.text+0x22ffc0>
1401a6bf8:     	cmpb	$-0x1, %al
1401a6bfa:     	je	0x1401a6c0e <.text+0x1a5c0e>
1401a6bfc:     	movq	0x90(%rbp), %rcx
1401a6c03:     	movb	$0x7, (%rcx)
1401a6c06:     	movb	%al, 0x1(%rcx)
1401a6c09:     	jmp	0x1401a6a21 <.text+0x1a5a21>
1401a6c0e:     	movq	0x90(%rbp), %rax
1401a6c15:     	movb	$-0x1, (%rax)
1401a6c18:     	jmp	0x1401a6a21 <.text+0x1a5a21>
1401a6c1d:     	leaq	0xbf514(%rip), %r9      # 0x140266138
1401a6c24:     	xorl	%ecx, %ecx
1401a6c26:     	movq	%rax, %rdx
1401a6c29:     	movq	%r10, %r8
1401a6c2c:     	callq	0x14024eff0 <.text+0x24dff0>
1401a6c31:     	ud2
1401a6c33:     	movb	%r14b, 0x58(%rsp)
1401a6c38:     	movq	%rdi, 0x50(%rsp)
1401a6c3d:     	movq	0x88(%rbp), %rax
1401a6c44:     	movq	%rax, 0x48(%rsp)
1401a6c49:     	movq	%r15, 0x40(%rsp)
1401a6c4e:     	movq	%rbp, %rax
1401a6c51:     	movq	%rax, 0x38(%rsp)
1401a6c56:     	movq	%rsi, 0x30(%rsp)
1401a6c5b:     	movq	%r8, 0x28(%rsp)
1401a6c60:     	leaq	0x68(%rbp), %rax
1401a6c64:     	movq	%rax, 0x20(%rsp)
1401a6c69:     	leaq	-0x20(%rbp), %rax
1401a6c6d:     	movq	%r9, %rdx
1401a6c70:     	movq	%r11, %r8
1401a6c73:     	movq	%rax, %r9
1401a6c76:     	callq	0x140263540 <.text+0x262540>
1401a6c7b:     	jmp	0x1401a6a21 <.text+0x1a5a21>
1401a6c80:     	leaq	0xcc139(%rip), %r9      # 0x140272dc0
1401a6c87:     	xorl	%ecx, %ecx
1401a6c89:     	movq	0x80(%rbp), %rdx
1401a6c90:     	callq	0x14024eff0 <.text+0x24dff0>
1401a6c95:     	ud2


D:\CoapticCurrent\packet-body-borrow-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401a6ca0:     	pushq	%rbp
1401a6ca1:     	pushq	%r15
1401a6ca3:     	pushq	%r14
1401a6ca5:     	pushq	%r13
1401a6ca7:     	pushq	%r12
1401a6ca9:     	pushq	%rsi
1401a6caa:     	pushq	%rdi
1401a6cab:     	pushq	%rbx
1401a6cac:     	subq	$0xf8, %rsp
1401a6cb3:     	leaq	0x80(%rsp), %rbp
1401a6cbb:     	movq	0xe0(%rbp), %rax
1401a6cc2:     	movq	(%rdx), %r10
1401a6cc5:     	movups	(%r10), %xmm0
1401a6cc9:     	movups	0xc(%r10), %xmm1
1401a6cce:     	movups	%xmm1, -0x14(%rbp)
1401a6cd2:     	movaps	%xmm0, -0x20(%rbp)
1401a6cd6:     	movq	0x8(%rdx), %r10
1401a6cda:     	movq	(%r10), %r11
1401a6cdd:     	movq	0x7(%r10), %r10
1401a6ce1:     	movq	%r10, 0x57(%rbp)
1401a6ce5:     	movq	%r11, 0x50(%rbp)
1401a6ce9:     	movq	0x10(%rdx), %r10
1401a6ced:     	movq	(%r10), %rsi
1401a6cf0:     	movups	(%rax), %xmm0
1401a6cf3:     	movups	0x10(%rax), %xmm1
1401a6cf7:     	movups	0x20(%rax), %xmm2
1401a6cfb:     	movaps	%xmm2, 0x20(%rbp)
1401a6cff:     	movaps	%xmm1, 0x10(%rbp)
1401a6d03:     	movaps	%xmm0, (%rbp)
1401a6d07:     	cmpq	0x88(%r8), %rsi
1401a6d0e:     	jae	0x1401a6d7e <.text+0x1a5d7e>
1401a6d10:     	movq	0x80(%r8), %rax
1401a6d17:     	cmpb	$0x1, (%rax,%rsi)
1401a6d1b:     	jne	0x1401a6d7e <.text+0x1a5d7e>
1401a6d1d:     	cmpq	0x70(%r8), %rsi
1401a6d21:     	jae	0x1401a6d7e <.text+0x1a5d7e>
1401a6d23:     	movq	0x68(%r8), %rbx
1401a6d27:     	imulq	$0x58, %rsi, %r15
1401a6d2b:     	movq	0x10(%rbx,%r15), %rax
1401a6d30:     	movq	0x30(%rbx,%r15), %r10
1401a6d35:     	cmpq	%rax, %r10
1401a6d38:     	ja	0x1401a6f3f <.text+0x1a5f3f>
1401a6d3e:     	movzbl	0xe8(%rbp), %r12d
1401a6d46:     	movq	0x18(%rdx), %r11
1401a6d4a:     	movq	0x20(%rdx), %r14
1401a6d4e:     	movq	(%r11), %r11
1401a6d51:     	movq	0x28(%rdx), %rdi
1401a6d55:     	testq	%r10, %r10
1401a6d58:     	jne	0x1401a6f55 <.text+0x1a5f55>
1401a6d5e:     	movq	0xa0(%r8), %r12
1401a6d65:     	cmpq	%r12, %rsi
1401a6d68:     	jae	0x1401a6d97 <.text+0x1a5d97>
1401a6d6a:     	movq	0x98(%r8), %rdx
1401a6d71:     	cmpb	$0x0, (%rdx,%rsi)
1401a6d75:     	je	0x1401a6d97 <.text+0x1a5d97>
1401a6d77:     	movw	$0x307, (%rcx)          # imm = 0x307
1401a6d7c:     	jmp	0x1401a6d83 <.text+0x1a5d83>
1401a6d7e:     	movw	$0x107, (%rcx)          # imm = 0x107
1401a6d83:     	addq	$0xf8, %rsp
1401a6d8a:     	popq	%rbx
1401a6d8b:     	popq	%rdi
1401a6d8c:     	popq	%rsi
1401a6d8d:     	popq	%r12
1401a6d8f:     	popq	%r13
1401a6d91:     	popq	%r14
1401a6d93:     	popq	%r15
1401a6d95:     	popq	%rbp
1401a6d96:     	retq
1401a6d97:     	cmpl	$0x0, 0x1c0(%r9)
1401a6d9f:     	setne	0x76(%rbp)
1401a6da3:     	cmpq	$-0x1, (%r9)
1401a6da7:     	setne	0x77(%rbp)
1401a6dab:     	movq	%rdi, %r13
1401a6dae:     	subq	%r14, %r13
1401a6db1:     	setb	%dl
1401a6db4:     	cmpq	$0x401, %r13            # imm = 0x401
1401a6dbb:     	setae	%r10b
1401a6dbf:     	orb	%dl, %r10b
1401a6dc2:     	je	0x1401a6dd1 <.text+0x1a5dd1>
1401a6dc4:     	movb	$0xa, (%rcx)
1401a6dc7:     	movq	$0xb, 0x8(%rcx)
1401a6dcf:     	jmp	0x1401a6d83 <.text+0x1a5d83>
1401a6dd1:     	cmpq	$-0x1, 0x230(%r8)
1401a6dd9:     	je	0x1401a6f09 <.text+0x1a5f09>
1401a6ddf:     	cmpq	0x258(%r8), %r11
1401a6de6:     	jae	0x1401a6f09 <.text+0x1a5f09>
1401a6dec:     	movq	0x250(%r8), %rdx
1401a6df3:     	movb	$0x1, %r10b
1401a6df6:     	cmpb	$0x1, (%rdx,%r11)
1401a6dfb:     	jne	0x1401a6f0c <.text+0x1a5f0c>
1401a6e01:     	cmpq	0x240(%r8), %r11
1401a6e08:     	jae	0x1401a6f0c <.text+0x1a5f0c>
1401a6e0e:     	movq	0x238(%r8), %r10
1401a6e15:     	imulq	$0x2d0, %r11, %r11      # imm = 0x2D0
1401a6e1c:     	movq	0x2c0(%r10,%r11), %rdx
1401a6e24:     	movq	%rdx, 0x68(%rbp)
1401a6e28:     	movq	0x2c8(%r10,%r11), %rdx
1401a6e30:     	movq	%rdx, 0x60(%rbp)
1401a6e34:     	cmpq	0x68(%rbp), %rdx
1401a6e38:     	ja	0x1401a6f93 <.text+0x1a5f93>
1401a6e3e:     	addq	%r11, %r10
1401a6e41:     	movq	0x2b8(%r10), %r11
1401a6e48:     	cmpq	%r12, %rsi
1401a6e4b:     	jae	0x1401a6e68 <.text+0x1a5e68>
1401a6e4d:     	movq	%r11, %r12
1401a6e50:     	movq	0x98(%r8), %r11
1401a6e57:     	movb	$0x3, %r10b
1401a6e5a:     	cmpb	$0x0, (%r11,%rsi)
1401a6e5f:     	movq	%r12, %r11
1401a6e62:     	jne	0x1401a6f0c <.text+0x1a5f0c>
1401a6e68:     	cmpq	0x60(%rbp), %rdi
1401a6e6c:     	ja	0x1401a6dc4 <.text+0x1a5dc4>
1401a6e72:     	movq	%r8, 0x68(%rbp)
1401a6e76:     	movq	%rcx, %rdi
1401a6e79:     	addq	%r15, %rbx
1401a6e7c:     	movzbl	0x76(%rbp), %r8d
1401a6e81:     	orb	0x77(%rbp), %r8b
1401a6e85:     	movq	0x8(%rbx), %rcx
1401a6e89:     	addq	%r14, %r11
1401a6e8c:     	movq	%r11, 0x10(%rbp)
1401a6e90:     	movq	%r13, 0x18(%rbp)
1401a6e94:     	cmpq	$0x5c0, %rax            # imm = 0x5C0
1401a6e9a:     	movl	$0x5c0, %edx            # imm = 0x5C0
1401a6e9f:     	cmovbq	%rax, %rdx
1401a6ea3:     	testb	%r8b, %r8b
1401a6ea6:     	cmoveq	%rax, %rdx
1401a6eaa:     	movl	-0xc(%rbp), %r8d
1401a6eae:     	movq	%rdx, 0x38(%rsp)
1401a6eb3:     	movq	%rcx, 0x30(%rsp)
1401a6eb8:     	movzbl	0xe8(%rbp), %eax
1401a6ebf:     	movb	%al, 0x28(%rsp)
1401a6ec3:     	movq	%rbp, %rax
1401a6ec6:     	movq	%rax, 0x20(%rsp)
1401a6ecb:     	leaq	0x30(%rbp), %rcx
1401a6ecf:     	leaq	0x50(%rbp), %rax
1401a6ed3:     	movq	%r9, %rdx
1401a6ed6:     	movq	%rax, %r9
1401a6ed9:     	callq	0x140101e90 <.text+0x100e90>
1401a6ede:     	movzbl	0x30(%rbp), %eax
1401a6ee2:     	cmpb	$-0x1, %al
1401a6ee4:     	je	0x1401a6f18 <.text+0x1a5f18>
1401a6ee6:     	movl	0x31(%rbp), %ecx
1401a6ee9:     	movl	0x34(%rbp), %edx
1401a6eec:     	movl	%edx, 0x4(%rdi)
1401a6eef:     	movl	%ecx, 0x1(%rdi)
1401a6ef2:     	movq	0x38(%rbp), %rcx
1401a6ef6:     	movups	0x40(%rbp), %xmm0
1401a6efa:     	movups	%xmm0, 0x10(%rdi)
1401a6efe:     	movb	%al, (%rdi)
1401a6f00:     	movq	%rcx, 0x8(%rdi)
1401a6f04:     	jmp	0x1401a6d83 <.text+0x1a5d83>
1401a6f09:     	xorl	%r10d, %r10d
1401a6f0c:     	movb	$0x7, (%rcx)
1401a6f0f:     	movb	%r10b, 0x1(%rcx)
1401a6f13:     	jmp	0x1401a6d83 <.text+0x1a5d83>
1401a6f18:     	movq	0x38(%rbp), %r8
1401a6f1c:     	movq	0x68(%rbp), %rcx
1401a6f20:     	movq	%rsi, %rdx
1401a6f23:     	callq	0x140230fc0 <.text+0x22ffc0>
1401a6f28:     	cmpb	$-0x1, %al
1401a6f2a:     	je	0x1401a6f37 <.text+0x1a5f37>
1401a6f2c:     	movb	$0x7, (%rdi)
1401a6f2f:     	movb	%al, 0x1(%rdi)
1401a6f32:     	jmp	0x1401a6d83 <.text+0x1a5d83>
1401a6f37:     	movb	$-0x1, (%rdi)
1401a6f3a:     	jmp	0x1401a6d83 <.text+0x1a5d83>
1401a6f3f:     	leaq	0xbf1f2(%rip), %r9      # 0x140266138
1401a6f46:     	xorl	%ecx, %ecx
1401a6f48:     	movq	%r10, %rdx
1401a6f4b:     	movq	%rax, %r8
1401a6f4e:     	callq	0x14024eff0 <.text+0x24dff0>
1401a6f53:     	ud2
1401a6f55:     	movb	%r12b, 0x50(%rsp)
1401a6f5a:     	movq	%rdi, 0x48(%rsp)
1401a6f5f:     	movq	%r14, 0x40(%rsp)
1401a6f64:     	movq	%r11, 0x38(%rsp)
1401a6f69:     	movq	%rbp, %rax
1401a6f6c:     	movq	%rax, 0x30(%rsp)
1401a6f71:     	movq	%rsi, 0x28(%rsp)
1401a6f76:     	movq	%r8, 0x20(%rsp)
1401a6f7b:     	leaq	-0x20(%rbp), %r8
1401a6f7f:     	leaq	0x50(%rbp), %rax
1401a6f83:     	movq	%r9, %rdx
1401a6f86:     	movq	%rax, %r9
1401a6f89:     	callq	0x140263760 <.text+0x262760>
1401a6f8e:     	jmp	0x1401a6d83 <.text+0x1a5d83>
1401a6f93:     	leaq	0xcbe26(%rip), %r9      # 0x140272dc0
1401a6f9a:     	xorl	%ecx, %ecx
1401a6f9c:     	movq	0x60(%rbp), %rdx
1401a6fa0:     	movq	0x68(%rbp), %r8
1401a6fa4:     	callq	0x14024eff0 <.text+0x24dff0>
1401a6fa9:     	ud2

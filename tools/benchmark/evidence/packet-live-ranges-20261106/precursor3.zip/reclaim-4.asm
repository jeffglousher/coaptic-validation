
D:\CoapticCurrent\packet-body-access-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140099540:     	pushq	%rbp
140099541:     	pushq	%r15
140099543:     	pushq	%r14
140099545:     	pushq	%r13
140099547:     	pushq	%r12
140099549:     	pushq	%rsi
14009954a:     	pushq	%rdi
14009954b:     	pushq	%rbx
14009954c:     	subq	$0x318, %rsp            # imm = 0x318
140099553:     	leaq	0x80(%rsp), %rbp
14009955b:     	movaps	%xmm7, 0x280(%rbp)
140099562:     	movdqa	%xmm6, 0x270(%rbp)
14009956a:     	movq	0xe8(%rcx), %r8
140099571:     	testq	%r8, %r8
140099574:     	je	0x140099954 <.text+0x98954>
14009957a:     	movq	0x88(%rcx), %r11
140099581:     	movq	0xe0(%rcx), %rdx
140099588:     	movq	0xc8(%rcx), %rax
14009958f:     	movq	0xd0(%rcx), %r9
140099596:     	leaq	0x30(%rax), %rsi
14009959a:     	xorl	%ebx, %ebx
14009959c:     	xorl	%edi, %edi
14009959e:     	leaq	(%rdi,%rdi,4), %r12
1400995a2:     	shlq	$0x6, %r12
1400995a6:     	addq	%rsi, %r12
1400995a9:     	jmp	0x1400995c3 <.text+0x985c3>
1400995ab:     	nopl	(%rax,%rax)
1400995b0:     	incq	%rdi
1400995b3:     	addq	$0x140, %r12            # imm = 0x140
1400995ba:     	cmpq	%r8, %rdi
1400995bd:     	jae	0x14009968c <.text+0x9868c>
1400995c3:     	cmpq	%r9, %rdi
1400995c6:     	setb	%r15b
1400995ca:     	andb	(%rdx,%rdi), %r15b
1400995ce:     	cmpb	$0x1, %r15b
1400995d2:     	jne	0x1400995b0 <.text+0x985b0>
1400995d4:     	movq	-0x30(%r12), %r15
1400995d9:     	cmpq	$0x2, %r15
1400995dd:     	je	0x1400995b0 <.text+0x985b0>
1400995df:     	movq	(%r12), %r13
1400995e3:     	cmpl	$0x1, %r15d
1400995e7:     	setne	%r15b
1400995eb:     	testq	%r13, %r13
1400995ee:     	sete	%r10b
1400995f2:     	orb	%r15b, %r10b
1400995f5:     	cmpb	$0x1, %r10b
1400995f9:     	je	0x1400995b0 <.text+0x985b0>
1400995fb:     	movq	0x260(%rbp), %r15
140099602:     	cmpq	%r15, %r13
140099605:     	setae	%r10b
140099609:     	testb	%r10b, %bl
14009960c:     	jne	0x140099675 <.text+0x98675>
14009960e:     	movq	-0x28(%r12), %r10
140099613:     	movq	%r10, 0x250(%rbp)
14009961a:     	movq	-0x20(%r12), %r10
14009961f:     	movq	%r10, 0x248(%rbp)
140099626:     	movd	-0x4(%r12), %xmm6
14009962d:     	movzbl	-0x5(%r12), %r10d
140099633:     	movb	%r10b, 0x26e(%rbp)
14009963a:     	movzbl	-0x6(%r12), %r10d
140099640:     	movb	%r10b, 0x26f(%rbp)
140099647:     	movzwl	-0x8(%r12), %r10d
14009964d:     	movw	%r10w, 0x26c(%rbp)
140099655:     	movl	-0xc(%r12), %r10d
14009965a:     	movl	%r10d, 0x268(%rbp)
140099661:     	movl	-0x10(%r12), %r14d
140099666:     	movq	-0x18(%r12), %r10
14009966b:     	movq	%r10, 0x258(%rbp)
140099672:     	movq	%r13, %r15
140099675:     	movq	%r15, 0x260(%rbp)
14009967c:     	incq	%rdi
14009967f:     	movb	$0x1, %bl
140099681:     	cmpq	%r8, %rdi
140099684:     	jb	0x14009959e <.text+0x9859e>
14009968a:     	jmp	0x140099695 <.text+0x98695>
14009968c:     	testb	$0x1, %bl
14009968f:     	je	0x140099954 <.text+0x98954>
140099695:     	movq	0x250(%rbp), %r10
14009969c:     	cmpq	%r11, %r10
14009969f:     	jae	0x1400996f5 <.text+0x986f5>
1400996a1:     	movq	0x80(%rcx), %r11
1400996a8:     	cmpb	$0x1, (%r11,%r10)
1400996ad:     	jne	0x1400996f5 <.text+0x986f5>
1400996af:     	cmpq	0xa0(%rcx), %r10
1400996b6:     	jae	0x1400996c6 <.text+0x986c6>
1400996b8:     	movq	0x98(%rcx), %rsi
1400996bf:     	cmpb	$0x0, (%rsi,%r10)
1400996c4:     	jne	0x1400996f5 <.text+0x986f5>
1400996c6:     	movb	$0x0, (%r11,%r10)
1400996cb:     	decq	0xb0(%rcx)
1400996d2:     	cmpq	0x70(%rcx), %r10
1400996d6:     	jae	0x1400996f5 <.text+0x986f5>
1400996d8:     	movq	0x68(%rcx), %r11
1400996dc:     	imulq	$0x58, %r10, %r10
1400996e0:     	movq	$0x0, 0x30(%r11,%r10)
1400996e9:     	movb	$0x2, 0x52(%r11,%r10)
1400996ef:     	movb	$0x2, 0x25(%r11,%r10)
1400996f5:     	leaq	0xc0(%rcx), %rsi
1400996fc:     	movd	%xmm6, %r10d
140099701:     	addq	$0x2c, %rax
140099705:     	xorl	%r11d, %r11d
140099708:     	movq	0x248(%rbp), %r15
14009970f:     	movzbl	0x26e(%rbp), %r12d
140099717:     	jmp	0x140099732 <.text+0x98732>
140099719:     	nopl	(%rax)
140099720:     	incq	%r11
140099723:     	addq	$0x140, %rax            # imm = 0x140
140099729:     	cmpq	%r11, %r8
14009972c:     	je	0x1400997be <.text+0x987be>
140099732:     	cmpq	%r9, %r11
140099735:     	setb	%bl
140099738:     	andb	(%rdx,%r11), %bl
14009973c:     	cmpb	$0x1, %bl
14009973f:     	jne	0x140099720 <.text+0x98720>
140099741:     	cmpl	$0x2, -0x2c(%rax)
140099745:     	je	0x140099720 <.text+0x98720>
140099747:     	cmpw	%r10w, (%rax)
14009974b:     	jne	0x140099720 <.text+0x98720>
14009974d:     	cmpl	%r14d, -0xc(%rax)
140099751:     	jne	0x140099720 <.text+0x98720>
140099753:     	movl	0x268(%rbp), %edi
140099759:     	cmpl	%edi, -0x8(%rax)
14009975c:     	jne	0x140099720 <.text+0x98720>
14009975e:     	movzwl	0x26c(%rbp), %edi
140099765:     	cmpw	%di, -0x4(%rax)
140099769:     	jne	0x140099720 <.text+0x98720>
14009976b:     	movzbl	0x26f(%rbp), %ebx
140099772:     	cmpb	%bl, -0x2(%rax)
140099775:     	jne	0x140099720 <.text+0x98720>
140099777:     	movq	-0x1c(%rax), %rdi
14009977b:     	xorq	%r15, %rdi
14009977e:     	movq	-0x14(%rax), %rbx
140099782:     	xorq	0x258(%rbp), %rbx
140099789:     	orq	%rdi, %rbx
14009978c:     	jne	0x140099720 <.text+0x98720>
14009978e:     	cmpq	%r8, %r11
140099791:     	jae	0x1400997be <.text+0x987be>
140099793:     	cmpq	0x100(%rcx), %r11
14009979a:     	jae	0x1400997aa <.text+0x987aa>
14009979c:     	movq	0xf8(%rcx), %r8
1400997a3:     	cmpb	$0x0, (%r8,%r11)
1400997a8:     	jne	0x1400997be <.text+0x987be>
1400997aa:     	movb	$0x0, (%rdx,%r11)
1400997af:     	decq	0x110(%rcx)
1400997b6:     	movq	$0x2, -0x2c(%rax)
1400997be:     	xorps	%xmm7, %xmm7
1400997c1:     	movaps	%xmm7, 0x230(%rbp)
1400997c8:     	movb	$0x0, 0x212(%rbp)
1400997cf:     	movw	%r10w, 0x210(%rbp)
1400997d7:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
1400997e0:     	movq	$0x0, 0x213(%rbp)
1400997eb:     	movq	$0x8, 0x1f0(%rbp)
1400997f6:     	movq	$0x0, 0x1f8(%rbp)
140099801:     	movq	$0x1, 0x200(%rbp)
14009980c:     	movq	$0x0, 0x208(%rbp)
140099817:     	leaq	0x220(%rbp), %rcx
14009981e:     	leaq	0x1f0(%rbp), %rdx
140099825:     	leaq	0x230(%rbp), %r8
14009982c:     	movl	$0x10, %r9d
140099832:     	callq	0x140110890 <.text+0x10f890>
140099837:     	cmpb	$0x0, 0x220(%rbp)
14009983e:     	jne	0x140099950 <.text+0x98950>
140099844:     	movq	0x228(%rbp), %rdi
14009984b:     	movaps	%xmm7, 0xe0(%rbp)
140099852:     	movaps	%xmm7, 0xf0(%rbp)
140099859:     	movaps	%xmm7, 0x100(%rbp)
140099860:     	movaps	%xmm7, 0x110(%rbp)
140099867:     	movaps	%xmm7, 0x120(%rbp)
14009986e:     	movaps	%xmm7, 0x130(%rbp)
140099875:     	movaps	%xmm7, 0x140(%rbp)
14009987c:     	movaps	%xmm7, 0x150(%rbp)
140099883:     	movaps	%xmm7, 0x160(%rbp)
14009988a:     	movaps	%xmm7, 0x170(%rbp)
140099891:     	movaps	%xmm7, 0x180(%rbp)
140099898:     	movaps	%xmm7, 0x190(%rbp)
14009989f:     	movaps	%xmm7, 0x1a0(%rbp)
1400998a6:     	movaps	%xmm7, 0x1b0(%rbp)
1400998ad:     	movaps	%xmm7, 0x1c0(%rbp)
1400998b4:     	movaps	%xmm7, 0x1d0(%rbp)
1400998bb:     	cmpq	$0x11, %rdi
1400998bf:     	jae	0x140099978 <.text+0x98978>
1400998c5:     	leaq	0xe0(%rbp), %rbx
1400998cc:     	leaq	0x230(%rbp), %rdx
1400998d3:     	movq	%rbx, %rcx
1400998d6:     	movq	%rdi, %r8
1400998d9:     	callq	0x14024ea60 <.text+0x24da60>
1400998de:     	movw	%di, 0x1e0(%rbp)
1400998e5:     	movq	$0x0, -0x60(%rbp)
1400998ed:     	movq	0x258(%rbp), %rax
1400998f4:     	movq	%rax, -0x48(%rbp)
1400998f8:     	movq	%r15, -0x50(%rbp)
1400998fc:     	movl	%r14d, -0x40(%rbp)
140099900:     	movl	0x268(%rbp), %eax
140099906:     	movl	%eax, -0x3c(%rbp)
140099909:     	movzwl	0x26c(%rbp), %eax
140099910:     	movw	%ax, -0x38(%rbp)
140099914:     	movzbl	0x26f(%rbp), %eax
14009991b:     	movb	%al, -0x36(%rbp)
14009991e:     	movb	%r12b, -0x35(%rbp)
140099922:     	movd	%xmm6, -0x34(%rbp)
140099927:     	movq	0x260(%rbp), %rax
14009992e:     	movq	%rax, -0x30(%rbp)
140099932:     	leaq	-0x28(%rbp), %rcx
140099936:     	movl	$0x108, %r8d            # imm = 0x108
14009993c:     	movq	%rbx, %rdx
14009993f:     	callq	0x14024ea60 <.text+0x24da60>
140099944:     	leaq	-0x60(%rbp), %rdx
140099948:     	movq	%rsi, %rcx
14009994b:     	callq	0x140011760 <.text+0x10760>
140099950:     	movb	$0x1, %al
140099952:     	jmp	0x140099956 <.text+0x98956>
140099954:     	xorl	%eax, %eax
140099956:     	movaps	0x270(%rbp), %xmm6
14009995d:     	movaps	0x280(%rbp), %xmm7
140099964:     	addq	$0x318, %rsp            # imm = 0x318
14009996b:     	popq	%rbx
14009996c:     	popq	%rdi
14009996d:     	popq	%rsi
14009996e:     	popq	%r12
140099970:     	popq	%r13
140099972:     	popq	%r14
140099974:     	popq	%r15
140099976:     	popq	%rbp
140099977:     	retq
140099978:     	leaq	0x1d71b9(%rip), %r9     # 0x140270b38
14009997f:     	movl	$0x10, %r8d
140099985:     	xorl	%ecx, %ecx
140099987:     	movq	%rdi, %rdx
14009998a:     	callq	0x14024f4b0 <.text+0x24e4b0>
14009998f:     	ud2


D:\CoapticCurrent\packet-body-access-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140067370:     	pushq	%rbp
140067371:     	pushq	%r15
140067373:     	pushq	%r14
140067375:     	pushq	%r13
140067377:     	pushq	%r12
140067379:     	pushq	%rsi
14006737a:     	pushq	%rdi
14006737b:     	pushq	%rbx
14006737c:     	subq	$0xe8, %rsp
140067383:     	leaq	0x80(%rsp), %rbp
14006738b:     	movq	0xe0(%rbp), %r15
140067392:     	movq	0x8(%r15), %rbx
140067396:     	movl	$0x3, %r10d
14006739c:     	cmpq	$0x3, %rbx
1400673a0:     	ja	0x140067410 <.text+0x66410>
1400673a2:     	cmpb	$0x1, 0x1b748(%rdx,%rbx)
1400673aa:     	jne	0x140067410 <.text+0x66410>
1400673ac:     	movq	0x2b750(%rdx,%rbx,8), %rax
1400673b4:     	cmpq	$0x4001, %rax           # imm = 0x4001
1400673ba:     	jae	0x140067586 <.text+0x66586>
1400673c0:     	movq	0x10(%r15), %r14
1400673c4:     	movq	0x18(%r15), %r11
1400673c8:     	movq	%r11, %r12
1400673cb:     	movl	$0xb, %r10d
1400673d1:     	addq	%r14, %r12
1400673d4:     	jb	0x140067410 <.text+0x66410>
1400673d6:     	cmpq	$0x400, %r11            # imm = 0x400
1400673dd:     	ja	0x140067410 <.text+0x66410>
1400673df:     	cmpq	%rax, %r12
1400673e2:     	ja	0x140067410 <.text+0x66410>
1400673e4:     	cmpb	$0x0, 0xe8(%rbp)
1400673eb:     	movq	%r9, 0x48(%rbp)
1400673ef:     	movq	%rcx, 0x60(%rbp)
1400673f3:     	movq	%r8, 0x50(%rbp)
1400673f7:     	je	0x14006740b <.text+0x6640b>
1400673f9:     	imulq	$0x2b0, %rbx, %rax      # imm = 0x2B0
140067400:     	cmpq	$0x2, 0x1ac78(%rdx,%rax)
140067409:     	jne	0x14006742b <.text+0x6642b>
14006740b:     	xorl	%r13d, %r13d
14006740e:     	jmp	0x140067445 <.text+0x66445>
140067410:     	movb	$0xa, (%rcx)
140067413:     	movq	%r10, 0x8(%rcx)
140067417:     	addq	$0xe8, %rsp
14006741e:     	popq	%rbx
14006741f:     	popq	%rdi
140067420:     	popq	%rsi
140067421:     	popq	%r12
140067423:     	popq	%r13
140067425:     	popq	%r14
140067427:     	popq	%r15
140067429:     	popq	%rbp
14006742a:     	retq
14006742b:     	addq	%rdx, %rax
14006742e:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
140067434:     	movq	0x98(%rax), %rax
14006743b:     	movq	%rax, 0x58(%rbp)
14006743f:     	movl	$0x1, %r13d
140067445:     	movq	%rdx, %rdi
140067448:     	movq	%rdx, %rcx
14006744b:     	callq	0x140095690 <.text+0x94690>
140067450:     	testb	$0x1, %al
140067452:     	je	0x14006756a <.text+0x6656a>
140067458:     	movq	%rdx, %rsi
14006745b:     	movq	0xf8(%rbp), %rax
140067462:     	movq	0xf0(%rbp), %rcx
140067469:     	movzwl	0xd8(%rbp), %edx
140067470:     	movzbl	0xd0(%rbp), %r9d
140067478:     	movq	(%r15), %r8
14006747b:     	movq	%r13, 0x28(%rbp)
14006747f:     	movq	0x58(%rbp), %r10
140067483:     	movq	%r10, 0x30(%rbp)
140067487:     	movq	%r8, 0x38(%rbp)
14006748b:     	movzbl	0xe8(%rbp), %r8d
140067493:     	movb	%r8b, 0x40(%rbp)
140067497:     	movq	0x50(%rbp), %r10
14006749b:     	leaq	0x38(%r10), %r8
14006749f:     	leaq	0x66(%r10), %r11
1400674a3:     	leaq	0x56(%r10), %r15
1400674a7:     	movq	%r15, 0x78(%rsp)
1400674ac:     	movq	%rax, 0x70(%rsp)
1400674b1:     	movq	%rcx, 0x68(%rsp)
1400674b6:     	movq	%r10, 0x60(%rsp)
1400674bb:     	leaq	0x28(%rbp), %rax
1400674bf:     	movq	%rax, 0x58(%rsp)
1400674c4:     	movq	%r12, 0x50(%rsp)
1400674c9:     	movq	%r14, 0x48(%rsp)
1400674ce:     	movq	%rbx, 0x40(%rsp)
1400674d3:     	movq	0x48(%rbp), %rax
1400674d7:     	movq	%rax, 0x38(%rsp)
1400674dc:     	movq	%r11, 0x30(%rsp)
1400674e1:     	movw	%dx, 0x28(%rsp)
1400674e6:     	movb	%r9b, 0x20(%rsp)
1400674eb:     	leaq	0x8(%rbp), %rcx
1400674ef:     	movq	%rdi, %rdx
1400674f2:     	movq	%rsi, %r9
1400674f5:     	callq	0x14009c910 <.text+0x9b910>
1400674fa:     	cmpb	$-0x1, 0x8(%rbp)
1400674fe:     	je	0x140067576 <.text+0x66576>
140067500:     	cmpb	$0x1, 0x37740(%rdi,%rsi)
140067508:     	movq	0x60(%rbp), %rax
14006750c:     	jne	0x140067556 <.text+0x66556>
14006750e:     	cmpb	$0x0, 0x37760(%rdi,%rsi)
140067516:     	jne	0x140067556 <.text+0x66556>
140067518:     	movb	$0x0, 0x37740(%rdi,%rsi)
140067520:     	decq	0x37788(%rdi)
140067527:     	leaq	0x37740(%rdi), %rcx
14006752e:     	movq	$0x0, 0x43610(%rdi,%rsi,8)
14006753a:     	leaq	(%rsi,%rsi,8), %rdx
14006753e:     	leaq	(%rdx,%rdx,2), %rdx
140067542:     	addq	%rsi, %rdx
140067545:     	movb	$0x2, 0x36a(%rcx,%rdx)
14006754d:     	leaq	(%rsi,%rsi,2), %rdx
140067551:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140067556:     	movups	0x8(%rbp), %xmm0
14006755a:     	movups	0x18(%rbp), %xmm1
14006755e:     	movups	%xmm1, 0x10(%rax)
140067562:     	movups	%xmm0, (%rax)
140067565:     	jmp	0x140067417 <.text+0x66417>
14006756a:     	movq	0x60(%rbp), %rax
14006756e:     	movb	$0x9, (%rax)
140067571:     	jmp	0x140067417 <.text+0x66417>
140067576:     	movq	0x60(%rbp), %rax
14006757a:     	movq	%rsi, 0x8(%rax)
14006757e:     	movb	$-0x1, (%rax)
140067581:     	jmp	0x140067417 <.text+0x66417>
140067586:     	leaq	0x20c6a3(%rip), %r9     # 0x140273c30
14006758d:     	movl	$0x4000, %r8d           # imm = 0x4000
140067593:     	xorl	%ecx, %ecx
140067595:     	movq	%rax, %rdx
140067598:     	callq	0x14024f4b0 <.text+0x24e4b0>
14006759d:     	ud2

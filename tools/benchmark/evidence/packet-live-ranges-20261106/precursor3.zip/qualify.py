"""Run required integration checks only after the frozen runtime cohort passes."""
from pathlib import Path
import json, os, subprocess
root = Path(__file__).resolve().parent
assert json.loads((root/'measurement.json').read_text())['runtime_accepted']
repo = Path('C:/Users/jeffg/.t3/worktrees/coaptic/t3-a578955c')
wrapper = str(Path.home()/'.cargo/bin/agent-resources.exe')
env = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_TARGET_DIR='D:/coaptic-batch-interop-target')
env.pop('RUSTFLAGS', None)
env.pop('RUSTC_BOOTSTRAP', None)
checks = [
    ('clippy-all', ['clippy','--locked','--offline','--all-targets','--all-features','--','-D','warnings']),
    ('clippy-no-default', ['clippy','--locked','--offline','--all-targets','--no-default-features','--','-D','warnings']),
    ('test-all', ['test','--locked','--offline','--all-features']),
    ('test-no-default', ['test','--locked','--offline','--no-default-features','--lib']),
    *[(f'test-{features}', ['test','--locked','--offline','--no-default-features','--features',features,'--lib'])
      for features in ['alloc','oscore','alloc,oscore','std']],
    ('msrv-no-default', ['+1.89.0','check','--locked','--offline','-p','coaptic','--no-default-features']),
    ('msrv-all', ['+1.89.0','check','--locked','--offline','-p','coaptic','--all-features']),
    ('docs', ['doc','--locked','--offline','--no-deps','--all-features']),
]
assert subprocess.run(['git','diff','--quiet','5ef69ac78cdedd013cecb58f3b7a2b1aa8f0d824','--','src','crates','tests','Cargo.toml','Cargo.lock'],cwd=repo).returncode==0
prior=json.loads((root/'prequalification.json').read_text())
assert prior['source']=='5ef69ac78cdedd013cecb58f3b7a2b1aa8f0d824'
reused={row['name']:row for row in prior['checks'] if row['exit_code']==0}
results=[]
for name, args in checks:
    cmd=[wrapper,'run','--id','coaptic-core-reusable','--directory',str(repo),'--','cargo',*args]
    if name in reused:
        assert reused[name]['command']==cmd
        results.append(reused[name])
        print({'name':name,'reused_passing_check':True},flush=True)
        continue
    with (root/(name+'.log')).open('wb') as log:
        p=subprocess.run(cmd, cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT)
    results.append({'name':name,'exit_code':p.returncode,'command':cmd})
    (root/'qualification.json').write_text(json.dumps(results,indent=2)+'\n')
    print(results[-1],flush=True)
    if p.returncode:
        raise SystemExit(p.returncode)

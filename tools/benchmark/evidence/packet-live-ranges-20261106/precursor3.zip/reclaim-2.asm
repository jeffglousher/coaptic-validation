
D:\CoapticCurrent\packet-body-access-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140098e00:     	pushq	%rbp
140098e01:     	pushq	%r15
140098e03:     	pushq	%r14
140098e05:     	pushq	%r13
140098e07:     	pushq	%r12
140098e09:     	pushq	%rsi
140098e0a:     	pushq	%rdi
140098e0b:     	pushq	%rbx
140098e0c:     	subq	$0x318, %rsp            # imm = 0x318
140098e13:     	leaq	0x80(%rsp), %rbp
140098e1b:     	movaps	%xmm7, 0x280(%rbp)
140098e22:     	movaps	%xmm6, 0x270(%rbp)
140098e29:     	leaq	0x30(%rcx), %rdx
140098e2d:     	xorl	%r8d, %r8d
140098e30:     	xorl	%r11d, %r11d
140098e33:     	leaq	(%r11,%r11,4), %r10
140098e37:     	shlq	$0x6, %r10
140098e3b:     	addq	%rdx, %r10
140098e3e:     	movq	%r11, %r9
140098e41:     	jmp	0x140098e64 <.text+0x97e64>
140098e43:     	nopw	%cs:(%rax,%rax)
140098e50:     	incq	%r9
140098e53:     	addq	$0x140, %r10            # imm = 0x140
140098e5a:     	cmpq	$0x4, %r9
140098e5e:     	je	0x140098eee <.text+0x97eee>
140098e64:     	cmpb	$0x1, 0x510(%rcx,%r9)
140098e6d:     	jne	0x140098e50 <.text+0x97e50>
140098e6f:     	movq	-0x30(%r10), %rsi
140098e73:     	cmpq	$0x2, %rsi
140098e77:     	je	0x140098e50 <.text+0x97e50>
140098e79:     	movq	(%r10), %r11
140098e7c:     	cmpl	$0x1, %esi
140098e7f:     	setne	%bl
140098e82:     	testq	%r11, %r11
140098e85:     	sete	%sil
140098e89:     	orb	%bl, %sil
140098e8c:     	cmpb	$0x1, %sil
140098e90:     	je	0x140098e50 <.text+0x97e50>
140098e92:     	movq	0x268(%rbp), %rsi
140098e99:     	cmpq	%rsi, %r11
140098e9c:     	setae	%bl
140098e9f:     	testb	%bl, %r8b
140098ea2:     	jne	0x140098ed4 <.text+0x97ed4>
140098ea4:     	movq	-0x28(%r10), %rax
140098ea8:     	movd	-0x4(%r10), %xmm6
140098eae:     	movzbl	-0x5(%r10), %edi
140098eb3:     	movzbl	-0x6(%r10), %r15d
140098eb8:     	movzwl	-0x8(%r10), %r12d
140098ebd:     	movl	-0xc(%r10), %r13d
140098ec1:     	movl	-0x10(%r10), %r14d
140098ec5:     	movups	-0x20(%r10), %xmm0
140098eca:     	movaps	%xmm0, 0x240(%rbp)
140098ed1:     	movq	%r11, %rsi
140098ed4:     	movq	%rsi, 0x268(%rbp)
140098edb:     	leaq	0x1(%r9), %r11
140098edf:     	movb	$0x1, %r8b
140098ee2:     	cmpq	$0x3, %r9
140098ee6:     	jb	0x140098e33 <.text+0x97e33>
140098eec:     	jmp	0x140098ef8 <.text+0x97ef8>
140098eee:     	testb	$0x1, %r8b
140098ef2:     	je	0x140099138 <.text+0x98138>
140098ef8:     	cmpq	$0x1, %rax
140098efc:     	ja	0x140098f54 <.text+0x97f54>
140098efe:     	cmpb	$0x1, 0x4420(%rcx,%rax)
140098f06:     	jne	0x140098f54 <.text+0x97f54>
140098f08:     	cmpb	$0x0, 0x4422(%rcx,%rax)
140098f10:     	jne	0x140098f54 <.text+0x97f54>
140098f12:     	movb	$0x0, 0x4420(%rcx,%rax)
140098f1a:     	decq	0x4418(%rcx)
140098f21:     	leaq	0x3a98(%rcx), %rdx
140098f28:     	movq	$0x0, 0x4398(%rcx,%rax,8)
140098f34:     	leaq	(%rax,%rax,8), %r8
140098f38:     	leaq	(%r8,%r8,2), %r8
140098f3c:     	addq	%rax, %r8
140098f3f:     	movb	$0x2, 0x95a(%rdx,%r8)
140098f48:     	leaq	(%rax,%rax,2), %rax
140098f4c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
140098f54:     	movaps	0x240(%rbp), %xmm0
140098f5b:     	movaps	%xmm0, -0x60(%rbp)
140098f5f:     	movl	%r14d, %esi
140098f62:     	movl	%r14d, -0x50(%rbp)
140098f66:     	movl	%r13d, %r14d
140098f69:     	movl	%r13d, -0x4c(%rbp)
140098f6d:     	movl	%r12d, %r13d
140098f70:     	movw	%r12w, -0x48(%rbp)
140098f75:     	movl	%r15d, %r12d
140098f78:     	movb	%r15b, -0x46(%rbp)
140098f7c:     	movl	%edi, %r15d
140098f7f:     	movb	%dil, -0x45(%rbp)
140098f83:     	movd	%xmm6, %edi
140098f87:     	movd	%xmm6, -0x44(%rbp)
140098f8c:     	leaq	-0x60(%rbp), %rdx
140098f90:     	movq	%rcx, 0x260(%rbp)
140098f97:     	callq	0x140214060 <.text+0x213060>
140098f9c:     	xorps	%xmm7, %xmm7
140098f9f:     	movaps	%xmm7, 0x250(%rbp)
140098fa6:     	movb	$0x0, 0x222(%rbp)
140098fad:     	movw	%di, 0x220(%rbp)
140098fb4:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
140098fbd:     	movq	$0x0, 0x223(%rbp)
140098fc8:     	movq	$0x8, 0x200(%rbp)
140098fd3:     	movq	$0x0, 0x208(%rbp)
140098fde:     	movq	$0x1, 0x210(%rbp)
140098fe9:     	movq	$0x0, 0x218(%rbp)
140098ff4:     	leaq	0x230(%rbp), %rcx
140098ffb:     	leaq	0x200(%rbp), %rdx
140099002:     	leaq	0x250(%rbp), %r8
140099009:     	movl	$0x10, %r9d
14009900f:     	callq	0x140110890 <.text+0x10f890>
140099014:     	cmpb	$0x0, 0x230(%rbp)
14009901b:     	jne	0x140099134 <.text+0x98134>
140099021:     	movq	0x238(%rbp), %rdi
140099028:     	movaps	%xmm7, 0xe0(%rbp)
14009902f:     	movaps	%xmm7, 0xf0(%rbp)
140099036:     	movaps	%xmm7, 0x100(%rbp)
14009903d:     	movaps	%xmm7, 0x110(%rbp)
140099044:     	movaps	%xmm7, 0x120(%rbp)
14009904b:     	movaps	%xmm7, 0x130(%rbp)
140099052:     	movaps	%xmm7, 0x140(%rbp)
140099059:     	movaps	%xmm7, 0x150(%rbp)
140099060:     	movaps	%xmm7, 0x160(%rbp)
140099067:     	movaps	%xmm7, 0x170(%rbp)
14009906e:     	movaps	%xmm7, 0x180(%rbp)
140099075:     	movaps	%xmm7, 0x190(%rbp)
14009907c:     	movaps	%xmm7, 0x1a0(%rbp)
140099083:     	movaps	%xmm7, 0x1b0(%rbp)
14009908a:     	movaps	%xmm7, 0x1c0(%rbp)
140099091:     	movaps	%xmm7, 0x1d0(%rbp)
140099098:     	movaps	0x240(%rbp), %xmm0
14009909f:     	movups	%xmm0, 0x1f0(%rbp)
1400990a6:     	cmpq	$0x11, %rdi
1400990aa:     	jae	0x14009915c <.text+0x9815c>
1400990b0:     	leaq	0xe0(%rbp), %rbx
1400990b7:     	leaq	0x250(%rbp), %rdx
1400990be:     	movq	%rbx, %rcx
1400990c1:     	movq	%rdi, %r8
1400990c4:     	callq	0x14024ea60 <.text+0x24da60>
1400990c9:     	movw	%di, 0x1e0(%rbp)
1400990d0:     	movq	$0x0, -0x60(%rbp)
1400990d8:     	movups	0x1e8(%rbp), %xmm0
1400990df:     	movups	%xmm0, -0x58(%rbp)
1400990e3:     	movq	0x1f8(%rbp), %rax
1400990ea:     	movq	%rax, -0x48(%rbp)
1400990ee:     	movl	%esi, -0x40(%rbp)
1400990f1:     	movl	%r14d, -0x3c(%rbp)
1400990f5:     	movw	%r13w, -0x38(%rbp)
1400990fa:     	movb	%r12b, -0x36(%rbp)
1400990fe:     	movb	%r15b, -0x35(%rbp)
140099102:     	movd	%xmm6, -0x34(%rbp)
140099107:     	movq	0x268(%rbp), %rax
14009910e:     	movq	%rax, -0x30(%rbp)
140099112:     	leaq	-0x28(%rbp), %rcx
140099116:     	movl	$0x108, %r8d            # imm = 0x108
14009911c:     	movq	%rbx, %rdx
14009911f:     	callq	0x14024ea60 <.text+0x24da60>
140099124:     	leaq	-0x60(%rbp), %rdx
140099128:     	movq	0x260(%rbp), %rcx
14009912f:     	callq	0x140213dd0 <.text+0x212dd0>
140099134:     	movb	$0x1, %al
140099136:     	jmp	0x14009913a <.text+0x9813a>
140099138:     	xorl	%eax, %eax
14009913a:     	movaps	0x270(%rbp), %xmm6
140099141:     	movaps	0x280(%rbp), %xmm7
140099148:     	addq	$0x318, %rsp            # imm = 0x318
14009914f:     	popq	%rbx
140099150:     	popq	%rdi
140099151:     	popq	%rsi
140099152:     	popq	%r12
140099154:     	popq	%r13
140099156:     	popq	%r14
140099158:     	popq	%r15
14009915a:     	popq	%rbp
14009915b:     	retq
14009915c:     	leaq	0x1d79d5(%rip), %r9     # 0x140270b38
140099163:     	movl	$0x10, %r8d
140099169:     	xorl	%ecx, %ecx
14009916b:     	movq	%rdi, %rdx
14009916e:     	callq	0x14024f4b0 <.text+0x24e4b0>
140099173:     	ud2

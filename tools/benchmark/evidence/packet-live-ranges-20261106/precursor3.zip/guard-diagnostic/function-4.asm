
D:\CoapticCurrent\packet-body-access-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401eddc0:     	pushq	%rbp
1401eddc1:     	movq	%rsp, %rbp
1401eddc4:     	movq	%rcx, %rax
1401eddc7:     	movl	$0x0, (%rcx)
1401eddcd:     	movl	$0x0, 0x8(%rcx)
1401eddd4:     	movw	$0x1, 0x10(%rcx)
1401eddda:     	leaq	0x85174(%rip), %rcx     # 0x140272f55
1401edde1:     	movq	%rcx, 0x18(%rax)
1401edde5:     	movq	$0x20, 0x20(%rax)
1401edded:     	movb	$-0x1, 0xb5(%rax)
1401eddf4:     	movq	$0x1, 0xc0(%rax)
1401eddff:     	movq	$0x0, 0xc8(%rax)
1401ede0a:     	movq	$0x1, 0xd0(%rax)
1401ede15:     	movq	$0x0, 0xd8(%rax)
1401ede20:     	movq	$0x1, 0xe0(%rax)
1401ede2b:     	movq	$0x0, 0xe8(%rax)
1401ede36:     	movq	$0x1, 0xf0(%rax)
1401ede41:     	movq	$0x0, 0xf8(%rax)
1401ede4c:     	movq	$0x1, 0x100(%rax)
1401ede57:     	movq	$0x0, 0x108(%rax)
1401ede62:     	movq	$0x1, 0x110(%rax)
1401ede6d:     	movq	$0x0, 0x118(%rax)
1401ede78:     	movq	$0x1, 0x120(%rax)
1401ede83:     	movq	$0x0, 0x128(%rax)
1401ede8e:     	movq	$0x1, 0x130(%rax)
1401ede99:     	movq	$0x0, 0x138(%rax)
1401edea4:     	movq	$0x1, 0x140(%rax)
1401edeaf:     	movq	$0x0, 0x148(%rax)
1401edeba:     	movq	$0x1, 0x150(%rax)
1401edec5:     	movq	$0x0, 0x158(%rax)
1401eded0:     	movq	$0x1, 0x160(%rax)
1401ededb:     	movq	$0x0, 0x168(%rax)
1401edee6:     	movq	$0x1, 0x170(%rax)
1401edef1:     	movq	$0x0, 0x178(%rax)
1401edefc:     	movq	$0x1, 0x180(%rax)
1401edf07:     	movq	$0x0, 0x188(%rax)
1401edf12:     	movq	$0x1, 0x190(%rax)
1401edf1d:     	movq	$0x0, 0x198(%rax)
1401edf28:     	movq	$0x1, 0x1a0(%rax)
1401edf33:     	movq	$0x0, 0x1a8(%rax)
1401edf3e:     	movq	$0x1, 0x1b0(%rax)
1401edf49:     	movq	$0x0, 0x1b8(%rax)
1401edf54:     	movabsq	$0x65727574786966, %rcx # imm = 0x65727574786966
1401edf5e:     	movq	%rcx, 0x1c0(%rax)
1401edf65:     	movq	$0x0, 0x1c8(%rax)
1401edf70:     	movq	$0x20, 0x1d8(%rax)
1401edf7b:     	movl	$0x2a0001, 0x1e0(%rax)  # imm = 0x2A0001
1401edf85:     	movb	$0x0, 0x1e4(%rax)
1401edf8c:     	movabsq	$0x745ff000000, %rcx    # imm = 0x745FF000000
1401edf96:     	movq	%rcx, 0x20e(%rax)
1401edf9d:     	popq	%rbp
1401edf9e:     	retq


D:\CoapticCurrent\packet-body-access-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401a7230:     	pushq	%rbp
1401a7231:     	pushq	%r15
1401a7233:     	pushq	%r14
1401a7235:     	pushq	%r13
1401a7237:     	pushq	%r12
1401a7239:     	pushq	%rsi
1401a723a:     	pushq	%rdi
1401a723b:     	pushq	%rbx
1401a723c:     	subq	$0x118, %rsp            # imm = 0x118
1401a7243:     	leaq	0x80(%rsp), %rbp
1401a724b:     	movq	$-0x2, 0x90(%rbp)
1401a7256:     	movzbl	0x120(%rbp), %r10d
1401a725e:     	movq	(%rdx), %rax
1401a7261:     	movq	(%rax), %rax
1401a7264:     	movb	%r10b, 0x8e(%rbp)
1401a726b:     	cmpl	$0x0, 0x1c0(%r9)
1401a7273:     	movq	0x8(%rdx), %rdi
1401a7277:     	setne	%r11b
1401a727b:     	cmpq	$-0x1, (%r9)
1401a727f:     	movq	0x10(%rdx), %r15
1401a7283:     	setne	%r14b
1401a7287:     	movq	%r15, %rsi
1401a728a:     	subq	%rdi, %rsi
1401a728d:     	setb	%dl
1401a7290:     	cmpq	$0x401, %rsi            # imm = 0x401
1401a7297:     	setae	%bl
1401a729a:     	orb	%dl, %bl
1401a729c:     	je	0x1401a72ae <.text+0x1a62ae>
1401a729e:     	movb	$0xa, (%rcx)
1401a72a1:     	movq	$0xb, 0x8(%rcx)
1401a72a9:     	jmp	0x1401a741b <.text+0x1a641b>
1401a72ae:     	cmpq	$-0x1, 0x230(%r8)
1401a72b6:     	je	0x1401a7413 <.text+0x1a6413>
1401a72bc:     	cmpq	0x258(%r8), %rax
1401a72c3:     	jae	0x1401a7413 <.text+0x1a6413>
1401a72c9:     	movq	0x108(%rbp), %rdx
1401a72d0:     	cmpq	0x88(%r8), %rdx
1401a72d7:     	jae	0x1401a7413 <.text+0x1a6413>
1401a72dd:     	movq	0x250(%r8), %rdx
1401a72e4:     	movb	$0x1, %bl
1401a72e6:     	cmpb	$0x1, (%rdx,%rax)
1401a72ea:     	jne	0x1401a7415 <.text+0x1a6415>
1401a72f0:     	cmpq	0x240(%r8), %rax
1401a72f7:     	jae	0x1401a7415 <.text+0x1a6415>
1401a72fd:     	movq	0x238(%r8), %r12
1401a7304:     	imulq	$0x2d0, %rax, %rax      # imm = 0x2D0
1401a730b:     	movq	0x2c0(%r12,%rax), %rdx
1401a7313:     	movq	0x2c8(%r12,%rax), %r13
1401a731b:     	movq	%r13, 0x78(%rbp)
1401a731f:     	cmpq	%rdx, %r13
1401a7322:     	ja	0x1401a7558 <.text+0x1a6558>
1401a7328:     	movq	0x80(%r8), %r13
1401a732f:     	movq	0x108(%rbp), %rdx
1401a7336:     	cmpb	$0x1, (%r13,%rdx)
1401a733c:     	jne	0x1401a7415 <.text+0x1a6415>
1401a7342:     	cmpq	0xa0(%r8), %rdx
1401a7349:     	jae	0x1401a7413 <.text+0x1a6413>
1401a734f:     	movq	0x98(%r8), %r13
1401a7356:     	movb	$0x3, %bl
1401a7358:     	cmpb	$0x0, (%r13,%rdx)
1401a735e:     	jne	0x1401a7415 <.text+0x1a6415>
1401a7364:     	addq	%rax, %r12
1401a7367:     	movq	0x2b8(%r12), %rdx
1401a736f:     	movq	0x108(%rbp), %rax
1401a7376:     	addq	%rax, %r13
1401a7379:     	movb	$0x1, (%r13)
1401a737e:     	cmpq	0x70(%r8), %rax
1401a7382:     	jae	0x1401a7413 <.text+0x1a6413>
1401a7388:     	movq	0x68(%r8), %r8
1401a738c:     	imulq	$0x58, %rax, %r12
1401a7390:     	movq	0x8(%r8,%r12), %rax
1401a7395:     	movq	0x10(%r8,%r12), %rbx
1401a739a:     	addq	%r12, %r8
1401a739d:     	addq	$0x30, %r8
1401a73a1:     	movb	%bl, 0x8f(%rbp)
1401a73a7:     	movq	%rbx, %r12
1401a73aa:     	shrq	$0x8, %r12
1401a73ae:     	movq	%r13, 0x80(%rbp)
1401a73b5:     	movq	%rbx, %r13
1401a73b8:     	shrq	$0x38, %r13
1401a73bc:     	movb	%r13b, 0x27(%rbp)
1401a73c0:     	movq	0x80(%rbp), %r13
1401a73c7:     	shrq	$0x28, %rbx
1401a73cb:     	movw	%bx, 0x25(%rbp)
1401a73cf:     	movl	%r12d, 0x21(%rbp)
1401a73d3:     	movq	%r8, %r12
1401a73d6:     	movq	%r8, 0x28(%rbp)
1401a73da:     	movq	%r13, 0x30(%rbp)
1401a73de:     	movq	0x108(%rbp), %r8
1401a73e5:     	movq	%r8, 0x38(%rbp)
1401a73e9:     	movq	%rax, 0x40(%rbp)
1401a73ed:     	movq	%rax, 0x18(%rbp)
1401a73f1:     	movzbl	0x8f(%rbp), %eax
1401a73f8:     	movb	%al, 0x20(%rbp)
1401a73fb:     	cmpq	0x78(%rbp), %r15
1401a73ff:     	jbe	0x1401a742f <.text+0x1a642f>
1401a7401:     	movb	$0xa, (%rcx)
1401a7404:     	movq	$0xb, 0x8(%rcx)
1401a740c:     	movb	$0x0, (%r13)
1401a7411:     	jmp	0x1401a741b <.text+0x1a641b>
1401a7413:     	xorl	%ebx, %ebx
1401a7415:     	movb	$0x7, (%rcx)
1401a7418:     	movb	%bl, 0x1(%rcx)
1401a741b:     	addq	$0x118, %rsp            # imm = 0x118
1401a7422:     	popq	%rbx
1401a7423:     	popq	%rdi
1401a7424:     	popq	%rsi
1401a7425:     	popq	%r12
1401a7427:     	popq	%r13
1401a7429:     	popq	%r14
1401a742b:     	popq	%r15
1401a742d:     	popq	%rbp
1401a742e:     	retq
1401a742f:     	movq	%rdx, %rax
1401a7432:     	movq	0x118(%rbp), %rdx
1401a7439:     	movq	0x110(%rbp), %r15
1401a7440:     	movq	0x100(%rbp), %r13
1401a7447:     	orb	%r14b, %r11b
1401a744a:     	addq	%rdi, %rax
1401a744d:     	movzbl	0x2c(%rdx), %r8d
1401a7452:     	movzbl	0x22(%rdx), %ebx
1401a7456:     	movzwl	0x20(%rdx), %edi
1401a745a:     	movzbl	0x2b(%rdx), %r14d
1401a745f:     	movb	%r14b, 0x13(%rbp)
1401a7463:     	movq	0x23(%rdx), %r14
1401a7467:     	movq	%r14, 0xb(%rbp)
1401a746b:     	movups	(%rdx), %xmm0
1401a746e:     	movups	%xmm0, -0x18(%rbp)
1401a7472:     	movq	%rax, -0x8(%rbp)
1401a7476:     	movq	%rsi, (%rbp)
1401a747a:     	movw	%di, 0x8(%rbp)
1401a747e:     	movb	%bl, 0xa(%rbp)
1401a7481:     	movb	%r8b, 0x14(%rbp)
1401a7485:     	movq	0x20(%rbp), %rsi
1401a7489:     	movq	%rsi, %r8
1401a748c:     	testb	%r11b, %r11b
1401a748f:     	je	0x1401a74b8 <.text+0x1a64b8>
1401a7491:     	cmpq	$0x5c0, %rsi            # imm = 0x5C0
1401a7498:     	movl	$0x5c0, %r8d            # imm = 0x5C0
1401a749e:     	cmovbq	%rsi, %r8
1401a74a2:     	movq	(%r12), %rdx
1401a74a6:     	cmpq	%rsi, %rdx
1401a74a9:     	ja	0x1401a7572 <.text+0x1a6572>
1401a74af:     	testq	%rdx, %rdx
1401a74b2:     	jne	0x1401a7586 <.text+0x1a6586>
1401a74b8:     	movq	%rcx, %rdi
1401a74bb:     	movl	0x14(%r13), %eax
1401a74bf:     	movq	%r8, 0x40(%rsp)
1401a74c4:     	movq	0x40(%rbp), %rcx
1401a74c8:     	movq	%rcx, 0x38(%rsp)
1401a74cd:     	movb	%r10b, 0x30(%rsp)
1401a74d2:     	leaq	-0x18(%rbp), %rcx
1401a74d6:     	movq	%rcx, 0x28(%rsp)
1401a74db:     	movq	%r15, 0x20(%rsp)
1401a74e0:     	leaq	0xc9669(%rip), %r8      # 0x140270b50
1401a74e7:     	leaq	0x48(%rbp), %rcx
1401a74eb:     	movq	%r9, %rdx
1401a74ee:     	movl	%eax, %r9d
1401a74f1:     	callq	0x1401020a0 <.text+0x1010a0>
1401a74f6:     	nop
1401a74f7:     	movzbl	0x48(%rbp), %eax
1401a74fb:     	cmpb	$-0x1, %al
1401a74fd:     	je	0x1401a752c <.text+0x1a652c>
1401a74ff:     	movl	0x49(%rbp), %ecx
1401a7502:     	movl	0x4c(%rbp), %edx
1401a7505:     	movl	%edx, 0x4(%rdi)
1401a7508:     	movl	%ecx, 0x1(%rdi)
1401a750b:     	movq	0x50(%rbp), %rcx
1401a750f:     	movups	0x58(%rbp), %xmm0
1401a7513:     	movups	%xmm0, 0x10(%rdi)
1401a7517:     	movb	%al, (%rdi)
1401a7519:     	movq	%rcx, 0x8(%rdi)
1401a751d:     	movq	0x80(%rbp), %rax
1401a7524:     	movb	$0x0, (%rax)
1401a7527:     	jmp	0x1401a741b <.text+0x1a641b>
1401a752c:     	movq	0x50(%rbp), %rax
1401a7530:     	cmpq	%rsi, %rax
1401a7533:     	movq	0x80(%rbp), %rcx
1401a753a:     	jbe	0x1401a7549 <.text+0x1a6549>
1401a753c:     	movw	$0x207, (%rdi)          # imm = 0x207
1401a7541:     	movb	$0x0, (%rcx)
1401a7544:     	jmp	0x1401a741b <.text+0x1a641b>
1401a7549:     	movq	%rax, (%r12)
1401a754d:     	movb	$0x0, (%rcx)
1401a7550:     	movb	$-0x1, (%rdi)
1401a7553:     	jmp	0x1401a741b <.text+0x1a641b>
1401a7558:     	movq	%rdx, %r13
1401a755b:     	leaq	0xcc88e(%rip), %r9      # 0x140273df0
1401a7562:     	xorl	%ecx, %ecx
1401a7564:     	movq	0x78(%rbp), %rdx
1401a7568:     	movq	%r13, %r8
1401a756b:     	callq	0x14024f4b0 <.text+0x24e4b0>
1401a7570:     	ud2
1401a7572:     	leaq	0xbfc2f(%rip), %r9      # 0x1402671a8
1401a7579:     	xorl	%ecx, %ecx
1401a757b:     	movq	%rsi, %r8
1401a757e:     	callq	0x14024f4b0 <.text+0x24e4b0>
1401a7583:     	nop
1401a7584:     	ud2
1401a7586:     	movq	%rcx, %rsi
1401a7589:     	movq	%r9, 0x48(%rbp)
1401a758d:     	leaq	0xc95bc(%rip), %rax     # 0x140270b50
1401a7594:     	movq	%rax, 0x50(%rbp)
1401a7598:     	movq	%r13, 0x58(%rbp)
1401a759c:     	movq	%r15, 0x60(%rbp)
1401a75a0:     	leaq	-0x18(%rbp), %rax
1401a75a4:     	movq	%rax, 0x68(%rbp)
1401a75a8:     	leaq	0x8e(%rbp), %rax
1401a75af:     	movq	%rax, 0x70(%rbp)
1401a75b3:     	leaq	-0x38(%rbp), %rcx
1401a75b7:     	leaq	0x18(%rbp), %rdx
1401a75bb:     	leaq	0x48(%rbp), %r9
1401a75bf:     	callq	0x140264110 <.text+0x263110>
1401a75c4:     	nop
1401a75c5:     	cmpb	$-0x1, -0x38(%rbp)
1401a75c9:     	je	0x1401a75df <.text+0x1a65df>
1401a75cb:     	movups	-0x38(%rbp), %xmm0
1401a75cf:     	movups	-0x28(%rbp), %xmm1
1401a75d3:     	movups	%xmm1, 0x10(%rsi)
1401a75d7:     	movups	%xmm0, (%rsi)
1401a75da:     	jmp	0x1401a751d <.text+0x1a651d>
1401a75df:     	movq	%rsi, %rdi
1401a75e2:     	movq	0x80(%rbp), %rcx
1401a75e9:     	jmp	0x1401a754d <.text+0x1a654d>
1401a75ee:     	nop
1401a75f0:     	movq	%rdx, 0x10(%rsp)
1401a75f5:     	pushq	%rbp
1401a75f6:     	pushq	%r15
1401a75f8:     	pushq	%r14
1401a75fa:     	pushq	%r13
1401a75fc:     	pushq	%r12
1401a75fe:     	pushq	%rsi
1401a75ff:     	pushq	%rdi
1401a7600:     	pushq	%rbx
1401a7601:     	subq	$0x48, %rsp
1401a7605:     	leaq	0x80(%rdx), %rbp
1401a760c:     	movq	0x80(%rbp), %rax
1401a7613:     	movb	$0x0, (%rax)
1401a7616:     	addq	$0x48, %rsp
1401a761a:     	popq	%rbx
1401a761b:     	popq	%rdi
1401a761c:     	popq	%rsi
1401a761d:     	popq	%r12
1401a761f:     	popq	%r13
1401a7621:     	popq	%r14
1401a7623:     	popq	%r15
1401a7625:     	popq	%rbp
1401a7626:     	retq


D:\CoapticCurrent\packet-body-access-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401a6e40:     	pushq	%rbp
1401a6e41:     	pushq	%r15
1401a6e43:     	pushq	%r14
1401a6e45:     	pushq	%r13
1401a6e47:     	pushq	%r12
1401a6e49:     	pushq	%rsi
1401a6e4a:     	pushq	%rdi
1401a6e4b:     	pushq	%rbx
1401a6e4c:     	subq	$0x128, %rsp            # imm = 0x128
1401a6e53:     	leaq	0x80(%rsp), %rbp
1401a6e5b:     	movq	$-0x2, 0xa0(%rbp)
1401a6e66:     	movq	%r9, %rdi
1401a6e69:     	movq	%r8, %r14
1401a6e6c:     	movq	%rcx, %rsi
1401a6e6f:     	movzbl	0x138(%rbp), %r15d
1401a6e77:     	movq	0x110(%rbp), %r8
1401a6e7e:     	movq	(%rdx), %rax
1401a6e81:     	movq	0x8(%rdx), %r12
1401a6e85:     	movq	(%rax), %rbx
1401a6e88:     	movq	0x10(%rdx), %r13
1401a6e8c:     	movb	%r15b, 0x9f(%rbp)
1401a6e93:     	movq	%r9, %rcx
1401a6e96:     	callq	*0x50(%r8)
1401a6e9a:     	movq	%r13, %rcx
1401a6e9d:     	subq	%r12, %rcx
1401a6ea0:     	setb	%dl
1401a6ea3:     	cmpq	$0x401, %rcx            # imm = 0x401
1401a6eaa:     	setae	%r8b
1401a6eae:     	orb	%dl, %r8b
1401a6eb1:     	je	0x1401a6ec3 <.text+0x1a5ec3>
1401a6eb3:     	movb	$0xa, (%rsi)
1401a6eb6:     	movq	$0xb, 0x8(%rsi)
1401a6ebe:     	jmp	0x1401a7018 <.text+0x1a6018>
1401a6ec3:     	cmpq	$-0x1, 0x230(%r14)
1401a6ecb:     	je	0x1401a700e <.text+0x1a600e>
1401a6ed1:     	cmpq	0x258(%r14), %rbx
1401a6ed8:     	jae	0x1401a700e <.text+0x1a600e>
1401a6ede:     	movq	0x120(%rbp), %r9
1401a6ee5:     	cmpq	0x88(%r14), %r9
1401a6eec:     	jae	0x1401a700e <.text+0x1a600e>
1401a6ef2:     	movq	0x250(%r14), %rdx
1401a6ef9:     	movb	$0x1, %r10b
1401a6efc:     	cmpb	$0x1, (%rdx,%rbx)
1401a6f00:     	jne	0x1401a7011 <.text+0x1a6011>
1401a6f06:     	cmpq	0x240(%r14), %rbx
1401a6f0d:     	jae	0x1401a7011 <.text+0x1a6011>
1401a6f13:     	movq	0x238(%r14), %r11
1401a6f1a:     	imulq	$0x2d0, %rbx, %rbx      # imm = 0x2D0
1401a6f21:     	movq	0x2c0(%r11,%rbx), %r8
1401a6f29:     	movq	0x2c8(%r11,%rbx), %rdx
1401a6f31:     	cmpq	%r8, %rdx
1401a6f34:     	ja	0x1401a715d <.text+0x1a615d>
1401a6f3a:     	movq	0x80(%r14), %r8
1401a6f41:     	cmpb	$0x1, (%r8,%r9)
1401a6f46:     	jne	0x1401a7011 <.text+0x1a6011>
1401a6f4c:     	cmpq	0xa0(%r14), %r9
1401a6f53:     	jae	0x1401a700e <.text+0x1a600e>
1401a6f59:     	movq	0x98(%r14), %r8
1401a6f60:     	movb	$0x3, %r10b
1401a6f63:     	cmpb	$0x0, (%r8,%r9)
1401a6f68:     	jne	0x1401a7011 <.text+0x1a6011>
1401a6f6e:     	addq	%rbx, %r11
1401a6f71:     	movq	0x2b8(%r11), %r10
1401a6f78:     	addq	%r9, %r8
1401a6f7b:     	movb	$0x1, (%r8)
1401a6f7f:     	cmpq	0x70(%r14), %r9
1401a6f83:     	jae	0x1401a700e <.text+0x1a600e>
1401a6f89:     	movq	%r10, 0x50(%rbp)
1401a6f8d:     	movq	0x68(%r14), %r11
1401a6f91:     	imulq	$0x58, %r9, %r10
1401a6f95:     	movq	0x8(%r11,%r10), %rbx
1401a6f9a:     	movq	%rbx, 0x48(%rbp)
1401a6f9e:     	movq	0x10(%r11,%r10), %rbx
1401a6fa3:     	addq	%r10, %r11
1401a6fa6:     	addq	$0x30, %r11
1401a6faa:     	movb	%bl, 0x90(%rbp)
1401a6fb0:     	movq	%rbx, %r10
1401a6fb3:     	shrq	$0x8, %r10
1401a6fb7:     	movq	%rbx, %r14
1401a6fba:     	shrq	$0x38, %r14
1401a6fbe:     	movb	%r14b, 0x2f(%rbp)
1401a6fc2:     	shrq	$0x28, %rbx
1401a6fc6:     	movw	%bx, 0x2d(%rbp)
1401a6fca:     	movl	%r10d, 0x29(%rbp)
1401a6fce:     	movq	%r11, 0x88(%rbp)
1401a6fd5:     	movq	%r11, 0x30(%rbp)
1401a6fd9:     	movq	%r8, 0x38(%rbp)
1401a6fdd:     	movq	%r9, 0x40(%rbp)
1401a6fe1:     	movq	0x48(%rbp), %r9
1401a6fe5:     	movq	%r9, %r11
1401a6fe8:     	movq	%r9, 0x20(%rbp)
1401a6fec:     	movzbl	0x90(%rbp), %r9d
1401a6ff4:     	movb	%r9b, 0x28(%rbp)
1401a6ff8:     	cmpq	%rdx, %r13
1401a6ffb:     	jbe	0x1401a702c <.text+0x1a602c>
1401a6ffd:     	movb	$0xa, (%rsi)
1401a7000:     	movq	$0xb, 0x8(%rsi)
1401a7008:     	movb	$0x0, (%r8)
1401a700c:     	jmp	0x1401a7018 <.text+0x1a6018>
1401a700e:     	xorl	%r10d, %r10d
1401a7011:     	movb	$0x7, (%rsi)
1401a7014:     	movb	%r10b, 0x1(%rsi)
1401a7018:     	addq	$0x128, %rsp            # imm = 0x128
1401a701f:     	popq	%rbx
1401a7020:     	popq	%rdi
1401a7021:     	popq	%rsi
1401a7022:     	popq	%r12
1401a7024:     	popq	%r13
1401a7026:     	popq	%r14
1401a7028:     	popq	%r15
1401a702a:     	popq	%rbp
1401a702b:     	retq
1401a702c:     	movq	%r8, 0x90(%rbp)
1401a7033:     	movq	0x130(%rbp), %rdx
1401a703a:     	movq	0x128(%rbp), %r13
1401a7041:     	movq	0x118(%rbp), %r9
1401a7048:     	movq	0x50(%rbp), %r8
1401a704c:     	addq	%r12, %r8
1401a704f:     	movzbl	0x2c(%rdx), %r10d
1401a7054:     	movzbl	0x22(%rdx), %ebx
1401a7058:     	movzwl	0x20(%rdx), %r14d
1401a705d:     	movzbl	0x2b(%rdx), %r12d
1401a7062:     	movb	%r12b, 0x1b(%rbp)
1401a7066:     	movq	0x23(%rdx), %r12
1401a706a:     	movq	%r12, 0x13(%rbp)
1401a706e:     	movups	(%rdx), %xmm0
1401a7071:     	movups	%xmm0, -0x10(%rbp)
1401a7075:     	movq	%r8, (%rbp)
1401a7079:     	movq	%rcx, 0x8(%rbp)
1401a707d:     	movw	%r14w, 0x10(%rbp)
1401a7082:     	movb	%bl, 0x12(%rbp)
1401a7085:     	movb	%r10b, 0x1c(%rbp)
1401a7089:     	movq	0x28(%rbp), %r14
1401a708d:     	movq	%r14, %r8
1401a7090:     	testb	%al, %al
1401a7092:     	je	0x1401a70c1 <.text+0x1a60c1>
1401a7094:     	cmpq	$0x5c0, %r14            # imm = 0x5C0
1401a709b:     	movl	$0x5c0, %r8d            # imm = 0x5C0
1401a70a1:     	cmovbq	%r14, %r8
1401a70a5:     	movq	0x88(%rbp), %rax
1401a70ac:     	movq	(%rax), %rdx
1401a70af:     	cmpq	%r14, %rdx
1401a70b2:     	ja	0x1401a716d <.text+0x1a616d>
1401a70b8:     	testq	%rdx, %rdx
1401a70bb:     	jne	0x1401a7181 <.text+0x1a6181>
1401a70c1:     	movl	0x14(%r9), %r9d
1401a70c5:     	movq	%r8, 0x40(%rsp)
1401a70ca:     	movq	%r11, 0x38(%rsp)
1401a70cf:     	movb	%r15b, 0x30(%rsp)
1401a70d4:     	leaq	-0x10(%rbp), %rax
1401a70d8:     	movq	%rax, 0x28(%rsp)
1401a70dd:     	movq	%r13, 0x20(%rsp)
1401a70e2:     	leaq	0x58(%rbp), %rcx
1401a70e6:     	movq	%rdi, %rdx
1401a70e9:     	movq	0x110(%rbp), %r8
1401a70f0:     	callq	0x1401020a0 <.text+0x1010a0>
1401a70f5:     	nop
1401a70f6:     	movzbl	0x58(%rbp), %eax
1401a70fa:     	cmpb	$-0x1, %al
1401a70fc:     	je	0x1401a712b <.text+0x1a612b>
1401a70fe:     	movl	0x59(%rbp), %ecx
1401a7101:     	movl	0x5c(%rbp), %edx
1401a7104:     	movl	%edx, 0x4(%rsi)
1401a7107:     	movl	%ecx, 0x1(%rsi)
1401a710a:     	movq	0x60(%rbp), %rcx
1401a710e:     	movups	0x68(%rbp), %xmm0
1401a7112:     	movups	%xmm0, 0x10(%rsi)
1401a7116:     	movb	%al, (%rsi)
1401a7118:     	movq	%rcx, 0x8(%rsi)
1401a711c:     	movq	0x90(%rbp), %rax
1401a7123:     	movb	$0x0, (%rax)
1401a7126:     	jmp	0x1401a7018 <.text+0x1a6018>
1401a712b:     	movq	0x60(%rbp), %rax
1401a712f:     	cmpq	%r14, %rax
1401a7132:     	movq	0x90(%rbp), %rcx
1401a7139:     	jbe	0x1401a7148 <.text+0x1a6148>
1401a713b:     	movw	$0x207, (%rsi)          # imm = 0x207
1401a7140:     	movb	$0x0, (%rcx)
1401a7143:     	jmp	0x1401a7018 <.text+0x1a6018>
1401a7148:     	movq	0x88(%rbp), %rdx
1401a714f:     	movq	%rax, (%rdx)
1401a7152:     	movb	$0x0, (%rcx)
1401a7155:     	movb	$-0x1, (%rsi)
1401a7158:     	jmp	0x1401a7018 <.text+0x1a6018>
1401a715d:     	leaq	0xccc8c(%rip), %r9      # 0x140273df0
1401a7164:     	xorl	%ecx, %ecx
1401a7166:     	callq	0x14024f4b0 <.text+0x24e4b0>
1401a716b:     	ud2
1401a716d:     	leaq	0xc0034(%rip), %r9      # 0x1402671a8
1401a7174:     	xorl	%ecx, %ecx
1401a7176:     	movq	%r14, %r8
1401a7179:     	callq	0x14024f4b0 <.text+0x24e4b0>
1401a717e:     	nop
1401a717f:     	ud2
1401a7181:     	movq	%rdi, 0x58(%rbp)
1401a7185:     	movq	0x110(%rbp), %rax
1401a718c:     	movq	%rax, 0x60(%rbp)
1401a7190:     	movq	%r9, 0x68(%rbp)
1401a7194:     	movq	%r13, 0x70(%rbp)
1401a7198:     	leaq	-0x10(%rbp), %rax
1401a719c:     	movq	%rax, 0x78(%rbp)
1401a71a0:     	leaq	0x9f(%rbp), %rax
1401a71a7:     	movq	%rax, 0x80(%rbp)
1401a71ae:     	leaq	-0x30(%rbp), %rcx
1401a71b2:     	leaq	0x20(%rbp), %rdx
1401a71b6:     	leaq	0x58(%rbp), %r9
1401a71ba:     	callq	0x140264110 <.text+0x263110>
1401a71bf:     	nop
1401a71c0:     	cmpb	$-0x1, -0x30(%rbp)
1401a71c4:     	je	0x1401a71da <.text+0x1a61da>
1401a71c6:     	movups	-0x30(%rbp), %xmm0
1401a71ca:     	movups	-0x20(%rbp), %xmm1
1401a71ce:     	movups	%xmm1, 0x10(%rsi)
1401a71d2:     	movups	%xmm0, (%rsi)
1401a71d5:     	jmp	0x1401a711c <.text+0x1a611c>
1401a71da:     	movq	0x90(%rbp), %rcx
1401a71e1:     	jmp	0x1401a7152 <.text+0x1a6152>
1401a71e6:     	nopw	%cs:(%rax,%rax)
1401a71f0:     	movq	%rdx, 0x10(%rsp)
1401a71f5:     	pushq	%rbp
1401a71f6:     	pushq	%r15
1401a71f8:     	pushq	%r14
1401a71fa:     	pushq	%r13
1401a71fc:     	pushq	%r12
1401a71fe:     	pushq	%rsi
1401a71ff:     	pushq	%rdi
1401a7200:     	pushq	%rbx
1401a7201:     	subq	$0x48, %rsp
1401a7205:     	leaq	0x80(%rdx), %rbp
1401a720c:     	movq	0x90(%rbp), %rax
1401a7213:     	movb	$0x0, (%rax)
1401a7216:     	addq	$0x48, %rsp
1401a721a:     	popq	%rbx
1401a721b:     	popq	%rdi
1401a721c:     	popq	%rsi
1401a721d:     	popq	%r12
1401a721f:     	popq	%r13
1401a7221:     	popq	%r14
1401a7223:     	popq	%r15
1401a7225:     	popq	%rbp
1401a7226:     	retq

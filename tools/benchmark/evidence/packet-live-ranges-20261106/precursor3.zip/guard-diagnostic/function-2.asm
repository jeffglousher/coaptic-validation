
D:\CoapticCurrent\packet-body-access-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401e5de0:     	pushq	%rbp
1401e5de1:     	movq	%rsp, %rbp
1401e5de4:     	movq	%rcx, %rax
1401e5de7:     	movl	$0x0, (%rcx)
1401e5ded:     	movl	$0x0, 0x8(%rcx)
1401e5df4:     	movw	$0x1, 0x10(%rcx)
1401e5dfa:     	leaq	0x8504f(%rip), %rcx     # 0x14026ae50
1401e5e01:     	movq	%rcx, 0x18(%rax)
1401e5e05:     	movq	$0x400, 0x20(%rax)      # imm = 0x400
1401e5e0d:     	movb	$-0x1, 0xb5(%rax)
1401e5e14:     	movq	$0x1, 0xc0(%rax)
1401e5e1f:     	movq	$0x0, 0xc8(%rax)
1401e5e2a:     	movq	$0x1, 0xd0(%rax)
1401e5e35:     	movq	$0x0, 0xd8(%rax)
1401e5e40:     	movq	$0x1, 0xe0(%rax)
1401e5e4b:     	movq	$0x0, 0xe8(%rax)
1401e5e56:     	movq	$0x1, 0xf0(%rax)
1401e5e61:     	movq	$0x0, 0xf8(%rax)
1401e5e6c:     	movq	$0x1, 0x100(%rax)
1401e5e77:     	movq	$0x0, 0x108(%rax)
1401e5e82:     	movq	$0x1, 0x110(%rax)
1401e5e8d:     	movq	$0x0, 0x118(%rax)
1401e5e98:     	movq	$0x1, 0x120(%rax)
1401e5ea3:     	movq	$0x0, 0x128(%rax)
1401e5eae:     	movq	$0x1, 0x130(%rax)
1401e5eb9:     	movq	$0x0, 0x138(%rax)
1401e5ec4:     	movq	$0x1, 0x140(%rax)
1401e5ecf:     	movq	$0x0, 0x148(%rax)
1401e5eda:     	movq	$0x1, 0x150(%rax)
1401e5ee5:     	movq	$0x0, 0x158(%rax)
1401e5ef0:     	movq	$0x1, 0x160(%rax)
1401e5efb:     	movq	$0x0, 0x168(%rax)
1401e5f06:     	movq	$0x1, 0x170(%rax)
1401e5f11:     	movq	$0x0, 0x178(%rax)
1401e5f1c:     	movq	$0x1, 0x180(%rax)
1401e5f27:     	movq	$0x0, 0x188(%rax)
1401e5f32:     	movq	$0x1, 0x190(%rax)
1401e5f3d:     	movq	$0x0, 0x198(%rax)
1401e5f48:     	movq	$0x1, 0x1a0(%rax)
1401e5f53:     	movq	$0x0, 0x1a8(%rax)
1401e5f5e:     	movq	$0x1, 0x1b0(%rax)
1401e5f69:     	movq	$0x0, 0x1b8(%rax)
1401e5f74:     	movabsq	$0x65727574786966, %rcx # imm = 0x65727574786966
1401e5f7e:     	movq	%rcx, 0x1c0(%rax)
1401e5f85:     	movq	$0x0, 0x1c8(%rax)
1401e5f90:     	movq	$0x400, 0x1d8(%rax)     # imm = 0x400
1401e5f9b:     	movl	$0x2a0001, 0x1e0(%rax)  # imm = 0x2A0001
1401e5fa5:     	movb	$0x0, 0x1e4(%rax)
1401e5fac:     	movabsq	$0x745ff000000, %rcx    # imm = 0x745FF000000
1401e5fb6:     	movq	%rcx, 0x20e(%rax)
1401e5fbd:     	popq	%rbp
1401e5fbe:     	retq


D:\CoapticCurrent\packet-body-access-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401e6030:     	pushq	%rbp
1401e6031:     	movq	%rsp, %rbp
1401e6034:     	movq	%rcx, %rax
1401e6037:     	movl	$0x0, (%rcx)
1401e603d:     	movl	$0x0, 0x8(%rcx)
1401e6044:     	movw	$0x1, 0x10(%rcx)
1401e604a:     	leaq	0x84dff(%rip), %rcx     # 0x14026ae50
1401e6051:     	movq	%rcx, 0x18(%rax)
1401e6055:     	movq	$0x4000, 0x20(%rax)     # imm = 0x4000
1401e605d:     	movb	$-0x1, 0xb5(%rax)
1401e6064:     	movq	$0x1, 0xc0(%rax)
1401e606f:     	movq	$0x0, 0xc8(%rax)
1401e607a:     	movq	$0x1, 0xd0(%rax)
1401e6085:     	movq	$0x0, 0xd8(%rax)
1401e6090:     	movq	$0x1, 0xe0(%rax)
1401e609b:     	movq	$0x0, 0xe8(%rax)
1401e60a6:     	movq	$0x1, 0xf0(%rax)
1401e60b1:     	movq	$0x0, 0xf8(%rax)
1401e60bc:     	movq	$0x1, 0x100(%rax)
1401e60c7:     	movq	$0x0, 0x108(%rax)
1401e60d2:     	movq	$0x1, 0x110(%rax)
1401e60dd:     	movq	$0x0, 0x118(%rax)
1401e60e8:     	movq	$0x1, 0x120(%rax)
1401e60f3:     	movq	$0x0, 0x128(%rax)
1401e60fe:     	movq	$0x1, 0x130(%rax)
1401e6109:     	movq	$0x0, 0x138(%rax)
1401e6114:     	movq	$0x1, 0x140(%rax)
1401e611f:     	movq	$0x0, 0x148(%rax)
1401e612a:     	movq	$0x1, 0x150(%rax)
1401e6135:     	movq	$0x0, 0x158(%rax)
1401e6140:     	movq	$0x1, 0x160(%rax)
1401e614b:     	movq	$0x0, 0x168(%rax)
1401e6156:     	movq	$0x1, 0x170(%rax)
1401e6161:     	movq	$0x0, 0x178(%rax)
1401e616c:     	movq	$0x1, 0x180(%rax)
1401e6177:     	movq	$0x0, 0x188(%rax)
1401e6182:     	movq	$0x1, 0x190(%rax)
1401e618d:     	movq	$0x0, 0x198(%rax)
1401e6198:     	movq	$0x1, 0x1a0(%rax)
1401e61a3:     	movq	$0x0, 0x1a8(%rax)
1401e61ae:     	movq	$0x1, 0x1b0(%rax)
1401e61b9:     	movq	$0x0, 0x1b8(%rax)
1401e61c4:     	movabsq	$0x65727574786966, %rcx # imm = 0x65727574786966
1401e61ce:     	movq	%rcx, 0x1c0(%rax)
1401e61d5:     	movq	$0x0, 0x1c8(%rax)
1401e61e0:     	movq	$0x4000, 0x1d8(%rax)    # imm = 0x4000
1401e61eb:     	movl	$0x2a0001, 0x1e0(%rax)  # imm = 0x2A0001
1401e61f5:     	movb	$0x0, 0x1e4(%rax)
1401e61fc:     	movabsq	$0x745ff000000, %rcx    # imm = 0x745FF000000
1401e6206:     	movq	%rcx, 0x20e(%rax)
1401e620d:     	popq	%rbp
1401e620e:     	retq

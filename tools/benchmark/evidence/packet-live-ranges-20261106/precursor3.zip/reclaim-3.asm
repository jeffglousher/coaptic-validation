
D:\CoapticCurrent\packet-body-access-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140099180:     	pushq	%rbp
140099181:     	pushq	%r15
140099183:     	pushq	%r14
140099185:     	pushq	%r13
140099187:     	pushq	%r12
140099189:     	pushq	%rsi
14009918a:     	pushq	%rdi
14009918b:     	pushq	%rbx
14009918c:     	subq	$0x308, %rsp            # imm = 0x308
140099193:     	leaq	0x80(%rsp), %rbp
14009919b:     	movaps	%xmm7, 0x270(%rbp)
1400991a2:     	movaps	%xmm6, 0x260(%rbp)
1400991a9:     	leaq	0x5000(%rcx), %rax
1400991b0:     	leaq	0x30(%rcx), %r8
1400991b4:     	xorl	%r9d, %r9d
1400991b7:     	xorl	%esi, %esi
1400991b9:     	leaq	(%rsi,%rsi,4), %r11
1400991bd:     	shlq	$0x6, %r11
1400991c1:     	addq	%r8, %r11
1400991c4:     	movq	%rsi, %r10
1400991c7:     	jmp	0x1400991e4 <.text+0x981e4>
1400991c9:     	nopl	(%rax)
1400991d0:     	incq	%r10
1400991d3:     	addq	$0x140, %r11            # imm = 0x140
1400991da:     	cmpq	$0x40, %r10
1400991de:     	je	0x14009927e <.text+0x9827e>
1400991e4:     	cmpb	$0x1, 0x5000(%rcx,%r10)
1400991ed:     	jne	0x1400991d0 <.text+0x981d0>
1400991ef:     	movq	-0x30(%r11), %rdi
1400991f3:     	cmpq	$0x2, %rdi
1400991f7:     	je	0x1400991d0 <.text+0x981d0>
1400991f9:     	movq	(%r11), %rsi
1400991fc:     	cmpl	$0x1, %edi
1400991ff:     	setne	%bl
140099202:     	testq	%rsi, %rsi
140099205:     	sete	%dil
140099209:     	orb	%bl, %dil
14009920c:     	cmpb	$0x1, %dil
140099210:     	je	0x1400991d0 <.text+0x981d0>
140099212:     	movq	0x250(%rbp), %rdi
140099219:     	cmpq	%rdi, %rsi
14009921c:     	setae	%bl
14009921f:     	testb	%bl, %r9b
140099222:     	jne	0x140099264 <.text+0x98264>
140099224:     	movd	-0x4(%r11), %xmm6
14009922a:     	movzbl	-0x5(%r11), %edx
14009922f:     	movb	%dl, 0x25f(%rbp)
140099235:     	movzbl	-0x6(%r11), %r15d
14009923a:     	movzwl	-0x8(%r11), %r12d
14009923f:     	movl	-0xc(%r11), %r13d
140099243:     	movl	-0x10(%r11), %r14d
140099247:     	movq	-0x18(%r11), %rdx
14009924b:     	movq	%rdx, 0x248(%rbp)
140099252:     	movq	-0x28(%r11), %rdx
140099256:     	movq	-0x20(%r11), %r9
14009925a:     	movq	%r9, 0x240(%rbp)
140099261:     	movq	%rsi, %rdi
140099264:     	movq	%rdi, 0x250(%rbp)
14009926b:     	leaq	0x1(%r10), %rsi
14009926f:     	movb	$0x1, %r9b
140099272:     	cmpq	$0x3f, %r10
140099276:     	jb	0x1400991b9 <.text+0x981b9>
14009927c:     	jmp	0x140099288 <.text+0x98288>
14009927e:     	testb	$0x1, %r9b
140099282:     	je	0x140099500 <.text+0x98500>
140099288:     	cmpq	$0x1f, %rdx
14009928c:     	ja	0x1400992df <.text+0x982df>
14009928e:     	leaq	0x37740(%rcx), %r8
140099295:     	cmpb	$0x1, (%r8,%rdx)
14009929a:     	jne	0x1400992df <.text+0x982df>
14009929c:     	cmpb	$0x0, 0x37760(%rcx,%rdx)
1400992a4:     	jne	0x1400992df <.text+0x982df>
1400992a6:     	movb	$0x0, 0x37740(%rcx,%rdx)
1400992ae:     	decq	0x37788(%rcx)
1400992b5:     	movq	$0x0, 0x43610(%rcx,%rdx,8)
1400992c1:     	leaq	(%rdx,%rdx,8), %r9
1400992c5:     	leaq	(%r9,%r9,2), %r9
1400992c9:     	addq	%rdx, %r9
1400992cc:     	movb	$0x2, 0x36a(%r8,%r9)
1400992d5:     	leaq	(%rdx,%rdx,2), %rdx
1400992d9:     	movb	$0x2, 0x5d(%r8,%rdx,8)
1400992df:     	movd	%xmm6, %edx
1400992e3:     	movl	$0x2c, %r8d
1400992e9:     	movq	0x240(%rbp), %r11
1400992f0:     	movq	0x248(%rbp), %rsi
1400992f7:     	jmp	0x140099313 <.text+0x98313>
1400992f9:     	nopl	(%rax)
140099300:     	incq	%rax
140099303:     	addq	$0x140, %r8             # imm = 0x140
14009930a:     	cmpq	$0x502c, %r8            # imm = 0x502C
140099311:     	je	0x14009936c <.text+0x9836c>
140099313:     	cmpb	$0x1, (%rax)
140099316:     	jne	0x140099300 <.text+0x98300>
140099318:     	cmpl	$0x2, -0x2c(%rcx,%r8)
14009931e:     	je	0x140099300 <.text+0x98300>
140099320:     	cmpw	%dx, (%rcx,%r8)
140099325:     	jne	0x140099300 <.text+0x98300>
140099327:     	cmpl	%r14d, -0xc(%rcx,%r8)
14009932c:     	jne	0x140099300 <.text+0x98300>
14009932e:     	cmpl	%r13d, -0x8(%rcx,%r8)
140099333:     	jne	0x140099300 <.text+0x98300>
140099335:     	cmpw	%r12w, -0x4(%rcx,%r8)
14009933b:     	jne	0x140099300 <.text+0x98300>
14009933d:     	cmpb	%r15b, -0x2(%rcx,%r8)
140099342:     	jne	0x140099300 <.text+0x98300>
140099344:     	movq	-0x1c(%rcx,%r8), %r9
140099349:     	xorq	%r11, %r9
14009934c:     	movq	-0x14(%rcx,%r8), %r10
140099351:     	xorq	%rsi, %r10
140099354:     	orq	%r9, %r10
140099357:     	jne	0x140099300 <.text+0x98300>
140099359:     	movb	$0x0, (%rax)
14009935c:     	decq	0x5048(%rcx)
140099363:     	movq	$0x2, -0x2c(%rcx,%r8)
14009936c:     	movq	%rcx, %rsi
14009936f:     	xorps	%xmm7, %xmm7
140099372:     	movaps	%xmm7, 0x230(%rbp)
140099379:     	movb	$0x0, 0x212(%rbp)
140099380:     	movw	%dx, 0x210(%rbp)
140099387:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
140099390:     	movq	$0x0, 0x213(%rbp)
14009939b:     	movq	$0x8, 0x1f0(%rbp)
1400993a6:     	movq	$0x0, 0x1f8(%rbp)
1400993b1:     	movq	$0x1, 0x200(%rbp)
1400993bc:     	movq	$0x0, 0x208(%rbp)
1400993c7:     	leaq	0x220(%rbp), %rcx
1400993ce:     	leaq	0x1f0(%rbp), %rdx
1400993d5:     	leaq	0x230(%rbp), %r8
1400993dc:     	movl	$0x10, %r9d
1400993e2:     	callq	0x140110890 <.text+0x10f890>
1400993e7:     	cmpb	$0x0, 0x220(%rbp)
1400993ee:     	jne	0x1400994fc <.text+0x984fc>
1400993f4:     	movq	0x228(%rbp), %rdi
1400993fb:     	movaps	%xmm7, 0xe0(%rbp)
140099402:     	movaps	%xmm7, 0xf0(%rbp)
140099409:     	movaps	%xmm7, 0x100(%rbp)
140099410:     	movaps	%xmm7, 0x110(%rbp)
140099417:     	movaps	%xmm7, 0x120(%rbp)
14009941e:     	movaps	%xmm7, 0x130(%rbp)
140099425:     	movaps	%xmm7, 0x140(%rbp)
14009942c:     	movaps	%xmm7, 0x150(%rbp)
140099433:     	movaps	%xmm7, 0x160(%rbp)
14009943a:     	movaps	%xmm7, 0x170(%rbp)
140099441:     	movaps	%xmm7, 0x180(%rbp)
140099448:     	movaps	%xmm7, 0x190(%rbp)
14009944f:     	movaps	%xmm7, 0x1a0(%rbp)
140099456:     	movaps	%xmm7, 0x1b0(%rbp)
14009945d:     	movaps	%xmm7, 0x1c0(%rbp)
140099464:     	movaps	%xmm7, 0x1d0(%rbp)
14009946b:     	cmpq	$0x11, %rdi
14009946f:     	jae	0x140099524 <.text+0x98524>
140099475:     	leaq	0xe0(%rbp), %rbx
14009947c:     	leaq	0x230(%rbp), %rdx
140099483:     	movq	%rbx, %rcx
140099486:     	movq	%rdi, %r8
140099489:     	callq	0x14024ea60 <.text+0x24da60>
14009948e:     	movw	%di, 0x1e0(%rbp)
140099495:     	movq	$0x0, -0x60(%rbp)
14009949d:     	movq	0x248(%rbp), %rax
1400994a4:     	movq	%rax, -0x48(%rbp)
1400994a8:     	movq	0x240(%rbp), %rax
1400994af:     	movq	%rax, -0x50(%rbp)
1400994b3:     	movl	%r14d, -0x40(%rbp)
1400994b7:     	movl	%r13d, -0x3c(%rbp)
1400994bb:     	movw	%r12w, -0x38(%rbp)
1400994c0:     	movb	%r15b, -0x36(%rbp)
1400994c4:     	movzbl	0x25f(%rbp), %eax
1400994cb:     	movb	%al, -0x35(%rbp)
1400994ce:     	movd	%xmm6, -0x34(%rbp)
1400994d3:     	movq	0x250(%rbp), %rax
1400994da:     	movq	%rax, -0x30(%rbp)
1400994de:     	leaq	-0x28(%rbp), %rcx
1400994e2:     	movl	$0x108, %r8d            # imm = 0x108
1400994e8:     	movq	%rbx, %rdx
1400994eb:     	callq	0x14024ea60 <.text+0x24da60>
1400994f0:     	leaq	-0x60(%rbp), %rdx
1400994f4:     	movq	%rsi, %rcx
1400994f7:     	callq	0x140213c30 <.text+0x212c30>
1400994fc:     	movb	$0x1, %al
1400994fe:     	jmp	0x140099502 <.text+0x98502>
140099500:     	xorl	%eax, %eax
140099502:     	movaps	0x260(%rbp), %xmm6
140099509:     	movaps	0x270(%rbp), %xmm7
140099510:     	addq	$0x308, %rsp            # imm = 0x308
140099517:     	popq	%rbx
140099518:     	popq	%rdi
140099519:     	popq	%rsi
14009951a:     	popq	%r12
14009951c:     	popq	%r13
14009951e:     	popq	%r14
140099520:     	popq	%r15
140099522:     	popq	%rbp
140099523:     	retq
140099524:     	leaq	0x1d760d(%rip), %r9     # 0x140270b38
14009952b:     	movl	$0x10, %r8d
140099531:     	xorl	%ecx, %ecx
140099533:     	movq	%rdi, %rdx
140099536:     	callq	0x14024f4b0 <.text+0x24e4b0>
14009953b:     	ud2

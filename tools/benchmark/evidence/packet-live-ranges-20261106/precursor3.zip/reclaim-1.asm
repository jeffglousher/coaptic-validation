
D:\CoapticCurrent\packet-body-access-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140098a80:     	pushq	%rbp
140098a81:     	pushq	%r15
140098a83:     	pushq	%r14
140098a85:     	pushq	%r13
140098a87:     	pushq	%r12
140098a89:     	pushq	%rsi
140098a8a:     	pushq	%rdi
140098a8b:     	pushq	%rbx
140098a8c:     	subq	$0x318, %rsp            # imm = 0x318
140098a93:     	leaq	0x80(%rsp), %rbp
140098a9b:     	movaps	%xmm7, 0x280(%rbp)
140098aa2:     	movaps	%xmm6, 0x270(%rbp)
140098aa9:     	leaq	0x30(%rcx), %rdx
140098aad:     	xorl	%r8d, %r8d
140098ab0:     	xorl	%r11d, %r11d
140098ab3:     	leaq	(%r11,%r11,4), %r10
140098ab7:     	shlq	$0x6, %r10
140098abb:     	addq	%rdx, %r10
140098abe:     	movq	%r11, %r9
140098ac1:     	jmp	0x140098ae4 <.text+0x97ae4>
140098ac3:     	nopw	%cs:(%rax,%rax)
140098ad0:     	incq	%r9
140098ad3:     	addq	$0x140, %r10            # imm = 0x140
140098ada:     	cmpq	$0x4, %r9
140098ade:     	je	0x140098b6e <.text+0x97b6e>
140098ae4:     	cmpb	$0x1, 0x510(%rcx,%r9)
140098aed:     	jne	0x140098ad0 <.text+0x97ad0>
140098aef:     	movq	-0x30(%r10), %rsi
140098af3:     	cmpq	$0x2, %rsi
140098af7:     	je	0x140098ad0 <.text+0x97ad0>
140098af9:     	movq	(%r10), %r11
140098afc:     	cmpl	$0x1, %esi
140098aff:     	setne	%bl
140098b02:     	testq	%r11, %r11
140098b05:     	sete	%sil
140098b09:     	orb	%bl, %sil
140098b0c:     	cmpb	$0x1, %sil
140098b10:     	je	0x140098ad0 <.text+0x97ad0>
140098b12:     	movq	0x268(%rbp), %rsi
140098b19:     	cmpq	%rsi, %r11
140098b1c:     	setae	%bl
140098b1f:     	testb	%bl, %r8b
140098b22:     	jne	0x140098b54 <.text+0x97b54>
140098b24:     	movq	-0x28(%r10), %rax
140098b28:     	movd	-0x4(%r10), %xmm6
140098b2e:     	movzbl	-0x5(%r10), %edi
140098b33:     	movzbl	-0x6(%r10), %r15d
140098b38:     	movzwl	-0x8(%r10), %r12d
140098b3d:     	movl	-0xc(%r10), %r13d
140098b41:     	movl	-0x10(%r10), %r14d
140098b45:     	movups	-0x20(%r10), %xmm0
140098b4a:     	movaps	%xmm0, 0x240(%rbp)
140098b51:     	movq	%r11, %rsi
140098b54:     	movq	%rsi, 0x268(%rbp)
140098b5b:     	leaq	0x1(%r9), %r11
140098b5f:     	movb	$0x1, %r8b
140098b62:     	cmpq	$0x3, %r9
140098b66:     	jb	0x140098ab3 <.text+0x97ab3>
140098b6c:     	jmp	0x140098b78 <.text+0x97b78>
140098b6e:     	testb	$0x1, %r8b
140098b72:     	je	0x140098db8 <.text+0x97db8>
140098b78:     	cmpq	$0x1, %rax
140098b7c:     	ja	0x140098bd4 <.text+0x97bd4>
140098b7e:     	cmpb	$0x1, 0x1e80(%rcx,%rax)
140098b86:     	jne	0x140098bd4 <.text+0x97bd4>
140098b88:     	cmpb	$0x0, 0x1e82(%rcx,%rax)
140098b90:     	jne	0x140098bd4 <.text+0x97bd4>
140098b92:     	movb	$0x0, 0x1e80(%rcx,%rax)
140098b9a:     	decq	0x1e78(%rcx)
140098ba1:     	leaq	0x14f8(%rcx), %rdx
140098ba8:     	movq	$0x0, 0x1df8(%rcx,%rax,8)
140098bb4:     	leaq	(%rax,%rax,8), %r8
140098bb8:     	leaq	(%r8,%r8,2), %r8
140098bbc:     	addq	%rax, %r8
140098bbf:     	movb	$0x2, 0x95a(%rdx,%r8)
140098bc8:     	leaq	(%rax,%rax,2), %rax
140098bcc:     	movb	$0x2, 0x91d(%rdx,%rax,8)
140098bd4:     	movaps	0x240(%rbp), %xmm0
140098bdb:     	movaps	%xmm0, -0x60(%rbp)
140098bdf:     	movl	%r14d, %esi
140098be2:     	movl	%r14d, -0x50(%rbp)
140098be6:     	movl	%r13d, %r14d
140098be9:     	movl	%r13d, -0x4c(%rbp)
140098bed:     	movl	%r12d, %r13d
140098bf0:     	movw	%r12w, -0x48(%rbp)
140098bf5:     	movl	%r15d, %r12d
140098bf8:     	movb	%r15b, -0x46(%rbp)
140098bfc:     	movl	%edi, %r15d
140098bff:     	movb	%dil, -0x45(%rbp)
140098c03:     	movd	%xmm6, %edi
140098c07:     	movd	%xmm6, -0x44(%rbp)
140098c0c:     	leaq	-0x60(%rbp), %rdx
140098c10:     	movq	%rcx, 0x260(%rbp)
140098c17:     	callq	0x140214060 <.text+0x213060>
140098c1c:     	xorps	%xmm7, %xmm7
140098c1f:     	movaps	%xmm7, 0x250(%rbp)
140098c26:     	movb	$0x0, 0x222(%rbp)
140098c2d:     	movw	%di, 0x220(%rbp)
140098c34:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
140098c3d:     	movq	$0x0, 0x223(%rbp)
140098c48:     	movq	$0x8, 0x200(%rbp)
140098c53:     	movq	$0x0, 0x208(%rbp)
140098c5e:     	movq	$0x1, 0x210(%rbp)
140098c69:     	movq	$0x0, 0x218(%rbp)
140098c74:     	leaq	0x230(%rbp), %rcx
140098c7b:     	leaq	0x200(%rbp), %rdx
140098c82:     	leaq	0x250(%rbp), %r8
140098c89:     	movl	$0x10, %r9d
140098c8f:     	callq	0x140110890 <.text+0x10f890>
140098c94:     	cmpb	$0x0, 0x230(%rbp)
140098c9b:     	jne	0x140098db4 <.text+0x97db4>
140098ca1:     	movq	0x238(%rbp), %rdi
140098ca8:     	movaps	%xmm7, 0xe0(%rbp)
140098caf:     	movaps	%xmm7, 0xf0(%rbp)
140098cb6:     	movaps	%xmm7, 0x100(%rbp)
140098cbd:     	movaps	%xmm7, 0x110(%rbp)
140098cc4:     	movaps	%xmm7, 0x120(%rbp)
140098ccb:     	movaps	%xmm7, 0x130(%rbp)
140098cd2:     	movaps	%xmm7, 0x140(%rbp)
140098cd9:     	movaps	%xmm7, 0x150(%rbp)
140098ce0:     	movaps	%xmm7, 0x160(%rbp)
140098ce7:     	movaps	%xmm7, 0x170(%rbp)
140098cee:     	movaps	%xmm7, 0x180(%rbp)
140098cf5:     	movaps	%xmm7, 0x190(%rbp)
140098cfc:     	movaps	%xmm7, 0x1a0(%rbp)
140098d03:     	movaps	%xmm7, 0x1b0(%rbp)
140098d0a:     	movaps	%xmm7, 0x1c0(%rbp)
140098d11:     	movaps	%xmm7, 0x1d0(%rbp)
140098d18:     	movaps	0x240(%rbp), %xmm0
140098d1f:     	movups	%xmm0, 0x1f0(%rbp)
140098d26:     	cmpq	$0x11, %rdi
140098d2a:     	jae	0x140098ddc <.text+0x97ddc>
140098d30:     	leaq	0xe0(%rbp), %rbx
140098d37:     	leaq	0x250(%rbp), %rdx
140098d3e:     	movq	%rbx, %rcx
140098d41:     	movq	%rdi, %r8
140098d44:     	callq	0x14024ea60 <.text+0x24da60>
140098d49:     	movw	%di, 0x1e0(%rbp)
140098d50:     	movq	$0x0, -0x60(%rbp)
140098d58:     	movups	0x1e8(%rbp), %xmm0
140098d5f:     	movups	%xmm0, -0x58(%rbp)
140098d63:     	movq	0x1f8(%rbp), %rax
140098d6a:     	movq	%rax, -0x48(%rbp)
140098d6e:     	movl	%esi, -0x40(%rbp)
140098d71:     	movl	%r14d, -0x3c(%rbp)
140098d75:     	movw	%r13w, -0x38(%rbp)
140098d7a:     	movb	%r12b, -0x36(%rbp)
140098d7e:     	movb	%r15b, -0x35(%rbp)
140098d82:     	movd	%xmm6, -0x34(%rbp)
140098d87:     	movq	0x268(%rbp), %rax
140098d8e:     	movq	%rax, -0x30(%rbp)
140098d92:     	leaq	-0x28(%rbp), %rcx
140098d96:     	movl	$0x108, %r8d            # imm = 0x108
140098d9c:     	movq	%rbx, %rdx
140098d9f:     	callq	0x14024ea60 <.text+0x24da60>
140098da4:     	leaq	-0x60(%rbp), %rdx
140098da8:     	movq	0x260(%rbp), %rcx
140098daf:     	callq	0x140213dd0 <.text+0x212dd0>
140098db4:     	movb	$0x1, %al
140098db6:     	jmp	0x140098dba <.text+0x97dba>
140098db8:     	xorl	%eax, %eax
140098dba:     	movaps	0x270(%rbp), %xmm6
140098dc1:     	movaps	0x280(%rbp), %xmm7
140098dc8:     	addq	$0x318, %rsp            # imm = 0x318
140098dcf:     	popq	%rbx
140098dd0:     	popq	%rdi
140098dd1:     	popq	%rsi
140098dd2:     	popq	%r12
140098dd4:     	popq	%r13
140098dd6:     	popq	%r14
140098dd8:     	popq	%r15
140098dda:     	popq	%rbp
140098ddb:     	retq
140098ddc:     	leaq	0x1d7d55(%rip), %r9     # 0x140270b38
140098de3:     	movl	$0x10, %r8d
140098de9:     	xorl	%ecx, %ecx
140098deb:     	movq	%rdi, %rdx
140098dee:     	callq	0x14024f4b0 <.text+0x24e4b0>
140098df3:     	ud2


D:\CoapticCurrent\packet-body-access-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400675a0:     	pushq	%rbp
1400675a1:     	pushq	%r15
1400675a3:     	pushq	%r14
1400675a5:     	pushq	%r13
1400675a7:     	pushq	%r12
1400675a9:     	pushq	%rsi
1400675aa:     	pushq	%rdi
1400675ab:     	pushq	%rbx
1400675ac:     	subq	$0xd8, %rsp
1400675b3:     	leaq	0x80(%rsp), %rbp
1400675bb:     	movq	0xd0(%rbp), %r15
1400675c2:     	movq	0x8(%r15), %rbx
1400675c6:     	movl	$0x3, %r10d
1400675cc:     	cmpq	$0x3, %rbx
1400675d0:     	ja	0x140067640 <.text+0x66640>
1400675d2:     	cmpb	$0x1, 0x1b748(%rdx,%rbx)
1400675da:     	jne	0x140067640 <.text+0x66640>
1400675dc:     	movq	0x2b750(%rdx,%rbx,8), %rax
1400675e4:     	cmpq	$0x4001, %rax           # imm = 0x4001
1400675ea:     	jae	0x1400677a8 <.text+0x667a8>
1400675f0:     	movq	0x10(%r15), %r14
1400675f4:     	movq	0x18(%r15), %r11
1400675f8:     	movq	%r11, %r12
1400675fb:     	movl	$0xb, %r10d
140067601:     	addq	%r14, %r12
140067604:     	jb	0x140067640 <.text+0x66640>
140067606:     	cmpq	$0x400, %r11            # imm = 0x400
14006760d:     	ja	0x140067640 <.text+0x66640>
14006760f:     	cmpq	%rax, %r12
140067612:     	ja	0x140067640 <.text+0x66640>
140067614:     	cmpb	$0x0, 0xd8(%rbp)
14006761b:     	movq	%r9, 0x38(%rbp)
14006761f:     	movq	%rcx, 0x50(%rbp)
140067623:     	movq	%r8, 0x40(%rbp)
140067627:     	je	0x14006763b <.text+0x6663b>
140067629:     	imulq	$0x2b0, %rbx, %rax      # imm = 0x2B0
140067630:     	cmpq	$0x2, 0x1ac78(%rdx,%rax)
140067639:     	jne	0x14006765b <.text+0x6665b>
14006763b:     	xorl	%r13d, %r13d
14006763e:     	jmp	0x140067675 <.text+0x66675>
140067640:     	movb	$0xa, (%rcx)
140067643:     	movq	%r10, 0x8(%rcx)
140067647:     	addq	$0xd8, %rsp
14006764e:     	popq	%rbx
14006764f:     	popq	%rdi
140067650:     	popq	%rsi
140067651:     	popq	%r12
140067653:     	popq	%r13
140067655:     	popq	%r14
140067657:     	popq	%r15
140067659:     	popq	%rbp
14006765a:     	retq
14006765b:     	addq	%rdx, %rax
14006765e:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
140067664:     	movq	0x98(%rax), %rax
14006766b:     	movq	%rax, 0x48(%rbp)
14006766f:     	movl	$0x1, %r13d
140067675:     	movq	%rdx, %rdi
140067678:     	movq	%rdx, %rcx
14006767b:     	callq	0x140095690 <.text+0x94690>
140067680:     	testb	$0x1, %al
140067682:     	je	0x14006778c <.text+0x6678c>
140067688:     	movq	%rdx, %rsi
14006768b:     	movq	0xe0(%rbp), %rax
140067692:     	movzwl	0xc8(%rbp), %ecx
140067699:     	movzbl	0xc0(%rbp), %edx
1400676a0:     	movq	(%r15), %r8
1400676a3:     	movq	%r13, 0x18(%rbp)
1400676a7:     	movq	0x48(%rbp), %r9
1400676ab:     	movq	%r9, 0x20(%rbp)
1400676af:     	movq	%r8, 0x28(%rbp)
1400676b3:     	movzbl	0xd8(%rbp), %r8d
1400676bb:     	movb	%r8b, 0x30(%rbp)
1400676bf:     	movq	0x40(%rbp), %r9
1400676c3:     	leaq	0x38(%r9), %r8
1400676c7:     	leaq	0x66(%r9), %r10
1400676cb:     	leaq	0x56(%r9), %r11
1400676cf:     	movq	%r11, 0x70(%rsp)
1400676d4:     	movq	%rax, 0x68(%rsp)
1400676d9:     	movq	%r9, 0x60(%rsp)
1400676de:     	leaq	0x18(%rbp), %rax
1400676e2:     	movq	%rax, 0x58(%rsp)
1400676e7:     	movq	%r12, 0x50(%rsp)
1400676ec:     	movq	%r14, 0x48(%rsp)
1400676f1:     	movq	%rbx, 0x40(%rsp)
1400676f6:     	movq	0x38(%rbp), %rax
1400676fa:     	movq	%rax, 0x38(%rsp)
1400676ff:     	movq	%r10, 0x30(%rsp)
140067704:     	movw	%cx, 0x28(%rsp)
140067709:     	movb	%dl, 0x20(%rsp)
14006770d:     	leaq	-0x8(%rbp), %rcx
140067711:     	movq	%rdi, %rdx
140067714:     	movq	%rsi, %r9
140067717:     	callq	0x14009deb0 <.text+0x9ceb0>
14006771c:     	cmpb	$-0x1, -0x8(%rbp)
140067720:     	je	0x140067798 <.text+0x66798>
140067722:     	cmpb	$0x1, 0x37740(%rdi,%rsi)
14006772a:     	movq	0x50(%rbp), %rax
14006772e:     	jne	0x140067778 <.text+0x66778>
140067730:     	cmpb	$0x0, 0x37760(%rdi,%rsi)
140067738:     	jne	0x140067778 <.text+0x66778>
14006773a:     	movb	$0x0, 0x37740(%rdi,%rsi)
140067742:     	decq	0x37788(%rdi)
140067749:     	leaq	0x37740(%rdi), %rcx
140067750:     	movq	$0x0, 0x43610(%rdi,%rsi,8)
14006775c:     	leaq	(%rsi,%rsi,8), %rdx
140067760:     	leaq	(%rdx,%rdx,2), %rdx
140067764:     	addq	%rsi, %rdx
140067767:     	movb	$0x2, 0x36a(%rcx,%rdx)
14006776f:     	leaq	(%rsi,%rsi,2), %rdx
140067773:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140067778:     	movups	-0x8(%rbp), %xmm0
14006777c:     	movups	0x8(%rbp), %xmm1
140067780:     	movups	%xmm1, 0x10(%rax)
140067784:     	movups	%xmm0, (%rax)
140067787:     	jmp	0x140067647 <.text+0x66647>
14006778c:     	movq	0x50(%rbp), %rax
140067790:     	movb	$0x9, (%rax)
140067793:     	jmp	0x140067647 <.text+0x66647>
140067798:     	movq	0x50(%rbp), %rax
14006779c:     	movq	%rsi, 0x8(%rax)
1400677a0:     	movb	$-0x1, (%rax)
1400677a3:     	jmp	0x140067647 <.text+0x66647>
1400677a8:     	leaq	0x20c481(%rip), %r9     # 0x140273c30
1400677af:     	movl	$0x4000, %r8d           # imm = 0x4000
1400677b5:     	xorl	%ecx, %ecx
1400677b7:     	movq	%rax, %rdx
1400677ba:     	callq	0x14024f4b0 <.text+0x24e4b0>
1400677bf:     	ud2

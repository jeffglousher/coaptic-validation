
D:\CoapticCurrent\packet-request-borrow-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009bdc0:     	pushq	%rbp
14009bdc1:     	pushq	%r15
14009bdc3:     	pushq	%r14
14009bdc5:     	pushq	%r13
14009bdc7:     	pushq	%r12
14009bdc9:     	pushq	%rsi
14009bdca:     	pushq	%rdi
14009bdcb:     	pushq	%rbx
14009bdcc:     	subq	$0x318, %rsp            # imm = 0x318
14009bdd3:     	leaq	0x80(%rsp), %rbp
14009bddb:     	movaps	%xmm7, 0x280(%rbp)
14009bde2:     	movdqa	%xmm6, 0x270(%rbp)
14009bdea:     	movq	0xe8(%rcx), %r8
14009bdf1:     	testq	%r8, %r8
14009bdf4:     	je	0x14009c1d4 <.text+0x9b1d4>
14009bdfa:     	movq	0x88(%rcx), %r11
14009be01:     	movq	0xe0(%rcx), %rdx
14009be08:     	movq	0xc8(%rcx), %rax
14009be0f:     	movq	0xd0(%rcx), %r9
14009be16:     	leaq	0x30(%rax), %rsi
14009be1a:     	xorl	%ebx, %ebx
14009be1c:     	xorl	%edi, %edi
14009be1e:     	leaq	(%rdi,%rdi,4), %r12
14009be22:     	shlq	$0x6, %r12
14009be26:     	addq	%rsi, %r12
14009be29:     	jmp	0x14009be43 <.text+0x9ae43>
14009be2b:     	nopl	(%rax,%rax)
14009be30:     	incq	%rdi
14009be33:     	addq	$0x140, %r12            # imm = 0x140
14009be3a:     	cmpq	%r8, %rdi
14009be3d:     	jae	0x14009bf0c <.text+0x9af0c>
14009be43:     	cmpq	%r9, %rdi
14009be46:     	setb	%r15b
14009be4a:     	andb	(%rdx,%rdi), %r15b
14009be4e:     	cmpb	$0x1, %r15b
14009be52:     	jne	0x14009be30 <.text+0x9ae30>
14009be54:     	movq	-0x30(%r12), %r15
14009be59:     	cmpq	$0x2, %r15
14009be5d:     	je	0x14009be30 <.text+0x9ae30>
14009be5f:     	movq	(%r12), %r13
14009be63:     	cmpl	$0x1, %r15d
14009be67:     	setne	%r15b
14009be6b:     	testq	%r13, %r13
14009be6e:     	sete	%r10b
14009be72:     	orb	%r15b, %r10b
14009be75:     	cmpb	$0x1, %r10b
14009be79:     	je	0x14009be30 <.text+0x9ae30>
14009be7b:     	movq	0x260(%rbp), %r15
14009be82:     	cmpq	%r15, %r13
14009be85:     	setae	%r10b
14009be89:     	testb	%r10b, %bl
14009be8c:     	jne	0x14009bef5 <.text+0x9aef5>
14009be8e:     	movq	-0x28(%r12), %r10
14009be93:     	movq	%r10, 0x250(%rbp)
14009be9a:     	movq	-0x20(%r12), %r10
14009be9f:     	movq	%r10, 0x248(%rbp)
14009bea6:     	movd	-0x4(%r12), %xmm6
14009bead:     	movzbl	-0x5(%r12), %r10d
14009beb3:     	movb	%r10b, 0x26e(%rbp)
14009beba:     	movzbl	-0x6(%r12), %r10d
14009bec0:     	movb	%r10b, 0x26f(%rbp)
14009bec7:     	movzwl	-0x8(%r12), %r10d
14009becd:     	movw	%r10w, 0x26c(%rbp)
14009bed5:     	movl	-0xc(%r12), %r10d
14009beda:     	movl	%r10d, 0x268(%rbp)
14009bee1:     	movl	-0x10(%r12), %r14d
14009bee6:     	movq	-0x18(%r12), %r10
14009beeb:     	movq	%r10, 0x258(%rbp)
14009bef2:     	movq	%r13, %r15
14009bef5:     	movq	%r15, 0x260(%rbp)
14009befc:     	incq	%rdi
14009beff:     	movb	$0x1, %bl
14009bf01:     	cmpq	%r8, %rdi
14009bf04:     	jb	0x14009be1e <.text+0x9ae1e>
14009bf0a:     	jmp	0x14009bf15 <.text+0x9af15>
14009bf0c:     	testb	$0x1, %bl
14009bf0f:     	je	0x14009c1d4 <.text+0x9b1d4>
14009bf15:     	movq	0x250(%rbp), %r10
14009bf1c:     	cmpq	%r11, %r10
14009bf1f:     	jae	0x14009bf75 <.text+0x9af75>
14009bf21:     	movq	0x80(%rcx), %r11
14009bf28:     	cmpb	$0x1, (%r11,%r10)
14009bf2d:     	jne	0x14009bf75 <.text+0x9af75>
14009bf2f:     	cmpq	0xa0(%rcx), %r10
14009bf36:     	jae	0x14009bf46 <.text+0x9af46>
14009bf38:     	movq	0x98(%rcx), %rsi
14009bf3f:     	cmpb	$0x0, (%rsi,%r10)
14009bf44:     	jne	0x14009bf75 <.text+0x9af75>
14009bf46:     	movb	$0x0, (%r11,%r10)
14009bf4b:     	decq	0xb0(%rcx)
14009bf52:     	cmpq	0x70(%rcx), %r10
14009bf56:     	jae	0x14009bf75 <.text+0x9af75>
14009bf58:     	movq	0x68(%rcx), %r11
14009bf5c:     	imulq	$0x58, %r10, %r10
14009bf60:     	movq	$0x0, 0x30(%r11,%r10)
14009bf69:     	movb	$0x2, 0x52(%r11,%r10)
14009bf6f:     	movb	$0x2, 0x25(%r11,%r10)
14009bf75:     	leaq	0xc0(%rcx), %rsi
14009bf7c:     	movd	%xmm6, %r10d
14009bf81:     	addq	$0x2c, %rax
14009bf85:     	xorl	%r11d, %r11d
14009bf88:     	movq	0x248(%rbp), %r15
14009bf8f:     	movzbl	0x26e(%rbp), %r12d
14009bf97:     	jmp	0x14009bfb2 <.text+0x9afb2>
14009bf99:     	nopl	(%rax)
14009bfa0:     	incq	%r11
14009bfa3:     	addq	$0x140, %rax            # imm = 0x140
14009bfa9:     	cmpq	%r11, %r8
14009bfac:     	je	0x14009c03e <.text+0x9b03e>
14009bfb2:     	cmpq	%r9, %r11
14009bfb5:     	setb	%bl
14009bfb8:     	andb	(%rdx,%r11), %bl
14009bfbc:     	cmpb	$0x1, %bl
14009bfbf:     	jne	0x14009bfa0 <.text+0x9afa0>
14009bfc1:     	cmpl	$0x2, -0x2c(%rax)
14009bfc5:     	je	0x14009bfa0 <.text+0x9afa0>
14009bfc7:     	cmpw	%r10w, (%rax)
14009bfcb:     	jne	0x14009bfa0 <.text+0x9afa0>
14009bfcd:     	cmpl	%r14d, -0xc(%rax)
14009bfd1:     	jne	0x14009bfa0 <.text+0x9afa0>
14009bfd3:     	movl	0x268(%rbp), %edi
14009bfd9:     	cmpl	%edi, -0x8(%rax)
14009bfdc:     	jne	0x14009bfa0 <.text+0x9afa0>
14009bfde:     	movzwl	0x26c(%rbp), %edi
14009bfe5:     	cmpw	%di, -0x4(%rax)
14009bfe9:     	jne	0x14009bfa0 <.text+0x9afa0>
14009bfeb:     	movzbl	0x26f(%rbp), %ebx
14009bff2:     	cmpb	%bl, -0x2(%rax)
14009bff5:     	jne	0x14009bfa0 <.text+0x9afa0>
14009bff7:     	movq	-0x1c(%rax), %rdi
14009bffb:     	xorq	%r15, %rdi
14009bffe:     	movq	-0x14(%rax), %rbx
14009c002:     	xorq	0x258(%rbp), %rbx
14009c009:     	orq	%rdi, %rbx
14009c00c:     	jne	0x14009bfa0 <.text+0x9afa0>
14009c00e:     	cmpq	%r8, %r11
14009c011:     	jae	0x14009c03e <.text+0x9b03e>
14009c013:     	cmpq	0x100(%rcx), %r11
14009c01a:     	jae	0x14009c02a <.text+0x9b02a>
14009c01c:     	movq	0xf8(%rcx), %r8
14009c023:     	cmpb	$0x0, (%r8,%r11)
14009c028:     	jne	0x14009c03e <.text+0x9b03e>
14009c02a:     	movb	$0x0, (%rdx,%r11)
14009c02f:     	decq	0x110(%rcx)
14009c036:     	movq	$0x2, -0x2c(%rax)
14009c03e:     	xorps	%xmm7, %xmm7
14009c041:     	movaps	%xmm7, 0x230(%rbp)
14009c048:     	movb	$0x0, 0x212(%rbp)
14009c04f:     	movw	%r10w, 0x210(%rbp)
14009c057:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
14009c060:     	movq	$0x0, 0x213(%rbp)
14009c06b:     	movq	$0x8, 0x1f0(%rbp)
14009c076:     	movq	$0x0, 0x1f8(%rbp)
14009c081:     	movq	$0x1, 0x200(%rbp)
14009c08c:     	movq	$0x0, 0x208(%rbp)
14009c097:     	leaq	0x220(%rbp), %rcx
14009c09e:     	leaq	0x1f0(%rbp), %rdx
14009c0a5:     	leaq	0x230(%rbp), %r8
14009c0ac:     	movl	$0x10, %r9d
14009c0b2:     	callq	0x14010dfb0 <.text+0x10cfb0>
14009c0b7:     	cmpb	$0x0, 0x220(%rbp)
14009c0be:     	jne	0x14009c1d0 <.text+0x9b1d0>
14009c0c4:     	movq	0x228(%rbp), %rdi
14009c0cb:     	movaps	%xmm7, 0xe0(%rbp)
14009c0d2:     	movaps	%xmm7, 0xf0(%rbp)
14009c0d9:     	movaps	%xmm7, 0x100(%rbp)
14009c0e0:     	movaps	%xmm7, 0x110(%rbp)
14009c0e7:     	movaps	%xmm7, 0x120(%rbp)
14009c0ee:     	movaps	%xmm7, 0x130(%rbp)
14009c0f5:     	movaps	%xmm7, 0x140(%rbp)
14009c0fc:     	movaps	%xmm7, 0x150(%rbp)
14009c103:     	movaps	%xmm7, 0x160(%rbp)
14009c10a:     	movaps	%xmm7, 0x170(%rbp)
14009c111:     	movaps	%xmm7, 0x180(%rbp)
14009c118:     	movaps	%xmm7, 0x190(%rbp)
14009c11f:     	movaps	%xmm7, 0x1a0(%rbp)
14009c126:     	movaps	%xmm7, 0x1b0(%rbp)
14009c12d:     	movaps	%xmm7, 0x1c0(%rbp)
14009c134:     	movaps	%xmm7, 0x1d0(%rbp)
14009c13b:     	cmpq	$0x11, %rdi
14009c13f:     	jae	0x14009c1f8 <.text+0x9b1f8>
14009c145:     	leaq	0xe0(%rbp), %rbx
14009c14c:     	leaq	0x230(%rbp), %rdx
14009c153:     	movq	%rbx, %rcx
14009c156:     	movq	%rdi, %r8
14009c159:     	callq	0x14024af10 <.text+0x249f10>
14009c15e:     	movw	%di, 0x1e0(%rbp)
14009c165:     	movq	$0x0, -0x60(%rbp)
14009c16d:     	movq	0x258(%rbp), %rax
14009c174:     	movq	%rax, -0x48(%rbp)
14009c178:     	movq	%r15, -0x50(%rbp)
14009c17c:     	movl	%r14d, -0x40(%rbp)
14009c180:     	movl	0x268(%rbp), %eax
14009c186:     	movl	%eax, -0x3c(%rbp)
14009c189:     	movzwl	0x26c(%rbp), %eax
14009c190:     	movw	%ax, -0x38(%rbp)
14009c194:     	movzbl	0x26f(%rbp), %eax
14009c19b:     	movb	%al, -0x36(%rbp)
14009c19e:     	movb	%r12b, -0x35(%rbp)
14009c1a2:     	movd	%xmm6, -0x34(%rbp)
14009c1a7:     	movq	0x260(%rbp), %rax
14009c1ae:     	movq	%rax, -0x30(%rbp)
14009c1b2:     	leaq	-0x28(%rbp), %rcx
14009c1b6:     	movl	$0x108, %r8d            # imm = 0x108
14009c1bc:     	movq	%rbx, %rdx
14009c1bf:     	callq	0x14024af10 <.text+0x249f10>
14009c1c4:     	leaq	-0x60(%rbp), %rdx
14009c1c8:     	movq	%rsi, %rcx
14009c1cb:     	callq	0x1400116e0 <.text+0x106e0>
14009c1d0:     	movb	$0x1, %al
14009c1d2:     	jmp	0x14009c1d6 <.text+0x9b1d6>
14009c1d4:     	xorl	%eax, %eax
14009c1d6:     	movaps	0x270(%rbp), %xmm6
14009c1dd:     	movaps	0x280(%rbp), %xmm7
14009c1e4:     	addq	$0x318, %rsp            # imm = 0x318
14009c1eb:     	popq	%rbx
14009c1ec:     	popq	%rdi
14009c1ed:     	popq	%rsi
14009c1ee:     	popq	%r12
14009c1f0:     	popq	%r13
14009c1f2:     	popq	%r14
14009c1f4:     	popq	%r15
14009c1f6:     	popq	%rbp
14009c1f7:     	retq
14009c1f8:     	leaq	0x1c7959(%rip), %r9     # 0x140263b58
14009c1ff:     	movl	$0x10, %r8d
14009c205:     	xorl	%ecx, %ecx
14009c207:     	movq	%rdi, %rdx
14009c20a:     	callq	0x14024b960 <.text+0x24a960>
14009c20f:     	ud2

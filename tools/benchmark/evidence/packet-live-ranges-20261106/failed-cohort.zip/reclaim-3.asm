
D:\CoapticCurrent\packet-request-borrow-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009ba00:     	pushq	%rbp
14009ba01:     	pushq	%r15
14009ba03:     	pushq	%r14
14009ba05:     	pushq	%r13
14009ba07:     	pushq	%r12
14009ba09:     	pushq	%rsi
14009ba0a:     	pushq	%rdi
14009ba0b:     	pushq	%rbx
14009ba0c:     	subq	$0x308, %rsp            # imm = 0x308
14009ba13:     	leaq	0x80(%rsp), %rbp
14009ba1b:     	movaps	%xmm7, 0x270(%rbp)
14009ba22:     	movaps	%xmm6, 0x260(%rbp)
14009ba29:     	leaq	0x5000(%rcx), %rax
14009ba30:     	leaq	0x30(%rcx), %r8
14009ba34:     	xorl	%r9d, %r9d
14009ba37:     	xorl	%esi, %esi
14009ba39:     	leaq	(%rsi,%rsi,4), %r11
14009ba3d:     	shlq	$0x6, %r11
14009ba41:     	addq	%r8, %r11
14009ba44:     	movq	%rsi, %r10
14009ba47:     	jmp	0x14009ba64 <.text+0x9aa64>
14009ba49:     	nopl	(%rax)
14009ba50:     	incq	%r10
14009ba53:     	addq	$0x140, %r11            # imm = 0x140
14009ba5a:     	cmpq	$0x40, %r10
14009ba5e:     	je	0x14009bafe <.text+0x9aafe>
14009ba64:     	cmpb	$0x1, 0x5000(%rcx,%r10)
14009ba6d:     	jne	0x14009ba50 <.text+0x9aa50>
14009ba6f:     	movq	-0x30(%r11), %rdi
14009ba73:     	cmpq	$0x2, %rdi
14009ba77:     	je	0x14009ba50 <.text+0x9aa50>
14009ba79:     	movq	(%r11), %rsi
14009ba7c:     	cmpl	$0x1, %edi
14009ba7f:     	setne	%bl
14009ba82:     	testq	%rsi, %rsi
14009ba85:     	sete	%dil
14009ba89:     	orb	%bl, %dil
14009ba8c:     	cmpb	$0x1, %dil
14009ba90:     	je	0x14009ba50 <.text+0x9aa50>
14009ba92:     	movq	0x250(%rbp), %rdi
14009ba99:     	cmpq	%rdi, %rsi
14009ba9c:     	setae	%bl
14009ba9f:     	testb	%bl, %r9b
14009baa2:     	jne	0x14009bae4 <.text+0x9aae4>
14009baa4:     	movd	-0x4(%r11), %xmm6
14009baaa:     	movzbl	-0x5(%r11), %edx
14009baaf:     	movb	%dl, 0x25f(%rbp)
14009bab5:     	movzbl	-0x6(%r11), %r15d
14009baba:     	movzwl	-0x8(%r11), %r12d
14009babf:     	movl	-0xc(%r11), %r13d
14009bac3:     	movl	-0x10(%r11), %r14d
14009bac7:     	movq	-0x18(%r11), %rdx
14009bacb:     	movq	%rdx, 0x248(%rbp)
14009bad2:     	movq	-0x28(%r11), %rdx
14009bad6:     	movq	-0x20(%r11), %r9
14009bada:     	movq	%r9, 0x240(%rbp)
14009bae1:     	movq	%rsi, %rdi
14009bae4:     	movq	%rdi, 0x250(%rbp)
14009baeb:     	leaq	0x1(%r10), %rsi
14009baef:     	movb	$0x1, %r9b
14009baf2:     	cmpq	$0x3f, %r10
14009baf6:     	jb	0x14009ba39 <.text+0x9aa39>
14009bafc:     	jmp	0x14009bb08 <.text+0x9ab08>
14009bafe:     	testb	$0x1, %r9b
14009bb02:     	je	0x14009bd80 <.text+0x9ad80>
14009bb08:     	cmpq	$0x1f, %rdx
14009bb0c:     	ja	0x14009bb5f <.text+0x9ab5f>
14009bb0e:     	leaq	0x37740(%rcx), %r8
14009bb15:     	cmpb	$0x1, (%r8,%rdx)
14009bb1a:     	jne	0x14009bb5f <.text+0x9ab5f>
14009bb1c:     	cmpb	$0x0, 0x37760(%rcx,%rdx)
14009bb24:     	jne	0x14009bb5f <.text+0x9ab5f>
14009bb26:     	movb	$0x0, 0x37740(%rcx,%rdx)
14009bb2e:     	decq	0x37788(%rcx)
14009bb35:     	movq	$0x0, 0x43610(%rcx,%rdx,8)
14009bb41:     	leaq	(%rdx,%rdx,8), %r9
14009bb45:     	leaq	(%r9,%r9,2), %r9
14009bb49:     	addq	%rdx, %r9
14009bb4c:     	movb	$0x2, 0x36a(%r8,%r9)
14009bb55:     	leaq	(%rdx,%rdx,2), %rdx
14009bb59:     	movb	$0x2, 0x5d(%r8,%rdx,8)
14009bb5f:     	movd	%xmm6, %edx
14009bb63:     	movl	$0x2c, %r8d
14009bb69:     	movq	0x240(%rbp), %r11
14009bb70:     	movq	0x248(%rbp), %rsi
14009bb77:     	jmp	0x14009bb93 <.text+0x9ab93>
14009bb79:     	nopl	(%rax)
14009bb80:     	incq	%rax
14009bb83:     	addq	$0x140, %r8             # imm = 0x140
14009bb8a:     	cmpq	$0x502c, %r8            # imm = 0x502C
14009bb91:     	je	0x14009bbec <.text+0x9abec>
14009bb93:     	cmpb	$0x1, (%rax)
14009bb96:     	jne	0x14009bb80 <.text+0x9ab80>
14009bb98:     	cmpl	$0x2, -0x2c(%rcx,%r8)
14009bb9e:     	je	0x14009bb80 <.text+0x9ab80>
14009bba0:     	cmpw	%dx, (%rcx,%r8)
14009bba5:     	jne	0x14009bb80 <.text+0x9ab80>
14009bba7:     	cmpl	%r14d, -0xc(%rcx,%r8)
14009bbac:     	jne	0x14009bb80 <.text+0x9ab80>
14009bbae:     	cmpl	%r13d, -0x8(%rcx,%r8)
14009bbb3:     	jne	0x14009bb80 <.text+0x9ab80>
14009bbb5:     	cmpw	%r12w, -0x4(%rcx,%r8)
14009bbbb:     	jne	0x14009bb80 <.text+0x9ab80>
14009bbbd:     	cmpb	%r15b, -0x2(%rcx,%r8)
14009bbc2:     	jne	0x14009bb80 <.text+0x9ab80>
14009bbc4:     	movq	-0x1c(%rcx,%r8), %r9
14009bbc9:     	xorq	%r11, %r9
14009bbcc:     	movq	-0x14(%rcx,%r8), %r10
14009bbd1:     	xorq	%rsi, %r10
14009bbd4:     	orq	%r9, %r10
14009bbd7:     	jne	0x14009bb80 <.text+0x9ab80>
14009bbd9:     	movb	$0x0, (%rax)
14009bbdc:     	decq	0x5048(%rcx)
14009bbe3:     	movq	$0x2, -0x2c(%rcx,%r8)
14009bbec:     	movq	%rcx, %rsi
14009bbef:     	xorps	%xmm7, %xmm7
14009bbf2:     	movaps	%xmm7, 0x230(%rbp)
14009bbf9:     	movb	$0x0, 0x212(%rbp)
14009bc00:     	movw	%dx, 0x210(%rbp)
14009bc07:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
14009bc10:     	movq	$0x0, 0x213(%rbp)
14009bc1b:     	movq	$0x8, 0x1f0(%rbp)
14009bc26:     	movq	$0x0, 0x1f8(%rbp)
14009bc31:     	movq	$0x1, 0x200(%rbp)
14009bc3c:     	movq	$0x0, 0x208(%rbp)
14009bc47:     	leaq	0x220(%rbp), %rcx
14009bc4e:     	leaq	0x1f0(%rbp), %rdx
14009bc55:     	leaq	0x230(%rbp), %r8
14009bc5c:     	movl	$0x10, %r9d
14009bc62:     	callq	0x14010dfb0 <.text+0x10cfb0>
14009bc67:     	cmpb	$0x0, 0x220(%rbp)
14009bc6e:     	jne	0x14009bd7c <.text+0x9ad7c>
14009bc74:     	movq	0x228(%rbp), %rdi
14009bc7b:     	movaps	%xmm7, 0xe0(%rbp)
14009bc82:     	movaps	%xmm7, 0xf0(%rbp)
14009bc89:     	movaps	%xmm7, 0x100(%rbp)
14009bc90:     	movaps	%xmm7, 0x110(%rbp)
14009bc97:     	movaps	%xmm7, 0x120(%rbp)
14009bc9e:     	movaps	%xmm7, 0x130(%rbp)
14009bca5:     	movaps	%xmm7, 0x140(%rbp)
14009bcac:     	movaps	%xmm7, 0x150(%rbp)
14009bcb3:     	movaps	%xmm7, 0x160(%rbp)
14009bcba:     	movaps	%xmm7, 0x170(%rbp)
14009bcc1:     	movaps	%xmm7, 0x180(%rbp)
14009bcc8:     	movaps	%xmm7, 0x190(%rbp)
14009bccf:     	movaps	%xmm7, 0x1a0(%rbp)
14009bcd6:     	movaps	%xmm7, 0x1b0(%rbp)
14009bcdd:     	movaps	%xmm7, 0x1c0(%rbp)
14009bce4:     	movaps	%xmm7, 0x1d0(%rbp)
14009bceb:     	cmpq	$0x11, %rdi
14009bcef:     	jae	0x14009bda4 <.text+0x9ada4>
14009bcf5:     	leaq	0xe0(%rbp), %rbx
14009bcfc:     	leaq	0x230(%rbp), %rdx
14009bd03:     	movq	%rbx, %rcx
14009bd06:     	movq	%rdi, %r8
14009bd09:     	callq	0x14024af10 <.text+0x249f10>
14009bd0e:     	movw	%di, 0x1e0(%rbp)
14009bd15:     	movq	$0x0, -0x60(%rbp)
14009bd1d:     	movq	0x248(%rbp), %rax
14009bd24:     	movq	%rax, -0x48(%rbp)
14009bd28:     	movq	0x240(%rbp), %rax
14009bd2f:     	movq	%rax, -0x50(%rbp)
14009bd33:     	movl	%r14d, -0x40(%rbp)
14009bd37:     	movl	%r13d, -0x3c(%rbp)
14009bd3b:     	movw	%r12w, -0x38(%rbp)
14009bd40:     	movb	%r15b, -0x36(%rbp)
14009bd44:     	movzbl	0x25f(%rbp), %eax
14009bd4b:     	movb	%al, -0x35(%rbp)
14009bd4e:     	movd	%xmm6, -0x34(%rbp)
14009bd53:     	movq	0x250(%rbp), %rax
14009bd5a:     	movq	%rax, -0x30(%rbp)
14009bd5e:     	leaq	-0x28(%rbp), %rcx
14009bd62:     	movl	$0x108, %r8d            # imm = 0x108
14009bd68:     	movq	%rbx, %rdx
14009bd6b:     	callq	0x14024af10 <.text+0x249f10>
14009bd70:     	leaq	-0x60(%rbp), %rdx
14009bd74:     	movq	%rsi, %rcx
14009bd77:     	callq	0x14020ff70 <.text+0x20ef70>
14009bd7c:     	movb	$0x1, %al
14009bd7e:     	jmp	0x14009bd82 <.text+0x9ad82>
14009bd80:     	xorl	%eax, %eax
14009bd82:     	movaps	0x260(%rbp), %xmm6
14009bd89:     	movaps	0x270(%rbp), %xmm7
14009bd90:     	addq	$0x308, %rsp            # imm = 0x308
14009bd97:     	popq	%rbx
14009bd98:     	popq	%rdi
14009bd99:     	popq	%rsi
14009bd9a:     	popq	%r12
14009bd9c:     	popq	%r13
14009bd9e:     	popq	%r14
14009bda0:     	popq	%r15
14009bda2:     	popq	%rbp
14009bda3:     	retq
14009bda4:     	leaq	0x1c7dad(%rip), %r9     # 0x140263b58
14009bdab:     	movl	$0x10, %r8d
14009bdb1:     	xorl	%ecx, %ecx
14009bdb3:     	movq	%rdi, %rdx
14009bdb6:     	callq	0x14024b960 <.text+0x24a960>
14009bdbb:     	ud2

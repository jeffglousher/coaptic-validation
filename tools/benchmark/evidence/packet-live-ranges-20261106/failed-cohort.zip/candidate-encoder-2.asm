
D:\CoapticCurrent\packet-request-borrow-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140067bd0:     	pushq	%rbp
140067bd1:     	pushq	%r15
140067bd3:     	pushq	%r14
140067bd5:     	pushq	%r13
140067bd7:     	pushq	%r12
140067bd9:     	pushq	%rsi
140067bda:     	pushq	%rdi
140067bdb:     	pushq	%rbx
140067bdc:     	subq	$0x4f8, %rsp            # imm = 0x4F8
140067be3:     	leaq	0x80(%rsp), %rbp
140067beb:     	movq	%r9, %rbx
140067bee:     	movq	%r8, %r14
140067bf1:     	movq	%rdx, %rdi
140067bf4:     	movq	%rcx, %rsi
140067bf7:     	movq	0x4f0(%rbp), %r12
140067bfe:     	leaq	-0x10(%rbp), %rcx
140067c02:     	movl	$0x400, %r8d            # imm = 0x400
140067c08:     	xorl	%edx, %edx
140067c0a:     	callq	0x14024af22 <.text+0x249f22>
140067c0f:     	movq	0x8(%r12), %r13
140067c14:     	movl	$0x3, %eax
140067c19:     	cmpq	$0x3, %r13
140067c1d:     	ja	0x140067e36 <.text+0x66e36>
140067c23:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
140067c2c:     	jne	0x140067e36 <.text+0x66e36>
140067c32:     	movq	0x2b750(%rdi,%r13,8), %rdx
140067c3a:     	cmpq	$0x4001, %rdx           # imm = 0x4001
140067c41:     	jae	0x140067e92 <.text+0x66e92>
140067c47:     	movq	0x10(%r12), %rcx
140067c4c:     	movq	0x18(%r12), %r15
140067c51:     	movq	%r15, %r8
140067c54:     	movl	$0xb, %eax
140067c59:     	addq	%rcx, %r8
140067c5c:     	jb	0x140067e36 <.text+0x66e36>
140067c62:     	cmpq	$0x400, %r15            # imm = 0x400
140067c69:     	ja	0x140067e36 <.text+0x66e36>
140067c6f:     	cmpq	%rdx, %r8
140067c72:     	ja	0x140067e36 <.text+0x66e36>
140067c78:     	movq	%r13, %rax
140067c7b:     	shlq	$0xe, %rax
140067c7f:     	leaq	(%rdi,%rax), %rdx
140067c83:     	addq	$0x1b750, %rdx          # imm = 0x1B750
140067c8a:     	addq	%rcx, %rdx
140067c8d:     	leaq	-0x10(%rbp), %rcx
140067c91:     	movq	%r15, %r8
140067c94:     	callq	0x14024af10 <.text+0x249f10>
140067c99:     	cmpb	$0x0, 0x4f8(%rbp)
140067ca0:     	je	0x140067cb8 <.text+0x66cb8>
140067ca2:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
140067ca9:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
140067cb2:     	jne	0x140067e51 <.text+0x66e51>
140067cb8:     	movq	$0x0, 0x470(%rbp)
140067cc3:     	movq	%rdi, %rcx
140067cc6:     	callq	0x140097f10 <.text+0x96f10>
140067ccb:     	testb	$0x1, %al
140067ccd:     	je	0x140067e84 <.text+0x66e84>
140067cd3:     	movq	%rdx, %r13
140067cd6:     	movq	0x500(%rbp), %rdx
140067cdd:     	movzwl	0x4e8(%rbp), %ecx
140067ce4:     	movzbl	0x4e0(%rbp), %eax
140067ceb:     	movq	(%r12), %r8
140067cef:     	movq	0x470(%rbp), %r9
140067cf6:     	movq	%r9, 0x438(%rbp)
140067cfd:     	movq	0x468(%rbp), %r9
140067d04:     	movq	%r9, 0x440(%rbp)
140067d0b:     	movq	%r8, 0x448(%rbp)
140067d12:     	movzbl	0x4f8(%rbp), %r8d
140067d1a:     	movb	%r8b, 0x450(%rbp)
140067d21:     	movups	0x38(%r14), %xmm0
140067d26:     	movups	0x44(%r14), %xmm1
140067d2b:     	movups	%xmm1, 0x3fc(%rbp)
140067d32:     	movaps	%xmm0, 0x3f0(%rbp)
140067d39:     	leaq	0x66(%r14), %r8
140067d3d:     	movq	0x56(%r14), %r9
140067d41:     	movq	0x5d(%r14), %r10
140067d45:     	movq	%r10, 0x45f(%rbp)
140067d4c:     	movq	%r9, 0x458(%rbp)
140067d53:     	leaq	0x458(%rbp), %r9
140067d5a:     	movq	%r9, 0x68(%rsp)
140067d5f:     	movq	%rdx, 0x60(%rsp)
140067d64:     	movq	%r14, 0x58(%rsp)
140067d69:     	leaq	0x438(%rbp), %rdx
140067d70:     	movq	%rdx, 0x50(%rsp)
140067d75:     	movq	%r15, 0x48(%rsp)
140067d7a:     	leaq	-0x10(%rbp), %rdx
140067d7e:     	movq	%rdx, 0x40(%rsp)
140067d83:     	movq	%rbx, 0x38(%rsp)
140067d88:     	movq	%r8, 0x30(%rsp)
140067d8d:     	movw	%cx, 0x28(%rsp)
140067d92:     	movb	%al, 0x20(%rsp)
140067d96:     	leaq	0x418(%rbp), %rcx
140067d9d:     	leaq	0x3f0(%rbp), %r8
140067da4:     	movq	%rdi, %rdx
140067da7:     	movq	%r13, %r9
140067daa:     	callq	0x140080390 <.text+0x7f390>
140067daf:     	cmpb	$-0x1, 0x418(%rbp)
140067db6:     	je	0x140067e89 <.text+0x66e89>
140067dbc:     	cmpb	$0x1, 0x37740(%rdi,%r13)
140067dc5:     	jne	0x140067e1f <.text+0x66e1f>
140067dc7:     	cmpb	$0x0, 0x37760(%rdi,%r13)
140067dd0:     	jne	0x140067e1f <.text+0x66e1f>
140067dd2:     	movb	$0x0, 0x37740(%rdi,%r13)
140067ddb:     	decq	0x37788(%rdi)
140067de2:     	leaq	0x37740(%rdi), %rax
140067de9:     	movq	$0x0, 0x43610(%rdi,%r13,8)
140067df5:     	leaq	(,%r13,8), %rcx
140067dfd:     	addq	%r13, %rcx
140067e00:     	leaq	(%rcx,%rcx,2), %rcx
140067e04:     	addq	%r13, %rcx
140067e07:     	movb	$0x2, 0x36a(%rax,%rcx)
140067e0f:     	leaq	(,%r13,2), %rcx
140067e17:     	addq	%r13, %rcx
140067e1a:     	movb	$0x2, 0x5d(%rax,%rcx,8)
140067e1f:     	movups	0x418(%rbp), %xmm0
140067e26:     	movups	0x428(%rbp), %xmm1
140067e2d:     	movups	%xmm1, 0x10(%rsi)
140067e31:     	movups	%xmm0, (%rsi)
140067e34:     	jmp	0x140067e3d <.text+0x66e3d>
140067e36:     	movb	$0xa, (%rsi)
140067e39:     	movq	%rax, 0x8(%rsi)
140067e3d:     	addq	$0x4f8, %rsp            # imm = 0x4F8
140067e44:     	popq	%rbx
140067e45:     	popq	%rdi
140067e46:     	popq	%rsi
140067e47:     	popq	%r12
140067e49:     	popq	%r13
140067e4b:     	popq	%r14
140067e4d:     	popq	%r15
140067e4f:     	popq	%rbp
140067e50:     	retq
140067e51:     	addq	%rdi, %rax
140067e54:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
140067e5a:     	movq	0x98(%rax), %rax
140067e61:     	movq	%rax, 0x468(%rbp)
140067e68:     	movl	$0x1, %eax
140067e6d:     	movq	%rax, 0x470(%rbp)
140067e74:     	movq	%rdi, %rcx
140067e77:     	callq	0x140097f10 <.text+0x96f10>
140067e7c:     	testb	$0x1, %al
140067e7e:     	jne	0x140067cd3 <.text+0x66cd3>
140067e84:     	movb	$0x9, (%rsi)
140067e87:     	jmp	0x140067e3d <.text+0x66e3d>
140067e89:     	movq	%r13, 0x8(%rsi)
140067e8d:     	movb	$-0x1, (%rsi)
140067e90:     	jmp	0x140067e3d <.text+0x66e3d>
140067e92:     	leaq	0x1fed97(%rip), %r9     # 0x140266c30
140067e99:     	movl	$0x4000, %r8d           # imm = 0x4000
140067e9f:     	xorl	%ecx, %ecx
140067ea1:     	callq	0x14024b960 <.text+0x24a960>
140067ea6:     	ud2

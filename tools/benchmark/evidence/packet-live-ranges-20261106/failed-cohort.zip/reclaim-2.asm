
D:\CoapticCurrent\packet-request-borrow-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009b680:     	pushq	%rbp
14009b681:     	pushq	%r15
14009b683:     	pushq	%r14
14009b685:     	pushq	%r13
14009b687:     	pushq	%r12
14009b689:     	pushq	%rsi
14009b68a:     	pushq	%rdi
14009b68b:     	pushq	%rbx
14009b68c:     	subq	$0x318, %rsp            # imm = 0x318
14009b693:     	leaq	0x80(%rsp), %rbp
14009b69b:     	movaps	%xmm7, 0x280(%rbp)
14009b6a2:     	movaps	%xmm6, 0x270(%rbp)
14009b6a9:     	leaq	0x30(%rcx), %rdx
14009b6ad:     	xorl	%r8d, %r8d
14009b6b0:     	xorl	%r11d, %r11d
14009b6b3:     	leaq	(%r11,%r11,4), %r10
14009b6b7:     	shlq	$0x6, %r10
14009b6bb:     	addq	%rdx, %r10
14009b6be:     	movq	%r11, %r9
14009b6c1:     	jmp	0x14009b6e4 <.text+0x9a6e4>
14009b6c3:     	nopw	%cs:(%rax,%rax)
14009b6d0:     	incq	%r9
14009b6d3:     	addq	$0x140, %r10            # imm = 0x140
14009b6da:     	cmpq	$0x4, %r9
14009b6de:     	je	0x14009b76e <.text+0x9a76e>
14009b6e4:     	cmpb	$0x1, 0x510(%rcx,%r9)
14009b6ed:     	jne	0x14009b6d0 <.text+0x9a6d0>
14009b6ef:     	movq	-0x30(%r10), %rsi
14009b6f3:     	cmpq	$0x2, %rsi
14009b6f7:     	je	0x14009b6d0 <.text+0x9a6d0>
14009b6f9:     	movq	(%r10), %r11
14009b6fc:     	cmpl	$0x1, %esi
14009b6ff:     	setne	%bl
14009b702:     	testq	%r11, %r11
14009b705:     	sete	%sil
14009b709:     	orb	%bl, %sil
14009b70c:     	cmpb	$0x1, %sil
14009b710:     	je	0x14009b6d0 <.text+0x9a6d0>
14009b712:     	movq	0x268(%rbp), %rsi
14009b719:     	cmpq	%rsi, %r11
14009b71c:     	setae	%bl
14009b71f:     	testb	%bl, %r8b
14009b722:     	jne	0x14009b754 <.text+0x9a754>
14009b724:     	movq	-0x28(%r10), %rax
14009b728:     	movd	-0x4(%r10), %xmm6
14009b72e:     	movzbl	-0x5(%r10), %edi
14009b733:     	movzbl	-0x6(%r10), %r15d
14009b738:     	movzwl	-0x8(%r10), %r12d
14009b73d:     	movl	-0xc(%r10), %r13d
14009b741:     	movl	-0x10(%r10), %r14d
14009b745:     	movups	-0x20(%r10), %xmm0
14009b74a:     	movaps	%xmm0, 0x240(%rbp)
14009b751:     	movq	%r11, %rsi
14009b754:     	movq	%rsi, 0x268(%rbp)
14009b75b:     	leaq	0x1(%r9), %r11
14009b75f:     	movb	$0x1, %r8b
14009b762:     	cmpq	$0x3, %r9
14009b766:     	jb	0x14009b6b3 <.text+0x9a6b3>
14009b76c:     	jmp	0x14009b778 <.text+0x9a778>
14009b76e:     	testb	$0x1, %r8b
14009b772:     	je	0x14009b9b8 <.text+0x9a9b8>
14009b778:     	cmpq	$0x1, %rax
14009b77c:     	ja	0x14009b7d4 <.text+0x9a7d4>
14009b77e:     	cmpb	$0x1, 0x4420(%rcx,%rax)
14009b786:     	jne	0x14009b7d4 <.text+0x9a7d4>
14009b788:     	cmpb	$0x0, 0x4422(%rcx,%rax)
14009b790:     	jne	0x14009b7d4 <.text+0x9a7d4>
14009b792:     	movb	$0x0, 0x4420(%rcx,%rax)
14009b79a:     	decq	0x4418(%rcx)
14009b7a1:     	leaq	0x3a98(%rcx), %rdx
14009b7a8:     	movq	$0x0, 0x4398(%rcx,%rax,8)
14009b7b4:     	leaq	(%rax,%rax,8), %r8
14009b7b8:     	leaq	(%r8,%r8,2), %r8
14009b7bc:     	addq	%rax, %r8
14009b7bf:     	movb	$0x2, 0x95a(%rdx,%r8)
14009b7c8:     	leaq	(%rax,%rax,2), %rax
14009b7cc:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009b7d4:     	movaps	0x240(%rbp), %xmm0
14009b7db:     	movaps	%xmm0, -0x60(%rbp)
14009b7df:     	movl	%r14d, %esi
14009b7e2:     	movl	%r14d, -0x50(%rbp)
14009b7e6:     	movl	%r13d, %r14d
14009b7e9:     	movl	%r13d, -0x4c(%rbp)
14009b7ed:     	movl	%r12d, %r13d
14009b7f0:     	movw	%r12w, -0x48(%rbp)
14009b7f5:     	movl	%r15d, %r12d
14009b7f8:     	movb	%r15b, -0x46(%rbp)
14009b7fc:     	movl	%edi, %r15d
14009b7ff:     	movb	%dil, -0x45(%rbp)
14009b803:     	movd	%xmm6, %edi
14009b807:     	movd	%xmm6, -0x44(%rbp)
14009b80c:     	leaq	-0x60(%rbp), %rdx
14009b810:     	movq	%rcx, 0x260(%rbp)
14009b817:     	callq	0x1402103a0 <.text+0x20f3a0>
14009b81c:     	xorps	%xmm7, %xmm7
14009b81f:     	movaps	%xmm7, 0x250(%rbp)
14009b826:     	movb	$0x0, 0x222(%rbp)
14009b82d:     	movw	%di, 0x220(%rbp)
14009b834:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009b83d:     	movq	$0x0, 0x223(%rbp)
14009b848:     	movq	$0x8, 0x200(%rbp)
14009b853:     	movq	$0x0, 0x208(%rbp)
14009b85e:     	movq	$0x1, 0x210(%rbp)
14009b869:     	movq	$0x0, 0x218(%rbp)
14009b874:     	leaq	0x230(%rbp), %rcx
14009b87b:     	leaq	0x200(%rbp), %rdx
14009b882:     	leaq	0x250(%rbp), %r8
14009b889:     	movl	$0x10, %r9d
14009b88f:     	callq	0x14010dfb0 <.text+0x10cfb0>
14009b894:     	cmpb	$0x0, 0x230(%rbp)
14009b89b:     	jne	0x14009b9b4 <.text+0x9a9b4>
14009b8a1:     	movq	0x238(%rbp), %rdi
14009b8a8:     	movaps	%xmm7, 0xe0(%rbp)
14009b8af:     	movaps	%xmm7, 0xf0(%rbp)
14009b8b6:     	movaps	%xmm7, 0x100(%rbp)
14009b8bd:     	movaps	%xmm7, 0x110(%rbp)
14009b8c4:     	movaps	%xmm7, 0x120(%rbp)
14009b8cb:     	movaps	%xmm7, 0x130(%rbp)
14009b8d2:     	movaps	%xmm7, 0x140(%rbp)
14009b8d9:     	movaps	%xmm7, 0x150(%rbp)
14009b8e0:     	movaps	%xmm7, 0x160(%rbp)
14009b8e7:     	movaps	%xmm7, 0x170(%rbp)
14009b8ee:     	movaps	%xmm7, 0x180(%rbp)
14009b8f5:     	movaps	%xmm7, 0x190(%rbp)
14009b8fc:     	movaps	%xmm7, 0x1a0(%rbp)
14009b903:     	movaps	%xmm7, 0x1b0(%rbp)
14009b90a:     	movaps	%xmm7, 0x1c0(%rbp)
14009b911:     	movaps	%xmm7, 0x1d0(%rbp)
14009b918:     	movaps	0x240(%rbp), %xmm0
14009b91f:     	movups	%xmm0, 0x1f0(%rbp)
14009b926:     	cmpq	$0x11, %rdi
14009b92a:     	jae	0x14009b9dc <.text+0x9a9dc>
14009b930:     	leaq	0xe0(%rbp), %rbx
14009b937:     	leaq	0x250(%rbp), %rdx
14009b93e:     	movq	%rbx, %rcx
14009b941:     	movq	%rdi, %r8
14009b944:     	callq	0x14024af10 <.text+0x249f10>
14009b949:     	movw	%di, 0x1e0(%rbp)
14009b950:     	movq	$0x0, -0x60(%rbp)
14009b958:     	movups	0x1e8(%rbp), %xmm0
14009b95f:     	movups	%xmm0, -0x58(%rbp)
14009b963:     	movq	0x1f8(%rbp), %rax
14009b96a:     	movq	%rax, -0x48(%rbp)
14009b96e:     	movl	%esi, -0x40(%rbp)
14009b971:     	movl	%r14d, -0x3c(%rbp)
14009b975:     	movw	%r13w, -0x38(%rbp)
14009b97a:     	movb	%r12b, -0x36(%rbp)
14009b97e:     	movb	%r15b, -0x35(%rbp)
14009b982:     	movd	%xmm6, -0x34(%rbp)
14009b987:     	movq	0x268(%rbp), %rax
14009b98e:     	movq	%rax, -0x30(%rbp)
14009b992:     	leaq	-0x28(%rbp), %rcx
14009b996:     	movl	$0x108, %r8d            # imm = 0x108
14009b99c:     	movq	%rbx, %rdx
14009b99f:     	callq	0x14024af10 <.text+0x249f10>
14009b9a4:     	leaq	-0x60(%rbp), %rdx
14009b9a8:     	movq	0x260(%rbp), %rcx
14009b9af:     	callq	0x140210110 <.text+0x20f110>
14009b9b4:     	movb	$0x1, %al
14009b9b6:     	jmp	0x14009b9ba <.text+0x9a9ba>
14009b9b8:     	xorl	%eax, %eax
14009b9ba:     	movaps	0x270(%rbp), %xmm6
14009b9c1:     	movaps	0x280(%rbp), %xmm7
14009b9c8:     	addq	$0x318, %rsp            # imm = 0x318
14009b9cf:     	popq	%rbx
14009b9d0:     	popq	%rdi
14009b9d1:     	popq	%rsi
14009b9d2:     	popq	%r12
14009b9d4:     	popq	%r13
14009b9d6:     	popq	%r14
14009b9d8:     	popq	%r15
14009b9da:     	popq	%rbp
14009b9db:     	retq
14009b9dc:     	leaq	0x1c8175(%rip), %r9     # 0x140263b58
14009b9e3:     	movl	$0x10, %r8d
14009b9e9:     	xorl	%ecx, %ecx
14009b9eb:     	movq	%rdi, %rdx
14009b9ee:     	callq	0x14024b960 <.text+0x24a960>
14009b9f3:     	ud2

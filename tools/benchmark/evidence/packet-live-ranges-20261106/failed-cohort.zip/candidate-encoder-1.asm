
D:\CoapticCurrent\packet-request-borrow-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400678e0:     	pushq	%rbp
1400678e1:     	pushq	%r15
1400678e3:     	pushq	%r14
1400678e5:     	pushq	%r13
1400678e7:     	pushq	%r12
1400678e9:     	pushq	%rsi
1400678ea:     	pushq	%rdi
1400678eb:     	pushq	%rbx
1400678ec:     	subq	$0x508, %rsp            # imm = 0x508
1400678f3:     	leaq	0x80(%rsp), %rbp
1400678fb:     	movq	%r9, %rbx
1400678fe:     	movq	%r8, %r14
140067901:     	movq	%rdx, %rdi
140067904:     	movq	%rcx, %rsi
140067907:     	movq	0x500(%rbp), %r12
14006790e:     	movq	%rbp, %rcx
140067911:     	movl	$0x400, %r8d            # imm = 0x400
140067917:     	xorl	%edx, %edx
140067919:     	callq	0x14024af22 <.text+0x249f22>
14006791e:     	movq	0x8(%r12), %r13
140067923:     	movl	$0x3, %eax
140067928:     	cmpq	$0x3, %r13
14006792c:     	ja	0x140067b4f <.text+0x66b4f>
140067932:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
14006793b:     	jne	0x140067b4f <.text+0x66b4f>
140067941:     	movq	0x2b750(%rdi,%r13,8), %rdx
140067949:     	cmpq	$0x4001, %rdx           # imm = 0x4001
140067950:     	jae	0x140067bab <.text+0x66bab>
140067956:     	movq	0x10(%r12), %rcx
14006795b:     	movq	0x18(%r12), %r15
140067960:     	movq	%r15, %r8
140067963:     	movl	$0xb, %eax
140067968:     	addq	%rcx, %r8
14006796b:     	jb	0x140067b4f <.text+0x66b4f>
140067971:     	cmpq	$0x400, %r15            # imm = 0x400
140067978:     	ja	0x140067b4f <.text+0x66b4f>
14006797e:     	cmpq	%rdx, %r8
140067981:     	ja	0x140067b4f <.text+0x66b4f>
140067987:     	movq	%r13, %rax
14006798a:     	shlq	$0xe, %rax
14006798e:     	leaq	(%rdi,%rax), %rdx
140067992:     	addq	$0x1b750, %rdx          # imm = 0x1B750
140067999:     	addq	%rcx, %rdx
14006799c:     	movq	%rbp, %rcx
14006799f:     	movq	%r15, %r8
1400679a2:     	callq	0x14024af10 <.text+0x249f10>
1400679a7:     	cmpb	$0x0, 0x508(%rbp)
1400679ae:     	je	0x1400679c6 <.text+0x669c6>
1400679b0:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
1400679b7:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
1400679c0:     	jne	0x140067b6a <.text+0x66b6a>
1400679c6:     	movq	$0x0, 0x480(%rbp)
1400679d1:     	movq	%rdi, %rcx
1400679d4:     	callq	0x140097f10 <.text+0x96f10>
1400679d9:     	testb	$0x1, %al
1400679db:     	je	0x140067b9d <.text+0x66b9d>
1400679e1:     	movq	%rdx, %r13
1400679e4:     	movq	0x518(%rbp), %rdx
1400679eb:     	movq	0x510(%rbp), %r8
1400679f2:     	movzwl	0x4f8(%rbp), %ecx
1400679f9:     	movzbl	0x4f0(%rbp), %eax
140067a00:     	movq	(%r12), %r9
140067a04:     	movq	0x480(%rbp), %r10
140067a0b:     	movq	%r10, 0x448(%rbp)
140067a12:     	movq	0x478(%rbp), %r10
140067a19:     	movq	%r10, 0x450(%rbp)
140067a20:     	movq	%r9, 0x458(%rbp)
140067a27:     	movzbl	0x508(%rbp), %r9d
140067a2f:     	movb	%r9b, 0x460(%rbp)
140067a36:     	movups	0x38(%r14), %xmm0
140067a3b:     	movups	0x44(%r14), %xmm1
140067a40:     	movups	%xmm1, 0x40c(%rbp)
140067a47:     	movaps	%xmm0, 0x400(%rbp)
140067a4e:     	leaq	0x66(%r14), %r9
140067a52:     	movq	0x56(%r14), %r10
140067a56:     	movq	0x5d(%r14), %r11
140067a5a:     	movq	%r11, 0x46f(%rbp)
140067a61:     	movq	%r10, 0x468(%rbp)
140067a68:     	leaq	0x468(%rbp), %r10
140067a6f:     	movq	%r10, 0x70(%rsp)
140067a74:     	movq	%rdx, 0x68(%rsp)
140067a79:     	movq	%r8, 0x60(%rsp)
140067a7e:     	movq	%r14, 0x58(%rsp)
140067a83:     	leaq	0x448(%rbp), %rdx
140067a8a:     	movq	%rdx, 0x50(%rsp)
140067a8f:     	movq	%r15, 0x48(%rsp)
140067a94:     	movq	%rbp, %rdx
140067a97:     	movq	%rdx, 0x40(%rsp)
140067a9c:     	movq	%rbx, 0x38(%rsp)
140067aa1:     	movq	%r9, 0x30(%rsp)
140067aa6:     	movw	%cx, 0x28(%rsp)
140067aab:     	movb	%al, 0x20(%rsp)
140067aaf:     	leaq	0x428(%rbp), %rcx
140067ab6:     	leaq	0x400(%rbp), %r8
140067abd:     	movq	%rdi, %rdx
140067ac0:     	movq	%r13, %r9
140067ac3:     	callq	0x14007eba0 <.text+0x7dba0>
140067ac8:     	cmpb	$-0x1, 0x428(%rbp)
140067acf:     	je	0x140067ba2 <.text+0x66ba2>
140067ad5:     	cmpb	$0x1, 0x37740(%rdi,%r13)
140067ade:     	jne	0x140067b38 <.text+0x66b38>
140067ae0:     	cmpb	$0x0, 0x37760(%rdi,%r13)
140067ae9:     	jne	0x140067b38 <.text+0x66b38>
140067aeb:     	movb	$0x0, 0x37740(%rdi,%r13)
140067af4:     	decq	0x37788(%rdi)
140067afb:     	leaq	0x37740(%rdi), %rax
140067b02:     	movq	$0x0, 0x43610(%rdi,%r13,8)
140067b0e:     	leaq	(,%r13,8), %rcx
140067b16:     	addq	%r13, %rcx
140067b19:     	leaq	(%rcx,%rcx,2), %rcx
140067b1d:     	addq	%r13, %rcx
140067b20:     	movb	$0x2, 0x36a(%rax,%rcx)
140067b28:     	leaq	(,%r13,2), %rcx
140067b30:     	addq	%r13, %rcx
140067b33:     	movb	$0x2, 0x5d(%rax,%rcx,8)
140067b38:     	movups	0x428(%rbp), %xmm0
140067b3f:     	movups	0x438(%rbp), %xmm1
140067b46:     	movups	%xmm1, 0x10(%rsi)
140067b4a:     	movups	%xmm0, (%rsi)
140067b4d:     	jmp	0x140067b56 <.text+0x66b56>
140067b4f:     	movb	$0xa, (%rsi)
140067b52:     	movq	%rax, 0x8(%rsi)
140067b56:     	addq	$0x508, %rsp            # imm = 0x508
140067b5d:     	popq	%rbx
140067b5e:     	popq	%rdi
140067b5f:     	popq	%rsi
140067b60:     	popq	%r12
140067b62:     	popq	%r13
140067b64:     	popq	%r14
140067b66:     	popq	%r15
140067b68:     	popq	%rbp
140067b69:     	retq
140067b6a:     	addq	%rdi, %rax
140067b6d:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
140067b73:     	movq	0x98(%rax), %rax
140067b7a:     	movq	%rax, 0x478(%rbp)
140067b81:     	movl	$0x1, %eax
140067b86:     	movq	%rax, 0x480(%rbp)
140067b8d:     	movq	%rdi, %rcx
140067b90:     	callq	0x140097f10 <.text+0x96f10>
140067b95:     	testb	$0x1, %al
140067b97:     	jne	0x1400679e1 <.text+0x669e1>
140067b9d:     	movb	$0x9, (%rsi)
140067ba0:     	jmp	0x140067b56 <.text+0x66b56>
140067ba2:     	movq	%r13, 0x8(%rsi)
140067ba6:     	movb	$-0x1, (%rsi)
140067ba9:     	jmp	0x140067b56 <.text+0x66b56>
140067bab:     	leaq	0x1ff07e(%rip), %r9     # 0x140266c30
140067bb2:     	movl	$0x4000, %r8d           # imm = 0x4000
140067bb8:     	xorl	%ecx, %ecx
140067bba:     	callq	0x14024b960 <.text+0x24a960>
140067bbf:     	ud2


D:\CoapticCurrent\packet-request-borrow-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009b300:     	pushq	%rbp
14009b301:     	pushq	%r15
14009b303:     	pushq	%r14
14009b305:     	pushq	%r13
14009b307:     	pushq	%r12
14009b309:     	pushq	%rsi
14009b30a:     	pushq	%rdi
14009b30b:     	pushq	%rbx
14009b30c:     	subq	$0x318, %rsp            # imm = 0x318
14009b313:     	leaq	0x80(%rsp), %rbp
14009b31b:     	movaps	%xmm7, 0x280(%rbp)
14009b322:     	movaps	%xmm6, 0x270(%rbp)
14009b329:     	leaq	0x30(%rcx), %rdx
14009b32d:     	xorl	%r8d, %r8d
14009b330:     	xorl	%r11d, %r11d
14009b333:     	leaq	(%r11,%r11,4), %r10
14009b337:     	shlq	$0x6, %r10
14009b33b:     	addq	%rdx, %r10
14009b33e:     	movq	%r11, %r9
14009b341:     	jmp	0x14009b364 <.text+0x9a364>
14009b343:     	nopw	%cs:(%rax,%rax)
14009b350:     	incq	%r9
14009b353:     	addq	$0x140, %r10            # imm = 0x140
14009b35a:     	cmpq	$0x4, %r9
14009b35e:     	je	0x14009b3ee <.text+0x9a3ee>
14009b364:     	cmpb	$0x1, 0x510(%rcx,%r9)
14009b36d:     	jne	0x14009b350 <.text+0x9a350>
14009b36f:     	movq	-0x30(%r10), %rsi
14009b373:     	cmpq	$0x2, %rsi
14009b377:     	je	0x14009b350 <.text+0x9a350>
14009b379:     	movq	(%r10), %r11
14009b37c:     	cmpl	$0x1, %esi
14009b37f:     	setne	%bl
14009b382:     	testq	%r11, %r11
14009b385:     	sete	%sil
14009b389:     	orb	%bl, %sil
14009b38c:     	cmpb	$0x1, %sil
14009b390:     	je	0x14009b350 <.text+0x9a350>
14009b392:     	movq	0x268(%rbp), %rsi
14009b399:     	cmpq	%rsi, %r11
14009b39c:     	setae	%bl
14009b39f:     	testb	%bl, %r8b
14009b3a2:     	jne	0x14009b3d4 <.text+0x9a3d4>
14009b3a4:     	movq	-0x28(%r10), %rax
14009b3a8:     	movd	-0x4(%r10), %xmm6
14009b3ae:     	movzbl	-0x5(%r10), %edi
14009b3b3:     	movzbl	-0x6(%r10), %r15d
14009b3b8:     	movzwl	-0x8(%r10), %r12d
14009b3bd:     	movl	-0xc(%r10), %r13d
14009b3c1:     	movl	-0x10(%r10), %r14d
14009b3c5:     	movups	-0x20(%r10), %xmm0
14009b3ca:     	movaps	%xmm0, 0x240(%rbp)
14009b3d1:     	movq	%r11, %rsi
14009b3d4:     	movq	%rsi, 0x268(%rbp)
14009b3db:     	leaq	0x1(%r9), %r11
14009b3df:     	movb	$0x1, %r8b
14009b3e2:     	cmpq	$0x3, %r9
14009b3e6:     	jb	0x14009b333 <.text+0x9a333>
14009b3ec:     	jmp	0x14009b3f8 <.text+0x9a3f8>
14009b3ee:     	testb	$0x1, %r8b
14009b3f2:     	je	0x14009b638 <.text+0x9a638>
14009b3f8:     	cmpq	$0x1, %rax
14009b3fc:     	ja	0x14009b454 <.text+0x9a454>
14009b3fe:     	cmpb	$0x1, 0x1e80(%rcx,%rax)
14009b406:     	jne	0x14009b454 <.text+0x9a454>
14009b408:     	cmpb	$0x0, 0x1e82(%rcx,%rax)
14009b410:     	jne	0x14009b454 <.text+0x9a454>
14009b412:     	movb	$0x0, 0x1e80(%rcx,%rax)
14009b41a:     	decq	0x1e78(%rcx)
14009b421:     	leaq	0x14f8(%rcx), %rdx
14009b428:     	movq	$0x0, 0x1df8(%rcx,%rax,8)
14009b434:     	leaq	(%rax,%rax,8), %r8
14009b438:     	leaq	(%r8,%r8,2), %r8
14009b43c:     	addq	%rax, %r8
14009b43f:     	movb	$0x2, 0x95a(%rdx,%r8)
14009b448:     	leaq	(%rax,%rax,2), %rax
14009b44c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009b454:     	movaps	0x240(%rbp), %xmm0
14009b45b:     	movaps	%xmm0, -0x60(%rbp)
14009b45f:     	movl	%r14d, %esi
14009b462:     	movl	%r14d, -0x50(%rbp)
14009b466:     	movl	%r13d, %r14d
14009b469:     	movl	%r13d, -0x4c(%rbp)
14009b46d:     	movl	%r12d, %r13d
14009b470:     	movw	%r12w, -0x48(%rbp)
14009b475:     	movl	%r15d, %r12d
14009b478:     	movb	%r15b, -0x46(%rbp)
14009b47c:     	movl	%edi, %r15d
14009b47f:     	movb	%dil, -0x45(%rbp)
14009b483:     	movd	%xmm6, %edi
14009b487:     	movd	%xmm6, -0x44(%rbp)
14009b48c:     	leaq	-0x60(%rbp), %rdx
14009b490:     	movq	%rcx, 0x260(%rbp)
14009b497:     	callq	0x1402103a0 <.text+0x20f3a0>
14009b49c:     	xorps	%xmm7, %xmm7
14009b49f:     	movaps	%xmm7, 0x250(%rbp)
14009b4a6:     	movb	$0x0, 0x222(%rbp)
14009b4ad:     	movw	%di, 0x220(%rbp)
14009b4b4:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009b4bd:     	movq	$0x0, 0x223(%rbp)
14009b4c8:     	movq	$0x8, 0x200(%rbp)
14009b4d3:     	movq	$0x0, 0x208(%rbp)
14009b4de:     	movq	$0x1, 0x210(%rbp)
14009b4e9:     	movq	$0x0, 0x218(%rbp)
14009b4f4:     	leaq	0x230(%rbp), %rcx
14009b4fb:     	leaq	0x200(%rbp), %rdx
14009b502:     	leaq	0x250(%rbp), %r8
14009b509:     	movl	$0x10, %r9d
14009b50f:     	callq	0x14010dfb0 <.text+0x10cfb0>
14009b514:     	cmpb	$0x0, 0x230(%rbp)
14009b51b:     	jne	0x14009b634 <.text+0x9a634>
14009b521:     	movq	0x238(%rbp), %rdi
14009b528:     	movaps	%xmm7, 0xe0(%rbp)
14009b52f:     	movaps	%xmm7, 0xf0(%rbp)
14009b536:     	movaps	%xmm7, 0x100(%rbp)
14009b53d:     	movaps	%xmm7, 0x110(%rbp)
14009b544:     	movaps	%xmm7, 0x120(%rbp)
14009b54b:     	movaps	%xmm7, 0x130(%rbp)
14009b552:     	movaps	%xmm7, 0x140(%rbp)
14009b559:     	movaps	%xmm7, 0x150(%rbp)
14009b560:     	movaps	%xmm7, 0x160(%rbp)
14009b567:     	movaps	%xmm7, 0x170(%rbp)
14009b56e:     	movaps	%xmm7, 0x180(%rbp)
14009b575:     	movaps	%xmm7, 0x190(%rbp)
14009b57c:     	movaps	%xmm7, 0x1a0(%rbp)
14009b583:     	movaps	%xmm7, 0x1b0(%rbp)
14009b58a:     	movaps	%xmm7, 0x1c0(%rbp)
14009b591:     	movaps	%xmm7, 0x1d0(%rbp)
14009b598:     	movaps	0x240(%rbp), %xmm0
14009b59f:     	movups	%xmm0, 0x1f0(%rbp)
14009b5a6:     	cmpq	$0x11, %rdi
14009b5aa:     	jae	0x14009b65c <.text+0x9a65c>
14009b5b0:     	leaq	0xe0(%rbp), %rbx
14009b5b7:     	leaq	0x250(%rbp), %rdx
14009b5be:     	movq	%rbx, %rcx
14009b5c1:     	movq	%rdi, %r8
14009b5c4:     	callq	0x14024af10 <.text+0x249f10>
14009b5c9:     	movw	%di, 0x1e0(%rbp)
14009b5d0:     	movq	$0x0, -0x60(%rbp)
14009b5d8:     	movups	0x1e8(%rbp), %xmm0
14009b5df:     	movups	%xmm0, -0x58(%rbp)
14009b5e3:     	movq	0x1f8(%rbp), %rax
14009b5ea:     	movq	%rax, -0x48(%rbp)
14009b5ee:     	movl	%esi, -0x40(%rbp)
14009b5f1:     	movl	%r14d, -0x3c(%rbp)
14009b5f5:     	movw	%r13w, -0x38(%rbp)
14009b5fa:     	movb	%r12b, -0x36(%rbp)
14009b5fe:     	movb	%r15b, -0x35(%rbp)
14009b602:     	movd	%xmm6, -0x34(%rbp)
14009b607:     	movq	0x268(%rbp), %rax
14009b60e:     	movq	%rax, -0x30(%rbp)
14009b612:     	leaq	-0x28(%rbp), %rcx
14009b616:     	movl	$0x108, %r8d            # imm = 0x108
14009b61c:     	movq	%rbx, %rdx
14009b61f:     	callq	0x14024af10 <.text+0x249f10>
14009b624:     	leaq	-0x60(%rbp), %rdx
14009b628:     	movq	0x260(%rbp), %rcx
14009b62f:     	callq	0x140210110 <.text+0x20f110>
14009b634:     	movb	$0x1, %al
14009b636:     	jmp	0x14009b63a <.text+0x9a63a>
14009b638:     	xorl	%eax, %eax
14009b63a:     	movaps	0x270(%rbp), %xmm6
14009b641:     	movaps	0x280(%rbp), %xmm7
14009b648:     	addq	$0x318, %rsp            # imm = 0x318
14009b64f:     	popq	%rbx
14009b650:     	popq	%rdi
14009b651:     	popq	%rsi
14009b652:     	popq	%r12
14009b654:     	popq	%r13
14009b656:     	popq	%r14
14009b658:     	popq	%r15
14009b65a:     	popq	%rbp
14009b65b:     	retq
14009b65c:     	leaq	0x1c84f5(%rip), %r9     # 0x140263b58
14009b663:     	movl	$0x10, %r8d
14009b669:     	xorl	%ecx, %ecx
14009b66b:     	movq	%rdi, %rdx
14009b66e:     	callq	0x14024b960 <.text+0x24a960>
14009b673:     	ud2

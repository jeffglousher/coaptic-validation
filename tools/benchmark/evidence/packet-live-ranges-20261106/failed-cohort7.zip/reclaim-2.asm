
D:\CoapticCurrent\packet-selection-match-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140095af0:     	pushq	%rbp
140095af1:     	pushq	%r15
140095af3:     	pushq	%r14
140095af5:     	pushq	%r13
140095af7:     	pushq	%r12
140095af9:     	pushq	%rsi
140095afa:     	pushq	%rdi
140095afb:     	pushq	%rbx
140095afc:     	subq	$0x318, %rsp            # imm = 0x318
140095b03:     	leaq	0x80(%rsp), %rbp
140095b0b:     	movaps	%xmm7, 0x280(%rbp)
140095b12:     	movaps	%xmm6, 0x270(%rbp)
140095b19:     	leaq	0x30(%rcx), %rdx
140095b1d:     	xorl	%r8d, %r8d
140095b20:     	xorl	%r11d, %r11d
140095b23:     	leaq	(%r11,%r11,4), %r10
140095b27:     	shlq	$0x6, %r10
140095b2b:     	addq	%rdx, %r10
140095b2e:     	movq	%r11, %r9
140095b31:     	jmp	0x140095b54 <.text+0x94b54>
140095b33:     	nopw	%cs:(%rax,%rax)
140095b40:     	incq	%r9
140095b43:     	addq	$0x140, %r10            # imm = 0x140
140095b4a:     	cmpq	$0x4, %r9
140095b4e:     	je	0x140095bde <.text+0x94bde>
140095b54:     	cmpb	$0x1, 0x510(%rcx,%r9)
140095b5d:     	jne	0x140095b40 <.text+0x94b40>
140095b5f:     	movq	-0x30(%r10), %rsi
140095b63:     	cmpq	$0x2, %rsi
140095b67:     	je	0x140095b40 <.text+0x94b40>
140095b69:     	movq	(%r10), %r11
140095b6c:     	cmpl	$0x1, %esi
140095b6f:     	setne	%bl
140095b72:     	testq	%r11, %r11
140095b75:     	sete	%sil
140095b79:     	orb	%bl, %sil
140095b7c:     	cmpb	$0x1, %sil
140095b80:     	je	0x140095b40 <.text+0x94b40>
140095b82:     	movq	0x268(%rbp), %rsi
140095b89:     	cmpq	%rsi, %r11
140095b8c:     	setae	%bl
140095b8f:     	testb	%bl, %r8b
140095b92:     	jne	0x140095bc4 <.text+0x94bc4>
140095b94:     	movq	-0x28(%r10), %rax
140095b98:     	movd	-0x4(%r10), %xmm6
140095b9e:     	movzbl	-0x5(%r10), %edi
140095ba3:     	movzbl	-0x6(%r10), %r15d
140095ba8:     	movzwl	-0x8(%r10), %r12d
140095bad:     	movl	-0xc(%r10), %r13d
140095bb1:     	movl	-0x10(%r10), %r14d
140095bb5:     	movups	-0x20(%r10), %xmm0
140095bba:     	movaps	%xmm0, 0x240(%rbp)
140095bc1:     	movq	%r11, %rsi
140095bc4:     	movq	%rsi, 0x268(%rbp)
140095bcb:     	leaq	0x1(%r9), %r11
140095bcf:     	movb	$0x1, %r8b
140095bd2:     	cmpq	$0x3, %r9
140095bd6:     	jb	0x140095b23 <.text+0x94b23>
140095bdc:     	jmp	0x140095be8 <.text+0x94be8>
140095bde:     	testb	$0x1, %r8b
140095be2:     	je	0x140095e28 <.text+0x94e28>
140095be8:     	cmpq	$0x1, %rax
140095bec:     	ja	0x140095c44 <.text+0x94c44>
140095bee:     	cmpb	$0x1, 0x4420(%rcx,%rax)
140095bf6:     	jne	0x140095c44 <.text+0x94c44>
140095bf8:     	cmpb	$0x0, 0x4422(%rcx,%rax)
140095c00:     	jne	0x140095c44 <.text+0x94c44>
140095c02:     	movb	$0x0, 0x4420(%rcx,%rax)
140095c0a:     	decq	0x4418(%rcx)
140095c11:     	leaq	0x3a98(%rcx), %rdx
140095c18:     	movq	$0x0, 0x4398(%rcx,%rax,8)
140095c24:     	leaq	(%rax,%rax,8), %r8
140095c28:     	leaq	(%r8,%r8,2), %r8
140095c2c:     	addq	%rax, %r8
140095c2f:     	movb	$0x2, 0x95a(%rdx,%r8)
140095c38:     	leaq	(%rax,%rax,2), %rax
140095c3c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
140095c44:     	movaps	0x240(%rbp), %xmm0
140095c4b:     	movaps	%xmm0, -0x60(%rbp)
140095c4f:     	movl	%r14d, %esi
140095c52:     	movl	%r14d, -0x50(%rbp)
140095c56:     	movl	%r13d, %r14d
140095c59:     	movl	%r13d, -0x4c(%rbp)
140095c5d:     	movl	%r12d, %r13d
140095c60:     	movw	%r12w, -0x48(%rbp)
140095c65:     	movl	%r15d, %r12d
140095c68:     	movb	%r15b, -0x46(%rbp)
140095c6c:     	movl	%edi, %r15d
140095c6f:     	movb	%dil, -0x45(%rbp)
140095c73:     	movd	%xmm6, %edi
140095c77:     	movd	%xmm6, -0x44(%rbp)
140095c7c:     	leaq	-0x60(%rbp), %rdx
140095c80:     	movq	%rcx, 0x260(%rbp)
140095c87:     	callq	0x1401ff6b0 <.text+0x1fe6b0>
140095c8c:     	xorps	%xmm7, %xmm7
140095c8f:     	movaps	%xmm7, 0x250(%rbp)
140095c96:     	movb	$0x0, 0x222(%rbp)
140095c9d:     	movw	%di, 0x220(%rbp)
140095ca4:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
140095cad:     	movq	$0x0, 0x223(%rbp)
140095cb8:     	movq	$0x8, 0x200(%rbp)
140095cc3:     	movq	$0x0, 0x208(%rbp)
140095cce:     	movq	$0x1, 0x210(%rbp)
140095cd9:     	movq	$0x0, 0x218(%rbp)
140095ce4:     	leaq	0x230(%rbp), %rcx
140095ceb:     	leaq	0x200(%rbp), %rdx
140095cf2:     	leaq	0x250(%rbp), %r8
140095cf9:     	movl	$0x10, %r9d
140095cff:     	callq	0x140106220 <.text+0x105220>
140095d04:     	cmpb	$0x0, 0x230(%rbp)
140095d0b:     	jne	0x140095e24 <.text+0x94e24>
140095d11:     	movq	0x238(%rbp), %rdi
140095d18:     	movaps	%xmm7, 0xe0(%rbp)
140095d1f:     	movaps	%xmm7, 0xf0(%rbp)
140095d26:     	movaps	%xmm7, 0x100(%rbp)
140095d2d:     	movaps	%xmm7, 0x110(%rbp)
140095d34:     	movaps	%xmm7, 0x120(%rbp)
140095d3b:     	movaps	%xmm7, 0x130(%rbp)
140095d42:     	movaps	%xmm7, 0x140(%rbp)
140095d49:     	movaps	%xmm7, 0x150(%rbp)
140095d50:     	movaps	%xmm7, 0x160(%rbp)
140095d57:     	movaps	%xmm7, 0x170(%rbp)
140095d5e:     	movaps	%xmm7, 0x180(%rbp)
140095d65:     	movaps	%xmm7, 0x190(%rbp)
140095d6c:     	movaps	%xmm7, 0x1a0(%rbp)
140095d73:     	movaps	%xmm7, 0x1b0(%rbp)
140095d7a:     	movaps	%xmm7, 0x1c0(%rbp)
140095d81:     	movaps	%xmm7, 0x1d0(%rbp)
140095d88:     	movaps	0x240(%rbp), %xmm0
140095d8f:     	movups	%xmm0, 0x1f0(%rbp)
140095d96:     	cmpq	$0x11, %rdi
140095d9a:     	jae	0x140095e4c <.text+0x94e4c>
140095da0:     	leaq	0xe0(%rbp), %rbx
140095da7:     	leaq	0x250(%rbp), %rdx
140095dae:     	movq	%rbx, %rcx
140095db1:     	movq	%rdi, %r8
140095db4:     	callq	0x140239710 <.text+0x238710>
140095db9:     	movw	%di, 0x1e0(%rbp)
140095dc0:     	movq	$0x0, -0x60(%rbp)
140095dc8:     	movups	0x1e8(%rbp), %xmm0
140095dcf:     	movups	%xmm0, -0x58(%rbp)
140095dd3:     	movq	0x1f8(%rbp), %rax
140095dda:     	movq	%rax, -0x48(%rbp)
140095dde:     	movl	%esi, -0x40(%rbp)
140095de1:     	movl	%r14d, -0x3c(%rbp)
140095de5:     	movw	%r13w, -0x38(%rbp)
140095dea:     	movb	%r12b, -0x36(%rbp)
140095dee:     	movb	%r15b, -0x35(%rbp)
140095df2:     	movd	%xmm6, -0x34(%rbp)
140095df7:     	movq	0x268(%rbp), %rax
140095dfe:     	movq	%rax, -0x30(%rbp)
140095e02:     	leaq	-0x28(%rbp), %rcx
140095e06:     	movl	$0x108, %r8d            # imm = 0x108
140095e0c:     	movq	%rbx, %rdx
140095e0f:     	callq	0x140239710 <.text+0x238710>
140095e14:     	leaq	-0x60(%rbp), %rdx
140095e18:     	movq	0x260(%rbp), %rcx
140095e1f:     	callq	0x1401ff420 <.text+0x1fe420>
140095e24:     	movb	$0x1, %al
140095e26:     	jmp	0x140095e2a <.text+0x94e2a>
140095e28:     	xorl	%eax, %eax
140095e2a:     	movaps	0x270(%rbp), %xmm6
140095e31:     	movaps	0x280(%rbp), %xmm7
140095e38:     	addq	$0x318, %rsp            # imm = 0x318
140095e3f:     	popq	%rbx
140095e40:     	popq	%rdi
140095e41:     	popq	%rsi
140095e42:     	popq	%r12
140095e44:     	popq	%r13
140095e46:     	popq	%r14
140095e48:     	popq	%r15
140095e4a:     	popq	%rbp
140095e4b:     	retq
140095e4c:     	leaq	0x1bbd15(%rip), %r9     # 0x140251b68
140095e53:     	movl	$0x10, %r8d
140095e59:     	xorl	%ecx, %ecx
140095e5b:     	movq	%rdi, %rdx
140095e5e:     	callq	0x14023a160 <.text+0x239160>
140095e63:     	ud2

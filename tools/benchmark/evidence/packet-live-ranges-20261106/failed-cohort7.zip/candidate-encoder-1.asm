
D:\CoapticCurrent\packet-selection-match-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140064280:     	pushq	%rbp
140064281:     	pushq	%r15
140064283:     	pushq	%r14
140064285:     	pushq	%r13
140064287:     	pushq	%r12
140064289:     	pushq	%rsi
14006428a:     	pushq	%rdi
14006428b:     	pushq	%rbx
14006428c:     	subq	$0x508, %rsp            # imm = 0x508
140064293:     	leaq	0x80(%rsp), %rbp
14006429b:     	movq	%r9, %rbx
14006429e:     	movq	%r8, %r14
1400642a1:     	movq	%rdx, %rdi
1400642a4:     	movq	%rcx, %rsi
1400642a7:     	movq	0x500(%rbp), %r12
1400642ae:     	movq	%rbp, %rcx
1400642b1:     	movl	$0x400, %r8d            # imm = 0x400
1400642b7:     	xorl	%edx, %edx
1400642b9:     	callq	0x140239722 <.text+0x238722>
1400642be:     	movq	0x8(%r12), %r13
1400642c3:     	movl	$0x3, %eax
1400642c8:     	cmpq	$0x3, %r13
1400642cc:     	ja	0x1400644ef <.text+0x634ef>
1400642d2:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
1400642db:     	jne	0x1400644ef <.text+0x634ef>
1400642e1:     	movq	0x2b750(%rdi,%r13,8), %rdx
1400642e9:     	cmpq	$0x4001, %rdx           # imm = 0x4001
1400642f0:     	jae	0x14006454b <.text+0x6354b>
1400642f6:     	movq	0x10(%r12), %rcx
1400642fb:     	movq	0x18(%r12), %r15
140064300:     	movq	%r15, %r8
140064303:     	movl	$0xb, %eax
140064308:     	addq	%rcx, %r8
14006430b:     	jb	0x1400644ef <.text+0x634ef>
140064311:     	cmpq	$0x400, %r15            # imm = 0x400
140064318:     	ja	0x1400644ef <.text+0x634ef>
14006431e:     	cmpq	%rdx, %r8
140064321:     	ja	0x1400644ef <.text+0x634ef>
140064327:     	movq	%r13, %rax
14006432a:     	shlq	$0xe, %rax
14006432e:     	leaq	(%rdi,%rax), %rdx
140064332:     	addq	$0x1b750, %rdx          # imm = 0x1B750
140064339:     	addq	%rcx, %rdx
14006433c:     	movq	%rbp, %rcx
14006433f:     	movq	%r15, %r8
140064342:     	callq	0x140239710 <.text+0x238710>
140064347:     	cmpb	$0x0, 0x508(%rbp)
14006434e:     	je	0x140064366 <.text+0x63366>
140064350:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
140064357:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
140064360:     	jne	0x14006450a <.text+0x6350a>
140064366:     	movq	$0x0, 0x480(%rbp)
140064371:     	movq	%rdi, %rcx
140064374:     	callq	0x140092380 <.text+0x91380>
140064379:     	testb	$0x1, %al
14006437b:     	je	0x14006453d <.text+0x6353d>
140064381:     	movq	%rdx, %r13
140064384:     	movq	0x518(%rbp), %rdx
14006438b:     	movq	0x510(%rbp), %r8
140064392:     	movzwl	0x4f8(%rbp), %ecx
140064399:     	movzbl	0x4f0(%rbp), %eax
1400643a0:     	movq	(%r12), %r9
1400643a4:     	movq	0x480(%rbp), %r10
1400643ab:     	movq	%r10, 0x448(%rbp)
1400643b2:     	movq	0x478(%rbp), %r10
1400643b9:     	movq	%r10, 0x450(%rbp)
1400643c0:     	movq	%r9, 0x458(%rbp)
1400643c7:     	movzbl	0x508(%rbp), %r9d
1400643cf:     	movb	%r9b, 0x460(%rbp)
1400643d6:     	movups	0x38(%r14), %xmm0
1400643db:     	movups	0x44(%r14), %xmm1
1400643e0:     	movups	%xmm1, 0x40c(%rbp)
1400643e7:     	movaps	%xmm0, 0x400(%rbp)
1400643ee:     	leaq	0x66(%r14), %r9
1400643f2:     	movq	0x56(%r14), %r10
1400643f6:     	movq	0x5d(%r14), %r11
1400643fa:     	movq	%r11, 0x46f(%rbp)
140064401:     	movq	%r10, 0x468(%rbp)
140064408:     	leaq	0x468(%rbp), %r10
14006440f:     	movq	%r10, 0x70(%rsp)
140064414:     	movq	%rdx, 0x68(%rsp)
140064419:     	movq	%r8, 0x60(%rsp)
14006441e:     	movq	%r14, 0x58(%rsp)
140064423:     	leaq	0x448(%rbp), %rdx
14006442a:     	movq	%rdx, 0x50(%rsp)
14006442f:     	movq	%r15, 0x48(%rsp)
140064434:     	movq	%rbp, %rdx
140064437:     	movq	%rdx, 0x40(%rsp)
14006443c:     	movq	%rbx, 0x38(%rsp)
140064441:     	movq	%r9, 0x30(%rsp)
140064446:     	movw	%cx, 0x28(%rsp)
14006444b:     	movb	%al, 0x20(%rsp)
14006444f:     	leaq	0x428(%rbp), %rcx
140064456:     	leaq	0x400(%rbp), %r8
14006445d:     	movq	%rdi, %rdx
140064460:     	movq	%r13, %r9
140064463:     	callq	0x14007a870 <.text+0x79870>
140064468:     	cmpb	$-0x1, 0x428(%rbp)
14006446f:     	je	0x140064542 <.text+0x63542>
140064475:     	cmpb	$0x1, 0x37740(%rdi,%r13)
14006447e:     	jne	0x1400644d8 <.text+0x634d8>
140064480:     	cmpb	$0x0, 0x37760(%rdi,%r13)
140064489:     	jne	0x1400644d8 <.text+0x634d8>
14006448b:     	movb	$0x0, 0x37740(%rdi,%r13)
140064494:     	decq	0x37788(%rdi)
14006449b:     	leaq	0x37740(%rdi), %rax
1400644a2:     	movq	$0x0, 0x43610(%rdi,%r13,8)
1400644ae:     	leaq	(,%r13,8), %rcx
1400644b6:     	addq	%r13, %rcx
1400644b9:     	leaq	(%rcx,%rcx,2), %rcx
1400644bd:     	addq	%r13, %rcx
1400644c0:     	movb	$0x2, 0x36a(%rax,%rcx)
1400644c8:     	leaq	(,%r13,2), %rcx
1400644d0:     	addq	%r13, %rcx
1400644d3:     	movb	$0x2, 0x5d(%rax,%rcx,8)
1400644d8:     	movups	0x428(%rbp), %xmm0
1400644df:     	movups	0x438(%rbp), %xmm1
1400644e6:     	movups	%xmm1, 0x10(%rsi)
1400644ea:     	movups	%xmm0, (%rsi)
1400644ed:     	jmp	0x1400644f6 <.text+0x634f6>
1400644ef:     	movb	$0xa, (%rsi)
1400644f2:     	movq	%rax, 0x8(%rsi)
1400644f6:     	addq	$0x508, %rsp            # imm = 0x508
1400644fd:     	popq	%rbx
1400644fe:     	popq	%rdi
1400644ff:     	popq	%rsi
140064500:     	popq	%r12
140064502:     	popq	%r13
140064504:     	popq	%r14
140064506:     	popq	%r15
140064508:     	popq	%rbp
140064509:     	retq
14006450a:     	addq	%rdi, %rax
14006450d:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
140064513:     	movq	0x98(%rax), %rax
14006451a:     	movq	%rax, 0x478(%rbp)
140064521:     	movl	$0x1, %eax
140064526:     	movq	%rax, 0x480(%rbp)
14006452d:     	movq	%rdi, %rcx
140064530:     	callq	0x140092380 <.text+0x91380>
140064535:     	testb	$0x1, %al
140064537:     	jne	0x140064381 <.text+0x63381>
14006453d:     	movb	$0x9, (%rsi)
140064540:     	jmp	0x1400644f6 <.text+0x634f6>
140064542:     	movq	%r13, 0x8(%rsi)
140064546:     	movb	$-0x1, (%rsi)
140064549:     	jmp	0x1400644f6 <.text+0x634f6>
14006454b:     	leaq	0x1f06de(%rip), %r9     # 0x140254c30
140064552:     	movl	$0x4000, %r8d           # imm = 0x4000
140064558:     	xorl	%ecx, %ecx
14006455a:     	callq	0x14023a160 <.text+0x239160>
14006455f:     	ud2

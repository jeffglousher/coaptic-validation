
D:\CoapticCurrent\packet-selection-match-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140095770:     	pushq	%rbp
140095771:     	pushq	%r15
140095773:     	pushq	%r14
140095775:     	pushq	%r13
140095777:     	pushq	%r12
140095779:     	pushq	%rsi
14009577a:     	pushq	%rdi
14009577b:     	pushq	%rbx
14009577c:     	subq	$0x318, %rsp            # imm = 0x318
140095783:     	leaq	0x80(%rsp), %rbp
14009578b:     	movaps	%xmm7, 0x280(%rbp)
140095792:     	movaps	%xmm6, 0x270(%rbp)
140095799:     	leaq	0x30(%rcx), %rdx
14009579d:     	xorl	%r8d, %r8d
1400957a0:     	xorl	%r11d, %r11d
1400957a3:     	leaq	(%r11,%r11,4), %r10
1400957a7:     	shlq	$0x6, %r10
1400957ab:     	addq	%rdx, %r10
1400957ae:     	movq	%r11, %r9
1400957b1:     	jmp	0x1400957d4 <.text+0x947d4>
1400957b3:     	nopw	%cs:(%rax,%rax)
1400957c0:     	incq	%r9
1400957c3:     	addq	$0x140, %r10            # imm = 0x140
1400957ca:     	cmpq	$0x4, %r9
1400957ce:     	je	0x14009585e <.text+0x9485e>
1400957d4:     	cmpb	$0x1, 0x510(%rcx,%r9)
1400957dd:     	jne	0x1400957c0 <.text+0x947c0>
1400957df:     	movq	-0x30(%r10), %rsi
1400957e3:     	cmpq	$0x2, %rsi
1400957e7:     	je	0x1400957c0 <.text+0x947c0>
1400957e9:     	movq	(%r10), %r11
1400957ec:     	cmpl	$0x1, %esi
1400957ef:     	setne	%bl
1400957f2:     	testq	%r11, %r11
1400957f5:     	sete	%sil
1400957f9:     	orb	%bl, %sil
1400957fc:     	cmpb	$0x1, %sil
140095800:     	je	0x1400957c0 <.text+0x947c0>
140095802:     	movq	0x268(%rbp), %rsi
140095809:     	cmpq	%rsi, %r11
14009580c:     	setae	%bl
14009580f:     	testb	%bl, %r8b
140095812:     	jne	0x140095844 <.text+0x94844>
140095814:     	movq	-0x28(%r10), %rax
140095818:     	movd	-0x4(%r10), %xmm6
14009581e:     	movzbl	-0x5(%r10), %edi
140095823:     	movzbl	-0x6(%r10), %r15d
140095828:     	movzwl	-0x8(%r10), %r12d
14009582d:     	movl	-0xc(%r10), %r13d
140095831:     	movl	-0x10(%r10), %r14d
140095835:     	movups	-0x20(%r10), %xmm0
14009583a:     	movaps	%xmm0, 0x240(%rbp)
140095841:     	movq	%r11, %rsi
140095844:     	movq	%rsi, 0x268(%rbp)
14009584b:     	leaq	0x1(%r9), %r11
14009584f:     	movb	$0x1, %r8b
140095852:     	cmpq	$0x3, %r9
140095856:     	jb	0x1400957a3 <.text+0x947a3>
14009585c:     	jmp	0x140095868 <.text+0x94868>
14009585e:     	testb	$0x1, %r8b
140095862:     	je	0x140095aa8 <.text+0x94aa8>
140095868:     	cmpq	$0x1, %rax
14009586c:     	ja	0x1400958c4 <.text+0x948c4>
14009586e:     	cmpb	$0x1, 0x1e80(%rcx,%rax)
140095876:     	jne	0x1400958c4 <.text+0x948c4>
140095878:     	cmpb	$0x0, 0x1e82(%rcx,%rax)
140095880:     	jne	0x1400958c4 <.text+0x948c4>
140095882:     	movb	$0x0, 0x1e80(%rcx,%rax)
14009588a:     	decq	0x1e78(%rcx)
140095891:     	leaq	0x14f8(%rcx), %rdx
140095898:     	movq	$0x0, 0x1df8(%rcx,%rax,8)
1400958a4:     	leaq	(%rax,%rax,8), %r8
1400958a8:     	leaq	(%r8,%r8,2), %r8
1400958ac:     	addq	%rax, %r8
1400958af:     	movb	$0x2, 0x95a(%rdx,%r8)
1400958b8:     	leaq	(%rax,%rax,2), %rax
1400958bc:     	movb	$0x2, 0x91d(%rdx,%rax,8)
1400958c4:     	movaps	0x240(%rbp), %xmm0
1400958cb:     	movaps	%xmm0, -0x60(%rbp)
1400958cf:     	movl	%r14d, %esi
1400958d2:     	movl	%r14d, -0x50(%rbp)
1400958d6:     	movl	%r13d, %r14d
1400958d9:     	movl	%r13d, -0x4c(%rbp)
1400958dd:     	movl	%r12d, %r13d
1400958e0:     	movw	%r12w, -0x48(%rbp)
1400958e5:     	movl	%r15d, %r12d
1400958e8:     	movb	%r15b, -0x46(%rbp)
1400958ec:     	movl	%edi, %r15d
1400958ef:     	movb	%dil, -0x45(%rbp)
1400958f3:     	movd	%xmm6, %edi
1400958f7:     	movd	%xmm6, -0x44(%rbp)
1400958fc:     	leaq	-0x60(%rbp), %rdx
140095900:     	movq	%rcx, 0x260(%rbp)
140095907:     	callq	0x1401ff6b0 <.text+0x1fe6b0>
14009590c:     	xorps	%xmm7, %xmm7
14009590f:     	movaps	%xmm7, 0x250(%rbp)
140095916:     	movb	$0x0, 0x222(%rbp)
14009591d:     	movw	%di, 0x220(%rbp)
140095924:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009592d:     	movq	$0x0, 0x223(%rbp)
140095938:     	movq	$0x8, 0x200(%rbp)
140095943:     	movq	$0x0, 0x208(%rbp)
14009594e:     	movq	$0x1, 0x210(%rbp)
140095959:     	movq	$0x0, 0x218(%rbp)
140095964:     	leaq	0x230(%rbp), %rcx
14009596b:     	leaq	0x200(%rbp), %rdx
140095972:     	leaq	0x250(%rbp), %r8
140095979:     	movl	$0x10, %r9d
14009597f:     	callq	0x140106220 <.text+0x105220>
140095984:     	cmpb	$0x0, 0x230(%rbp)
14009598b:     	jne	0x140095aa4 <.text+0x94aa4>
140095991:     	movq	0x238(%rbp), %rdi
140095998:     	movaps	%xmm7, 0xe0(%rbp)
14009599f:     	movaps	%xmm7, 0xf0(%rbp)
1400959a6:     	movaps	%xmm7, 0x100(%rbp)
1400959ad:     	movaps	%xmm7, 0x110(%rbp)
1400959b4:     	movaps	%xmm7, 0x120(%rbp)
1400959bb:     	movaps	%xmm7, 0x130(%rbp)
1400959c2:     	movaps	%xmm7, 0x140(%rbp)
1400959c9:     	movaps	%xmm7, 0x150(%rbp)
1400959d0:     	movaps	%xmm7, 0x160(%rbp)
1400959d7:     	movaps	%xmm7, 0x170(%rbp)
1400959de:     	movaps	%xmm7, 0x180(%rbp)
1400959e5:     	movaps	%xmm7, 0x190(%rbp)
1400959ec:     	movaps	%xmm7, 0x1a0(%rbp)
1400959f3:     	movaps	%xmm7, 0x1b0(%rbp)
1400959fa:     	movaps	%xmm7, 0x1c0(%rbp)
140095a01:     	movaps	%xmm7, 0x1d0(%rbp)
140095a08:     	movaps	0x240(%rbp), %xmm0
140095a0f:     	movups	%xmm0, 0x1f0(%rbp)
140095a16:     	cmpq	$0x11, %rdi
140095a1a:     	jae	0x140095acc <.text+0x94acc>
140095a20:     	leaq	0xe0(%rbp), %rbx
140095a27:     	leaq	0x250(%rbp), %rdx
140095a2e:     	movq	%rbx, %rcx
140095a31:     	movq	%rdi, %r8
140095a34:     	callq	0x140239710 <.text+0x238710>
140095a39:     	movw	%di, 0x1e0(%rbp)
140095a40:     	movq	$0x0, -0x60(%rbp)
140095a48:     	movups	0x1e8(%rbp), %xmm0
140095a4f:     	movups	%xmm0, -0x58(%rbp)
140095a53:     	movq	0x1f8(%rbp), %rax
140095a5a:     	movq	%rax, -0x48(%rbp)
140095a5e:     	movl	%esi, -0x40(%rbp)
140095a61:     	movl	%r14d, -0x3c(%rbp)
140095a65:     	movw	%r13w, -0x38(%rbp)
140095a6a:     	movb	%r12b, -0x36(%rbp)
140095a6e:     	movb	%r15b, -0x35(%rbp)
140095a72:     	movd	%xmm6, -0x34(%rbp)
140095a77:     	movq	0x268(%rbp), %rax
140095a7e:     	movq	%rax, -0x30(%rbp)
140095a82:     	leaq	-0x28(%rbp), %rcx
140095a86:     	movl	$0x108, %r8d            # imm = 0x108
140095a8c:     	movq	%rbx, %rdx
140095a8f:     	callq	0x140239710 <.text+0x238710>
140095a94:     	leaq	-0x60(%rbp), %rdx
140095a98:     	movq	0x260(%rbp), %rcx
140095a9f:     	callq	0x1401ff420 <.text+0x1fe420>
140095aa4:     	movb	$0x1, %al
140095aa6:     	jmp	0x140095aaa <.text+0x94aaa>
140095aa8:     	xorl	%eax, %eax
140095aaa:     	movaps	0x270(%rbp), %xmm6
140095ab1:     	movaps	0x280(%rbp), %xmm7
140095ab8:     	addq	$0x318, %rsp            # imm = 0x318
140095abf:     	popq	%rbx
140095ac0:     	popq	%rdi
140095ac1:     	popq	%rsi
140095ac2:     	popq	%r12
140095ac4:     	popq	%r13
140095ac6:     	popq	%r14
140095ac8:     	popq	%r15
140095aca:     	popq	%rbp
140095acb:     	retq
140095acc:     	leaq	0x1bc095(%rip), %r9     # 0x140251b68
140095ad3:     	movl	$0x10, %r8d
140095ad9:     	xorl	%ecx, %ecx
140095adb:     	movq	%rdi, %rdx
140095ade:     	callq	0x14023a160 <.text+0x239160>
140095ae3:     	ud2

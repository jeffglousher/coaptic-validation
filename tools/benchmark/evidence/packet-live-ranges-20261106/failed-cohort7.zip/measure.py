from pathlib import Path
import subprocess,json,hashlib,statistics,math,time,psutil
ROOT=Path(__file__).resolve().parent
CELLS=[('ordinary',p,s,m,b) for p in ['small-device','service-fixed','service-allocated'] for s in ['unprotected','oscore'] for m in ['sync','async'] for b in ([32] if p=='small-device' else [1024,16384])]
CELLS += [('retained',p,s,m,11264) for p in ['fixed','allocated'] for s in ['unprotected','oscore'] for m in ['sync','async']]
BIN={('A','ordinary'):Path('D:/CoapticCurrent/phase-sharing-static-20261106/B/dispatch-probe.exe'),('A','retained'):Path('D:/CoapticCurrent/phase-sharing-static-20261106/B/retained-probe.exe'),('B','ordinary'):ROOT/'B/dispatch-probe.exe',('B','retained'):ROOT/'B/retained-probe.exe'}
def run(arm,cell,count,label):
 kind,p,s,m,size=cell
 env=dict(__import__('os').environ);env.pop('COAPTIC_DISPATCH_ASYNC',None);env['COAPTIC_EXPIRY_PROBE']='steady'
 if m=='async':env['COAPTIC_DISPATCH_ASYNC']='1'
 if kind=='ordinary':cmd=[str(BIN[arm,kind]),str(count),s,'--'+p]+([] if p=='small-device' else [str(size)])
 else:cmd=[str(BIN[arm,kind]),str(count),s,m,p]
 with (ROOT/(label+'.json')).open('wb') as out,(ROOT/(label+'.stderr')).open('wb') as err:
  started=time.monotonic();child=subprocess.Popen(cmd,env=env,stdout=out,stderr=err)
  observation={'label':label,'pid':child.pid}
  try:
   observation['exit_code']=child.wait(timeout=15)
  except subprocess.TimeoutExpired:
   observation['timeout']=True;observation['exit_code']=child.poll()
   try:
    q=psutil.Process(child.pid);observation['child']={'status':q.status(),'cpu':list(q.cpu_times()),'threads':q.num_threads(),'rss':q.memory_info().rss}
   except psutil.NoSuchProcess:observation['child']='exited'
   if observation['exit_code'] is None:
    child.kill();child.wait();raise
  finally:
   observation['seconds']=time.monotonic()-started
   observation['stdout_bytes']=(ROOT/(label+'.json')).stat().st_size
   with (ROOT/'process-exits.jsonl').open('a',encoding='utf-8') as events:events.write(json.dumps(observation)+'\n')
 assert observation['exit_code']==0,(label,(ROOT/(label+'.stderr')).read_text())
 x=json.loads((ROOT/(label+'.json')).read_bytes());assert x['operations']==count and x['security']==s and x['payload_bytes']==size
 if kind=='retained':
  assert x['mode']==m and x['storage']==p and x['verified']==count+128 and x['requests_per_operation']==2 and x['data_packets_per_operation']==11
  values=x['cycles']
 elif p=='small-device':
  assert x['black_box'] and x['dedup']==4;values=x['latencies_cycles']
 else:
  assert x['black_box'] and x['verified']==count+128 and x['server_poll_counts']==[(size+1023)//1024]*count and x['expiry_probe']=='steady'
  assert x['server_capacities']['dedup']==64;values=x['server_poll_cpu_cycles_sum']
 assert len(values)==count and all(type(v)==int and v>0 for v in values)
 return statistics.mean(values),x
def name(cell):return '-'.join(map(str,cell))
assert not (ROOT/'measurement.json').exists(),'Never replace an observed cohort'
method={'baseline':'fd7d18a72f795779e352443ebdeef9533be7fb27','candidate':'eefc387d7ba8fc3a3da5585dc27ccf47a41ab9db','cells':CELLS,'operations':'8192 ordinary32/1024;1024 ordinary16384 and retained11264','warmup':128,'process_pairs':64,'orders':['AB','BA','BA','AB']*16,'cpu':0,'binaries':{a+'-'+k:hashlib.sha256(v.read_bytes()).hexdigest() for (a,k),v in BIN.items()},'primary':'Equal weight complete-App process-mean ratios; separate original20 ordinary controls and all28 groups. User-approved prospective memory-improvement route: both sync/async upper95<=1.02 in original20 AND all28; every cell upper95<=1.02. Historical failures retain original decisions. RetainedQ groups reported separately. Matched memory reduction required independently.','limits':'In-memory complete server App CPU work, actual sync poll and native async wait+progress; client preparation/authentication/verification outside clock. Not sockets, executor latency, peak memory or hardware. All previous failed cohorts retained.','memory_gate':'Configured capacity fields identical. Only declared App-inline/pool-requested-heap memory owners may shrink, none may grow; every ordinary server inline+heap sum must strictly shrink. All other ledger fields equal. Retained fixed App must shrink; allocated inline may remain equal (heap covered by ordinary ledger). New prospective noninferiority gate declared in METHOD-BEFORE.json per user direction; no historical relabeling.', 'output_capture':'Direct stdout/stderr files; parse after process exit; avoids Python reader threads. Original incomplete pipe-capture cohort retained without verdict.','interval':'Student-t df63 one-sided95 percent on64 paired log ratios; geometric means, no trimming or discarded measured samples.'}
method['memory_gate']='Prospective lifetime-only rule: App/pool owners may remain equal, none grow; all other ledger/capacity/allocation fields identical. Selected complete futures and emitted frames nongrowing; both Service progress futures strictly shrink, verified before timing. Prior failures unchanged.'
memory_check=json.loads((ROOT/'memory-preflight.json').read_text())
source=json.loads((ROOT/'source-verification.json').read_text())
before=json.loads((ROOT/'METHOD-BEFORE.json').read_text())
assert memory_check['memory_accepted']
assert memory_check['source']==source['source']==before['candidate']==method['candidate']
assert source['baseline']==before['baseline']==method['baseline']
for filename,digest in json.loads((ROOT/'baseline-reuse.json').read_text())['binaries'].items():
 assert method['binaries']['A-'+('retained' if filename.startswith('retained') else 'ordinary')]==digest
method['output_capture']='Direct stdout/stderr files parsed after process exit; all observations retained without replacement.'
preflight=json.loads((ROOT/'preflight-host.json').read_text());assert all(v['candidate']<=v['baseline'] for v in preflight['future_rows']);assert all(v['candidate']<v['baseline'] for v in preflight['future_rows'] if v['owner'].startswith('Service'))
(ROOT/'METHOD.json').write_text(json.dumps(method,indent=2),encoding='utf-8')
process=psutil.Process();affinity=process.cpu_affinity();process.cpu_affinity([0]);rows=[];start=time.monotonic()
try:
 for cell in CELLS:
  _,a=run('A',cell,8,'qualify-A-'+name(cell));_,b=run('B',cell,8,'qualify-B-'+name(cell))
  for key in ['server_capacities','client_capacities','routes','calls','deferred','security_requests','associations','rx_slots','rx_datagram_bytes','tx_slots','tx_datagram_bytes','dedup','observe','rx_body_slots','tx_body_slots','blockwise']:
   if key in a:assert a[key]==b[key],(cell,key)
  if 'memory' in a:
   assert set(a['memory'])==set(b['memory'])
   reducible={'app_including_transport_inline_bytes','server_app_including_transport_inline_bytes','server_pool_requested_heap_bytes','client_app_including_transport_inline_bytes','client_pool_requested_heap_bytes'}
   for key,value in a['memory'].items():
    if key in reducible:assert type(b['memory'][key]) is int and 0<=b['memory'][key]<=value,(cell,key)
    else:assert b['memory'][key]==value,(cell,key)
   if cell[1]=='small-device':
    assert b['memory']['app_including_transport_inline_bytes']<=a['memory']['app_including_transport_inline_bytes']
   else:
    keys=['server_app_including_transport_inline_bytes','server_pool_requested_heap_bytes']
    assert sum(b['memory'][k] for k in keys)<=sum(a['memory'][k] for k in keys)
  if 'app_inline_bytes' in a:
   assert b['app_inline_bytes']<=a['app_inline_bytes']
   if cell[1]=='fixed':assert b['app_inline_bytes']<=a['app_inline_bytes']
 for pair,order in enumerate(method['orders']):
  for cell in CELLS:
   means={}
   for arm in order:
    assert time.monotonic()-start<1200
    means[arm],_=run(arm,cell,8192 if cell[4] in [32,1024] else 1024,f'measure-{pair}-'+name(cell)+'-'+arm)
   rows.append(dict(pair=pair,cell=cell,means=means,ratio=means['B']/means['A']))
 def interval(values):
  logs=list(map(math.log,values));mean=statistics.mean(logs)
  return dict(ratio=math.exp(mean),upper95=math.exp(mean+1.67*statistics.stdev(logs)/math.sqrt(len(logs))))
 summary=[dict(cell=cell,**interval([r['ratio'] for r in rows if r['cell']==cell])) for cell in CELLS]
 groups={}
 for kind in ['ordinary','retained','all']:
  for mode in ['sync','async','all']:
   groups[kind+'-'+mode]=interval([math.exp(statistics.mean(math.log(r['ratio']) for r in rows if r['pair']==pair and (kind=='all' or r['cell'][0]==kind) and (mode=='all' or r['cell'][3]==mode))) for pair in range(64)])
 failed=[r for r in summary if r['upper95']>1.02]
 accepted=not failed and all(groups[k+'-'+m]['upper95']<=1.02 for k in ['ordinary','all'] for m in ['sync','async'])
 result=dict(status='complete',runtime_accepted=accepted,rows=rows,summary=summary,groups=groups,failed_point_guards=failed,seconds=time.monotonic()-start)
 (ROOT/'measurement.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 print(json.dumps(dict(runtime_accepted=accepted,groups=groups,failed_point_guards=failed),indent=2))
except BaseException as e:
 (ROOT/'measurement.json').write_text(json.dumps(dict(status='failed',error=str(e),rows=rows),indent=2),encoding='utf-8');raise
finally:process.cpu_affinity(affinity)

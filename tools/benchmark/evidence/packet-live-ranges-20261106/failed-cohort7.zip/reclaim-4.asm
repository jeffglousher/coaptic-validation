
D:\CoapticCurrent\packet-selection-match-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140096230:     	pushq	%rbp
140096231:     	pushq	%r15
140096233:     	pushq	%r14
140096235:     	pushq	%r13
140096237:     	pushq	%r12
140096239:     	pushq	%rsi
14009623a:     	pushq	%rdi
14009623b:     	pushq	%rbx
14009623c:     	subq	$0x318, %rsp            # imm = 0x318
140096243:     	leaq	0x80(%rsp), %rbp
14009624b:     	movaps	%xmm7, 0x280(%rbp)
140096252:     	movdqa	%xmm6, 0x270(%rbp)
14009625a:     	movq	0xe8(%rcx), %r8
140096261:     	testq	%r8, %r8
140096264:     	je	0x140096644 <.text+0x95644>
14009626a:     	movq	0x88(%rcx), %r11
140096271:     	movq	0xe0(%rcx), %rdx
140096278:     	movq	0xc8(%rcx), %rax
14009627f:     	movq	0xd0(%rcx), %r9
140096286:     	leaq	0x30(%rax), %rsi
14009628a:     	xorl	%ebx, %ebx
14009628c:     	xorl	%edi, %edi
14009628e:     	leaq	(%rdi,%rdi,4), %r12
140096292:     	shlq	$0x6, %r12
140096296:     	addq	%rsi, %r12
140096299:     	jmp	0x1400962b3 <.text+0x952b3>
14009629b:     	nopl	(%rax,%rax)
1400962a0:     	incq	%rdi
1400962a3:     	addq	$0x140, %r12            # imm = 0x140
1400962aa:     	cmpq	%r8, %rdi
1400962ad:     	jae	0x14009637c <.text+0x9537c>
1400962b3:     	cmpq	%r9, %rdi
1400962b6:     	setb	%r15b
1400962ba:     	andb	(%rdx,%rdi), %r15b
1400962be:     	cmpb	$0x1, %r15b
1400962c2:     	jne	0x1400962a0 <.text+0x952a0>
1400962c4:     	movq	-0x30(%r12), %r15
1400962c9:     	cmpq	$0x2, %r15
1400962cd:     	je	0x1400962a0 <.text+0x952a0>
1400962cf:     	movq	(%r12), %r13
1400962d3:     	cmpl	$0x1, %r15d
1400962d7:     	setne	%r15b
1400962db:     	testq	%r13, %r13
1400962de:     	sete	%r10b
1400962e2:     	orb	%r15b, %r10b
1400962e5:     	cmpb	$0x1, %r10b
1400962e9:     	je	0x1400962a0 <.text+0x952a0>
1400962eb:     	movq	0x260(%rbp), %r15
1400962f2:     	cmpq	%r15, %r13
1400962f5:     	setae	%r10b
1400962f9:     	testb	%r10b, %bl
1400962fc:     	jne	0x140096365 <.text+0x95365>
1400962fe:     	movq	-0x28(%r12), %r10
140096303:     	movq	%r10, 0x250(%rbp)
14009630a:     	movq	-0x20(%r12), %r10
14009630f:     	movq	%r10, 0x248(%rbp)
140096316:     	movd	-0x4(%r12), %xmm6
14009631d:     	movzbl	-0x5(%r12), %r10d
140096323:     	movb	%r10b, 0x26e(%rbp)
14009632a:     	movzbl	-0x6(%r12), %r10d
140096330:     	movb	%r10b, 0x26f(%rbp)
140096337:     	movzwl	-0x8(%r12), %r10d
14009633d:     	movw	%r10w, 0x26c(%rbp)
140096345:     	movl	-0xc(%r12), %r10d
14009634a:     	movl	%r10d, 0x268(%rbp)
140096351:     	movl	-0x10(%r12), %r14d
140096356:     	movq	-0x18(%r12), %r10
14009635b:     	movq	%r10, 0x258(%rbp)
140096362:     	movq	%r13, %r15
140096365:     	movq	%r15, 0x260(%rbp)
14009636c:     	incq	%rdi
14009636f:     	movb	$0x1, %bl
140096371:     	cmpq	%r8, %rdi
140096374:     	jb	0x14009628e <.text+0x9528e>
14009637a:     	jmp	0x140096385 <.text+0x95385>
14009637c:     	testb	$0x1, %bl
14009637f:     	je	0x140096644 <.text+0x95644>
140096385:     	movq	0x250(%rbp), %r10
14009638c:     	cmpq	%r11, %r10
14009638f:     	jae	0x1400963e5 <.text+0x953e5>
140096391:     	movq	0x80(%rcx), %r11
140096398:     	cmpb	$0x1, (%r11,%r10)
14009639d:     	jne	0x1400963e5 <.text+0x953e5>
14009639f:     	cmpq	0xa0(%rcx), %r10
1400963a6:     	jae	0x1400963b6 <.text+0x953b6>
1400963a8:     	movq	0x98(%rcx), %rsi
1400963af:     	cmpb	$0x0, (%rsi,%r10)
1400963b4:     	jne	0x1400963e5 <.text+0x953e5>
1400963b6:     	movb	$0x0, (%r11,%r10)
1400963bb:     	decq	0xb0(%rcx)
1400963c2:     	cmpq	0x70(%rcx), %r10
1400963c6:     	jae	0x1400963e5 <.text+0x953e5>
1400963c8:     	movq	0x68(%rcx), %r11
1400963cc:     	imulq	$0x58, %r10, %r10
1400963d0:     	movq	$0x0, 0x30(%r11,%r10)
1400963d9:     	movb	$0x2, 0x52(%r11,%r10)
1400963df:     	movb	$0x2, 0x25(%r11,%r10)
1400963e5:     	leaq	0xc0(%rcx), %rsi
1400963ec:     	movd	%xmm6, %r10d
1400963f1:     	addq	$0x2c, %rax
1400963f5:     	xorl	%r11d, %r11d
1400963f8:     	movq	0x248(%rbp), %r15
1400963ff:     	movzbl	0x26e(%rbp), %r12d
140096407:     	jmp	0x140096422 <.text+0x95422>
140096409:     	nopl	(%rax)
140096410:     	incq	%r11
140096413:     	addq	$0x140, %rax            # imm = 0x140
140096419:     	cmpq	%r11, %r8
14009641c:     	je	0x1400964ae <.text+0x954ae>
140096422:     	cmpq	%r9, %r11
140096425:     	setb	%bl
140096428:     	andb	(%rdx,%r11), %bl
14009642c:     	cmpb	$0x1, %bl
14009642f:     	jne	0x140096410 <.text+0x95410>
140096431:     	cmpl	$0x2, -0x2c(%rax)
140096435:     	je	0x140096410 <.text+0x95410>
140096437:     	cmpw	%r10w, (%rax)
14009643b:     	jne	0x140096410 <.text+0x95410>
14009643d:     	cmpl	%r14d, -0xc(%rax)
140096441:     	jne	0x140096410 <.text+0x95410>
140096443:     	movl	0x268(%rbp), %edi
140096449:     	cmpl	%edi, -0x8(%rax)
14009644c:     	jne	0x140096410 <.text+0x95410>
14009644e:     	movzwl	0x26c(%rbp), %edi
140096455:     	cmpw	%di, -0x4(%rax)
140096459:     	jne	0x140096410 <.text+0x95410>
14009645b:     	movzbl	0x26f(%rbp), %ebx
140096462:     	cmpb	%bl, -0x2(%rax)
140096465:     	jne	0x140096410 <.text+0x95410>
140096467:     	movq	-0x1c(%rax), %rdi
14009646b:     	xorq	%r15, %rdi
14009646e:     	movq	-0x14(%rax), %rbx
140096472:     	xorq	0x258(%rbp), %rbx
140096479:     	orq	%rdi, %rbx
14009647c:     	jne	0x140096410 <.text+0x95410>
14009647e:     	cmpq	%r8, %r11
140096481:     	jae	0x1400964ae <.text+0x954ae>
140096483:     	cmpq	0x100(%rcx), %r11
14009648a:     	jae	0x14009649a <.text+0x9549a>
14009648c:     	movq	0xf8(%rcx), %r8
140096493:     	cmpb	$0x0, (%r8,%r11)
140096498:     	jne	0x1400964ae <.text+0x954ae>
14009649a:     	movb	$0x0, (%rdx,%r11)
14009649f:     	decq	0x110(%rcx)
1400964a6:     	movq	$0x2, -0x2c(%rax)
1400964ae:     	xorps	%xmm7, %xmm7
1400964b1:     	movaps	%xmm7, 0x230(%rbp)
1400964b8:     	movb	$0x0, 0x212(%rbp)
1400964bf:     	movw	%r10w, 0x210(%rbp)
1400964c7:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
1400964d0:     	movq	$0x0, 0x213(%rbp)
1400964db:     	movq	$0x8, 0x1f0(%rbp)
1400964e6:     	movq	$0x0, 0x1f8(%rbp)
1400964f1:     	movq	$0x1, 0x200(%rbp)
1400964fc:     	movq	$0x0, 0x208(%rbp)
140096507:     	leaq	0x220(%rbp), %rcx
14009650e:     	leaq	0x1f0(%rbp), %rdx
140096515:     	leaq	0x230(%rbp), %r8
14009651c:     	movl	$0x10, %r9d
140096522:     	callq	0x140106220 <.text+0x105220>
140096527:     	cmpb	$0x0, 0x220(%rbp)
14009652e:     	jne	0x140096640 <.text+0x95640>
140096534:     	movq	0x228(%rbp), %rdi
14009653b:     	movaps	%xmm7, 0xe0(%rbp)
140096542:     	movaps	%xmm7, 0xf0(%rbp)
140096549:     	movaps	%xmm7, 0x100(%rbp)
140096550:     	movaps	%xmm7, 0x110(%rbp)
140096557:     	movaps	%xmm7, 0x120(%rbp)
14009655e:     	movaps	%xmm7, 0x130(%rbp)
140096565:     	movaps	%xmm7, 0x140(%rbp)
14009656c:     	movaps	%xmm7, 0x150(%rbp)
140096573:     	movaps	%xmm7, 0x160(%rbp)
14009657a:     	movaps	%xmm7, 0x170(%rbp)
140096581:     	movaps	%xmm7, 0x180(%rbp)
140096588:     	movaps	%xmm7, 0x190(%rbp)
14009658f:     	movaps	%xmm7, 0x1a0(%rbp)
140096596:     	movaps	%xmm7, 0x1b0(%rbp)
14009659d:     	movaps	%xmm7, 0x1c0(%rbp)
1400965a4:     	movaps	%xmm7, 0x1d0(%rbp)
1400965ab:     	cmpq	$0x11, %rdi
1400965af:     	jae	0x140096668 <.text+0x95668>
1400965b5:     	leaq	0xe0(%rbp), %rbx
1400965bc:     	leaq	0x230(%rbp), %rdx
1400965c3:     	movq	%rbx, %rcx
1400965c6:     	movq	%rdi, %r8
1400965c9:     	callq	0x140239710 <.text+0x238710>
1400965ce:     	movw	%di, 0x1e0(%rbp)
1400965d5:     	movq	$0x0, -0x60(%rbp)
1400965dd:     	movq	0x258(%rbp), %rax
1400965e4:     	movq	%rax, -0x48(%rbp)
1400965e8:     	movq	%r15, -0x50(%rbp)
1400965ec:     	movl	%r14d, -0x40(%rbp)
1400965f0:     	movl	0x268(%rbp), %eax
1400965f6:     	movl	%eax, -0x3c(%rbp)
1400965f9:     	movzwl	0x26c(%rbp), %eax
140096600:     	movw	%ax, -0x38(%rbp)
140096604:     	movzbl	0x26f(%rbp), %eax
14009660b:     	movb	%al, -0x36(%rbp)
14009660e:     	movb	%r12b, -0x35(%rbp)
140096612:     	movd	%xmm6, -0x34(%rbp)
140096617:     	movq	0x260(%rbp), %rax
14009661e:     	movq	%rax, -0x30(%rbp)
140096622:     	leaq	-0x28(%rbp), %rcx
140096626:     	movl	$0x108, %r8d            # imm = 0x108
14009662c:     	movq	%rbx, %rdx
14009662f:     	callq	0x140239710 <.text+0x238710>
140096634:     	leaq	-0x60(%rbp), %rdx
140096638:     	movq	%rsi, %rcx
14009663b:     	callq	0x1400116e0 <.text+0x106e0>
140096640:     	movb	$0x1, %al
140096642:     	jmp	0x140096646 <.text+0x95646>
140096644:     	xorl	%eax, %eax
140096646:     	movaps	0x270(%rbp), %xmm6
14009664d:     	movaps	0x280(%rbp), %xmm7
140096654:     	addq	$0x318, %rsp            # imm = 0x318
14009665b:     	popq	%rbx
14009665c:     	popq	%rdi
14009665d:     	popq	%rsi
14009665e:     	popq	%r12
140096660:     	popq	%r13
140096662:     	popq	%r14
140096664:     	popq	%r15
140096666:     	popq	%rbp
140096667:     	retq
140096668:     	leaq	0x1bb4f9(%rip), %r9     # 0x140251b68
14009666f:     	movl	$0x10, %r8d
140096675:     	xorl	%ecx, %ecx
140096677:     	movq	%rdi, %rdx
14009667a:     	callq	0x14023a160 <.text+0x239160>
14009667f:     	ud2

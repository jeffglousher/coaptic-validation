
D:\CoapticCurrent\packet-selection-match-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140095e70:     	pushq	%rbp
140095e71:     	pushq	%r15
140095e73:     	pushq	%r14
140095e75:     	pushq	%r13
140095e77:     	pushq	%r12
140095e79:     	pushq	%rsi
140095e7a:     	pushq	%rdi
140095e7b:     	pushq	%rbx
140095e7c:     	subq	$0x308, %rsp            # imm = 0x308
140095e83:     	leaq	0x80(%rsp), %rbp
140095e8b:     	movaps	%xmm7, 0x270(%rbp)
140095e92:     	movaps	%xmm6, 0x260(%rbp)
140095e99:     	leaq	0x5000(%rcx), %rax
140095ea0:     	leaq	0x30(%rcx), %r8
140095ea4:     	xorl	%r9d, %r9d
140095ea7:     	xorl	%esi, %esi
140095ea9:     	leaq	(%rsi,%rsi,4), %r11
140095ead:     	shlq	$0x6, %r11
140095eb1:     	addq	%r8, %r11
140095eb4:     	movq	%rsi, %r10
140095eb7:     	jmp	0x140095ed4 <.text+0x94ed4>
140095eb9:     	nopl	(%rax)
140095ec0:     	incq	%r10
140095ec3:     	addq	$0x140, %r11            # imm = 0x140
140095eca:     	cmpq	$0x40, %r10
140095ece:     	je	0x140095f6e <.text+0x94f6e>
140095ed4:     	cmpb	$0x1, 0x5000(%rcx,%r10)
140095edd:     	jne	0x140095ec0 <.text+0x94ec0>
140095edf:     	movq	-0x30(%r11), %rdi
140095ee3:     	cmpq	$0x2, %rdi
140095ee7:     	je	0x140095ec0 <.text+0x94ec0>
140095ee9:     	movq	(%r11), %rsi
140095eec:     	cmpl	$0x1, %edi
140095eef:     	setne	%bl
140095ef2:     	testq	%rsi, %rsi
140095ef5:     	sete	%dil
140095ef9:     	orb	%bl, %dil
140095efc:     	cmpb	$0x1, %dil
140095f00:     	je	0x140095ec0 <.text+0x94ec0>
140095f02:     	movq	0x250(%rbp), %rdi
140095f09:     	cmpq	%rdi, %rsi
140095f0c:     	setae	%bl
140095f0f:     	testb	%bl, %r9b
140095f12:     	jne	0x140095f54 <.text+0x94f54>
140095f14:     	movd	-0x4(%r11), %xmm6
140095f1a:     	movzbl	-0x5(%r11), %edx
140095f1f:     	movb	%dl, 0x25f(%rbp)
140095f25:     	movzbl	-0x6(%r11), %r15d
140095f2a:     	movzwl	-0x8(%r11), %r12d
140095f2f:     	movl	-0xc(%r11), %r13d
140095f33:     	movl	-0x10(%r11), %r14d
140095f37:     	movq	-0x18(%r11), %rdx
140095f3b:     	movq	%rdx, 0x248(%rbp)
140095f42:     	movq	-0x28(%r11), %rdx
140095f46:     	movq	-0x20(%r11), %r9
140095f4a:     	movq	%r9, 0x240(%rbp)
140095f51:     	movq	%rsi, %rdi
140095f54:     	movq	%rdi, 0x250(%rbp)
140095f5b:     	leaq	0x1(%r10), %rsi
140095f5f:     	movb	$0x1, %r9b
140095f62:     	cmpq	$0x3f, %r10
140095f66:     	jb	0x140095ea9 <.text+0x94ea9>
140095f6c:     	jmp	0x140095f78 <.text+0x94f78>
140095f6e:     	testb	$0x1, %r9b
140095f72:     	je	0x1400961f0 <.text+0x951f0>
140095f78:     	cmpq	$0x1f, %rdx
140095f7c:     	ja	0x140095fcf <.text+0x94fcf>
140095f7e:     	leaq	0x37740(%rcx), %r8
140095f85:     	cmpb	$0x1, (%r8,%rdx)
140095f8a:     	jne	0x140095fcf <.text+0x94fcf>
140095f8c:     	cmpb	$0x0, 0x37760(%rcx,%rdx)
140095f94:     	jne	0x140095fcf <.text+0x94fcf>
140095f96:     	movb	$0x0, 0x37740(%rcx,%rdx)
140095f9e:     	decq	0x37788(%rcx)
140095fa5:     	movq	$0x0, 0x43610(%rcx,%rdx,8)
140095fb1:     	leaq	(%rdx,%rdx,8), %r9
140095fb5:     	leaq	(%r9,%r9,2), %r9
140095fb9:     	addq	%rdx, %r9
140095fbc:     	movb	$0x2, 0x36a(%r8,%r9)
140095fc5:     	leaq	(%rdx,%rdx,2), %rdx
140095fc9:     	movb	$0x2, 0x5d(%r8,%rdx,8)
140095fcf:     	movd	%xmm6, %edx
140095fd3:     	movl	$0x2c, %r8d
140095fd9:     	movq	0x240(%rbp), %r11
140095fe0:     	movq	0x248(%rbp), %rsi
140095fe7:     	jmp	0x140096003 <.text+0x95003>
140095fe9:     	nopl	(%rax)
140095ff0:     	incq	%rax
140095ff3:     	addq	$0x140, %r8             # imm = 0x140
140095ffa:     	cmpq	$0x502c, %r8            # imm = 0x502C
140096001:     	je	0x14009605c <.text+0x9505c>
140096003:     	cmpb	$0x1, (%rax)
140096006:     	jne	0x140095ff0 <.text+0x94ff0>
140096008:     	cmpl	$0x2, -0x2c(%rcx,%r8)
14009600e:     	je	0x140095ff0 <.text+0x94ff0>
140096010:     	cmpw	%dx, (%rcx,%r8)
140096015:     	jne	0x140095ff0 <.text+0x94ff0>
140096017:     	cmpl	%r14d, -0xc(%rcx,%r8)
14009601c:     	jne	0x140095ff0 <.text+0x94ff0>
14009601e:     	cmpl	%r13d, -0x8(%rcx,%r8)
140096023:     	jne	0x140095ff0 <.text+0x94ff0>
140096025:     	cmpw	%r12w, -0x4(%rcx,%r8)
14009602b:     	jne	0x140095ff0 <.text+0x94ff0>
14009602d:     	cmpb	%r15b, -0x2(%rcx,%r8)
140096032:     	jne	0x140095ff0 <.text+0x94ff0>
140096034:     	movq	-0x1c(%rcx,%r8), %r9
140096039:     	xorq	%r11, %r9
14009603c:     	movq	-0x14(%rcx,%r8), %r10
140096041:     	xorq	%rsi, %r10
140096044:     	orq	%r9, %r10
140096047:     	jne	0x140095ff0 <.text+0x94ff0>
140096049:     	movb	$0x0, (%rax)
14009604c:     	decq	0x5048(%rcx)
140096053:     	movq	$0x2, -0x2c(%rcx,%r8)
14009605c:     	movq	%rcx, %rsi
14009605f:     	xorps	%xmm7, %xmm7
140096062:     	movaps	%xmm7, 0x230(%rbp)
140096069:     	movb	$0x0, 0x212(%rbp)
140096070:     	movw	%dx, 0x210(%rbp)
140096077:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
140096080:     	movq	$0x0, 0x213(%rbp)
14009608b:     	movq	$0x8, 0x1f0(%rbp)
140096096:     	movq	$0x0, 0x1f8(%rbp)
1400960a1:     	movq	$0x1, 0x200(%rbp)
1400960ac:     	movq	$0x0, 0x208(%rbp)
1400960b7:     	leaq	0x220(%rbp), %rcx
1400960be:     	leaq	0x1f0(%rbp), %rdx
1400960c5:     	leaq	0x230(%rbp), %r8
1400960cc:     	movl	$0x10, %r9d
1400960d2:     	callq	0x140106220 <.text+0x105220>
1400960d7:     	cmpb	$0x0, 0x220(%rbp)
1400960de:     	jne	0x1400961ec <.text+0x951ec>
1400960e4:     	movq	0x228(%rbp), %rdi
1400960eb:     	movaps	%xmm7, 0xe0(%rbp)
1400960f2:     	movaps	%xmm7, 0xf0(%rbp)
1400960f9:     	movaps	%xmm7, 0x100(%rbp)
140096100:     	movaps	%xmm7, 0x110(%rbp)
140096107:     	movaps	%xmm7, 0x120(%rbp)
14009610e:     	movaps	%xmm7, 0x130(%rbp)
140096115:     	movaps	%xmm7, 0x140(%rbp)
14009611c:     	movaps	%xmm7, 0x150(%rbp)
140096123:     	movaps	%xmm7, 0x160(%rbp)
14009612a:     	movaps	%xmm7, 0x170(%rbp)
140096131:     	movaps	%xmm7, 0x180(%rbp)
140096138:     	movaps	%xmm7, 0x190(%rbp)
14009613f:     	movaps	%xmm7, 0x1a0(%rbp)
140096146:     	movaps	%xmm7, 0x1b0(%rbp)
14009614d:     	movaps	%xmm7, 0x1c0(%rbp)
140096154:     	movaps	%xmm7, 0x1d0(%rbp)
14009615b:     	cmpq	$0x11, %rdi
14009615f:     	jae	0x140096214 <.text+0x95214>
140096165:     	leaq	0xe0(%rbp), %rbx
14009616c:     	leaq	0x230(%rbp), %rdx
140096173:     	movq	%rbx, %rcx
140096176:     	movq	%rdi, %r8
140096179:     	callq	0x140239710 <.text+0x238710>
14009617e:     	movw	%di, 0x1e0(%rbp)
140096185:     	movq	$0x0, -0x60(%rbp)
14009618d:     	movq	0x248(%rbp), %rax
140096194:     	movq	%rax, -0x48(%rbp)
140096198:     	movq	0x240(%rbp), %rax
14009619f:     	movq	%rax, -0x50(%rbp)
1400961a3:     	movl	%r14d, -0x40(%rbp)
1400961a7:     	movl	%r13d, -0x3c(%rbp)
1400961ab:     	movw	%r12w, -0x38(%rbp)
1400961b0:     	movb	%r15b, -0x36(%rbp)
1400961b4:     	movzbl	0x25f(%rbp), %eax
1400961bb:     	movb	%al, -0x35(%rbp)
1400961be:     	movd	%xmm6, -0x34(%rbp)
1400961c3:     	movq	0x250(%rbp), %rax
1400961ca:     	movq	%rax, -0x30(%rbp)
1400961ce:     	leaq	-0x28(%rbp), %rcx
1400961d2:     	movl	$0x108, %r8d            # imm = 0x108
1400961d8:     	movq	%rbx, %rdx
1400961db:     	callq	0x140239710 <.text+0x238710>
1400961e0:     	leaq	-0x60(%rbp), %rdx
1400961e4:     	movq	%rsi, %rcx
1400961e7:     	callq	0x1401ff280 <.text+0x1fe280>
1400961ec:     	movb	$0x1, %al
1400961ee:     	jmp	0x1400961f2 <.text+0x951f2>
1400961f0:     	xorl	%eax, %eax
1400961f2:     	movaps	0x260(%rbp), %xmm6
1400961f9:     	movaps	0x270(%rbp), %xmm7
140096200:     	addq	$0x308, %rsp            # imm = 0x308
140096207:     	popq	%rbx
140096208:     	popq	%rdi
140096209:     	popq	%rsi
14009620a:     	popq	%r12
14009620c:     	popq	%r13
14009620e:     	popq	%r14
140096210:     	popq	%r15
140096212:     	popq	%rbp
140096213:     	retq
140096214:     	leaq	0x1bb94d(%rip), %r9     # 0x140251b68
14009621b:     	movl	$0x10, %r8d
140096221:     	xorl	%ecx, %ecx
140096223:     	movq	%rdi, %rdx
140096226:     	callq	0x14023a160 <.text+0x239160>
14009622b:     	ud2

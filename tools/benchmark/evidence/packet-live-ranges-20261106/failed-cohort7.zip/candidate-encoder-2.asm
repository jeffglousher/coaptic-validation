
D:\CoapticCurrent\packet-selection-match-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140064570:     	pushq	%rbp
140064571:     	pushq	%r15
140064573:     	pushq	%r14
140064575:     	pushq	%r13
140064577:     	pushq	%r12
140064579:     	pushq	%rsi
14006457a:     	pushq	%rdi
14006457b:     	pushq	%rbx
14006457c:     	subq	$0x4f8, %rsp            # imm = 0x4F8
140064583:     	leaq	0x80(%rsp), %rbp
14006458b:     	movq	%r9, %rbx
14006458e:     	movq	%r8, %r14
140064591:     	movq	%rdx, %rdi
140064594:     	movq	%rcx, %rsi
140064597:     	movq	0x4f0(%rbp), %r12
14006459e:     	leaq	-0x10(%rbp), %rcx
1400645a2:     	movl	$0x400, %r8d            # imm = 0x400
1400645a8:     	xorl	%edx, %edx
1400645aa:     	callq	0x140239722 <.text+0x238722>
1400645af:     	movq	0x8(%r12), %r13
1400645b4:     	movl	$0x3, %eax
1400645b9:     	cmpq	$0x3, %r13
1400645bd:     	ja	0x1400647d6 <.text+0x637d6>
1400645c3:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
1400645cc:     	jne	0x1400647d6 <.text+0x637d6>
1400645d2:     	movq	0x2b750(%rdi,%r13,8), %rdx
1400645da:     	cmpq	$0x4001, %rdx           # imm = 0x4001
1400645e1:     	jae	0x140064832 <.text+0x63832>
1400645e7:     	movq	0x10(%r12), %rcx
1400645ec:     	movq	0x18(%r12), %r15
1400645f1:     	movq	%r15, %r8
1400645f4:     	movl	$0xb, %eax
1400645f9:     	addq	%rcx, %r8
1400645fc:     	jb	0x1400647d6 <.text+0x637d6>
140064602:     	cmpq	$0x400, %r15            # imm = 0x400
140064609:     	ja	0x1400647d6 <.text+0x637d6>
14006460f:     	cmpq	%rdx, %r8
140064612:     	ja	0x1400647d6 <.text+0x637d6>
140064618:     	movq	%r13, %rax
14006461b:     	shlq	$0xe, %rax
14006461f:     	leaq	(%rdi,%rax), %rdx
140064623:     	addq	$0x1b750, %rdx          # imm = 0x1B750
14006462a:     	addq	%rcx, %rdx
14006462d:     	leaq	-0x10(%rbp), %rcx
140064631:     	movq	%r15, %r8
140064634:     	callq	0x140239710 <.text+0x238710>
140064639:     	cmpb	$0x0, 0x4f8(%rbp)
140064640:     	je	0x140064658 <.text+0x63658>
140064642:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
140064649:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
140064652:     	jne	0x1400647f1 <.text+0x637f1>
140064658:     	movq	$0x0, 0x470(%rbp)
140064663:     	movq	%rdi, %rcx
140064666:     	callq	0x140092380 <.text+0x91380>
14006466b:     	testb	$0x1, %al
14006466d:     	je	0x140064824 <.text+0x63824>
140064673:     	movq	%rdx, %r13
140064676:     	movq	0x500(%rbp), %rdx
14006467d:     	movzwl	0x4e8(%rbp), %ecx
140064684:     	movzbl	0x4e0(%rbp), %eax
14006468b:     	movq	(%r12), %r8
14006468f:     	movq	0x470(%rbp), %r9
140064696:     	movq	%r9, 0x438(%rbp)
14006469d:     	movq	0x468(%rbp), %r9
1400646a4:     	movq	%r9, 0x440(%rbp)
1400646ab:     	movq	%r8, 0x448(%rbp)
1400646b2:     	movzbl	0x4f8(%rbp), %r8d
1400646ba:     	movb	%r8b, 0x450(%rbp)
1400646c1:     	movups	0x38(%r14), %xmm0
1400646c6:     	movups	0x44(%r14), %xmm1
1400646cb:     	movups	%xmm1, 0x3fc(%rbp)
1400646d2:     	movaps	%xmm0, 0x3f0(%rbp)
1400646d9:     	leaq	0x66(%r14), %r8
1400646dd:     	movq	0x56(%r14), %r9
1400646e1:     	movq	0x5d(%r14), %r10
1400646e5:     	movq	%r10, 0x45f(%rbp)
1400646ec:     	movq	%r9, 0x458(%rbp)
1400646f3:     	leaq	0x458(%rbp), %r9
1400646fa:     	movq	%r9, 0x68(%rsp)
1400646ff:     	movq	%rdx, 0x60(%rsp)
140064704:     	movq	%r14, 0x58(%rsp)
140064709:     	leaq	0x438(%rbp), %rdx
140064710:     	movq	%rdx, 0x50(%rsp)
140064715:     	movq	%r15, 0x48(%rsp)
14006471a:     	leaq	-0x10(%rbp), %rdx
14006471e:     	movq	%rdx, 0x40(%rsp)
140064723:     	movq	%rbx, 0x38(%rsp)
140064728:     	movq	%r8, 0x30(%rsp)
14006472d:     	movw	%cx, 0x28(%rsp)
140064732:     	movb	%al, 0x20(%rsp)
140064736:     	leaq	0x418(%rbp), %rcx
14006473d:     	leaq	0x3f0(%rbp), %r8
140064744:     	movq	%rdi, %rdx
140064747:     	movq	%r13, %r9
14006474a:     	callq	0x14007bfe0 <.text+0x7afe0>
14006474f:     	cmpb	$-0x1, 0x418(%rbp)
140064756:     	je	0x140064829 <.text+0x63829>
14006475c:     	cmpb	$0x1, 0x37740(%rdi,%r13)
140064765:     	jne	0x1400647bf <.text+0x637bf>
140064767:     	cmpb	$0x0, 0x37760(%rdi,%r13)
140064770:     	jne	0x1400647bf <.text+0x637bf>
140064772:     	movb	$0x0, 0x37740(%rdi,%r13)
14006477b:     	decq	0x37788(%rdi)
140064782:     	leaq	0x37740(%rdi), %rax
140064789:     	movq	$0x0, 0x43610(%rdi,%r13,8)
140064795:     	leaq	(,%r13,8), %rcx
14006479d:     	addq	%r13, %rcx
1400647a0:     	leaq	(%rcx,%rcx,2), %rcx
1400647a4:     	addq	%r13, %rcx
1400647a7:     	movb	$0x2, 0x36a(%rax,%rcx)
1400647af:     	leaq	(,%r13,2), %rcx
1400647b7:     	addq	%r13, %rcx
1400647ba:     	movb	$0x2, 0x5d(%rax,%rcx,8)
1400647bf:     	movups	0x418(%rbp), %xmm0
1400647c6:     	movups	0x428(%rbp), %xmm1
1400647cd:     	movups	%xmm1, 0x10(%rsi)
1400647d1:     	movups	%xmm0, (%rsi)
1400647d4:     	jmp	0x1400647dd <.text+0x637dd>
1400647d6:     	movb	$0xa, (%rsi)
1400647d9:     	movq	%rax, 0x8(%rsi)
1400647dd:     	addq	$0x4f8, %rsp            # imm = 0x4F8
1400647e4:     	popq	%rbx
1400647e5:     	popq	%rdi
1400647e6:     	popq	%rsi
1400647e7:     	popq	%r12
1400647e9:     	popq	%r13
1400647eb:     	popq	%r14
1400647ed:     	popq	%r15
1400647ef:     	popq	%rbp
1400647f0:     	retq
1400647f1:     	addq	%rdi, %rax
1400647f4:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
1400647fa:     	movq	0x98(%rax), %rax
140064801:     	movq	%rax, 0x468(%rbp)
140064808:     	movl	$0x1, %eax
14006480d:     	movq	%rax, 0x470(%rbp)
140064814:     	movq	%rdi, %rcx
140064817:     	callq	0x140092380 <.text+0x91380>
14006481c:     	testb	$0x1, %al
14006481e:     	jne	0x140064673 <.text+0x63673>
140064824:     	movb	$0x9, (%rsi)
140064827:     	jmp	0x1400647dd <.text+0x637dd>
140064829:     	movq	%r13, 0x8(%rsi)
14006482d:     	movb	$-0x1, (%rsi)
140064830:     	jmp	0x1400647dd <.text+0x637dd>
140064832:     	leaq	0x1f03f7(%rip), %r9     # 0x140254c30
140064839:     	movl	$0x4000, %r8d           # imm = 0x4000
14006483f:     	xorl	%ecx, %ecx
140064841:     	callq	0x14023a160 <.text+0x239160>
140064846:     	ud2


D:\CoapticCurrent\packet-lazy-staged-20261106\B\retained-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140017570:     	pushq	%rbp
140017571:     	pushq	%r15
140017573:     	pushq	%r14
140017575:     	pushq	%r13
140017577:     	pushq	%r12
140017579:     	pushq	%rsi
14001757a:     	pushq	%rdi
14001757b:     	pushq	%rbx
14001757c:     	subq	$0x528, %rsp            # imm = 0x528
140017583:     	leaq	0x80(%rsp), %rbp
14001758b:     	movq	%r9, 0x448(%rbp)
140017592:     	movq	%r8, 0x450(%rbp)
140017599:     	movq	%rdx, %rdi
14001759c:     	movq	%rcx, 0x488(%rbp)
1400175a3:     	movups	0x131536(%rip), %xmm0   # 0x140148ae0
1400175aa:     	movaps	%xmm0, 0x200(%rbp)
1400175b1:     	movq	$0x0, 0x210(%rbp)
1400175bc:     	movups	%xmm0, 0x218(%rbp)
1400175c3:     	movq	$0x0, 0x228(%rbp)
1400175ce:     	movaps	%xmm0, 0x230(%rbp)
1400175d5:     	movq	$0x0, 0x240(%rbp)
1400175e0:     	movups	%xmm0, 0x248(%rbp)
1400175e7:     	movq	$0x0, 0x258(%rbp)
1400175f2:     	movaps	%xmm0, 0x260(%rbp)
1400175f9:     	movq	$0x0, 0x270(%rbp)
140017604:     	movups	%xmm0, 0x278(%rbp)
14001760b:     	movq	$0x0, 0x288(%rbp)
140017616:     	movaps	%xmm0, 0x290(%rbp)
14001761d:     	movq	$0x0, 0x2a0(%rbp)
140017628:     	movups	%xmm0, 0x2a8(%rbp)
14001762f:     	movq	$0x0, 0x2b8(%rbp)
14001763a:     	movaps	%xmm0, 0x2c0(%rbp)
140017641:     	movq	$0x0, 0x2d0(%rbp)
14001764c:     	movups	%xmm0, 0x2d8(%rbp)
140017653:     	movq	$0x0, 0x2e8(%rbp)
14001765e:     	movaps	%xmm0, 0x2f0(%rbp)
140017665:     	movq	$0x0, 0x300(%rbp)
140017670:     	movups	%xmm0, 0x308(%rbp)
140017677:     	movq	$0x0, 0x318(%rbp)
140017682:     	movaps	%xmm0, 0x320(%rbp)
140017689:     	movq	$0x0, 0x330(%rbp)
140017694:     	movups	%xmm0, 0x338(%rbp)
14001769b:     	movq	$0x0, 0x348(%rbp)
1400176a6:     	movaps	%xmm0, 0x350(%rbp)
1400176ad:     	movq	$0x0, 0x360(%rbp)
1400176b8:     	movups	%xmm0, 0x368(%rbp)
1400176bf:     	movq	$0x0, 0x378(%rbp)
1400176ca:     	movaps	%xmm0, 0x380(%rbp)
1400176d1:     	movq	$0x0, 0x390(%rbp)
1400176dc:     	movups	%xmm0, 0x398(%rbp)
1400176e3:     	movq	$0x0, 0x3a8(%rbp)
1400176ee:     	movaps	%xmm0, 0x3b0(%rbp)
1400176f5:     	movq	$0x0, 0x3c0(%rbp)
140017700:     	movups	%xmm0, 0x3c8(%rbp)
140017707:     	movq	$0x0, 0x3d8(%rbp)
140017712:     	movaps	%xmm0, 0x3e0(%rbp)
140017719:     	movq	$0x0, 0x3f0(%rbp)
140017724:     	movups	%xmm0, 0x3f8(%rbp)
14001772b:     	movq	$0x0, 0x408(%rbp)
140017736:     	movaps	%xmm0, 0x410(%rbp)
14001773d:     	movq	$0x0, 0x420(%rbp)
140017748:     	movups	%xmm0, 0x428(%rbp)
14001774f:     	movq	$0x0, 0x438(%rbp)
14001775a:     	leaq	-0x48(%rbp), %rcx
14001775e:     	leaq	0x200(%rbp), %rdx
140017765:     	movl	$0x240, %r8d            # imm = 0x240
14001776b:     	callq	0x140138f10 <.text+0x137f10>
140017770:     	movq	$0x0, 0x1f8(%rbp)
14001777b:     	movups	(%rdi), %xmm0
14001777e:     	movups	%xmm0, 0x200(%rbp)
140017785:     	leaq	0x210(%rbp), %r12
14001778c:     	movq	$0x0, 0x210(%rbp)
140017797:     	leaq	0x218(%rbp), %rsi
14001779e:     	movl	$0x0, 0x218(%rbp)
1400177a8:     	movq	%rdi, 0x220(%rbp)
1400177af:     	movzbl	0x24(%rdi), %eax
1400177b3:     	movb	%al, 0x4a7(%rbp)
1400177b9:     	leaq	0x46a(%rbp), %rbx
1400177c0:     	xorl	%r13d, %r13d
1400177c3:     	leaq	0x458(%rbp), %r15
1400177ca:     	cmpb	$0x5, %al
1400177cc:     	jne	0x140017902 <.text+0x16902>
1400177d2:     	movl	$0x29832, %r14d         # imm = 0x29832
1400177d8:     	nopl	(%rax,%rax)
1400177e0:     	movq	0x208(%rbp), %r8
1400177e7:     	cmpq	%r8, 0x210(%rbp)
1400177ee:     	jae	0x140017a32 <.text+0x16a32>
1400177f4:     	movq	0x200(%rbp), %rdx
1400177fb:     	movq	%rsi, 0x20(%rsp)
140017800:     	movq	%r15, %rcx
140017803:     	movq	%r12, %r9
140017806:     	callq	0x14000cc50 <.text+0xbc50>
14001780b:     	movq	0x458(%rbp), %rax
140017812:     	testq	%rax, %rax
140017815:     	je	0x140017a32 <.text+0x16a32>
14001781b:     	movq	0x460(%rbp), %rcx
140017822:     	movzwl	0x468(%rbp), %edx
140017829:     	movl	(%rbx), %r8d
14001782c:     	movl	%r8d, 0x490(%rbp)
140017833:     	movzwl	0x4(%rbx), %r8d
140017838:     	movw	%r8w, 0x494(%rbp)
140017840:     	cmpl	$0x11, %edx
140017843:     	ja	0x1400177e0 <.text+0x167e0>
140017845:     	btl	%edx, %r14d
140017849:     	jae	0x1400177e0 <.text+0x167e0>
14001784b:     	movzwl	0x494(%rbp), %r8d
140017853:     	movl	0x490(%rbp), %r9d
14001785a:     	movl	%r9d, 0x4a0(%rbp)
140017861:     	movw	%r8w, 0x4a4(%rbp)
140017869:     	cmpq	$0x17, %r13
14001786d:     	ja	0x140017b42 <.text+0x16b42>
140017873:     	testq	%r13, %r13
140017876:     	je	0x1400178b6 <.text+0x168b6>
140017878:     	leaq	(,%r13,2), %r8
140017880:     	addq	%r13, %r8
140017883:     	leaq	-0x48(,%r8,8), %r8
14001788b:     	addq	%rbp, %r8
14001788e:     	nop
140017890:     	cmpw	%dx, -0x8(%r8)
140017895:     	jbe	0x1400178b9 <.text+0x168b9>
140017897:     	decq	%r13
14001789a:     	leaq	-0x18(%r8), %r9
14001789e:     	movq	0x10(%r9), %r10
1400178a2:     	movq	%r10, 0x10(%r8)
1400178a6:     	movups	(%r9), %xmm0
1400178aa:     	movups	%xmm0, (%r8)
1400178ae:     	movq	%r9, %r8
1400178b1:     	testq	%r13, %r13
1400178b4:     	jne	0x140017890 <.text+0x16890>
1400178b6:     	xorl	%r13d, %r13d
1400178b9:     	leaq	(,%r13,2), %r8
1400178c1:     	addq	%r13, %r8
1400178c4:     	movq	%rax, -0x48(%rbp,%r8,8)
1400178c9:     	movq	%rcx, -0x40(%rbp,%r8,8)
1400178ce:     	movw	%dx, -0x38(%rbp,%r8,8)
1400178d4:     	movl	0x4a0(%rbp), %eax
1400178da:     	movl	%eax, -0x36(%rbp,%r8,8)
1400178df:     	movzwl	0x4a4(%rbp), %eax
1400178e6:     	movw	%ax, -0x32(%rbp,%r8,8)
1400178ec:     	movq	0x1f8(%rbp), %r13
1400178f3:     	incq	%r13
1400178f6:     	movq	%r13, 0x1f8(%rbp)
1400178fd:     	jmp	0x1400177e0 <.text+0x167e0>
140017902:     	movl	$0x29822, %r14d         # imm = 0x29822
140017908:     	nopl	(%rax,%rax)
140017910:     	movq	0x208(%rbp), %r8
140017917:     	cmpq	%r8, 0x210(%rbp)
14001791e:     	jae	0x140017a32 <.text+0x16a32>
140017924:     	movq	0x200(%rbp), %rdx
14001792b:     	movq	%rsi, 0x20(%rsp)
140017930:     	movq	%r15, %rcx
140017933:     	movq	%r12, %r9
140017936:     	callq	0x14000cc50 <.text+0xbc50>
14001793b:     	movq	0x458(%rbp), %rax
140017942:     	testq	%rax, %rax
140017945:     	je	0x140017a32 <.text+0x16a32>
14001794b:     	movq	0x460(%rbp), %rcx
140017952:     	movzwl	0x468(%rbp), %edx
140017959:     	movl	(%rbx), %r8d
14001795c:     	movl	%r8d, 0x490(%rbp)
140017963:     	movzwl	0x4(%rbx), %r8d
140017968:     	movw	%r8w, 0x494(%rbp)
140017970:     	cmpl	$0x11, %edx
140017973:     	ja	0x140017910 <.text+0x16910>
140017975:     	btl	%edx, %r14d
140017979:     	jae	0x140017910 <.text+0x16910>
14001797b:     	movzwl	0x494(%rbp), %r8d
140017983:     	movl	0x490(%rbp), %r9d
14001798a:     	movl	%r9d, 0x4a0(%rbp)
140017991:     	movw	%r8w, 0x4a4(%rbp)
140017999:     	cmpq	$0x17, %r13
14001799d:     	ja	0x140017b42 <.text+0x16b42>
1400179a3:     	testq	%r13, %r13
1400179a6:     	je	0x1400179e6 <.text+0x169e6>
1400179a8:     	leaq	(,%r13,2), %r8
1400179b0:     	addq	%r13, %r8
1400179b3:     	leaq	-0x48(,%r8,8), %r8
1400179bb:     	addq	%rbp, %r8
1400179be:     	nop
1400179c0:     	cmpw	%dx, -0x8(%r8)
1400179c5:     	jbe	0x1400179e9 <.text+0x169e9>
1400179c7:     	decq	%r13
1400179ca:     	leaq	-0x18(%r8), %r9
1400179ce:     	movq	0x10(%r9), %r10
1400179d2:     	movq	%r10, 0x10(%r8)
1400179d6:     	movups	(%r9), %xmm0
1400179da:     	movups	%xmm0, (%r8)
1400179de:     	movq	%r9, %r8
1400179e1:     	testq	%r13, %r13
1400179e4:     	jne	0x1400179c0 <.text+0x169c0>
1400179e6:     	xorl	%r13d, %r13d
1400179e9:     	leaq	(,%r13,2), %r8
1400179f1:     	addq	%r13, %r8
1400179f4:     	movq	%rax, -0x48(%rbp,%r8,8)
1400179f9:     	movq	%rcx, -0x40(%rbp,%r8,8)
1400179fe:     	movw	%dx, -0x38(%rbp,%r8,8)
140017a04:     	movl	0x4a0(%rbp), %eax
140017a0a:     	movl	%eax, -0x36(%rbp,%r8,8)
140017a0f:     	movzwl	0x4a4(%rbp), %eax
140017a16:     	movw	%ax, -0x32(%rbp,%r8,8)
140017a1c:     	movq	0x1f8(%rbp), %r13
140017a23:     	incq	%r13
140017a26:     	movq	%r13, 0x1f8(%rbp)
140017a2d:     	jmp	0x140017910 <.text+0x16910>
140017a32:     	cmpq	$0x19, %r13
140017a36:     	jae	0x140017b50 <.text+0x16b50>
140017a3c:     	xorl	%eax, %eax
140017a3e:     	movzbl	0x4a7(%rbp), %r8d
140017a46:     	cmpb	$0x5, %r8b
140017a4a:     	movq	0x448(%rbp), %rcx
140017a51:     	cmovneq	%rax, %rcx
140017a55:     	movl	$0x1, %eax
140017a5a:     	cmoveq	0x450(%rbp), %rax
140017a62:     	leaq	-0x48(%rbp), %rdx
140017a66:     	movq	%rdx, 0x458(%rbp)
140017a6d:     	movq	%r13, 0x460(%rbp)
140017a74:     	movq	%rax, 0x468(%rbp)
140017a7b:     	movq	%rcx, 0x470(%rbp)
140017a82:     	movw	$0x0, 0x478(%rbp)
140017a8b:     	movb	%r8b, 0x47a(%rbp)
140017a92:     	movq	0x26(%rdi), %rax
140017a96:     	movq	%rax, 0x47b(%rbp)
140017a9d:     	movzbl	0x2e(%rdi), %eax
140017aa1:     	movb	%al, 0x483(%rbp)
140017aa7:     	movb	$0x1, 0x484(%rbp)
140017aae:     	leaq	0x200(%rbp), %rdi
140017ab5:     	movl	$0x208, %r8d            # imm = 0x208
140017abb:     	movq	%rdi, %rcx
140017abe:     	xorl	%edx, %edx
140017ac0:     	callq	0x140138f22 <.text+0x137f22>
140017ac5:     	leaq	0x490(%rbp), %rcx
140017acc:     	leaq	0x458(%rbp), %rdx
140017ad3:     	movl	$0x200, %r9d            # imm = 0x200
140017ad9:     	movq	%rdi, %r8
140017adc:     	callq	0x14008b870 <.text+0x8a870>
140017ae1:     	cmpb	$0x1, 0x490(%rbp)
140017ae8:     	jne	0x140017b00 <.text+0x16b00>
140017aea:     	movzbl	0x491(%rbp), %eax
140017af1:     	movq	0x488(%rbp), %rcx
140017af8:     	movb	%al, 0x1(%rcx)
140017afb:     	movb	$0x1, (%rcx)
140017afe:     	jmp	0x140017b2e <.text+0x16b2e>
140017b00:     	movq	0x498(%rbp), %rax
140017b07:     	movq	%rax, 0x400(%rbp)
140017b0e:     	movq	0x488(%rbp), %rsi
140017b15:     	leaq	0x8(%rsi), %rcx
140017b19:     	leaq	0x200(%rbp), %rdx
140017b20:     	movl	$0x208, %r8d            # imm = 0x208
140017b26:     	callq	0x140138f10 <.text+0x137f10>
140017b2b:     	movb	$0x0, (%rsi)
140017b2e:     	addq	$0x528, %rsp            # imm = 0x528
140017b35:     	popq	%rbx
140017b36:     	popq	%rdi
140017b37:     	popq	%rsi
140017b38:     	popq	%r12
140017b3a:     	popq	%r13
140017b3c:     	popq	%r14
140017b3e:     	popq	%r15
140017b40:     	popq	%rbp
140017b41:     	retq
140017b42:     	movq	0x488(%rbp), %rax
140017b49:     	movw	$0x501, (%rax)          # imm = 0x501
140017b4e:     	jmp	0x140017b2e <.text+0x16b2e>
140017b50:     	leaq	0x132b41(%rip), %r9     # 0x14014a698
140017b57:     	movl	$0x18, %r8d
140017b5d:     	xorl	%ecx, %ecx
140017b5f:     	movq	%r13, %rdx
140017b62:     	callq	0x1401399d0 <.text+0x1389d0>
140017b67:     	ud2

1400213bd:     	leaq	(%rcx,%rcx,2), %rax
1400213c1:     	movb	$0x2, 0x172d(%rdx,%rax,8)
1400213c9:     	movq	0x1e48(%rbp), %rcx
1400213d0:     	movq	0x1d70(%rbp), %rdx
1400213d7:     	movq	0x1e58(%rbp), %r8
1400213de:     	callq	0x140019b70 <.text+0x18b70>
1400213e3:     	nop
1400213e4:     	movaps	0x12d0(%rbp), %xmm0
1400213eb:     	movaps	0x12e0(%rbp), %xmm1
1400213f2:     	jmp	0x14002214a <.text+0x2114a>
1400213f7:     	leaq	0x1408(%rbp), %rdx
1400213fe:     	leaq	0x9e8(%rbp), %r15
140021405:     	movl	$0x208, %r8d            # imm = 0x208
14002140b:     	movq	%r15, %rcx
14002140e:     	callq	0x140138f10 <.text+0x137f10>
140021413:     	leaq	0x378(%r14), %rdx
14002141a:     	movl	$0x200, %r8d            # imm = 0x200
140021420:     	movq	%r15, %rcx
140021423:     	callq	0x140138f28 <.text+0x137f28>
140021428:     	testl	%eax, %eax
14002142a:     	jne	0x1400211b5 <.text+0x201b5>
140021430:     	movq	0x578(%r14), %rax
140021437:     	cmpq	%rax, 0xbe8(%rbp)
14002143e:     	jne	0x1400211b5 <.text+0x201b5>
140021444:     	cmpb	$0x5, 0x1c1c(%rbp)
14002144b:     	je	0x14002145b <.text+0x2045b>
14002144d:     	cmpq	$0x0, 0x1c10(%rbp)
140021455:     	jne	0x1400211b5 <.text+0x201b5>
14002145b:     	cmpb	$0x2, 0x2d(%r14)
140021460:     	setne	%al
140021463:     	movzbl	0x1c5d(%rbp), %esi
14002146a:     	cmpb	$0x2, %sil
14002146e:     	sete	%cl
140021471:     	cmpb	%cl, %al
140021473:     	je	0x1400211b5 <.text+0x201b5>
140021479:     	cmpl	$0x2, 0x78(%r14)
14002147e:     	je	0x140021492 <.text+0x20492>
140021480:     	movzbl	0x1c55(%rbp), %r8d
140021488:     	cmpq	$0x2, %r8
14002148c:     	jne	0x140022fbe <.text+0x21fbe>
140021492:     	movq	0xa0(%r14), %r15
140021499:     	addq	$0xa8, %r14
1400226f1:     	leaq	0x9e2(%rbp), %rcx
1400226f8:     	movl	$0x200, %r8d            # imm = 0x200
1400226fe:     	movq	%rcx, %rbx
140022701:     	movq	%r15, %rdx
140022704:     	callq	0x140138f10 <.text+0x137f10>
140022709:     	movw	%di, 0xbe2(%rbp)
140022710:     	movw	$0x1, 0x9e0(%rbp)
140022719:     	movw	$0x1, 0x1400(%rbp)
140022722:     	leaq	0x1402(%rbp), %r15
140022729:     	leaq	-0x10(%rbp), %rdx
14002272d:     	movl	$0x200, %r8d            # imm = 0x200
140022733:     	movq	%r15, %rcx
140022736:     	callq	0x140138f10 <.text+0x137f10>
14002273b:     	cmpw	%di, %r13w
14002273f:     	jne	0x14002275a <.text+0x2175a>
140022741:     	movl	$0x200, %r8d            # imm = 0x200
140022747:     	movq	%rbx, %rcx
14002274a:     	movq	%r15, %rdx
14002274d:     	callq	0x140138f28 <.text+0x137f28>
140022752:     	testl	%eax, %eax
140022754:     	je	0x14002300a <.text+0x2200a>
14002275a:     	leaq	0x1c68(%rbp), %rdx
140022761:     	movups	(%rdx), %xmm0
140022764:     	movups	0xc(%rdx), %xmm1
140022768:     	movups	%xmm1, 0x10e4(%rbp)
14002276f:     	movups	%xmm0, 0x10d8(%rbp)
140022776:     	movzbl	0x1c95(%rbp), %eax
14002277d:     	movb	%al, 0x1105(%rbp)
140022783:     	movzwl	0x1c84(%rbp), %eax
14002278a:     	movw	%ax, 0x10f4(%rbp)
140022791:     	leaq	0x1c96(%rbp), %rcx
140022798:     	movq	(%rcx), %rax
14002279b:     	movq	%rax, 0x1106(%rbp)
1400227a2:     	movzbl	0x8(%rcx), %eax
1400227a6:     	movb	%al, 0x110e(%rbp)
1400227ac:     	movzbl	0x1c9f(%rbp), %eax
1400227b3:     	movb	%al, 0x110f(%rbp)
1400227b9:     	movb	$0x2, 0x10c5(%rbp)
1400227c0:     	movb	$0x2, 0x10cd(%rbp)
1400227c7:     	movq	$0x0, 0x10d0(%rbp)
1400227d2:     	movups	0x1c30(%rbp), %xmm0
1400227d9:     	movups	0x1c40(%rbp), %xmm1

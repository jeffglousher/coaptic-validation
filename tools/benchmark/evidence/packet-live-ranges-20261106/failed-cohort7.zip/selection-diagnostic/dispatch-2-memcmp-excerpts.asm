140026987:     	movq	%rdi, %rdx
14002698a:     	movq	0x1708(%rbp), %r8
140026991:     	callq	0x14001a2d0 <.text+0x192d0>
140026996:     	nop
140026997:     	movaps	0xcc0(%rbp), %xmm0
14002699e:     	movaps	0xcd0(%rbp), %xmm1
1400269a5:     	movq	0x1610(%rbp), %rax
1400269ac:     	movups	%xmm1, 0x10(%rax)
1400269b0:     	movups	%xmm0, (%rax)
1400269b3:     	jmp	0x140027ab7 <.text+0x26ab7>
1400269b8:     	leaq	0x11c8(%rbp), %rdx
1400269bf:     	leaq	0xe68(%rbp), %rbx
1400269c6:     	movl	$0x208, %r8d            # imm = 0x208
1400269cc:     	movq	%rbx, %rcx
1400269cf:     	callq	0x140138f10 <.text+0x137f10>
1400269d4:     	leaq	0x378(%r14), %rdx
1400269db:     	movl	$0x200, %r8d            # imm = 0x200
1400269e1:     	movq	%rbx, %rcx
1400269e4:     	callq	0x140138f28 <.text+0x137f28>
1400269e9:     	testl	%eax, %eax
1400269eb:     	jne	0x14002681a <.text+0x2581a>
1400269f1:     	movq	0x578(%r14), %rax
1400269f8:     	cmpq	%rax, 0x1068(%rbp)
1400269ff:     	jne	0x14002681a <.text+0x2581a>
140026a05:     	cmpb	$0x5, 0x1504(%rbp)
140026a0c:     	je	0x140026a1c <.text+0x25a1c>
140026a0e:     	cmpq	$0x0, 0x14f8(%rbp)
140026a16:     	jne	0x14002681a <.text+0x2581a>
140026a1c:     	cmpb	$0x2, 0x2d(%r14)
140026a21:     	setne	%al
140026a24:     	movzbl	0x153d(%rbp), %r15d
140026a2c:     	cmpb	$0x2, %r15b
140026a30:     	sete	%cl
140026a33:     	cmpb	%cl, %al
140026a35:     	je	0x14002681a <.text+0x2581a>
140026a3b:     	cmpl	$0x2, 0x78(%r14)
140026a40:     	je	0x140026a54 <.text+0x25a54>
140026a42:     	movzbl	0x1535(%rbp), %r8d
140026a4a:     	cmpq	$0x2, %r8
140026a4e:     	jne	0x140027ef7 <.text+0x26ef7>
140026a54:     	movq	0xa0(%r14), %rbx
140026a5b:     	addq	$0xa8, %r14
140027879:     	leaq	0xe62(%rbp), %r12
140027880:     	movl	$0x200, %r8d            # imm = 0x200
140027886:     	movq	%r12, %rcx
140027889:     	movq	%r14, %rdx
14002788c:     	callq	0x140138f10 <.text+0x137f10>
140027891:     	movw	%bx, 0x1062(%rbp)
140027898:     	movw	$0x1, 0xe60(%rbp)
1400278a1:     	movw	$0x1, 0x11c0(%rbp)
1400278aa:     	leaq	0x11c2(%rbp), %r14
1400278b1:     	leaq	-0x10(%rbp), %rdx
1400278b5:     	movl	$0x200, %r8d            # imm = 0x200
1400278bb:     	movq	%r14, %rcx
1400278be:     	callq	0x140138f10 <.text+0x137f10>
1400278c3:     	cmpw	%bx, %r13w
1400278c7:     	jne	0x1400278e2 <.text+0x268e2>
1400278c9:     	movl	$0x200, %r8d            # imm = 0x200
1400278cf:     	movq	%r12, %rcx
1400278d2:     	movq	%r14, %rdx
1400278d5:     	callq	0x140138f28 <.text+0x137f28>
1400278da:     	testl	%eax, %eax
1400278dc:     	je	0x140027f43 <.text+0x26f43>
1400278e2:     	leaq	0x1548(%rbp), %rdx
1400278e9:     	movups	(%rdx), %xmm0
1400278ec:     	movups	0xc(%rdx), %xmm1
1400278f0:     	movups	%xmm1, 0xa04(%rbp)
1400278f7:     	movups	%xmm0, 0x9f8(%rbp)
1400278fe:     	movzbl	0x1575(%rbp), %eax
140027905:     	movb	%al, 0xa25(%rbp)
14002790b:     	movzwl	0x1564(%rbp), %eax
140027912:     	movw	%ax, 0xa14(%rbp)
140027919:     	leaq	0x1576(%rbp), %rcx
140027920:     	movq	(%rcx), %rax
140027923:     	movq	%rax, 0xa26(%rbp)
14002792a:     	movzbl	0x8(%rcx), %eax
14002792e:     	movb	%al, 0xa2e(%rbp)
140027934:     	movzbl	0x157f(%rbp), %eax
14002793b:     	movb	%al, 0xa2f(%rbp)
140027941:     	movb	$0x2, 0x9e5(%rbp)
140027948:     	movb	$0x2, 0x9ed(%rbp)
14002794f:     	movq	$0x0, 0x9f0(%rbp)
14002795a:     	movups	0x1510(%rbp), %xmm0
140027961:     	movups	0x1520(%rbp), %xmm1

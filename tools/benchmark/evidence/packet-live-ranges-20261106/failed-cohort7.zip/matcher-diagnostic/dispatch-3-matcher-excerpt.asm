140026969:     	movq	$0x0, 0x1318(%rbp)
140026974:     	movabsq	$0x5fff000000, %rax     # imm = 0x5FFF000000
14002697e:     	movq	%rax, 0x13ce(%rbp)
140026985:     	movq	$0x0, 0x1398(%rbp)
140026990:     	xorps	%xmm0, %xmm0
140026993:     	movups	%xmm0, 0x1280(%rbp)
14002699a:     	movq	0x16e8(%rbp), %rax
1400269a1:     	movq	%rax, 0x40(%rsp)
1400269a6:     	movq	0x16d0(%rbp), %rax
1400269ad:     	movq	%rax, 0x38(%rsp)
1400269b2:     	movq	0x1708(%rbp), %rax
1400269b9:     	movq	%rax, 0x30(%rsp)
1400269be:     	movq	%r13, 0x28(%rsp)
1400269c3:     	leaq	0xe60(%rbp), %rax
1400269ca:     	movq	%rax, 0x20(%rsp)
1400269cf:     	leaq	0x9c0(%rbp), %rcx
1400269d6:     	movq	0x1620(%rbp), %rdx
1400269dd:     	movq	0x1608(%rbp), %r8
1400269e4:     	movq	0x16c8(%rbp), %r9
1400269eb:     	callq	0x140038e30 <.text+0x37e30>
1400269f0:     	nop
1400269f1:     	jmp	0x1400274a8 <.text+0x264a8>
1400269f6:     	movq	%rdx, %r9
1400269f9:     	leaq	0x378(%r15), %rcx
140026a00:     	leaq	0x14e0(%rbp), %rdx
140026a07:     	callq	0x140017b70 <.text+0x16b70>
140026a0c:     	nop
140026a0d:     	testb	%al, %al
140026a0f:     	je	0x140027dc4 <.text+0x26dc4>
140026a15:     	cmpb	$0x5, 0x1504(%rbp)
140026a1c:     	je	0x140026a2c <.text+0x25a2c>
140026a1e:     	cmpq	$0x0, 0x14f8(%rbp)
140026a26:     	jne	0x140027dc4 <.text+0x26dc4>
140026a2c:     	cmpb	$0x2, 0x2d(%r15)
140026a31:     	setne	%al
140026a34:     	movzbl	0x153d(%rbp), %ebx
140026a3b:     	cmpb	$0x2, %bl
140026a3e:     	sete	%cl
140026a41:     	cmpb	%cl, %al
140026a43:     	je	0x140027dc4 <.text+0x26dc4>
140026a49:     	cmpl	$0x2, 0x78(%r15)
140026a4e:     	je	0x140026a62 <.text+0x25a62>
140026a50:     	movzbl	0x1535(%rbp), %r8d
140026a58:     	cmpq	$0x2, %r8
140026a5c:     	jne	0x140027d7d <.text+0x26d7d>
140026a62:     	movq	0xa0(%r15), %r14
140026a69:     	addq	$0xa8, %r15
140026a70:     	cmpb	$0x2, %bl
140026a73:     	jne	0x1400277fe <.text+0x267fe>
140026a79:     	movq	%rdi, %rcx
140026a7c:     	movq	%r15, %rdx
140026a7f:     	callq	0x1400188c0 <.text+0x178c0>
140026a84:     	nop
140026a85:     	cmpb	$0x0, 0x1575(%rbp)
140026a8c:     	sete	%bl
140026a8f:     	je	0x1400280ec <.text+0x270ec>
140026a95:     	leaq	0xe60(%rbp), %rcx
140026a9c:     	movq	0x16c8(%rbp), %rdx
140026aa3:     	movq	0x1620(%rbp), %r8
140026aaa:     	movq	0x1708(%rbp), %r9

1400d04a0:     	movq	0x7d0(%r13), %rdx
1400d04a7:     	movq	0x868(%r13), %rcx
1400d04ae:     	callq	0x14000ec90 <.text+0xdc90>
1400d04b3:     	movq	0x5d40(%rbp), %rax
1400d04ba:     	movq	0x5d47(%rbp), %rcx
1400d04c1:     	movq	%rax, 0x6448(%rbp)
1400d04c8:     	movq	%rcx, 0x644f(%rbp)
1400d04cf:     	movzbl	0x38(%r13), %esi
1400d04d4:     	cmpb	$0x2, %sil
1400d04d8:     	jne	0x1400d4640 <.text+0xd3640>
1400d04de:     	jmp	0x1400d473d <.text+0xd373d>
1400d04e3:     	movq	0x6488(%rbp), %rcx
1400d04ea:     	movq	%rcx, 0x6400(%rbp)
1400d04f1:     	movq	0x6480(%rbp), %rcx
1400d04f8:     	movq	%rcx, 0x63f8(%rbp)
1400d04ff:     	leaq	0x7910a(%rip), %r9      # 0x140149610
1400d0506:     	movl	$0x5c0, %r8d            # imm = 0x5C0
1400d050c:     	xorl	%ecx, %ecx
1400d050e:     	movq	%rax, %rdx
1400d0511:     	callq	0x140139c30 <.text+0x138c30>
1400d0516:     	nop
1400d0517:     	jmp	0x1400d50c8 <.text+0xd40c8>
1400d051c:     	movq	%rdx, %r9
1400d051f:     	leaq	0x378(%r15), %rcx
1400d0526:     	movq	%rbx, %rdx
1400d0529:     	callq	0x140017b70 <.text+0x16b70>
1400d052e:     	nop
1400d052f:     	testb	%al, %al
1400d0531:     	je	0x1400d0579 <.text+0xcf579>
1400d0533:     	movq	0x6490(%rbp), %rax
1400d053a:     	cmpb	$0x5, 0x114(%rax)
1400d0541:     	je	0x1400d0554 <.text+0xcf554>
1400d0543:     	movq	0x6490(%rbp), %rax
1400d054a:     	cmpq	$0x0, 0x108(%rax)
1400d0552:     	jne	0x1400d0579 <.text+0xcf579>
1400d0554:     	cmpb	$0x2, 0x2d(%r15)
1400d0559:     	setne	%al
1400d055c:     	movq	0x6490(%rbp), %rcx
1400d0563:     	movzbl	0x81d(%rcx), %esi
1400d056a:     	cmpb	$0x2, %sil
1400d056e:     	setne	%cl
1400d0571:     	cmpb	%cl, %al
1400d0573:     	je	0x1400d07dc <.text+0xcf7dc>
1400d0579:     	movq	(%r13), %rbx
1400d057d:     	movq	0x6490(%rbp), %r13
1400d0584:     	movq	0x770(%r13), %rsi
1400d058b:     	movq	0x790(%r13), %r14
1400d0592:     	movq	0x6470(%rbp), %rcx
1400d0599:     	movq	0x70(%rcx), %rax
1400d059d:     	movq	%rax, 0x40f0(%rbp)
1400d05a4:     	movups	0x60(%rcx), %xmm0
1400d05a8:     	movaps	%xmm0, 0x40e0(%rbp)
1400d05af:     	movups	0x50(%rcx), %xmm0
1400d05b3:     	movaps	%xmm0, 0x40d0(%rbp)
1400d05ba:     	movups	0x40(%rcx), %xmm0
1400d05be:     	movaps	%xmm0, 0x40c0(%rbp)
1400d05c5:     	movups	(%rcx), %xmm0
1400d05c8:     	movups	0x10(%rcx), %xmm1
1400d05cc:     	movups	0x20(%rcx), %xmm2
1400d05d0:     	movups	0x30(%rcx), %xmm3


D:\CoapticCurrent\packet-selection-match-20261106\B\retained-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140017b70:     	pushq	%rbp
140017b71:     	pushq	%r15
140017b73:     	pushq	%r14
140017b75:     	pushq	%r13
140017b77:     	pushq	%r12
140017b79:     	pushq	%rsi
140017b7a:     	pushq	%rdi
140017b7b:     	pushq	%rbx
140017b7c:     	subq	$0x88, %rsp
140017b83:     	leaq	0x80(%rsp), %rbp
140017b8b:     	movq	0x200(%rcx), %r10
140017b92:     	cmpq	$0x200, %r10            # imm = 0x200
140017b99:     	ja	0x140017d19 <.text+0x16d19>
140017b9f:     	cmpq	$0x4, %r10
140017ba3:     	jb	0x140017d19 <.text+0x16d19>
140017ba9:     	movzbl	(%rcx), %r15d
140017bad:     	movl	%r15d, %eax
140017bb0:     	andb	$-0x40, %al
140017bb2:     	cmpb	$0x40, %al
140017bb4:     	jne	0x140017d19 <.text+0x16d19>
140017bba:     	movl	%r15d, %edi
140017bbd:     	andl	$0xf, %edi
140017bc0:     	movzbl	0x1(%rcx), %r14d
140017bc5:     	movzwl	0x2(%rcx), %r12d
140017bca:     	cmpb	$0xd, %dil
140017bce:     	jae	0x140017c3b <.text+0x16c3b>
140017bd0:     	movl	$0x4, %r13d
140017bd6:     	movq	%rdi, %rsi
140017bd9:     	leaq	(%rsi,%r13), %r11
140017bdd:     	cmpq	%r10, %r11
140017be0:     	ja	0x140017d19 <.text+0x16d19>
140017be6:     	testb	%r14b, %r14b
140017be9:     	je	0x140017c8e <.text+0x16c8e>
140017bef:     	movq	%r9, -0x38(%rbp)
140017bf3:     	movq	%r8, %rbx
140017bf6:     	movq	%rdx, %rdi
140017bf9:     	leaq	-0x30(%rbp), %rax
140017bfd:     	movq	%rcx, %rdx
140017c00:     	movq	%rax, %rcx
140017c03:     	movq	%rdx, -0x8(%rbp)
140017c07:     	movq	%r10, %r8
140017c0a:     	movq	%r11, %r9
140017c0d:     	callq	0x14000c730 <.text+0xb730>
140017c12:     	movq	-0x30(%rbp), %r10
140017c16:     	testq	%r10, %r10
140017c19:     	je	0x140017d19 <.text+0x16d19>
140017c1f:     	movq	-0x28(%rbp), %r11
140017c23:     	movq	-0x20(%rbp), %rcx
140017c27:     	movq	-0x18(%rbp), %rax
140017c2b:     	movq	%rax, (%rbp)
140017c2f:     	movq	%rdi, %rdx
140017c32:     	movq	%rbx, %r8
140017c35:     	movq	-0x38(%rbp), %r9
140017c39:     	jmp	0x140017cb8 <.text+0x16cb8>
140017c3b:     	je	0x140017c71 <.text+0x16c71>
140017c3d:     	movzbl	%dil, %eax
140017c41:     	cmpl	$0xe, %eax
140017c44:     	jne	0x140017d19 <.text+0x16d19>
140017c4a:     	cmpq	$0x5, %r10
140017c4e:     	jbe	0x140017d19 <.text+0x16d19>
140017c54:     	movzwl	0x4(%rcx), %eax
140017c58:     	rolw	$0x8, %ax
140017c5c:     	movzwl	%ax, %esi
140017c5f:     	addq	$0x10d, %rsi            # imm = 0x10D
140017c66:     	movl	$0x6, %r13d
140017c6c:     	jmp	0x140017bd9 <.text+0x16bd9>
140017c71:     	cmpq	$0x4, %r10
140017c75:     	je	0x140017d19 <.text+0x16d19>
140017c7b:     	movzbl	0x4(%rcx), %esi
140017c7f:     	addq	$0xd, %rsi
140017c83:     	movl	$0x5, %r13d
140017c89:     	jmp	0x140017bd9 <.text+0x16bd9>
140017c8e:     	xorl	%eax, %eax
140017c90:     	testb	%dil, %dil
140017c93:     	jne	0x140017d1b <.text+0x16d1b>
140017c99:     	cmpq	%r10, %r11
140017c9c:     	jne	0x140017d1b <.text+0x16d1b>
140017c9e:     	movq	%rcx, -0x8(%rbp)
140017ca2:     	movl	$0x1, %ecx
140017ca7:     	movq	$0x0, (%rbp)
140017caf:     	xorl	%r11d, %r11d
140017cb2:     	movl	$0x1, %r10d
140017cb8:     	andb	$0x30, %r15b
140017cbc:     	xorl	%eax, %eax
140017cbe:     	cmpb	$0x10, %r15b
140017cc2:     	jne	0x140017d1b <.text+0x16d1b>
140017cc4:     	movq	%rcx, %rbx
140017cc7:     	testw	%r12w, %r12w
140017ccb:     	movq	-0x8(%rbp), %rcx
140017ccf:     	jne	0x140017d1b <.text+0x16d1b>
140017cd1:     	cmpb	0x24(%rdx), %r14b
140017cd5:     	jne	0x140017d1b <.text+0x16d1b>
140017cd7:     	movq	0x26(%rdx), %rax
140017cdb:     	movq	%rax, -0x30(%rbp)
140017cdf:     	movzbl	0x2e(%rdx), %eax
140017ce3:     	movb	%al, -0x28(%rbp)
140017ce6:     	cmpq	$0x9, %rax
140017cea:     	jae	0x140017da4 <.text+0x16da4>
140017cf0:     	cmpl	%eax, %esi
140017cf2:     	jne	0x140017d19 <.text+0x16d19>
140017cf4:     	addq	%r13, %rcx
140017cf7:     	leaq	-0x30(%rbp), %rax
140017cfb:     	movq	%rdx, %r13
140017cfe:     	movq	%rax, %rdx
140017d01:     	movq	%r8, %rdi
140017d04:     	movq	%rsi, %r8
140017d07:     	movq	%r9, %rsi
140017d0a:     	movq	%r10, %r15
140017d0d:     	movq	%r11, %r12
140017d10:     	callq	0x140139188 <.text+0x138188>
140017d15:     	testl	%eax, %eax
140017d17:     	je	0x140017d2f <.text+0x16d2f>
140017d19:     	xorl	%eax, %eax
140017d1b:     	addq	$0x88, %rsp
140017d22:     	popq	%rbx
140017d23:     	popq	%rdi
140017d24:     	popq	%rsi
140017d25:     	popq	%r12
140017d27:     	popq	%r13
140017d29:     	popq	%r14
140017d2b:     	popq	%r15
140017d2d:     	popq	%rbp
140017d2e:     	retq
140017d2f:     	movq	%rsi, %rdx
140017d32:     	xorl	%eax, %eax
140017d34:     	cmpb	$0x5, %r14b
140017d38:     	cmovneq	%rax, %rdx
140017d3c:     	cmpq	%rdx, (%rbp)
140017d40:     	jne	0x140017d1b <.text+0x16d1b>
140017d42:     	cmpb	$0x5, %r14b
140017d46:     	movl	$0x1, %edx
140017d4b:     	cmoveq	%rdi, %rdx
140017d4f:     	movq	%rbx, %rcx
140017d52:     	movq	(%rbp), %r8
140017d56:     	callq	0x140139188 <.text+0x138188>
140017d5b:     	testl	%eax, %eax
140017d5d:     	jne	0x140017d19 <.text+0x16d19>
140017d5f:     	movq	%r15, -0x58(%rbp)
140017d63:     	movq	%r12, -0x50(%rbp)
140017d67:     	movq	$0x0, -0x48(%rbp)
140017d6f:     	movl	$0x0, -0x40(%rbp)
140017d76:     	movups	(%r13), %xmm0
140017d7b:     	movups	%xmm0, -0x30(%rbp)
140017d7f:     	movq	$0x0, -0x20(%rbp)
140017d87:     	movl	$0x0, -0x18(%rbp)
140017d8e:     	movq	%r13, -0x10(%rbp)
140017d92:     	leaq	-0x58(%rbp), %rcx
140017d96:     	leaq	-0x30(%rbp), %rdx
140017d9a:     	callq	0x14008f930 <.text+0x8e930>
140017d9f:     	jmp	0x140017d1b <.text+0x16d1b>
140017da4:     	leaq	0x12ba75(%rip), %r9     # 0x140143820
140017dab:     	movl	$0x8, %r8d
140017db1:     	xorl	%ecx, %ecx
140017db3:     	movq	%rax, %rdx
140017db6:     	callq	0x140139c30 <.text+0x138c30>
140017dbb:     	ud2

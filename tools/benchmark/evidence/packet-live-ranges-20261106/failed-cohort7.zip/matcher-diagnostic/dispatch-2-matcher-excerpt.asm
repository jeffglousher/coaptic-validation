140021354:     	movq	$0x0, 0x1558(%rbp)
14002135f:     	movabsq	$0x5fff000000, %rax     # imm = 0x5FFF000000
140021369:     	movq	%rax, 0x160e(%rbp)
140021370:     	movq	$0x0, 0x15d8(%rbp)
14002137b:     	xorps	%xmm0, %xmm0
14002137e:     	movups	%xmm0, 0x14c0(%rbp)
140021385:     	movq	0x1e38(%rbp), %rax
14002138c:     	movq	%rax, 0x40(%rsp)
140021391:     	movq	0x1e20(%rbp), %rax
140021398:     	movq	%rax, 0x38(%rsp)
14002139d:     	movq	0x1e58(%rbp), %rax
1400213a4:     	movq	%rax, 0x30(%rsp)
1400213a9:     	movq	%rbx, 0x28(%rsp)
1400213ae:     	leaq	0x970(%rbp), %rax
1400213b5:     	movq	%rax, 0x20(%rsp)
1400213ba:     	leaq	0x10a0(%rbp), %rcx
1400213c1:     	movq	0x1d70(%rbp), %rdx
1400213c8:     	movq	0x1d50(%rbp), %r8
1400213cf:     	movq	0x1e18(%rbp), %r9
1400213d6:     	callq	0x140038770 <.text+0x37770>
1400213db:     	nop
1400213dc:     	jmp	0x14002208b <.text+0x2108b>
1400213e1:     	movq	%rdx, %r9
1400213e4:     	leaq	0x378(%r15), %rcx
1400213eb:     	leaq	0x1bf8(%rbp), %rdx
1400213f2:     	callq	0x140017b70 <.text+0x16b70>
1400213f7:     	nop
1400213f8:     	testb	%al, %al
1400213fa:     	je	0x140022d8c <.text+0x21d8c>
140021400:     	cmpb	$0x5, 0x1c1c(%rbp)
140021407:     	je	0x140021417 <.text+0x20417>
140021409:     	cmpq	$0x0, 0x1c10(%rbp)
140021411:     	jne	0x140022d8c <.text+0x21d8c>
140021417:     	cmpb	$0x2, 0x2d(%r15)
14002141c:     	setne	%al
14002141f:     	movzbl	0x1c5d(%rbp), %esi
140021426:     	cmpb	$0x2, %sil
14002142a:     	sete	%cl
14002142d:     	cmpb	%cl, %al
14002142f:     	je	0x140022d8c <.text+0x21d8c>
140021435:     	cmpl	$0x2, 0x78(%r15)
14002143a:     	je	0x14002144e <.text+0x2044e>
14002143c:     	movzbl	0x1c55(%rbp), %r8d
140021444:     	cmpq	$0x2, %r8
140021448:     	jne	0x140022d45 <.text+0x21d45>
14002144e:     	movq	0xa0(%r15), %r14
140021455:     	addq	$0xa8, %r15
14002145c:     	cmpb	$0x2, %sil
140021460:     	jne	0x140022625 <.text+0x21625>
140021466:     	movq	%rbx, %rcx
140021469:     	movq	%r15, %rdx
14002146c:     	callq	0x1400188c0 <.text+0x178c0>
140021471:     	nop
140021472:     	cmpb	$0x0, 0x1c95(%rbp)
140021479:     	sete	%sil
14002147d:     	je	0x140023163 <.text+0x22163>
140021483:     	leaq	0x970(%rbp), %rcx
14002148a:     	movq	0x1e18(%rbp), %rdx
140021491:     	movq	0x1d70(%rbp), %r8
140021498:     	movq	0x1e58(%rbp), %r9

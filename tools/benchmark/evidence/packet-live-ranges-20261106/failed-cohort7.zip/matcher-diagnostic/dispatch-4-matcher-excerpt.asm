1400bc785:     	movq	%rax, 0x5160(%rbp)
1400bc78c:     	movq	0x39b2(%rbp), %rax
1400bc793:     	movq	%rax, 0x5080(%rbp)
1400bc79a:     	movq	0x39b8(%rbp), %rax
1400bc7a1:     	movq	%rax, 0x5086(%rbp)
1400bc7a8:     	movq	0x39c0(%rbp), %r15
1400bc7af:     	movq	0x39c8(%rbp), %xmm6
1400bc7b7:     	movq	0x5168(%rbp), %rcx
1400bc7be:     	callq	0x14005e900 <.text+0x5d900>
1400bc7c3:     	nop
1400bc7c4:     	jmp	0x1400bcf4e <.text+0xbbf4e>
1400bc7c9:     	movq	0x5168(%rbp), %rcx
1400bc7d0:     	movq	%rcx, 0x5108(%rbp)
1400bc7d7:     	movq	0x5158(%rbp), %rcx
1400bc7de:     	movq	%rcx, 0x5100(%rbp)
1400bc7e5:     	leaq	0x8ce24(%rip), %r9      # 0x140149610
1400bc7ec:     	movl	$0x5c0, %r8d            # imm = 0x5C0
1400bc7f2:     	xorl	%ecx, %ecx
1400bc7f4:     	movq	%rax, %rdx
1400bc7f7:     	callq	0x140139c30 <.text+0x138c30>
1400bc7fc:     	nop
1400bc7fd:     	jmp	0x1400c0a9b <.text+0xbfa9b>
1400bc802:     	movq	%rdx, %r9
1400bc805:     	leaq	0x378(%r15), %rcx
1400bc80c:     	movq	0x5158(%rbp), %rdx
1400bc813:     	callq	0x140017b70 <.text+0x16b70>
1400bc818:     	nop
1400bc819:     	testb	%al, %al
1400bc81b:     	je	0x1400bc863 <.text+0xbb863>
1400bc81d:     	movq	0x5170(%rbp), %rax
1400bc824:     	cmpb	$0x5, 0x114(%rax)
1400bc82b:     	je	0x1400bc83e <.text+0xbb83e>
1400bc82d:     	movq	0x5170(%rbp), %rax
1400bc834:     	cmpq	$0x0, 0x108(%rax)
1400bc83c:     	jne	0x1400bc863 <.text+0xbb863>
1400bc83e:     	cmpb	$0x2, 0x2d(%r15)
1400bc843:     	setne	%al
1400bc846:     	movq	0x5170(%rbp), %rcx
1400bc84d:     	movzbl	0x81d(%rcx), %esi
1400bc854:     	cmpb	$0x2, %sil
1400bc858:     	setne	%cl
1400bc85b:     	cmpb	%cl, %al
1400bc85d:     	je	0x1400bcdd6 <.text+0xbbdd6>
1400bc863:     	movq	0x5120(%rbp), %rax
1400bc86a:     	movq	(%rax), %rbx
1400bc86d:     	movq	0x5170(%rbp), %r12
1400bc874:     	movq	0x770(%r12), %rsi
1400bc87c:     	movq	0x790(%r12), %r14
1400bc884:     	movq	0x5138(%rbp), %rcx
1400bc88b:     	movq	0x70(%rcx), %rax
1400bc88f:     	movq	%rax, 0x3a20(%rbp)
1400bc896:     	movups	0x60(%rcx), %xmm0
1400bc89a:     	movaps	%xmm0, 0x3a10(%rbp)
1400bc8a1:     	movups	0x50(%rcx), %xmm0
1400bc8a5:     	movaps	%xmm0, 0x3a00(%rbp)
1400bc8ac:     	movups	0x40(%rcx), %xmm0
1400bc8b0:     	movaps	%xmm0, 0x39f0(%rbp)
1400bc8b7:     	movups	(%rcx), %xmm0
1400bc8ba:     	movups	0x10(%rcx), %xmm1
1400bc8be:     	movups	0x20(%rcx), %xmm2

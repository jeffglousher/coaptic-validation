
D:\CoapticCurrent\packet-selection-match-20261106\B\retained-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14000c730:     	pushq	%rbp
14000c731:     	pushq	%r15
14000c733:     	pushq	%r14
14000c735:     	pushq	%r13
14000c737:     	pushq	%r12
14000c739:     	pushq	%rsi
14000c73a:     	pushq	%rdi
14000c73b:     	pushq	%rbx
14000c73c:     	movq	%rsp, %rbp
14000c73f:     	xorl	%r10d, %r10d
14000c742:     	movl	$0x3, %r11d
14000c748:     	movl	$0x2, %esi
14000c74d:     	movl	$0x1, %edi
14000c752:     	movq	%r9, %r15
14000c755:     	cmpq	%r8, %r15
14000c758:     	jae	0x14000c878 <.text+0xb878>
14000c75e:     	movq	%r12, %rax
14000c761:     	movzbl	(%rdx,%r15), %r12d
14000c766:     	leaq	0x1(%r15), %rbx
14000c76a:     	cmpl	$0xff, %r12d
14000c771:     	je	0x14000c899 <.text+0xb899>
14000c777:     	movl	%r12d, %r14d
14000c77a:     	shrl	$0x4, %r14d
14000c77e:     	cmpl	$0xf, %r14d
14000c782:     	je	0x14000c8a6 <.text+0xb8a6>
14000c788:     	andb	$0xf, %r12b
14000c78c:     	cmpb	$0xf, %r12b
14000c790:     	je	0x14000c8b2 <.text+0xb8b2>
14000c796:     	cmpb	$0xe, %r14b
14000c79a:     	je	0x14000c7c0 <.text+0xb7c0>
14000c79c:     	movzbl	%r14b, %r13d
14000c7a0:     	cmpl	$0xd, %r13d
14000c7a4:     	jne	0x14000c7f3 <.text+0xb7f3>
14000c7a6:     	cmpq	%rbx, %r8
14000c7a9:     	jbe	0x14000c86c <.text+0xb86c>
14000c7af:     	movzbl	(%rdx,%rbx), %r14d
14000c7b4:     	addl	$0xd, %r14d
14000c7b8:     	addq	%rsi, %r15
14000c7bb:     	jmp	0x14000c7f0 <.text+0xb7f0>
14000c7bd:     	nopl	(%rax)
14000c7c0:     	leaq	0x2(%r15), %r14
14000c7c4:     	cmpq	%r8, %r14
14000c7c7:     	jae	0x14000c86c <.text+0xb86c>
14000c7cd:     	movzbl	(%rdx,%rbx), %ebx
14000c7d1:     	movzbl	(%rdx,%r14), %r14d
14000c7d6:     	shll	$0x8, %r14d
14000c7da:     	orl	%ebx, %r14d
14000c7dd:     	rolw	$0x8, %r14w
14000c7e2:     	movzwl	%r14w, %r14d
14000c7e6:     	addl	$0x10d, %r14d           # imm = 0x10D
14000c7ed:     	addq	%r11, %r15
14000c7f0:     	movq	%r15, %rbx
14000c7f3:     	cmpb	$0xe, %r12b
14000c7f7:     	je	0x14000c830 <.text+0xb830>
14000c7f9:     	movzbl	%r12b, %r12d
14000c7fd:     	cmpl	$0xd, %r12d
14000c801:     	jne	0x14000c814 <.text+0xb814>
14000c803:     	cmpq	%r8, %rbx
14000c806:     	jae	0x14000c86c <.text+0xb86c>
14000c808:     	movzbl	(%rdx,%rbx), %r12d
14000c80d:     	addq	$0xd, %r12
14000c811:     	addq	%rdi, %rbx
14000c814:     	addl	%r14d, %r10d
14000c817:     	cmpl	$0xffff, %r10d          # imm = 0xFFFF
14000c81e:     	jbe	0x14000c85d <.text+0xb85d>
14000c820:     	jmp	0x14000c8be <.text+0xb8be>
14000c825:     	nopw	%cs:(%rax,%rax)
14000c830:     	leaq	0x1(%rbx), %r15
14000c834:     	cmpq	%r8, %r15
14000c837:     	jae	0x14000c86c <.text+0xb86c>
14000c839:     	movzwl	(%rdx,%rbx), %r15d
14000c83e:     	rolw	$0x8, %r15w
14000c843:     	movzwl	%r15w, %r12d
14000c847:     	addq	$0x10d, %r12            # imm = 0x10D
14000c84e:     	addq	%rsi, %rbx
14000c851:     	addl	%r14d, %r10d
14000c854:     	cmpl	$0xffff, %r10d          # imm = 0xFFFF
14000c85b:     	ja	0x14000c8be <.text+0xb8be>
14000c85d:     	addq	%r12, %rbx
14000c860:     	movq	%rbx, %r15
14000c863:     	cmpq	%r8, %rbx
14000c866:     	jbe	0x14000c755 <.text+0xb755>
14000c86c:     	andq	$-0x10000, %rax         # imm = 0xFFFF0000
14000c872:     	orq	$0x4, %rax
14000c876:     	jmp	0x14000c8c3 <.text+0xb8c3>
14000c878:     	subq	%r9, %r8
14000c87b:     	jb	0x14000c8df <.text+0xb8df>
14000c87d:     	addq	%r9, %rdx
14000c880:     	movq	%rdx, (%rcx)
14000c883:     	movq	%r8, 0x8(%rcx)
14000c887:     	movq	$0x1, 0x10(%rcx)
14000c88f:     	movq	$0x0, 0x18(%rcx)
14000c897:     	jmp	0x14000c8cd <.text+0xb8cd>
14000c899:     	subq	%rbx, %r8
14000c89c:     	jne	0x14000c8da <.text+0xb8da>
14000c89e:     	movw	$0x9, 0x8(%rcx)
14000c8a4:     	jmp	0x14000c8c6 <.text+0xb8c6>
14000c8a6:     	andq	$-0x10000, %rax         # imm = 0xFFFF0000
14000c8ac:     	orq	$0x5, %rax
14000c8b0:     	jmp	0x14000c8c3 <.text+0xb8c3>
14000c8b2:     	andq	$-0x10000, %rax         # imm = 0xFFFF0000
14000c8b8:     	orq	$0x6, %rax
14000c8bc:     	jmp	0x14000c8c3 <.text+0xb8c3>
14000c8be:     	movl	$0x7, %eax
14000c8c3:     	movl	%eax, 0x8(%rcx)
14000c8c6:     	movq	$0x0, (%rcx)
14000c8cd:     	popq	%rbx
14000c8ce:     	popq	%rdi
14000c8cf:     	popq	%rsi
14000c8d0:     	popq	%r12
14000c8d2:     	popq	%r13
14000c8d4:     	popq	%r14
14000c8d6:     	popq	%r15
14000c8d8:     	popq	%rbp
14000c8d9:     	retq
14000c8da:     	subq	%r9, %r15
14000c8dd:     	jae	0x14000c8e8 <.text+0xb8e8>
14000c8df:     	movl	$0x4, 0x8(%rcx)
14000c8e6:     	jmp	0x14000c8c6 <.text+0xb8c6>
14000c8e8:     	addq	%rdx, %r9
14000c8eb:     	addq	%rdx, %rbx
14000c8ee:     	movq	%r9, (%rcx)
14000c8f1:     	movq	%r15, 0x8(%rcx)
14000c8f5:     	movq	%rbx, 0x10(%rcx)
14000c8f9:     	movq	%r8, 0x18(%rcx)
14000c8fd:     	jmp	0x14000c8cd <.text+0xb8cd>

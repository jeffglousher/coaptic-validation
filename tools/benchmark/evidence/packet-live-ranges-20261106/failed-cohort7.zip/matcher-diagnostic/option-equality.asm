
D:\CoapticCurrent\packet-selection-match-20261106\B\retained-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14008f930:     	pushq	%rbp
14008f931:     	pushq	%r15
14008f933:     	pushq	%r14
14008f935:     	pushq	%r13
14008f937:     	pushq	%r12
14008f939:     	pushq	%rsi
14008f93a:     	pushq	%rdi
14008f93b:     	pushq	%rbx
14008f93c:     	subq	$0x98, %rsp
14008f943:     	leaq	0x80(%rsp), %rbp
14008f94b:     	movups	(%rcx), %xmm0
14008f94e:     	movups	0x10(%rcx), %xmm1
14008f952:     	movaps	%xmm1, -0x40(%rbp)
14008f956:     	movaps	%xmm0, -0x50(%rbp)
14008f95a:     	movq	0x20(%rdx), %rax
14008f95e:     	movq	%rax, -0x10(%rbp)
14008f962:     	movups	(%rdx), %xmm0
14008f965:     	movups	0x10(%rdx), %xmm1
14008f969:     	movaps	%xmm1, -0x20(%rbp)
14008f96d:     	movaps	%xmm0, -0x30(%rbp)
14008f971:     	leaq	-0x20(%rbp), %rsi
14008f975:     	leaq	-0x18(%rbp), %r13
14008f979:     	movq	%rbp, %rbx
14008f97c:     	movq	-0x48(%rbp), %r8
14008f980:     	cmpq	%r8, -0x40(%rbp)
14008f984:     	jae	0x14008fa42 <.text+0x8ea42>
14008f98a:     	movq	-0x50(%rbp), %rdx
14008f98e:     	leaq	-0x38(%rbp), %rax
14008f992:     	movq	%rax, 0x20(%rsp)
14008f997:     	movq	%rbx, %rcx
14008f99a:     	leaq	-0x40(%rbp), %r9
14008f99e:     	callq	0x14000cc50 <.text+0xbc50>
14008f9a3:     	movq	(%rbp), %r15
14008f9a7:     	testq	%r15, %r15
14008f9aa:     	je	0x14008fa42 <.text+0x8ea42>
14008f9b0:     	movq	0x8(%rbp), %r12
14008f9b4:     	movzwl	0x10(%rbp), %edi
14008f9b8:     	movq	-0x10(%rbp), %r14
14008f9bc:     	movq	-0x28(%rbp), %r8
14008f9c0:     	cmpq	%r8, -0x20(%rbp)
14008f9c4:     	jae	0x14008fa28 <.text+0x8ea28>
14008f9c6:     	movq	-0x30(%rbp), %rdx
14008f9ca:     	movq	%r13, 0x20(%rsp)
14008f9cf:     	movq	%rbx, %rcx
14008f9d2:     	movq	%rsi, %r9
14008f9d5:     	callq	0x14000cc50 <.text+0xbc50>
14008f9da:     	movq	(%rbp), %rdx
14008f9de:     	testq	%rdx, %rdx
14008f9e1:     	je	0x14008fa28 <.text+0x8ea28>
14008f9e3:     	movq	0x8(%rbp), %rax
14008f9e7:     	movzwl	0x10(%rbp), %ecx
14008f9eb:     	cmpl	$0x4, %ecx
14008f9ee:     	jne	0x14008f9f7 <.text+0x8e9f7>
14008f9f0:     	cmpb	$0x5, 0x24(%r14)
14008f9f5:     	je	0x14008fa08 <.text+0x8ea08>
14008f9f7:     	cmpl	$0x11, %ecx
14008f9fa:     	ja	0x14008f9bc <.text+0x8e9bc>
14008f9fc:     	movl	$0x29822, %r8d          # imm = 0x29822
14008fa02:     	btl	%ecx, %r8d
14008fa06:     	jae	0x14008f9bc <.text+0x8e9bc>
14008fa08:     	xorl	%r14d, %r14d
14008fa0b:     	cmpw	%cx, %di
14008fa0e:     	jne	0x14008fa2b <.text+0x8ea2b>
14008fa10:     	cmpq	%rax, %r12
14008fa13:     	jne	0x14008fa2b <.text+0x8ea2b>
14008fa15:     	movq	%r15, %rcx
14008fa18:     	movq	%r12, %r8
14008fa1b:     	callq	0x140139188 <.text+0x138188>
14008fa20:     	testl	%eax, %eax
14008fa22:     	je	0x14008f97c <.text+0x8e97c>
14008fa28:     	xorl	%r14d, %r14d
14008fa2b:     	movl	%r14d, %eax
14008fa2e:     	addq	$0x98, %rsp
14008fa35:     	popq	%rbx
14008fa36:     	popq	%rdi
14008fa37:     	popq	%rsi
14008fa38:     	popq	%r12
14008fa3a:     	popq	%r13
14008fa3c:     	popq	%r14
14008fa3e:     	popq	%r15
14008fa40:     	popq	%rbp
14008fa41:     	retq
14008fa42:     	movq	-0x10(%rbp), %rbx
14008fa46:     	movq	%rbp, %rdi
14008fa49:     	movl	$0x29822, %r15d         # imm = 0x29822
14008fa4f:     	movq	-0x28(%rbp), %r8
14008fa53:     	cmpq	%r8, -0x20(%rbp)
14008fa57:     	setae	%r14b
14008fa5b:     	jae	0x14008fa2b <.text+0x8ea2b>
14008fa5d:     	movq	-0x30(%rbp), %rdx
14008fa61:     	movq	%r13, 0x20(%rsp)
14008fa66:     	movq	%rdi, %rcx
14008fa69:     	movq	%rsi, %r9
14008fa6c:     	callq	0x14000cc50 <.text+0xbc50>
14008fa71:     	cmpq	$0x0, (%rbp)
14008fa76:     	je	0x14008fa94 <.text+0x8ea94>
14008fa78:     	movzwl	0x10(%rbp), %eax
14008fa7c:     	cmpl	$0x4, %eax
14008fa7f:     	jne	0x14008fa87 <.text+0x8ea87>
14008fa81:     	cmpb	$0x5, 0x24(%rbx)
14008fa85:     	je	0x14008fa2b <.text+0x8ea2b>
14008fa87:     	cmpl	$0x11, %eax
14008fa8a:     	ja	0x14008fa4f <.text+0x8ea4f>
14008fa8c:     	btl	%eax, %r15d
14008fa90:     	jae	0x14008fa4f <.text+0x8ea4f>
14008fa92:     	jmp	0x14008fa2b <.text+0x8ea2b>
14008fa94:     	movb	$0x1, %r14b
14008fa97:     	jmp	0x14008fa2b <.text+0x8ea2b>

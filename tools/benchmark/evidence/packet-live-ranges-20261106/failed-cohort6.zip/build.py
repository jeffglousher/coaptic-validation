from pathlib import Path
import os,subprocess,shutil,json
root=Path(__file__).resolve().parent
repo=Path('C:/Users/jeffg/.t3/worktrees/coaptic/t3-a578955c')
fixture=Path('D:/CoapticCurrent/replay-active-copy-20261105/fixture/probe')
lane=Path('D:/coaptic-batch-interop-target')
wrapper=str(Path.home()/'.cargo/bin/agent-resources.exe')
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR=str(lane));env.pop('RUSTC_BOOTSTRAP',None);env.pop('RUSTFLAGS',None)
commands=[('ordinary',fixture,['build','--locked','--offline','--release','--bin','dispatch-probe']),('retained',fixture,['build','--locked','--offline','--release','--bin','retained-probe','--features','oscore,alloc'])]
results=[]
for label,cwd,args in commands:
 if label!='tests':env['RUSTFLAGS']='-Cforce-frame-pointers=yes'
 with (root/(label+'.log')).open('wb') as log:
  p=subprocess.run([wrapper,'run','--id','coaptic-core-reusable','--directory',str(cwd),'--','cargo',*args],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(label=label,exit_code=p.returncode));(root/'build-results.json').write_text(json.dumps(results,indent=2));print(results[-1],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 if label!='tests':
  stem='dispatch' if label=='ordinary' else 'retained'
  for ext in ['exe','pdb']:
   src=lane/'release'/(stem+('_probe' if ext=='pdb' else '-probe')+'.'+ext)
   shutil.copyfile(src,root/'B'/(stem+'-probe.'+ext))


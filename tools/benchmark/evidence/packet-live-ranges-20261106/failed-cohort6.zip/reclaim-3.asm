
D:\CoapticCurrent\packet-lazy-staged-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140095cd0:     	pushq	%rbp
140095cd1:     	pushq	%r15
140095cd3:     	pushq	%r14
140095cd5:     	pushq	%r13
140095cd7:     	pushq	%r12
140095cd9:     	pushq	%rsi
140095cda:     	pushq	%rdi
140095cdb:     	pushq	%rbx
140095cdc:     	subq	$0x308, %rsp            # imm = 0x308
140095ce3:     	leaq	0x80(%rsp), %rbp
140095ceb:     	movaps	%xmm7, 0x270(%rbp)
140095cf2:     	movaps	%xmm6, 0x260(%rbp)
140095cf9:     	leaq	0x5000(%rcx), %rax
140095d00:     	leaq	0x30(%rcx), %r8
140095d04:     	xorl	%r9d, %r9d
140095d07:     	xorl	%esi, %esi
140095d09:     	leaq	(%rsi,%rsi,4), %r11
140095d0d:     	shlq	$0x6, %r11
140095d11:     	addq	%r8, %r11
140095d14:     	movq	%rsi, %r10
140095d17:     	jmp	0x140095d34 <.text+0x94d34>
140095d19:     	nopl	(%rax)
140095d20:     	incq	%r10
140095d23:     	addq	$0x140, %r11            # imm = 0x140
140095d2a:     	cmpq	$0x40, %r10
140095d2e:     	je	0x140095dce <.text+0x94dce>
140095d34:     	cmpb	$0x1, 0x5000(%rcx,%r10)
140095d3d:     	jne	0x140095d20 <.text+0x94d20>
140095d3f:     	movq	-0x30(%r11), %rdi
140095d43:     	cmpq	$0x2, %rdi
140095d47:     	je	0x140095d20 <.text+0x94d20>
140095d49:     	movq	(%r11), %rsi
140095d4c:     	cmpl	$0x1, %edi
140095d4f:     	setne	%bl
140095d52:     	testq	%rsi, %rsi
140095d55:     	sete	%dil
140095d59:     	orb	%bl, %dil
140095d5c:     	cmpb	$0x1, %dil
140095d60:     	je	0x140095d20 <.text+0x94d20>
140095d62:     	movq	0x250(%rbp), %rdi
140095d69:     	cmpq	%rdi, %rsi
140095d6c:     	setae	%bl
140095d6f:     	testb	%bl, %r9b
140095d72:     	jne	0x140095db4 <.text+0x94db4>
140095d74:     	movd	-0x4(%r11), %xmm6
140095d7a:     	movzbl	-0x5(%r11), %edx
140095d7f:     	movb	%dl, 0x25f(%rbp)
140095d85:     	movzbl	-0x6(%r11), %r15d
140095d8a:     	movzwl	-0x8(%r11), %r12d
140095d8f:     	movl	-0xc(%r11), %r13d
140095d93:     	movl	-0x10(%r11), %r14d
140095d97:     	movq	-0x18(%r11), %rdx
140095d9b:     	movq	%rdx, 0x248(%rbp)
140095da2:     	movq	-0x28(%r11), %rdx
140095da6:     	movq	-0x20(%r11), %r9
140095daa:     	movq	%r9, 0x240(%rbp)
140095db1:     	movq	%rsi, %rdi
140095db4:     	movq	%rdi, 0x250(%rbp)
140095dbb:     	leaq	0x1(%r10), %rsi
140095dbf:     	movb	$0x1, %r9b
140095dc2:     	cmpq	$0x3f, %r10
140095dc6:     	jb	0x140095d09 <.text+0x94d09>
140095dcc:     	jmp	0x140095dd8 <.text+0x94dd8>
140095dce:     	testb	$0x1, %r9b
140095dd2:     	je	0x140096050 <.text+0x95050>
140095dd8:     	cmpq	$0x1f, %rdx
140095ddc:     	ja	0x140095e2f <.text+0x94e2f>
140095dde:     	leaq	0x37740(%rcx), %r8
140095de5:     	cmpb	$0x1, (%r8,%rdx)
140095dea:     	jne	0x140095e2f <.text+0x94e2f>
140095dec:     	cmpb	$0x0, 0x37760(%rcx,%rdx)
140095df4:     	jne	0x140095e2f <.text+0x94e2f>
140095df6:     	movb	$0x0, 0x37740(%rcx,%rdx)
140095dfe:     	decq	0x37788(%rcx)
140095e05:     	movq	$0x0, 0x43610(%rcx,%rdx,8)
140095e11:     	leaq	(%rdx,%rdx,8), %r9
140095e15:     	leaq	(%r9,%r9,2), %r9
140095e19:     	addq	%rdx, %r9
140095e1c:     	movb	$0x2, 0x36a(%r8,%r9)
140095e25:     	leaq	(%rdx,%rdx,2), %rdx
140095e29:     	movb	$0x2, 0x5d(%r8,%rdx,8)
140095e2f:     	movd	%xmm6, %edx
140095e33:     	movl	$0x2c, %r8d
140095e39:     	movq	0x240(%rbp), %r11
140095e40:     	movq	0x248(%rbp), %rsi
140095e47:     	jmp	0x140095e63 <.text+0x94e63>
140095e49:     	nopl	(%rax)
140095e50:     	incq	%rax
140095e53:     	addq	$0x140, %r8             # imm = 0x140
140095e5a:     	cmpq	$0x502c, %r8            # imm = 0x502C
140095e61:     	je	0x140095ebc <.text+0x94ebc>
140095e63:     	cmpb	$0x1, (%rax)
140095e66:     	jne	0x140095e50 <.text+0x94e50>
140095e68:     	cmpl	$0x2, -0x2c(%rcx,%r8)
140095e6e:     	je	0x140095e50 <.text+0x94e50>
140095e70:     	cmpw	%dx, (%rcx,%r8)
140095e75:     	jne	0x140095e50 <.text+0x94e50>
140095e77:     	cmpl	%r14d, -0xc(%rcx,%r8)
140095e7c:     	jne	0x140095e50 <.text+0x94e50>
140095e7e:     	cmpl	%r13d, -0x8(%rcx,%r8)
140095e83:     	jne	0x140095e50 <.text+0x94e50>
140095e85:     	cmpw	%r12w, -0x4(%rcx,%r8)
140095e8b:     	jne	0x140095e50 <.text+0x94e50>
140095e8d:     	cmpb	%r15b, -0x2(%rcx,%r8)
140095e92:     	jne	0x140095e50 <.text+0x94e50>
140095e94:     	movq	-0x1c(%rcx,%r8), %r9
140095e99:     	xorq	%r11, %r9
140095e9c:     	movq	-0x14(%rcx,%r8), %r10
140095ea1:     	xorq	%rsi, %r10
140095ea4:     	orq	%r9, %r10
140095ea7:     	jne	0x140095e50 <.text+0x94e50>
140095ea9:     	movb	$0x0, (%rax)
140095eac:     	decq	0x5048(%rcx)
140095eb3:     	movq	$0x2, -0x2c(%rcx,%r8)
140095ebc:     	movq	%rcx, %rsi
140095ebf:     	xorps	%xmm7, %xmm7
140095ec2:     	movaps	%xmm7, 0x230(%rbp)
140095ec9:     	movb	$0x0, 0x212(%rbp)
140095ed0:     	movw	%dx, 0x210(%rbp)
140095ed7:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
140095ee0:     	movq	$0x0, 0x213(%rbp)
140095eeb:     	movq	$0x8, 0x1f0(%rbp)
140095ef6:     	movq	$0x0, 0x1f8(%rbp)
140095f01:     	movq	$0x1, 0x200(%rbp)
140095f0c:     	movq	$0x0, 0x208(%rbp)
140095f17:     	leaq	0x220(%rbp), %rcx
140095f1e:     	leaq	0x1f0(%rbp), %rdx
140095f25:     	leaq	0x230(%rbp), %r8
140095f2c:     	movl	$0x10, %r9d
140095f32:     	callq	0x140106080 <.text+0x105080>
140095f37:     	cmpb	$0x0, 0x220(%rbp)
140095f3e:     	jne	0x14009604c <.text+0x9504c>
140095f44:     	movq	0x228(%rbp), %rdi
140095f4b:     	movaps	%xmm7, 0xe0(%rbp)
140095f52:     	movaps	%xmm7, 0xf0(%rbp)
140095f59:     	movaps	%xmm7, 0x100(%rbp)
140095f60:     	movaps	%xmm7, 0x110(%rbp)
140095f67:     	movaps	%xmm7, 0x120(%rbp)
140095f6e:     	movaps	%xmm7, 0x130(%rbp)
140095f75:     	movaps	%xmm7, 0x140(%rbp)
140095f7c:     	movaps	%xmm7, 0x150(%rbp)
140095f83:     	movaps	%xmm7, 0x160(%rbp)
140095f8a:     	movaps	%xmm7, 0x170(%rbp)
140095f91:     	movaps	%xmm7, 0x180(%rbp)
140095f98:     	movaps	%xmm7, 0x190(%rbp)
140095f9f:     	movaps	%xmm7, 0x1a0(%rbp)
140095fa6:     	movaps	%xmm7, 0x1b0(%rbp)
140095fad:     	movaps	%xmm7, 0x1c0(%rbp)
140095fb4:     	movaps	%xmm7, 0x1d0(%rbp)
140095fbb:     	cmpq	$0x11, %rdi
140095fbf:     	jae	0x140096074 <.text+0x95074>
140095fc5:     	leaq	0xe0(%rbp), %rbx
140095fcc:     	leaq	0x230(%rbp), %rdx
140095fd3:     	movq	%rbx, %rcx
140095fd6:     	movq	%rdi, %r8
140095fd9:     	callq	0x1402394a0 <.text+0x2384a0>
140095fde:     	movw	%di, 0x1e0(%rbp)
140095fe5:     	movq	$0x0, -0x60(%rbp)
140095fed:     	movq	0x248(%rbp), %rax
140095ff4:     	movq	%rax, -0x48(%rbp)
140095ff8:     	movq	0x240(%rbp), %rax
140095fff:     	movq	%rax, -0x50(%rbp)
140096003:     	movl	%r14d, -0x40(%rbp)
140096007:     	movl	%r13d, -0x3c(%rbp)
14009600b:     	movw	%r12w, -0x38(%rbp)
140096010:     	movb	%r15b, -0x36(%rbp)
140096014:     	movzbl	0x25f(%rbp), %eax
14009601b:     	movb	%al, -0x35(%rbp)
14009601e:     	movd	%xmm6, -0x34(%rbp)
140096023:     	movq	0x250(%rbp), %rax
14009602a:     	movq	%rax, -0x30(%rbp)
14009602e:     	leaq	-0x28(%rbp), %rcx
140096032:     	movl	$0x108, %r8d            # imm = 0x108
140096038:     	movq	%rbx, %rdx
14009603b:     	callq	0x1402394a0 <.text+0x2384a0>
140096040:     	leaq	-0x60(%rbp), %rdx
140096044:     	movq	%rsi, %rcx
140096047:     	callq	0x1401ff010 <.text+0x1fe010>
14009604c:     	movb	$0x1, %al
14009604e:     	jmp	0x140096052 <.text+0x95052>
140096050:     	xorl	%eax, %eax
140096052:     	movaps	0x260(%rbp), %xmm6
140096059:     	movaps	0x270(%rbp), %xmm7
140096060:     	addq	$0x308, %rsp            # imm = 0x308
140096067:     	popq	%rbx
140096068:     	popq	%rdi
140096069:     	popq	%rsi
14009606a:     	popq	%r12
14009606c:     	popq	%r13
14009606e:     	popq	%r14
140096070:     	popq	%r15
140096072:     	popq	%rbp
140096073:     	retq
140096074:     	leaq	0x1bbaed(%rip), %r9     # 0x140251b68
14009607b:     	movl	$0x10, %r8d
140096081:     	xorl	%ecx, %ecx
140096083:     	movq	%rdi, %rdx
140096086:     	callq	0x140239ef0 <.text+0x238ef0>
14009608b:     	ud2

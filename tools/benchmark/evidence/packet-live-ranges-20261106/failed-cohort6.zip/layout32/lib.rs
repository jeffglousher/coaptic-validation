#![no_std]
use coaptic::{App, profiles};
use coaptic::storage::{AllocMemory, DedupEntry, DedupTable, Memory, WithBodies};
use core::mem::size_of;
type Small = App<profiles::Constrained, (), 4, false, Memory<profiles::Constrained>, 0, 1>;
type Service = App<profiles::Service, (), 32, true, Memory<profiles::Service, WithBodies<profiles::Service>>, 8, 4>;
type Allocated = App<profiles::Service, (), 32, true, AllocMemory, 8, 4>;
#[unsafe(no_mangle)]
pub static COAPTIC_LAYOUT: [usize; 7] = [size_of::<usize>(), size_of::<DedupEntry>(), size_of::<DedupTable<4>>(), size_of::<DedupTable<64>>(), size_of::<Small>(), size_of::<Service>(), size_of::<Allocated>()];

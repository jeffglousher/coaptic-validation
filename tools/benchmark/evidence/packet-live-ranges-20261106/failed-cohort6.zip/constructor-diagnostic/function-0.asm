
D:\CoapticCurrent\packet-lazy-staged-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14007d560:     	pushq	%rbp
14007d561:     	pushq	%r15
14007d563:     	pushq	%r14
14007d565:     	pushq	%r13
14007d567:     	pushq	%r12
14007d569:     	pushq	%rsi
14007d56a:     	pushq	%rdi
14007d56b:     	pushq	%rbx
14007d56c:     	subq	$0x2f8, %rsp            # imm = 0x2F8
14007d573:     	leaq	0x80(%rsp), %rbp
14007d57b:     	movq	%rcx, %rsi
14007d57e:     	movq	0x2f8(%rbp), %r12
14007d585:     	movzbl	0x215(%r12), %eax
14007d58e:     	orb	0x214(%r12), %al
14007d596:     	jne	0x14007ec0d <.text+0x7dc0d>
14007d59c:     	movzbl	0x211(%r12), %eax
14007d5a5:     	cmpb	$-0x1, %al
14007d5a7:     	jne	0x14007d5d1 <.text+0x7c5d1>
14007d5a9:     	movzwl	0x10(%r12), %eax
14007d5af:     	leaq	0x1da8fe(%rip), %rcx    # 0x140257eb4
14007d5b6:     	movslq	(%rcx,%rax,4), %r10
14007d5ba:     	addq	%rcx, %r10
14007d5bd:     	jmpq	*%r10
14007d5c0:     	movq	0x20(%r12), %rax
14007d5c5:     	cmpq	%rax, 0x1d8(%r12)
14007d5cd:     	jbe	0x14007d5fb <.text+0x7c5fb>
14007d5cf:     	xorl	%eax, %eax
14007d5d1:     	movb	$0x3, (%rsi)
14007d5d4:     	movb	%al, 0x1(%rsi)
14007d5d7:     	addq	$0x2f8, %rsp            # imm = 0x2F8
14007d5de:     	popq	%rbx
14007d5df:     	popq	%rdi
14007d5e0:     	popq	%rsi
14007d5e1:     	popq	%r12
14007d5e3:     	popq	%r13
14007d5e5:     	popq	%r14
14007d5e7:     	popq	%r15
14007d5e9:     	popq	%rbp
14007d5ea:     	retq
14007d5eb:     	movzwl	0x12(%r12), %eax
14007d5f1:     	cmpq	%rax, 0x1d8(%r12)
14007d5f9:     	ja	0x14007d5cf <.text+0x7c5cf>
14007d5fb:     	movq	%r8, 0x148(%rbp)
14007d602:     	movq	%rdx, 0x140(%rbp)
14007d609:     	movq	0x330(%rbp), %rax
14007d610:     	movq	%rax, 0x158(%rbp)
14007d617:     	movq	0x328(%rbp), %rax
14007d61e:     	movq	%rax, 0x160(%rbp)
14007d625:     	movq	0x320(%rbp), %rax
14007d62c:     	movq	%rax, 0x150(%rbp)
14007d633:     	movq	0x318(%rbp), %rax
14007d63a:     	movq	%rax, 0x100(%rbp)
14007d641:     	movq	0x310(%rbp), %r14
14007d648:     	movq	0x308(%rbp), %rax
14007d64f:     	movq	%rax, 0x20(%rbp)
14007d653:     	movq	0x300(%rbp), %rax
14007d65a:     	movq	%rax, 0x28(%rbp)
14007d65e:     	movq	0x2f0(%rbp), %rax
14007d665:     	movq	%rax, 0x108(%rbp)
14007d66c:     	movzwl	0x2e8(%rbp), %eax
14007d673:     	movw	%ax, 0x266(%rbp)
14007d67a:     	movzbl	0x2e0(%rbp), %eax
14007d681:     	movb	%al, 0x277(%rbp)
14007d687:     	cmpw	$0x1, 0x1e0(%r12)
14007d691:     	movq	%r9, %rdi
14007d694:     	jne	0x14007d6b9 <.text+0x7c6b9>
14007d696:     	movzwl	0x1e2(%r12), %eax
14007d69f:     	movl	%eax, %ecx
14007d6a1:     	bswapl	%ecx
14007d6a3:     	movl	%ecx, 0x40(%rbp)
14007d6a6:     	testl	$0xff0000, %ecx         # imm = 0xFF0000
14007d6ac:     	je	0x14007d6dd <.text+0x7c6dd>
14007d6ae:     	leaq	0x42(%rbp), %rdx
14007d6b2:     	movl	$0x2, %ebx
14007d6b7:     	jmp	0x14007d6eb <.text+0x7c6eb>
14007d6b9:     	movq	$0x0, 0x118(%rbp)
14007d6c4:     	xorl	%ebx, %ebx
14007d6c6:     	movb	%bl, 0x186(%rbp)
14007d6cc:     	cmpl	$0x1, (%r12)
14007d6d1:     	je	0x14007d72c <.text+0x7c72c>
14007d6d3:     	xorl	%r15d, %r15d
14007d6d6:     	xorl	%eax, %eax
14007d6d8:     	jmp	0x14007d7b6 <.text+0x7c7b6>
14007d6dd:     	testw	%ax, %ax
14007d6e0:     	je	0x14007d75c <.text+0x7c75c>
14007d6e2:     	leaq	0x43(%rbp), %rdx
14007d6e6:     	movl	$0x1, %ebx
14007d6eb:     	movl	$0x0, 0x198(%rbp)
14007d6f5:     	leaq	0x198(%rbp), %rcx
14007d6fc:     	movq	%rbx, %r8
14007d6ff:     	callq	0x1402394a0 <.text+0x2384a0>
14007d704:     	movl	0x198(%rbp), %eax
14007d70a:     	movl	%eax, 0x187(%rbp)
14007d710:     	movq	%rbx, 0x118(%rbp)
14007d717:     	movb	%bl, 0x18b(%rbp)
14007d71d:     	movb	$0x1, %bl
14007d71f:     	movb	%bl, 0x186(%rbp)
14007d725:     	cmpl	$0x1, (%r12)
14007d72a:     	jne	0x14007d6d3 <.text+0x7c6d3>
14007d72c:     	movl	0x4(%r12), %eax
14007d731:     	movl	%eax, %ecx
14007d733:     	bswapl	%ecx
14007d735:     	movl	%ecx, 0x40(%rbp)
14007d738:     	testb	%cl, %cl
14007d73a:     	je	0x14007d748 <.text+0x7c748>
14007d73c:     	movl	$0x4, %r15d
14007d742:     	leaq	0x40(%rbp), %rdx
14007d746:     	jmp	0x14007d788 <.text+0x7c788>
14007d748:     	testl	$0xff00, %ecx           # imm = 0xFF00
14007d74e:     	je	0x14007d762 <.text+0x7c762>
14007d750:     	leaq	0x41(%rbp), %rdx
14007d754:     	movl	$0x3, %r15d
14007d75a:     	jmp	0x14007d788 <.text+0x7c788>
14007d75c:     	xorl	%ebx, %ebx
14007d75e:     	xorl	%eax, %eax
14007d760:     	jmp	0x14007d70a <.text+0x7c70a>
14007d762:     	testl	$0xff0000, %ecx         # imm = 0xFF0000
14007d768:     	je	0x14007d776 <.text+0x7c776>
14007d76a:     	leaq	0x42(%rbp), %rdx
14007d76e:     	movl	$0x2, %r15d
14007d774:     	jmp	0x14007d788 <.text+0x7c788>
14007d776:     	testl	%eax, %eax
14007d778:     	je	0x14007ebde <.text+0x7dbde>
14007d77e:     	leaq	0x43(%rbp), %rdx
14007d782:     	movl	$0x1, %r15d
14007d788:     	movl	$0x0, 0x198(%rbp)
14007d792:     	leaq	0x198(%rbp), %rcx
14007d799:     	movq	%r15, %r8
14007d79c:     	callq	0x1402394a0 <.text+0x2384a0>
14007d7a1:     	movl	0x198(%rbp), %eax
14007d7a7:     	movl	%eax, 0x181(%rbp)
14007d7ad:     	movb	%r15b, 0x185(%rbp)
14007d7b4:     	movb	$0x1, %al
14007d7b6:     	movq	%rax, 0x110(%rbp)
14007d7bd:     	movb	%al, 0x180(%rbp)
14007d7c3:     	movl	0x8(%r12), %eax
14007d7c8:     	movl	%eax, 0x12c(%rbp)
14007d7ce:     	cmpl	$0x1, %eax
14007d7d1:     	movq	%r14, 0x268(%rbp)
14007d7d8:     	movq	%r15, 0x38(%rbp)
14007d7dc:     	jne	0x14007d800 <.text+0x7c800>
14007d7de:     	movl	$0xffffff, %eax         # imm = 0xFFFFFF


D:\CoapticCurrent\packet-lazy-staged-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401d0eb0:     	pushq	%rbp
1401d0eb1:     	movq	%rsp, %rbp
1401d0eb4:     	movq	%rcx, %rax
1401d0eb7:     	movl	$0x0, (%rcx)
1401d0ebd:     	movl	$0x0, 0x8(%rcx)
1401d0ec4:     	movw	$0x1, 0x10(%rcx)
1401d0eca:     	leaq	0x7af7f(%rip), %rcx     # 0x14024be50
1401d0ed1:     	movq	%rcx, 0x18(%rax)
1401d0ed5:     	movq	$0x400, 0x20(%rax)      # imm = 0x400
1401d0edd:     	movb	$-0x1, 0xb5(%rax)
1401d0ee4:     	movabsq	$0x65727574786966, %rcx # imm = 0x65727574786966
1401d0eee:     	movq	%rcx, 0xc0(%rax)
1401d0ef5:     	movq	$0x0, 0xc8(%rax)
1401d0f00:     	movq	$0x0, 0xd8(%rax)
1401d0f0b:     	movq	$0x0, 0x158(%rax)
1401d0f16:     	movq	$0x400, 0x1d8(%rax)     # imm = 0x400
1401d0f21:     	movl	$0x2a0001, 0x1e0(%rax)  # imm = 0x2A0001
1401d0f2b:     	movb	$0x0, 0x1e4(%rax)
1401d0f32:     	movabsq	$0x745ff000000, %rcx    # imm = 0x745FF000000
1401d0f3c:     	movq	%rcx, 0x20e(%rax)
1401d0f43:     	popq	%rbp
1401d0f44:     	retq


D:\CoapticCurrent\packet-lazy-staged-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401d79d0:     	pushq	%rbp
1401d79d1:     	movq	%rsp, %rbp
1401d79d4:     	movq	%rcx, %rax
1401d79d7:     	movl	$0x0, (%rcx)
1401d79dd:     	movl	$0x0, 0x8(%rcx)
1401d79e4:     	movw	$0x1, 0x10(%rcx)
1401d79ea:     	leaq	0x7c564(%rip), %rcx     # 0x140253f55
1401d79f1:     	movq	%rcx, 0x18(%rax)
1401d79f5:     	movq	$0x20, 0x20(%rax)
1401d79fd:     	movb	$-0x1, 0xb5(%rax)
1401d7a04:     	movabsq	$0x65727574786966, %rcx # imm = 0x65727574786966
1401d7a0e:     	movq	%rcx, 0xc0(%rax)
1401d7a15:     	movq	$0x0, 0xc8(%rax)
1401d7a20:     	movq	$0x0, 0xd8(%rax)
1401d7a2b:     	movq	$0x0, 0x158(%rax)
1401d7a36:     	movq	$0x20, 0x1d8(%rax)
1401d7a41:     	movl	$0x2a0001, 0x1e0(%rax)  # imm = 0x2A0001
1401d7a4b:     	movb	$0x0, 0x1e4(%rax)
1401d7a52:     	movabsq	$0x745ff000000, %rcx    # imm = 0x745FF000000
1401d7a5c:     	movq	%rcx, 0x20e(%rax)
1401d7a63:     	popq	%rbp
1401d7a64:     	retq

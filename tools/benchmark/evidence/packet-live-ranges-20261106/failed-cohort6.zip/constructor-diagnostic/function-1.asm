
D:\CoapticCurrent\packet-lazy-staged-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14007ecd0:     	pushq	%rbp
14007ecd1:     	pushq	%r15
14007ecd3:     	pushq	%r14
14007ecd5:     	pushq	%r13
14007ecd7:     	pushq	%r12
14007ecd9:     	pushq	%rsi
14007ecda:     	pushq	%rdi
14007ecdb:     	pushq	%rbx
14007ecdc:     	subq	$0x2e8, %rsp            # imm = 0x2E8
14007ece3:     	leaq	0x80(%rsp), %rbp
14007eceb:     	movq	%rcx, %rsi
14007ecee:     	movq	0x2e8(%rbp), %r12
14007ecf5:     	movzbl	0x215(%r12), %eax
14007ecfe:     	orb	0x214(%r12), %al
14007ed06:     	jne	0x14008032a <.text+0x7f32a>
14007ed0c:     	movzbl	0x211(%r12), %eax
14007ed15:     	cmpb	$-0x1, %al
14007ed17:     	jne	0x14007ed41 <.text+0x7dd41>
14007ed19:     	movzwl	0x10(%r12), %eax
14007ed1f:     	leaq	0x1d919e(%rip), %rcx    # 0x140257ec4
14007ed26:     	movslq	(%rcx,%rax,4), %r10
14007ed2a:     	addq	%rcx, %r10
14007ed2d:     	jmpq	*%r10
14007ed30:     	movq	0x20(%r12), %rax
14007ed35:     	cmpq	%rax, 0x1d8(%r12)
14007ed3d:     	jbe	0x14007ed6b <.text+0x7dd6b>
14007ed3f:     	xorl	%eax, %eax
14007ed41:     	movb	$0x3, (%rsi)
14007ed44:     	movb	%al, 0x1(%rsi)
14007ed47:     	addq	$0x2e8, %rsp            # imm = 0x2E8
14007ed4e:     	popq	%rbx
14007ed4f:     	popq	%rdi
14007ed50:     	popq	%rsi
14007ed51:     	popq	%r12
14007ed53:     	popq	%r13
14007ed55:     	popq	%r14
14007ed57:     	popq	%r15
14007ed59:     	popq	%rbp
14007ed5a:     	retq
14007ed5b:     	movzwl	0x12(%r12), %eax
14007ed61:     	cmpq	%rax, 0x1d8(%r12)
14007ed69:     	ja	0x14007ed3f <.text+0x7dd3f>
14007ed6b:     	movq	%r8, 0x140(%rbp)
14007ed72:     	movq	%rdx, 0x138(%rbp)
14007ed79:     	movq	0x318(%rbp), %rax
14007ed80:     	movq	%rax, 0x148(%rbp)
14007ed87:     	movq	0x310(%rbp), %rax
14007ed8e:     	movq	%rax, 0x150(%rbp)
14007ed95:     	movq	0x308(%rbp), %rax
14007ed9c:     	movq	%rax, 0xf8(%rbp)
14007eda3:     	movq	0x300(%rbp), %r14
14007edaa:     	movq	0x2f8(%rbp), %rax
14007edb1:     	movq	%rax, 0x10(%rbp)
14007edb5:     	movq	0x2f0(%rbp), %rax
14007edbc:     	movq	%rax, 0x18(%rbp)
14007edc0:     	movq	0x2e0(%rbp), %rax
14007edc7:     	movq	%rax, 0x100(%rbp)
14007edce:     	movzwl	0x2d8(%rbp), %eax
14007edd5:     	movw	%ax, 0x256(%rbp)
14007eddc:     	movzbl	0x2d0(%rbp), %eax
14007ede3:     	movb	%al, 0x267(%rbp)
14007ede9:     	cmpw	$0x1, 0x1e0(%r12)
14007edf3:     	movq	%r9, %rdi
14007edf6:     	jne	0x14007ee1b <.text+0x7de1b>
14007edf8:     	movzwl	0x1e2(%r12), %eax
14007ee01:     	movl	%eax, %ecx
14007ee03:     	bswapl	%ecx
14007ee05:     	movl	%ecx, 0x30(%rbp)
14007ee08:     	testl	$0xff0000, %ecx         # imm = 0xFF0000
14007ee0e:     	je	0x14007ee3f <.text+0x7de3f>
14007ee10:     	leaq	0x32(%rbp), %rdx
14007ee14:     	movl	$0x2, %ebx
14007ee19:     	jmp	0x14007ee4d <.text+0x7de4d>
14007ee1b:     	movq	$0x0, 0x110(%rbp)
14007ee26:     	xorl	%ebx, %ebx
14007ee28:     	movb	%bl, 0x176(%rbp)
14007ee2e:     	cmpl	$0x1, (%r12)
14007ee33:     	je	0x14007ee8e <.text+0x7de8e>
14007ee35:     	xorl	%r15d, %r15d
14007ee38:     	xorl	%eax, %eax
14007ee3a:     	jmp	0x14007ef18 <.text+0x7df18>
14007ee3f:     	testw	%ax, %ax
14007ee42:     	je	0x14007eebe <.text+0x7debe>
14007ee44:     	leaq	0x33(%rbp), %rdx
14007ee48:     	movl	$0x1, %ebx
14007ee4d:     	movl	$0x0, 0x188(%rbp)
14007ee57:     	leaq	0x188(%rbp), %rcx
14007ee5e:     	movq	%rbx, %r8
14007ee61:     	callq	0x1402394a0 <.text+0x2384a0>
14007ee66:     	movl	0x188(%rbp), %eax
14007ee6c:     	movl	%eax, 0x177(%rbp)
14007ee72:     	movq	%rbx, 0x110(%rbp)
14007ee79:     	movb	%bl, 0x17b(%rbp)
14007ee7f:     	movb	$0x1, %bl
14007ee81:     	movb	%bl, 0x176(%rbp)
14007ee87:     	cmpl	$0x1, (%r12)
14007ee8c:     	jne	0x14007ee35 <.text+0x7de35>
14007ee8e:     	movl	0x4(%r12), %eax
14007ee93:     	movl	%eax, %ecx
14007ee95:     	bswapl	%ecx
14007ee97:     	movl	%ecx, 0x30(%rbp)
14007ee9a:     	testb	%cl, %cl
14007ee9c:     	je	0x14007eeaa <.text+0x7deaa>
14007ee9e:     	movl	$0x4, %r15d
14007eea4:     	leaq	0x30(%rbp), %rdx
14007eea8:     	jmp	0x14007eeea <.text+0x7deea>
14007eeaa:     	testl	$0xff00, %ecx           # imm = 0xFF00
14007eeb0:     	je	0x14007eec4 <.text+0x7dec4>
14007eeb2:     	leaq	0x31(%rbp), %rdx
14007eeb6:     	movl	$0x3, %r15d
14007eebc:     	jmp	0x14007eeea <.text+0x7deea>
14007eebe:     	xorl	%ebx, %ebx
14007eec0:     	xorl	%eax, %eax
14007eec2:     	jmp	0x14007ee6c <.text+0x7de6c>
14007eec4:     	testl	$0xff0000, %ecx         # imm = 0xFF0000
14007eeca:     	je	0x14007eed8 <.text+0x7ded8>
14007eecc:     	leaq	0x32(%rbp), %rdx
14007eed0:     	movl	$0x2, %r15d
14007eed6:     	jmp	0x14007eeea <.text+0x7deea>
14007eed8:     	testl	%eax, %eax
14007eeda:     	je	0x1400802fb <.text+0x7f2fb>
14007eee0:     	leaq	0x33(%rbp), %rdx
14007eee4:     	movl	$0x1, %r15d
14007eeea:     	movl	$0x0, 0x188(%rbp)
14007eef4:     	leaq	0x188(%rbp), %rcx
14007eefb:     	movq	%r15, %r8
14007eefe:     	callq	0x1402394a0 <.text+0x2384a0>
14007ef03:     	movl	0x188(%rbp), %eax
14007ef09:     	movl	%eax, 0x171(%rbp)
14007ef0f:     	movb	%r15b, 0x175(%rbp)
14007ef16:     	movb	$0x1, %al
14007ef18:     	movq	%rax, 0x108(%rbp)
14007ef1f:     	movb	%al, 0x170(%rbp)
14007ef25:     	movl	0x8(%r12), %eax
14007ef2a:     	movl	%eax, 0x124(%rbp)
14007ef30:     	cmpl	$0x1, %eax
14007ef33:     	movq	%r14, 0x258(%rbp)
14007ef3a:     	movq	%r15, 0x28(%rbp)
14007ef3e:     	jne	0x14007ef62 <.text+0x7df62>
14007ef40:     	movl	$0xffffff, %eax         # imm = 0xFFFFFF
14007ef45:     	andl	0xc(%r12), %eax
14007ef4a:     	movl	%eax, %ecx
14007ef4c:     	bswapl	%ecx
14007ef4e:     	movl	%ecx, 0x30(%rbp)

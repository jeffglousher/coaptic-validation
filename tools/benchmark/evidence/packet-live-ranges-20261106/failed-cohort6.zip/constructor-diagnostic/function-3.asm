
D:\CoapticCurrent\packet-lazy-staged-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1401d0fc0:     	pushq	%rbp
1401d0fc1:     	movq	%rsp, %rbp
1401d0fc4:     	movq	%rcx, %rax
1401d0fc7:     	movl	$0x0, (%rcx)
1401d0fcd:     	movl	$0x0, 0x8(%rcx)
1401d0fd4:     	movw	$0x1, 0x10(%rcx)
1401d0fda:     	leaq	0x7ae6f(%rip), %rcx     # 0x14024be50
1401d0fe1:     	movq	%rcx, 0x18(%rax)
1401d0fe5:     	movq	$0x4000, 0x20(%rax)     # imm = 0x4000
1401d0fed:     	movb	$-0x1, 0xb5(%rax)
1401d0ff4:     	movabsq	$0x65727574786966, %rcx # imm = 0x65727574786966
1401d0ffe:     	movq	%rcx, 0xc0(%rax)
1401d1005:     	movq	$0x0, 0xc8(%rax)
1401d1010:     	movq	$0x0, 0xd8(%rax)
1401d101b:     	movq	$0x0, 0x158(%rax)
1401d1026:     	movq	$0x4000, 0x1d8(%rax)    # imm = 0x4000
1401d1031:     	movl	$0x2a0001, 0x1e0(%rax)  # imm = 0x2A0001
1401d103b:     	movb	$0x0, 0x1e4(%rax)
1401d1042:     	movabsq	$0x745ff000000, %rcx    # imm = 0x745FF000000
1401d104c:     	movq	%rcx, 0x20e(%rax)
1401d1053:     	popq	%rbp
1401d1054:     	retq

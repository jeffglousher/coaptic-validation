
D:\CoapticCurrent\packet-lazy-staged-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400955d0:     	pushq	%rbp
1400955d1:     	pushq	%r15
1400955d3:     	pushq	%r14
1400955d5:     	pushq	%r13
1400955d7:     	pushq	%r12
1400955d9:     	pushq	%rsi
1400955da:     	pushq	%rdi
1400955db:     	pushq	%rbx
1400955dc:     	subq	$0x318, %rsp            # imm = 0x318
1400955e3:     	leaq	0x80(%rsp), %rbp
1400955eb:     	movaps	%xmm7, 0x280(%rbp)
1400955f2:     	movaps	%xmm6, 0x270(%rbp)
1400955f9:     	leaq	0x30(%rcx), %rdx
1400955fd:     	xorl	%r8d, %r8d
140095600:     	xorl	%r11d, %r11d
140095603:     	leaq	(%r11,%r11,4), %r10
140095607:     	shlq	$0x6, %r10
14009560b:     	addq	%rdx, %r10
14009560e:     	movq	%r11, %r9
140095611:     	jmp	0x140095634 <.text+0x94634>
140095613:     	nopw	%cs:(%rax,%rax)
140095620:     	incq	%r9
140095623:     	addq	$0x140, %r10            # imm = 0x140
14009562a:     	cmpq	$0x4, %r9
14009562e:     	je	0x1400956be <.text+0x946be>
140095634:     	cmpb	$0x1, 0x510(%rcx,%r9)
14009563d:     	jne	0x140095620 <.text+0x94620>
14009563f:     	movq	-0x30(%r10), %rsi
140095643:     	cmpq	$0x2, %rsi
140095647:     	je	0x140095620 <.text+0x94620>
140095649:     	movq	(%r10), %r11
14009564c:     	cmpl	$0x1, %esi
14009564f:     	setne	%bl
140095652:     	testq	%r11, %r11
140095655:     	sete	%sil
140095659:     	orb	%bl, %sil
14009565c:     	cmpb	$0x1, %sil
140095660:     	je	0x140095620 <.text+0x94620>
140095662:     	movq	0x268(%rbp), %rsi
140095669:     	cmpq	%rsi, %r11
14009566c:     	setae	%bl
14009566f:     	testb	%bl, %r8b
140095672:     	jne	0x1400956a4 <.text+0x946a4>
140095674:     	movq	-0x28(%r10), %rax
140095678:     	movd	-0x4(%r10), %xmm6
14009567e:     	movzbl	-0x5(%r10), %edi
140095683:     	movzbl	-0x6(%r10), %r15d
140095688:     	movzwl	-0x8(%r10), %r12d
14009568d:     	movl	-0xc(%r10), %r13d
140095691:     	movl	-0x10(%r10), %r14d
140095695:     	movups	-0x20(%r10), %xmm0
14009569a:     	movaps	%xmm0, 0x240(%rbp)
1400956a1:     	movq	%r11, %rsi
1400956a4:     	movq	%rsi, 0x268(%rbp)
1400956ab:     	leaq	0x1(%r9), %r11
1400956af:     	movb	$0x1, %r8b
1400956b2:     	cmpq	$0x3, %r9
1400956b6:     	jb	0x140095603 <.text+0x94603>
1400956bc:     	jmp	0x1400956c8 <.text+0x946c8>
1400956be:     	testb	$0x1, %r8b
1400956c2:     	je	0x140095908 <.text+0x94908>
1400956c8:     	cmpq	$0x1, %rax
1400956cc:     	ja	0x140095724 <.text+0x94724>
1400956ce:     	cmpb	$0x1, 0x1e80(%rcx,%rax)
1400956d6:     	jne	0x140095724 <.text+0x94724>
1400956d8:     	cmpb	$0x0, 0x1e82(%rcx,%rax)
1400956e0:     	jne	0x140095724 <.text+0x94724>
1400956e2:     	movb	$0x0, 0x1e80(%rcx,%rax)
1400956ea:     	decq	0x1e78(%rcx)
1400956f1:     	leaq	0x14f8(%rcx), %rdx
1400956f8:     	movq	$0x0, 0x1df8(%rcx,%rax,8)
140095704:     	leaq	(%rax,%rax,8), %r8
140095708:     	leaq	(%r8,%r8,2), %r8
14009570c:     	addq	%rax, %r8
14009570f:     	movb	$0x2, 0x95a(%rdx,%r8)
140095718:     	leaq	(%rax,%rax,2), %rax
14009571c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
140095724:     	movaps	0x240(%rbp), %xmm0
14009572b:     	movaps	%xmm0, -0x60(%rbp)
14009572f:     	movl	%r14d, %esi
140095732:     	movl	%r14d, -0x50(%rbp)
140095736:     	movl	%r13d, %r14d
140095739:     	movl	%r13d, -0x4c(%rbp)
14009573d:     	movl	%r12d, %r13d
140095740:     	movw	%r12w, -0x48(%rbp)
140095745:     	movl	%r15d, %r12d
140095748:     	movb	%r15b, -0x46(%rbp)
14009574c:     	movl	%edi, %r15d
14009574f:     	movb	%dil, -0x45(%rbp)
140095753:     	movd	%xmm6, %edi
140095757:     	movd	%xmm6, -0x44(%rbp)
14009575c:     	leaq	-0x60(%rbp), %rdx
140095760:     	movq	%rcx, 0x260(%rbp)
140095767:     	callq	0x1401ff440 <.text+0x1fe440>
14009576c:     	xorps	%xmm7, %xmm7
14009576f:     	movaps	%xmm7, 0x250(%rbp)
140095776:     	movb	$0x0, 0x222(%rbp)
14009577d:     	movw	%di, 0x220(%rbp)
140095784:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009578d:     	movq	$0x0, 0x223(%rbp)
140095798:     	movq	$0x8, 0x200(%rbp)
1400957a3:     	movq	$0x0, 0x208(%rbp)
1400957ae:     	movq	$0x1, 0x210(%rbp)
1400957b9:     	movq	$0x0, 0x218(%rbp)
1400957c4:     	leaq	0x230(%rbp), %rcx
1400957cb:     	leaq	0x200(%rbp), %rdx
1400957d2:     	leaq	0x250(%rbp), %r8
1400957d9:     	movl	$0x10, %r9d
1400957df:     	callq	0x140106080 <.text+0x105080>
1400957e4:     	cmpb	$0x0, 0x230(%rbp)
1400957eb:     	jne	0x140095904 <.text+0x94904>
1400957f1:     	movq	0x238(%rbp), %rdi
1400957f8:     	movaps	%xmm7, 0xe0(%rbp)
1400957ff:     	movaps	%xmm7, 0xf0(%rbp)
140095806:     	movaps	%xmm7, 0x100(%rbp)
14009580d:     	movaps	%xmm7, 0x110(%rbp)
140095814:     	movaps	%xmm7, 0x120(%rbp)
14009581b:     	movaps	%xmm7, 0x130(%rbp)
140095822:     	movaps	%xmm7, 0x140(%rbp)
140095829:     	movaps	%xmm7, 0x150(%rbp)
140095830:     	movaps	%xmm7, 0x160(%rbp)
140095837:     	movaps	%xmm7, 0x170(%rbp)
14009583e:     	movaps	%xmm7, 0x180(%rbp)
140095845:     	movaps	%xmm7, 0x190(%rbp)
14009584c:     	movaps	%xmm7, 0x1a0(%rbp)
140095853:     	movaps	%xmm7, 0x1b0(%rbp)
14009585a:     	movaps	%xmm7, 0x1c0(%rbp)
140095861:     	movaps	%xmm7, 0x1d0(%rbp)
140095868:     	movaps	0x240(%rbp), %xmm0
14009586f:     	movups	%xmm0, 0x1f0(%rbp)
140095876:     	cmpq	$0x11, %rdi
14009587a:     	jae	0x14009592c <.text+0x9492c>
140095880:     	leaq	0xe0(%rbp), %rbx
140095887:     	leaq	0x250(%rbp), %rdx
14009588e:     	movq	%rbx, %rcx
140095891:     	movq	%rdi, %r8
140095894:     	callq	0x1402394a0 <.text+0x2384a0>
140095899:     	movw	%di, 0x1e0(%rbp)
1400958a0:     	movq	$0x0, -0x60(%rbp)
1400958a8:     	movups	0x1e8(%rbp), %xmm0
1400958af:     	movups	%xmm0, -0x58(%rbp)
1400958b3:     	movq	0x1f8(%rbp), %rax
1400958ba:     	movq	%rax, -0x48(%rbp)
1400958be:     	movl	%esi, -0x40(%rbp)
1400958c1:     	movl	%r14d, -0x3c(%rbp)
1400958c5:     	movw	%r13w, -0x38(%rbp)
1400958ca:     	movb	%r12b, -0x36(%rbp)
1400958ce:     	movb	%r15b, -0x35(%rbp)
1400958d2:     	movd	%xmm6, -0x34(%rbp)
1400958d7:     	movq	0x268(%rbp), %rax
1400958de:     	movq	%rax, -0x30(%rbp)
1400958e2:     	leaq	-0x28(%rbp), %rcx
1400958e6:     	movl	$0x108, %r8d            # imm = 0x108
1400958ec:     	movq	%rbx, %rdx
1400958ef:     	callq	0x1402394a0 <.text+0x2384a0>
1400958f4:     	leaq	-0x60(%rbp), %rdx
1400958f8:     	movq	0x260(%rbp), %rcx
1400958ff:     	callq	0x1401ff1b0 <.text+0x1fe1b0>
140095904:     	movb	$0x1, %al
140095906:     	jmp	0x14009590a <.text+0x9490a>
140095908:     	xorl	%eax, %eax
14009590a:     	movaps	0x270(%rbp), %xmm6
140095911:     	movaps	0x280(%rbp), %xmm7
140095918:     	addq	$0x318, %rsp            # imm = 0x318
14009591f:     	popq	%rbx
140095920:     	popq	%rdi
140095921:     	popq	%rsi
140095922:     	popq	%r12
140095924:     	popq	%r13
140095926:     	popq	%r14
140095928:     	popq	%r15
14009592a:     	popq	%rbp
14009592b:     	retq
14009592c:     	leaq	0x1bc235(%rip), %r9     # 0x140251b68
140095933:     	movl	$0x10, %r8d
140095939:     	xorl	%ecx, %ecx
14009593b:     	movq	%rdi, %rdx
14009593e:     	callq	0x140239ef0 <.text+0x238ef0>
140095943:     	ud2

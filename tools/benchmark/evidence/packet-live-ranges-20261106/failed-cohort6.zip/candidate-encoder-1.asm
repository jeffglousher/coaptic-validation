
D:\CoapticCurrent\packet-lazy-staged-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400640e0:     	pushq	%rbp
1400640e1:     	pushq	%r15
1400640e3:     	pushq	%r14
1400640e5:     	pushq	%r13
1400640e7:     	pushq	%r12
1400640e9:     	pushq	%rsi
1400640ea:     	pushq	%rdi
1400640eb:     	pushq	%rbx
1400640ec:     	subq	$0x508, %rsp            # imm = 0x508
1400640f3:     	leaq	0x80(%rsp), %rbp
1400640fb:     	movq	%r9, %rbx
1400640fe:     	movq	%r8, %r14
140064101:     	movq	%rdx, %rdi
140064104:     	movq	%rcx, %rsi
140064107:     	movq	0x500(%rbp), %r12
14006410e:     	movq	%rbp, %rcx
140064111:     	movl	$0x400, %r8d            # imm = 0x400
140064117:     	xorl	%edx, %edx
140064119:     	callq	0x1402394b2 <.text+0x2384b2>
14006411e:     	movq	0x8(%r12), %r13
140064123:     	movl	$0x3, %eax
140064128:     	cmpq	$0x3, %r13
14006412c:     	ja	0x14006434f <.text+0x6334f>
140064132:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
14006413b:     	jne	0x14006434f <.text+0x6334f>
140064141:     	movq	0x2b750(%rdi,%r13,8), %rdx
140064149:     	cmpq	$0x4001, %rdx           # imm = 0x4001
140064150:     	jae	0x1400643ab <.text+0x633ab>
140064156:     	movq	0x10(%r12), %rcx
14006415b:     	movq	0x18(%r12), %r15
140064160:     	movq	%r15, %r8
140064163:     	movl	$0xb, %eax
140064168:     	addq	%rcx, %r8
14006416b:     	jb	0x14006434f <.text+0x6334f>
140064171:     	cmpq	$0x400, %r15            # imm = 0x400
140064178:     	ja	0x14006434f <.text+0x6334f>
14006417e:     	cmpq	%rdx, %r8
140064181:     	ja	0x14006434f <.text+0x6334f>
140064187:     	movq	%r13, %rax
14006418a:     	shlq	$0xe, %rax
14006418e:     	leaq	(%rdi,%rax), %rdx
140064192:     	addq	$0x1b750, %rdx          # imm = 0x1B750
140064199:     	addq	%rcx, %rdx
14006419c:     	movq	%rbp, %rcx
14006419f:     	movq	%r15, %r8
1400641a2:     	callq	0x1402394a0 <.text+0x2384a0>
1400641a7:     	cmpb	$0x0, 0x508(%rbp)
1400641ae:     	je	0x1400641c6 <.text+0x631c6>
1400641b0:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
1400641b7:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
1400641c0:     	jne	0x14006436a <.text+0x6336a>
1400641c6:     	movq	$0x0, 0x480(%rbp)
1400641d1:     	movq	%rdi, %rcx
1400641d4:     	callq	0x1400921e0 <.text+0x911e0>
1400641d9:     	testb	$0x1, %al
1400641db:     	je	0x14006439d <.text+0x6339d>
1400641e1:     	movq	%rdx, %r13
1400641e4:     	movq	0x518(%rbp), %rdx
1400641eb:     	movq	0x510(%rbp), %r8
1400641f2:     	movzwl	0x4f8(%rbp), %ecx
1400641f9:     	movzbl	0x4f0(%rbp), %eax
140064200:     	movq	(%r12), %r9
140064204:     	movq	0x480(%rbp), %r10
14006420b:     	movq	%r10, 0x448(%rbp)
140064212:     	movq	0x478(%rbp), %r10
140064219:     	movq	%r10, 0x450(%rbp)
140064220:     	movq	%r9, 0x458(%rbp)
140064227:     	movzbl	0x508(%rbp), %r9d
14006422f:     	movb	%r9b, 0x460(%rbp)
140064236:     	movups	0x38(%r14), %xmm0
14006423b:     	movups	0x44(%r14), %xmm1
140064240:     	movups	%xmm1, 0x40c(%rbp)
140064247:     	movaps	%xmm0, 0x400(%rbp)
14006424e:     	leaq	0x66(%r14), %r9
140064252:     	movq	0x56(%r14), %r10
140064256:     	movq	0x5d(%r14), %r11
14006425a:     	movq	%r11, 0x46f(%rbp)
140064261:     	movq	%r10, 0x468(%rbp)
140064268:     	leaq	0x468(%rbp), %r10
14006426f:     	movq	%r10, 0x70(%rsp)
140064274:     	movq	%rdx, 0x68(%rsp)
140064279:     	movq	%r8, 0x60(%rsp)
14006427e:     	movq	%r14, 0x58(%rsp)
140064283:     	leaq	0x448(%rbp), %rdx
14006428a:     	movq	%rdx, 0x50(%rsp)
14006428f:     	movq	%r15, 0x48(%rsp)
140064294:     	movq	%rbp, %rdx
140064297:     	movq	%rdx, 0x40(%rsp)
14006429c:     	movq	%rbx, 0x38(%rsp)
1400642a1:     	movq	%r9, 0x30(%rsp)
1400642a6:     	movw	%cx, 0x28(%rsp)
1400642ab:     	movb	%al, 0x20(%rsp)
1400642af:     	leaq	0x428(%rbp), %rcx
1400642b6:     	leaq	0x400(%rbp), %r8
1400642bd:     	movq	%rdi, %rdx
1400642c0:     	movq	%r13, %r9
1400642c3:     	callq	0x14007a6d0 <.text+0x796d0>
1400642c8:     	cmpb	$-0x1, 0x428(%rbp)
1400642cf:     	je	0x1400643a2 <.text+0x633a2>
1400642d5:     	cmpb	$0x1, 0x37740(%rdi,%r13)
1400642de:     	jne	0x140064338 <.text+0x63338>
1400642e0:     	cmpb	$0x0, 0x37760(%rdi,%r13)
1400642e9:     	jne	0x140064338 <.text+0x63338>
1400642eb:     	movb	$0x0, 0x37740(%rdi,%r13)
1400642f4:     	decq	0x37788(%rdi)
1400642fb:     	leaq	0x37740(%rdi), %rax
140064302:     	movq	$0x0, 0x43610(%rdi,%r13,8)
14006430e:     	leaq	(,%r13,8), %rcx
140064316:     	addq	%r13, %rcx
140064319:     	leaq	(%rcx,%rcx,2), %rcx
14006431d:     	addq	%r13, %rcx
140064320:     	movb	$0x2, 0x36a(%rax,%rcx)
140064328:     	leaq	(,%r13,2), %rcx
140064330:     	addq	%r13, %rcx
140064333:     	movb	$0x2, 0x5d(%rax,%rcx,8)
140064338:     	movups	0x428(%rbp), %xmm0
14006433f:     	movups	0x438(%rbp), %xmm1
140064346:     	movups	%xmm1, 0x10(%rsi)
14006434a:     	movups	%xmm0, (%rsi)
14006434d:     	jmp	0x140064356 <.text+0x63356>
14006434f:     	movb	$0xa, (%rsi)
140064352:     	movq	%rax, 0x8(%rsi)
140064356:     	addq	$0x508, %rsp            # imm = 0x508
14006435d:     	popq	%rbx
14006435e:     	popq	%rdi
14006435f:     	popq	%rsi
140064360:     	popq	%r12
140064362:     	popq	%r13
140064364:     	popq	%r14
140064366:     	popq	%r15
140064368:     	popq	%rbp
140064369:     	retq
14006436a:     	addq	%rdi, %rax
14006436d:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
140064373:     	movq	0x98(%rax), %rax
14006437a:     	movq	%rax, 0x478(%rbp)
140064381:     	movl	$0x1, %eax
140064386:     	movq	%rax, 0x480(%rbp)
14006438d:     	movq	%rdi, %rcx
140064390:     	callq	0x1400921e0 <.text+0x911e0>
140064395:     	testb	$0x1, %al
140064397:     	jne	0x1400641e1 <.text+0x631e1>
14006439d:     	movb	$0x9, (%rsi)
1400643a0:     	jmp	0x140064356 <.text+0x63356>
1400643a2:     	movq	%r13, 0x8(%rsi)
1400643a6:     	movb	$-0x1, (%rsi)
1400643a9:     	jmp	0x140064356 <.text+0x63356>
1400643ab:     	leaq	0x1f087e(%rip), %r9     # 0x140254c30
1400643b2:     	movl	$0x4000, %r8d           # imm = 0x4000
1400643b8:     	xorl	%ecx, %ecx
1400643ba:     	callq	0x140239ef0 <.text+0x238ef0>
1400643bf:     	ud2


D:\CoapticCurrent\packet-lazy-staged-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140080bc0:     	pushq	%rbp
140080bc1:     	pushq	%r15
140080bc3:     	pushq	%r14
140080bc5:     	pushq	%r13
140080bc7:     	pushq	%r12
140080bc9:     	pushq	%rsi
140080bca:     	pushq	%rdi
140080bcb:     	pushq	%rbx
140080bcc:     	subq	$0x608, %rsp            # imm = 0x608
140080bd3:     	leaq	0x80(%rsp), %rbp
140080bdb:     	movq	%rdx, %rdi
140080bde:     	movq	0x5f8(%rbp), %r12
140080be5:     	movzbl	0x2d(%r12), %edx
140080beb:     	cmpq	$0x2, %rdx
140080bef:     	je	0x140081773 <.text+0x80773>
140080bf5:     	movq	%r9, %rbx
140080bf8:     	movq	0x610(%rbp), %r9
140080bff:     	cmpq	$0x3, %r9
140080c03:     	ja	0x140080d6e <.text+0x7fd6e>
140080c09:     	cmpb	$0x1, 0x1b748(%rdi,%r9)
140080c12:     	jne	0x140080d6e <.text+0x7fd6e>
140080c18:     	movq	0x2b750(%rdi,%r9,8), %rax
140080c20:     	cmpq	$0x4001, %rax           # imm = 0x4001
140080c26:     	jae	0x14008175a <.text+0x8075a>
140080c2c:     	movq	%r8, %r15
140080c2f:     	movq	%rax, 0x570(%rbp)
140080c36:     	movq	%rcx, %rsi
140080c39:     	movl	0x28(%r12), %eax
140080c3e:     	movzbl	0x2c(%r12), %r14d
140080c44:     	shlq	$0x20, %r14
140080c48:     	orq	%rax, %r14
140080c4b:     	movq	%r14, %r10
140080c4e:     	shrq	$0x20, %r10
140080c52:     	movl	%r10d, %ecx
140080c55:     	andb	$0xf, %cl
140080c58:     	movl	$0x10, %r8d
140080c5e:     	shll	%cl, %r8d
140080c61:     	movq	0x618(%rbp), %rax
140080c68:     	movq	%r10, 0x4a0(%rbp)
140080c6f:     	cmpq	$0x7, %r10
140080c73:     	movzwl	%r8w, %ecx
140080c77:     	movl	$0x400, %r13d           # imm = 0x400
140080c7d:     	cmovneq	%rcx, %r13
140080c81:     	cmpb	$0x0, (%rax)
140080c84:     	je	0x140080d8d <.text+0x7fd8d>
140080c8a:     	movups	0x8(%rax), %xmm0
140080c8e:     	movups	0x18(%rax), %xmm1
140080c92:     	movups	0x28(%rax), %xmm2
140080c96:     	movaps	%xmm2, 0x490(%rbp)
140080c9d:     	movaps	%xmm1, 0x480(%rbp)
140080ca4:     	movaps	%xmm0, 0x470(%rbp)
140080cab:     	movq	0x498(%rbp), %rdx
140080cb2:     	cmpq	$0xb, %rdx
140080cb6:     	jae	0x1400815f3 <.text+0x805f3>
140080cbc:     	movq	%rbx, 0x4f8(%rbp)
140080cc3:     	movq	%rsi, 0x578(%rbp)
140080cca:     	testq	%rdx, %rdx
140080ccd:     	movq	0x570(%rbp), %rsi
140080cd4:     	je	0x14008155e <.text+0x8055e>
140080cda:     	shrq	$0x23, %r14
140080cde:     	je	0x140081064 <.text+0x80064>
140080ce4:     	movl	0x470(%rbp), %r14d
140080ceb:     	imulq	%r13, %r14
140080cef:     	addq	%r14, %r13
140080cf2:     	cmpq	%r13, %rsi
140080cf5:     	cmovbq	%rsi, %r13
140080cf9:     	leaq	-0x10(%rbp), %rcx
140080cfd:     	movl	$0x400, %r8d            # imm = 0x400
140080d03:     	xorl	%edx, %edx
140080d05:     	callq	0x1402394b2 <.text+0x2384b2>
140080d0a:     	movq	%r13, %r15
140080d0d:     	subq	%r14, %r15
140080d10:     	cmpq	$0x400, %r15            # imm = 0x400
140080d17:     	ja	0x14008178d <.text+0x8078d>
140080d1d:     	movq	0x610(%rbp), %rax
140080d24:     	cmpb	$0x1, 0x1b748(%rdi,%rax)
140080d2c:     	jne	0x140081609 <.text+0x80609>
140080d32:     	movq	0x2b750(%rdi,%rax,8), %rax
140080d3a:     	cmpq	$0x4000, %rax           # imm = 0x4000
140080d40:     	ja	0x14008175a <.text+0x8075a>
140080d46:     	cmpq	%r14, %rsi
140080d49:     	jb	0x1400817a6 <.text+0x807a6>
140080d4f:     	cmpq	%rax, %r13
140080d52:     	movq	0x578(%rbp), %rcx
140080d59:     	ja	0x1400817a6 <.text+0x807a6>
140080d5f:     	movabsq	$0x21100000000, %rax    # imm = 0x21100000000
140080d69:     	jmp	0x140081631 <.text+0x80631>
140080d6e:     	movb	$0xa, (%rcx)
140080d71:     	movq	$0x3, 0x8(%rcx)
140080d79:     	addq	$0x608, %rsp            # imm = 0x608
140080d80:     	popq	%rbx
140080d81:     	popq	%rdi
140080d82:     	popq	%rsi
140080d83:     	popq	%r12
140080d85:     	popq	%r13
140080d87:     	popq	%r14
140080d89:     	popq	%r15
140080d8b:     	popq	%rbp
140080d8c:     	retq
140080d8d:     	movq	0x30(%r12), %rax
140080d92:     	testq	%rax, %rax
140080d95:     	je	0x14008156d <.text+0x8056d>
140080d9b:     	movq	%r13, 0x530(%rbp)
140080da2:     	movq	%r15, 0x538(%rbp)
140080da9:     	movups	(%rax), %xmm0
140080dac:     	xorps	%xmm1, %xmm1
140080daf:     	movaps	%xmm1, 0x10(%rbp)
140080db3:     	movaps	%xmm1, (%rbp)
140080db7:     	movaps	%xmm1, -0x10(%rbp)
140080dbb:     	movups	%xmm0, 0x540(%rbp)
140080dc2:     	movq	$0x0, 0x550(%rbp)
140080dcd:     	leaq	0x558(%rbp), %r15
140080dd4:     	movl	$0x0, 0x558(%rbp)
140080dde:     	movw	$0x1f, 0x560(%rbp)
140080de7:     	xorl	%r12d, %r12d
140080dea:     	leaq	0x510(%rbp), %r13
140080df1:     	nopw	%cs:(%rax,%rax)
140080e00:     	movq	0x548(%rbp), %r8
140080e07:     	cmpq	%r8, 0x550(%rbp)
140080e0e:     	jae	0x140080fde <.text+0x7ffde>
140080e14:     	movq	0x540(%rbp), %rdx
140080e1b:     	movq	%r15, 0x20(%rsp)
140080e20:     	movq	%r13, %rcx
140080e23:     	leaq	0x550(%rbp), %r9
140080e2a:     	callq	0x14000e450 <.text+0xd450>
140080e2f:     	movq	0x510(%rbp), %rax
140080e36:     	testq	%rax, %rax
140080e39:     	je	0x140080fde <.text+0x7ffde>
140080e3f:     	movzwl	0x560(%rbp), %ecx
140080e46:     	cmpw	%cx, 0x520(%rbp)
140080e4d:     	je	0x140080e56 <.text+0x7fe56>
140080e4f:     	jbe	0x140080e00 <.text+0x7fe00>
140080e51:     	jmp	0x140080fde <.text+0x7ffde>
140080e56:     	movq	0x518(%rbp), %rdx
140080e5d:     	cmpq	$0x3, %rdx
140080e61:     	ja	0x1400817d6 <.text+0x807d6>
140080e67:     	testq	%rdx, %rdx
140080e6a:     	je	0x140080e9d <.text+0x7fe9d>
140080e6c:     	movzbl	(%rax), %ecx
140080e6f:     	cmpq	$0x1, %rdx
140080e73:     	je	0x140080e92 <.text+0x7fe92>
140080e75:     	movl	%ecx, %r8d
140080e78:     	shll	$0x8, %r8d
140080e7c:     	movzbl	0x1(%rax), %ecx
140080e80:     	orl	%r8d, %ecx
140080e83:     	cmpq	$0x2, %rdx
140080e87:     	je	0x140080e92 <.text+0x7fe92>
140080e89:     	shll	$0x8, %ecx
140080e8c:     	movzbl	0x2(%rax), %eax
140080e90:     	orl	%eax, %ecx
140080e92:     	movl	%ecx, %eax
140080e94:     	movq	%rax, %r8
140080e97:     	shlq	$0x20, %r8
140080e9b:     	jmp	0x140080ea5 <.text+0x7fea5>
140080e9d:     	movl	$0x100, %r8d            # imm = 0x100
140080ea3:     	xorl	%eax, %eax
140080ea5:     	andb	$0x7, %al
140080ea7:     	movq	%r8, %rcx
140080eaa:     	shrq	$0x24, %rcx
140080eae:     	movl	%ecx, 0x510(%rbp)
140080eb4:     	movb	%al, 0x514(%rbp)
140080eba:     	movl	0x511(%rbp), %edx
140080ec0:     	movq	%rdx, %r9
140080ec3:     	shlq	$0x8, %r9
140080ec7:     	movzbl	%cl, %eax
140080eca:     	orq	%r9, %rax
140080ecd:     	shrl	$0x18, %edx
140080ed0:     	movl	%edx, %ecx
140080ed2:     	andb	$0xf, %cl
140080ed5:     	movl	$0x10, %r9d
140080edb:     	shll	%cl, %r9d
140080ede:     	cmpl	$0x7, %edx
140080ee1:     	movzwl	%r9w, %ecx
140080ee5:     	movl	$0x400, %edx            # imm = 0x400
140080eea:     	cmoveq	%rdx, %rcx
140080eee:     	movl	%eax, %r9d
140080ef1:     	movq	%r9, %rdx
140080ef4:     	imulq	%rcx, %rdx
140080ef8:     	movq	0x570(%rbp), %r11
140080eff:     	cmpq	%r11, %rdx
140080f02:     	setb	%r10b
140080f06:     	orq	%r11, %rdx
140080f09:     	sete	%dl
140080f0c:     	orb	%r10b, %dl
140080f0f:     	je	0x140081710 <.text+0x80710>
140080f15:     	movl	$0x1, %edx
140080f1a:     	btq	$0x23, %r8
140080f1f:     	jae	0x140080f3a <.text+0x7ff3a>
140080f21:     	movl	$0xcccccccd, %edx       # imm = 0xCCCCCCCD
140080f26:     	imulq	%rdx, %r9
140080f2a:     	shrq	$0x23, %r9
140080f2e:     	addl	%r9d, %r9d
140080f31:     	leal	(%r9,%r9,4), %edx
140080f35:     	subl	%eax, %edx
140080f37:     	addl	$0xa, %edx
140080f3a:     	testq	%r12, %r12
140080f3d:     	je	0x140080f5a <.text+0x7ff5a>
140080f3f:     	cmpq	$0xa, %r12
140080f43:     	ja	0x1400817bd <.text+0x807bd>
140080f49:     	cmpl	%eax, -0x14(%rbp,%r12,4)
140080f4e:     	jae	0x140080f6a <.text+0x7ff6a>
140080f50:     	cmpq	$0xa, %r12
140080f54:     	je	0x140081710 <.text+0x80710>
140080f5a:     	movl	%eax, -0x10(%rbp,%r12,4)
140080f5f:     	movq	0x18(%rbp), %r12
140080f63:     	incq	%r12
140080f66:     	movq	%r12, 0x18(%rbp)
140080f6a:     	cmpl	$0x1, %edx
140080f6d:     	je	0x140080e00 <.text+0x7fe00>
140080f73:     	incl	%eax
140080f75:     	movq	%rcx, %r8
140080f78:     	imulq	%rax, %r8
140080f7c:     	cmpq	0x570(%rbp), %r8
140080f83:     	jae	0x140080e00 <.text+0x7fe00>
140080f89:     	addq	$-0x2, %rdx
140080f8d:     	testq	%r12, %r12
140080f90:     	je	0x140080fad <.text+0x7ffad>
140080f92:     	cmpq	$0xb, %r12
140080f96:     	jae	0x1400817bd <.text+0x807bd>
140080f9c:     	cmpl	-0x14(%rbp,%r12,4), %eax
140080fa1:     	jbe	0x140080fbd <.text+0x7ffbd>
140080fa3:     	cmpq	$0xa, %r12
140080fa7:     	je	0x140081710 <.text+0x80710>
140080fad:     	movl	%eax, -0x10(%rbp,%r12,4)
140080fb2:     	movq	0x18(%rbp), %r12
140080fb6:     	incq	%r12
140080fb9:     	movq	%r12, 0x18(%rbp)
140080fbd:     	subq	$0x1, %rdx
140080fc1:     	jb	0x140080e00 <.text+0x7fe00>
140080fc7:     	incl	%eax
140080fc9:     	movq	%rcx, %r8
140080fcc:     	imulq	%rax, %r8
140080fd0:     	cmpq	0x570(%rbp), %r8
140080fd7:     	jb	0x140080f8d <.text+0x7ff8d>
140080fd9:     	jmp	0x140080e00 <.text+0x7fe00>
140080fde:     	movaps	-0x10(%rbp), %xmm0
140080fe2:     	movaps	(%rbp), %xmm1
140080fe6:     	movaps	0x10(%rbp), %xmm2
140080fea:     	movups	%xmm0, 0x440(%rbp)
140080ff1:     	movups	%xmm1, 0x450(%rbp)
140080ff8:     	movups	%xmm2, 0x460(%rbp)
140080fff:     	xorl	%eax, %eax
140081001:     	movq	0x538(%rbp), %r15
140081008:     	movq	0x5f8(%rbp), %r12
14008100f:     	movq	0x530(%rbp), %r13
140081016:     	testq	%rax, %rax
140081019:     	je	0x1400815a4 <.text+0x805a4>
14008101f:     	leaq	0x440(%rbp), %rax
140081026:     	movq	0x10(%rax), %rcx
14008102a:     	movq	%rcx, 0x430(%rbp)
140081031:     	movups	(%rax), %xmm0
140081034:     	movups	%xmm0, 0x420(%rbp)
14008103b:     	movq	0x428(%rbp), %rax
140081042:     	movq	%rax, 0x10(%rsi)
140081046:     	movq	0x430(%rbp), %rax
14008104d:     	movq	%rax, 0x18(%rsi)
140081051:     	movups	0x419(%rbp), %xmm0
140081058:     	movups	%xmm0, 0x1(%rsi)
14008105c:     	movb	$0xa, (%rsi)
14008105f:     	jmp	0x140080d79 <.text+0x7fd79>
140081064:     	shlq	$0x2, %rdx
140081068:     	movq	%r9, %rax
14008106b:     	shlq	$0xe, %rax
14008106f:     	addq	%rdi, %rax
140081072:     	addq	$0x1b750, %rax          # imm = 0x1B750
140081078:     	movq	%rax, 0x4a8(%rbp)
14008107f:     	leaq	0x38(%r12), %rax
140081084:     	movq	%rax, 0x500(%rbp)
14008108b:     	leaq	0x66(%r12), %rax
140081090:     	movq	%rax, 0x4b0(%rbp)
140081097:     	leaq	0x56(%r12), %rax
14008109c:     	movq	%rax, 0x4b8(%rbp)
1400810a3:     	imulq	$0x2b0, %r9, %rax       # imm = 0x2B0
1400810aa:     	movzwl	0x54(%r12), %ecx
1400810b0:     	movw	%cx, 0x582(%rbp)
1400810b7:     	movzbl	0x70(%r12), %ecx
1400810bd:     	movb	%cl, 0x585(%rbp)
1400810c3:     	addq	%rdi, %rax
1400810c6:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
1400810cc:     	movq	%rax, 0x508(%rbp)
1400810d3:     	addq	$-0x4, %rdx
1400810d7:     	xorl	%r12d, %r12d
1400810da:     	movq	%r15, 0x538(%rbp)
1400810e1:     	movq	%r13, 0x530(%rbp)
1400810e8:     	movq	%rdx, 0x4c0(%rbp)
1400810ef:     	movl	0x470(%rbp,%r12), %ebx
1400810f7:     	movq	%r13, %r14
1400810fa:     	imulq	%rbx, %r14
1400810fe:     	testq	%r12, %r12
140081101:     	je	0x14008110c <.text+0x8010c>
140081103:     	cmpq	%rsi, %r14
140081106:     	jae	0x14008155e <.text+0x8055e>
14008110c:     	movq	%r12, 0x4f0(%rbp)
140081113:     	leaq	(%r14,%r13), %r12
140081117:     	cmpq	%r12, %rsi
14008111a:     	movq	%r12, %r13
14008111d:     	cmovbq	%rsi, %r13
140081121:     	movl	$0x400, %r8d            # imm = 0x400
140081127:     	leaq	-0x10(%rbp), %rcx
14008112b:     	xorl	%edx, %edx
14008112d:     	callq	0x1402394b2 <.text+0x2384b2>
140081132:     	movq	%r13, %r15
140081135:     	subq	%r14, %r15
140081138:     	cmpq	$0x401, %r15            # imm = 0x401
14008113f:     	jae	0x14008178d <.text+0x8078d>
140081145:     	movq	0x610(%rbp), %rax
14008114c:     	cmpb	$0x1, 0x1b748(%rdi,%rax)
140081154:     	jne	0x140081609 <.text+0x80609>
14008115a:     	movq	0x2b750(%rdi,%rax,8), %rax
140081162:     	cmpq	$0x4001, %rax           # imm = 0x4001
140081168:     	jae	0x14008175a <.text+0x8075a>
14008116e:     	cmpq	%r14, %rsi
140081171:     	jb	0x1400817a6 <.text+0x807a6>
140081177:     	cmpq	%rax, %r13
14008117a:     	ja	0x1400817a6 <.text+0x807a6>
140081180:     	addq	0x4a8(%rbp), %r14
140081187:     	leaq	-0x10(%rbp), %rcx
14008118b:     	movq	%r14, %rdx
14008118e:     	movq	%r15, %r8
140081191:     	callq	0x1402394a0 <.text+0x2384a0>
140081196:     	movq	%rbx, %rax
140081199:     	cmpl	$0xfffff, %eax          # imm = 0xFFFFF
14008119e:     	ja	0x140081620 <.text+0x80620>
1400811a4:     	movq	%rdi, %r14
1400811a7:     	xorl	%edi, %edi
1400811a9:     	cmpq	%rsi, %r12
1400811ac:     	setb	0x584(%rbp)
1400811b3:     	movl	%eax, 0x540(%rbp)
1400811b9:     	movq	0x4a0(%rbp), %rax
1400811c0:     	movb	%al, 0x544(%rbp)
1400811c6:     	movl	0x541(%rbp), %r13d
1400811cd:     	cmpq	$0x0, 0x4f0(%rbp)
1400811d5:     	je	0x140081216 <.text+0x80216>
1400811d7:     	leaq	0x540(%rbp), %rcx
1400811de:     	movq	0x4f8(%rbp), %rdx
1400811e5:     	movq	%r14, %r8
1400811e8:     	movq	0x5f0(%rbp), %r9
1400811ef:     	callq	0x1400245a0 <.text+0x235a0>
1400811f4:     	movzbl	0x540(%rbp), %eax
1400811fb:     	cmpb	$-0x1, %al
1400811fd:     	jne	0x1400816d2 <.text+0x806d2>
140081203:     	movzwl	0x542(%rbp), %eax
14008120a:     	movw	%ax, 0x586(%rbp)
140081211:     	jmp	0x140081360 <.text+0x80360>
140081216:     	movzwl	0x582(%rbp), %eax
14008121d:     	movw	%ax, 0x586(%rbp)
140081224:     	cmpb	$0x2, 0x608(%rbp)
14008122b:     	jne	0x140081360 <.text+0x80360>
140081231:     	movq	0x628(%rbp), %rax
140081238:     	movq	%rax, 0x28(%rsp)
14008123d:     	movzbl	0x585(%rbp), %eax
140081244:     	movb	%al, 0x20(%rsp)
140081248:     	movq	%r14, %rcx
14008124b:     	movq	%r14, 0x4c8(%rbp)
140081252:     	movq	0x500(%rbp), %rdx
140081259:     	movzwl	0x582(%rbp), %esi
140081260:     	movl	%esi, %r8d
140081263:     	movq	0x5f0(%rbp), %r9
14008126a:     	callq	0x14008f560 <.text+0x8e560>
14008126f:     	movb	$0x2, 0x56c(%rbp)
140081276:     	movb	$0x0, 0x562(%rbp)
14008127d:     	movw	%si, 0x560(%rbp)
140081284:     	movq	0x4c8(%rbp), %rsi
14008128b:     	leaq	0x563(%rbp), %rax
140081292:     	movb	$0x0, 0x8(%rax)
140081296:     	movq	$0x0, (%rax)
14008129d:     	movq	$0x8, 0x540(%rbp)
1400812a8:     	movq	$0x0, 0x548(%rbp)
1400812b3:     	movq	$0x1, 0x550(%rbp)
1400812be:     	movq	$0x0, 0x558(%rbp)
1400812c9:     	leaq	0x540(%rbp), %rax
1400812d0:     	movq	%rax, 0x20(%rsp)
1400812d5:     	leaq	0x510(%rbp), %rcx
1400812dc:     	movq	%rsi, %rdx
1400812df:     	movq	0x538(%rbp), %r8
1400812e6:     	movq	0x500(%rbp), %r9
1400812ed:     	callq	0x1400333f0 <.text+0x323f0>
1400812f2:     	cmpb	$-0x1, 0x510(%rbp)
1400812f9:     	je	0x140081319 <.text+0x80319>
1400812fb:     	movups	0x510(%rbp), %xmm0
140081302:     	movups	0x520(%rbp), %xmm1
140081309:     	movaps	%xmm1, 0x4e0(%rbp)
140081310:     	movaps	%xmm0, 0x4d0(%rbp)
140081317:     	jmp	0x140081336 <.text+0x80336>
140081319:     	leaq	0x4d0(%rbp), %rcx
140081320:     	movq	0x4f8(%rbp), %rdx
140081327:     	movq	%rsi, %r8
14008132a:     	movq	0x5f0(%rbp), %r9
140081331:     	callq	0x1400245a0 <.text+0x235a0>
140081336:     	movzbl	0x4d0(%rbp), %eax
14008133d:     	movzwl	0x4d2(%rbp), %ecx
140081344:     	movw	%cx, 0x586(%rbp)
14008134b:     	cmpb	$-0x1, %al
14008134d:     	jne	0x140081721 <.text+0x80721>
140081353:     	nopw	%cs:(%rax,%rax)
140081360:     	movq	%r14, %rcx
140081363:     	callq	0x1400921e0 <.text+0x911e0>
140081368:     	testb	$0x1, %al
14008136a:     	je	0x14008163d <.text+0x8063d>
140081370:     	movq	%rdx, %rsi
140081373:     	movzbl	0x584(%rbp), %eax
14008137a:     	movb	%al, %dil
14008137d:     	shlq	$0x28, %rdi
140081381:     	shlq	$0x8, %r13
140081385:     	orq	%rdi, %r13
140081388:     	movzbl	%bl, %eax
14008138b:     	orq	%r13, %rax
14008138e:     	movq	0x500(%rbp), %r13
140081395:     	movups	(%r13), %xmm0
14008139a:     	movups	0xc(%r13), %xmm1
14008139f:     	movups	%xmm1, 0x51c(%rbp)
1400813a6:     	movaps	%xmm0, 0x510(%rbp)
1400813ad:     	movq	$0x1, 0x540(%rbp)
1400813b8:     	movq	0x570(%rbp), %rcx
1400813bf:     	movq	%rcx, 0x548(%rbp)
1400813c6:     	movq	%rax, 0x550(%rbp)
1400813cd:     	movb	$0x1, 0x558(%rbp)
1400813d4:     	movq	0x4b8(%rbp), %rcx
1400813db:     	movq	(%rcx), %rax
1400813de:     	movq	0x7(%rcx), %rcx
1400813e2:     	movq	%rcx, 0x4d7(%rbp)
1400813e9:     	movq	%rax, 0x4d0(%rbp)
1400813f0:     	leaq	0x4d0(%rbp), %rax
1400813f7:     	movq	%rax, 0x68(%rsp)
1400813fc:     	movq	0x620(%rbp), %rax
140081403:     	movq	%rax, 0x60(%rsp)
140081408:     	movq	0x5f8(%rbp), %rax
14008140f:     	movq	%rax, 0x58(%rsp)
140081414:     	leaq	0x540(%rbp), %rdi
14008141b:     	movq	%rdi, 0x50(%rsp)
140081420:     	movq	%r15, 0x48(%rsp)
140081425:     	leaq	-0x10(%rbp), %rax
140081429:     	movq	%rax, 0x40(%rsp)
14008142e:     	movq	0x600(%rbp), %rax
140081435:     	movq	%rax, 0x38(%rsp)
14008143a:     	movq	0x4b0(%rbp), %rax
140081441:     	movq	%rax, 0x30(%rsp)
140081446:     	movzwl	0x586(%rbp), %ebx
14008144d:     	movw	%bx, 0x28(%rsp)
140081452:     	movb	$0x1, 0x20(%rsp)
140081457:     	leaq	0x3f8(%rbp), %rcx
14008145e:     	movq	%r14, %rdx
140081461:     	leaq	0x510(%rbp), %r15
140081468:     	movq	%r15, %r8
14008146b:     	movq	%rsi, %r9
14008146e:     	callq	0x14007be40 <.text+0x7ae40>
140081473:     	cmpb	$-0x1, 0x3f8(%rbp)
14008147a:     	jne	0x14008164c <.text+0x8064c>
140081480:     	movq	$0x0, 0x510(%rbp)
14008148b:     	movq	%r15, 0x28(%rsp)
140081490:     	movq	%r13, 0x20(%rsp)
140081495:     	movq	%rdi, %rcx
140081498:     	movq	%r14, %rdx
14008149b:     	movq	0x538(%rbp), %r8
1400814a2:     	movq	%rsi, %r9
1400814a5:     	callq	0x1400bd7f0 <.text+0xbc7f0>
1400814aa:     	cmpb	$-0x1, 0x540(%rbp)
1400814b1:     	jne	0x1400816b1 <.text+0x806b1>
1400814b7:     	movq	%r14, %rdi
1400814ba:     	movq	0x610(%rbp), %rax
1400814c1:     	cmpb	$0x1, 0x1b748(%r14,%rax)
1400814ca:     	jne	0x140081530 <.text+0x80530>
1400814cc:     	movq	0x508(%rbp), %rax
1400814d3:     	movq	(%rax), %rax
1400814d6:     	cmpq	$0x2, %rax
1400814da:     	je	0x140081530 <.text+0x80530>
1400814dc:     	movq	0x508(%rbp), %rcx
1400814e3:     	cmpb	$0x7, 0x2ae(%rcx)
1400814ea:     	sete	%cl
1400814ed:     	andb	%cl, %al
1400814ef:     	cmpb	$0x1, %al
1400814f1:     	jne	0x140081530 <.text+0x80530>
1400814f3:     	movq	0x508(%rbp), %rdx
1400814fa:     	cmpl	$0x2, 0x20(%rdx)
1400814fe:     	movzwl	%bx, %eax
140081501:     	cmovel	0x34(%rdx), %eax
140081505:     	movl	0x30(%rdx), %ecx
140081508:     	movl	$0x1, %r8d
14008150e:     	cmovnel	%r8d, %ecx
140081512:     	movq	$0x1, (%rdx)
140081519:     	movl	%ecx, 0x30(%rdx)
14008151c:     	movl	%eax, 0x34(%rdx)
14008151f:     	movb	$0x7, 0x2ae(%rdx)
140081526:     	nopw	%cs:(%rax,%rax)
140081530:     	movq	0x570(%rbp), %rsi
140081537:     	cmpq	%rsi, %r12
14008153a:     	movq	0x530(%rbp), %r13
140081541:     	movq	0x4c0(%rbp), %rdx
140081548:     	movq	0x4f0(%rbp), %rax
14008154f:     	jae	0x14008155e <.text+0x8055e>
140081551:     	cmpq	%rax, %rdx
140081554:     	leaq	0x4(%rax), %r12
140081558:     	jne	0x1400810ef <.text+0x800ef>
14008155e:     	movq	0x578(%rbp), %rax
140081565:     	movb	$-0x1, (%rax)
140081568:     	jmp	0x140080d79 <.text+0x7fd79>
14008156d:     	movzwl	0x2e(%r12), %eax
140081573:     	shlq	$0x30, %rax
140081577:     	shlq	$0x28, %rdx
14008157b:     	orq	%rax, %rdx
14008157e:     	orq	%r14, %rdx
140081581:     	leaq	0x438(%rbp), %rcx
140081588:     	movq	0x570(%rbp), %r8
14008158f:     	callq	0x1400803f0 <.text+0x7f3f0>
140081594:     	movq	0x438(%rbp), %rax
14008159b:     	testq	%rax, %rax
14008159e:     	jne	0x14008101f <.text+0x8001f>
1400815a4:     	movzbl	0x440(%rbp), %eax
1400815ab:     	movups	0x460(%rbp), %xmm0
1400815b2:     	movups	%xmm0, 0x490(%rbp)
1400815b9:     	movups	0x441(%rbp), %xmm0
1400815c0:     	movups	%xmm0, 0x471(%rbp)
1400815c7:     	movups	0x450(%rbp), %xmm0
1400815ce:     	movups	%xmm0, 0x480(%rbp)
1400815d5:     	movb	%al, 0x470(%rbp)
1400815db:     	movq	0x610(%rbp), %r9
1400815e2:     	movq	0x498(%rbp), %rdx
1400815e9:     	cmpq	$0xb, %rdx
1400815ed:     	jb	0x140080cbc <.text+0x7fcbc>
1400815f3:     	leaq	0x1d0516(%rip), %r9     # 0x140251b10
1400815fa:     	movl	$0xa, %r8d
140081600:     	xorl	%ecx, %ecx
140081602:     	callq	0x140239ef0 <.text+0x238ef0>
140081607:     	ud2
140081609:     	movq	0x578(%rbp), %rax
140081610:     	movb	$0xa, (%rax)
140081613:     	movq	$0x3, 0x8(%rax)
14008161b:     	jmp	0x140080d79 <.text+0x7fd79>
140081620:     	movq	0x578(%rbp), %rcx
140081627:     	movabsq	$0x31100000000, %rax    # imm = 0x31100000000
140081631:     	movb	$0xa, (%rcx)
140081634:     	movq	%rax, 0x4(%rcx)
140081638:     	jmp	0x140080d79 <.text+0x7fd79>
14008163d:     	movq	0x578(%rbp), %rax
140081644:     	movb	$0x9, (%rax)
140081647:     	jmp	0x140080d79 <.text+0x7fd79>
14008164c:     	cmpb	$0x1, 0x37740(%r14,%rsi)
140081655:     	jne	0x1400816a1 <.text+0x806a1>
140081657:     	cmpb	$0x0, 0x37760(%r14,%rsi)
140081660:     	jne	0x1400816a1 <.text+0x806a1>
140081662:     	movb	$0x0, 0x37740(%r14,%rsi)
14008166b:     	decq	0x37788(%r14)
140081672:     	leaq	0x37740(%r14), %rax
140081679:     	movq	$0x0, 0x43610(%r14,%rsi,8)
140081685:     	leaq	(%rsi,%rsi,8), %rcx
140081689:     	leaq	(%rcx,%rcx,2), %rcx
14008168d:     	addq	%rsi, %rcx
140081690:     	movb	$0x2, 0x36a(%rax,%rcx)
140081698:     	leaq	(%rsi,%rsi,2), %rcx
14008169c:     	movb	$0x2, 0x5d(%rax,%rcx,8)
1400816a1:     	movups	0x3f8(%rbp), %xmm0
1400816a8:     	movups	0x408(%rbp), %xmm1
1400816af:     	jmp	0x1400816bf <.text+0x806bf>
1400816b1:     	movups	0x540(%rbp), %xmm0
1400816b8:     	movups	0x550(%rbp), %xmm1
1400816bf:     	movq	0x578(%rbp), %rax
1400816c6:     	movups	%xmm1, 0x10(%rax)
1400816ca:     	movups	%xmm0, (%rax)
1400816cd:     	jmp	0x140080d79 <.text+0x7fd79>
1400816d2:     	movzbl	0x541(%rbp), %ecx
1400816d9:     	movzwl	0x542(%rbp), %edx
1400816e0:     	movups	0x550(%rbp), %xmm0
1400816e7:     	movq	0x578(%rbp), %r8
1400816ee:     	movups	%xmm0, 0x10(%r8)
1400816f3:     	movups	0x544(%rbp), %xmm0
1400816fa:     	movups	%xmm0, 0x4(%r8)
1400816ff:     	movb	%al, (%r8)
140081702:     	movb	%cl, 0x1(%r8)
140081706:     	movw	%dx, 0x2(%r8)
14008170b:     	jmp	0x140080d79 <.text+0x7fd79>
140081710:     	movb	$0x7, 0x440(%rbp)
140081717:     	movl	$0x1, %eax
14008171c:     	jmp	0x140081001 <.text+0x80001>
140081721:     	movzbl	0x4d1(%rbp), %ecx
140081728:     	movups	0x4e0(%rbp), %xmm0
14008172f:     	movq	0x578(%rbp), %rdx
140081736:     	movups	%xmm0, 0x10(%rdx)
14008173a:     	movups	0x4d4(%rbp), %xmm0
140081741:     	movups	%xmm0, 0x4(%rdx)
140081745:     	movb	%al, (%rdx)
140081747:     	movb	%cl, 0x1(%rdx)
14008174a:     	movzwl	0x586(%rbp), %eax
140081751:     	movw	%ax, 0x2(%rdx)
140081755:     	jmp	0x140080d79 <.text+0x7fd79>
14008175a:     	leaq	0x1d34cf(%rip), %r9     # 0x140254c30
140081761:     	movl	$0x4000, %r8d           # imm = 0x4000
140081767:     	xorl	%ecx, %ecx
140081769:     	movq	%rax, %rdx
14008176c:     	callq	0x140239ef0 <.text+0x238ef0>
140081771:     	ud2
140081773:     	leaq	0x1d033e(%rip), %rcx    # 0x140251ab8
14008177a:     	leaq	0x1d0347(%rip), %r8     # 0x140251ac8
140081781:     	movl	$0xb, %edx
140081786:     	callq	0x140239c00 <.text+0x238c00>
14008178b:     	ud2
14008178d:     	leaq	0x1d0364(%rip), %r9     # 0x140251af8
140081794:     	movl	$0x400, %r8d            # imm = 0x400
14008179a:     	xorl	%ecx, %ecx
14008179c:     	movq	%r15, %rdx
14008179f:     	callq	0x140239ef0 <.text+0x238ef0>
1400817a4:     	ud2
1400817a6:     	leaq	0x1d0333(%rip), %r9     # 0x140251ae0
1400817ad:     	movq	%r14, %rcx
1400817b0:     	movq	%r13, %rdx
1400817b3:     	movq	%rax, %r8
1400817b6:     	callq	0x140239ef0 <.text+0x238ef0>
1400817bb:     	ud2
1400817bd:     	decq	%r12
1400817c0:     	leaq	0x1d02d9(%rip), %r8     # 0x140251aa0
1400817c7:     	movl	$0xa, %edx
1400817cc:     	movq	%r12, %rcx
1400817cf:     	callq	0x140239ce3 <.text+0x238ce3>
1400817d4:     	ud2
1400817d6:     	movb	$0x1, 0x510(%rbp)
1400817dd:     	leaq	0x1d142c(%rip), %rax    # 0x140252c10
1400817e4:     	movq	%rax, 0x20(%rsp)
1400817e9:     	leaq	0x1d1408(%rip), %rcx    # 0x140252bf8
1400817f0:     	leaq	0x1d2b41(%rip), %r9     # 0x140254338
1400817f7:     	leaq	0x510(%rbp), %r8
1400817fe:     	movl	$0x11, %edx
140081803:     	callq	0x140239c60 <.text+0x238c60>
140081808:     	ud2


D:\CoapticCurrent\packet-lazy-staged-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140081810:     	pushq	%rbp
140081811:     	pushq	%r15
140081813:     	pushq	%r14
140081815:     	pushq	%r13
140081817:     	pushq	%r12
140081819:     	pushq	%rsi
14008181a:     	pushq	%rdi
14008181b:     	pushq	%rbx
14008181c:     	subq	$0x5e8, %rsp            # imm = 0x5E8
140081823:     	leaq	0x80(%rsp), %rbp
14008182b:     	movq	%rdx, %rdi
14008182e:     	movq	0x5d8(%rbp), %r11
140081835:     	movzbl	0x2d(%r11), %edx
14008183a:     	cmpq	$0x2, %rdx
14008183e:     	je	0x1400823b9 <.text+0x813b9>
140081844:     	movq	%rcx, %rsi
140081847:     	cmpq	$-0x1, 0x230(%rdi)
14008184f:     	je	0x1400821d5 <.text+0x811d5>
140081855:     	movq	0x5f0(%rbp), %rbx
14008185c:     	cmpq	0x258(%rdi), %rbx
140081863:     	jae	0x1400821d5 <.text+0x811d5>
140081869:     	movq	0x250(%rdi), %rax
140081870:     	cmpb	$0x1, (%rax,%rbx)
140081874:     	jne	0x1400821d5 <.text+0x811d5>
14008187a:     	cmpq	0x240(%rdi), %rbx
140081881:     	jae	0x1400821d5 <.text+0x811d5>
140081887:     	movq	0x238(%rdi), %rcx
14008188e:     	imulq	$0x2d0, %rbx, %r10      # imm = 0x2D0
140081895:     	movq	0x2c0(%rcx,%r10), %rax
14008189d:     	movq	%r10, 0x548(%rbp)
1400818a4:     	movq	0x2c8(%rcx,%r10), %rcx
1400818ac:     	movq	%rcx, 0x558(%rbp)
1400818b3:     	cmpq	%rax, %rcx
1400818b6:     	ja	0x1400823ec <.text+0x813ec>
1400818bc:     	movl	0x28(%r11), %eax
1400818c0:     	movzbl	0x2c(%r11), %r15d
1400818c5:     	shlq	$0x20, %r15
1400818c9:     	orq	%rax, %r15
1400818cc:     	movq	%r15, %r14
1400818cf:     	shrq	$0x20, %r14
1400818d3:     	movl	%r14d, %ecx
1400818d6:     	andb	$0xf, %cl
1400818d9:     	movl	$0x10, %r10d
1400818df:     	shll	%cl, %r10d
1400818e2:     	movq	0x5f8(%rbp), %rax
1400818e9:     	movq	%r14, 0x488(%rbp)
1400818f0:     	cmpq	$0x7, %r14
1400818f4:     	movzwl	%r10w, %ecx
1400818f8:     	movl	$0x400, %r12d           # imm = 0x400
1400818fe:     	cmovneq	%rcx, %r12
140081902:     	cmpb	$0x0, (%rax)
140081905:     	movq	%r9, 0x4e8(%rbp)
14008190c:     	movq	%r8, 0x4e0(%rbp)
140081913:     	je	0x140081a26 <.text+0x80a26>
140081919:     	movups	0x8(%rax), %xmm0
14008191d:     	movups	0x18(%rax), %xmm1
140081921:     	movups	0x28(%rax), %xmm2
140081925:     	movaps	%xmm2, 0x440(%rbp)
14008192c:     	movaps	%xmm1, 0x430(%rbp)
140081933:     	movaps	%xmm0, 0x420(%rbp)
14008193a:     	movq	0x448(%rbp), %rdx
140081941:     	cmpq	$0xb, %rdx
140081945:     	jae	0x140082371 <.text+0x81371>
14008194b:     	testq	%rdx, %rdx
14008194e:     	je	0x1400821d0 <.text+0x811d0>
140081954:     	shrq	$0x23, %r15
140081958:     	je	0x140081c9a <.text+0x80c9a>
14008195e:     	movl	0x420(%rbp), %r13d
140081965:     	imulq	%r12, %r13
140081969:     	addq	%r13, %r12
14008196c:     	movq	0x558(%rbp), %rax
140081973:     	cmpq	%r12, %rax
140081976:     	movq	%r12, %r15
140081979:     	cmovbq	%rax, %r15
14008197d:     	leaq	-0x10(%rbp), %rcx
140081981:     	movl	$0x400, %r8d            # imm = 0x400
140081987:     	xorl	%edx, %edx
140081989:     	callq	0x1402394b2 <.text+0x2384b2>
14008198e:     	movq	%r15, %r14
140081991:     	subq	%r13, %r14
140081994:     	cmpq	$0x400, %r14            # imm = 0x400
14008199b:     	ja	0x1400823d3 <.text+0x813d3>
1400819a1:     	cmpq	$-0x1, 0x230(%rdi)
1400819a9:     	je	0x1400821d5 <.text+0x811d5>
1400819af:     	cmpq	0x258(%rdi), %rbx
1400819b6:     	jae	0x1400821d5 <.text+0x811d5>
1400819bc:     	movq	0x250(%rdi), %rax
1400819c3:     	cmpb	$0x1, (%rax,%rbx)
1400819c7:     	jne	0x1400821d5 <.text+0x811d5>
1400819cd:     	cmpq	0x240(%rdi), %rbx
1400819d4:     	jae	0x1400821d5 <.text+0x811d5>
1400819da:     	movq	0x238(%rdi), %rax
1400819e1:     	movq	0x548(%rbp), %rcx
1400819e8:     	movq	0x2c0(%rax,%rcx), %r8
1400819f0:     	movq	0x2c8(%rax,%rcx), %rax
1400819f8:     	cmpq	%r8, %rax
1400819fb:     	ja	0x140082406 <.text+0x81406>
140081a01:     	cmpq	%r13, 0x558(%rbp)
140081a08:     	jb	0x140082419 <.text+0x81419>
140081a0e:     	cmpq	%rax, %r15
140081a11:     	ja	0x140082419 <.text+0x81419>
140081a17:     	movabsq	$0x21100000000, %rax    # imm = 0x21100000000
140081a21:     	jmp	0x140082279 <.text+0x81279>
140081a26:     	movq	0x30(%r11), %rax
140081a2a:     	testq	%rax, %rax
140081a2d:     	je	0x1400821f4 <.text+0x811f4>
140081a33:     	movups	(%rax), %xmm0
140081a36:     	xorps	%xmm1, %xmm1
140081a39:     	movaps	%xmm1, 0x10(%rbp)
140081a3d:     	movaps	%xmm1, (%rbp)
140081a41:     	movaps	%xmm1, -0x10(%rbp)
140081a45:     	movups	%xmm0, 0x518(%rbp)
140081a4c:     	movq	$0x0, 0x528(%rbp)
140081a57:     	leaq	0x530(%rbp), %rbx
140081a5e:     	movl	$0x0, 0x530(%rbp)
140081a68:     	movw	$0x1f, 0x538(%rbp)
140081a71:     	xorl	%r14d, %r14d
140081a74:     	leaq	0x4f8(%rbp), %r13
140081a7b:     	nopl	(%rax,%rax)
140081a80:     	movq	0x520(%rbp), %r8
140081a87:     	cmpq	%r8, 0x528(%rbp)
140081a8e:     	jae	0x140081c57 <.text+0x80c57>
140081a94:     	movq	0x518(%rbp), %rdx
140081a9b:     	movq	%rbx, 0x20(%rsp)
140081aa0:     	movq	%r13, %rcx
140081aa3:     	leaq	0x528(%rbp), %r9
140081aaa:     	callq	0x14000e450 <.text+0xd450>
140081aaf:     	movq	0x4f8(%rbp), %rax
140081ab6:     	testq	%rax, %rax
140081ab9:     	je	0x140081c57 <.text+0x80c57>
140081abf:     	movzwl	0x538(%rbp), %ecx
140081ac6:     	cmpw	%cx, 0x508(%rbp)
140081acd:     	je	0x140081ad6 <.text+0x80ad6>
140081acf:     	jbe	0x140081a80 <.text+0x80a80>
140081ad1:     	jmp	0x140081c57 <.text+0x80c57>
140081ad6:     	movq	0x500(%rbp), %rdx
140081add:     	cmpq	$0x3, %rdx
140081ae1:     	ja	0x140082449 <.text+0x81449>
140081ae7:     	testq	%rdx, %rdx
140081aea:     	je	0x140081b1d <.text+0x80b1d>
140081aec:     	movzbl	(%rax), %ecx
140081aef:     	cmpq	$0x1, %rdx
140081af3:     	je	0x140081b12 <.text+0x80b12>
140081af5:     	movl	%ecx, %r8d
140081af8:     	shll	$0x8, %r8d
140081afc:     	movzbl	0x1(%rax), %ecx
140081b00:     	orl	%r8d, %ecx
140081b03:     	cmpq	$0x2, %rdx
140081b07:     	je	0x140081b12 <.text+0x80b12>
140081b09:     	shll	$0x8, %ecx
140081b0c:     	movzbl	0x2(%rax), %eax
140081b10:     	orl	%eax, %ecx
140081b12:     	movl	%ecx, %eax
140081b14:     	movq	%rax, %r8
140081b17:     	shlq	$0x20, %r8
140081b1b:     	jmp	0x140081b25 <.text+0x80b25>
140081b1d:     	movl	$0x100, %r8d            # imm = 0x100
140081b23:     	xorl	%eax, %eax
140081b25:     	andb	$0x7, %al
140081b27:     	movq	%r8, %rcx
140081b2a:     	shrq	$0x24, %rcx
140081b2e:     	movl	%ecx, 0x4f8(%rbp)
140081b34:     	movb	%al, 0x4fc(%rbp)
140081b3a:     	movl	0x4f9(%rbp), %edx
140081b40:     	movq	%rdx, %r9
140081b43:     	shlq	$0x8, %r9
140081b47:     	movzbl	%cl, %eax
140081b4a:     	orq	%r9, %rax
140081b4d:     	shrl	$0x18, %edx
140081b50:     	movl	%edx, %ecx
140081b52:     	andb	$0xf, %cl
140081b55:     	movl	$0x10, %r9d
140081b5b:     	shll	%cl, %r9d
140081b5e:     	cmpl	$0x7, %edx
140081b61:     	movzwl	%r9w, %ecx
140081b65:     	movl	$0x400, %edx            # imm = 0x400
140081b6a:     	cmoveq	%rdx, %rcx
140081b6e:     	movl	%eax, %r9d
140081b71:     	movq	%r9, %rdx
140081b74:     	imulq	%rcx, %rdx
140081b78:     	cmpq	0x558(%rbp), %rdx
140081b7f:     	jb	0x140081b8e <.text+0x80b8e>
140081b81:     	orq	0x558(%rbp), %rdx
140081b88:     	jne	0x140082302 <.text+0x81302>
140081b8e:     	movl	$0x1, %edx
140081b93:     	btq	$0x23, %r8
140081b98:     	jae	0x140081bb3 <.text+0x80bb3>
140081b9a:     	movl	$0xcccccccd, %edx       # imm = 0xCCCCCCCD
140081b9f:     	imulq	%rdx, %r9
140081ba3:     	shrq	$0x23, %r9
140081ba7:     	addl	%r9d, %r9d
140081baa:     	leal	(%r9,%r9,4), %edx
140081bae:     	subl	%eax, %edx
140081bb0:     	addl	$0xa, %edx
140081bb3:     	testq	%r14, %r14
140081bb6:     	je	0x140081bd3 <.text+0x80bd3>
140081bb8:     	cmpq	$0xa, %r14
140081bbc:     	ja	0x140082430 <.text+0x81430>
140081bc2:     	cmpl	%eax, -0x14(%rbp,%r14,4)
140081bc7:     	jae	0x140081be3 <.text+0x80be3>
140081bc9:     	cmpq	$0xa, %r14
140081bcd:     	je	0x140082302 <.text+0x81302>
140081bd3:     	movl	%eax, -0x10(%rbp,%r14,4)
140081bd8:     	movq	0x18(%rbp), %r14
140081bdc:     	incq	%r14
140081bdf:     	movq	%r14, 0x18(%rbp)
140081be3:     	cmpl	$0x1, %edx
140081be6:     	je	0x140081a80 <.text+0x80a80>
140081bec:     	incl	%eax
140081bee:     	movq	%rcx, %r8
140081bf1:     	imulq	%rax, %r8
140081bf5:     	cmpq	0x558(%rbp), %r8
140081bfc:     	jae	0x140081a80 <.text+0x80a80>
140081c02:     	addq	$-0x2, %rdx
140081c06:     	testq	%r14, %r14
140081c09:     	je	0x140081c26 <.text+0x80c26>
140081c0b:     	cmpq	$0xb, %r14
140081c0f:     	jae	0x140082430 <.text+0x81430>
140081c15:     	cmpl	-0x14(%rbp,%r14,4), %eax
140081c1a:     	jbe	0x140081c36 <.text+0x80c36>
140081c1c:     	cmpq	$0xa, %r14
140081c20:     	je	0x140082302 <.text+0x81302>
140081c26:     	movl	%eax, -0x10(%rbp,%r14,4)
140081c2b:     	movq	0x18(%rbp), %r14
140081c2f:     	incq	%r14
140081c32:     	movq	%r14, 0x18(%rbp)
140081c36:     	subq	$0x1, %rdx
140081c3a:     	jb	0x140081a80 <.text+0x80a80>
140081c40:     	incl	%eax
140081c42:     	movq	%rcx, %r8
140081c45:     	imulq	%rax, %r8
140081c49:     	cmpq	0x558(%rbp), %r8
140081c50:     	jb	0x140081c06 <.text+0x80c06>
140081c52:     	jmp	0x140081a80 <.text+0x80a80>
140081c57:     	movaps	-0x10(%rbp), %xmm0
140081c5b:     	movaps	(%rbp), %xmm1
140081c5f:     	movaps	0x10(%rbp), %xmm2
140081c63:     	movups	%xmm0, 0x458(%rbp)
140081c6a:     	movups	%xmm1, 0x468(%rbp)
140081c71:     	movups	%xmm2, 0x478(%rbp)
140081c78:     	movq	$0x0, 0x450(%rbp)
140081c83:     	xorl	%eax, %eax
140081c85:     	movq	0x5f0(%rbp), %rbx
140081c8c:     	testq	%rax, %rax
140081c8f:     	jne	0x14008222a <.text+0x8122a>
140081c95:     	jmp	0x140082329 <.text+0x81329>
140081c9a:     	shlq	$0x2, %rdx
140081c9e:     	movq	0x5d8(%rbp), %rax
140081ca5:     	leaq	0x38(%rax), %rcx
140081ca9:     	movq	%rcx, 0x4f0(%rbp)
140081cb0:     	leaq	0x66(%rax), %rcx
140081cb4:     	movq	%rcx, 0x490(%rbp)
140081cbb:     	leaq	0x56(%rax), %rcx
140081cbf:     	movq	%rcx, 0x498(%rbp)
140081cc6:     	movzwl	0x54(%rax), %ecx
140081cca:     	movw	%cx, 0x556(%rbp)
140081cd1:     	movzbl	0x70(%rax), %eax
140081cd5:     	movb	%al, 0x565(%rbp)
140081cdb:     	addq	$-0x4, %rdx
140081cdf:     	xorl	%eax, %eax
140081ce1:     	movq	%r12, 0x4a0(%rbp)
140081ce8:     	movq	%rdx, 0x4a8(%rbp)
140081cef:     	movl	0x420(%rbp,%rax), %ecx
140081cf6:     	movq	%r12, %r13
140081cf9:     	imulq	%rcx, %r13
140081cfd:     	testq	%rax, %rax
140081d00:     	je	0x140081d0f <.text+0x80d0f>
140081d02:     	cmpq	0x558(%rbp), %r13
140081d09:     	jae	0x1400821d0 <.text+0x811d0>
140081d0f:     	movq	%rcx, 0x4d0(%rbp)
140081d16:     	movq	%rax, 0x4d8(%rbp)
140081d1d:     	addq	%r13, %r12
140081d20:     	movq	0x558(%rbp), %rax
140081d27:     	cmpq	%r12, %rax
140081d2a:     	movq	%r12, %r15
140081d2d:     	cmovbq	%rax, %r15
140081d31:     	movl	$0x400, %r8d            # imm = 0x400
140081d37:     	leaq	-0x10(%rbp), %rcx
140081d3b:     	xorl	%edx, %edx
140081d3d:     	callq	0x1402394b2 <.text+0x2384b2>
140081d42:     	movq	%r15, %r14
140081d45:     	subq	%r13, %r14
140081d48:     	cmpq	$0x401, %r14            # imm = 0x401
140081d4f:     	jae	0x1400823d3 <.text+0x813d3>
140081d55:     	cmpq	$-0x1, 0x230(%rdi)
140081d5d:     	je	0x1400821d5 <.text+0x811d5>
140081d63:     	cmpq	0x258(%rdi), %rbx
140081d6a:     	jae	0x1400821d5 <.text+0x811d5>
140081d70:     	movq	0x250(%rdi), %rax
140081d77:     	cmpb	$0x1, (%rax,%rbx)
140081d7b:     	jne	0x1400821d5 <.text+0x811d5>
140081d81:     	cmpq	0x240(%rdi), %rbx
140081d88:     	jae	0x1400821d5 <.text+0x811d5>
140081d8e:     	movq	0x238(%rdi), %rcx
140081d95:     	movq	0x548(%rbp), %rax
140081d9c:     	movq	0x2c0(%rcx,%rax), %r8
140081da4:     	movq	0x2c8(%rcx,%rax), %rax
140081dac:     	cmpq	%r8, %rax
140081daf:     	ja	0x140082406 <.text+0x81406>
140081db5:     	cmpq	%r13, 0x558(%rbp)
140081dbc:     	jb	0x140082419 <.text+0x81419>
140081dc2:     	cmpq	%rax, %r15
140081dc5:     	ja	0x140082419 <.text+0x81419>
140081dcb:     	addq	0x548(%rbp), %rcx
140081dd2:     	addq	0x2b8(%rcx), %r13
140081dd9:     	leaq	-0x10(%rbp), %rcx
140081ddd:     	movq	%r13, %rdx
140081de0:     	movq	%r14, %r8
140081de3:     	callq	0x1402394a0 <.text+0x2384a0>
140081de8:     	movq	0x4d0(%rbp), %rax
140081def:     	cmpl	$0xfffff, %eax          # imm = 0xFFFFF
140081df4:     	ja	0x14008226f <.text+0x8126f>
140081dfa:     	xorl	%ebx, %ebx
140081dfc:     	cmpq	0x558(%rbp), %r12
140081e03:     	setb	%r15b
140081e07:     	movl	%eax, 0x518(%rbp)
140081e0d:     	movq	0x488(%rbp), %rax
140081e14:     	movb	%al, 0x51c(%rbp)
140081e1a:     	movl	0x519(%rbp), %r13d
140081e21:     	cmpq	$0x0, 0x4d8(%rbp)
140081e29:     	movb	%r15b, 0x564(%rbp)
140081e30:     	je	0x140081e71 <.text+0x80e71>
140081e32:     	leaq	0x518(%rbp), %rcx
140081e39:     	movq	0x4e8(%rbp), %rdx
140081e40:     	movq	%rdi, %r8
140081e43:     	movq	0x5d0(%rbp), %r9
140081e4a:     	callq	0x140024850 <.text+0x23850>
140081e4f:     	movzbl	0x518(%rbp), %eax
140081e56:     	cmpb	$-0x1, %al
140081e58:     	jne	0x1400822d0 <.text+0x812d0>
140081e5e:     	movzwl	0x51a(%rbp), %eax
140081e65:     	movw	%ax, 0x566(%rbp)
140081e6c:     	jmp	0x140081fa2 <.text+0x80fa2>
140081e71:     	movzwl	0x556(%rbp), %eax
140081e78:     	movw	%ax, 0x566(%rbp)
140081e7f:     	cmpb	$0x2, 0x5e8(%rbp)
140081e86:     	movq	0x5d0(%rbp), %r9
140081e8d:     	jne	0x140081fa2 <.text+0x80fa2>
140081e93:     	movq	0x608(%rbp), %rax
140081e9a:     	movq	%rax, 0x28(%rsp)
140081e9f:     	movzbl	0x565(%rbp), %eax
140081ea6:     	movb	%al, 0x20(%rsp)
140081eaa:     	movq	%rdi, %rcx
140081ead:     	movq	0x4f0(%rbp), %rdx
140081eb4:     	movzwl	0x556(%rbp), %r15d
140081ebc:     	movl	%r15d, %r8d
140081ebf:     	callq	0x14008f820 <.text+0x8e820>
140081ec4:     	movb	$0x2, 0x544(%rbp)
140081ecb:     	movb	$0x0, 0x53a(%rbp)
140081ed2:     	movw	%r15w, 0x538(%rbp)
140081eda:     	leaq	0x53b(%rbp), %rax
140081ee1:     	movb	$0x0, 0x8(%rax)
140081ee5:     	movq	$0x0, (%rax)
140081eec:     	movq	$0x8, 0x518(%rbp)
140081ef7:     	movq	$0x0, 0x520(%rbp)
140081f02:     	movq	$0x1, 0x528(%rbp)
140081f0d:     	movq	$0x0, 0x530(%rbp)
140081f18:     	leaq	0x518(%rbp), %rax
140081f1f:     	movq	%rax, 0x20(%rsp)
140081f24:     	leaq	0x4f8(%rbp), %rcx
140081f2b:     	movq	%rdi, %rdx
140081f2e:     	movq	0x4e0(%rbp), %r8
140081f35:     	movq	0x4f0(%rbp), %r9
140081f3c:     	callq	0x140033980 <.text+0x32980>
140081f41:     	cmpb	$-0x1, 0x4f8(%rbp)
140081f48:     	je	0x140081f68 <.text+0x80f68>
140081f4a:     	movups	0x4f8(%rbp), %xmm0
140081f51:     	movups	0x508(%rbp), %xmm1
140081f58:     	movaps	%xmm1, 0x4c0(%rbp)
140081f5f:     	movaps	%xmm0, 0x4b0(%rbp)
140081f66:     	jmp	0x140081f85 <.text+0x80f85>
140081f68:     	leaq	0x4b0(%rbp), %rcx
140081f6f:     	movq	0x4e8(%rbp), %rdx
140081f76:     	movq	%rdi, %r8
140081f79:     	movq	0x5d0(%rbp), %r9
140081f80:     	callq	0x140024850 <.text+0x23850>
140081f85:     	movzbl	0x4b0(%rbp), %eax
140081f8c:     	movzwl	0x4b2(%rbp), %ecx
140081f93:     	movw	%cx, 0x566(%rbp)
140081f9a:     	cmpb	$-0x1, %al
140081f9c:     	jne	0x140082387 <.text+0x81387>
140081fa2:     	movq	%rdi, %rcx
140081fa5:     	callq	0x140092370 <.text+0x91370>
140081faa:     	testb	$0x1, %al
140081fac:     	je	0x140082285 <.text+0x81285>
140081fb2:     	movq	%rdx, %r15
140081fb5:     	movzbl	0x564(%rbp), %eax
140081fbc:     	movb	%al, %bl
140081fbe:     	shlq	$0x28, %rbx
140081fc2:     	shlq	$0x8, %r13
140081fc6:     	orq	%rbx, %r13
140081fc9:     	movzbl	0x4d0(%rbp), %eax
140081fd0:     	orq	%r13, %rax
140081fd3:     	movq	0x4f0(%rbp), %rbx
140081fda:     	movups	(%rbx), %xmm0
140081fdd:     	movups	0xc(%rbx), %xmm1
140081fe1:     	movups	%xmm1, 0x4bc(%rbp)
140081fe8:     	movaps	%xmm0, 0x4b0(%rbp)
140081fef:     	movq	$0x1, 0x518(%rbp)
140081ffa:     	movq	0x558(%rbp), %rcx
140082001:     	movq	%rcx, 0x520(%rbp)
140082008:     	movq	%rax, 0x528(%rbp)
14008200f:     	movb	$0x1, 0x530(%rbp)
140082016:     	movq	0x498(%rbp), %rcx
14008201d:     	movq	(%rcx), %rax
140082020:     	movq	0x7(%rcx), %rcx
140082024:     	movq	%rcx, 0x417(%rbp)
14008202b:     	movq	%rax, 0x410(%rbp)
140082032:     	leaq	0x410(%rbp), %rax
140082039:     	movq	%rax, 0x68(%rsp)
14008203e:     	movq	0x600(%rbp), %rax
140082045:     	movq	%rax, 0x60(%rsp)
14008204a:     	movq	0x5d8(%rbp), %rax
140082051:     	movq	%rax, 0x58(%rsp)
140082056:     	leaq	0x518(%rbp), %r13
14008205d:     	movq	%r13, 0x50(%rsp)
140082062:     	movq	%r14, 0x48(%rsp)
140082067:     	leaq	-0x10(%rbp), %rax
14008206b:     	movq	%rax, 0x40(%rsp)
140082070:     	movq	0x5e0(%rbp), %rax
140082077:     	movq	%rax, 0x38(%rsp)
14008207c:     	movq	0x490(%rbp), %rax
140082083:     	movq	%rax, 0x30(%rsp)
140082088:     	movzwl	0x566(%rbp), %eax
14008208f:     	movw	%ax, 0x28(%rsp)
140082094:     	movb	$0x1, 0x20(%rsp)
140082099:     	leaq	0x4f8(%rbp), %r14
1400820a0:     	movq	%r14, %rcx
1400820a3:     	movq	%rdi, %rdx
1400820a6:     	leaq	0x4b0(%rbp), %r8
1400820ad:     	movq	%r15, %r9
1400820b0:     	callq	0x14007ecd0 <.text+0x7dcd0>
1400820b5:     	cmpb	$-0x1, 0x4f8(%rbp)
1400820bc:     	jne	0x14008228d <.text+0x8128d>
1400820c2:     	movq	$0x0, 0x4f8(%rbp)
1400820cd:     	movq	%r14, 0x28(%rsp)
1400820d2:     	movq	%rbx, 0x20(%rsp)
1400820d7:     	movq	%r13, %rcx
1400820da:     	movq	%rdi, %rdx
1400820dd:     	movq	0x4e0(%rbp), %r8
1400820e4:     	movq	%r15, %r9
1400820e7:     	callq	0x1400be110 <.text+0xbd110>
1400820ec:     	cmpb	$-0x1, 0x518(%rbp)
1400820f3:     	jne	0x1400822b6 <.text+0x812b6>
1400820f9:     	cmpq	$-0x1, 0x230(%rdi)
140082101:     	movq	0x5f0(%rbp), %rbx
140082108:     	je	0x1400821a5 <.text+0x811a5>
14008210e:     	cmpq	0x258(%rdi), %rbx
140082115:     	jae	0x1400821a5 <.text+0x811a5>
14008211b:     	movq	0x250(%rdi), %rax
140082122:     	cmpb	$0x1, (%rax,%rbx)
140082126:     	jne	0x1400821a5 <.text+0x811a5>
140082128:     	cmpq	0x240(%rdi), %rbx
14008212f:     	jae	0x1400821a5 <.text+0x811a5>
140082131:     	movq	0x238(%rdi), %rax
140082138:     	movq	0x548(%rbp), %rcx
14008213f:     	movq	(%rax,%rcx), %rdx
140082143:     	cmpq	$0x2, %rdx
140082147:     	je	0x1400821a5 <.text+0x811a5>
140082149:     	movq	0x548(%rbp), %rcx
140082150:     	addq	%rax, %rcx
140082153:     	cmpb	$0x7, 0x2ae(%rcx)
14008215a:     	sete	%r8b
14008215e:     	andb	%r8b, %dl
140082161:     	cmpb	$0x1, %dl
140082164:     	jne	0x1400821a5 <.text+0x811a5>
140082166:     	movq	0x548(%rbp), %r9
14008216d:     	cmpl	$0x2, 0x20(%rax,%r9)
140082173:     	movl	0x30(%rax,%r9), %edx
140082178:     	movl	$0x1, %r8d
14008217e:     	cmovnel	%r8d, %edx
140082182:     	movzwl	0x566(%rbp), %r8d
14008218a:     	cmovel	0x34(%rax,%r9), %r8d
140082190:     	movq	$0x1, (%rcx)
140082197:     	movl	%edx, 0x30(%rcx)
14008219a:     	movl	%r8d, 0x34(%rcx)
14008219e:     	movb	$0x7, 0x2ae(%rcx)
1400821a5:     	cmpq	0x558(%rbp), %r12
1400821ac:     	movq	0x4a0(%rbp), %r12
1400821b3:     	movq	0x4a8(%rbp), %rdx
1400821ba:     	movq	0x4d8(%rbp), %rax
1400821c1:     	jae	0x1400821d0 <.text+0x811d0>
1400821c3:     	cmpq	%rax, %rdx
1400821c6:     	leaq	0x4(%rax), %rax
1400821ca:     	jne	0x140081cef <.text+0x80cef>
1400821d0:     	movb	$-0x1, (%rsi)
1400821d3:     	jmp	0x1400821e0 <.text+0x811e0>
1400821d5:     	movb	$0xa, (%rsi)
1400821d8:     	movq	$0x3, 0x8(%rsi)
1400821e0:     	addq	$0x5e8, %rsp            # imm = 0x5E8
1400821e7:     	popq	%rbx
1400821e8:     	popq	%rdi
1400821e9:     	popq	%rsi
1400821ea:     	popq	%r12
1400821ec:     	popq	%r13
1400821ee:     	popq	%r14
1400821f0:     	popq	%r15
1400821f2:     	popq	%rbp
1400821f3:     	retq
1400821f4:     	movzwl	0x2e(%r11), %eax
1400821f9:     	shlq	$0x30, %rax
1400821fd:     	shlq	$0x28, %rdx
140082201:     	orq	%rax, %rdx
140082204:     	orq	%r15, %rdx
140082207:     	leaq	0x450(%rbp), %rcx
14008220e:     	movq	0x558(%rbp), %r8
140082215:     	callq	0x1400803f0 <.text+0x7f3f0>
14008221a:     	movq	0x450(%rbp), %rax
140082221:     	testq	%rax, %rax
140082224:     	je	0x140082329 <.text+0x81329>
14008222a:     	leaq	0x458(%rbp), %rax
140082231:     	movq	0x10(%rax), %rcx
140082235:     	movq	%rcx, 0x408(%rbp)
14008223c:     	movups	(%rax), %xmm0
14008223f:     	movups	%xmm0, 0x3f8(%rbp)
140082246:     	movq	0x400(%rbp), %rax
14008224d:     	movq	%rax, 0x10(%rsi)
140082251:     	movq	0x408(%rbp), %rax
140082258:     	movq	%rax, 0x18(%rsi)
14008225c:     	movups	0x3f1(%rbp), %xmm0
140082263:     	movups	%xmm0, 0x1(%rsi)
140082267:     	movb	$0xa, (%rsi)
14008226a:     	jmp	0x1400821e0 <.text+0x811e0>
14008226f:     	movabsq	$0x31100000000, %rax    # imm = 0x31100000000
140082279:     	movb	$0xa, (%rsi)
14008227c:     	movq	%rax, 0x4(%rsi)
140082280:     	jmp	0x1400821e0 <.text+0x811e0>
140082285:     	movb	$0x9, (%rsi)
140082288:     	jmp	0x1400821e0 <.text+0x811e0>
14008228d:     	movups	0x4f8(%rbp), %xmm0
140082294:     	movups	0x508(%rbp), %xmm1
14008229b:     	movups	%xmm1, 0x10(%rsi)
14008229f:     	movups	%xmm0, (%rsi)
1400822a2:     	addq	$0x60, %rdi
1400822a6:     	movq	%rdi, %rcx
1400822a9:     	movq	%r15, %rdx
1400822ac:     	callq	0x1400110e0 <.text+0x100e0>
1400822b1:     	jmp	0x1400821e0 <.text+0x811e0>
1400822b6:     	movups	0x518(%rbp), %xmm0
1400822bd:     	movups	0x528(%rbp), %xmm1
1400822c4:     	movups	%xmm1, 0x10(%rsi)
1400822c8:     	movups	%xmm0, (%rsi)
1400822cb:     	jmp	0x1400821e0 <.text+0x811e0>
1400822d0:     	movzbl	0x519(%rbp), %ecx
1400822d7:     	movzwl	0x51a(%rbp), %edx
1400822de:     	movups	0x528(%rbp), %xmm0
1400822e5:     	movups	%xmm0, 0x10(%rsi)
1400822e9:     	movups	0x51c(%rbp), %xmm0
1400822f0:     	movups	%xmm0, 0x4(%rsi)
1400822f4:     	movb	%al, (%rsi)
1400822f6:     	movb	%cl, 0x1(%rsi)
1400822f9:     	movw	%dx, 0x2(%rsi)
1400822fd:     	jmp	0x1400821e0 <.text+0x811e0>
140082302:     	movb	$0x7, 0x458(%rbp)
140082309:     	movq	$0x1, 0x450(%rbp)
140082314:     	movl	$0x1, %eax
140082319:     	movq	0x5f0(%rbp), %rbx
140082320:     	testq	%rax, %rax
140082323:     	jne	0x14008222a <.text+0x8122a>
140082329:     	movzbl	0x458(%rbp), %eax
140082330:     	movups	0x478(%rbp), %xmm0
140082337:     	movups	%xmm0, 0x440(%rbp)
14008233e:     	movups	0x459(%rbp), %xmm0
140082345:     	movups	%xmm0, 0x421(%rbp)
14008234c:     	movups	0x468(%rbp), %xmm0
140082353:     	movups	%xmm0, 0x430(%rbp)
14008235a:     	movb	%al, 0x420(%rbp)
140082360:     	movq	0x448(%rbp), %rdx
140082367:     	cmpq	$0xb, %rdx
14008236b:     	jb	0x14008194b <.text+0x8094b>
140082371:     	leaq	0x1cf798(%rip), %r9     # 0x140251b10
140082378:     	movl	$0xa, %r8d
14008237e:     	xorl	%ecx, %ecx
140082380:     	callq	0x140239ef0 <.text+0x238ef0>
140082385:     	ud2
140082387:     	movzbl	0x4b1(%rbp), %ecx
14008238e:     	movups	0x4c0(%rbp), %xmm0
140082395:     	movups	%xmm0, 0x10(%rsi)
140082399:     	movups	0x4b4(%rbp), %xmm0
1400823a0:     	movups	%xmm0, 0x4(%rsi)
1400823a4:     	movb	%al, (%rsi)
1400823a6:     	movb	%cl, 0x1(%rsi)
1400823a9:     	movzwl	0x566(%rbp), %eax
1400823b0:     	movw	%ax, 0x2(%rsi)
1400823b4:     	jmp	0x1400821e0 <.text+0x811e0>
1400823b9:     	leaq	0x1cf6f8(%rip), %rcx    # 0x140251ab8
1400823c0:     	leaq	0x1cf701(%rip), %r8     # 0x140251ac8
1400823c7:     	movl	$0xb, %edx
1400823cc:     	callq	0x140239c00 <.text+0x238c00>
1400823d1:     	ud2
1400823d3:     	leaq	0x1cf71e(%rip), %r9     # 0x140251af8
1400823da:     	movl	$0x400, %r8d            # imm = 0x400
1400823e0:     	xorl	%ecx, %ecx
1400823e2:     	movq	%r14, %rdx
1400823e5:     	callq	0x140239ef0 <.text+0x238ef0>
1400823ea:     	ud2
1400823ec:     	leaq	0x1d299d(%rip), %r9     # 0x140254d90
1400823f3:     	xorl	%ecx, %ecx
1400823f5:     	movq	0x558(%rbp), %rdx
1400823fc:     	movq	%rax, %r8
1400823ff:     	callq	0x140239ef0 <.text+0x238ef0>
140082404:     	ud2
140082406:     	leaq	0x1d2983(%rip), %r9     # 0x140254d90
14008240d:     	xorl	%ecx, %ecx
14008240f:     	movq	%rax, %rdx
140082412:     	callq	0x140239ef0 <.text+0x238ef0>
140082417:     	ud2
140082419:     	leaq	0x1cf6c0(%rip), %r9     # 0x140251ae0
140082420:     	movq	%r13, %rcx
140082423:     	movq	%r15, %rdx
140082426:     	movq	%rax, %r8
140082429:     	callq	0x140239ef0 <.text+0x238ef0>
14008242e:     	ud2
140082430:     	decq	%r14
140082433:     	leaq	0x1cf666(%rip), %r8     # 0x140251aa0
14008243a:     	movl	$0xa, %edx
14008243f:     	movq	%r14, %rcx
140082442:     	callq	0x140239ce3 <.text+0x238ce3>
140082447:     	ud2
140082449:     	movb	$0x1, 0x4f8(%rbp)
140082450:     	leaq	0x1d07b9(%rip), %rax    # 0x140252c10
140082457:     	movq	%rax, 0x20(%rsp)
14008245c:     	leaq	0x1d0795(%rip), %rcx    # 0x140252bf8
140082463:     	leaq	0x1d1ece(%rip), %r9     # 0x140254338
14008246a:     	leaq	0x4f8(%rbp), %r8
140082471:     	movl	$0x11, %edx
140082476:     	callq	0x140239c60 <.text+0x238c60>
14008247b:     	ud2

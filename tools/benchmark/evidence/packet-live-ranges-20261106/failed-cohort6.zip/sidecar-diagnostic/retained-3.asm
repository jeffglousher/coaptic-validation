
D:\CoapticCurrent\packet-lazy-staged-20261106\B\retained-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140046230:     	pushq	%rbp
140046231:     	pushq	%r15
140046233:     	pushq	%r14
140046235:     	pushq	%r13
140046237:     	pushq	%r12
140046239:     	pushq	%rsi
14004623a:     	pushq	%rdi
14004623b:     	pushq	%rbx
14004623c:     	subq	$0x5e8, %rsp            # imm = 0x5E8
140046243:     	leaq	0x80(%rsp), %rbp
14004624b:     	movq	%rdx, %rdi
14004624e:     	movq	0x5d8(%rbp), %r11
140046255:     	movzbl	0x2d(%r11), %edx
14004625a:     	cmpq	$0x2, %rdx
14004625e:     	je	0x140046dd9 <.text+0x45dd9>
140046264:     	movq	%rcx, %rsi
140046267:     	cmpq	$-0x1, 0x230(%rdi)
14004626f:     	je	0x140046bf5 <.text+0x45bf5>
140046275:     	movq	0x5f0(%rbp), %rbx
14004627c:     	cmpq	0x258(%rdi), %rbx
140046283:     	jae	0x140046bf5 <.text+0x45bf5>
140046289:     	movq	0x250(%rdi), %rax
140046290:     	cmpb	$0x1, (%rax,%rbx)
140046294:     	jne	0x140046bf5 <.text+0x45bf5>
14004629a:     	cmpq	0x240(%rdi), %rbx
1400462a1:     	jae	0x140046bf5 <.text+0x45bf5>
1400462a7:     	movq	0x238(%rdi), %rcx
1400462ae:     	imulq	$0x2d0, %rbx, %r10      # imm = 0x2D0
1400462b5:     	movq	0x2c0(%rcx,%r10), %rax
1400462bd:     	movq	%r10, 0x548(%rbp)
1400462c4:     	movq	0x2c8(%rcx,%r10), %rcx
1400462cc:     	movq	%rcx, 0x558(%rbp)
1400462d3:     	cmpq	%rax, %rcx
1400462d6:     	ja	0x140046e0c <.text+0x45e0c>
1400462dc:     	movl	0x28(%r11), %eax
1400462e0:     	movzbl	0x2c(%r11), %r15d
1400462e5:     	shlq	$0x20, %r15
1400462e9:     	orq	%rax, %r15
1400462ec:     	movq	%r15, %r14
1400462ef:     	shrq	$0x20, %r14
1400462f3:     	movl	%r14d, %ecx
1400462f6:     	andb	$0xf, %cl
1400462f9:     	movl	$0x10, %r10d
1400462ff:     	shll	%cl, %r10d
140046302:     	movq	0x5f8(%rbp), %rax
140046309:     	movq	%r14, 0x488(%rbp)
140046310:     	cmpq	$0x7, %r14
140046314:     	movzwl	%r10w, %ecx
140046318:     	movl	$0x400, %r12d           # imm = 0x400
14004631e:     	cmovneq	%rcx, %r12
140046322:     	cmpb	$0x0, (%rax)
140046325:     	movq	%r9, 0x4e8(%rbp)
14004632c:     	movq	%r8, 0x4e0(%rbp)
140046333:     	je	0x140046446 <.text+0x45446>
140046339:     	movups	0x8(%rax), %xmm0
14004633d:     	movups	0x18(%rax), %xmm1
140046341:     	movups	0x28(%rax), %xmm2
140046345:     	movaps	%xmm2, 0x440(%rbp)
14004634c:     	movaps	%xmm1, 0x430(%rbp)
140046353:     	movaps	%xmm0, 0x420(%rbp)
14004635a:     	movq	0x448(%rbp), %rdx
140046361:     	cmpq	$0xb, %rdx
140046365:     	jae	0x140046d91 <.text+0x45d91>
14004636b:     	testq	%rdx, %rdx
14004636e:     	je	0x140046bf0 <.text+0x45bf0>
140046374:     	shrq	$0x23, %r15
140046378:     	je	0x1400466ba <.text+0x456ba>
14004637e:     	movl	0x420(%rbp), %r13d
140046385:     	imulq	%r12, %r13
140046389:     	addq	%r13, %r12
14004638c:     	movq	0x558(%rbp), %rax
140046393:     	cmpq	%r12, %rax
140046396:     	movq	%r12, %r15
140046399:     	cmovbq	%rax, %r15
14004639d:     	leaq	-0x10(%rbp), %rcx
1400463a1:     	movl	$0x400, %r8d            # imm = 0x400
1400463a7:     	xorl	%edx, %edx
1400463a9:     	callq	0x140138f22 <.text+0x137f22>
1400463ae:     	movq	%r15, %r14
1400463b1:     	subq	%r13, %r14
1400463b4:     	cmpq	$0x400, %r14            # imm = 0x400
1400463bb:     	ja	0x140046df3 <.text+0x45df3>
1400463c1:     	cmpq	$-0x1, 0x230(%rdi)
1400463c9:     	je	0x140046bf5 <.text+0x45bf5>
1400463cf:     	cmpq	0x258(%rdi), %rbx
1400463d6:     	jae	0x140046bf5 <.text+0x45bf5>
1400463dc:     	movq	0x250(%rdi), %rax
1400463e3:     	cmpb	$0x1, (%rax,%rbx)
1400463e7:     	jne	0x140046bf5 <.text+0x45bf5>
1400463ed:     	cmpq	0x240(%rdi), %rbx
1400463f4:     	jae	0x140046bf5 <.text+0x45bf5>
1400463fa:     	movq	0x238(%rdi), %rax
140046401:     	movq	0x548(%rbp), %rcx
140046408:     	movq	0x2c0(%rax,%rcx), %r8
140046410:     	movq	0x2c8(%rax,%rcx), %rax
140046418:     	cmpq	%r8, %rax
14004641b:     	ja	0x140046e26 <.text+0x45e26>
140046421:     	cmpq	%r13, 0x558(%rbp)
140046428:     	jb	0x140046e39 <.text+0x45e39>
14004642e:     	cmpq	%rax, %r15
140046431:     	ja	0x140046e39 <.text+0x45e39>
140046437:     	movabsq	$0x21100000000, %rax    # imm = 0x21100000000
140046441:     	jmp	0x140046c99 <.text+0x45c99>
140046446:     	movq	0x30(%r11), %rax
14004644a:     	testq	%rax, %rax
14004644d:     	je	0x140046c14 <.text+0x45c14>
140046453:     	movups	(%rax), %xmm0
140046456:     	xorps	%xmm1, %xmm1
140046459:     	movaps	%xmm1, 0x10(%rbp)
14004645d:     	movaps	%xmm1, (%rbp)
140046461:     	movaps	%xmm1, -0x10(%rbp)
140046465:     	movups	%xmm0, 0x518(%rbp)
14004646c:     	movq	$0x0, 0x528(%rbp)
140046477:     	leaq	0x530(%rbp), %rbx
14004647e:     	movl	$0x0, 0x530(%rbp)
140046488:     	movw	$0x1f, 0x538(%rbp)
140046491:     	xorl	%r14d, %r14d
140046494:     	leaq	0x4f8(%rbp), %r13
14004649b:     	nopl	(%rax,%rax)
1400464a0:     	movq	0x520(%rbp), %r8
1400464a7:     	cmpq	%r8, 0x528(%rbp)
1400464ae:     	jae	0x140046677 <.text+0x45677>
1400464b4:     	movq	0x518(%rbp), %rdx
1400464bb:     	movq	%rbx, 0x20(%rsp)
1400464c0:     	movq	%r13, %rcx
1400464c3:     	leaq	0x528(%rbp), %r9
1400464ca:     	callq	0x14000cc50 <.text+0xbc50>
1400464cf:     	movq	0x4f8(%rbp), %rax
1400464d6:     	testq	%rax, %rax
1400464d9:     	je	0x140046677 <.text+0x45677>
1400464df:     	movzwl	0x538(%rbp), %ecx
1400464e6:     	cmpw	%cx, 0x508(%rbp)
1400464ed:     	je	0x1400464f6 <.text+0x454f6>
1400464ef:     	jbe	0x1400464a0 <.text+0x454a0>
1400464f1:     	jmp	0x140046677 <.text+0x45677>
1400464f6:     	movq	0x500(%rbp), %rdx
1400464fd:     	cmpq	$0x3, %rdx
140046501:     	ja	0x140046e69 <.text+0x45e69>
140046507:     	testq	%rdx, %rdx
14004650a:     	je	0x14004653d <.text+0x4553d>
14004650c:     	movzbl	(%rax), %ecx
14004650f:     	cmpq	$0x1, %rdx
140046513:     	je	0x140046532 <.text+0x45532>
140046515:     	movl	%ecx, %r8d
140046518:     	shll	$0x8, %r8d
14004651c:     	movzbl	0x1(%rax), %ecx
140046520:     	orl	%r8d, %ecx
140046523:     	cmpq	$0x2, %rdx
140046527:     	je	0x140046532 <.text+0x45532>
140046529:     	shll	$0x8, %ecx
14004652c:     	movzbl	0x2(%rax), %eax
140046530:     	orl	%eax, %ecx
140046532:     	movl	%ecx, %eax
140046534:     	movq	%rax, %r8
140046537:     	shlq	$0x20, %r8
14004653b:     	jmp	0x140046545 <.text+0x45545>
14004653d:     	movl	$0x100, %r8d            # imm = 0x100
140046543:     	xorl	%eax, %eax
140046545:     	andb	$0x7, %al
140046547:     	movq	%r8, %rcx
14004654a:     	shrq	$0x24, %rcx
14004654e:     	movl	%ecx, 0x4f8(%rbp)
140046554:     	movb	%al, 0x4fc(%rbp)
14004655a:     	movl	0x4f9(%rbp), %edx
140046560:     	movq	%rdx, %r9
140046563:     	shlq	$0x8, %r9
140046567:     	movzbl	%cl, %eax
14004656a:     	orq	%r9, %rax
14004656d:     	shrl	$0x18, %edx
140046570:     	movl	%edx, %ecx
140046572:     	andb	$0xf, %cl
140046575:     	movl	$0x10, %r9d
14004657b:     	shll	%cl, %r9d
14004657e:     	cmpl	$0x7, %edx
140046581:     	movzwl	%r9w, %ecx
140046585:     	movl	$0x400, %edx            # imm = 0x400
14004658a:     	cmoveq	%rdx, %rcx
14004658e:     	movl	%eax, %r9d
140046591:     	movq	%r9, %rdx
140046594:     	imulq	%rcx, %rdx
140046598:     	cmpq	0x558(%rbp), %rdx
14004659f:     	jb	0x1400465ae <.text+0x455ae>
1400465a1:     	orq	0x558(%rbp), %rdx
1400465a8:     	jne	0x140046d22 <.text+0x45d22>
1400465ae:     	movl	$0x1, %edx
1400465b3:     	btq	$0x23, %r8
1400465b8:     	jae	0x1400465d3 <.text+0x455d3>
1400465ba:     	movl	$0xcccccccd, %edx       # imm = 0xCCCCCCCD
1400465bf:     	imulq	%rdx, %r9
1400465c3:     	shrq	$0x23, %r9
1400465c7:     	addl	%r9d, %r9d
1400465ca:     	leal	(%r9,%r9,4), %edx
1400465ce:     	subl	%eax, %edx
1400465d0:     	addl	$0xa, %edx
1400465d3:     	testq	%r14, %r14
1400465d6:     	je	0x1400465f3 <.text+0x455f3>
1400465d8:     	cmpq	$0xa, %r14
1400465dc:     	ja	0x140046e50 <.text+0x45e50>
1400465e2:     	cmpl	%eax, -0x14(%rbp,%r14,4)
1400465e7:     	jae	0x140046603 <.text+0x45603>
1400465e9:     	cmpq	$0xa, %r14
1400465ed:     	je	0x140046d22 <.text+0x45d22>
1400465f3:     	movl	%eax, -0x10(%rbp,%r14,4)
1400465f8:     	movq	0x18(%rbp), %r14
1400465fc:     	incq	%r14
1400465ff:     	movq	%r14, 0x18(%rbp)
140046603:     	cmpl	$0x1, %edx
140046606:     	je	0x1400464a0 <.text+0x454a0>
14004660c:     	incl	%eax
14004660e:     	movq	%rcx, %r8
140046611:     	imulq	%rax, %r8
140046615:     	cmpq	0x558(%rbp), %r8
14004661c:     	jae	0x1400464a0 <.text+0x454a0>
140046622:     	addq	$-0x2, %rdx
140046626:     	testq	%r14, %r14
140046629:     	je	0x140046646 <.text+0x45646>
14004662b:     	cmpq	$0xb, %r14
14004662f:     	jae	0x140046e50 <.text+0x45e50>
140046635:     	cmpl	-0x14(%rbp,%r14,4), %eax
14004663a:     	jbe	0x140046656 <.text+0x45656>
14004663c:     	cmpq	$0xa, %r14
140046640:     	je	0x140046d22 <.text+0x45d22>
140046646:     	movl	%eax, -0x10(%rbp,%r14,4)
14004664b:     	movq	0x18(%rbp), %r14
14004664f:     	incq	%r14
140046652:     	movq	%r14, 0x18(%rbp)
140046656:     	subq	$0x1, %rdx
14004665a:     	jb	0x1400464a0 <.text+0x454a0>
140046660:     	incl	%eax
140046662:     	movq	%rcx, %r8
140046665:     	imulq	%rax, %r8
140046669:     	cmpq	0x558(%rbp), %r8
140046670:     	jb	0x140046626 <.text+0x45626>
140046672:     	jmp	0x1400464a0 <.text+0x454a0>
140046677:     	movaps	-0x10(%rbp), %xmm0
14004667b:     	movaps	(%rbp), %xmm1
14004667f:     	movaps	0x10(%rbp), %xmm2
140046683:     	movups	%xmm0, 0x458(%rbp)
14004668a:     	movups	%xmm1, 0x468(%rbp)
140046691:     	movups	%xmm2, 0x478(%rbp)
140046698:     	movq	$0x0, 0x450(%rbp)
1400466a3:     	xorl	%eax, %eax
1400466a5:     	movq	0x5f0(%rbp), %rbx
1400466ac:     	testq	%rax, %rax
1400466af:     	jne	0x140046c4a <.text+0x45c4a>
1400466b5:     	jmp	0x140046d49 <.text+0x45d49>
1400466ba:     	shlq	$0x2, %rdx
1400466be:     	movq	0x5d8(%rbp), %rax
1400466c5:     	leaq	0x38(%rax), %rcx
1400466c9:     	movq	%rcx, 0x4f0(%rbp)
1400466d0:     	leaq	0x66(%rax), %rcx
1400466d4:     	movq	%rcx, 0x490(%rbp)
1400466db:     	leaq	0x56(%rax), %rcx
1400466df:     	movq	%rcx, 0x498(%rbp)
1400466e6:     	movzwl	0x54(%rax), %ecx
1400466ea:     	movw	%cx, 0x556(%rbp)
1400466f1:     	movzbl	0x70(%rax), %eax
1400466f5:     	movb	%al, 0x565(%rbp)
1400466fb:     	addq	$-0x4, %rdx
1400466ff:     	xorl	%eax, %eax
140046701:     	movq	%r12, 0x4a0(%rbp)
140046708:     	movq	%rdx, 0x4a8(%rbp)
14004670f:     	movl	0x420(%rbp,%rax), %ecx
140046716:     	movq	%r12, %r13
140046719:     	imulq	%rcx, %r13
14004671d:     	testq	%rax, %rax
140046720:     	je	0x14004672f <.text+0x4572f>
140046722:     	cmpq	0x558(%rbp), %r13
140046729:     	jae	0x140046bf0 <.text+0x45bf0>
14004672f:     	movq	%rcx, 0x4d0(%rbp)
140046736:     	movq	%rax, 0x4d8(%rbp)
14004673d:     	addq	%r13, %r12
140046740:     	movq	0x558(%rbp), %rax
140046747:     	cmpq	%r12, %rax
14004674a:     	movq	%r12, %r15
14004674d:     	cmovbq	%rax, %r15
140046751:     	movl	$0x400, %r8d            # imm = 0x400
140046757:     	leaq	-0x10(%rbp), %rcx
14004675b:     	xorl	%edx, %edx
14004675d:     	callq	0x140138f22 <.text+0x137f22>
140046762:     	movq	%r15, %r14
140046765:     	subq	%r13, %r14
140046768:     	cmpq	$0x401, %r14            # imm = 0x401
14004676f:     	jae	0x140046df3 <.text+0x45df3>
140046775:     	cmpq	$-0x1, 0x230(%rdi)
14004677d:     	je	0x140046bf5 <.text+0x45bf5>
140046783:     	cmpq	0x258(%rdi), %rbx
14004678a:     	jae	0x140046bf5 <.text+0x45bf5>
140046790:     	movq	0x250(%rdi), %rax
140046797:     	cmpb	$0x1, (%rax,%rbx)
14004679b:     	jne	0x140046bf5 <.text+0x45bf5>
1400467a1:     	cmpq	0x240(%rdi), %rbx
1400467a8:     	jae	0x140046bf5 <.text+0x45bf5>
1400467ae:     	movq	0x238(%rdi), %rcx
1400467b5:     	movq	0x548(%rbp), %rax
1400467bc:     	movq	0x2c0(%rcx,%rax), %r8
1400467c4:     	movq	0x2c8(%rcx,%rax), %rax
1400467cc:     	cmpq	%r8, %rax
1400467cf:     	ja	0x140046e26 <.text+0x45e26>
1400467d5:     	cmpq	%r13, 0x558(%rbp)
1400467dc:     	jb	0x140046e39 <.text+0x45e39>
1400467e2:     	cmpq	%rax, %r15
1400467e5:     	ja	0x140046e39 <.text+0x45e39>
1400467eb:     	addq	0x548(%rbp), %rcx
1400467f2:     	addq	0x2b8(%rcx), %r13
1400467f9:     	leaq	-0x10(%rbp), %rcx
1400467fd:     	movq	%r13, %rdx
140046800:     	movq	%r14, %r8
140046803:     	callq	0x140138f10 <.text+0x137f10>
140046808:     	movq	0x4d0(%rbp), %rax
14004680f:     	cmpl	$0xfffff, %eax          # imm = 0xFFFFF
140046814:     	ja	0x140046c8f <.text+0x45c8f>
14004681a:     	xorl	%ebx, %ebx
14004681c:     	cmpq	0x558(%rbp), %r12
140046823:     	setb	%r15b
140046827:     	movl	%eax, 0x518(%rbp)
14004682d:     	movq	0x488(%rbp), %rax
140046834:     	movb	%al, 0x51c(%rbp)
14004683a:     	movl	0x519(%rbp), %r13d
140046841:     	cmpq	$0x0, 0x4d8(%rbp)
140046849:     	movb	%r15b, 0x564(%rbp)
140046850:     	je	0x140046891 <.text+0x45891>
140046852:     	leaq	0x518(%rbp), %rcx
140046859:     	movq	0x4e8(%rbp), %rdx
140046860:     	movq	%rdi, %r8
140046863:     	movq	0x5d0(%rbp), %r9
14004686a:     	callq	0x1400167a0 <.text+0x157a0>
14004686f:     	movzbl	0x518(%rbp), %eax
140046876:     	cmpb	$-0x1, %al
140046878:     	jne	0x140046cf0 <.text+0x45cf0>
14004687e:     	movzwl	0x51a(%rbp), %eax
140046885:     	movw	%ax, 0x566(%rbp)
14004688c:     	jmp	0x1400469c2 <.text+0x459c2>
140046891:     	movzwl	0x556(%rbp), %eax
140046898:     	movw	%ax, 0x566(%rbp)
14004689f:     	cmpb	$0x2, 0x5e8(%rbp)
1400468a6:     	movq	0x5d0(%rbp), %r9
1400468ad:     	jne	0x1400469c2 <.text+0x459c2>
1400468b3:     	movq	0x608(%rbp), %rax
1400468ba:     	movq	%rax, 0x28(%rsp)
1400468bf:     	movzbl	0x565(%rbp), %eax
1400468c6:     	movb	%al, 0x20(%rsp)
1400468ca:     	movq	%rdi, %rcx
1400468cd:     	movq	0x4f0(%rbp), %rdx
1400468d4:     	movzwl	0x556(%rbp), %r15d
1400468dc:     	movl	%r15d, %r8d
1400468df:     	callq	0x14004cfe0 <.text+0x4bfe0>
1400468e4:     	movb	$0x2, 0x544(%rbp)
1400468eb:     	movb	$0x0, 0x53a(%rbp)
1400468f2:     	movw	%r15w, 0x538(%rbp)
1400468fa:     	leaq	0x53b(%rbp), %rax
140046901:     	movb	$0x0, 0x8(%rax)
140046905:     	movq	$0x0, (%rax)
14004690c:     	movq	$0x8, 0x518(%rbp)
140046917:     	movq	$0x0, 0x520(%rbp)
140046922:     	movq	$0x1, 0x528(%rbp)
14004692d:     	movq	$0x0, 0x530(%rbp)
140046938:     	leaq	0x518(%rbp), %rax
14004693f:     	movq	%rax, 0x20(%rsp)
140046944:     	leaq	0x4f8(%rbp), %rcx
14004694b:     	movq	%rdi, %rdx
14004694e:     	movq	0x4e0(%rbp), %r8
140046955:     	movq	0x4f0(%rbp), %r9
14004695c:     	callq	0x14001d220 <.text+0x1c220>
140046961:     	cmpb	$-0x1, 0x4f8(%rbp)
140046968:     	je	0x140046988 <.text+0x45988>
14004696a:     	movups	0x4f8(%rbp), %xmm0
140046971:     	movups	0x508(%rbp), %xmm1
140046978:     	movaps	%xmm1, 0x4c0(%rbp)
14004697f:     	movaps	%xmm0, 0x4b0(%rbp)
140046986:     	jmp	0x1400469a5 <.text+0x459a5>
140046988:     	leaq	0x4b0(%rbp), %rcx
14004698f:     	movq	0x4e8(%rbp), %rdx
140046996:     	movq	%rdi, %r8
140046999:     	movq	0x5d0(%rbp), %r9
1400469a0:     	callq	0x1400167a0 <.text+0x157a0>
1400469a5:     	movzbl	0x4b0(%rbp), %eax
1400469ac:     	movzwl	0x4b2(%rbp), %ecx
1400469b3:     	movw	%cx, 0x566(%rbp)
1400469ba:     	cmpb	$-0x1, %al
1400469bc:     	jne	0x140046da7 <.text+0x45da7>
1400469c2:     	movq	%rdi, %rcx
1400469c5:     	callq	0x14004e2b0 <.text+0x4d2b0>
1400469ca:     	testb	$0x1, %al
1400469cc:     	je	0x140046ca5 <.text+0x45ca5>
1400469d2:     	movq	%rdx, %r15
1400469d5:     	movzbl	0x564(%rbp), %eax
1400469dc:     	movb	%al, %bl
1400469de:     	shlq	$0x28, %rbx
1400469e2:     	shlq	$0x8, %r13
1400469e6:     	orq	%rbx, %r13
1400469e9:     	movzbl	0x4d0(%rbp), %eax
1400469f0:     	orq	%r13, %rax
1400469f3:     	movq	0x4f0(%rbp), %rbx
1400469fa:     	movups	(%rbx), %xmm0
1400469fd:     	movups	0xc(%rbx), %xmm1
140046a01:     	movups	%xmm1, 0x4bc(%rbp)
140046a08:     	movaps	%xmm0, 0x4b0(%rbp)
140046a0f:     	movq	$0x1, 0x518(%rbp)
140046a1a:     	movq	0x558(%rbp), %rcx
140046a21:     	movq	%rcx, 0x520(%rbp)
140046a28:     	movq	%rax, 0x528(%rbp)
140046a2f:     	movb	$0x1, 0x530(%rbp)
140046a36:     	movq	0x498(%rbp), %rcx
140046a3d:     	movq	(%rcx), %rax
140046a40:     	movq	0x7(%rcx), %rcx
140046a44:     	movq	%rcx, 0x417(%rbp)
140046a4b:     	movq	%rax, 0x410(%rbp)
140046a52:     	leaq	0x410(%rbp), %rax
140046a59:     	movq	%rax, 0x68(%rsp)
140046a5e:     	movq	0x600(%rbp), %rax
140046a65:     	movq	%rax, 0x60(%rsp)
140046a6a:     	movq	0x5d8(%rbp), %rax
140046a71:     	movq	%rax, 0x58(%rsp)
140046a76:     	leaq	0x518(%rbp), %r13
140046a7d:     	movq	%r13, 0x50(%rsp)
140046a82:     	movq	%r14, 0x48(%rsp)
140046a87:     	leaq	-0x10(%rbp), %rax
140046a8b:     	movq	%rax, 0x40(%rsp)
140046a90:     	movq	0x5e0(%rbp), %rax
140046a97:     	movq	%rax, 0x38(%rsp)
140046a9c:     	movq	0x490(%rbp), %rax
140046aa3:     	movq	%rax, 0x30(%rsp)
140046aa8:     	movzwl	0x566(%rbp), %eax
140046aaf:     	movw	%ax, 0x28(%rsp)
140046ab4:     	movb	$0x1, 0x20(%rsp)
140046ab9:     	leaq	0x4f8(%rbp), %r14
140046ac0:     	movq	%r14, %rcx
140046ac3:     	movq	%rdi, %rdx
140046ac6:     	leaq	0x4b0(%rbp), %r8
140046acd:     	movq	%r15, %r9
140046ad0:     	callq	0x1400436f0 <.text+0x426f0>
140046ad5:     	cmpb	$-0x1, 0x4f8(%rbp)
140046adc:     	jne	0x140046cad <.text+0x45cad>
140046ae2:     	movq	$0x0, 0x4f8(%rbp)
140046aed:     	movq	%r14, 0x28(%rsp)
140046af2:     	movq	%rbx, 0x20(%rsp)
140046af7:     	movq	%r13, %rcx
140046afa:     	movq	%rdi, %rdx
140046afd:     	movq	0x4e0(%rbp), %r8
140046b04:     	movq	%r15, %r9
140046b07:     	callq	0x140065930 <.text+0x64930>
140046b0c:     	cmpb	$-0x1, 0x518(%rbp)
140046b13:     	jne	0x140046cd6 <.text+0x45cd6>
140046b19:     	cmpq	$-0x1, 0x230(%rdi)
140046b21:     	movq	0x5f0(%rbp), %rbx
140046b28:     	je	0x140046bc5 <.text+0x45bc5>
140046b2e:     	cmpq	0x258(%rdi), %rbx
140046b35:     	jae	0x140046bc5 <.text+0x45bc5>
140046b3b:     	movq	0x250(%rdi), %rax
140046b42:     	cmpb	$0x1, (%rax,%rbx)
140046b46:     	jne	0x140046bc5 <.text+0x45bc5>
140046b48:     	cmpq	0x240(%rdi), %rbx
140046b4f:     	jae	0x140046bc5 <.text+0x45bc5>
140046b51:     	movq	0x238(%rdi), %rax
140046b58:     	movq	0x548(%rbp), %rcx
140046b5f:     	movq	(%rax,%rcx), %rdx
140046b63:     	cmpq	$0x2, %rdx
140046b67:     	je	0x140046bc5 <.text+0x45bc5>
140046b69:     	movq	0x548(%rbp), %rcx
140046b70:     	addq	%rax, %rcx
140046b73:     	cmpb	$0x7, 0x2ae(%rcx)
140046b7a:     	sete	%r8b
140046b7e:     	andb	%r8b, %dl
140046b81:     	cmpb	$0x1, %dl
140046b84:     	jne	0x140046bc5 <.text+0x45bc5>
140046b86:     	movq	0x548(%rbp), %r9
140046b8d:     	cmpl	$0x2, 0x20(%rax,%r9)
140046b93:     	movl	0x30(%rax,%r9), %edx
140046b98:     	movl	$0x1, %r8d
140046b9e:     	cmovnel	%r8d, %edx
140046ba2:     	movzwl	0x566(%rbp), %r8d
140046baa:     	cmovel	0x34(%rax,%r9), %r8d
140046bb0:     	movq	$0x1, (%rcx)
140046bb7:     	movl	%edx, 0x30(%rcx)
140046bba:     	movl	%r8d, 0x34(%rcx)
140046bbe:     	movb	$0x7, 0x2ae(%rcx)
140046bc5:     	cmpq	0x558(%rbp), %r12
140046bcc:     	movq	0x4a0(%rbp), %r12
140046bd3:     	movq	0x4a8(%rbp), %rdx
140046bda:     	movq	0x4d8(%rbp), %rax
140046be1:     	jae	0x140046bf0 <.text+0x45bf0>
140046be3:     	cmpq	%rax, %rdx
140046be6:     	leaq	0x4(%rax), %rax
140046bea:     	jne	0x14004670f <.text+0x4570f>
140046bf0:     	movb	$-0x1, (%rsi)
140046bf3:     	jmp	0x140046c00 <.text+0x45c00>
140046bf5:     	movb	$0xa, (%rsi)
140046bf8:     	movq	$0x3, 0x8(%rsi)
140046c00:     	addq	$0x5e8, %rsp            # imm = 0x5E8
140046c07:     	popq	%rbx
140046c08:     	popq	%rdi
140046c09:     	popq	%rsi
140046c0a:     	popq	%r12
140046c0c:     	popq	%r13
140046c0e:     	popq	%r14
140046c10:     	popq	%r15
140046c12:     	popq	%rbp
140046c13:     	retq
140046c14:     	movzwl	0x2e(%r11), %eax
140046c19:     	shlq	$0x30, %rax
140046c1d:     	shlq	$0x28, %rdx
140046c21:     	orq	%rax, %rdx
140046c24:     	orq	%r15, %rdx
140046c27:     	leaq	0x450(%rbp), %rcx
140046c2e:     	movq	0x558(%rbp), %r8
140046c35:     	callq	0x140044e10 <.text+0x43e10>
140046c3a:     	movq	0x450(%rbp), %rax
140046c41:     	testq	%rax, %rax
140046c44:     	je	0x140046d49 <.text+0x45d49>
140046c4a:     	leaq	0x458(%rbp), %rax
140046c51:     	movq	0x10(%rax), %rcx
140046c55:     	movq	%rcx, 0x408(%rbp)
140046c5c:     	movups	(%rax), %xmm0
140046c5f:     	movups	%xmm0, 0x3f8(%rbp)
140046c66:     	movq	0x400(%rbp), %rax
140046c6d:     	movq	%rax, 0x10(%rsi)
140046c71:     	movq	0x408(%rbp), %rax
140046c78:     	movq	%rax, 0x18(%rsi)
140046c7c:     	movups	0x3f1(%rbp), %xmm0
140046c83:     	movups	%xmm0, 0x1(%rsi)
140046c87:     	movb	$0xa, (%rsi)
140046c8a:     	jmp	0x140046c00 <.text+0x45c00>
140046c8f:     	movabsq	$0x31100000000, %rax    # imm = 0x31100000000
140046c99:     	movb	$0xa, (%rsi)
140046c9c:     	movq	%rax, 0x4(%rsi)
140046ca0:     	jmp	0x140046c00 <.text+0x45c00>
140046ca5:     	movb	$0x9, (%rsi)
140046ca8:     	jmp	0x140046c00 <.text+0x45c00>
140046cad:     	movups	0x4f8(%rbp), %xmm0
140046cb4:     	movups	0x508(%rbp), %xmm1
140046cbb:     	movups	%xmm1, 0x10(%rsi)
140046cbf:     	movups	%xmm0, (%rsi)
140046cc2:     	addq	$0x60, %rdi
140046cc6:     	movq	%rdi, %rcx
140046cc9:     	movq	%r15, %rdx
140046ccc:     	callq	0x14000ec90 <.text+0xdc90>
140046cd1:     	jmp	0x140046c00 <.text+0x45c00>
140046cd6:     	movups	0x518(%rbp), %xmm0
140046cdd:     	movups	0x528(%rbp), %xmm1
140046ce4:     	movups	%xmm1, 0x10(%rsi)
140046ce8:     	movups	%xmm0, (%rsi)
140046ceb:     	jmp	0x140046c00 <.text+0x45c00>
140046cf0:     	movzbl	0x519(%rbp), %ecx
140046cf7:     	movzwl	0x51a(%rbp), %edx
140046cfe:     	movups	0x528(%rbp), %xmm0
140046d05:     	movups	%xmm0, 0x10(%rsi)
140046d09:     	movups	0x51c(%rbp), %xmm0
140046d10:     	movups	%xmm0, 0x4(%rsi)
140046d14:     	movb	%al, (%rsi)
140046d16:     	movb	%cl, 0x1(%rsi)
140046d19:     	movw	%dx, 0x2(%rsi)
140046d1d:     	jmp	0x140046c00 <.text+0x45c00>
140046d22:     	movb	$0x7, 0x458(%rbp)
140046d29:     	movq	$0x1, 0x450(%rbp)
140046d34:     	movl	$0x1, %eax
140046d39:     	movq	0x5f0(%rbp), %rbx
140046d40:     	testq	%rax, %rax
140046d43:     	jne	0x140046c4a <.text+0x45c4a>
140046d49:     	movzbl	0x458(%rbp), %eax
140046d50:     	movups	0x478(%rbp), %xmm0
140046d57:     	movups	%xmm0, 0x440(%rbp)
140046d5e:     	movups	0x459(%rbp), %xmm0
140046d65:     	movups	%xmm0, 0x421(%rbp)
140046d6c:     	movups	0x468(%rbp), %xmm0
140046d73:     	movups	%xmm0, 0x430(%rbp)
140046d7a:     	movb	%al, 0x420(%rbp)
140046d80:     	movq	0x448(%rbp), %rdx
140046d87:     	cmpq	$0xb, %rdx
140046d8b:     	jb	0x14004636b <.text+0x4536b>
140046d91:     	leaq	0x102350(%rip), %r9     # 0x1401490e8
140046d98:     	movl	$0xa, %r8d
140046d9e:     	xorl	%ecx, %ecx
140046da0:     	callq	0x1401399d0 <.text+0x1389d0>
140046da5:     	ud2
140046da7:     	movzbl	0x4b1(%rbp), %ecx
140046dae:     	movups	0x4c0(%rbp), %xmm0
140046db5:     	movups	%xmm0, 0x10(%rsi)
140046db9:     	movups	0x4b4(%rbp), %xmm0
140046dc0:     	movups	%xmm0, 0x4(%rsi)
140046dc4:     	movb	%al, (%rsi)
140046dc6:     	movb	%cl, 0x1(%rsi)
140046dc9:     	movzwl	0x566(%rbp), %eax
140046dd0:     	movw	%ax, 0x2(%rsi)
140046dd4:     	jmp	0x140046c00 <.text+0x45c00>
140046dd9:     	leaq	0x1022b0(%rip), %rcx    # 0x140149090
140046de0:     	leaq	0x1022b9(%rip), %r8     # 0x1401490a0
140046de7:     	movl	$0xb, %edx
140046dec:     	callq	0x1401396e0 <.text+0x1386e0>
140046df1:     	ud2
140046df3:     	leaq	0x1022d6(%rip), %r9     # 0x1401490d0
140046dfa:     	movl	$0x400, %r8d            # imm = 0x400
140046e00:     	xorl	%ecx, %ecx
140046e02:     	movq	%r14, %rdx
140046e05:     	callq	0x1401399d0 <.text+0x1389d0>
140046e0a:     	ud2
140046e0c:     	leaq	0x103d85(%rip), %r9     # 0x14014ab98
140046e13:     	xorl	%ecx, %ecx
140046e15:     	movq	0x558(%rbp), %rdx
140046e1c:     	movq	%rax, %r8
140046e1f:     	callq	0x1401399d0 <.text+0x1389d0>
140046e24:     	ud2
140046e26:     	leaq	0x103d6b(%rip), %r9     # 0x14014ab98
140046e2d:     	xorl	%ecx, %ecx
140046e2f:     	movq	%rax, %rdx
140046e32:     	callq	0x1401399d0 <.text+0x1389d0>
140046e37:     	ud2
140046e39:     	leaq	0x102278(%rip), %r9     # 0x1401490b8
140046e40:     	movq	%r13, %rcx
140046e43:     	movq	%r15, %rdx
140046e46:     	movq	%rax, %r8
140046e49:     	callq	0x1401399d0 <.text+0x1389d0>
140046e4e:     	ud2
140046e50:     	decq	%r14
140046e53:     	leaq	0x10221e(%rip), %r8     # 0x140149078
140046e5a:     	movl	$0xa, %edx
140046e5f:     	movq	%r14, %rcx
140046e62:     	callq	0x1401397c3 <.text+0x1387c3>
140046e67:     	ud2
140046e69:     	movb	$0x1, 0x4f8(%rbp)
140046e70:     	leaq	0x102c39(%rip), %rax    # 0x140149ab0
140046e77:     	movq	%rax, 0x20(%rsp)
140046e7c:     	leaq	0x102c15(%rip), %rcx    # 0x140149a98
140046e83:     	leaq	0x103606(%rip), %r9     # 0x14014a490
140046e8a:     	leaq	0x4f8(%rbp), %r8
140046e91:     	movl	$0x11, %edx
140046e96:     	callq	0x140139740 <.text+0x138740>
140046e9b:     	ud2

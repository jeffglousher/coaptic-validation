
D:\CoapticCurrent\packet-lazy-staged-20261106\B\retained-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400455e0:     	pushq	%rbp
1400455e1:     	pushq	%r15
1400455e3:     	pushq	%r14
1400455e5:     	pushq	%r13
1400455e7:     	pushq	%r12
1400455e9:     	pushq	%rsi
1400455ea:     	pushq	%rdi
1400455eb:     	pushq	%rbx
1400455ec:     	subq	$0x608, %rsp            # imm = 0x608
1400455f3:     	leaq	0x80(%rsp), %rbp
1400455fb:     	movq	%rdx, %rdi
1400455fe:     	movq	0x5f8(%rbp), %r12
140045605:     	movzbl	0x2d(%r12), %edx
14004560b:     	cmpq	$0x2, %rdx
14004560f:     	je	0x140046196 <.text+0x45196>
140045615:     	movq	%r9, %rbx
140045618:     	movq	0x610(%rbp), %r9
14004561f:     	cmpq	$0x1, %r9
140045623:     	ja	0x14004578e <.text+0x4478e>
140045629:     	cmpb	$0x1, 0x81b8(%rdi,%r9)
140045632:     	jne	0x14004578e <.text+0x4478e>
140045638:     	movq	0xe1c0(%rdi,%r9,8), %rax
140045640:     	cmpq	$0x3001, %rax           # imm = 0x3001
140045646:     	jae	0x14004617d <.text+0x4517d>
14004564c:     	movq	%r8, %r15
14004564f:     	movq	%rax, 0x570(%rbp)
140045656:     	movq	%rcx, %rsi
140045659:     	movl	0x28(%r12), %eax
14004565e:     	movzbl	0x2c(%r12), %r14d
140045664:     	shlq	$0x20, %r14
140045668:     	orq	%rax, %r14
14004566b:     	movq	%r14, %r10
14004566e:     	shrq	$0x20, %r10
140045672:     	movl	%r10d, %ecx
140045675:     	andb	$0xf, %cl
140045678:     	movl	$0x10, %r8d
14004567e:     	shll	%cl, %r8d
140045681:     	movq	0x618(%rbp), %rax
140045688:     	movq	%r10, 0x4a0(%rbp)
14004568f:     	cmpq	$0x7, %r10
140045693:     	movzwl	%r8w, %ecx
140045697:     	movl	$0x400, %r13d           # imm = 0x400
14004569d:     	cmovneq	%rcx, %r13
1400456a1:     	cmpb	$0x0, (%rax)
1400456a4:     	je	0x1400457ad <.text+0x447ad>
1400456aa:     	movups	0x8(%rax), %xmm0
1400456ae:     	movups	0x18(%rax), %xmm1
1400456b2:     	movups	0x28(%rax), %xmm2
1400456b6:     	movaps	%xmm2, 0x490(%rbp)
1400456bd:     	movaps	%xmm1, 0x480(%rbp)
1400456c4:     	movaps	%xmm0, 0x470(%rbp)
1400456cb:     	movq	0x498(%rbp), %rdx
1400456d2:     	cmpq	$0xb, %rdx
1400456d6:     	jae	0x140046013 <.text+0x45013>
1400456dc:     	movq	%rbx, 0x4f8(%rbp)
1400456e3:     	movq	%rsi, 0x578(%rbp)
1400456ea:     	testq	%rdx, %rdx
1400456ed:     	movq	0x570(%rbp), %rsi
1400456f4:     	je	0x140045f7e <.text+0x44f7e>
1400456fa:     	shrq	$0x23, %r14
1400456fe:     	je	0x140045a84 <.text+0x44a84>
140045704:     	movl	0x470(%rbp), %r14d
14004570b:     	imulq	%r13, %r14
14004570f:     	addq	%r14, %r13
140045712:     	cmpq	%r13, %rsi
140045715:     	cmovbq	%rsi, %r13
140045719:     	leaq	-0x10(%rbp), %rcx
14004571d:     	movl	$0x400, %r8d            # imm = 0x400
140045723:     	xorl	%edx, %edx
140045725:     	callq	0x140138f22 <.text+0x137f22>
14004572a:     	movq	%r13, %r15
14004572d:     	subq	%r14, %r15
140045730:     	cmpq	$0x400, %r15            # imm = 0x400
140045737:     	ja	0x1400461b0 <.text+0x451b0>
14004573d:     	movq	0x610(%rbp), %rax
140045744:     	cmpb	$0x1, 0x81b8(%rdi,%rax)
14004574c:     	jne	0x140046029 <.text+0x45029>
140045752:     	movq	0xe1c0(%rdi,%rax,8), %rax
14004575a:     	cmpq	$0x3000, %rax           # imm = 0x3000
140045760:     	ja	0x14004617d <.text+0x4517d>
140045766:     	cmpq	%r14, %rsi
140045769:     	jb	0x1400461c9 <.text+0x451c9>
14004576f:     	cmpq	%rax, %r13
140045772:     	movq	0x578(%rbp), %rcx
140045779:     	ja	0x1400461c9 <.text+0x451c9>
14004577f:     	movabsq	$0x21100000000, %rax    # imm = 0x21100000000
140045789:     	jmp	0x140046051 <.text+0x45051>
14004578e:     	movb	$0xa, (%rcx)
140045791:     	movq	$0x3, 0x8(%rcx)
140045799:     	addq	$0x608, %rsp            # imm = 0x608
1400457a0:     	popq	%rbx
1400457a1:     	popq	%rdi
1400457a2:     	popq	%rsi
1400457a3:     	popq	%r12
1400457a5:     	popq	%r13
1400457a7:     	popq	%r14
1400457a9:     	popq	%r15
1400457ab:     	popq	%rbp
1400457ac:     	retq
1400457ad:     	movq	0x30(%r12), %rax
1400457b2:     	testq	%rax, %rax
1400457b5:     	je	0x140045f8d <.text+0x44f8d>
1400457bb:     	movq	%r13, 0x530(%rbp)
1400457c2:     	movq	%r15, 0x538(%rbp)
1400457c9:     	movups	(%rax), %xmm0
1400457cc:     	xorps	%xmm1, %xmm1
1400457cf:     	movaps	%xmm1, 0x10(%rbp)
1400457d3:     	movaps	%xmm1, (%rbp)
1400457d7:     	movaps	%xmm1, -0x10(%rbp)
1400457db:     	movups	%xmm0, 0x540(%rbp)
1400457e2:     	movq	$0x0, 0x550(%rbp)
1400457ed:     	leaq	0x558(%rbp), %r15
1400457f4:     	movl	$0x0, 0x558(%rbp)
1400457fe:     	movw	$0x1f, 0x560(%rbp)
140045807:     	xorl	%r12d, %r12d
14004580a:     	leaq	0x510(%rbp), %r13
140045811:     	nopw	%cs:(%rax,%rax)
140045820:     	movq	0x548(%rbp), %r8
140045827:     	cmpq	%r8, 0x550(%rbp)
14004582e:     	jae	0x1400459fe <.text+0x449fe>
140045834:     	movq	0x540(%rbp), %rdx
14004583b:     	movq	%r15, 0x20(%rsp)
140045840:     	movq	%r13, %rcx
140045843:     	leaq	0x550(%rbp), %r9
14004584a:     	callq	0x14000cc50 <.text+0xbc50>
14004584f:     	movq	0x510(%rbp), %rax
140045856:     	testq	%rax, %rax
140045859:     	je	0x1400459fe <.text+0x449fe>
14004585f:     	movzwl	0x560(%rbp), %ecx
140045866:     	cmpw	%cx, 0x520(%rbp)
14004586d:     	je	0x140045876 <.text+0x44876>
14004586f:     	jbe	0x140045820 <.text+0x44820>
140045871:     	jmp	0x1400459fe <.text+0x449fe>
140045876:     	movq	0x518(%rbp), %rdx
14004587d:     	cmpq	$0x3, %rdx
140045881:     	ja	0x1400461f9 <.text+0x451f9>
140045887:     	testq	%rdx, %rdx
14004588a:     	je	0x1400458bd <.text+0x448bd>
14004588c:     	movzbl	(%rax), %ecx
14004588f:     	cmpq	$0x1, %rdx
140045893:     	je	0x1400458b2 <.text+0x448b2>
140045895:     	movl	%ecx, %r8d
140045898:     	shll	$0x8, %r8d
14004589c:     	movzbl	0x1(%rax), %ecx
1400458a0:     	orl	%r8d, %ecx
1400458a3:     	cmpq	$0x2, %rdx
1400458a7:     	je	0x1400458b2 <.text+0x448b2>
1400458a9:     	shll	$0x8, %ecx
1400458ac:     	movzbl	0x2(%rax), %eax
1400458b0:     	orl	%eax, %ecx
1400458b2:     	movl	%ecx, %eax
1400458b4:     	movq	%rax, %r8
1400458b7:     	shlq	$0x20, %r8
1400458bb:     	jmp	0x1400458c5 <.text+0x448c5>
1400458bd:     	movl	$0x100, %r8d            # imm = 0x100
1400458c3:     	xorl	%eax, %eax
1400458c5:     	andb	$0x7, %al
1400458c7:     	movq	%r8, %rcx
1400458ca:     	shrq	$0x24, %rcx
1400458ce:     	movl	%ecx, 0x510(%rbp)
1400458d4:     	movb	%al, 0x514(%rbp)
1400458da:     	movl	0x511(%rbp), %edx
1400458e0:     	movq	%rdx, %r9
1400458e3:     	shlq	$0x8, %r9
1400458e7:     	movzbl	%cl, %eax
1400458ea:     	orq	%r9, %rax
1400458ed:     	shrl	$0x18, %edx
1400458f0:     	movl	%edx, %ecx
1400458f2:     	andb	$0xf, %cl
1400458f5:     	movl	$0x10, %r9d
1400458fb:     	shll	%cl, %r9d
1400458fe:     	cmpl	$0x7, %edx
140045901:     	movzwl	%r9w, %ecx
140045905:     	movl	$0x400, %edx            # imm = 0x400
14004590a:     	cmoveq	%rdx, %rcx
14004590e:     	movl	%eax, %r9d
140045911:     	movq	%r9, %rdx
140045914:     	imulq	%rcx, %rdx
140045918:     	movq	0x570(%rbp), %r11
14004591f:     	cmpq	%r11, %rdx
140045922:     	setb	%r10b
140045926:     	orq	%r11, %rdx
140045929:     	sete	%dl
14004592c:     	orb	%r10b, %dl
14004592f:     	je	0x140046133 <.text+0x45133>
140045935:     	movl	$0x1, %edx
14004593a:     	btq	$0x23, %r8
14004593f:     	jae	0x14004595a <.text+0x4495a>
140045941:     	movl	$0xcccccccd, %edx       # imm = 0xCCCCCCCD
140045946:     	imulq	%rdx, %r9
14004594a:     	shrq	$0x23, %r9
14004594e:     	addl	%r9d, %r9d
140045951:     	leal	(%r9,%r9,4), %edx
140045955:     	subl	%eax, %edx
140045957:     	addl	$0xa, %edx
14004595a:     	testq	%r12, %r12
14004595d:     	je	0x14004597a <.text+0x4497a>
14004595f:     	cmpq	$0xa, %r12
140045963:     	ja	0x1400461e0 <.text+0x451e0>
140045969:     	cmpl	%eax, -0x14(%rbp,%r12,4)
14004596e:     	jae	0x14004598a <.text+0x4498a>
140045970:     	cmpq	$0xa, %r12
140045974:     	je	0x140046133 <.text+0x45133>
14004597a:     	movl	%eax, -0x10(%rbp,%r12,4)
14004597f:     	movq	0x18(%rbp), %r12
140045983:     	incq	%r12
140045986:     	movq	%r12, 0x18(%rbp)
14004598a:     	cmpl	$0x1, %edx
14004598d:     	je	0x140045820 <.text+0x44820>
140045993:     	incl	%eax
140045995:     	movq	%rcx, %r8
140045998:     	imulq	%rax, %r8
14004599c:     	cmpq	0x570(%rbp), %r8
1400459a3:     	jae	0x140045820 <.text+0x44820>
1400459a9:     	addq	$-0x2, %rdx
1400459ad:     	testq	%r12, %r12
1400459b0:     	je	0x1400459cd <.text+0x449cd>
1400459b2:     	cmpq	$0xb, %r12
1400459b6:     	jae	0x1400461e0 <.text+0x451e0>
1400459bc:     	cmpl	-0x14(%rbp,%r12,4), %eax
1400459c1:     	jbe	0x1400459dd <.text+0x449dd>
1400459c3:     	cmpq	$0xa, %r12
1400459c7:     	je	0x140046133 <.text+0x45133>
1400459cd:     	movl	%eax, -0x10(%rbp,%r12,4)
1400459d2:     	movq	0x18(%rbp), %r12
1400459d6:     	incq	%r12
1400459d9:     	movq	%r12, 0x18(%rbp)
1400459dd:     	subq	$0x1, %rdx
1400459e1:     	jb	0x140045820 <.text+0x44820>
1400459e7:     	incl	%eax
1400459e9:     	movq	%rcx, %r8
1400459ec:     	imulq	%rax, %r8
1400459f0:     	cmpq	0x570(%rbp), %r8
1400459f7:     	jb	0x1400459ad <.text+0x449ad>
1400459f9:     	jmp	0x140045820 <.text+0x44820>
1400459fe:     	movaps	-0x10(%rbp), %xmm0
140045a02:     	movaps	(%rbp), %xmm1
140045a06:     	movaps	0x10(%rbp), %xmm2
140045a0a:     	movups	%xmm0, 0x440(%rbp)
140045a11:     	movups	%xmm1, 0x450(%rbp)
140045a18:     	movups	%xmm2, 0x460(%rbp)
140045a1f:     	xorl	%eax, %eax
140045a21:     	movq	0x538(%rbp), %r15
140045a28:     	movq	0x5f8(%rbp), %r12
140045a2f:     	movq	0x530(%rbp), %r13
140045a36:     	testq	%rax, %rax
140045a39:     	je	0x140045fc4 <.text+0x44fc4>
140045a3f:     	leaq	0x440(%rbp), %rax
140045a46:     	movq	0x10(%rax), %rcx
140045a4a:     	movq	%rcx, 0x430(%rbp)
140045a51:     	movups	(%rax), %xmm0
140045a54:     	movups	%xmm0, 0x420(%rbp)
140045a5b:     	movq	0x428(%rbp), %rax
140045a62:     	movq	%rax, 0x10(%rsi)
140045a66:     	movq	0x430(%rbp), %rax
140045a6d:     	movq	%rax, 0x18(%rsi)
140045a71:     	movups	0x419(%rbp), %xmm0
140045a78:     	movups	%xmm0, 0x1(%rsi)
140045a7c:     	movb	$0xa, (%rsi)
140045a7f:     	jmp	0x140045799 <.text+0x44799>
140045a84:     	shlq	$0x2, %rdx
140045a88:     	leaq	(%r9,%r9,2), %rax
140045a8c:     	shlq	$0xc, %rax
140045a90:     	addq	%rdi, %rax
140045a93:     	addq	$0x81c0, %rax           # imm = 0x81C0
140045a99:     	movq	%rax, 0x4a8(%rbp)
140045aa0:     	leaq	0x38(%r12), %rax
140045aa5:     	movq	%rax, 0x500(%rbp)
140045aac:     	leaq	0x66(%r12), %rax
140045ab1:     	movq	%rax, 0x4b0(%rbp)
140045ab8:     	leaq	0x56(%r12), %rax
140045abd:     	movq	%rax, 0x4b8(%rbp)
140045ac4:     	imulq	$0x2b0, %r9, %rax       # imm = 0x2B0
140045acb:     	movzwl	0x54(%r12), %ecx
140045ad1:     	movw	%cx, 0x582(%rbp)
140045ad8:     	movzbl	0x70(%r12), %ecx
140045ade:     	movb	%cl, 0x585(%rbp)
140045ae4:     	addq	%rdi, %rax
140045ae7:     	addq	$0x7c48, %rax           # imm = 0x7C48
140045aed:     	movq	%rax, 0x508(%rbp)
140045af4:     	addq	$-0x4, %rdx
140045af8:     	xorl	%r12d, %r12d
140045afb:     	movq	%r15, 0x538(%rbp)
140045b02:     	movq	%r13, 0x530(%rbp)
140045b09:     	movq	%rdx, 0x4c0(%rbp)
140045b10:     	movl	0x470(%rbp,%r12), %ebx
140045b18:     	movq	%r13, %r14
140045b1b:     	imulq	%rbx, %r14
140045b1f:     	testq	%r12, %r12
140045b22:     	je	0x140045b2d <.text+0x44b2d>
140045b24:     	cmpq	%rsi, %r14
140045b27:     	jae	0x140045f7e <.text+0x44f7e>
140045b2d:     	movq	%r12, 0x4f0(%rbp)
140045b34:     	leaq	(%r14,%r13), %r12
140045b38:     	cmpq	%r12, %rsi
140045b3b:     	movq	%r12, %r13
140045b3e:     	cmovbq	%rsi, %r13
140045b42:     	movl	$0x400, %r8d            # imm = 0x400
140045b48:     	leaq	-0x10(%rbp), %rcx
140045b4c:     	xorl	%edx, %edx
140045b4e:     	callq	0x140138f22 <.text+0x137f22>
140045b53:     	movq	%r13, %r15
140045b56:     	subq	%r14, %r15
140045b59:     	cmpq	$0x401, %r15            # imm = 0x401
140045b60:     	jae	0x1400461b0 <.text+0x451b0>
140045b66:     	movq	0x610(%rbp), %rax
140045b6d:     	cmpb	$0x1, 0x81b8(%rdi,%rax)
140045b75:     	jne	0x140046029 <.text+0x45029>
140045b7b:     	movq	0xe1c0(%rdi,%rax,8), %rax
140045b83:     	cmpq	$0x3001, %rax           # imm = 0x3001
140045b89:     	jae	0x14004617d <.text+0x4517d>
140045b8f:     	cmpq	%r14, %rsi
140045b92:     	jb	0x1400461c9 <.text+0x451c9>
140045b98:     	cmpq	%rax, %r13
140045b9b:     	ja	0x1400461c9 <.text+0x451c9>
140045ba1:     	addq	0x4a8(%rbp), %r14
140045ba8:     	leaq	-0x10(%rbp), %rcx
140045bac:     	movq	%r14, %rdx
140045baf:     	movq	%r15, %r8
140045bb2:     	callq	0x140138f10 <.text+0x137f10>
140045bb7:     	movq	%rbx, %rax
140045bba:     	cmpl	$0xfffff, %eax          # imm = 0xFFFFF
140045bbf:     	ja	0x140046040 <.text+0x45040>
140045bc5:     	movq	%rdi, %r14
140045bc8:     	xorl	%edi, %edi
140045bca:     	cmpq	%rsi, %r12
140045bcd:     	setb	0x584(%rbp)
140045bd4:     	movl	%eax, 0x540(%rbp)
140045bda:     	movq	0x4a0(%rbp), %rax
140045be1:     	movb	%al, 0x544(%rbp)
140045be7:     	movl	0x541(%rbp), %r13d
140045bee:     	cmpq	$0x0, 0x4f0(%rbp)
140045bf6:     	je	0x140045c37 <.text+0x44c37>
140045bf8:     	leaq	0x540(%rbp), %rcx
140045bff:     	movq	0x4f8(%rbp), %rdx
140045c06:     	movq	%r14, %r8
140045c09:     	movq	0x5f0(%rbp), %r9
140045c10:     	callq	0x1400164c0 <.text+0x154c0>
140045c15:     	movzbl	0x540(%rbp), %eax
140045c1c:     	cmpb	$-0x1, %al
140045c1e:     	jne	0x1400460f5 <.text+0x450f5>
140045c24:     	movzwl	0x542(%rbp), %eax
140045c2b:     	movw	%ax, 0x586(%rbp)
140045c32:     	jmp	0x140045d80 <.text+0x44d80>
140045c37:     	movzwl	0x582(%rbp), %eax
140045c3e:     	movw	%ax, 0x586(%rbp)
140045c45:     	cmpb	$0x2, 0x608(%rbp)
140045c4c:     	jne	0x140045d80 <.text+0x44d80>
140045c52:     	movq	0x628(%rbp), %rax
140045c59:     	movq	%rax, 0x28(%rsp)
140045c5e:     	movzbl	0x585(%rbp), %eax
140045c65:     	movb	%al, 0x20(%rsp)
140045c69:     	movq	%r14, %rcx
140045c6c:     	movq	%r14, 0x4c8(%rbp)
140045c73:     	movq	0x500(%rbp), %rdx
140045c7a:     	movzwl	0x582(%rbp), %esi
140045c81:     	movl	%esi, %r8d
140045c84:     	movq	0x5f0(%rbp), %r9
140045c8b:     	callq	0x14004cd20 <.text+0x4bd20>
140045c90:     	movb	$0x2, 0x56c(%rbp)
140045c97:     	movb	$0x0, 0x562(%rbp)
140045c9e:     	movw	%si, 0x560(%rbp)
140045ca5:     	movq	0x4c8(%rbp), %rsi
140045cac:     	leaq	0x563(%rbp), %rax
140045cb3:     	movb	$0x0, 0x8(%rax)
140045cb7:     	movq	$0x0, (%rax)
140045cbe:     	movq	$0x8, 0x540(%rbp)
140045cc9:     	movq	$0x0, 0x548(%rbp)
140045cd4:     	movq	$0x1, 0x550(%rbp)
140045cdf:     	movq	$0x0, 0x558(%rbp)
140045cea:     	leaq	0x540(%rbp), %rax
140045cf1:     	movq	%rax, 0x20(%rsp)
140045cf6:     	leaq	0x510(%rbp), %rcx
140045cfd:     	movq	%rsi, %rdx
140045d00:     	movq	0x538(%rbp), %r8
140045d07:     	movq	0x500(%rbp), %r9
140045d0e:     	callq	0x14001cf20 <.text+0x1bf20>
140045d13:     	cmpb	$-0x1, 0x510(%rbp)
140045d1a:     	je	0x140045d3a <.text+0x44d3a>
140045d1c:     	movups	0x510(%rbp), %xmm0
140045d23:     	movups	0x520(%rbp), %xmm1
140045d2a:     	movaps	%xmm1, 0x4e0(%rbp)
140045d31:     	movaps	%xmm0, 0x4d0(%rbp)
140045d38:     	jmp	0x140045d57 <.text+0x44d57>
140045d3a:     	leaq	0x4d0(%rbp), %rcx
140045d41:     	movq	0x4f8(%rbp), %rdx
140045d48:     	movq	%rsi, %r8
140045d4b:     	movq	0x5f0(%rbp), %r9
140045d52:     	callq	0x1400164c0 <.text+0x154c0>
140045d57:     	movzbl	0x4d0(%rbp), %eax
140045d5e:     	movzwl	0x4d2(%rbp), %ecx
140045d65:     	movw	%cx, 0x586(%rbp)
140045d6c:     	cmpb	$-0x1, %al
140045d6e:     	jne	0x140046144 <.text+0x45144>
140045d74:     	nopw	%cs:(%rax,%rax)
140045d80:     	movq	%r14, %rcx
140045d83:     	callq	0x14004e110 <.text+0x4d110>
140045d88:     	testb	$0x1, %al
140045d8a:     	je	0x14004605d <.text+0x4505d>
140045d90:     	movq	%rdx, %rsi
140045d93:     	movzbl	0x584(%rbp), %eax
140045d9a:     	movb	%al, %dil
140045d9d:     	shlq	$0x28, %rdi
140045da1:     	shlq	$0x8, %r13
140045da5:     	orq	%rdi, %r13
140045da8:     	movzbl	%bl, %eax
140045dab:     	orq	%r13, %rax
140045dae:     	movq	0x500(%rbp), %r13
140045db5:     	movups	(%r13), %xmm0
140045dba:     	movups	0xc(%r13), %xmm1
140045dbf:     	movups	%xmm1, 0x51c(%rbp)
140045dc6:     	movaps	%xmm0, 0x510(%rbp)
140045dcd:     	movq	$0x1, 0x540(%rbp)
140045dd8:     	movq	0x570(%rbp), %rcx
140045ddf:     	movq	%rcx, 0x548(%rbp)
140045de6:     	movq	%rax, 0x550(%rbp)
140045ded:     	movb	$0x1, 0x558(%rbp)
140045df4:     	movq	0x4b8(%rbp), %rcx
140045dfb:     	movq	(%rcx), %rax
140045dfe:     	movq	0x7(%rcx), %rcx
140045e02:     	movq	%rcx, 0x4d7(%rbp)
140045e09:     	movq	%rax, 0x4d0(%rbp)
140045e10:     	leaq	0x4d0(%rbp), %rax
140045e17:     	movq	%rax, 0x68(%rsp)
140045e1c:     	movq	0x620(%rbp), %rax
140045e23:     	movq	%rax, 0x60(%rsp)
140045e28:     	movq	0x5f8(%rbp), %rax
140045e2f:     	movq	%rax, 0x58(%rsp)
140045e34:     	leaq	0x540(%rbp), %rdi
140045e3b:     	movq	%rdi, 0x50(%rsp)
140045e40:     	movq	%r15, 0x48(%rsp)
140045e45:     	leaq	-0x10(%rbp), %rax
140045e49:     	movq	%rax, 0x40(%rsp)
140045e4e:     	movq	0x600(%rbp), %rax
140045e55:     	movq	%rax, 0x38(%rsp)
140045e5a:     	movq	0x4b0(%rbp), %rax
140045e61:     	movq	%rax, 0x30(%rsp)
140045e66:     	movzwl	0x586(%rbp), %ebx
140045e6d:     	movw	%bx, 0x28(%rsp)
140045e72:     	movb	$0x1, 0x20(%rsp)
140045e77:     	leaq	0x3f8(%rbp), %rcx
140045e7e:     	movq	%r14, %rdx
140045e81:     	leaq	0x510(%rbp), %r15
140045e88:     	movq	%r15, %r8
140045e8b:     	movq	%rsi, %r9
140045e8e:     	callq	0x140040860 <.text+0x3f860>
140045e93:     	cmpb	$-0x1, 0x3f8(%rbp)
140045e9a:     	jne	0x14004606c <.text+0x4506c>
140045ea0:     	movq	$0x0, 0x510(%rbp)
140045eab:     	movq	%r15, 0x28(%rsp)
140045eb0:     	movq	%r13, 0x20(%rsp)
140045eb5:     	movq	%rdi, %rcx
140045eb8:     	movq	%r14, %rdx
140045ebb:     	movq	0x538(%rbp), %r8
140045ec2:     	movq	%rsi, %r9
140045ec5:     	callq	0x140065520 <.text+0x64520>
140045eca:     	cmpb	$-0x1, 0x540(%rbp)
140045ed1:     	jne	0x1400460d4 <.text+0x450d4>
140045ed7:     	movq	%r14, %rdi
140045eda:     	movq	0x610(%rbp), %rax
140045ee1:     	cmpb	$0x1, 0x81b8(%r14,%rax)
140045eea:     	jne	0x140045f50 <.text+0x44f50>
140045eec:     	movq	0x508(%rbp), %rax
140045ef3:     	movq	(%rax), %rax
140045ef6:     	cmpq	$0x2, %rax
140045efa:     	je	0x140045f50 <.text+0x44f50>
140045efc:     	movq	0x508(%rbp), %rcx
140045f03:     	cmpb	$0x7, 0x2ae(%rcx)
140045f0a:     	sete	%cl
140045f0d:     	andb	%cl, %al
140045f0f:     	cmpb	$0x1, %al
140045f11:     	jne	0x140045f50 <.text+0x44f50>
140045f13:     	movq	0x508(%rbp), %rdx
140045f1a:     	cmpl	$0x2, 0x20(%rdx)
140045f1e:     	movzwl	%bx, %eax
140045f21:     	cmovel	0x34(%rdx), %eax
140045f25:     	movl	0x30(%rdx), %ecx
140045f28:     	movl	$0x1, %r8d
140045f2e:     	cmovnel	%r8d, %ecx
140045f32:     	movq	$0x1, (%rdx)
140045f39:     	movl	%ecx, 0x30(%rdx)
140045f3c:     	movl	%eax, 0x34(%rdx)
140045f3f:     	movb	$0x7, 0x2ae(%rdx)
140045f46:     	nopw	%cs:(%rax,%rax)
140045f50:     	movq	0x570(%rbp), %rsi
140045f57:     	cmpq	%rsi, %r12
140045f5a:     	movq	0x530(%rbp), %r13
140045f61:     	movq	0x4c0(%rbp), %rdx
140045f68:     	movq	0x4f0(%rbp), %rax
140045f6f:     	jae	0x140045f7e <.text+0x44f7e>
140045f71:     	cmpq	%rax, %rdx
140045f74:     	leaq	0x4(%rax), %r12
140045f78:     	jne	0x140045b10 <.text+0x44b10>
140045f7e:     	movq	0x578(%rbp), %rax
140045f85:     	movb	$-0x1, (%rax)
140045f88:     	jmp	0x140045799 <.text+0x44799>
140045f8d:     	movzwl	0x2e(%r12), %eax
140045f93:     	shlq	$0x30, %rax
140045f97:     	shlq	$0x28, %rdx
140045f9b:     	orq	%rax, %rdx
140045f9e:     	orq	%r14, %rdx
140045fa1:     	leaq	0x438(%rbp), %rcx
140045fa8:     	movq	0x570(%rbp), %r8
140045faf:     	callq	0x140044e10 <.text+0x43e10>
140045fb4:     	movq	0x438(%rbp), %rax
140045fbb:     	testq	%rax, %rax
140045fbe:     	jne	0x140045a3f <.text+0x44a3f>
140045fc4:     	movzbl	0x440(%rbp), %eax
140045fcb:     	movups	0x460(%rbp), %xmm0
140045fd2:     	movups	%xmm0, 0x490(%rbp)
140045fd9:     	movups	0x441(%rbp), %xmm0
140045fe0:     	movups	%xmm0, 0x471(%rbp)
140045fe7:     	movups	0x450(%rbp), %xmm0
140045fee:     	movups	%xmm0, 0x480(%rbp)
140045ff5:     	movb	%al, 0x470(%rbp)
140045ffb:     	movq	0x610(%rbp), %r9
140046002:     	movq	0x498(%rbp), %rdx
140046009:     	cmpq	$0xb, %rdx
14004600d:     	jb	0x1400456dc <.text+0x446dc>
140046013:     	leaq	0x1030ce(%rip), %r9     # 0x1401490e8
14004601a:     	movl	$0xa, %r8d
140046020:     	xorl	%ecx, %ecx
140046022:     	callq	0x1401399d0 <.text+0x1389d0>
140046027:     	ud2
140046029:     	movq	0x578(%rbp), %rax
140046030:     	movb	$0xa, (%rax)
140046033:     	movq	$0x3, 0x8(%rax)
14004603b:     	jmp	0x140045799 <.text+0x44799>
140046040:     	movq	0x578(%rbp), %rcx
140046047:     	movabsq	$0x31100000000, %rax    # imm = 0x31100000000
140046051:     	movb	$0xa, (%rcx)
140046054:     	movq	%rax, 0x4(%rcx)
140046058:     	jmp	0x140045799 <.text+0x44799>
14004605d:     	movq	0x578(%rbp), %rax
140046064:     	movb	$0x9, (%rax)
140046067:     	jmp	0x140045799 <.text+0x44799>
14004606c:     	cmpb	$0x1, 0x11410(%r14,%rsi)
140046075:     	jne	0x1400460c4 <.text+0x450c4>
140046077:     	cmpb	$0x0, 0x11414(%r14,%rsi)
140046080:     	jne	0x1400460c4 <.text+0x450c4>
140046082:     	movb	$0x0, 0x11410(%r14,%rsi)
14004608b:     	decq	0x11408(%r14)
140046092:     	leaq	0xfc10(%r14), %rax
140046099:     	movq	$0x0, 0x11310(%r14,%rsi,8)
1400460a5:     	leaq	(%rsi,%rsi,8), %rcx
1400460a9:     	leaq	(%rcx,%rcx,2), %rcx
1400460ad:     	addq	%rsi, %rcx
1400460b0:     	movb	$0x2, 0x179a(%rax,%rcx)
1400460b8:     	leaq	(%rsi,%rsi,2), %rcx
1400460bc:     	movb	$0x2, 0x172d(%rax,%rcx,8)
1400460c4:     	movups	0x3f8(%rbp), %xmm0
1400460cb:     	movups	0x408(%rbp), %xmm1
1400460d2:     	jmp	0x1400460e2 <.text+0x450e2>
1400460d4:     	movups	0x540(%rbp), %xmm0
1400460db:     	movups	0x550(%rbp), %xmm1
1400460e2:     	movq	0x578(%rbp), %rax
1400460e9:     	movups	%xmm1, 0x10(%rax)
1400460ed:     	movups	%xmm0, (%rax)
1400460f0:     	jmp	0x140045799 <.text+0x44799>
1400460f5:     	movzbl	0x541(%rbp), %ecx
1400460fc:     	movzwl	0x542(%rbp), %edx
140046103:     	movups	0x550(%rbp), %xmm0
14004610a:     	movq	0x578(%rbp), %r8
140046111:     	movups	%xmm0, 0x10(%r8)
140046116:     	movups	0x544(%rbp), %xmm0
14004611d:     	movups	%xmm0, 0x4(%r8)
140046122:     	movb	%al, (%r8)
140046125:     	movb	%cl, 0x1(%r8)
140046129:     	movw	%dx, 0x2(%r8)
14004612e:     	jmp	0x140045799 <.text+0x44799>
140046133:     	movb	$0x7, 0x440(%rbp)
14004613a:     	movl	$0x1, %eax
14004613f:     	jmp	0x140045a21 <.text+0x44a21>
140046144:     	movzbl	0x4d1(%rbp), %ecx
14004614b:     	movups	0x4e0(%rbp), %xmm0
140046152:     	movq	0x578(%rbp), %rdx
140046159:     	movups	%xmm0, 0x10(%rdx)
14004615d:     	movups	0x4d4(%rbp), %xmm0
140046164:     	movups	%xmm0, 0x4(%rdx)
140046168:     	movb	%al, (%rdx)
14004616a:     	movb	%cl, 0x1(%rdx)
14004616d:     	movzwl	0x586(%rbp), %eax
140046174:     	movw	%ax, 0x2(%rdx)
140046178:     	jmp	0x140045799 <.text+0x44799>
14004617d:     	leaq	0x104954(%rip), %r9     # 0x14014aad8
140046184:     	movl	$0x3000, %r8d           # imm = 0x3000
14004618a:     	xorl	%ecx, %ecx
14004618c:     	movq	%rax, %rdx
14004618f:     	callq	0x1401399d0 <.text+0x1389d0>
140046194:     	ud2
140046196:     	leaq	0x102ef3(%rip), %rcx    # 0x140149090
14004619d:     	leaq	0x102efc(%rip), %r8     # 0x1401490a0
1400461a4:     	movl	$0xb, %edx
1400461a9:     	callq	0x1401396e0 <.text+0x1386e0>
1400461ae:     	ud2
1400461b0:     	leaq	0x102f19(%rip), %r9     # 0x1401490d0
1400461b7:     	movl	$0x400, %r8d            # imm = 0x400
1400461bd:     	xorl	%ecx, %ecx
1400461bf:     	movq	%r15, %rdx
1400461c2:     	callq	0x1401399d0 <.text+0x1389d0>
1400461c7:     	ud2
1400461c9:     	leaq	0x102ee8(%rip), %r9     # 0x1401490b8
1400461d0:     	movq	%r14, %rcx
1400461d3:     	movq	%r13, %rdx
1400461d6:     	movq	%rax, %r8
1400461d9:     	callq	0x1401399d0 <.text+0x1389d0>
1400461de:     	ud2
1400461e0:     	decq	%r12
1400461e3:     	leaq	0x102e8e(%rip), %r8     # 0x140149078
1400461ea:     	movl	$0xa, %edx
1400461ef:     	movq	%r12, %rcx
1400461f2:     	callq	0x1401397c3 <.text+0x1387c3>
1400461f7:     	ud2
1400461f9:     	movb	$0x1, 0x510(%rbp)
140046200:     	leaq	0x1038a9(%rip), %rax    # 0x140149ab0
140046207:     	movq	%rax, 0x20(%rsp)
14004620c:     	leaq	0x103885(%rip), %rcx    # 0x140149a98
140046213:     	leaq	0x104276(%rip), %r9     # 0x14014a490
14004621a:     	leaq	0x510(%rbp), %r8
140046221:     	movl	$0x11, %edx
140046226:     	callq	0x140139740 <.text+0x138740>
14004622b:     	ud2

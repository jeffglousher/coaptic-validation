
D:\CoapticCurrent\packet-lazy-staged-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140095950:     	pushq	%rbp
140095951:     	pushq	%r15
140095953:     	pushq	%r14
140095955:     	pushq	%r13
140095957:     	pushq	%r12
140095959:     	pushq	%rsi
14009595a:     	pushq	%rdi
14009595b:     	pushq	%rbx
14009595c:     	subq	$0x318, %rsp            # imm = 0x318
140095963:     	leaq	0x80(%rsp), %rbp
14009596b:     	movaps	%xmm7, 0x280(%rbp)
140095972:     	movaps	%xmm6, 0x270(%rbp)
140095979:     	leaq	0x30(%rcx), %rdx
14009597d:     	xorl	%r8d, %r8d
140095980:     	xorl	%r11d, %r11d
140095983:     	leaq	(%r11,%r11,4), %r10
140095987:     	shlq	$0x6, %r10
14009598b:     	addq	%rdx, %r10
14009598e:     	movq	%r11, %r9
140095991:     	jmp	0x1400959b4 <.text+0x949b4>
140095993:     	nopw	%cs:(%rax,%rax)
1400959a0:     	incq	%r9
1400959a3:     	addq	$0x140, %r10            # imm = 0x140
1400959aa:     	cmpq	$0x4, %r9
1400959ae:     	je	0x140095a3e <.text+0x94a3e>
1400959b4:     	cmpb	$0x1, 0x510(%rcx,%r9)
1400959bd:     	jne	0x1400959a0 <.text+0x949a0>
1400959bf:     	movq	-0x30(%r10), %rsi
1400959c3:     	cmpq	$0x2, %rsi
1400959c7:     	je	0x1400959a0 <.text+0x949a0>
1400959c9:     	movq	(%r10), %r11
1400959cc:     	cmpl	$0x1, %esi
1400959cf:     	setne	%bl
1400959d2:     	testq	%r11, %r11
1400959d5:     	sete	%sil
1400959d9:     	orb	%bl, %sil
1400959dc:     	cmpb	$0x1, %sil
1400959e0:     	je	0x1400959a0 <.text+0x949a0>
1400959e2:     	movq	0x268(%rbp), %rsi
1400959e9:     	cmpq	%rsi, %r11
1400959ec:     	setae	%bl
1400959ef:     	testb	%bl, %r8b
1400959f2:     	jne	0x140095a24 <.text+0x94a24>
1400959f4:     	movq	-0x28(%r10), %rax
1400959f8:     	movd	-0x4(%r10), %xmm6
1400959fe:     	movzbl	-0x5(%r10), %edi
140095a03:     	movzbl	-0x6(%r10), %r15d
140095a08:     	movzwl	-0x8(%r10), %r12d
140095a0d:     	movl	-0xc(%r10), %r13d
140095a11:     	movl	-0x10(%r10), %r14d
140095a15:     	movups	-0x20(%r10), %xmm0
140095a1a:     	movaps	%xmm0, 0x240(%rbp)
140095a21:     	movq	%r11, %rsi
140095a24:     	movq	%rsi, 0x268(%rbp)
140095a2b:     	leaq	0x1(%r9), %r11
140095a2f:     	movb	$0x1, %r8b
140095a32:     	cmpq	$0x3, %r9
140095a36:     	jb	0x140095983 <.text+0x94983>
140095a3c:     	jmp	0x140095a48 <.text+0x94a48>
140095a3e:     	testb	$0x1, %r8b
140095a42:     	je	0x140095c88 <.text+0x94c88>
140095a48:     	cmpq	$0x1, %rax
140095a4c:     	ja	0x140095aa4 <.text+0x94aa4>
140095a4e:     	cmpb	$0x1, 0x4420(%rcx,%rax)
140095a56:     	jne	0x140095aa4 <.text+0x94aa4>
140095a58:     	cmpb	$0x0, 0x4422(%rcx,%rax)
140095a60:     	jne	0x140095aa4 <.text+0x94aa4>
140095a62:     	movb	$0x0, 0x4420(%rcx,%rax)
140095a6a:     	decq	0x4418(%rcx)
140095a71:     	leaq	0x3a98(%rcx), %rdx
140095a78:     	movq	$0x0, 0x4398(%rcx,%rax,8)
140095a84:     	leaq	(%rax,%rax,8), %r8
140095a88:     	leaq	(%r8,%r8,2), %r8
140095a8c:     	addq	%rax, %r8
140095a8f:     	movb	$0x2, 0x95a(%rdx,%r8)
140095a98:     	leaq	(%rax,%rax,2), %rax
140095a9c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
140095aa4:     	movaps	0x240(%rbp), %xmm0
140095aab:     	movaps	%xmm0, -0x60(%rbp)
140095aaf:     	movl	%r14d, %esi
140095ab2:     	movl	%r14d, -0x50(%rbp)
140095ab6:     	movl	%r13d, %r14d
140095ab9:     	movl	%r13d, -0x4c(%rbp)
140095abd:     	movl	%r12d, %r13d
140095ac0:     	movw	%r12w, -0x48(%rbp)
140095ac5:     	movl	%r15d, %r12d
140095ac8:     	movb	%r15b, -0x46(%rbp)
140095acc:     	movl	%edi, %r15d
140095acf:     	movb	%dil, -0x45(%rbp)
140095ad3:     	movd	%xmm6, %edi
140095ad7:     	movd	%xmm6, -0x44(%rbp)
140095adc:     	leaq	-0x60(%rbp), %rdx
140095ae0:     	movq	%rcx, 0x260(%rbp)
140095ae7:     	callq	0x1401ff440 <.text+0x1fe440>
140095aec:     	xorps	%xmm7, %xmm7
140095aef:     	movaps	%xmm7, 0x250(%rbp)
140095af6:     	movb	$0x0, 0x222(%rbp)
140095afd:     	movw	%di, 0x220(%rbp)
140095b04:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
140095b0d:     	movq	$0x0, 0x223(%rbp)
140095b18:     	movq	$0x8, 0x200(%rbp)
140095b23:     	movq	$0x0, 0x208(%rbp)
140095b2e:     	movq	$0x1, 0x210(%rbp)
140095b39:     	movq	$0x0, 0x218(%rbp)
140095b44:     	leaq	0x230(%rbp), %rcx
140095b4b:     	leaq	0x200(%rbp), %rdx
140095b52:     	leaq	0x250(%rbp), %r8
140095b59:     	movl	$0x10, %r9d
140095b5f:     	callq	0x140106080 <.text+0x105080>
140095b64:     	cmpb	$0x0, 0x230(%rbp)
140095b6b:     	jne	0x140095c84 <.text+0x94c84>
140095b71:     	movq	0x238(%rbp), %rdi
140095b78:     	movaps	%xmm7, 0xe0(%rbp)
140095b7f:     	movaps	%xmm7, 0xf0(%rbp)
140095b86:     	movaps	%xmm7, 0x100(%rbp)
140095b8d:     	movaps	%xmm7, 0x110(%rbp)
140095b94:     	movaps	%xmm7, 0x120(%rbp)
140095b9b:     	movaps	%xmm7, 0x130(%rbp)
140095ba2:     	movaps	%xmm7, 0x140(%rbp)
140095ba9:     	movaps	%xmm7, 0x150(%rbp)
140095bb0:     	movaps	%xmm7, 0x160(%rbp)
140095bb7:     	movaps	%xmm7, 0x170(%rbp)
140095bbe:     	movaps	%xmm7, 0x180(%rbp)
140095bc5:     	movaps	%xmm7, 0x190(%rbp)
140095bcc:     	movaps	%xmm7, 0x1a0(%rbp)
140095bd3:     	movaps	%xmm7, 0x1b0(%rbp)
140095bda:     	movaps	%xmm7, 0x1c0(%rbp)
140095be1:     	movaps	%xmm7, 0x1d0(%rbp)
140095be8:     	movaps	0x240(%rbp), %xmm0
140095bef:     	movups	%xmm0, 0x1f0(%rbp)
140095bf6:     	cmpq	$0x11, %rdi
140095bfa:     	jae	0x140095cac <.text+0x94cac>
140095c00:     	leaq	0xe0(%rbp), %rbx
140095c07:     	leaq	0x250(%rbp), %rdx
140095c0e:     	movq	%rbx, %rcx
140095c11:     	movq	%rdi, %r8
140095c14:     	callq	0x1402394a0 <.text+0x2384a0>
140095c19:     	movw	%di, 0x1e0(%rbp)
140095c20:     	movq	$0x0, -0x60(%rbp)
140095c28:     	movups	0x1e8(%rbp), %xmm0
140095c2f:     	movups	%xmm0, -0x58(%rbp)
140095c33:     	movq	0x1f8(%rbp), %rax
140095c3a:     	movq	%rax, -0x48(%rbp)
140095c3e:     	movl	%esi, -0x40(%rbp)
140095c41:     	movl	%r14d, -0x3c(%rbp)
140095c45:     	movw	%r13w, -0x38(%rbp)
140095c4a:     	movb	%r12b, -0x36(%rbp)
140095c4e:     	movb	%r15b, -0x35(%rbp)
140095c52:     	movd	%xmm6, -0x34(%rbp)
140095c57:     	movq	0x268(%rbp), %rax
140095c5e:     	movq	%rax, -0x30(%rbp)
140095c62:     	leaq	-0x28(%rbp), %rcx
140095c66:     	movl	$0x108, %r8d            # imm = 0x108
140095c6c:     	movq	%rbx, %rdx
140095c6f:     	callq	0x1402394a0 <.text+0x2384a0>
140095c74:     	leaq	-0x60(%rbp), %rdx
140095c78:     	movq	0x260(%rbp), %rcx
140095c7f:     	callq	0x1401ff1b0 <.text+0x1fe1b0>
140095c84:     	movb	$0x1, %al
140095c86:     	jmp	0x140095c8a <.text+0x94c8a>
140095c88:     	xorl	%eax, %eax
140095c8a:     	movaps	0x270(%rbp), %xmm6
140095c91:     	movaps	0x280(%rbp), %xmm7
140095c98:     	addq	$0x318, %rsp            # imm = 0x318
140095c9f:     	popq	%rbx
140095ca0:     	popq	%rdi
140095ca1:     	popq	%rsi
140095ca2:     	popq	%r12
140095ca4:     	popq	%r13
140095ca6:     	popq	%r14
140095ca8:     	popq	%r15
140095caa:     	popq	%rbp
140095cab:     	retq
140095cac:     	leaq	0x1bbeb5(%rip), %r9     # 0x140251b68
140095cb3:     	movl	$0x10, %r8d
140095cb9:     	xorl	%ecx, %ecx
140095cbb:     	movq	%rdi, %rdx
140095cbe:     	callq	0x140239ef0 <.text+0x238ef0>
140095cc3:     	ud2

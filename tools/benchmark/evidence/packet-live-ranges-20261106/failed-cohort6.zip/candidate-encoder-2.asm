
D:\CoapticCurrent\packet-lazy-staged-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400643d0:     	pushq	%rbp
1400643d1:     	pushq	%r15
1400643d3:     	pushq	%r14
1400643d5:     	pushq	%r13
1400643d7:     	pushq	%r12
1400643d9:     	pushq	%rsi
1400643da:     	pushq	%rdi
1400643db:     	pushq	%rbx
1400643dc:     	subq	$0x4f8, %rsp            # imm = 0x4F8
1400643e3:     	leaq	0x80(%rsp), %rbp
1400643eb:     	movq	%r9, %rbx
1400643ee:     	movq	%r8, %r14
1400643f1:     	movq	%rdx, %rdi
1400643f4:     	movq	%rcx, %rsi
1400643f7:     	movq	0x4f0(%rbp), %r12
1400643fe:     	leaq	-0x10(%rbp), %rcx
140064402:     	movl	$0x400, %r8d            # imm = 0x400
140064408:     	xorl	%edx, %edx
14006440a:     	callq	0x1402394b2 <.text+0x2384b2>
14006440f:     	movq	0x8(%r12), %r13
140064414:     	movl	$0x3, %eax
140064419:     	cmpq	$0x3, %r13
14006441d:     	ja	0x140064636 <.text+0x63636>
140064423:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
14006442c:     	jne	0x140064636 <.text+0x63636>
140064432:     	movq	0x2b750(%rdi,%r13,8), %rdx
14006443a:     	cmpq	$0x4001, %rdx           # imm = 0x4001
140064441:     	jae	0x140064692 <.text+0x63692>
140064447:     	movq	0x10(%r12), %rcx
14006444c:     	movq	0x18(%r12), %r15
140064451:     	movq	%r15, %r8
140064454:     	movl	$0xb, %eax
140064459:     	addq	%rcx, %r8
14006445c:     	jb	0x140064636 <.text+0x63636>
140064462:     	cmpq	$0x400, %r15            # imm = 0x400
140064469:     	ja	0x140064636 <.text+0x63636>
14006446f:     	cmpq	%rdx, %r8
140064472:     	ja	0x140064636 <.text+0x63636>
140064478:     	movq	%r13, %rax
14006447b:     	shlq	$0xe, %rax
14006447f:     	leaq	(%rdi,%rax), %rdx
140064483:     	addq	$0x1b750, %rdx          # imm = 0x1B750
14006448a:     	addq	%rcx, %rdx
14006448d:     	leaq	-0x10(%rbp), %rcx
140064491:     	movq	%r15, %r8
140064494:     	callq	0x1402394a0 <.text+0x2384a0>
140064499:     	cmpb	$0x0, 0x4f8(%rbp)
1400644a0:     	je	0x1400644b8 <.text+0x634b8>
1400644a2:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
1400644a9:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
1400644b2:     	jne	0x140064651 <.text+0x63651>
1400644b8:     	movq	$0x0, 0x470(%rbp)
1400644c3:     	movq	%rdi, %rcx
1400644c6:     	callq	0x1400921e0 <.text+0x911e0>
1400644cb:     	testb	$0x1, %al
1400644cd:     	je	0x140064684 <.text+0x63684>
1400644d3:     	movq	%rdx, %r13
1400644d6:     	movq	0x500(%rbp), %rdx
1400644dd:     	movzwl	0x4e8(%rbp), %ecx
1400644e4:     	movzbl	0x4e0(%rbp), %eax
1400644eb:     	movq	(%r12), %r8
1400644ef:     	movq	0x470(%rbp), %r9
1400644f6:     	movq	%r9, 0x438(%rbp)
1400644fd:     	movq	0x468(%rbp), %r9
140064504:     	movq	%r9, 0x440(%rbp)
14006450b:     	movq	%r8, 0x448(%rbp)
140064512:     	movzbl	0x4f8(%rbp), %r8d
14006451a:     	movb	%r8b, 0x450(%rbp)
140064521:     	movups	0x38(%r14), %xmm0
140064526:     	movups	0x44(%r14), %xmm1
14006452b:     	movups	%xmm1, 0x3fc(%rbp)
140064532:     	movaps	%xmm0, 0x3f0(%rbp)
140064539:     	leaq	0x66(%r14), %r8
14006453d:     	movq	0x56(%r14), %r9
140064541:     	movq	0x5d(%r14), %r10
140064545:     	movq	%r10, 0x45f(%rbp)
14006454c:     	movq	%r9, 0x458(%rbp)
140064553:     	leaq	0x458(%rbp), %r9
14006455a:     	movq	%r9, 0x68(%rsp)
14006455f:     	movq	%rdx, 0x60(%rsp)
140064564:     	movq	%r14, 0x58(%rsp)
140064569:     	leaq	0x438(%rbp), %rdx
140064570:     	movq	%rdx, 0x50(%rsp)
140064575:     	movq	%r15, 0x48(%rsp)
14006457a:     	leaq	-0x10(%rbp), %rdx
14006457e:     	movq	%rdx, 0x40(%rsp)
140064583:     	movq	%rbx, 0x38(%rsp)
140064588:     	movq	%r8, 0x30(%rsp)
14006458d:     	movw	%cx, 0x28(%rsp)
140064592:     	movb	%al, 0x20(%rsp)
140064596:     	leaq	0x418(%rbp), %rcx
14006459d:     	leaq	0x3f0(%rbp), %r8
1400645a4:     	movq	%rdi, %rdx
1400645a7:     	movq	%r13, %r9
1400645aa:     	callq	0x14007be40 <.text+0x7ae40>
1400645af:     	cmpb	$-0x1, 0x418(%rbp)
1400645b6:     	je	0x140064689 <.text+0x63689>
1400645bc:     	cmpb	$0x1, 0x37740(%rdi,%r13)
1400645c5:     	jne	0x14006461f <.text+0x6361f>
1400645c7:     	cmpb	$0x0, 0x37760(%rdi,%r13)
1400645d0:     	jne	0x14006461f <.text+0x6361f>
1400645d2:     	movb	$0x0, 0x37740(%rdi,%r13)
1400645db:     	decq	0x37788(%rdi)
1400645e2:     	leaq	0x37740(%rdi), %rax
1400645e9:     	movq	$0x0, 0x43610(%rdi,%r13,8)
1400645f5:     	leaq	(,%r13,8), %rcx
1400645fd:     	addq	%r13, %rcx
140064600:     	leaq	(%rcx,%rcx,2), %rcx
140064604:     	addq	%r13, %rcx
140064607:     	movb	$0x2, 0x36a(%rax,%rcx)
14006460f:     	leaq	(,%r13,2), %rcx
140064617:     	addq	%r13, %rcx
14006461a:     	movb	$0x2, 0x5d(%rax,%rcx,8)
14006461f:     	movups	0x418(%rbp), %xmm0
140064626:     	movups	0x428(%rbp), %xmm1
14006462d:     	movups	%xmm1, 0x10(%rsi)
140064631:     	movups	%xmm0, (%rsi)
140064634:     	jmp	0x14006463d <.text+0x6363d>
140064636:     	movb	$0xa, (%rsi)
140064639:     	movq	%rax, 0x8(%rsi)
14006463d:     	addq	$0x4f8, %rsp            # imm = 0x4F8
140064644:     	popq	%rbx
140064645:     	popq	%rdi
140064646:     	popq	%rsi
140064647:     	popq	%r12
140064649:     	popq	%r13
14006464b:     	popq	%r14
14006464d:     	popq	%r15
14006464f:     	popq	%rbp
140064650:     	retq
140064651:     	addq	%rdi, %rax
140064654:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
14006465a:     	movq	0x98(%rax), %rax
140064661:     	movq	%rax, 0x468(%rbp)
140064668:     	movl	$0x1, %eax
14006466d:     	movq	%rax, 0x470(%rbp)
140064674:     	movq	%rdi, %rcx
140064677:     	callq	0x1400921e0 <.text+0x911e0>
14006467c:     	testb	$0x1, %al
14006467e:     	jne	0x1400644d3 <.text+0x634d3>
140064684:     	movb	$0x9, (%rsi)
140064687:     	jmp	0x14006463d <.text+0x6363d>
140064689:     	movq	%r13, 0x8(%rsi)
14006468d:     	movb	$-0x1, (%rsi)
140064690:     	jmp	0x14006463d <.text+0x6363d>
140064692:     	leaq	0x1f0597(%rip), %r9     # 0x140254c30
140064699:     	movl	$0x4000, %r8d           # imm = 0x4000
14006469f:     	xorl	%ecx, %ecx
1400646a1:     	callq	0x140239ef0 <.text+0x238ef0>
1400646a6:     	ud2

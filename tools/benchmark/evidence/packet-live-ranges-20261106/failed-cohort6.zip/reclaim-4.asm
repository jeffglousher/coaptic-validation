
D:\CoapticCurrent\packet-lazy-staged-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140096090:     	pushq	%rbp
140096091:     	pushq	%r15
140096093:     	pushq	%r14
140096095:     	pushq	%r13
140096097:     	pushq	%r12
140096099:     	pushq	%rsi
14009609a:     	pushq	%rdi
14009609b:     	pushq	%rbx
14009609c:     	subq	$0x318, %rsp            # imm = 0x318
1400960a3:     	leaq	0x80(%rsp), %rbp
1400960ab:     	movaps	%xmm7, 0x280(%rbp)
1400960b2:     	movdqa	%xmm6, 0x270(%rbp)
1400960ba:     	movq	0xe8(%rcx), %r8
1400960c1:     	testq	%r8, %r8
1400960c4:     	je	0x1400964a4 <.text+0x954a4>
1400960ca:     	movq	0x88(%rcx), %r11
1400960d1:     	movq	0xe0(%rcx), %rdx
1400960d8:     	movq	0xc8(%rcx), %rax
1400960df:     	movq	0xd0(%rcx), %r9
1400960e6:     	leaq	0x30(%rax), %rsi
1400960ea:     	xorl	%ebx, %ebx
1400960ec:     	xorl	%edi, %edi
1400960ee:     	leaq	(%rdi,%rdi,4), %r12
1400960f2:     	shlq	$0x6, %r12
1400960f6:     	addq	%rsi, %r12
1400960f9:     	jmp	0x140096113 <.text+0x95113>
1400960fb:     	nopl	(%rax,%rax)
140096100:     	incq	%rdi
140096103:     	addq	$0x140, %r12            # imm = 0x140
14009610a:     	cmpq	%r8, %rdi
14009610d:     	jae	0x1400961dc <.text+0x951dc>
140096113:     	cmpq	%r9, %rdi
140096116:     	setb	%r15b
14009611a:     	andb	(%rdx,%rdi), %r15b
14009611e:     	cmpb	$0x1, %r15b
140096122:     	jne	0x140096100 <.text+0x95100>
140096124:     	movq	-0x30(%r12), %r15
140096129:     	cmpq	$0x2, %r15
14009612d:     	je	0x140096100 <.text+0x95100>
14009612f:     	movq	(%r12), %r13
140096133:     	cmpl	$0x1, %r15d
140096137:     	setne	%r15b
14009613b:     	testq	%r13, %r13
14009613e:     	sete	%r10b
140096142:     	orb	%r15b, %r10b
140096145:     	cmpb	$0x1, %r10b
140096149:     	je	0x140096100 <.text+0x95100>
14009614b:     	movq	0x260(%rbp), %r15
140096152:     	cmpq	%r15, %r13
140096155:     	setae	%r10b
140096159:     	testb	%r10b, %bl
14009615c:     	jne	0x1400961c5 <.text+0x951c5>
14009615e:     	movq	-0x28(%r12), %r10
140096163:     	movq	%r10, 0x250(%rbp)
14009616a:     	movq	-0x20(%r12), %r10
14009616f:     	movq	%r10, 0x248(%rbp)
140096176:     	movd	-0x4(%r12), %xmm6
14009617d:     	movzbl	-0x5(%r12), %r10d
140096183:     	movb	%r10b, 0x26e(%rbp)
14009618a:     	movzbl	-0x6(%r12), %r10d
140096190:     	movb	%r10b, 0x26f(%rbp)
140096197:     	movzwl	-0x8(%r12), %r10d
14009619d:     	movw	%r10w, 0x26c(%rbp)
1400961a5:     	movl	-0xc(%r12), %r10d
1400961aa:     	movl	%r10d, 0x268(%rbp)
1400961b1:     	movl	-0x10(%r12), %r14d
1400961b6:     	movq	-0x18(%r12), %r10
1400961bb:     	movq	%r10, 0x258(%rbp)
1400961c2:     	movq	%r13, %r15
1400961c5:     	movq	%r15, 0x260(%rbp)
1400961cc:     	incq	%rdi
1400961cf:     	movb	$0x1, %bl
1400961d1:     	cmpq	%r8, %rdi
1400961d4:     	jb	0x1400960ee <.text+0x950ee>
1400961da:     	jmp	0x1400961e5 <.text+0x951e5>
1400961dc:     	testb	$0x1, %bl
1400961df:     	je	0x1400964a4 <.text+0x954a4>
1400961e5:     	movq	0x250(%rbp), %r10
1400961ec:     	cmpq	%r11, %r10
1400961ef:     	jae	0x140096245 <.text+0x95245>
1400961f1:     	movq	0x80(%rcx), %r11
1400961f8:     	cmpb	$0x1, (%r11,%r10)
1400961fd:     	jne	0x140096245 <.text+0x95245>
1400961ff:     	cmpq	0xa0(%rcx), %r10
140096206:     	jae	0x140096216 <.text+0x95216>
140096208:     	movq	0x98(%rcx), %rsi
14009620f:     	cmpb	$0x0, (%rsi,%r10)
140096214:     	jne	0x140096245 <.text+0x95245>
140096216:     	movb	$0x0, (%r11,%r10)
14009621b:     	decq	0xb0(%rcx)
140096222:     	cmpq	0x70(%rcx), %r10
140096226:     	jae	0x140096245 <.text+0x95245>
140096228:     	movq	0x68(%rcx), %r11
14009622c:     	imulq	$0x58, %r10, %r10
140096230:     	movq	$0x0, 0x30(%r11,%r10)
140096239:     	movb	$0x2, 0x52(%r11,%r10)
14009623f:     	movb	$0x2, 0x25(%r11,%r10)
140096245:     	leaq	0xc0(%rcx), %rsi
14009624c:     	movd	%xmm6, %r10d
140096251:     	addq	$0x2c, %rax
140096255:     	xorl	%r11d, %r11d
140096258:     	movq	0x248(%rbp), %r15
14009625f:     	movzbl	0x26e(%rbp), %r12d
140096267:     	jmp	0x140096282 <.text+0x95282>
140096269:     	nopl	(%rax)
140096270:     	incq	%r11
140096273:     	addq	$0x140, %rax            # imm = 0x140
140096279:     	cmpq	%r11, %r8
14009627c:     	je	0x14009630e <.text+0x9530e>
140096282:     	cmpq	%r9, %r11
140096285:     	setb	%bl
140096288:     	andb	(%rdx,%r11), %bl
14009628c:     	cmpb	$0x1, %bl
14009628f:     	jne	0x140096270 <.text+0x95270>
140096291:     	cmpl	$0x2, -0x2c(%rax)
140096295:     	je	0x140096270 <.text+0x95270>
140096297:     	cmpw	%r10w, (%rax)
14009629b:     	jne	0x140096270 <.text+0x95270>
14009629d:     	cmpl	%r14d, -0xc(%rax)
1400962a1:     	jne	0x140096270 <.text+0x95270>
1400962a3:     	movl	0x268(%rbp), %edi
1400962a9:     	cmpl	%edi, -0x8(%rax)
1400962ac:     	jne	0x140096270 <.text+0x95270>
1400962ae:     	movzwl	0x26c(%rbp), %edi
1400962b5:     	cmpw	%di, -0x4(%rax)
1400962b9:     	jne	0x140096270 <.text+0x95270>
1400962bb:     	movzbl	0x26f(%rbp), %ebx
1400962c2:     	cmpb	%bl, -0x2(%rax)
1400962c5:     	jne	0x140096270 <.text+0x95270>
1400962c7:     	movq	-0x1c(%rax), %rdi
1400962cb:     	xorq	%r15, %rdi
1400962ce:     	movq	-0x14(%rax), %rbx
1400962d2:     	xorq	0x258(%rbp), %rbx
1400962d9:     	orq	%rdi, %rbx
1400962dc:     	jne	0x140096270 <.text+0x95270>
1400962de:     	cmpq	%r8, %r11
1400962e1:     	jae	0x14009630e <.text+0x9530e>
1400962e3:     	cmpq	0x100(%rcx), %r11
1400962ea:     	jae	0x1400962fa <.text+0x952fa>
1400962ec:     	movq	0xf8(%rcx), %r8
1400962f3:     	cmpb	$0x0, (%r8,%r11)
1400962f8:     	jne	0x14009630e <.text+0x9530e>
1400962fa:     	movb	$0x0, (%rdx,%r11)
1400962ff:     	decq	0x110(%rcx)
140096306:     	movq	$0x2, -0x2c(%rax)
14009630e:     	xorps	%xmm7, %xmm7
140096311:     	movaps	%xmm7, 0x230(%rbp)
140096318:     	movb	$0x0, 0x212(%rbp)
14009631f:     	movw	%r10w, 0x210(%rbp)
140096327:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
140096330:     	movq	$0x0, 0x213(%rbp)
14009633b:     	movq	$0x8, 0x1f0(%rbp)
140096346:     	movq	$0x0, 0x1f8(%rbp)
140096351:     	movq	$0x1, 0x200(%rbp)
14009635c:     	movq	$0x0, 0x208(%rbp)
140096367:     	leaq	0x220(%rbp), %rcx
14009636e:     	leaq	0x1f0(%rbp), %rdx
140096375:     	leaq	0x230(%rbp), %r8
14009637c:     	movl	$0x10, %r9d
140096382:     	callq	0x140106080 <.text+0x105080>
140096387:     	cmpb	$0x0, 0x220(%rbp)
14009638e:     	jne	0x1400964a0 <.text+0x954a0>
140096394:     	movq	0x228(%rbp), %rdi
14009639b:     	movaps	%xmm7, 0xe0(%rbp)
1400963a2:     	movaps	%xmm7, 0xf0(%rbp)
1400963a9:     	movaps	%xmm7, 0x100(%rbp)
1400963b0:     	movaps	%xmm7, 0x110(%rbp)
1400963b7:     	movaps	%xmm7, 0x120(%rbp)
1400963be:     	movaps	%xmm7, 0x130(%rbp)
1400963c5:     	movaps	%xmm7, 0x140(%rbp)
1400963cc:     	movaps	%xmm7, 0x150(%rbp)
1400963d3:     	movaps	%xmm7, 0x160(%rbp)
1400963da:     	movaps	%xmm7, 0x170(%rbp)
1400963e1:     	movaps	%xmm7, 0x180(%rbp)
1400963e8:     	movaps	%xmm7, 0x190(%rbp)
1400963ef:     	movaps	%xmm7, 0x1a0(%rbp)
1400963f6:     	movaps	%xmm7, 0x1b0(%rbp)
1400963fd:     	movaps	%xmm7, 0x1c0(%rbp)
140096404:     	movaps	%xmm7, 0x1d0(%rbp)
14009640b:     	cmpq	$0x11, %rdi
14009640f:     	jae	0x1400964c8 <.text+0x954c8>
140096415:     	leaq	0xe0(%rbp), %rbx
14009641c:     	leaq	0x230(%rbp), %rdx
140096423:     	movq	%rbx, %rcx
140096426:     	movq	%rdi, %r8
140096429:     	callq	0x1402394a0 <.text+0x2384a0>
14009642e:     	movw	%di, 0x1e0(%rbp)
140096435:     	movq	$0x0, -0x60(%rbp)
14009643d:     	movq	0x258(%rbp), %rax
140096444:     	movq	%rax, -0x48(%rbp)
140096448:     	movq	%r15, -0x50(%rbp)
14009644c:     	movl	%r14d, -0x40(%rbp)
140096450:     	movl	0x268(%rbp), %eax
140096456:     	movl	%eax, -0x3c(%rbp)
140096459:     	movzwl	0x26c(%rbp), %eax
140096460:     	movw	%ax, -0x38(%rbp)
140096464:     	movzbl	0x26f(%rbp), %eax
14009646b:     	movb	%al, -0x36(%rbp)
14009646e:     	movb	%r12b, -0x35(%rbp)
140096472:     	movd	%xmm6, -0x34(%rbp)
140096477:     	movq	0x260(%rbp), %rax
14009647e:     	movq	%rax, -0x30(%rbp)
140096482:     	leaq	-0x28(%rbp), %rcx
140096486:     	movl	$0x108, %r8d            # imm = 0x108
14009648c:     	movq	%rbx, %rdx
14009648f:     	callq	0x1402394a0 <.text+0x2384a0>
140096494:     	leaq	-0x60(%rbp), %rdx
140096498:     	movq	%rsi, %rcx
14009649b:     	callq	0x1400116e0 <.text+0x106e0>
1400964a0:     	movb	$0x1, %al
1400964a2:     	jmp	0x1400964a6 <.text+0x954a6>
1400964a4:     	xorl	%eax, %eax
1400964a6:     	movaps	0x270(%rbp), %xmm6
1400964ad:     	movaps	0x280(%rbp), %xmm7
1400964b4:     	addq	$0x318, %rsp            # imm = 0x318
1400964bb:     	popq	%rbx
1400964bc:     	popq	%rdi
1400964bd:     	popq	%rsi
1400964be:     	popq	%r12
1400964c0:     	popq	%r13
1400964c2:     	popq	%r14
1400964c4:     	popq	%r15
1400964c6:     	popq	%rbp
1400964c7:     	retq
1400964c8:     	leaq	0x1bb699(%rip), %r9     # 0x140251b68
1400964cf:     	movl	$0x10, %r8d
1400964d5:     	xorl	%ecx, %ecx
1400964d7:     	movq	%rdi, %rdx
1400964da:     	callq	0x140239ef0 <.text+0x238ef0>
1400964df:     	ud2

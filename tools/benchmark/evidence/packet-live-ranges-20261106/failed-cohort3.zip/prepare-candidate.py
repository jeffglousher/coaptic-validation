from pathlib import Path
import hashlib, json, subprocess

root = Path(__file__).resolve().parent
repo = Path('C:/Users/jeffg/.t3/worktrees/coaptic/t3-a578955c')
fixture = Path('D:/CoapticCurrent/replay-active-copy-20261105/fixture')
baseline = 'fd7d18a72f795779e352443ebdeef9533be7fb27'
candidate = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo)
assert candidate != baseline
previous = json.loads(Path('D:/CoapticCurrent/phase-sharing-static-20261106/source-verification.json').read_text())
hashes = {}
for name in previous['source_file_hashes']:
    data = subprocess.check_output(['git', 'show', candidate+':'+name], cwd=repo).replace(b'\r\n', b'\n')
    target = fixture/'coaptic'/name
    if target.read_bytes() != data:
        target.write_bytes(data)
    hashes[name] = hashlib.sha256(target.read_bytes()).hexdigest()
assert len(hashes) == 148
patch = subprocess.check_output(['git', 'diff', '--binary', baseline, candidate], cwd=repo)
(root/'candidate.patch').write_bytes(patch)
previous.update(source=candidate, baseline=baseline, source_file_hashes=hashes, patch_sha256=hashlib.sha256(patch).hexdigest())
(root/'source-verification.json').write_text(json.dumps(previous, indent=2)+'\n')
for name, expected in json.loads((root/'fixture-sha256.json').read_text()).items():
    target = fixture/('tools/benchmark/native/servers/src/bin' if name == 'bench-core.rs' or name.startswith('bench_core') else 'probe')/name
    assert hashlib.sha256(target.read_bytes()).hexdigest() == expected, str(target)
for path in root.glob('*.py'):
    if path == Path(__file__):
        continue
    source = path.read_text()
    for old in ['0ec8618cfac85929922ff2f96d70a7403be654ec']:
        source = source.replace(old, candidate)
    path.write_text(source)
method = json.loads((root/'METHOD-BEFORE.json').read_text())
assert method['candidate'] == 'PENDING_SOURCE_PIN'
method['candidate'] = candidate
(root/'METHOD-BEFORE.json').write_text(json.dumps(method, indent=2)+'\n')
print(json.dumps({'candidate':candidate, 'source_files':len(hashes), 'fixture_files':7}))

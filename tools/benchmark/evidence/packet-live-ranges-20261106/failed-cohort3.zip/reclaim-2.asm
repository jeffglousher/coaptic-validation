
D:\CoapticCurrent\packet-full-block-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140099140:     	pushq	%rbp
140099141:     	pushq	%r15
140099143:     	pushq	%r14
140099145:     	pushq	%r13
140099147:     	pushq	%r12
140099149:     	pushq	%rsi
14009914a:     	pushq	%rdi
14009914b:     	pushq	%rbx
14009914c:     	subq	$0x318, %rsp            # imm = 0x318
140099153:     	leaq	0x80(%rsp), %rbp
14009915b:     	movaps	%xmm7, 0x280(%rbp)
140099162:     	movaps	%xmm6, 0x270(%rbp)
140099169:     	leaq	0x30(%rcx), %rdx
14009916d:     	xorl	%r8d, %r8d
140099170:     	xorl	%r11d, %r11d
140099173:     	leaq	(%r11,%r11,4), %r10
140099177:     	shlq	$0x6, %r10
14009917b:     	addq	%rdx, %r10
14009917e:     	movq	%r11, %r9
140099181:     	jmp	0x1400991a4 <.text+0x981a4>
140099183:     	nopw	%cs:(%rax,%rax)
140099190:     	incq	%r9
140099193:     	addq	$0x140, %r10            # imm = 0x140
14009919a:     	cmpq	$0x4, %r9
14009919e:     	je	0x14009922e <.text+0x9822e>
1400991a4:     	cmpb	$0x1, 0x510(%rcx,%r9)
1400991ad:     	jne	0x140099190 <.text+0x98190>
1400991af:     	movq	-0x30(%r10), %rsi
1400991b3:     	cmpq	$0x2, %rsi
1400991b7:     	je	0x140099190 <.text+0x98190>
1400991b9:     	movq	(%r10), %r11
1400991bc:     	cmpl	$0x1, %esi
1400991bf:     	setne	%bl
1400991c2:     	testq	%r11, %r11
1400991c5:     	sete	%sil
1400991c9:     	orb	%bl, %sil
1400991cc:     	cmpb	$0x1, %sil
1400991d0:     	je	0x140099190 <.text+0x98190>
1400991d2:     	movq	0x268(%rbp), %rsi
1400991d9:     	cmpq	%rsi, %r11
1400991dc:     	setae	%bl
1400991df:     	testb	%bl, %r8b
1400991e2:     	jne	0x140099214 <.text+0x98214>
1400991e4:     	movq	-0x28(%r10), %rax
1400991e8:     	movd	-0x4(%r10), %xmm6
1400991ee:     	movzbl	-0x5(%r10), %edi
1400991f3:     	movzbl	-0x6(%r10), %r15d
1400991f8:     	movzwl	-0x8(%r10), %r12d
1400991fd:     	movl	-0xc(%r10), %r13d
140099201:     	movl	-0x10(%r10), %r14d
140099205:     	movups	-0x20(%r10), %xmm0
14009920a:     	movaps	%xmm0, 0x240(%rbp)
140099211:     	movq	%r11, %rsi
140099214:     	movq	%rsi, 0x268(%rbp)
14009921b:     	leaq	0x1(%r9), %r11
14009921f:     	movb	$0x1, %r8b
140099222:     	cmpq	$0x3, %r9
140099226:     	jb	0x140099173 <.text+0x98173>
14009922c:     	jmp	0x140099238 <.text+0x98238>
14009922e:     	testb	$0x1, %r8b
140099232:     	je	0x140099478 <.text+0x98478>
140099238:     	cmpq	$0x1, %rax
14009923c:     	ja	0x140099294 <.text+0x98294>
14009923e:     	cmpb	$0x1, 0x4420(%rcx,%rax)
140099246:     	jne	0x140099294 <.text+0x98294>
140099248:     	cmpb	$0x0, 0x4422(%rcx,%rax)
140099250:     	jne	0x140099294 <.text+0x98294>
140099252:     	movb	$0x0, 0x4420(%rcx,%rax)
14009925a:     	decq	0x4418(%rcx)
140099261:     	leaq	0x3a98(%rcx), %rdx
140099268:     	movq	$0x0, 0x4398(%rcx,%rax,8)
140099274:     	leaq	(%rax,%rax,8), %r8
140099278:     	leaq	(%r8,%r8,2), %r8
14009927c:     	addq	%rax, %r8
14009927f:     	movb	$0x2, 0x95a(%rdx,%r8)
140099288:     	leaq	(%rax,%rax,2), %rax
14009928c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
140099294:     	movaps	0x240(%rbp), %xmm0
14009929b:     	movaps	%xmm0, -0x60(%rbp)
14009929f:     	movl	%r14d, %esi
1400992a2:     	movl	%r14d, -0x50(%rbp)
1400992a6:     	movl	%r13d, %r14d
1400992a9:     	movl	%r13d, -0x4c(%rbp)
1400992ad:     	movl	%r12d, %r13d
1400992b0:     	movw	%r12w, -0x48(%rbp)
1400992b5:     	movl	%r15d, %r12d
1400992b8:     	movb	%r15b, -0x46(%rbp)
1400992bc:     	movl	%edi, %r15d
1400992bf:     	movb	%dil, -0x45(%rbp)
1400992c3:     	movd	%xmm6, %edi
1400992c7:     	movd	%xmm6, -0x44(%rbp)
1400992cc:     	leaq	-0x60(%rbp), %rdx
1400992d0:     	movq	%rcx, 0x260(%rbp)
1400992d7:     	callq	0x14020d210 <.text+0x20c210>
1400992dc:     	xorps	%xmm7, %xmm7
1400992df:     	movaps	%xmm7, 0x250(%rbp)
1400992e6:     	movb	$0x0, 0x222(%rbp)
1400992ed:     	movw	%di, 0x220(%rbp)
1400992f4:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
1400992fd:     	movq	$0x0, 0x223(%rbp)
140099308:     	movq	$0x8, 0x200(%rbp)
140099313:     	movq	$0x0, 0x208(%rbp)
14009931e:     	movq	$0x1, 0x210(%rbp)
140099329:     	movq	$0x0, 0x218(%rbp)
140099334:     	leaq	0x230(%rbp), %rcx
14009933b:     	leaq	0x200(%rbp), %rdx
140099342:     	leaq	0x250(%rbp), %r8
140099349:     	movl	$0x10, %r9d
14009934f:     	callq	0x14010b630 <.text+0x10a630>
140099354:     	cmpb	$0x0, 0x230(%rbp)
14009935b:     	jne	0x140099474 <.text+0x98474>
140099361:     	movq	0x238(%rbp), %rdi
140099368:     	movaps	%xmm7, 0xe0(%rbp)
14009936f:     	movaps	%xmm7, 0xf0(%rbp)
140099376:     	movaps	%xmm7, 0x100(%rbp)
14009937d:     	movaps	%xmm7, 0x110(%rbp)
140099384:     	movaps	%xmm7, 0x120(%rbp)
14009938b:     	movaps	%xmm7, 0x130(%rbp)
140099392:     	movaps	%xmm7, 0x140(%rbp)
140099399:     	movaps	%xmm7, 0x150(%rbp)
1400993a0:     	movaps	%xmm7, 0x160(%rbp)
1400993a7:     	movaps	%xmm7, 0x170(%rbp)
1400993ae:     	movaps	%xmm7, 0x180(%rbp)
1400993b5:     	movaps	%xmm7, 0x190(%rbp)
1400993bc:     	movaps	%xmm7, 0x1a0(%rbp)
1400993c3:     	movaps	%xmm7, 0x1b0(%rbp)
1400993ca:     	movaps	%xmm7, 0x1c0(%rbp)
1400993d1:     	movaps	%xmm7, 0x1d0(%rbp)
1400993d8:     	movaps	0x240(%rbp), %xmm0
1400993df:     	movups	%xmm0, 0x1f0(%rbp)
1400993e6:     	cmpq	$0x11, %rdi
1400993ea:     	jae	0x14009949c <.text+0x9849c>
1400993f0:     	leaq	0xe0(%rbp), %rbx
1400993f7:     	leaq	0x250(%rbp), %rdx
1400993fe:     	movq	%rbx, %rcx
140099401:     	movq	%rdi, %r8
140099404:     	callq	0x140247c10 <.text+0x246c10>
140099409:     	movw	%di, 0x1e0(%rbp)
140099410:     	movq	$0x0, -0x60(%rbp)
140099418:     	movups	0x1e8(%rbp), %xmm0
14009941f:     	movups	%xmm0, -0x58(%rbp)
140099423:     	movq	0x1f8(%rbp), %rax
14009942a:     	movq	%rax, -0x48(%rbp)
14009942e:     	movl	%esi, -0x40(%rbp)
140099431:     	movl	%r14d, -0x3c(%rbp)
140099435:     	movw	%r13w, -0x38(%rbp)
14009943a:     	movb	%r12b, -0x36(%rbp)
14009943e:     	movb	%r15b, -0x35(%rbp)
140099442:     	movd	%xmm6, -0x34(%rbp)
140099447:     	movq	0x268(%rbp), %rax
14009944e:     	movq	%rax, -0x30(%rbp)
140099452:     	leaq	-0x28(%rbp), %rcx
140099456:     	movl	$0x108, %r8d            # imm = 0x108
14009945c:     	movq	%rbx, %rdx
14009945f:     	callq	0x140247c10 <.text+0x246c10>
140099464:     	leaq	-0x60(%rbp), %rdx
140099468:     	movq	0x260(%rbp), %rcx
14009946f:     	callq	0x14020cf80 <.text+0x20bf80>
140099474:     	movb	$0x1, %al
140099476:     	jmp	0x14009947a <.text+0x9847a>
140099478:     	xorl	%eax, %eax
14009947a:     	movaps	0x270(%rbp), %xmm6
140099481:     	movaps	0x280(%rbp), %xmm7
140099488:     	addq	$0x318, %rsp            # imm = 0x318
14009948f:     	popq	%rbx
140099490:     	popq	%rdi
140099491:     	popq	%rsi
140099492:     	popq	%r12
140099494:     	popq	%r13
140099496:     	popq	%r14
140099498:     	popq	%r15
14009949a:     	popq	%rbp
14009949b:     	retq
14009949c:     	leaq	0x1c66c5(%rip), %r9     # 0x14025fb68
1400994a3:     	movl	$0x10, %r8d
1400994a9:     	xorl	%ecx, %ecx
1400994ab:     	movq	%rdi, %rdx
1400994ae:     	callq	0x140248660 <.text+0x247660>
1400994b3:     	ud2

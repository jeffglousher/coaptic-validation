
D:\CoapticCurrent\packet-full-block-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140066150:     	pushq	%rbp
140066151:     	pushq	%r15
140066153:     	pushq	%r14
140066155:     	pushq	%r13
140066157:     	pushq	%r12
140066159:     	pushq	%rsi
14006615a:     	pushq	%rdi
14006615b:     	pushq	%rbx
14006615c:     	subq	$0x508, %rsp            # imm = 0x508
140066163:     	leaq	0x80(%rsp), %rbp
14006616b:     	movq	0x500(%rbp), %r12
140066172:     	movq	0x8(%r12), %rdi
140066177:     	movl	$0x3, %r10d
14006617d:     	cmpq	$0x3, %rdi
140066181:     	ja	0x140066261 <.text+0x65261>
140066187:     	cmpb	$0x1, 0x1b748(%rdx,%rdi)
14006618f:     	jne	0x140066261 <.text+0x65261>
140066195:     	movq	0x2b750(%rdx,%rdi,8), %rax
14006619d:     	cmpq	$0x4001, %rax           # imm = 0x4001
1400661a3:     	jae	0x140066438 <.text+0x65438>
1400661a9:     	movq	0x10(%r12), %r11
1400661ae:     	movq	0x18(%r12), %r15
1400661b3:     	movq	%r15, %rsi
1400661b6:     	movl	$0xb, %r10d
1400661bc:     	addq	%r11, %rsi
1400661bf:     	jb	0x140066261 <.text+0x65261>
1400661c5:     	cmpq	$0x400, %r15            # imm = 0x400
1400661cc:     	ja	0x140066261 <.text+0x65261>
1400661d2:     	cmpq	%rax, %rsi
1400661d5:     	ja	0x140066261 <.text+0x65261>
1400661db:     	movq	%r8, %r13
1400661de:     	movq	%r9, 0x470(%rbp)
1400661e5:     	movq	%rcx, 0x480(%rbp)
1400661ec:     	movzbl	0x508(%rbp), %r14d
1400661f4:     	movq	%rdi, %rax
1400661f7:     	shlq	$0xe, %rax
1400661fb:     	movq	%rdx, %rsi
1400661fe:     	leaq	(%rdx,%rax), %rbx
140066202:     	addq	$0x1b750, %rbx          # imm = 0x1B750
140066209:     	addq	%r11, %rbx
14006620c:     	movl	$0x400, %r8d            # imm = 0x400
140066212:     	cmpq	$0x400, %r15            # imm = 0x400
140066219:     	je	0x140066228 <.text+0x65228>
14006621b:     	movq	%rbp, %rcx
14006621e:     	xorl	%edx, %edx
140066220:     	callq	0x140247c22 <.text+0x246c22>
140066225:     	movq	%r15, %r8
140066228:     	movq	%rbp, %rcx
14006622b:     	movq	%rbx, %rdx
14006622e:     	callq	0x140247c10 <.text+0x246c10>
140066233:     	testb	%r14b, %r14b
140066236:     	je	0x14006627c <.text+0x6527c>
140066238:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
14006623f:     	movq	%rsi, %rcx
140066242:     	cmpq	$0x2, 0x1ac78(%rsi,%rax)
14006624b:     	jne	0x1400663ed <.text+0x653ed>
140066251:     	xorl	%edi, %edi
140066253:     	callq	0x1400959d0 <.text+0x949d0>
140066258:     	testb	$0x1, %al
14006625a:     	jne	0x14006628e <.text+0x6528e>
14006625c:     	jmp	0x140066416 <.text+0x65416>
140066261:     	movb	$0xa, (%rcx)
140066264:     	movq	%r10, 0x8(%rcx)
140066268:     	addq	$0x508, %rsp            # imm = 0x508
14006626f:     	popq	%rbx
140066270:     	popq	%rdi
140066271:     	popq	%rsi
140066272:     	popq	%r12
140066274:     	popq	%r13
140066276:     	popq	%r14
140066278:     	popq	%r15
14006627a:     	popq	%rbp
14006627b:     	retq
14006627c:     	xorl	%edi, %edi
14006627e:     	movq	%rsi, %rcx
140066281:     	callq	0x1400959d0 <.text+0x949d0>
140066286:     	testb	$0x1, %al
140066288:     	je	0x140066416 <.text+0x65416>
14006628e:     	movq	%rdx, %rbx
140066291:     	movq	0x518(%rbp), %rdx
140066298:     	movq	0x510(%rbp), %r8
14006629f:     	movzwl	0x4f8(%rbp), %ecx
1400662a6:     	movzbl	0x4f0(%rbp), %eax
1400662ad:     	movq	(%r12), %r9
1400662b1:     	movq	%rdi, 0x440(%rbp)
1400662b8:     	movq	0x478(%rbp), %r10
1400662bf:     	movq	%r10, 0x448(%rbp)
1400662c6:     	movq	%r9, 0x450(%rbp)
1400662cd:     	movb	%r14b, 0x458(%rbp)
1400662d4:     	movups	0x38(%r13), %xmm0
1400662d9:     	movups	0x44(%r13), %xmm1
1400662de:     	movups	%xmm1, 0x40c(%rbp)
1400662e5:     	movaps	%xmm0, 0x400(%rbp)
1400662ec:     	leaq	0x66(%r13), %r9
1400662f0:     	movq	0x56(%r13), %r10
1400662f4:     	movq	0x5d(%r13), %r11
1400662f8:     	movq	%r11, 0x467(%rbp)
1400662ff:     	movq	%r10, 0x460(%rbp)
140066306:     	leaq	0x460(%rbp), %r10
14006630d:     	movq	%r10, 0x70(%rsp)
140066312:     	movq	%rdx, 0x68(%rsp)
140066317:     	movq	%r8, 0x60(%rsp)
14006631c:     	movq	%r13, 0x58(%rsp)
140066321:     	leaq	0x440(%rbp), %rdx
140066328:     	movq	%rdx, 0x50(%rsp)
14006632d:     	movq	%r15, 0x48(%rsp)
140066332:     	movq	%rbp, %rdx
140066335:     	movq	%rdx, 0x40(%rsp)
14006633a:     	movq	0x470(%rbp), %rdx
140066341:     	movq	%rdx, 0x38(%rsp)
140066346:     	movq	%r9, 0x30(%rsp)
14006634b:     	movw	%cx, 0x28(%rsp)
140066350:     	movb	%al, 0x20(%rsp)
140066354:     	leaq	0x420(%rbp), %rcx
14006635b:     	leaq	0x400(%rbp), %r8
140066362:     	movq	%rsi, %rdx
140066365:     	movq	%rbx, %r9
140066368:     	callq	0x14007d380 <.text+0x7c380>
14006636d:     	cmpb	$-0x1, 0x420(%rbp)
140066374:     	je	0x140066425 <.text+0x65425>
14006637a:     	cmpb	$0x1, 0x37740(%rsi,%rbx)
140066382:     	movq	0x480(%rbp), %rax
140066389:     	jne	0x1400663d3 <.text+0x653d3>
14006638b:     	cmpb	$0x0, 0x37760(%rsi,%rbx)
140066393:     	jne	0x1400663d3 <.text+0x653d3>
140066395:     	movb	$0x0, 0x37740(%rsi,%rbx)
14006639d:     	decq	0x37788(%rsi)
1400663a4:     	leaq	0x37740(%rsi), %rcx
1400663ab:     	movq	$0x0, 0x43610(%rsi,%rbx,8)
1400663b7:     	leaq	(%rbx,%rbx,8), %rdx
1400663bb:     	leaq	(%rdx,%rdx,2), %rdx
1400663bf:     	addq	%rbx, %rdx
1400663c2:     	movb	$0x2, 0x36a(%rcx,%rdx)
1400663ca:     	leaq	(%rbx,%rbx,2), %rdx
1400663ce:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
1400663d3:     	movups	0x420(%rbp), %xmm0
1400663da:     	movups	0x430(%rbp), %xmm1
1400663e1:     	movups	%xmm1, 0x10(%rax)
1400663e5:     	movups	%xmm0, (%rax)
1400663e8:     	jmp	0x140066268 <.text+0x65268>
1400663ed:     	addq	%rcx, %rax
1400663f0:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
1400663f6:     	movq	0x98(%rax), %rax
1400663fd:     	movq	%rax, 0x478(%rbp)
140066404:     	movl	$0x1, %edi
140066409:     	callq	0x1400959d0 <.text+0x949d0>
14006640e:     	testb	$0x1, %al
140066410:     	jne	0x14006628e <.text+0x6528e>
140066416:     	movq	0x480(%rbp), %rax
14006641d:     	movb	$0x9, (%rax)
140066420:     	jmp	0x140066268 <.text+0x65268>
140066425:     	movq	0x480(%rbp), %rax
14006642c:     	movq	%rbx, 0x8(%rax)
140066430:     	movb	$-0x1, (%rax)
140066433:     	jmp	0x140066268 <.text+0x65268>
140066438:     	leaq	0x1fc809(%rip), %r9     # 0x140262c48
14006643f:     	movl	$0x4000, %r8d           # imm = 0x4000
140066445:     	xorl	%ecx, %ecx
140066447:     	movq	%rax, %rdx
14006644a:     	callq	0x140248660 <.text+0x247660>
14006644f:     	ud2

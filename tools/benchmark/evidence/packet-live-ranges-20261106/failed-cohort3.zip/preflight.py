from pathlib import Path
import json,re,subprocess
r=Path(__file__).resolve().parent;a=Path('D:/CoapticCurrent/phase-sharing-static-20261106')
def layouts(p):return {m[1]:int(m[2]) for m in re.finditer(r'^print-type-size type: `(.*)`: (\d+) bytes',p.read_text(),re.M)}
ao=layouts(a/'owner-layout.txt');bo=layouts(r/'owner-layout-2.txt')
expected={k for k in ao if k.startswith('coaptic::')}
assert expected<=bo.keys(),sorted(expected-bo.keys())
rows=[dict(owner=k,baseline=ao[k],candidate=bo[k]) for k in sorted(expected)]
assert len([k for k in expected if k.startswith('coaptic::App<')])==6
future=[]
for p,base in [('SmallDevice',15952),('Service fixed',15496),('Service allocated',15496)]:
 keys=[k for k in bo if k.startswith('{async fn body') and '::progress_async<' in k and ('Constrained' in k if p=='SmallDevice' else 'Service' in k and ('AllocMemory' in k if p.endswith('allocated') else 'AllocMemory' not in k))]
 assert len(keys)==1,keys
 future.append(dict(owner=p+' complete progress future',baseline=base,candidate=bo[keys[0]]))
print('futures',future)
assert all(x['candidate']<=x['baseline'] for x in rows)
frame_results={}
for name in ['encoder','reclaim']:
 aa=json.loads((a/(name+'-frames.json')).read_text());bb=json.loads((r/(name+'-frames.json')).read_text())
 if name=='reclaim':aa=aa['rows'];bb=bb['rows']
 def key(x):return x['symbol'].split('`',1)[1]
 ad={key(x):x['frame'] if name=='encoder' else x['candidate'] for x in aa};bd={key(x):x['frame'] if name=='encoder' else x['candidate'] for x in bb};assert set(ad)==set(bd)
 frame_results[name]=[dict(symbol=k,baseline=v,candidate=bd[k]) for k,v in ad.items()]
text=[];keep=0
p=subprocess.Popen(['llvm-pdbutil','dump','--symbols',str(r/'B/dispatch-probe.pdb')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf8',errors='replace')
for line in p.stdout:
 if ('S_GPROC32' in line or 'S_LPROC32' in line) and 'coaptic::app::dispatch_rx_io_async::async_fn$0<' in line:keep=7
 if keep:text.append(line);keep-=1
assert p.wait()==0
s=''.join(text);(r/'dispatch-symbols.txt').write_text(s);dr=[]
for c in re.split(r'(?m)(?=^\d+ \| S_[LG]PROC32)',s):
 if 'coaptic::app::dispatch_rx_io_async' not in c:continue
 profile='SmallDevice' if 'Constrained' in c else 'Service' if 'profiles::Service' in c else 'Default';storage='allocated' if 'alloc_memory::AllocMemory' in c else 'fixed';idx={('SmallDevice','fixed'):0,('Service','fixed'):1,('Default','allocated'):2,('Service','allocated'):3}[profile,storage]
 dr.append(dict(profile=profile,storage=storage,frame_bytes=int(re.search(r'\n +size = (\d+)',c)[1]),code_bytes=int(re.search(r'code size = (\d+)',c)[1]),baseline_frame_bytes=[19568,18144,26208,26240][idx],baseline_code_bytes=[66444,69560,84124,87480][idx]))
assert len(dr)==4
nongrowth=all(x['frame_bytes']<=x['baseline_frame_bytes'] for x in dr)
(r/'dispatch-preflight.json').write_text(json.dumps(dict(rows=dr,nongrowth=nongrowth),indent=2)+'\n')
a32=layouts(a/'layout32/candidate-layout.txt');b32=layouts(r/'layout32/candidate-layout.txt')
assert a32.keys()<=b32.keys(),sorted(a32.keys()-b32.keys())
r32=[dict(owner=k,baseline=v,candidate=b32[k]) for k,v in a32.items()];assert len(r32)>=5
out=dict(future_rows=future,app_rows=rows,frames=frame_results,layout32=r32,source_hashes_verified=148,dispatch_nongrowth=nongrowth)
(r/'preflight-host.json').write_text(json.dumps(out,indent=2)+'\n')
okay=all(x['candidate']<=x['baseline'] for x in future+rows+r32+sum(frame_results.values(),[])) and all(x['candidate']<x['baseline'] for x in future if x['owner'].startswith('Service')) and nongrowth
print(json.dumps(dict(memory_accepted=okay,dispatch=dr),indent=2))
(r/'memory-preflight.json').write_text(json.dumps(dict(memory_accepted=okay,source=json.loads((r/'source-verification.json').read_text())['source']),indent=2)+'\n')

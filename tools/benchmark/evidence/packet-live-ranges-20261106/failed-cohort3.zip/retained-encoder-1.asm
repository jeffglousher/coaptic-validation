
D:\CoapticCurrent\packet-full-block-20261106\B\retained-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400392e0:     	pushq	%rbp
1400392e1:     	pushq	%r15
1400392e3:     	pushq	%r14
1400392e5:     	pushq	%r13
1400392e7:     	pushq	%r12
1400392e9:     	pushq	%rsi
1400392ea:     	pushq	%rdi
1400392eb:     	pushq	%rbx
1400392ec:     	subq	$0x4f8, %rsp            # imm = 0x4F8
1400392f3:     	leaq	0x80(%rsp), %rbp
1400392fb:     	movq	0x4f0(%rbp), %r12
140039302:     	movq	0x8(%r12), %rdi
140039307:     	movl	$0x3, %r10d
14003930d:     	cmpq	$0x1, %rdi
140039311:     	ja	0x1400393f8 <.text+0x383f8>
140039317:     	cmpb	$0x1, 0x81b8(%rdx,%rdi)
14003931f:     	jne	0x1400393f8 <.text+0x383f8>
140039325:     	movq	0xe1c0(%rdx,%rdi,8), %rax
14003932d:     	cmpq	$0x3001, %rax           # imm = 0x3001
140039333:     	jae	0x1400395c0 <.text+0x385c0>
140039339:     	movq	0x10(%r12), %r11
14003933e:     	movq	0x18(%r12), %r15
140039343:     	movq	%r15, %rsi
140039346:     	movl	$0xb, %r10d
14003934c:     	addq	%r11, %rsi
14003934f:     	jb	0x1400393f8 <.text+0x383f8>
140039355:     	cmpq	$0x400, %r15            # imm = 0x400
14003935c:     	ja	0x1400393f8 <.text+0x383f8>
140039362:     	cmpq	%rax, %rsi
140039365:     	ja	0x1400393f8 <.text+0x383f8>
14003936b:     	movq	%r8, 0x468(%rbp)
140039372:     	movq	%r9, 0x460(%rbp)
140039379:     	movq	%rcx, 0x470(%rbp)
140039380:     	movzbl	0x4f8(%rbp), %r13d
140039388:     	leaq	(%rdi,%rdi,2), %rax
14003938c:     	shlq	$0xc, %rax
140039390:     	movq	%rdx, %rsi
140039393:     	leaq	(%rdx,%rax), %rbx
140039397:     	addq	$0x81c0, %rbx           # imm = 0x81C0
14003939e:     	addq	%r11, %rbx
1400393a1:     	movl	$0x400, %r8d            # imm = 0x400
1400393a7:     	cmpq	$0x400, %r15            # imm = 0x400
1400393ae:     	je	0x1400393be <.text+0x383be>
1400393b0:     	leaq	-0x10(%rbp), %rcx
1400393b4:     	xorl	%edx, %edx
1400393b6:     	callq	0x14013fc62 <.text+0x13ec62>
1400393bb:     	movq	%r15, %r8
1400393be:     	leaq	-0x10(%rbp), %rcx
1400393c2:     	movq	%rbx, %rdx
1400393c5:     	callq	0x14013fc50 <.text+0x13ec50>
1400393ca:     	testb	%r13b, %r13b
1400393cd:     	je	0x140039413 <.text+0x38413>
1400393cf:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
1400393d6:     	movq	%rsi, %rcx
1400393d9:     	cmpq	$0x2, 0x7c48(%rsi,%rax)
1400393e2:     	jne	0x14003957c <.text+0x3857c>
1400393e8:     	xorl	%edi, %edi
1400393ea:     	callq	0x140051a40 <.text+0x50a40>
1400393ef:     	testb	$0x1, %al
1400393f1:     	jne	0x140039425 <.text+0x38425>
1400393f3:     	jmp	0x14003959e <.text+0x3859e>
1400393f8:     	movb	$0xa, (%rcx)
1400393fb:     	movq	%r10, 0x8(%rcx)
1400393ff:     	addq	$0x4f8, %rsp            # imm = 0x4F8
140039406:     	popq	%rbx
140039407:     	popq	%rdi
140039408:     	popq	%rsi
140039409:     	popq	%r12
14003940b:     	popq	%r13
14003940d:     	popq	%r14
14003940f:     	popq	%r15
140039411:     	popq	%rbp
140039412:     	retq
140039413:     	xorl	%edi, %edi
140039415:     	movq	%rsi, %rcx
140039418:     	callq	0x140051a40 <.text+0x50a40>
14003941d:     	testb	$0x1, %al
14003941f:     	je	0x14003959e <.text+0x3859e>
140039425:     	movq	%rdx, %rbx
140039428:     	movq	0x500(%rbp), %rdx
14003942f:     	movzwl	0x4e8(%rbp), %ecx
140039436:     	movzbl	0x4e0(%rbp), %eax
14003943d:     	movq	(%r12), %r8
140039441:     	movq	%rdi, 0x430(%rbp)
140039448:     	movq	%r14, 0x438(%rbp)
14003944f:     	movq	%r8, 0x440(%rbp)
140039456:     	movb	%r13b, 0x448(%rbp)
14003945d:     	movq	0x468(%rbp), %r13
140039464:     	movups	0x38(%r13), %xmm0
140039469:     	movups	0x44(%r13), %xmm1
14003946e:     	movups	%xmm1, 0x3fc(%rbp)
140039475:     	movaps	%xmm0, 0x3f0(%rbp)
14003947c:     	leaq	0x66(%r13), %r8
140039480:     	movq	0x56(%r13), %r9
140039484:     	movq	0x5d(%r13), %r10
140039488:     	movq	%r10, 0x457(%rbp)
14003948f:     	movq	%r9, 0x450(%rbp)
140039496:     	leaq	0x450(%rbp), %r9
14003949d:     	movq	%r9, 0x68(%rsp)
1400394a2:     	movq	%rdx, 0x60(%rsp)
1400394a7:     	movq	%r13, 0x58(%rsp)
1400394ac:     	leaq	0x430(%rbp), %rdx
1400394b3:     	movq	%rdx, 0x50(%rsp)
1400394b8:     	movq	%r15, 0x48(%rsp)
1400394bd:     	leaq	-0x10(%rbp), %rdx
1400394c1:     	movq	%rdx, 0x40(%rsp)
1400394c6:     	movq	0x460(%rbp), %rdx
1400394cd:     	movq	%rdx, 0x38(%rsp)
1400394d2:     	movq	%r8, 0x30(%rsp)
1400394d7:     	movw	%cx, 0x28(%rsp)
1400394dc:     	movb	%al, 0x20(%rsp)
1400394e0:     	leaq	0x410(%rbp), %rcx
1400394e7:     	leaq	0x3f0(%rbp), %r8
1400394ee:     	movq	%rsi, %rdx
1400394f1:     	movq	%rbx, %r9
1400394f4:     	callq	0x140043c30 <.text+0x42c30>
1400394f9:     	cmpb	$-0x1, 0x410(%rbp)
140039500:     	je	0x1400395ad <.text+0x385ad>
140039506:     	cmpb	$0x1, 0x11410(%rsi,%rbx)
14003950e:     	movq	0x470(%rbp), %rax
140039515:     	jne	0x140039562 <.text+0x38562>
140039517:     	cmpb	$0x0, 0x11414(%rsi,%rbx)
14003951f:     	jne	0x140039562 <.text+0x38562>
140039521:     	movb	$0x0, 0x11410(%rsi,%rbx)
140039529:     	decq	0x11408(%rsi)
140039530:     	leaq	0xfc10(%rsi), %rcx
140039537:     	movq	$0x0, 0x11310(%rsi,%rbx,8)
140039543:     	leaq	(%rbx,%rbx,8), %rdx
140039547:     	leaq	(%rdx,%rdx,2), %rdx
14003954b:     	addq	%rbx, %rdx
14003954e:     	movb	$0x2, 0x179a(%rcx,%rdx)
140039556:     	leaq	(%rbx,%rbx,2), %rdx
14003955a:     	movb	$0x2, 0x172d(%rcx,%rdx,8)
140039562:     	movups	0x410(%rbp), %xmm0
140039569:     	movups	0x420(%rbp), %xmm1
140039570:     	movups	%xmm1, 0x10(%rax)
140039574:     	movups	%xmm0, (%rax)
140039577:     	jmp	0x1400393ff <.text+0x383ff>
14003957c:     	addq	%rcx, %rax
14003957f:     	addq	$0x7c48, %rax           # imm = 0x7C48
140039585:     	movq	0x98(%rax), %r14
14003958c:     	movl	$0x1, %edi
140039591:     	callq	0x140051a40 <.text+0x50a40>
140039596:     	testb	$0x1, %al
140039598:     	jne	0x140039425 <.text+0x38425>
14003959e:     	movq	0x470(%rbp), %rax
1400395a5:     	movb	$0x9, (%rax)
1400395a8:     	jmp	0x1400393ff <.text+0x383ff>
1400395ad:     	movq	0x470(%rbp), %rax
1400395b4:     	movq	%rbx, 0x8(%rax)
1400395b8:     	movb	$-0x1, (%rax)
1400395bb:     	jmp	0x1400393ff <.text+0x383ff>
1400395c0:     	leaq	0x118511(%rip), %r9     # 0x140151ad8
1400395c7:     	movl	$0x3000, %r8d           # imm = 0x3000
1400395cd:     	xorl	%ecx, %ecx
1400395cf:     	movq	%rax, %rdx
1400395d2:     	callq	0x140140710 <.text+0x13f710>
1400395d7:     	ud2


D:\CoapticCurrent\packet-full-block-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140099880:     	pushq	%rbp
140099881:     	pushq	%r15
140099883:     	pushq	%r14
140099885:     	pushq	%r13
140099887:     	pushq	%r12
140099889:     	pushq	%rsi
14009988a:     	pushq	%rdi
14009988b:     	pushq	%rbx
14009988c:     	subq	$0x318, %rsp            # imm = 0x318
140099893:     	leaq	0x80(%rsp), %rbp
14009989b:     	movaps	%xmm7, 0x280(%rbp)
1400998a2:     	movdqa	%xmm6, 0x270(%rbp)
1400998aa:     	movq	0xe8(%rcx), %r8
1400998b1:     	testq	%r8, %r8
1400998b4:     	je	0x140099c94 <.text+0x98c94>
1400998ba:     	movq	0x88(%rcx), %r11
1400998c1:     	movq	0xe0(%rcx), %rdx
1400998c8:     	movq	0xc8(%rcx), %rax
1400998cf:     	movq	0xd0(%rcx), %r9
1400998d6:     	leaq	0x30(%rax), %rsi
1400998da:     	xorl	%ebx, %ebx
1400998dc:     	xorl	%edi, %edi
1400998de:     	leaq	(%rdi,%rdi,4), %r12
1400998e2:     	shlq	$0x6, %r12
1400998e6:     	addq	%rsi, %r12
1400998e9:     	jmp	0x140099903 <.text+0x98903>
1400998eb:     	nopl	(%rax,%rax)
1400998f0:     	incq	%rdi
1400998f3:     	addq	$0x140, %r12            # imm = 0x140
1400998fa:     	cmpq	%r8, %rdi
1400998fd:     	jae	0x1400999cc <.text+0x989cc>
140099903:     	cmpq	%r9, %rdi
140099906:     	setb	%r15b
14009990a:     	andb	(%rdx,%rdi), %r15b
14009990e:     	cmpb	$0x1, %r15b
140099912:     	jne	0x1400998f0 <.text+0x988f0>
140099914:     	movq	-0x30(%r12), %r15
140099919:     	cmpq	$0x2, %r15
14009991d:     	je	0x1400998f0 <.text+0x988f0>
14009991f:     	movq	(%r12), %r13
140099923:     	cmpl	$0x1, %r15d
140099927:     	setne	%r15b
14009992b:     	testq	%r13, %r13
14009992e:     	sete	%r10b
140099932:     	orb	%r15b, %r10b
140099935:     	cmpb	$0x1, %r10b
140099939:     	je	0x1400998f0 <.text+0x988f0>
14009993b:     	movq	0x260(%rbp), %r15
140099942:     	cmpq	%r15, %r13
140099945:     	setae	%r10b
140099949:     	testb	%r10b, %bl
14009994c:     	jne	0x1400999b5 <.text+0x989b5>
14009994e:     	movq	-0x28(%r12), %r10
140099953:     	movq	%r10, 0x250(%rbp)
14009995a:     	movq	-0x20(%r12), %r10
14009995f:     	movq	%r10, 0x248(%rbp)
140099966:     	movd	-0x4(%r12), %xmm6
14009996d:     	movzbl	-0x5(%r12), %r10d
140099973:     	movb	%r10b, 0x26e(%rbp)
14009997a:     	movzbl	-0x6(%r12), %r10d
140099980:     	movb	%r10b, 0x26f(%rbp)
140099987:     	movzwl	-0x8(%r12), %r10d
14009998d:     	movw	%r10w, 0x26c(%rbp)
140099995:     	movl	-0xc(%r12), %r10d
14009999a:     	movl	%r10d, 0x268(%rbp)
1400999a1:     	movl	-0x10(%r12), %r14d
1400999a6:     	movq	-0x18(%r12), %r10
1400999ab:     	movq	%r10, 0x258(%rbp)
1400999b2:     	movq	%r13, %r15
1400999b5:     	movq	%r15, 0x260(%rbp)
1400999bc:     	incq	%rdi
1400999bf:     	movb	$0x1, %bl
1400999c1:     	cmpq	%r8, %rdi
1400999c4:     	jb	0x1400998de <.text+0x988de>
1400999ca:     	jmp	0x1400999d5 <.text+0x989d5>
1400999cc:     	testb	$0x1, %bl
1400999cf:     	je	0x140099c94 <.text+0x98c94>
1400999d5:     	movq	0x250(%rbp), %r10
1400999dc:     	cmpq	%r11, %r10
1400999df:     	jae	0x140099a35 <.text+0x98a35>
1400999e1:     	movq	0x80(%rcx), %r11
1400999e8:     	cmpb	$0x1, (%r11,%r10)
1400999ed:     	jne	0x140099a35 <.text+0x98a35>
1400999ef:     	cmpq	0xa0(%rcx), %r10
1400999f6:     	jae	0x140099a06 <.text+0x98a06>
1400999f8:     	movq	0x98(%rcx), %rsi
1400999ff:     	cmpb	$0x0, (%rsi,%r10)
140099a04:     	jne	0x140099a35 <.text+0x98a35>
140099a06:     	movb	$0x0, (%r11,%r10)
140099a0b:     	decq	0xb0(%rcx)
140099a12:     	cmpq	0x70(%rcx), %r10
140099a16:     	jae	0x140099a35 <.text+0x98a35>
140099a18:     	movq	0x68(%rcx), %r11
140099a1c:     	imulq	$0x58, %r10, %r10
140099a20:     	movq	$0x0, 0x30(%r11,%r10)
140099a29:     	movb	$0x2, 0x52(%r11,%r10)
140099a2f:     	movb	$0x2, 0x25(%r11,%r10)
140099a35:     	leaq	0xc0(%rcx), %rsi
140099a3c:     	movd	%xmm6, %r10d
140099a41:     	addq	$0x2c, %rax
140099a45:     	xorl	%r11d, %r11d
140099a48:     	movq	0x248(%rbp), %r15
140099a4f:     	movzbl	0x26e(%rbp), %r12d
140099a57:     	jmp	0x140099a72 <.text+0x98a72>
140099a59:     	nopl	(%rax)
140099a60:     	incq	%r11
140099a63:     	addq	$0x140, %rax            # imm = 0x140
140099a69:     	cmpq	%r11, %r8
140099a6c:     	je	0x140099afe <.text+0x98afe>
140099a72:     	cmpq	%r9, %r11
140099a75:     	setb	%bl
140099a78:     	andb	(%rdx,%r11), %bl
140099a7c:     	cmpb	$0x1, %bl
140099a7f:     	jne	0x140099a60 <.text+0x98a60>
140099a81:     	cmpl	$0x2, -0x2c(%rax)
140099a85:     	je	0x140099a60 <.text+0x98a60>
140099a87:     	cmpw	%r10w, (%rax)
140099a8b:     	jne	0x140099a60 <.text+0x98a60>
140099a8d:     	cmpl	%r14d, -0xc(%rax)
140099a91:     	jne	0x140099a60 <.text+0x98a60>
140099a93:     	movl	0x268(%rbp), %edi
140099a99:     	cmpl	%edi, -0x8(%rax)
140099a9c:     	jne	0x140099a60 <.text+0x98a60>
140099a9e:     	movzwl	0x26c(%rbp), %edi
140099aa5:     	cmpw	%di, -0x4(%rax)
140099aa9:     	jne	0x140099a60 <.text+0x98a60>
140099aab:     	movzbl	0x26f(%rbp), %ebx
140099ab2:     	cmpb	%bl, -0x2(%rax)
140099ab5:     	jne	0x140099a60 <.text+0x98a60>
140099ab7:     	movq	-0x1c(%rax), %rdi
140099abb:     	xorq	%r15, %rdi
140099abe:     	movq	-0x14(%rax), %rbx
140099ac2:     	xorq	0x258(%rbp), %rbx
140099ac9:     	orq	%rdi, %rbx
140099acc:     	jne	0x140099a60 <.text+0x98a60>
140099ace:     	cmpq	%r8, %r11
140099ad1:     	jae	0x140099afe <.text+0x98afe>
140099ad3:     	cmpq	0x100(%rcx), %r11
140099ada:     	jae	0x140099aea <.text+0x98aea>
140099adc:     	movq	0xf8(%rcx), %r8
140099ae3:     	cmpb	$0x0, (%r8,%r11)
140099ae8:     	jne	0x140099afe <.text+0x98afe>
140099aea:     	movb	$0x0, (%rdx,%r11)
140099aef:     	decq	0x110(%rcx)
140099af6:     	movq	$0x2, -0x2c(%rax)
140099afe:     	xorps	%xmm7, %xmm7
140099b01:     	movaps	%xmm7, 0x230(%rbp)
140099b08:     	movb	$0x0, 0x212(%rbp)
140099b0f:     	movw	%r10w, 0x210(%rbp)
140099b17:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
140099b20:     	movq	$0x0, 0x213(%rbp)
140099b2b:     	movq	$0x8, 0x1f0(%rbp)
140099b36:     	movq	$0x0, 0x1f8(%rbp)
140099b41:     	movq	$0x1, 0x200(%rbp)
140099b4c:     	movq	$0x0, 0x208(%rbp)
140099b57:     	leaq	0x220(%rbp), %rcx
140099b5e:     	leaq	0x1f0(%rbp), %rdx
140099b65:     	leaq	0x230(%rbp), %r8
140099b6c:     	movl	$0x10, %r9d
140099b72:     	callq	0x14010b630 <.text+0x10a630>
140099b77:     	cmpb	$0x0, 0x220(%rbp)
140099b7e:     	jne	0x140099c90 <.text+0x98c90>
140099b84:     	movq	0x228(%rbp), %rdi
140099b8b:     	movaps	%xmm7, 0xe0(%rbp)
140099b92:     	movaps	%xmm7, 0xf0(%rbp)
140099b99:     	movaps	%xmm7, 0x100(%rbp)
140099ba0:     	movaps	%xmm7, 0x110(%rbp)
140099ba7:     	movaps	%xmm7, 0x120(%rbp)
140099bae:     	movaps	%xmm7, 0x130(%rbp)
140099bb5:     	movaps	%xmm7, 0x140(%rbp)
140099bbc:     	movaps	%xmm7, 0x150(%rbp)
140099bc3:     	movaps	%xmm7, 0x160(%rbp)
140099bca:     	movaps	%xmm7, 0x170(%rbp)
140099bd1:     	movaps	%xmm7, 0x180(%rbp)
140099bd8:     	movaps	%xmm7, 0x190(%rbp)
140099bdf:     	movaps	%xmm7, 0x1a0(%rbp)
140099be6:     	movaps	%xmm7, 0x1b0(%rbp)
140099bed:     	movaps	%xmm7, 0x1c0(%rbp)
140099bf4:     	movaps	%xmm7, 0x1d0(%rbp)
140099bfb:     	cmpq	$0x11, %rdi
140099bff:     	jae	0x140099cb8 <.text+0x98cb8>
140099c05:     	leaq	0xe0(%rbp), %rbx
140099c0c:     	leaq	0x230(%rbp), %rdx
140099c13:     	movq	%rbx, %rcx
140099c16:     	movq	%rdi, %r8
140099c19:     	callq	0x140247c10 <.text+0x246c10>
140099c1e:     	movw	%di, 0x1e0(%rbp)
140099c25:     	movq	$0x0, -0x60(%rbp)
140099c2d:     	movq	0x258(%rbp), %rax
140099c34:     	movq	%rax, -0x48(%rbp)
140099c38:     	movq	%r15, -0x50(%rbp)
140099c3c:     	movl	%r14d, -0x40(%rbp)
140099c40:     	movl	0x268(%rbp), %eax
140099c46:     	movl	%eax, -0x3c(%rbp)
140099c49:     	movzwl	0x26c(%rbp), %eax
140099c50:     	movw	%ax, -0x38(%rbp)
140099c54:     	movzbl	0x26f(%rbp), %eax
140099c5b:     	movb	%al, -0x36(%rbp)
140099c5e:     	movb	%r12b, -0x35(%rbp)
140099c62:     	movd	%xmm6, -0x34(%rbp)
140099c67:     	movq	0x260(%rbp), %rax
140099c6e:     	movq	%rax, -0x30(%rbp)
140099c72:     	leaq	-0x28(%rbp), %rcx
140099c76:     	movl	$0x108, %r8d            # imm = 0x108
140099c7c:     	movq	%rbx, %rdx
140099c7f:     	callq	0x140247c10 <.text+0x246c10>
140099c84:     	leaq	-0x60(%rbp), %rdx
140099c88:     	movq	%rsi, %rcx
140099c8b:     	callq	0x1400116e0 <.text+0x106e0>
140099c90:     	movb	$0x1, %al
140099c92:     	jmp	0x140099c96 <.text+0x98c96>
140099c94:     	xorl	%eax, %eax
140099c96:     	movaps	0x270(%rbp), %xmm6
140099c9d:     	movaps	0x280(%rbp), %xmm7
140099ca4:     	addq	$0x318, %rsp            # imm = 0x318
140099cab:     	popq	%rbx
140099cac:     	popq	%rdi
140099cad:     	popq	%rsi
140099cae:     	popq	%r12
140099cb0:     	popq	%r13
140099cb2:     	popq	%r14
140099cb4:     	popq	%r15
140099cb6:     	popq	%rbp
140099cb7:     	retq
140099cb8:     	leaq	0x1c5ea9(%rip), %r9     # 0x14025fb68
140099cbf:     	movl	$0x10, %r8d
140099cc5:     	xorl	%ecx, %ecx
140099cc7:     	movq	%rdi, %rdx
140099cca:     	callq	0x140248660 <.text+0x247660>
140099ccf:     	ud2


D:\CoapticCurrent\packet-full-block-20261106\B\retained-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140038fd0:     	pushq	%rbp
140038fd1:     	pushq	%r15
140038fd3:     	pushq	%r14
140038fd5:     	pushq	%r13
140038fd7:     	pushq	%r12
140038fd9:     	pushq	%rsi
140038fda:     	pushq	%rdi
140038fdb:     	pushq	%rbx
140038fdc:     	subq	$0x508, %rsp            # imm = 0x508
140038fe3:     	leaq	0x80(%rsp), %rbp
140038feb:     	movq	0x500(%rbp), %r12
140038ff2:     	movq	0x8(%r12), %rdi
140038ff7:     	movl	$0x3, %r10d
140038ffd:     	cmpq	$0x1, %rdi
140039001:     	ja	0x1400390e2 <.text+0x380e2>
140039007:     	cmpb	$0x1, 0x81b8(%rdx,%rdi)
14003900f:     	jne	0x1400390e2 <.text+0x380e2>
140039015:     	movq	0xe1c0(%rdx,%rdi,8), %rax
14003901d:     	cmpq	$0x3001, %rax           # imm = 0x3001
140039023:     	jae	0x1400392bc <.text+0x382bc>
140039029:     	movq	0x10(%r12), %r11
14003902e:     	movq	0x18(%r12), %r15
140039033:     	movq	%r15, %rsi
140039036:     	movl	$0xb, %r10d
14003903c:     	addq	%r11, %rsi
14003903f:     	jb	0x1400390e2 <.text+0x380e2>
140039045:     	cmpq	$0x400, %r15            # imm = 0x400
14003904c:     	ja	0x1400390e2 <.text+0x380e2>
140039052:     	cmpq	%rax, %rsi
140039055:     	ja	0x1400390e2 <.text+0x380e2>
14003905b:     	movq	%r8, %r13
14003905e:     	movq	%r9, 0x470(%rbp)
140039065:     	movq	%rcx, 0x480(%rbp)
14003906c:     	movzbl	0x508(%rbp), %r14d
140039074:     	leaq	(%rdi,%rdi,2), %rax
140039078:     	shlq	$0xc, %rax
14003907c:     	movq	%rdx, %rsi
14003907f:     	leaq	(%rdx,%rax), %rbx
140039083:     	addq	$0x81c0, %rbx           # imm = 0x81C0
14003908a:     	addq	%r11, %rbx
14003908d:     	movl	$0x400, %r8d            # imm = 0x400
140039093:     	cmpq	$0x400, %r15            # imm = 0x400
14003909a:     	je	0x1400390a9 <.text+0x380a9>
14003909c:     	movq	%rbp, %rcx
14003909f:     	xorl	%edx, %edx
1400390a1:     	callq	0x14013fc62 <.text+0x13ec62>
1400390a6:     	movq	%r15, %r8
1400390a9:     	movq	%rbp, %rcx
1400390ac:     	movq	%rbx, %rdx
1400390af:     	callq	0x14013fc50 <.text+0x13ec50>
1400390b4:     	testb	%r14b, %r14b
1400390b7:     	je	0x1400390fd <.text+0x380fd>
1400390b9:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
1400390c0:     	movq	%rsi, %rcx
1400390c3:     	cmpq	$0x2, 0x7c48(%rsi,%rax)
1400390cc:     	jne	0x140039271 <.text+0x38271>
1400390d2:     	xorl	%edi, %edi
1400390d4:     	callq	0x140051a40 <.text+0x50a40>
1400390d9:     	testb	$0x1, %al
1400390db:     	jne	0x14003910f <.text+0x3810f>
1400390dd:     	jmp	0x14003929a <.text+0x3829a>
1400390e2:     	movb	$0xa, (%rcx)
1400390e5:     	movq	%r10, 0x8(%rcx)
1400390e9:     	addq	$0x508, %rsp            # imm = 0x508
1400390f0:     	popq	%rbx
1400390f1:     	popq	%rdi
1400390f2:     	popq	%rsi
1400390f3:     	popq	%r12
1400390f5:     	popq	%r13
1400390f7:     	popq	%r14
1400390f9:     	popq	%r15
1400390fb:     	popq	%rbp
1400390fc:     	retq
1400390fd:     	xorl	%edi, %edi
1400390ff:     	movq	%rsi, %rcx
140039102:     	callq	0x140051a40 <.text+0x50a40>
140039107:     	testb	$0x1, %al
140039109:     	je	0x14003929a <.text+0x3829a>
14003910f:     	movq	%rdx, %rbx
140039112:     	movq	0x518(%rbp), %rdx
140039119:     	movq	0x510(%rbp), %r8
140039120:     	movzwl	0x4f8(%rbp), %ecx
140039127:     	movzbl	0x4f0(%rbp), %eax
14003912e:     	movq	(%r12), %r9
140039132:     	movq	%rdi, 0x440(%rbp)
140039139:     	movq	0x478(%rbp), %r10
140039140:     	movq	%r10, 0x448(%rbp)
140039147:     	movq	%r9, 0x450(%rbp)
14003914e:     	movb	%r14b, 0x458(%rbp)
140039155:     	movups	0x38(%r13), %xmm0
14003915a:     	movups	0x44(%r13), %xmm1
14003915f:     	movups	%xmm1, 0x40c(%rbp)
140039166:     	movaps	%xmm0, 0x400(%rbp)
14003916d:     	leaq	0x66(%r13), %r9
140039171:     	movq	0x56(%r13), %r10
140039175:     	movq	0x5d(%r13), %r11
140039179:     	movq	%r11, 0x467(%rbp)
140039180:     	movq	%r10, 0x460(%rbp)
140039187:     	leaq	0x460(%rbp), %r10
14003918e:     	movq	%r10, 0x70(%rsp)
140039193:     	movq	%rdx, 0x68(%rsp)
140039198:     	movq	%r8, 0x60(%rsp)
14003919d:     	movq	%r13, 0x58(%rsp)
1400391a2:     	leaq	0x440(%rbp), %rdx
1400391a9:     	movq	%rdx, 0x50(%rsp)
1400391ae:     	movq	%r15, 0x48(%rsp)
1400391b3:     	movq	%rbp, %rdx
1400391b6:     	movq	%rdx, 0x40(%rsp)
1400391bb:     	movq	0x470(%rbp), %rdx
1400391c2:     	movq	%rdx, 0x38(%rsp)
1400391c7:     	movq	%r9, 0x30(%rsp)
1400391cc:     	movw	%cx, 0x28(%rsp)
1400391d1:     	movb	%al, 0x20(%rsp)
1400391d5:     	leaq	0x420(%rbp), %rcx
1400391dc:     	leaq	0x400(%rbp), %r8
1400391e3:     	movq	%rsi, %rdx
1400391e6:     	movq	%rbx, %r9
1400391e9:     	callq	0x140042440 <.text+0x41440>
1400391ee:     	cmpb	$-0x1, 0x420(%rbp)
1400391f5:     	je	0x1400392a9 <.text+0x382a9>
1400391fb:     	cmpb	$0x1, 0x11410(%rsi,%rbx)
140039203:     	movq	0x480(%rbp), %rax
14003920a:     	jne	0x140039257 <.text+0x38257>
14003920c:     	cmpb	$0x0, 0x11414(%rsi,%rbx)
140039214:     	jne	0x140039257 <.text+0x38257>
140039216:     	movb	$0x0, 0x11410(%rsi,%rbx)
14003921e:     	decq	0x11408(%rsi)
140039225:     	leaq	0xfc10(%rsi), %rcx
14003922c:     	movq	$0x0, 0x11310(%rsi,%rbx,8)
140039238:     	leaq	(%rbx,%rbx,8), %rdx
14003923c:     	leaq	(%rdx,%rdx,2), %rdx
140039240:     	addq	%rbx, %rdx
140039243:     	movb	$0x2, 0x179a(%rcx,%rdx)
14003924b:     	leaq	(%rbx,%rbx,2), %rdx
14003924f:     	movb	$0x2, 0x172d(%rcx,%rdx,8)
140039257:     	movups	0x420(%rbp), %xmm0
14003925e:     	movups	0x430(%rbp), %xmm1
140039265:     	movups	%xmm1, 0x10(%rax)
140039269:     	movups	%xmm0, (%rax)
14003926c:     	jmp	0x1400390e9 <.text+0x380e9>
140039271:     	addq	%rcx, %rax
140039274:     	addq	$0x7c48, %rax           # imm = 0x7C48
14003927a:     	movq	0x98(%rax), %rax
140039281:     	movq	%rax, 0x478(%rbp)
140039288:     	movl	$0x1, %edi
14003928d:     	callq	0x140051a40 <.text+0x50a40>
140039292:     	testb	$0x1, %al
140039294:     	jne	0x14003910f <.text+0x3810f>
14003929a:     	movq	0x480(%rbp), %rax
1400392a1:     	movb	$0x9, (%rax)
1400392a4:     	jmp	0x1400390e9 <.text+0x380e9>
1400392a9:     	movq	0x480(%rbp), %rax
1400392b0:     	movq	%rbx, 0x8(%rax)
1400392b4:     	movb	$-0x1, (%rax)
1400392b7:     	jmp	0x1400390e9 <.text+0x380e9>
1400392bc:     	leaq	0x118815(%rip), %r9     # 0x140151ad8
1400392c3:     	movl	$0x3000, %r8d           # imm = 0x3000
1400392c9:     	xorl	%ecx, %ecx
1400392cb:     	movq	%rax, %rdx
1400392ce:     	callq	0x140140710 <.text+0x13f710>
1400392d3:     	ud2


D:\CoapticCurrent\packet-full-block-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140066460:     	pushq	%rbp
140066461:     	pushq	%r15
140066463:     	pushq	%r14
140066465:     	pushq	%r13
140066467:     	pushq	%r12
140066469:     	pushq	%rsi
14006646a:     	pushq	%rdi
14006646b:     	pushq	%rbx
14006646c:     	subq	$0x4f8, %rsp            # imm = 0x4F8
140066473:     	leaq	0x80(%rsp), %rbp
14006647b:     	movq	0x4f0(%rbp), %r12
140066482:     	movq	0x8(%r12), %rdi
140066487:     	movl	$0x3, %r10d
14006648d:     	cmpq	$0x3, %rdi
140066491:     	ja	0x140066573 <.text+0x65573>
140066497:     	cmpb	$0x1, 0x1b748(%rdx,%rdi)
14006649f:     	jne	0x140066573 <.text+0x65573>
1400664a5:     	movq	0x2b750(%rdx,%rdi,8), %rax
1400664ad:     	cmpq	$0x4001, %rax           # imm = 0x4001
1400664b3:     	jae	0x14006673f <.text+0x6573f>
1400664b9:     	movq	0x10(%r12), %r11
1400664be:     	movq	0x18(%r12), %r15
1400664c3:     	movq	%r15, %rsi
1400664c6:     	movl	$0xb, %r10d
1400664cc:     	addq	%r11, %rsi
1400664cf:     	jb	0x140066573 <.text+0x65573>
1400664d5:     	cmpq	$0x400, %r15            # imm = 0x400
1400664dc:     	ja	0x140066573 <.text+0x65573>
1400664e2:     	cmpq	%rax, %rsi
1400664e5:     	ja	0x140066573 <.text+0x65573>
1400664eb:     	movq	%r8, %r13
1400664ee:     	movq	%r9, 0x460(%rbp)
1400664f5:     	movq	%rcx, 0x470(%rbp)
1400664fc:     	movzbl	0x4f8(%rbp), %r14d
140066504:     	movq	%rdi, %rax
140066507:     	shlq	$0xe, %rax
14006650b:     	movq	%rdx, %rsi
14006650e:     	leaq	(%rdx,%rax), %rbx
140066512:     	addq	$0x1b750, %rbx          # imm = 0x1B750
140066519:     	addq	%r11, %rbx
14006651c:     	movl	$0x400, %r8d            # imm = 0x400
140066522:     	cmpq	$0x400, %r15            # imm = 0x400
140066529:     	je	0x140066539 <.text+0x65539>
14006652b:     	leaq	-0x10(%rbp), %rcx
14006652f:     	xorl	%edx, %edx
140066531:     	callq	0x140247c22 <.text+0x246c22>
140066536:     	movq	%r15, %r8
140066539:     	leaq	-0x10(%rbp), %rcx
14006653d:     	movq	%rbx, %rdx
140066540:     	callq	0x140247c10 <.text+0x246c10>
140066545:     	testb	%r14b, %r14b
140066548:     	je	0x14006658e <.text+0x6558e>
14006654a:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
140066551:     	movq	%rsi, %rcx
140066554:     	cmpq	$0x2, 0x1ac78(%rsi,%rax)
14006655d:     	jne	0x1400666f4 <.text+0x656f4>
140066563:     	xorl	%edi, %edi
140066565:     	callq	0x1400959d0 <.text+0x949d0>
14006656a:     	testb	$0x1, %al
14006656c:     	jne	0x1400665a0 <.text+0x655a0>
14006656e:     	jmp	0x14006671d <.text+0x6571d>
140066573:     	movb	$0xa, (%rcx)
140066576:     	movq	%r10, 0x8(%rcx)
14006657a:     	addq	$0x4f8, %rsp            # imm = 0x4F8
140066581:     	popq	%rbx
140066582:     	popq	%rdi
140066583:     	popq	%rsi
140066584:     	popq	%r12
140066586:     	popq	%r13
140066588:     	popq	%r14
14006658a:     	popq	%r15
14006658c:     	popq	%rbp
14006658d:     	retq
14006658e:     	xorl	%edi, %edi
140066590:     	movq	%rsi, %rcx
140066593:     	callq	0x1400959d0 <.text+0x949d0>
140066598:     	testb	$0x1, %al
14006659a:     	je	0x14006671d <.text+0x6571d>
1400665a0:     	movq	%rdx, %rbx
1400665a3:     	movq	0x500(%rbp), %rdx
1400665aa:     	movzwl	0x4e8(%rbp), %ecx
1400665b1:     	movzbl	0x4e0(%rbp), %eax
1400665b8:     	movq	(%r12), %r8
1400665bc:     	movq	%rdi, 0x430(%rbp)
1400665c3:     	movq	0x468(%rbp), %r9
1400665ca:     	movq	%r9, 0x438(%rbp)
1400665d1:     	movq	%r8, 0x440(%rbp)
1400665d8:     	movb	%r14b, 0x448(%rbp)
1400665df:     	movups	0x38(%r13), %xmm0
1400665e4:     	movups	0x44(%r13), %xmm1
1400665e9:     	movups	%xmm1, 0x3fc(%rbp)
1400665f0:     	movaps	%xmm0, 0x3f0(%rbp)
1400665f7:     	leaq	0x66(%r13), %r8
1400665fb:     	movq	0x56(%r13), %r9
1400665ff:     	movq	0x5d(%r13), %r10
140066603:     	movq	%r10, 0x457(%rbp)
14006660a:     	movq	%r9, 0x450(%rbp)
140066611:     	leaq	0x450(%rbp), %r9
140066618:     	movq	%r9, 0x68(%rsp)
14006661d:     	movq	%rdx, 0x60(%rsp)
140066622:     	movq	%r13, 0x58(%rsp)
140066627:     	leaq	0x430(%rbp), %rdx
14006662e:     	movq	%rdx, 0x50(%rsp)
140066633:     	movq	%r15, 0x48(%rsp)
140066638:     	leaq	-0x10(%rbp), %rdx
14006663c:     	movq	%rdx, 0x40(%rsp)
140066641:     	movq	0x460(%rbp), %rdx
140066648:     	movq	%rdx, 0x38(%rsp)
14006664d:     	movq	%r8, 0x30(%rsp)
140066652:     	movw	%cx, 0x28(%rsp)
140066657:     	movb	%al, 0x20(%rsp)
14006665b:     	leaq	0x410(%rbp), %rcx
140066662:     	leaq	0x3f0(%rbp), %r8
140066669:     	movq	%rsi, %rdx
14006666c:     	movq	%rbx, %r9
14006666f:     	callq	0x14007eb70 <.text+0x7db70>
140066674:     	cmpb	$-0x1, 0x410(%rbp)
14006667b:     	je	0x14006672c <.text+0x6572c>
140066681:     	cmpb	$0x1, 0x37740(%rsi,%rbx)
140066689:     	movq	0x470(%rbp), %rax
140066690:     	jne	0x1400666da <.text+0x656da>
140066692:     	cmpb	$0x0, 0x37760(%rsi,%rbx)
14006669a:     	jne	0x1400666da <.text+0x656da>
14006669c:     	movb	$0x0, 0x37740(%rsi,%rbx)
1400666a4:     	decq	0x37788(%rsi)
1400666ab:     	leaq	0x37740(%rsi), %rcx
1400666b2:     	movq	$0x0, 0x43610(%rsi,%rbx,8)
1400666be:     	leaq	(%rbx,%rbx,8), %rdx
1400666c2:     	leaq	(%rdx,%rdx,2), %rdx
1400666c6:     	addq	%rbx, %rdx
1400666c9:     	movb	$0x2, 0x36a(%rcx,%rdx)
1400666d1:     	leaq	(%rbx,%rbx,2), %rdx
1400666d5:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
1400666da:     	movups	0x410(%rbp), %xmm0
1400666e1:     	movups	0x420(%rbp), %xmm1
1400666e8:     	movups	%xmm1, 0x10(%rax)
1400666ec:     	movups	%xmm0, (%rax)
1400666ef:     	jmp	0x14006657a <.text+0x6557a>
1400666f4:     	addq	%rcx, %rax
1400666f7:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
1400666fd:     	movq	0x98(%rax), %rax
140066704:     	movq	%rax, 0x468(%rbp)
14006670b:     	movl	$0x1, %edi
140066710:     	callq	0x1400959d0 <.text+0x949d0>
140066715:     	testb	$0x1, %al
140066717:     	jne	0x1400665a0 <.text+0x655a0>
14006671d:     	movq	0x470(%rbp), %rax
140066724:     	movb	$0x9, (%rax)
140066727:     	jmp	0x14006657a <.text+0x6557a>
14006672c:     	movq	0x470(%rbp), %rax
140066733:     	movq	%rbx, 0x8(%rax)
140066737:     	movb	$-0x1, (%rax)
14006673a:     	jmp	0x14006657a <.text+0x6557a>
14006673f:     	leaq	0x1fc502(%rip), %r9     # 0x140262c48
140066746:     	movl	$0x4000, %r8d           # imm = 0x4000
14006674c:     	xorl	%ecx, %ecx
14006674e:     	movq	%rax, %rdx
140066751:     	callq	0x140248660 <.text+0x247660>
140066756:     	ud2

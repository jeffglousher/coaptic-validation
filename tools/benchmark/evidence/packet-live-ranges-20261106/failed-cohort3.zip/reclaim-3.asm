
D:\CoapticCurrent\packet-full-block-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400994c0:     	pushq	%rbp
1400994c1:     	pushq	%r15
1400994c3:     	pushq	%r14
1400994c5:     	pushq	%r13
1400994c7:     	pushq	%r12
1400994c9:     	pushq	%rsi
1400994ca:     	pushq	%rdi
1400994cb:     	pushq	%rbx
1400994cc:     	subq	$0x308, %rsp            # imm = 0x308
1400994d3:     	leaq	0x80(%rsp), %rbp
1400994db:     	movaps	%xmm7, 0x270(%rbp)
1400994e2:     	movaps	%xmm6, 0x260(%rbp)
1400994e9:     	leaq	0x5000(%rcx), %rax
1400994f0:     	leaq	0x30(%rcx), %r8
1400994f4:     	xorl	%r9d, %r9d
1400994f7:     	xorl	%esi, %esi
1400994f9:     	leaq	(%rsi,%rsi,4), %r11
1400994fd:     	shlq	$0x6, %r11
140099501:     	addq	%r8, %r11
140099504:     	movq	%rsi, %r10
140099507:     	jmp	0x140099524 <.text+0x98524>
140099509:     	nopl	(%rax)
140099510:     	incq	%r10
140099513:     	addq	$0x140, %r11            # imm = 0x140
14009951a:     	cmpq	$0x40, %r10
14009951e:     	je	0x1400995be <.text+0x985be>
140099524:     	cmpb	$0x1, 0x5000(%rcx,%r10)
14009952d:     	jne	0x140099510 <.text+0x98510>
14009952f:     	movq	-0x30(%r11), %rdi
140099533:     	cmpq	$0x2, %rdi
140099537:     	je	0x140099510 <.text+0x98510>
140099539:     	movq	(%r11), %rsi
14009953c:     	cmpl	$0x1, %edi
14009953f:     	setne	%bl
140099542:     	testq	%rsi, %rsi
140099545:     	sete	%dil
140099549:     	orb	%bl, %dil
14009954c:     	cmpb	$0x1, %dil
140099550:     	je	0x140099510 <.text+0x98510>
140099552:     	movq	0x250(%rbp), %rdi
140099559:     	cmpq	%rdi, %rsi
14009955c:     	setae	%bl
14009955f:     	testb	%bl, %r9b
140099562:     	jne	0x1400995a4 <.text+0x985a4>
140099564:     	movd	-0x4(%r11), %xmm6
14009956a:     	movzbl	-0x5(%r11), %edx
14009956f:     	movb	%dl, 0x25f(%rbp)
140099575:     	movzbl	-0x6(%r11), %r15d
14009957a:     	movzwl	-0x8(%r11), %r12d
14009957f:     	movl	-0xc(%r11), %r13d
140099583:     	movl	-0x10(%r11), %r14d
140099587:     	movq	-0x18(%r11), %rdx
14009958b:     	movq	%rdx, 0x248(%rbp)
140099592:     	movq	-0x28(%r11), %rdx
140099596:     	movq	-0x20(%r11), %r9
14009959a:     	movq	%r9, 0x240(%rbp)
1400995a1:     	movq	%rsi, %rdi
1400995a4:     	movq	%rdi, 0x250(%rbp)
1400995ab:     	leaq	0x1(%r10), %rsi
1400995af:     	movb	$0x1, %r9b
1400995b2:     	cmpq	$0x3f, %r10
1400995b6:     	jb	0x1400994f9 <.text+0x984f9>
1400995bc:     	jmp	0x1400995c8 <.text+0x985c8>
1400995be:     	testb	$0x1, %r9b
1400995c2:     	je	0x140099840 <.text+0x98840>
1400995c8:     	cmpq	$0x1f, %rdx
1400995cc:     	ja	0x14009961f <.text+0x9861f>
1400995ce:     	leaq	0x37740(%rcx), %r8
1400995d5:     	cmpb	$0x1, (%r8,%rdx)
1400995da:     	jne	0x14009961f <.text+0x9861f>
1400995dc:     	cmpb	$0x0, 0x37760(%rcx,%rdx)
1400995e4:     	jne	0x14009961f <.text+0x9861f>
1400995e6:     	movb	$0x0, 0x37740(%rcx,%rdx)
1400995ee:     	decq	0x37788(%rcx)
1400995f5:     	movq	$0x0, 0x43610(%rcx,%rdx,8)
140099601:     	leaq	(%rdx,%rdx,8), %r9
140099605:     	leaq	(%r9,%r9,2), %r9
140099609:     	addq	%rdx, %r9
14009960c:     	movb	$0x2, 0x36a(%r8,%r9)
140099615:     	leaq	(%rdx,%rdx,2), %rdx
140099619:     	movb	$0x2, 0x5d(%r8,%rdx,8)
14009961f:     	movd	%xmm6, %edx
140099623:     	movl	$0x2c, %r8d
140099629:     	movq	0x240(%rbp), %r11
140099630:     	movq	0x248(%rbp), %rsi
140099637:     	jmp	0x140099653 <.text+0x98653>
140099639:     	nopl	(%rax)
140099640:     	incq	%rax
140099643:     	addq	$0x140, %r8             # imm = 0x140
14009964a:     	cmpq	$0x502c, %r8            # imm = 0x502C
140099651:     	je	0x1400996ac <.text+0x986ac>
140099653:     	cmpb	$0x1, (%rax)
140099656:     	jne	0x140099640 <.text+0x98640>
140099658:     	cmpl	$0x2, -0x2c(%rcx,%r8)
14009965e:     	je	0x140099640 <.text+0x98640>
140099660:     	cmpw	%dx, (%rcx,%r8)
140099665:     	jne	0x140099640 <.text+0x98640>
140099667:     	cmpl	%r14d, -0xc(%rcx,%r8)
14009966c:     	jne	0x140099640 <.text+0x98640>
14009966e:     	cmpl	%r13d, -0x8(%rcx,%r8)
140099673:     	jne	0x140099640 <.text+0x98640>
140099675:     	cmpw	%r12w, -0x4(%rcx,%r8)
14009967b:     	jne	0x140099640 <.text+0x98640>
14009967d:     	cmpb	%r15b, -0x2(%rcx,%r8)
140099682:     	jne	0x140099640 <.text+0x98640>
140099684:     	movq	-0x1c(%rcx,%r8), %r9
140099689:     	xorq	%r11, %r9
14009968c:     	movq	-0x14(%rcx,%r8), %r10
140099691:     	xorq	%rsi, %r10
140099694:     	orq	%r9, %r10
140099697:     	jne	0x140099640 <.text+0x98640>
140099699:     	movb	$0x0, (%rax)
14009969c:     	decq	0x5048(%rcx)
1400996a3:     	movq	$0x2, -0x2c(%rcx,%r8)
1400996ac:     	movq	%rcx, %rsi
1400996af:     	xorps	%xmm7, %xmm7
1400996b2:     	movaps	%xmm7, 0x230(%rbp)
1400996b9:     	movb	$0x0, 0x212(%rbp)
1400996c0:     	movw	%dx, 0x210(%rbp)
1400996c7:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
1400996d0:     	movq	$0x0, 0x213(%rbp)
1400996db:     	movq	$0x8, 0x1f0(%rbp)
1400996e6:     	movq	$0x0, 0x1f8(%rbp)
1400996f1:     	movq	$0x1, 0x200(%rbp)
1400996fc:     	movq	$0x0, 0x208(%rbp)
140099707:     	leaq	0x220(%rbp), %rcx
14009970e:     	leaq	0x1f0(%rbp), %rdx
140099715:     	leaq	0x230(%rbp), %r8
14009971c:     	movl	$0x10, %r9d
140099722:     	callq	0x14010b630 <.text+0x10a630>
140099727:     	cmpb	$0x0, 0x220(%rbp)
14009972e:     	jne	0x14009983c <.text+0x9883c>
140099734:     	movq	0x228(%rbp), %rdi
14009973b:     	movaps	%xmm7, 0xe0(%rbp)
140099742:     	movaps	%xmm7, 0xf0(%rbp)
140099749:     	movaps	%xmm7, 0x100(%rbp)
140099750:     	movaps	%xmm7, 0x110(%rbp)
140099757:     	movaps	%xmm7, 0x120(%rbp)
14009975e:     	movaps	%xmm7, 0x130(%rbp)
140099765:     	movaps	%xmm7, 0x140(%rbp)
14009976c:     	movaps	%xmm7, 0x150(%rbp)
140099773:     	movaps	%xmm7, 0x160(%rbp)
14009977a:     	movaps	%xmm7, 0x170(%rbp)
140099781:     	movaps	%xmm7, 0x180(%rbp)
140099788:     	movaps	%xmm7, 0x190(%rbp)
14009978f:     	movaps	%xmm7, 0x1a0(%rbp)
140099796:     	movaps	%xmm7, 0x1b0(%rbp)
14009979d:     	movaps	%xmm7, 0x1c0(%rbp)
1400997a4:     	movaps	%xmm7, 0x1d0(%rbp)
1400997ab:     	cmpq	$0x11, %rdi
1400997af:     	jae	0x140099864 <.text+0x98864>
1400997b5:     	leaq	0xe0(%rbp), %rbx
1400997bc:     	leaq	0x230(%rbp), %rdx
1400997c3:     	movq	%rbx, %rcx
1400997c6:     	movq	%rdi, %r8
1400997c9:     	callq	0x140247c10 <.text+0x246c10>
1400997ce:     	movw	%di, 0x1e0(%rbp)
1400997d5:     	movq	$0x0, -0x60(%rbp)
1400997dd:     	movq	0x248(%rbp), %rax
1400997e4:     	movq	%rax, -0x48(%rbp)
1400997e8:     	movq	0x240(%rbp), %rax
1400997ef:     	movq	%rax, -0x50(%rbp)
1400997f3:     	movl	%r14d, -0x40(%rbp)
1400997f7:     	movl	%r13d, -0x3c(%rbp)
1400997fb:     	movw	%r12w, -0x38(%rbp)
140099800:     	movb	%r15b, -0x36(%rbp)
140099804:     	movzbl	0x25f(%rbp), %eax
14009980b:     	movb	%al, -0x35(%rbp)
14009980e:     	movd	%xmm6, -0x34(%rbp)
140099813:     	movq	0x250(%rbp), %rax
14009981a:     	movq	%rax, -0x30(%rbp)
14009981e:     	leaq	-0x28(%rbp), %rcx
140099822:     	movl	$0x108, %r8d            # imm = 0x108
140099828:     	movq	%rbx, %rdx
14009982b:     	callq	0x140247c10 <.text+0x246c10>
140099830:     	leaq	-0x60(%rbp), %rdx
140099834:     	movq	%rsi, %rcx
140099837:     	callq	0x14020cde0 <.text+0x20bde0>
14009983c:     	movb	$0x1, %al
14009983e:     	jmp	0x140099842 <.text+0x98842>
140099840:     	xorl	%eax, %eax
140099842:     	movaps	0x260(%rbp), %xmm6
140099849:     	movaps	0x270(%rbp), %xmm7
140099850:     	addq	$0x308, %rsp            # imm = 0x308
140099857:     	popq	%rbx
140099858:     	popq	%rdi
140099859:     	popq	%rsi
14009985a:     	popq	%r12
14009985c:     	popq	%r13
14009985e:     	popq	%r14
140099860:     	popq	%r15
140099862:     	popq	%rbp
140099863:     	retq
140099864:     	leaq	0x1c62fd(%rip), %r9     # 0x14025fb68
14009986b:     	movl	$0x10, %r8d
140099871:     	xorl	%ecx, %ecx
140099873:     	movq	%rdi, %rdx
140099876:     	callq	0x140248660 <.text+0x247660>
14009987b:     	ud2

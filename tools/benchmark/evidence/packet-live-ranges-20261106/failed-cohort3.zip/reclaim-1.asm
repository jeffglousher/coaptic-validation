
D:\CoapticCurrent\packet-full-block-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140098dc0:     	pushq	%rbp
140098dc1:     	pushq	%r15
140098dc3:     	pushq	%r14
140098dc5:     	pushq	%r13
140098dc7:     	pushq	%r12
140098dc9:     	pushq	%rsi
140098dca:     	pushq	%rdi
140098dcb:     	pushq	%rbx
140098dcc:     	subq	$0x318, %rsp            # imm = 0x318
140098dd3:     	leaq	0x80(%rsp), %rbp
140098ddb:     	movaps	%xmm7, 0x280(%rbp)
140098de2:     	movaps	%xmm6, 0x270(%rbp)
140098de9:     	leaq	0x30(%rcx), %rdx
140098ded:     	xorl	%r8d, %r8d
140098df0:     	xorl	%r11d, %r11d
140098df3:     	leaq	(%r11,%r11,4), %r10
140098df7:     	shlq	$0x6, %r10
140098dfb:     	addq	%rdx, %r10
140098dfe:     	movq	%r11, %r9
140098e01:     	jmp	0x140098e24 <.text+0x97e24>
140098e03:     	nopw	%cs:(%rax,%rax)
140098e10:     	incq	%r9
140098e13:     	addq	$0x140, %r10            # imm = 0x140
140098e1a:     	cmpq	$0x4, %r9
140098e1e:     	je	0x140098eae <.text+0x97eae>
140098e24:     	cmpb	$0x1, 0x510(%rcx,%r9)
140098e2d:     	jne	0x140098e10 <.text+0x97e10>
140098e2f:     	movq	-0x30(%r10), %rsi
140098e33:     	cmpq	$0x2, %rsi
140098e37:     	je	0x140098e10 <.text+0x97e10>
140098e39:     	movq	(%r10), %r11
140098e3c:     	cmpl	$0x1, %esi
140098e3f:     	setne	%bl
140098e42:     	testq	%r11, %r11
140098e45:     	sete	%sil
140098e49:     	orb	%bl, %sil
140098e4c:     	cmpb	$0x1, %sil
140098e50:     	je	0x140098e10 <.text+0x97e10>
140098e52:     	movq	0x268(%rbp), %rsi
140098e59:     	cmpq	%rsi, %r11
140098e5c:     	setae	%bl
140098e5f:     	testb	%bl, %r8b
140098e62:     	jne	0x140098e94 <.text+0x97e94>
140098e64:     	movq	-0x28(%r10), %rax
140098e68:     	movd	-0x4(%r10), %xmm6
140098e6e:     	movzbl	-0x5(%r10), %edi
140098e73:     	movzbl	-0x6(%r10), %r15d
140098e78:     	movzwl	-0x8(%r10), %r12d
140098e7d:     	movl	-0xc(%r10), %r13d
140098e81:     	movl	-0x10(%r10), %r14d
140098e85:     	movups	-0x20(%r10), %xmm0
140098e8a:     	movaps	%xmm0, 0x240(%rbp)
140098e91:     	movq	%r11, %rsi
140098e94:     	movq	%rsi, 0x268(%rbp)
140098e9b:     	leaq	0x1(%r9), %r11
140098e9f:     	movb	$0x1, %r8b
140098ea2:     	cmpq	$0x3, %r9
140098ea6:     	jb	0x140098df3 <.text+0x97df3>
140098eac:     	jmp	0x140098eb8 <.text+0x97eb8>
140098eae:     	testb	$0x1, %r8b
140098eb2:     	je	0x1400990f8 <.text+0x980f8>
140098eb8:     	cmpq	$0x1, %rax
140098ebc:     	ja	0x140098f14 <.text+0x97f14>
140098ebe:     	cmpb	$0x1, 0x1e80(%rcx,%rax)
140098ec6:     	jne	0x140098f14 <.text+0x97f14>
140098ec8:     	cmpb	$0x0, 0x1e82(%rcx,%rax)
140098ed0:     	jne	0x140098f14 <.text+0x97f14>
140098ed2:     	movb	$0x0, 0x1e80(%rcx,%rax)
140098eda:     	decq	0x1e78(%rcx)
140098ee1:     	leaq	0x14f8(%rcx), %rdx
140098ee8:     	movq	$0x0, 0x1df8(%rcx,%rax,8)
140098ef4:     	leaq	(%rax,%rax,8), %r8
140098ef8:     	leaq	(%r8,%r8,2), %r8
140098efc:     	addq	%rax, %r8
140098eff:     	movb	$0x2, 0x95a(%rdx,%r8)
140098f08:     	leaq	(%rax,%rax,2), %rax
140098f0c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
140098f14:     	movaps	0x240(%rbp), %xmm0
140098f1b:     	movaps	%xmm0, -0x60(%rbp)
140098f1f:     	movl	%r14d, %esi
140098f22:     	movl	%r14d, -0x50(%rbp)
140098f26:     	movl	%r13d, %r14d
140098f29:     	movl	%r13d, -0x4c(%rbp)
140098f2d:     	movl	%r12d, %r13d
140098f30:     	movw	%r12w, -0x48(%rbp)
140098f35:     	movl	%r15d, %r12d
140098f38:     	movb	%r15b, -0x46(%rbp)
140098f3c:     	movl	%edi, %r15d
140098f3f:     	movb	%dil, -0x45(%rbp)
140098f43:     	movd	%xmm6, %edi
140098f47:     	movd	%xmm6, -0x44(%rbp)
140098f4c:     	leaq	-0x60(%rbp), %rdx
140098f50:     	movq	%rcx, 0x260(%rbp)
140098f57:     	callq	0x14020d210 <.text+0x20c210>
140098f5c:     	xorps	%xmm7, %xmm7
140098f5f:     	movaps	%xmm7, 0x250(%rbp)
140098f66:     	movb	$0x0, 0x222(%rbp)
140098f6d:     	movw	%di, 0x220(%rbp)
140098f74:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
140098f7d:     	movq	$0x0, 0x223(%rbp)
140098f88:     	movq	$0x8, 0x200(%rbp)
140098f93:     	movq	$0x0, 0x208(%rbp)
140098f9e:     	movq	$0x1, 0x210(%rbp)
140098fa9:     	movq	$0x0, 0x218(%rbp)
140098fb4:     	leaq	0x230(%rbp), %rcx
140098fbb:     	leaq	0x200(%rbp), %rdx
140098fc2:     	leaq	0x250(%rbp), %r8
140098fc9:     	movl	$0x10, %r9d
140098fcf:     	callq	0x14010b630 <.text+0x10a630>
140098fd4:     	cmpb	$0x0, 0x230(%rbp)
140098fdb:     	jne	0x1400990f4 <.text+0x980f4>
140098fe1:     	movq	0x238(%rbp), %rdi
140098fe8:     	movaps	%xmm7, 0xe0(%rbp)
140098fef:     	movaps	%xmm7, 0xf0(%rbp)
140098ff6:     	movaps	%xmm7, 0x100(%rbp)
140098ffd:     	movaps	%xmm7, 0x110(%rbp)
140099004:     	movaps	%xmm7, 0x120(%rbp)
14009900b:     	movaps	%xmm7, 0x130(%rbp)
140099012:     	movaps	%xmm7, 0x140(%rbp)
140099019:     	movaps	%xmm7, 0x150(%rbp)
140099020:     	movaps	%xmm7, 0x160(%rbp)
140099027:     	movaps	%xmm7, 0x170(%rbp)
14009902e:     	movaps	%xmm7, 0x180(%rbp)
140099035:     	movaps	%xmm7, 0x190(%rbp)
14009903c:     	movaps	%xmm7, 0x1a0(%rbp)
140099043:     	movaps	%xmm7, 0x1b0(%rbp)
14009904a:     	movaps	%xmm7, 0x1c0(%rbp)
140099051:     	movaps	%xmm7, 0x1d0(%rbp)
140099058:     	movaps	0x240(%rbp), %xmm0
14009905f:     	movups	%xmm0, 0x1f0(%rbp)
140099066:     	cmpq	$0x11, %rdi
14009906a:     	jae	0x14009911c <.text+0x9811c>
140099070:     	leaq	0xe0(%rbp), %rbx
140099077:     	leaq	0x250(%rbp), %rdx
14009907e:     	movq	%rbx, %rcx
140099081:     	movq	%rdi, %r8
140099084:     	callq	0x140247c10 <.text+0x246c10>
140099089:     	movw	%di, 0x1e0(%rbp)
140099090:     	movq	$0x0, -0x60(%rbp)
140099098:     	movups	0x1e8(%rbp), %xmm0
14009909f:     	movups	%xmm0, -0x58(%rbp)
1400990a3:     	movq	0x1f8(%rbp), %rax
1400990aa:     	movq	%rax, -0x48(%rbp)
1400990ae:     	movl	%esi, -0x40(%rbp)
1400990b1:     	movl	%r14d, -0x3c(%rbp)
1400990b5:     	movw	%r13w, -0x38(%rbp)
1400990ba:     	movb	%r12b, -0x36(%rbp)
1400990be:     	movb	%r15b, -0x35(%rbp)
1400990c2:     	movd	%xmm6, -0x34(%rbp)
1400990c7:     	movq	0x268(%rbp), %rax
1400990ce:     	movq	%rax, -0x30(%rbp)
1400990d2:     	leaq	-0x28(%rbp), %rcx
1400990d6:     	movl	$0x108, %r8d            # imm = 0x108
1400990dc:     	movq	%rbx, %rdx
1400990df:     	callq	0x140247c10 <.text+0x246c10>
1400990e4:     	leaq	-0x60(%rbp), %rdx
1400990e8:     	movq	0x260(%rbp), %rcx
1400990ef:     	callq	0x14020cf80 <.text+0x20bf80>
1400990f4:     	movb	$0x1, %al
1400990f6:     	jmp	0x1400990fa <.text+0x980fa>
1400990f8:     	xorl	%eax, %eax
1400990fa:     	movaps	0x270(%rbp), %xmm6
140099101:     	movaps	0x280(%rbp), %xmm7
140099108:     	addq	$0x318, %rsp            # imm = 0x318
14009910f:     	popq	%rbx
140099110:     	popq	%rdi
140099111:     	popq	%rsi
140099112:     	popq	%r12
140099114:     	popq	%r13
140099116:     	popq	%r14
140099118:     	popq	%r15
14009911a:     	popq	%rbp
14009911b:     	retq
14009911c:     	leaq	0x1c6a45(%rip), %r9     # 0x14025fb68
140099123:     	movl	$0x10, %r8d
140099129:     	xorl	%ecx, %ecx
14009912b:     	movq	%rdi, %rdx
14009912e:     	callq	0x140248660 <.text+0x247660>
140099133:     	ud2

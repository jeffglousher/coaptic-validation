
D:\CoapticCurrent\packet-full-block-20261106\B\retained-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400398f0:     	pushq	%rbp
1400398f1:     	pushq	%r15
1400398f3:     	pushq	%r14
1400398f5:     	pushq	%r13
1400398f7:     	pushq	%r12
1400398f9:     	pushq	%rsi
1400398fa:     	pushq	%rdi
1400398fb:     	pushq	%rbx
1400398fc:     	subq	$0x4f8, %rsp            # imm = 0x4F8
140039903:     	leaq	0x80(%rsp), %rbp
14003990b:     	movl	$0x3, %r10d
140039911:     	cmpq	$-0x1, 0x230(%rdx)
140039919:     	je	0x140039a0a <.text+0x38a0a>
14003991f:     	movq	0x4f0(%rbp), %r15
140039926:     	movq	0x8(%r15), %rax
14003992a:     	cmpq	0x258(%rdx), %rax
140039931:     	jae	0x140039a0a <.text+0x38a0a>
140039937:     	movq	0x250(%rdx), %r11
14003993e:     	cmpb	$0x1, (%r11,%rax)
140039943:     	jne	0x140039a0a <.text+0x38a0a>
140039949:     	cmpq	0x240(%rdx), %rax
140039950:     	jae	0x140039a0a <.text+0x38a0a>
140039956:     	movq	0x238(%rdx), %rbx
14003995d:     	imulq	$0x2d0, %rax, %r11      # imm = 0x2D0
140039964:     	movq	0x2c0(%rbx,%r11), %r10
14003996c:     	movq	0x2c8(%rbx,%r11), %rax
140039974:     	cmpq	%r10, %rax
140039977:     	ja	0x140039bd9 <.text+0x38bd9>
14003997d:     	movq	0x10(%r15), %rdi
140039981:     	movq	0x18(%r15), %r12
140039985:     	movq	%r12, %rsi
140039988:     	movl	$0xb, %r10d
14003998e:     	addq	%rdi, %rsi
140039991:     	jb	0x140039a0a <.text+0x38a0a>
140039993:     	cmpq	$0x400, %r12            # imm = 0x400
14003999a:     	ja	0x140039a0a <.text+0x38a0a>
14003999c:     	cmpq	%rax, %rsi
14003999f:     	ja	0x140039a0a <.text+0x38a0a>
1400399a1:     	movq	%r8, %r13
1400399a4:     	movq	%r9, 0x468(%rbp)
1400399ab:     	movq	%rcx, %r14
1400399ae:     	movq	%rdx, %rsi
1400399b1:     	addq	%r11, %rbx
1400399b4:     	addq	0x2b8(%rbx), %rdi
1400399bb:     	movl	$0x400, %r8d            # imm = 0x400
1400399c1:     	cmpq	$0x400, %r12            # imm = 0x400
1400399c8:     	je	0x1400399d8 <.text+0x389d8>
1400399ca:     	leaq	-0x10(%rbp), %rcx
1400399ce:     	xorl	%edx, %edx
1400399d0:     	callq	0x14013fc62 <.text+0x13ec62>
1400399d5:     	movq	%r12, %r8
1400399d8:     	leaq	-0x10(%rbp), %rcx
1400399dc:     	movq	%rdi, %rdx
1400399df:     	callq	0x14013fc50 <.text+0x13ec50>
1400399e4:     	cmpb	$0x0, 0x4f8(%rbp)
1400399eb:     	je	0x140039a25 <.text+0x38a25>
1400399ed:     	cmpq	$0x2, (%rbx)
1400399f1:     	movq	%rsi, %rcx
1400399f4:     	jne	0x140039ba3 <.text+0x38ba3>
1400399fa:     	xorl	%ebx, %ebx
1400399fc:     	callq	0x140051be0 <.text+0x50be0>
140039a01:     	testb	$0x1, %al
140039a03:     	jne	0x140039a37 <.text+0x38a37>
140039a05:     	jmp	0x140039bc3 <.text+0x38bc3>
140039a0a:     	movb	$0xa, (%rcx)
140039a0d:     	movq	%r10, 0x8(%rcx)
140039a11:     	addq	$0x4f8, %rsp            # imm = 0x4F8
140039a18:     	popq	%rbx
140039a19:     	popq	%rdi
140039a1a:     	popq	%rsi
140039a1b:     	popq	%r12
140039a1d:     	popq	%r13
140039a1f:     	popq	%r14
140039a21:     	popq	%r15
140039a23:     	popq	%rbp
140039a24:     	retq
140039a25:     	xorl	%ebx, %ebx
140039a27:     	movq	%rsi, %rcx
140039a2a:     	callq	0x140051be0 <.text+0x50be0>
140039a2f:     	testb	$0x1, %al
140039a31:     	je	0x140039bc3 <.text+0x38bc3>
140039a37:     	movq	%rdx, %rdi
140039a3a:     	movq	0x500(%rbp), %rdx
140039a41:     	movzwl	0x4e8(%rbp), %ecx
140039a48:     	movzbl	0x4e0(%rbp), %eax
140039a4f:     	movq	(%r15), %r8
140039a52:     	movq	%rbx, 0x438(%rbp)
140039a59:     	movq	0x470(%rbp), %r9
140039a60:     	movq	%r9, 0x440(%rbp)
140039a67:     	movq	%r8, 0x448(%rbp)
140039a6e:     	movzbl	0x4f8(%rbp), %r8d
140039a76:     	movb	%r8b, 0x450(%rbp)
140039a7d:     	movups	0x38(%r13), %xmm0
140039a82:     	movups	0x44(%r13), %xmm1
140039a87:     	movups	%xmm1, 0x3fc(%rbp)
140039a8e:     	movaps	%xmm0, 0x3f0(%rbp)
140039a95:     	leaq	0x66(%r13), %r8
140039a99:     	movq	0x56(%r13), %r9
140039a9d:     	movq	0x5d(%r13), %r10
140039aa1:     	movq	%r10, 0x45f(%rbp)
140039aa8:     	movq	%r9, 0x458(%rbp)
140039aaf:     	leaq	0x458(%rbp), %r9
140039ab6:     	movq	%r9, 0x68(%rsp)
140039abb:     	movq	%rdx, 0x60(%rsp)
140039ac0:     	movq	%r13, 0x58(%rsp)
140039ac5:     	leaq	0x438(%rbp), %rdx
140039acc:     	movq	%rdx, 0x50(%rsp)
140039ad1:     	movq	%r12, 0x48(%rsp)
140039ad6:     	leaq	-0x10(%rbp), %rdx
140039ada:     	movq	%rdx, 0x40(%rsp)
140039adf:     	movq	0x468(%rbp), %rdx
140039ae6:     	movq	%rdx, 0x38(%rsp)
140039aeb:     	movq	%r8, 0x30(%rsp)
140039af0:     	movw	%cx, 0x28(%rsp)
140039af5:     	movb	%al, 0x20(%rsp)
140039af9:     	leaq	0x418(%rbp), %rcx
140039b00:     	leaq	0x3f0(%rbp), %r8
140039b07:     	movq	%rsi, %rdx
140039b0a:     	movq	%rdi, %r9
140039b0d:     	callq	0x140046bc0 <.text+0x45bc0>
140039b12:     	cmpb	$-0x1, 0x418(%rbp)
140039b19:     	je	0x140039bcc <.text+0x38bcc>
140039b1f:     	movups	0x418(%rbp), %xmm0
140039b26:     	movups	0x428(%rbp), %xmm1
140039b2d:     	movups	%xmm1, 0x10(%r14)
140039b32:     	movups	%xmm0, (%r14)
140039b36:     	cmpq	0x88(%rsi), %rdi
140039b3d:     	jae	0x140039a11 <.text+0x38a11>
140039b43:     	movq	0x80(%rsi), %rax
140039b4a:     	cmpb	$0x1, (%rax,%rdi)
140039b4e:     	jne	0x140039a11 <.text+0x38a11>
140039b54:     	cmpq	0xa0(%rsi), %rdi
140039b5b:     	jae	0x140039b6e <.text+0x38b6e>
140039b5d:     	movq	0x98(%rsi), %rcx
140039b64:     	cmpb	$0x0, (%rcx,%rdi)
140039b68:     	jne	0x140039a11 <.text+0x38a11>
140039b6e:     	movb	$0x0, (%rax,%rdi)
140039b72:     	decq	0xb0(%rsi)
140039b79:     	cmpq	0x70(%rsi), %rdi
140039b7d:     	jae	0x140039a11 <.text+0x38a11>
140039b83:     	movq	0x68(%rsi), %rax
140039b87:     	imulq	$0x58, %rdi, %rcx
140039b8b:     	movq	$0x0, 0x30(%rax,%rcx)
140039b94:     	movb	$0x2, 0x52(%rax,%rcx)
140039b99:     	movb	$0x2, 0x25(%rax,%rcx)
140039b9e:     	jmp	0x140039a11 <.text+0x38a11>
140039ba3:     	movq	0x98(%rbx), %rax
140039baa:     	movq	%rax, 0x470(%rbp)
140039bb1:     	movl	$0x1, %ebx
140039bb6:     	callq	0x140051be0 <.text+0x50be0>
140039bbb:     	testb	$0x1, %al
140039bbd:     	jne	0x140039a37 <.text+0x38a37>
140039bc3:     	movb	$0x9, (%r14)
140039bc7:     	jmp	0x140039a11 <.text+0x38a11>
140039bcc:     	movq	%rdi, 0x8(%r14)
140039bd0:     	movb	$-0x1, (%r14)
140039bd4:     	jmp	0x140039a11 <.text+0x38a11>
140039bd9:     	leaq	0x117fb8(%rip), %r9     # 0x140151b98
140039be0:     	xorl	%ecx, %ecx
140039be2:     	movq	%rax, %rdx
140039be5:     	movq	%r10, %r8
140039be8:     	callq	0x140140710 <.text+0x13f710>
140039bed:     	ud2

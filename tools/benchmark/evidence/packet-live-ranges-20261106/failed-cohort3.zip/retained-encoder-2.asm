
D:\CoapticCurrent\packet-full-block-20261106\B\retained-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400395e0:     	pushq	%rbp
1400395e1:     	pushq	%r15
1400395e3:     	pushq	%r14
1400395e5:     	pushq	%r13
1400395e7:     	pushq	%r12
1400395e9:     	pushq	%rsi
1400395ea:     	pushq	%rdi
1400395eb:     	pushq	%rbx
1400395ec:     	subq	$0x508, %rsp            # imm = 0x508
1400395f3:     	leaq	0x80(%rsp), %rbp
1400395fb:     	movl	$0x3, %r10d
140039601:     	cmpq	$-0x1, 0x230(%rdx)
140039609:     	je	0x1400396fb <.text+0x386fb>
14003960f:     	movq	0x500(%rbp), %r12
140039616:     	movq	0x8(%r12), %rax
14003961b:     	cmpq	0x258(%rdx), %rax
140039622:     	jae	0x1400396fb <.text+0x386fb>
140039628:     	movq	0x250(%rdx), %r11
14003962f:     	cmpb	$0x1, (%r11,%rax)
140039634:     	jne	0x1400396fb <.text+0x386fb>
14003963a:     	cmpq	0x240(%rdx), %rax
140039641:     	jae	0x1400396fb <.text+0x386fb>
140039647:     	movq	0x238(%rdx), %rbx
14003964e:     	imulq	$0x2d0, %rax, %r11      # imm = 0x2D0
140039655:     	movq	0x2c0(%rbx,%r11), %r10
14003965d:     	movq	0x2c8(%rbx,%r11), %rax
140039665:     	cmpq	%r10, %rax
140039668:     	ja	0x1400398d6 <.text+0x388d6>
14003966e:     	movq	0x10(%r12), %rdi
140039673:     	movq	0x18(%r12), %r15
140039678:     	movq	%r15, %rsi
14003967b:     	movl	$0xb, %r10d
140039681:     	addq	%rdi, %rsi
140039684:     	jb	0x1400396fb <.text+0x386fb>
140039686:     	cmpq	$0x400, %r15            # imm = 0x400
14003968d:     	ja	0x1400396fb <.text+0x386fb>
14003968f:     	cmpq	%rax, %rsi
140039692:     	ja	0x1400396fb <.text+0x386fb>
140039694:     	movq	%r8, %r13
140039697:     	movq	%r9, 0x478(%rbp)
14003969e:     	movq	%rcx, %r14
1400396a1:     	movq	%rdx, %rsi
1400396a4:     	addq	%r11, %rbx
1400396a7:     	addq	0x2b8(%rbx), %rdi
1400396ae:     	movl	$0x400, %r8d            # imm = 0x400
1400396b4:     	cmpq	$0x400, %r15            # imm = 0x400
1400396bb:     	je	0x1400396ca <.text+0x386ca>
1400396bd:     	movq	%rbp, %rcx
1400396c0:     	xorl	%edx, %edx
1400396c2:     	callq	0x14013fc62 <.text+0x13ec62>
1400396c7:     	movq	%r15, %r8
1400396ca:     	movq	%rbp, %rcx
1400396cd:     	movq	%rdi, %rdx
1400396d0:     	callq	0x14013fc50 <.text+0x13ec50>
1400396d5:     	cmpb	$0x0, 0x508(%rbp)
1400396dc:     	je	0x140039716 <.text+0x38716>
1400396de:     	cmpq	$0x2, (%rbx)
1400396e2:     	movq	%rsi, %rcx
1400396e5:     	jne	0x1400398a0 <.text+0x388a0>
1400396eb:     	xorl	%ebx, %ebx
1400396ed:     	callq	0x140051be0 <.text+0x50be0>
1400396f2:     	testb	$0x1, %al
1400396f4:     	jne	0x140039728 <.text+0x38728>
1400396f6:     	jmp	0x1400398c0 <.text+0x388c0>
1400396fb:     	movb	$0xa, (%rcx)
1400396fe:     	movq	%r10, 0x8(%rcx)
140039702:     	addq	$0x508, %rsp            # imm = 0x508
140039709:     	popq	%rbx
14003970a:     	popq	%rdi
14003970b:     	popq	%rsi
14003970c:     	popq	%r12
14003970e:     	popq	%r13
140039710:     	popq	%r14
140039712:     	popq	%r15
140039714:     	popq	%rbp
140039715:     	retq
140039716:     	xorl	%ebx, %ebx
140039718:     	movq	%rsi, %rcx
14003971b:     	callq	0x140051be0 <.text+0x50be0>
140039720:     	testb	$0x1, %al
140039722:     	je	0x1400398c0 <.text+0x388c0>
140039728:     	movq	%rdx, %rdi
14003972b:     	movq	0x518(%rbp), %rdx
140039732:     	movq	0x510(%rbp), %r8
140039739:     	movzwl	0x4f8(%rbp), %ecx
140039740:     	movzbl	0x4f0(%rbp), %eax
140039747:     	movq	(%r12), %r9
14003974b:     	movq	%rbx, 0x448(%rbp)
140039752:     	movq	0x480(%rbp), %r10
140039759:     	movq	%r10, 0x450(%rbp)
140039760:     	movq	%r9, 0x458(%rbp)
140039767:     	movzbl	0x508(%rbp), %r9d
14003976f:     	movb	%r9b, 0x460(%rbp)
140039776:     	movups	0x38(%r13), %xmm0
14003977b:     	movups	0x44(%r13), %xmm1
140039780:     	movups	%xmm1, 0x40c(%rbp)
140039787:     	movaps	%xmm0, 0x400(%rbp)
14003978e:     	leaq	0x66(%r13), %r9
140039792:     	movq	0x56(%r13), %r10
140039796:     	movq	0x5d(%r13), %r11
14003979a:     	movq	%r11, 0x46f(%rbp)
1400397a1:     	movq	%r10, 0x468(%rbp)
1400397a8:     	leaq	0x468(%rbp), %r10
1400397af:     	movq	%r10, 0x70(%rsp)
1400397b4:     	movq	%rdx, 0x68(%rsp)
1400397b9:     	movq	%r8, 0x60(%rsp)
1400397be:     	movq	%r13, 0x58(%rsp)
1400397c3:     	leaq	0x448(%rbp), %rdx
1400397ca:     	movq	%rdx, 0x50(%rsp)
1400397cf:     	movq	%r15, 0x48(%rsp)
1400397d4:     	movq	%rbp, %rdx
1400397d7:     	movq	%rdx, 0x40(%rsp)
1400397dc:     	movq	0x478(%rbp), %rdx
1400397e3:     	movq	%rdx, 0x38(%rsp)
1400397e8:     	movq	%r9, 0x30(%rsp)
1400397ed:     	movw	%cx, 0x28(%rsp)
1400397f2:     	movb	%al, 0x20(%rsp)
1400397f6:     	leaq	0x428(%rbp), %rcx
1400397fd:     	leaq	0x400(%rbp), %r8
140039804:     	movq	%rsi, %rdx
140039807:     	movq	%rdi, %r9
14003980a:     	callq	0x1400453d0 <.text+0x443d0>
14003980f:     	cmpb	$-0x1, 0x428(%rbp)
140039816:     	je	0x1400398c9 <.text+0x388c9>
14003981c:     	movups	0x428(%rbp), %xmm0
140039823:     	movups	0x438(%rbp), %xmm1
14003982a:     	movups	%xmm1, 0x10(%r14)
14003982f:     	movups	%xmm0, (%r14)
140039833:     	cmpq	0x88(%rsi), %rdi
14003983a:     	jae	0x140039702 <.text+0x38702>
140039840:     	movq	0x80(%rsi), %rax
140039847:     	cmpb	$0x1, (%rax,%rdi)
14003984b:     	jne	0x140039702 <.text+0x38702>
140039851:     	cmpq	0xa0(%rsi), %rdi
140039858:     	jae	0x14003986b <.text+0x3886b>
14003985a:     	movq	0x98(%rsi), %rcx
140039861:     	cmpb	$0x0, (%rcx,%rdi)
140039865:     	jne	0x140039702 <.text+0x38702>
14003986b:     	movb	$0x0, (%rax,%rdi)
14003986f:     	decq	0xb0(%rsi)
140039876:     	cmpq	0x70(%rsi), %rdi
14003987a:     	jae	0x140039702 <.text+0x38702>
140039880:     	movq	0x68(%rsi), %rax
140039884:     	imulq	$0x58, %rdi, %rcx
140039888:     	movq	$0x0, 0x30(%rax,%rcx)
140039891:     	movb	$0x2, 0x52(%rax,%rcx)
140039896:     	movb	$0x2, 0x25(%rax,%rcx)
14003989b:     	jmp	0x140039702 <.text+0x38702>
1400398a0:     	movq	0x98(%rbx), %rax
1400398a7:     	movq	%rax, 0x480(%rbp)
1400398ae:     	movl	$0x1, %ebx
1400398b3:     	callq	0x140051be0 <.text+0x50be0>
1400398b8:     	testb	$0x1, %al
1400398ba:     	jne	0x140039728 <.text+0x38728>
1400398c0:     	movb	$0x9, (%r14)
1400398c4:     	jmp	0x140039702 <.text+0x38702>
1400398c9:     	movq	%rdi, 0x8(%r14)
1400398cd:     	movb	$-0x1, (%r14)
1400398d1:     	jmp	0x140039702 <.text+0x38702>
1400398d6:     	leaq	0x1182bb(%rip), %r9     # 0x140151b98
1400398dd:     	xorl	%ecx, %ecx
1400398df:     	movq	%rax, %rdx
1400398e2:     	movq	%r10, %r8
1400398e5:     	callq	0x140140710 <.text+0x13f710>
1400398ea:     	ud2

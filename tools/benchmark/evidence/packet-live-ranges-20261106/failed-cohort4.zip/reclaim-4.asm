
D:\CoapticCurrent\packet-body-borrow-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140099440:     	pushq	%rbp
140099441:     	pushq	%r15
140099443:     	pushq	%r14
140099445:     	pushq	%r13
140099447:     	pushq	%r12
140099449:     	pushq	%rsi
14009944a:     	pushq	%rdi
14009944b:     	pushq	%rbx
14009944c:     	subq	$0x318, %rsp            # imm = 0x318
140099453:     	leaq	0x80(%rsp), %rbp
14009945b:     	movaps	%xmm7, 0x280(%rbp)
140099462:     	movdqa	%xmm6, 0x270(%rbp)
14009946a:     	movq	0xe8(%rcx), %r8
140099471:     	testq	%r8, %r8
140099474:     	je	0x140099854 <.text+0x98854>
14009947a:     	movq	0x88(%rcx), %r11
140099481:     	movq	0xe0(%rcx), %rdx
140099488:     	movq	0xc8(%rcx), %rax
14009948f:     	movq	0xd0(%rcx), %r9
140099496:     	leaq	0x30(%rax), %rsi
14009949a:     	xorl	%ebx, %ebx
14009949c:     	xorl	%edi, %edi
14009949e:     	leaq	(%rdi,%rdi,4), %r12
1400994a2:     	shlq	$0x6, %r12
1400994a6:     	addq	%rsi, %r12
1400994a9:     	jmp	0x1400994c3 <.text+0x984c3>
1400994ab:     	nopl	(%rax,%rax)
1400994b0:     	incq	%rdi
1400994b3:     	addq	$0x140, %r12            # imm = 0x140
1400994ba:     	cmpq	%r8, %rdi
1400994bd:     	jae	0x14009958c <.text+0x9858c>
1400994c3:     	cmpq	%r9, %rdi
1400994c6:     	setb	%r15b
1400994ca:     	andb	(%rdx,%rdi), %r15b
1400994ce:     	cmpb	$0x1, %r15b
1400994d2:     	jne	0x1400994b0 <.text+0x984b0>
1400994d4:     	movq	-0x30(%r12), %r15
1400994d9:     	cmpq	$0x2, %r15
1400994dd:     	je	0x1400994b0 <.text+0x984b0>
1400994df:     	movq	(%r12), %r13
1400994e3:     	cmpl	$0x1, %r15d
1400994e7:     	setne	%r15b
1400994eb:     	testq	%r13, %r13
1400994ee:     	sete	%r10b
1400994f2:     	orb	%r15b, %r10b
1400994f5:     	cmpb	$0x1, %r10b
1400994f9:     	je	0x1400994b0 <.text+0x984b0>
1400994fb:     	movq	0x260(%rbp), %r15
140099502:     	cmpq	%r15, %r13
140099505:     	setae	%r10b
140099509:     	testb	%r10b, %bl
14009950c:     	jne	0x140099575 <.text+0x98575>
14009950e:     	movq	-0x28(%r12), %r10
140099513:     	movq	%r10, 0x250(%rbp)
14009951a:     	movq	-0x20(%r12), %r10
14009951f:     	movq	%r10, 0x248(%rbp)
140099526:     	movd	-0x4(%r12), %xmm6
14009952d:     	movzbl	-0x5(%r12), %r10d
140099533:     	movb	%r10b, 0x26e(%rbp)
14009953a:     	movzbl	-0x6(%r12), %r10d
140099540:     	movb	%r10b, 0x26f(%rbp)
140099547:     	movzwl	-0x8(%r12), %r10d
14009954d:     	movw	%r10w, 0x26c(%rbp)
140099555:     	movl	-0xc(%r12), %r10d
14009955a:     	movl	%r10d, 0x268(%rbp)
140099561:     	movl	-0x10(%r12), %r14d
140099566:     	movq	-0x18(%r12), %r10
14009956b:     	movq	%r10, 0x258(%rbp)
140099572:     	movq	%r13, %r15
140099575:     	movq	%r15, 0x260(%rbp)
14009957c:     	incq	%rdi
14009957f:     	movb	$0x1, %bl
140099581:     	cmpq	%r8, %rdi
140099584:     	jb	0x14009949e <.text+0x9849e>
14009958a:     	jmp	0x140099595 <.text+0x98595>
14009958c:     	testb	$0x1, %bl
14009958f:     	je	0x140099854 <.text+0x98854>
140099595:     	movq	0x250(%rbp), %r10
14009959c:     	cmpq	%r11, %r10
14009959f:     	jae	0x1400995f5 <.text+0x985f5>
1400995a1:     	movq	0x80(%rcx), %r11
1400995a8:     	cmpb	$0x1, (%r11,%r10)
1400995ad:     	jne	0x1400995f5 <.text+0x985f5>
1400995af:     	cmpq	0xa0(%rcx), %r10
1400995b6:     	jae	0x1400995c6 <.text+0x985c6>
1400995b8:     	movq	0x98(%rcx), %rsi
1400995bf:     	cmpb	$0x0, (%rsi,%r10)
1400995c4:     	jne	0x1400995f5 <.text+0x985f5>
1400995c6:     	movb	$0x0, (%r11,%r10)
1400995cb:     	decq	0xb0(%rcx)
1400995d2:     	cmpq	0x70(%rcx), %r10
1400995d6:     	jae	0x1400995f5 <.text+0x985f5>
1400995d8:     	movq	0x68(%rcx), %r11
1400995dc:     	imulq	$0x58, %r10, %r10
1400995e0:     	movq	$0x0, 0x30(%r11,%r10)
1400995e9:     	movb	$0x2, 0x52(%r11,%r10)
1400995ef:     	movb	$0x2, 0x25(%r11,%r10)
1400995f5:     	leaq	0xc0(%rcx), %rsi
1400995fc:     	movd	%xmm6, %r10d
140099601:     	addq	$0x2c, %rax
140099605:     	xorl	%r11d, %r11d
140099608:     	movq	0x248(%rbp), %r15
14009960f:     	movzbl	0x26e(%rbp), %r12d
140099617:     	jmp	0x140099632 <.text+0x98632>
140099619:     	nopl	(%rax)
140099620:     	incq	%r11
140099623:     	addq	$0x140, %rax            # imm = 0x140
140099629:     	cmpq	%r11, %r8
14009962c:     	je	0x1400996be <.text+0x986be>
140099632:     	cmpq	%r9, %r11
140099635:     	setb	%bl
140099638:     	andb	(%rdx,%r11), %bl
14009963c:     	cmpb	$0x1, %bl
14009963f:     	jne	0x140099620 <.text+0x98620>
140099641:     	cmpl	$0x2, -0x2c(%rax)
140099645:     	je	0x140099620 <.text+0x98620>
140099647:     	cmpw	%r10w, (%rax)
14009964b:     	jne	0x140099620 <.text+0x98620>
14009964d:     	cmpl	%r14d, -0xc(%rax)
140099651:     	jne	0x140099620 <.text+0x98620>
140099653:     	movl	0x268(%rbp), %edi
140099659:     	cmpl	%edi, -0x8(%rax)
14009965c:     	jne	0x140099620 <.text+0x98620>
14009965e:     	movzwl	0x26c(%rbp), %edi
140099665:     	cmpw	%di, -0x4(%rax)
140099669:     	jne	0x140099620 <.text+0x98620>
14009966b:     	movzbl	0x26f(%rbp), %ebx
140099672:     	cmpb	%bl, -0x2(%rax)
140099675:     	jne	0x140099620 <.text+0x98620>
140099677:     	movq	-0x1c(%rax), %rdi
14009967b:     	xorq	%r15, %rdi
14009967e:     	movq	-0x14(%rax), %rbx
140099682:     	xorq	0x258(%rbp), %rbx
140099689:     	orq	%rdi, %rbx
14009968c:     	jne	0x140099620 <.text+0x98620>
14009968e:     	cmpq	%r8, %r11
140099691:     	jae	0x1400996be <.text+0x986be>
140099693:     	cmpq	0x100(%rcx), %r11
14009969a:     	jae	0x1400996aa <.text+0x986aa>
14009969c:     	movq	0xf8(%rcx), %r8
1400996a3:     	cmpb	$0x0, (%r8,%r11)
1400996a8:     	jne	0x1400996be <.text+0x986be>
1400996aa:     	movb	$0x0, (%rdx,%r11)
1400996af:     	decq	0x110(%rcx)
1400996b6:     	movq	$0x2, -0x2c(%rax)
1400996be:     	xorps	%xmm7, %xmm7
1400996c1:     	movaps	%xmm7, 0x230(%rbp)
1400996c8:     	movb	$0x0, 0x212(%rbp)
1400996cf:     	movw	%r10w, 0x210(%rbp)
1400996d7:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
1400996e0:     	movq	$0x0, 0x213(%rbp)
1400996eb:     	movq	$0x8, 0x1f0(%rbp)
1400996f6:     	movq	$0x0, 0x1f8(%rbp)
140099701:     	movq	$0x1, 0x200(%rbp)
14009970c:     	movq	$0x0, 0x208(%rbp)
140099717:     	leaq	0x220(%rbp), %rcx
14009971e:     	leaq	0x1f0(%rbp), %rdx
140099725:     	leaq	0x230(%rbp), %r8
14009972c:     	movl	$0x10, %r9d
140099732:     	callq	0x1401108d0 <.text+0x10f8d0>
140099737:     	cmpb	$0x0, 0x220(%rbp)
14009973e:     	jne	0x140099850 <.text+0x98850>
140099744:     	movq	0x228(%rbp), %rdi
14009974b:     	movaps	%xmm7, 0xe0(%rbp)
140099752:     	movaps	%xmm7, 0xf0(%rbp)
140099759:     	movaps	%xmm7, 0x100(%rbp)
140099760:     	movaps	%xmm7, 0x110(%rbp)
140099767:     	movaps	%xmm7, 0x120(%rbp)
14009976e:     	movaps	%xmm7, 0x130(%rbp)
140099775:     	movaps	%xmm7, 0x140(%rbp)
14009977c:     	movaps	%xmm7, 0x150(%rbp)
140099783:     	movaps	%xmm7, 0x160(%rbp)
14009978a:     	movaps	%xmm7, 0x170(%rbp)
140099791:     	movaps	%xmm7, 0x180(%rbp)
140099798:     	movaps	%xmm7, 0x190(%rbp)
14009979f:     	movaps	%xmm7, 0x1a0(%rbp)
1400997a6:     	movaps	%xmm7, 0x1b0(%rbp)
1400997ad:     	movaps	%xmm7, 0x1c0(%rbp)
1400997b4:     	movaps	%xmm7, 0x1d0(%rbp)
1400997bb:     	cmpq	$0x11, %rdi
1400997bf:     	jae	0x140099878 <.text+0x98878>
1400997c5:     	leaq	0xe0(%rbp), %rbx
1400997cc:     	leaq	0x230(%rbp), %rdx
1400997d3:     	movq	%rbx, %rcx
1400997d6:     	movq	%rdi, %r8
1400997d9:     	callq	0x14024e5a0 <.text+0x24d5a0>
1400997de:     	movw	%di, 0x1e0(%rbp)
1400997e5:     	movq	$0x0, -0x60(%rbp)
1400997ed:     	movq	0x258(%rbp), %rax
1400997f4:     	movq	%rax, -0x48(%rbp)
1400997f8:     	movq	%r15, -0x50(%rbp)
1400997fc:     	movl	%r14d, -0x40(%rbp)
140099800:     	movl	0x268(%rbp), %eax
140099806:     	movl	%eax, -0x3c(%rbp)
140099809:     	movzwl	0x26c(%rbp), %eax
140099810:     	movw	%ax, -0x38(%rbp)
140099814:     	movzbl	0x26f(%rbp), %eax
14009981b:     	movb	%al, -0x36(%rbp)
14009981e:     	movb	%r12b, -0x35(%rbp)
140099822:     	movd	%xmm6, -0x34(%rbp)
140099827:     	movq	0x260(%rbp), %rax
14009982e:     	movq	%rax, -0x30(%rbp)
140099832:     	leaq	-0x28(%rbp), %rcx
140099836:     	movl	$0x108, %r8d            # imm = 0x108
14009983c:     	movq	%rbx, %rdx
14009983f:     	callq	0x14024e5a0 <.text+0x24d5a0>
140099844:     	leaq	-0x60(%rbp), %rdx
140099848:     	movq	%rsi, %rcx
14009984b:     	callq	0x140011760 <.text+0x10760>
140099850:     	movb	$0x1, %al
140099852:     	jmp	0x140099856 <.text+0x98856>
140099854:     	xorl	%eax, %eax
140099856:     	movaps	0x270(%rbp), %xmm6
14009985d:     	movaps	0x280(%rbp), %xmm7
140099864:     	addq	$0x318, %rsp            # imm = 0x318
14009986b:     	popq	%rbx
14009986c:     	popq	%rdi
14009986d:     	popq	%rsi
14009986e:     	popq	%r12
140099870:     	popq	%r13
140099872:     	popq	%r14
140099874:     	popq	%r15
140099876:     	popq	%rbp
140099877:     	retq
140099878:     	leaq	0x1d62b9(%rip), %r9     # 0x14026fb38
14009987f:     	movl	$0x10, %r8d
140099885:     	xorl	%ecx, %ecx
140099887:     	movq	%rdi, %rdx
14009988a:     	callq	0x14024eff0 <.text+0x24dff0>
14009988f:     	ud2

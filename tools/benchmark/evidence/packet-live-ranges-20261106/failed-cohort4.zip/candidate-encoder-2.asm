
D:\CoapticCurrent\packet-body-borrow-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140067590:     	pushq	%rbp
140067591:     	pushq	%r15
140067593:     	pushq	%r14
140067595:     	pushq	%r13
140067597:     	pushq	%r12
140067599:     	pushq	%rsi
14006759a:     	pushq	%rdi
14006759b:     	pushq	%rbx
14006759c:     	subq	$0x118, %rsp            # imm = 0x118
1400675a3:     	leaq	0x80(%rsp), %rbp
1400675ab:     	movq	0x110(%rbp), %r13
1400675b2:     	movq	0x8(%r13), %rbx
1400675b6:     	movl	$0x3, %r10d
1400675bc:     	cmpq	$0x3, %rbx
1400675c0:     	ja	0x140067631 <.text+0x66631>
1400675c2:     	cmpb	$0x1, 0x1b748(%rdx,%rbx)
1400675ca:     	jne	0x140067631 <.text+0x66631>
1400675cc:     	movq	0x2b750(%rdx,%rbx,8), %rax
1400675d4:     	cmpq	$0x4001, %rax           # imm = 0x4001
1400675da:     	jae	0x1400677e0 <.text+0x667e0>
1400675e0:     	movq	0x10(%r13), %r14
1400675e4:     	movq	0x18(%r13), %r11
1400675e8:     	movq	%r11, %r15
1400675eb:     	movl	$0xb, %r10d
1400675f1:     	addq	%r14, %r15
1400675f4:     	jb	0x140067631 <.text+0x66631>
1400675f6:     	cmpq	$0x400, %r11            # imm = 0x400
1400675fd:     	ja	0x140067631 <.text+0x66631>
1400675ff:     	cmpq	%rax, %r15
140067602:     	ja	0x140067631 <.text+0x66631>
140067604:     	cmpb	$0x0, 0x118(%rbp)
14006760b:     	movq	%r9, 0x78(%rbp)
14006760f:     	movq	%rcx, 0x90(%rbp)
140067616:     	je	0x14006762a <.text+0x6662a>
140067618:     	imulq	$0x2b0, %rbx, %rax      # imm = 0x2B0
14006761f:     	cmpq	$0x2, 0x1ac78(%rdx,%rax)
140067628:     	jne	0x14006764c <.text+0x6664c>
14006762a:     	movq	%r8, %r12
14006762d:     	xorl	%edi, %edi
14006762f:     	jmp	0x14006766b <.text+0x6666b>
140067631:     	movb	$0xa, (%rcx)
140067634:     	movq	%r10, 0x8(%rcx)
140067638:     	addq	$0x118, %rsp            # imm = 0x118
14006763f:     	popq	%rbx
140067640:     	popq	%rdi
140067641:     	popq	%rsi
140067642:     	popq	%r12
140067644:     	popq	%r13
140067646:     	popq	%r14
140067648:     	popq	%r15
14006764a:     	popq	%rbp
14006764b:     	retq
14006764c:     	movq	%r8, %r12
14006764f:     	addq	%rdx, %rax
140067652:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
140067658:     	movq	0x98(%rax), %rax
14006765f:     	movq	%rax, 0x80(%rbp)
140067666:     	movl	$0x1, %edi
14006766b:     	movq	%rdx, 0x88(%rbp)
140067672:     	movq	%rdx, %rcx
140067675:     	callq	0x140095590 <.text+0x94590>
14006767a:     	testb	$0x1, %al
14006767c:     	je	0x1400677be <.text+0x667be>
140067682:     	movq	%rdx, %rsi
140067685:     	movq	0x120(%rbp), %rdx
14006768c:     	movzwl	0x108(%rbp), %ecx
140067693:     	movzbl	0x100(%rbp), %eax
14006769a:     	movq	(%r13), %r8
14006769e:     	movq	%rdi, 0x48(%rbp)
1400676a2:     	movq	0x80(%rbp), %r9
1400676a9:     	movq	%r9, 0x50(%rbp)
1400676ad:     	movq	%r8, 0x58(%rbp)
1400676b1:     	movzbl	0x118(%rbp), %r8d
1400676b9:     	movb	%r8b, 0x60(%rbp)
1400676bd:     	movups	0x38(%r12), %xmm0
1400676c3:     	movups	0x44(%r12), %xmm1
1400676c9:     	movups	%xmm1, 0xc(%rbp)
1400676cd:     	movaps	%xmm0, (%rbp)
1400676d1:     	leaq	0x66(%r12), %r8
1400676d6:     	movq	0x56(%r12), %r9
1400676db:     	movq	0x5d(%r12), %r10
1400676e0:     	movq	%r10, 0x6f(%rbp)
1400676e4:     	movq	%r9, 0x68(%rbp)
1400676e8:     	leaq	0x68(%rbp), %r9
1400676ec:     	movq	%r9, 0x70(%rsp)
1400676f1:     	movq	%rdx, 0x68(%rsp)
1400676f6:     	movq	%r12, 0x60(%rsp)
1400676fb:     	leaq	0x48(%rbp), %rdx
1400676ff:     	movq	%rdx, 0x58(%rsp)
140067704:     	movq	%r15, 0x50(%rsp)
140067709:     	movq	%r14, 0x48(%rsp)
14006770e:     	movq	%rbx, 0x40(%rsp)
140067713:     	movq	0x78(%rbp), %rdx
140067717:     	movq	%rdx, 0x38(%rsp)
14006771c:     	movq	%r8, 0x30(%rsp)
140067721:     	movw	%cx, 0x28(%rsp)
140067726:     	movb	%al, 0x20(%rsp)
14006772a:     	leaq	0x28(%rbp), %rcx
14006772e:     	movq	%rbp, %r8
140067731:     	movq	0x88(%rbp), %rdx
140067738:     	movq	%rsi, %r9
14006773b:     	callq	0x14009dca0 <.text+0x9cca0>
140067740:     	cmpb	$-0x1, 0x28(%rbp)
140067744:     	je	0x1400677cd <.text+0x667cd>
14006774a:     	movq	0x88(%rbp), %rcx
140067751:     	cmpb	$0x1, 0x37740(%rcx,%rsi)
140067759:     	movq	0x90(%rbp), %rax
140067760:     	jne	0x1400677aa <.text+0x667aa>
140067762:     	cmpb	$0x0, 0x37760(%rcx,%rsi)
14006776a:     	jne	0x1400677aa <.text+0x667aa>
14006776c:     	movb	$0x0, 0x37740(%rcx,%rsi)
140067774:     	decq	0x37788(%rcx)
14006777b:     	leaq	0x37740(%rcx), %rdx
140067782:     	movq	$0x0, 0x43610(%rcx,%rsi,8)
14006778e:     	leaq	(%rsi,%rsi,8), %rcx
140067792:     	leaq	(%rcx,%rcx,2), %rcx
140067796:     	addq	%rsi, %rcx
140067799:     	movb	$0x2, 0x36a(%rdx,%rcx)
1400677a1:     	leaq	(%rsi,%rsi,2), %rcx
1400677a5:     	movb	$0x2, 0x5d(%rdx,%rcx,8)
1400677aa:     	movups	0x28(%rbp), %xmm0
1400677ae:     	movups	0x38(%rbp), %xmm1
1400677b2:     	movups	%xmm1, 0x10(%rax)
1400677b6:     	movups	%xmm0, (%rax)
1400677b9:     	jmp	0x140067638 <.text+0x66638>
1400677be:     	movq	0x90(%rbp), %rax
1400677c5:     	movb	$0x9, (%rax)
1400677c8:     	jmp	0x140067638 <.text+0x66638>
1400677cd:     	movq	0x90(%rbp), %rax
1400677d4:     	movq	%rsi, 0x8(%rax)
1400677d8:     	movb	$-0x1, (%rax)
1400677db:     	jmp	0x140067638 <.text+0x66638>
1400677e0:     	leaq	0x20b419(%rip), %r9     # 0x140272c00
1400677e7:     	movl	$0x4000, %r8d           # imm = 0x4000
1400677ed:     	xorl	%ecx, %ecx
1400677ef:     	movq	%rax, %rdx
1400677f2:     	callq	0x14024eff0 <.text+0x24dff0>
1400677f7:     	ud2

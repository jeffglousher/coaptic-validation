"""Untimed proof that actual retained transfers use the borrowed-body path."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
r=Path(__file__).resolve().parent
assert json.loads((r/'memory-preflight.json').read_text())['memory_accepted']
assert not (r/'measurement.json').exists()
fixture=Path('D:/CoapticCurrent/replay-active-copy-20261105/fixture/probe')
lane=Path('D:/coaptic-batch-interop-target')
out=r/'diagnostic';out.mkdir(exist_ok=False)
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR=str(lane),RUSTFLAGS='-Cforce-frame-pointers=yes')
env.pop('RUSTC_BOOTSTRAP',None)
cmd=[str(Path.home()/'.cargo/bin/agent-resources.exe'),'run','--id','coaptic-core-reusable','--directory',str(fixture),'--','cargo','build','--locked','--offline','--release','--bin','retained-probe','--features','oscore,alloc,diagnostics']
with (out/'build.log').open('wb') as f:
 result=subprocess.run(cmd,cwd=fixture,env=env,stdout=f,stderr=subprocess.STDOUT)
assert result.returncode==0,result.returncode
exe=out/'retained-probe.exe';shutil.copyfile(lane/'release/retained-probe.exe',exe)
rows=[]
for storage in ['fixed','allocated']:
 for security in ['unprotected','oscore']:
  for mode in ['sync','async']:
   label='-'.join([storage,security,mode]);call=[str(exe),'8',security,mode,storage]
   with (out/(label+'.json')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:
    p=subprocess.run(call,env=env,stdout=stdout,stderr=stderr)
   assert p.returncode==0,(label,p.returncode)
   data=json.loads((out/(label+'.json')).read_bytes());assert data['verified']==136 and data['data_packets_per_operation']==11
   metrics={k:int(v) for k,v in re.findall(r'(\w+): (\d+)',(out/(label+'.stderr')).read_text())}
   assert metrics['block_tx_staged_bytes']==0,(label,metrics)
   assert metrics['tx_payload_encoded_bytes']==(136*11264 if security=='unprotected' else 0),(label,metrics)
   rows.append(dict(storage=storage,security=security,mode=mode,exit_code=p.returncode,verified=data['verified'],metrics=metrics,command=call))
record=dict(source=json.loads((r/'source-verification.json').read_text())['source'],build_command=cmd,build_exit_code=result.returncode,binary_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),scope='Instrumented actual-path work counts only; not timing acceptance or per-change CPU attribution',rows=rows)
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))

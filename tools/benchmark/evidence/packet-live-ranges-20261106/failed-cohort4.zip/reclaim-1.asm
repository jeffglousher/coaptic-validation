
D:\CoapticCurrent\packet-body-borrow-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140098980:     	pushq	%rbp
140098981:     	pushq	%r15
140098983:     	pushq	%r14
140098985:     	pushq	%r13
140098987:     	pushq	%r12
140098989:     	pushq	%rsi
14009898a:     	pushq	%rdi
14009898b:     	pushq	%rbx
14009898c:     	subq	$0x318, %rsp            # imm = 0x318
140098993:     	leaq	0x80(%rsp), %rbp
14009899b:     	movaps	%xmm7, 0x280(%rbp)
1400989a2:     	movaps	%xmm6, 0x270(%rbp)
1400989a9:     	leaq	0x30(%rcx), %rdx
1400989ad:     	xorl	%r8d, %r8d
1400989b0:     	xorl	%r11d, %r11d
1400989b3:     	leaq	(%r11,%r11,4), %r10
1400989b7:     	shlq	$0x6, %r10
1400989bb:     	addq	%rdx, %r10
1400989be:     	movq	%r11, %r9
1400989c1:     	jmp	0x1400989e4 <.text+0x979e4>
1400989c3:     	nopw	%cs:(%rax,%rax)
1400989d0:     	incq	%r9
1400989d3:     	addq	$0x140, %r10            # imm = 0x140
1400989da:     	cmpq	$0x4, %r9
1400989de:     	je	0x140098a6e <.text+0x97a6e>
1400989e4:     	cmpb	$0x1, 0x510(%rcx,%r9)
1400989ed:     	jne	0x1400989d0 <.text+0x979d0>
1400989ef:     	movq	-0x30(%r10), %rsi
1400989f3:     	cmpq	$0x2, %rsi
1400989f7:     	je	0x1400989d0 <.text+0x979d0>
1400989f9:     	movq	(%r10), %r11
1400989fc:     	cmpl	$0x1, %esi
1400989ff:     	setne	%bl
140098a02:     	testq	%r11, %r11
140098a05:     	sete	%sil
140098a09:     	orb	%bl, %sil
140098a0c:     	cmpb	$0x1, %sil
140098a10:     	je	0x1400989d0 <.text+0x979d0>
140098a12:     	movq	0x268(%rbp), %rsi
140098a19:     	cmpq	%rsi, %r11
140098a1c:     	setae	%bl
140098a1f:     	testb	%bl, %r8b
140098a22:     	jne	0x140098a54 <.text+0x97a54>
140098a24:     	movq	-0x28(%r10), %rax
140098a28:     	movd	-0x4(%r10), %xmm6
140098a2e:     	movzbl	-0x5(%r10), %edi
140098a33:     	movzbl	-0x6(%r10), %r15d
140098a38:     	movzwl	-0x8(%r10), %r12d
140098a3d:     	movl	-0xc(%r10), %r13d
140098a41:     	movl	-0x10(%r10), %r14d
140098a45:     	movups	-0x20(%r10), %xmm0
140098a4a:     	movaps	%xmm0, 0x240(%rbp)
140098a51:     	movq	%r11, %rsi
140098a54:     	movq	%rsi, 0x268(%rbp)
140098a5b:     	leaq	0x1(%r9), %r11
140098a5f:     	movb	$0x1, %r8b
140098a62:     	cmpq	$0x3, %r9
140098a66:     	jb	0x1400989b3 <.text+0x979b3>
140098a6c:     	jmp	0x140098a78 <.text+0x97a78>
140098a6e:     	testb	$0x1, %r8b
140098a72:     	je	0x140098cb8 <.text+0x97cb8>
140098a78:     	cmpq	$0x1, %rax
140098a7c:     	ja	0x140098ad4 <.text+0x97ad4>
140098a7e:     	cmpb	$0x1, 0x1e80(%rcx,%rax)
140098a86:     	jne	0x140098ad4 <.text+0x97ad4>
140098a88:     	cmpb	$0x0, 0x1e82(%rcx,%rax)
140098a90:     	jne	0x140098ad4 <.text+0x97ad4>
140098a92:     	movb	$0x0, 0x1e80(%rcx,%rax)
140098a9a:     	decq	0x1e78(%rcx)
140098aa1:     	leaq	0x14f8(%rcx), %rdx
140098aa8:     	movq	$0x0, 0x1df8(%rcx,%rax,8)
140098ab4:     	leaq	(%rax,%rax,8), %r8
140098ab8:     	leaq	(%r8,%r8,2), %r8
140098abc:     	addq	%rax, %r8
140098abf:     	movb	$0x2, 0x95a(%rdx,%r8)
140098ac8:     	leaq	(%rax,%rax,2), %rax
140098acc:     	movb	$0x2, 0x91d(%rdx,%rax,8)
140098ad4:     	movaps	0x240(%rbp), %xmm0
140098adb:     	movaps	%xmm0, -0x60(%rbp)
140098adf:     	movl	%r14d, %esi
140098ae2:     	movl	%r14d, -0x50(%rbp)
140098ae6:     	movl	%r13d, %r14d
140098ae9:     	movl	%r13d, -0x4c(%rbp)
140098aed:     	movl	%r12d, %r13d
140098af0:     	movw	%r12w, -0x48(%rbp)
140098af5:     	movl	%r15d, %r12d
140098af8:     	movb	%r15b, -0x46(%rbp)
140098afc:     	movl	%edi, %r15d
140098aff:     	movb	%dil, -0x45(%rbp)
140098b03:     	movd	%xmm6, %edi
140098b07:     	movd	%xmm6, -0x44(%rbp)
140098b0c:     	leaq	-0x60(%rbp), %rdx
140098b10:     	movq	%rcx, 0x260(%rbp)
140098b17:     	callq	0x140213ba0 <.text+0x212ba0>
140098b1c:     	xorps	%xmm7, %xmm7
140098b1f:     	movaps	%xmm7, 0x250(%rbp)
140098b26:     	movb	$0x0, 0x222(%rbp)
140098b2d:     	movw	%di, 0x220(%rbp)
140098b34:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
140098b3d:     	movq	$0x0, 0x223(%rbp)
140098b48:     	movq	$0x8, 0x200(%rbp)
140098b53:     	movq	$0x0, 0x208(%rbp)
140098b5e:     	movq	$0x1, 0x210(%rbp)
140098b69:     	movq	$0x0, 0x218(%rbp)
140098b74:     	leaq	0x230(%rbp), %rcx
140098b7b:     	leaq	0x200(%rbp), %rdx
140098b82:     	leaq	0x250(%rbp), %r8
140098b89:     	movl	$0x10, %r9d
140098b8f:     	callq	0x1401108d0 <.text+0x10f8d0>
140098b94:     	cmpb	$0x0, 0x230(%rbp)
140098b9b:     	jne	0x140098cb4 <.text+0x97cb4>
140098ba1:     	movq	0x238(%rbp), %rdi
140098ba8:     	movaps	%xmm7, 0xe0(%rbp)
140098baf:     	movaps	%xmm7, 0xf0(%rbp)
140098bb6:     	movaps	%xmm7, 0x100(%rbp)
140098bbd:     	movaps	%xmm7, 0x110(%rbp)
140098bc4:     	movaps	%xmm7, 0x120(%rbp)
140098bcb:     	movaps	%xmm7, 0x130(%rbp)
140098bd2:     	movaps	%xmm7, 0x140(%rbp)
140098bd9:     	movaps	%xmm7, 0x150(%rbp)
140098be0:     	movaps	%xmm7, 0x160(%rbp)
140098be7:     	movaps	%xmm7, 0x170(%rbp)
140098bee:     	movaps	%xmm7, 0x180(%rbp)
140098bf5:     	movaps	%xmm7, 0x190(%rbp)
140098bfc:     	movaps	%xmm7, 0x1a0(%rbp)
140098c03:     	movaps	%xmm7, 0x1b0(%rbp)
140098c0a:     	movaps	%xmm7, 0x1c0(%rbp)
140098c11:     	movaps	%xmm7, 0x1d0(%rbp)
140098c18:     	movaps	0x240(%rbp), %xmm0
140098c1f:     	movups	%xmm0, 0x1f0(%rbp)
140098c26:     	cmpq	$0x11, %rdi
140098c2a:     	jae	0x140098cdc <.text+0x97cdc>
140098c30:     	leaq	0xe0(%rbp), %rbx
140098c37:     	leaq	0x250(%rbp), %rdx
140098c3e:     	movq	%rbx, %rcx
140098c41:     	movq	%rdi, %r8
140098c44:     	callq	0x14024e5a0 <.text+0x24d5a0>
140098c49:     	movw	%di, 0x1e0(%rbp)
140098c50:     	movq	$0x0, -0x60(%rbp)
140098c58:     	movups	0x1e8(%rbp), %xmm0
140098c5f:     	movups	%xmm0, -0x58(%rbp)
140098c63:     	movq	0x1f8(%rbp), %rax
140098c6a:     	movq	%rax, -0x48(%rbp)
140098c6e:     	movl	%esi, -0x40(%rbp)
140098c71:     	movl	%r14d, -0x3c(%rbp)
140098c75:     	movw	%r13w, -0x38(%rbp)
140098c7a:     	movb	%r12b, -0x36(%rbp)
140098c7e:     	movb	%r15b, -0x35(%rbp)
140098c82:     	movd	%xmm6, -0x34(%rbp)
140098c87:     	movq	0x268(%rbp), %rax
140098c8e:     	movq	%rax, -0x30(%rbp)
140098c92:     	leaq	-0x28(%rbp), %rcx
140098c96:     	movl	$0x108, %r8d            # imm = 0x108
140098c9c:     	movq	%rbx, %rdx
140098c9f:     	callq	0x14024e5a0 <.text+0x24d5a0>
140098ca4:     	leaq	-0x60(%rbp), %rdx
140098ca8:     	movq	0x260(%rbp), %rcx
140098caf:     	callq	0x140213910 <.text+0x212910>
140098cb4:     	movb	$0x1, %al
140098cb6:     	jmp	0x140098cba <.text+0x97cba>
140098cb8:     	xorl	%eax, %eax
140098cba:     	movaps	0x270(%rbp), %xmm6
140098cc1:     	movaps	0x280(%rbp), %xmm7
140098cc8:     	addq	$0x318, %rsp            # imm = 0x318
140098ccf:     	popq	%rbx
140098cd0:     	popq	%rdi
140098cd1:     	popq	%rsi
140098cd2:     	popq	%r12
140098cd4:     	popq	%r13
140098cd6:     	popq	%r14
140098cd8:     	popq	%r15
140098cda:     	popq	%rbp
140098cdb:     	retq
140098cdc:     	leaq	0x1d6e55(%rip), %r9     # 0x14026fb38
140098ce3:     	movl	$0x10, %r8d
140098ce9:     	xorl	%ecx, %ecx
140098ceb:     	movq	%rdi, %rdx
140098cee:     	callq	0x14024eff0 <.text+0x24dff0>
140098cf3:     	ud2

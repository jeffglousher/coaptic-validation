
D:\CoapticCurrent\packet-body-borrow-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140067310:     	pushq	%rbp
140067311:     	pushq	%r15
140067313:     	pushq	%r14
140067315:     	pushq	%r13
140067317:     	pushq	%r12
140067319:     	pushq	%rsi
14006731a:     	pushq	%rdi
14006731b:     	pushq	%rbx
14006731c:     	subq	$0x118, %rsp            # imm = 0x118
140067323:     	leaq	0x80(%rsp), %rbp
14006732b:     	movq	0x110(%rbp), %r13
140067332:     	movq	0x8(%r13), %rbx
140067336:     	movl	$0x3, %r10d
14006733c:     	cmpq	$0x3, %rbx
140067340:     	ja	0x1400673b1 <.text+0x663b1>
140067342:     	cmpb	$0x1, 0x1b748(%rdx,%rbx)
14006734a:     	jne	0x1400673b1 <.text+0x663b1>
14006734c:     	movq	0x2b750(%rdx,%rbx,8), %rax
140067354:     	cmpq	$0x4001, %rax           # imm = 0x4001
14006735a:     	jae	0x14006756c <.text+0x6656c>
140067360:     	movq	0x10(%r13), %r14
140067364:     	movq	0x18(%r13), %r11
140067368:     	movq	%r11, %r15
14006736b:     	movl	$0xb, %r10d
140067371:     	addq	%r14, %r15
140067374:     	jb	0x1400673b1 <.text+0x663b1>
140067376:     	cmpq	$0x400, %r11            # imm = 0x400
14006737d:     	ja	0x1400673b1 <.text+0x663b1>
14006737f:     	cmpq	%rax, %r15
140067382:     	ja	0x1400673b1 <.text+0x663b1>
140067384:     	cmpb	$0x0, 0x118(%rbp)
14006738b:     	movq	%r9, 0x78(%rbp)
14006738f:     	movq	%rcx, 0x90(%rbp)
140067396:     	je	0x1400673aa <.text+0x663aa>
140067398:     	imulq	$0x2b0, %rbx, %rax      # imm = 0x2B0
14006739f:     	cmpq	$0x2, 0x1ac78(%rdx,%rax)
1400673a8:     	jne	0x1400673cc <.text+0x663cc>
1400673aa:     	movq	%r8, %r12
1400673ad:     	xorl	%edi, %edi
1400673af:     	jmp	0x1400673eb <.text+0x663eb>
1400673b1:     	movb	$0xa, (%rcx)
1400673b4:     	movq	%r10, 0x8(%rcx)
1400673b8:     	addq	$0x118, %rsp            # imm = 0x118
1400673bf:     	popq	%rbx
1400673c0:     	popq	%rdi
1400673c1:     	popq	%rsi
1400673c2:     	popq	%r12
1400673c4:     	popq	%r13
1400673c6:     	popq	%r14
1400673c8:     	popq	%r15
1400673ca:     	popq	%rbp
1400673cb:     	retq
1400673cc:     	movq	%r8, %r12
1400673cf:     	addq	%rdx, %rax
1400673d2:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
1400673d8:     	movq	0x98(%rax), %rax
1400673df:     	movq	%rax, 0x80(%rbp)
1400673e6:     	movl	$0x1, %edi
1400673eb:     	movq	%rdx, 0x88(%rbp)
1400673f2:     	movq	%rdx, %rcx
1400673f5:     	callq	0x140095590 <.text+0x94590>
1400673fa:     	testb	$0x1, %al
1400673fc:     	je	0x14006754a <.text+0x6654a>
140067402:     	movq	%rdx, %rsi
140067405:     	movq	0x128(%rbp), %rdx
14006740c:     	movq	0x120(%rbp), %r8
140067413:     	movzwl	0x108(%rbp), %ecx
14006741a:     	movzbl	0x100(%rbp), %eax
140067421:     	movq	(%r13), %r9
140067425:     	movq	%rdi, 0x48(%rbp)
140067429:     	movq	0x80(%rbp), %r10
140067430:     	movq	%r10, 0x50(%rbp)
140067434:     	movq	%r9, 0x58(%rbp)
140067438:     	movzbl	0x118(%rbp), %r9d
140067440:     	movb	%r9b, 0x60(%rbp)
140067444:     	movups	0x38(%r12), %xmm0
14006744a:     	movups	0x44(%r12), %xmm1
140067450:     	movups	%xmm1, 0xc(%rbp)
140067454:     	movaps	%xmm0, (%rbp)
140067458:     	leaq	0x66(%r12), %r9
14006745d:     	movq	0x56(%r12), %r10
140067462:     	movq	0x5d(%r12), %r11
140067467:     	movq	%r11, 0x6f(%rbp)
14006746b:     	movq	%r10, 0x68(%rbp)
14006746f:     	leaq	0x68(%rbp), %r10
140067473:     	movq	%r10, 0x78(%rsp)
140067478:     	movq	%rdx, 0x70(%rsp)
14006747d:     	movq	%r8, 0x68(%rsp)
140067482:     	movq	%r12, 0x60(%rsp)
140067487:     	leaq	0x48(%rbp), %rdx
14006748b:     	movq	%rdx, 0x58(%rsp)
140067490:     	movq	%r15, 0x50(%rsp)
140067495:     	movq	%r14, 0x48(%rsp)
14006749a:     	movq	%rbx, 0x40(%rsp)
14006749f:     	movq	0x78(%rbp), %rdx
1400674a3:     	movq	%rdx, 0x38(%rsp)
1400674a8:     	movq	%r9, 0x30(%rsp)
1400674ad:     	movw	%cx, 0x28(%rsp)
1400674b2:     	movb	%al, 0x20(%rsp)
1400674b6:     	leaq	0x28(%rbp), %rcx
1400674ba:     	movq	%rbp, %r8
1400674bd:     	movq	0x88(%rbp), %rdx
1400674c4:     	movq	%rsi, %r9
1400674c7:     	callq	0x14009c810 <.text+0x9b810>
1400674cc:     	cmpb	$-0x1, 0x28(%rbp)
1400674d0:     	je	0x140067559 <.text+0x66559>
1400674d6:     	movq	0x88(%rbp), %rcx
1400674dd:     	cmpb	$0x1, 0x37740(%rcx,%rsi)
1400674e5:     	movq	0x90(%rbp), %rax
1400674ec:     	jne	0x140067536 <.text+0x66536>
1400674ee:     	cmpb	$0x0, 0x37760(%rcx,%rsi)
1400674f6:     	jne	0x140067536 <.text+0x66536>
1400674f8:     	movb	$0x0, 0x37740(%rcx,%rsi)
140067500:     	decq	0x37788(%rcx)
140067507:     	leaq	0x37740(%rcx), %rdx
14006750e:     	movq	$0x0, 0x43610(%rcx,%rsi,8)
14006751a:     	leaq	(%rsi,%rsi,8), %rcx
14006751e:     	leaq	(%rcx,%rcx,2), %rcx
140067522:     	addq	%rsi, %rcx
140067525:     	movb	$0x2, 0x36a(%rdx,%rcx)
14006752d:     	leaq	(%rsi,%rsi,2), %rcx
140067531:     	movb	$0x2, 0x5d(%rdx,%rcx,8)
140067536:     	movups	0x28(%rbp), %xmm0
14006753a:     	movups	0x38(%rbp), %xmm1
14006753e:     	movups	%xmm1, 0x10(%rax)
140067542:     	movups	%xmm0, (%rax)
140067545:     	jmp	0x1400673b8 <.text+0x663b8>
14006754a:     	movq	0x90(%rbp), %rax
140067551:     	movb	$0x9, (%rax)
140067554:     	jmp	0x1400673b8 <.text+0x663b8>
140067559:     	movq	0x90(%rbp), %rax
140067560:     	movq	%rsi, 0x8(%rax)
140067564:     	movb	$-0x1, (%rax)
140067567:     	jmp	0x1400673b8 <.text+0x663b8>
14006756c:     	leaq	0x20b68d(%rip), %r9     # 0x140272c00
140067573:     	movl	$0x4000, %r8d           # imm = 0x4000
140067579:     	xorl	%ecx, %ecx
14006757b:     	movq	%rax, %rdx
14006757e:     	callq	0x14024eff0 <.text+0x24dff0>
140067583:     	ud2

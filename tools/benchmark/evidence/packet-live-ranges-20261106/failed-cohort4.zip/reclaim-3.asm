
D:\CoapticCurrent\packet-body-borrow-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140099080:     	pushq	%rbp
140099081:     	pushq	%r15
140099083:     	pushq	%r14
140099085:     	pushq	%r13
140099087:     	pushq	%r12
140099089:     	pushq	%rsi
14009908a:     	pushq	%rdi
14009908b:     	pushq	%rbx
14009908c:     	subq	$0x308, %rsp            # imm = 0x308
140099093:     	leaq	0x80(%rsp), %rbp
14009909b:     	movaps	%xmm7, 0x270(%rbp)
1400990a2:     	movaps	%xmm6, 0x260(%rbp)
1400990a9:     	leaq	0x5000(%rcx), %rax
1400990b0:     	leaq	0x30(%rcx), %r8
1400990b4:     	xorl	%r9d, %r9d
1400990b7:     	xorl	%esi, %esi
1400990b9:     	leaq	(%rsi,%rsi,4), %r11
1400990bd:     	shlq	$0x6, %r11
1400990c1:     	addq	%r8, %r11
1400990c4:     	movq	%rsi, %r10
1400990c7:     	jmp	0x1400990e4 <.text+0x980e4>
1400990c9:     	nopl	(%rax)
1400990d0:     	incq	%r10
1400990d3:     	addq	$0x140, %r11            # imm = 0x140
1400990da:     	cmpq	$0x40, %r10
1400990de:     	je	0x14009917e <.text+0x9817e>
1400990e4:     	cmpb	$0x1, 0x5000(%rcx,%r10)
1400990ed:     	jne	0x1400990d0 <.text+0x980d0>
1400990ef:     	movq	-0x30(%r11), %rdi
1400990f3:     	cmpq	$0x2, %rdi
1400990f7:     	je	0x1400990d0 <.text+0x980d0>
1400990f9:     	movq	(%r11), %rsi
1400990fc:     	cmpl	$0x1, %edi
1400990ff:     	setne	%bl
140099102:     	testq	%rsi, %rsi
140099105:     	sete	%dil
140099109:     	orb	%bl, %dil
14009910c:     	cmpb	$0x1, %dil
140099110:     	je	0x1400990d0 <.text+0x980d0>
140099112:     	movq	0x250(%rbp), %rdi
140099119:     	cmpq	%rdi, %rsi
14009911c:     	setae	%bl
14009911f:     	testb	%bl, %r9b
140099122:     	jne	0x140099164 <.text+0x98164>
140099124:     	movd	-0x4(%r11), %xmm6
14009912a:     	movzbl	-0x5(%r11), %edx
14009912f:     	movb	%dl, 0x25f(%rbp)
140099135:     	movzbl	-0x6(%r11), %r15d
14009913a:     	movzwl	-0x8(%r11), %r12d
14009913f:     	movl	-0xc(%r11), %r13d
140099143:     	movl	-0x10(%r11), %r14d
140099147:     	movq	-0x18(%r11), %rdx
14009914b:     	movq	%rdx, 0x248(%rbp)
140099152:     	movq	-0x28(%r11), %rdx
140099156:     	movq	-0x20(%r11), %r9
14009915a:     	movq	%r9, 0x240(%rbp)
140099161:     	movq	%rsi, %rdi
140099164:     	movq	%rdi, 0x250(%rbp)
14009916b:     	leaq	0x1(%r10), %rsi
14009916f:     	movb	$0x1, %r9b
140099172:     	cmpq	$0x3f, %r10
140099176:     	jb	0x1400990b9 <.text+0x980b9>
14009917c:     	jmp	0x140099188 <.text+0x98188>
14009917e:     	testb	$0x1, %r9b
140099182:     	je	0x140099400 <.text+0x98400>
140099188:     	cmpq	$0x1f, %rdx
14009918c:     	ja	0x1400991df <.text+0x981df>
14009918e:     	leaq	0x37740(%rcx), %r8
140099195:     	cmpb	$0x1, (%r8,%rdx)
14009919a:     	jne	0x1400991df <.text+0x981df>
14009919c:     	cmpb	$0x0, 0x37760(%rcx,%rdx)
1400991a4:     	jne	0x1400991df <.text+0x981df>
1400991a6:     	movb	$0x0, 0x37740(%rcx,%rdx)
1400991ae:     	decq	0x37788(%rcx)
1400991b5:     	movq	$0x0, 0x43610(%rcx,%rdx,8)
1400991c1:     	leaq	(%rdx,%rdx,8), %r9
1400991c5:     	leaq	(%r9,%r9,2), %r9
1400991c9:     	addq	%rdx, %r9
1400991cc:     	movb	$0x2, 0x36a(%r8,%r9)
1400991d5:     	leaq	(%rdx,%rdx,2), %rdx
1400991d9:     	movb	$0x2, 0x5d(%r8,%rdx,8)
1400991df:     	movd	%xmm6, %edx
1400991e3:     	movl	$0x2c, %r8d
1400991e9:     	movq	0x240(%rbp), %r11
1400991f0:     	movq	0x248(%rbp), %rsi
1400991f7:     	jmp	0x140099213 <.text+0x98213>
1400991f9:     	nopl	(%rax)
140099200:     	incq	%rax
140099203:     	addq	$0x140, %r8             # imm = 0x140
14009920a:     	cmpq	$0x502c, %r8            # imm = 0x502C
140099211:     	je	0x14009926c <.text+0x9826c>
140099213:     	cmpb	$0x1, (%rax)
140099216:     	jne	0x140099200 <.text+0x98200>
140099218:     	cmpl	$0x2, -0x2c(%rcx,%r8)
14009921e:     	je	0x140099200 <.text+0x98200>
140099220:     	cmpw	%dx, (%rcx,%r8)
140099225:     	jne	0x140099200 <.text+0x98200>
140099227:     	cmpl	%r14d, -0xc(%rcx,%r8)
14009922c:     	jne	0x140099200 <.text+0x98200>
14009922e:     	cmpl	%r13d, -0x8(%rcx,%r8)
140099233:     	jne	0x140099200 <.text+0x98200>
140099235:     	cmpw	%r12w, -0x4(%rcx,%r8)
14009923b:     	jne	0x140099200 <.text+0x98200>
14009923d:     	cmpb	%r15b, -0x2(%rcx,%r8)
140099242:     	jne	0x140099200 <.text+0x98200>
140099244:     	movq	-0x1c(%rcx,%r8), %r9
140099249:     	xorq	%r11, %r9
14009924c:     	movq	-0x14(%rcx,%r8), %r10
140099251:     	xorq	%rsi, %r10
140099254:     	orq	%r9, %r10
140099257:     	jne	0x140099200 <.text+0x98200>
140099259:     	movb	$0x0, (%rax)
14009925c:     	decq	0x5048(%rcx)
140099263:     	movq	$0x2, -0x2c(%rcx,%r8)
14009926c:     	movq	%rcx, %rsi
14009926f:     	xorps	%xmm7, %xmm7
140099272:     	movaps	%xmm7, 0x230(%rbp)
140099279:     	movb	$0x0, 0x212(%rbp)
140099280:     	movw	%dx, 0x210(%rbp)
140099287:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
140099290:     	movq	$0x0, 0x213(%rbp)
14009929b:     	movq	$0x8, 0x1f0(%rbp)
1400992a6:     	movq	$0x0, 0x1f8(%rbp)
1400992b1:     	movq	$0x1, 0x200(%rbp)
1400992bc:     	movq	$0x0, 0x208(%rbp)
1400992c7:     	leaq	0x220(%rbp), %rcx
1400992ce:     	leaq	0x1f0(%rbp), %rdx
1400992d5:     	leaq	0x230(%rbp), %r8
1400992dc:     	movl	$0x10, %r9d
1400992e2:     	callq	0x1401108d0 <.text+0x10f8d0>
1400992e7:     	cmpb	$0x0, 0x220(%rbp)
1400992ee:     	jne	0x1400993fc <.text+0x983fc>
1400992f4:     	movq	0x228(%rbp), %rdi
1400992fb:     	movaps	%xmm7, 0xe0(%rbp)
140099302:     	movaps	%xmm7, 0xf0(%rbp)
140099309:     	movaps	%xmm7, 0x100(%rbp)
140099310:     	movaps	%xmm7, 0x110(%rbp)
140099317:     	movaps	%xmm7, 0x120(%rbp)
14009931e:     	movaps	%xmm7, 0x130(%rbp)
140099325:     	movaps	%xmm7, 0x140(%rbp)
14009932c:     	movaps	%xmm7, 0x150(%rbp)
140099333:     	movaps	%xmm7, 0x160(%rbp)
14009933a:     	movaps	%xmm7, 0x170(%rbp)
140099341:     	movaps	%xmm7, 0x180(%rbp)
140099348:     	movaps	%xmm7, 0x190(%rbp)
14009934f:     	movaps	%xmm7, 0x1a0(%rbp)
140099356:     	movaps	%xmm7, 0x1b0(%rbp)
14009935d:     	movaps	%xmm7, 0x1c0(%rbp)
140099364:     	movaps	%xmm7, 0x1d0(%rbp)
14009936b:     	cmpq	$0x11, %rdi
14009936f:     	jae	0x140099424 <.text+0x98424>
140099375:     	leaq	0xe0(%rbp), %rbx
14009937c:     	leaq	0x230(%rbp), %rdx
140099383:     	movq	%rbx, %rcx
140099386:     	movq	%rdi, %r8
140099389:     	callq	0x14024e5a0 <.text+0x24d5a0>
14009938e:     	movw	%di, 0x1e0(%rbp)
140099395:     	movq	$0x0, -0x60(%rbp)
14009939d:     	movq	0x248(%rbp), %rax
1400993a4:     	movq	%rax, -0x48(%rbp)
1400993a8:     	movq	0x240(%rbp), %rax
1400993af:     	movq	%rax, -0x50(%rbp)
1400993b3:     	movl	%r14d, -0x40(%rbp)
1400993b7:     	movl	%r13d, -0x3c(%rbp)
1400993bb:     	movw	%r12w, -0x38(%rbp)
1400993c0:     	movb	%r15b, -0x36(%rbp)
1400993c4:     	movzbl	0x25f(%rbp), %eax
1400993cb:     	movb	%al, -0x35(%rbp)
1400993ce:     	movd	%xmm6, -0x34(%rbp)
1400993d3:     	movq	0x250(%rbp), %rax
1400993da:     	movq	%rax, -0x30(%rbp)
1400993de:     	leaq	-0x28(%rbp), %rcx
1400993e2:     	movl	$0x108, %r8d            # imm = 0x108
1400993e8:     	movq	%rbx, %rdx
1400993eb:     	callq	0x14024e5a0 <.text+0x24d5a0>
1400993f0:     	leaq	-0x60(%rbp), %rdx
1400993f4:     	movq	%rsi, %rcx
1400993f7:     	callq	0x140213770 <.text+0x212770>
1400993fc:     	movb	$0x1, %al
1400993fe:     	jmp	0x140099402 <.text+0x98402>
140099400:     	xorl	%eax, %eax
140099402:     	movaps	0x260(%rbp), %xmm6
140099409:     	movaps	0x270(%rbp), %xmm7
140099410:     	addq	$0x308, %rsp            # imm = 0x308
140099417:     	popq	%rbx
140099418:     	popq	%rdi
140099419:     	popq	%rsi
14009941a:     	popq	%r12
14009941c:     	popq	%r13
14009941e:     	popq	%r14
140099420:     	popq	%r15
140099422:     	popq	%rbp
140099423:     	retq
140099424:     	leaq	0x1d670d(%rip), %r9     # 0x14026fb38
14009942b:     	movl	$0x10, %r8d
140099431:     	xorl	%ecx, %ecx
140099433:     	movq	%rdi, %rdx
140099436:     	callq	0x14024eff0 <.text+0x24dff0>
14009943b:     	ud2

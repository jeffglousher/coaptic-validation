
D:\CoapticCurrent\packet-body-borrow-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140098d00:     	pushq	%rbp
140098d01:     	pushq	%r15
140098d03:     	pushq	%r14
140098d05:     	pushq	%r13
140098d07:     	pushq	%r12
140098d09:     	pushq	%rsi
140098d0a:     	pushq	%rdi
140098d0b:     	pushq	%rbx
140098d0c:     	subq	$0x318, %rsp            # imm = 0x318
140098d13:     	leaq	0x80(%rsp), %rbp
140098d1b:     	movaps	%xmm7, 0x280(%rbp)
140098d22:     	movaps	%xmm6, 0x270(%rbp)
140098d29:     	leaq	0x30(%rcx), %rdx
140098d2d:     	xorl	%r8d, %r8d
140098d30:     	xorl	%r11d, %r11d
140098d33:     	leaq	(%r11,%r11,4), %r10
140098d37:     	shlq	$0x6, %r10
140098d3b:     	addq	%rdx, %r10
140098d3e:     	movq	%r11, %r9
140098d41:     	jmp	0x140098d64 <.text+0x97d64>
140098d43:     	nopw	%cs:(%rax,%rax)
140098d50:     	incq	%r9
140098d53:     	addq	$0x140, %r10            # imm = 0x140
140098d5a:     	cmpq	$0x4, %r9
140098d5e:     	je	0x140098dee <.text+0x97dee>
140098d64:     	cmpb	$0x1, 0x510(%rcx,%r9)
140098d6d:     	jne	0x140098d50 <.text+0x97d50>
140098d6f:     	movq	-0x30(%r10), %rsi
140098d73:     	cmpq	$0x2, %rsi
140098d77:     	je	0x140098d50 <.text+0x97d50>
140098d79:     	movq	(%r10), %r11
140098d7c:     	cmpl	$0x1, %esi
140098d7f:     	setne	%bl
140098d82:     	testq	%r11, %r11
140098d85:     	sete	%sil
140098d89:     	orb	%bl, %sil
140098d8c:     	cmpb	$0x1, %sil
140098d90:     	je	0x140098d50 <.text+0x97d50>
140098d92:     	movq	0x268(%rbp), %rsi
140098d99:     	cmpq	%rsi, %r11
140098d9c:     	setae	%bl
140098d9f:     	testb	%bl, %r8b
140098da2:     	jne	0x140098dd4 <.text+0x97dd4>
140098da4:     	movq	-0x28(%r10), %rax
140098da8:     	movd	-0x4(%r10), %xmm6
140098dae:     	movzbl	-0x5(%r10), %edi
140098db3:     	movzbl	-0x6(%r10), %r15d
140098db8:     	movzwl	-0x8(%r10), %r12d
140098dbd:     	movl	-0xc(%r10), %r13d
140098dc1:     	movl	-0x10(%r10), %r14d
140098dc5:     	movups	-0x20(%r10), %xmm0
140098dca:     	movaps	%xmm0, 0x240(%rbp)
140098dd1:     	movq	%r11, %rsi
140098dd4:     	movq	%rsi, 0x268(%rbp)
140098ddb:     	leaq	0x1(%r9), %r11
140098ddf:     	movb	$0x1, %r8b
140098de2:     	cmpq	$0x3, %r9
140098de6:     	jb	0x140098d33 <.text+0x97d33>
140098dec:     	jmp	0x140098df8 <.text+0x97df8>
140098dee:     	testb	$0x1, %r8b
140098df2:     	je	0x140099038 <.text+0x98038>
140098df8:     	cmpq	$0x1, %rax
140098dfc:     	ja	0x140098e54 <.text+0x97e54>
140098dfe:     	cmpb	$0x1, 0x4420(%rcx,%rax)
140098e06:     	jne	0x140098e54 <.text+0x97e54>
140098e08:     	cmpb	$0x0, 0x4422(%rcx,%rax)
140098e10:     	jne	0x140098e54 <.text+0x97e54>
140098e12:     	movb	$0x0, 0x4420(%rcx,%rax)
140098e1a:     	decq	0x4418(%rcx)
140098e21:     	leaq	0x3a98(%rcx), %rdx
140098e28:     	movq	$0x0, 0x4398(%rcx,%rax,8)
140098e34:     	leaq	(%rax,%rax,8), %r8
140098e38:     	leaq	(%r8,%r8,2), %r8
140098e3c:     	addq	%rax, %r8
140098e3f:     	movb	$0x2, 0x95a(%rdx,%r8)
140098e48:     	leaq	(%rax,%rax,2), %rax
140098e4c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
140098e54:     	movaps	0x240(%rbp), %xmm0
140098e5b:     	movaps	%xmm0, -0x60(%rbp)
140098e5f:     	movl	%r14d, %esi
140098e62:     	movl	%r14d, -0x50(%rbp)
140098e66:     	movl	%r13d, %r14d
140098e69:     	movl	%r13d, -0x4c(%rbp)
140098e6d:     	movl	%r12d, %r13d
140098e70:     	movw	%r12w, -0x48(%rbp)
140098e75:     	movl	%r15d, %r12d
140098e78:     	movb	%r15b, -0x46(%rbp)
140098e7c:     	movl	%edi, %r15d
140098e7f:     	movb	%dil, -0x45(%rbp)
140098e83:     	movd	%xmm6, %edi
140098e87:     	movd	%xmm6, -0x44(%rbp)
140098e8c:     	leaq	-0x60(%rbp), %rdx
140098e90:     	movq	%rcx, 0x260(%rbp)
140098e97:     	callq	0x140213ba0 <.text+0x212ba0>
140098e9c:     	xorps	%xmm7, %xmm7
140098e9f:     	movaps	%xmm7, 0x250(%rbp)
140098ea6:     	movb	$0x0, 0x222(%rbp)
140098ead:     	movw	%di, 0x220(%rbp)
140098eb4:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
140098ebd:     	movq	$0x0, 0x223(%rbp)
140098ec8:     	movq	$0x8, 0x200(%rbp)
140098ed3:     	movq	$0x0, 0x208(%rbp)
140098ede:     	movq	$0x1, 0x210(%rbp)
140098ee9:     	movq	$0x0, 0x218(%rbp)
140098ef4:     	leaq	0x230(%rbp), %rcx
140098efb:     	leaq	0x200(%rbp), %rdx
140098f02:     	leaq	0x250(%rbp), %r8
140098f09:     	movl	$0x10, %r9d
140098f0f:     	callq	0x1401108d0 <.text+0x10f8d0>
140098f14:     	cmpb	$0x0, 0x230(%rbp)
140098f1b:     	jne	0x140099034 <.text+0x98034>
140098f21:     	movq	0x238(%rbp), %rdi
140098f28:     	movaps	%xmm7, 0xe0(%rbp)
140098f2f:     	movaps	%xmm7, 0xf0(%rbp)
140098f36:     	movaps	%xmm7, 0x100(%rbp)
140098f3d:     	movaps	%xmm7, 0x110(%rbp)
140098f44:     	movaps	%xmm7, 0x120(%rbp)
140098f4b:     	movaps	%xmm7, 0x130(%rbp)
140098f52:     	movaps	%xmm7, 0x140(%rbp)
140098f59:     	movaps	%xmm7, 0x150(%rbp)
140098f60:     	movaps	%xmm7, 0x160(%rbp)
140098f67:     	movaps	%xmm7, 0x170(%rbp)
140098f6e:     	movaps	%xmm7, 0x180(%rbp)
140098f75:     	movaps	%xmm7, 0x190(%rbp)
140098f7c:     	movaps	%xmm7, 0x1a0(%rbp)
140098f83:     	movaps	%xmm7, 0x1b0(%rbp)
140098f8a:     	movaps	%xmm7, 0x1c0(%rbp)
140098f91:     	movaps	%xmm7, 0x1d0(%rbp)
140098f98:     	movaps	0x240(%rbp), %xmm0
140098f9f:     	movups	%xmm0, 0x1f0(%rbp)
140098fa6:     	cmpq	$0x11, %rdi
140098faa:     	jae	0x14009905c <.text+0x9805c>
140098fb0:     	leaq	0xe0(%rbp), %rbx
140098fb7:     	leaq	0x250(%rbp), %rdx
140098fbe:     	movq	%rbx, %rcx
140098fc1:     	movq	%rdi, %r8
140098fc4:     	callq	0x14024e5a0 <.text+0x24d5a0>
140098fc9:     	movw	%di, 0x1e0(%rbp)
140098fd0:     	movq	$0x0, -0x60(%rbp)
140098fd8:     	movups	0x1e8(%rbp), %xmm0
140098fdf:     	movups	%xmm0, -0x58(%rbp)
140098fe3:     	movq	0x1f8(%rbp), %rax
140098fea:     	movq	%rax, -0x48(%rbp)
140098fee:     	movl	%esi, -0x40(%rbp)
140098ff1:     	movl	%r14d, -0x3c(%rbp)
140098ff5:     	movw	%r13w, -0x38(%rbp)
140098ffa:     	movb	%r12b, -0x36(%rbp)
140098ffe:     	movb	%r15b, -0x35(%rbp)
140099002:     	movd	%xmm6, -0x34(%rbp)
140099007:     	movq	0x268(%rbp), %rax
14009900e:     	movq	%rax, -0x30(%rbp)
140099012:     	leaq	-0x28(%rbp), %rcx
140099016:     	movl	$0x108, %r8d            # imm = 0x108
14009901c:     	movq	%rbx, %rdx
14009901f:     	callq	0x14024e5a0 <.text+0x24d5a0>
140099024:     	leaq	-0x60(%rbp), %rdx
140099028:     	movq	0x260(%rbp), %rcx
14009902f:     	callq	0x140213910 <.text+0x212910>
140099034:     	movb	$0x1, %al
140099036:     	jmp	0x14009903a <.text+0x9803a>
140099038:     	xorl	%eax, %eax
14009903a:     	movaps	0x270(%rbp), %xmm6
140099041:     	movaps	0x280(%rbp), %xmm7
140099048:     	addq	$0x318, %rsp            # imm = 0x318
14009904f:     	popq	%rbx
140099050:     	popq	%rdi
140099051:     	popq	%rsi
140099052:     	popq	%r12
140099054:     	popq	%r13
140099056:     	popq	%r14
140099058:     	popq	%r15
14009905a:     	popq	%rbp
14009905b:     	retq
14009905c:     	leaq	0x1d6ad5(%rip), %r9     # 0x14026fb38
140099063:     	movl	$0x10, %r8d
140099069:     	xorl	%ecx, %ecx
14009906b:     	movq	%rdi, %rdx
14009906e:     	callq	0x14024eff0 <.text+0x24dff0>
140099073:     	ud2

import tarfile,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;D=Path('D:/codex-work/coaptic-validation/tools/benchmark/evidence/hot-path-windows-20261021')
files=sorted({p for p in R.glob('*.json') if not p.name.startswith('board-')}|{R/n for n in ['paired-summary.jsonl','crossed-summary.jsonl','measure-baseline.py','measure-stages.py','measure-paired.py','measure-crossed-clients.py','make-evidence.py','update-evidence.py']})
with tarfile.open(D/'raw-samples.tar.gz','w:gz') as t:
 for p in files:t.add(p,arcname=p.name)
with (D/'SHA256SUMS').open('w') as f:
 for p in sorted(D.iterdir()):
  if p.name!='SHA256SUMS':f.write(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n')
print(json.dumps({'files':len(files),'archive_bytes':(D/'raw-samples.tar.gz').stat().st_size,'public_bytes':sum(p.stat().st_size for p in D.iterdir())}))

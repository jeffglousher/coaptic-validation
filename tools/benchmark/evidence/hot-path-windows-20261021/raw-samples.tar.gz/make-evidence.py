import hashlib,json,tarfile,platform,sys
from pathlib import Path
R=Path(__file__).resolve().parent
D=Path('D:/codex-work/coaptic-validation/tools/benchmark/evidence/hot-path-windows-20261021');D.mkdir(exist_ok=False)
files=[p for p in R.glob('*.json') if not p.name.startswith('board-')]+list(R.glob('core-*.json'))+[R/'paired-summary.jsonl',R/'measure-baseline.py',R/'measure-stages.py',R/'measure-paired.py']
files=sorted(set(files))
with tarfile.open(D/'raw-samples.tar.gz','w:gz') as a:
 for p in files:a.add(p,arcname=p.name)
analysis=json.loads((R/'analysis.json').read_text())
analysis['scope']='current-source baseline9243417 versus planning-only candidate7f3c58c; no earlier-estimate search; five alternating adjacent diagnostic windows, not independent long-term qualification'
analysis['stage']={}
for size in [64,65536]:
 p=json.loads((R/f'baseline-stage-{size}.json').read_text());stage=next(x for x in p['profile'] if x['kind']=='socket');work=next(x for x in p['profile'] if x['kind']=='work');n=work['recv_attempts']-work['recv_idle'];analysis['stage'][str(size)]={'active_datagrams':n,'active_poll_ns_per_datagram':stage['active_poll_ns']/n,'receive_ns_per_datagram':stage['transport_active_receive_ns']/n,'send_ns_per_datagram':stage['transport_send_ns']/n,'residual_inclusive_ns_per_datagram':(stage['active_poll_ns']-stage['transport_active_receive_ns']-stage['transport_send_ns'])/n,'poll_allocations':stage['poll_allocations'],'body_snapshot_bytes':work['body_snapshot_bytes'],'body_compare_candidate_bytes':work['body_compare_candidate_bytes'],'scope':'nested diagnostic clocks/counters perturb timings;3s process includes idle before/after finite external load; residual is not isolated pure protocol time'}
analysis['current_core']={}
for security in ['unprotected','oscore']:
 x=json.loads((R/f'current-source-core-{security}.json').read_text(encoding='utf-8-sig'));v=sorted(x['latencies_ns']);analysis['current_core'][security]={'p50_ns':v[len(v)//2],'p99_ns':v[int(.99*len(v))],'mean_ns':sum(v)/len(v),'samples':len(v),'measurement':x['measurement']}
(D/'analysis.json').write_text(json.dumps(analysis,indent=2)+'\n')
print(json.dumps({'public':str(D),'files':len(files),'compressed_bytes':(D/'raw-samples.tar.gz').stat().st_size,'stage':analysis['stage'],'current_core':analysis['current_core']}))

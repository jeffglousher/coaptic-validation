import json,socket,subprocess,tempfile,time,statistics,secrets
from pathlib import Path
R=Path(__file__).resolve().parent;S=Path('D:/codex-work/coaptic-validation');PY=Path('D:/CoapticCurrent/matched-benchmark-20261013-venv/Scripts/python.exe')
def port():
 with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
def stats(x):
 v=sorted(x['latencies_ns']);return {'p50_ns':statistics.median(v),'mean_ns':statistics.mean(v),'p99_ns':v[int(.99*(len(v)-1))],'ops_s':len(v)*1e9/x['elapsed_ns']}
rows=[]
for window in range(5):
 cases=[(s,c,k) for s in ['coaptic','aiocoap'] for c in ['native-coaptic','python-independent'] for k in ['unprotected','oscore']]
 if window%2:cases.reverse()
 for server,client,security in cases:
  p=port()
  with tempfile.TemporaryDirectory(prefix='coaptic-hot-cross-') as d:
   credentials=Path(d)/'credentials';credentials.write_bytes(secrets.token_bytes(24))
   if server=='coaptic':cmd=[str(R/'planning-bench-rust-server.exe'),'coaptic-reusable','127.0.0.1',str(p),'64','1472']+([str(credentials)] if security=='oscore' else [])
   else:cmd=[str(PY),str(S/'tools/benchmark/protected/aiocoap_server.py'),'--host','127.0.0.1','--port',str(p),'--bytes','64']+(['--credentials',str(credentials)] if security=='oscore' else [])
   proc=subprocess.Popen(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
   try:
    for _ in range(200):
     if proc.poll() is not None:raise RuntimeError(proc.stderr.read())
     with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:
      try:s.bind(('127.0.0.1',p))
      except OSError:break
     time.sleep(.01)
    else:raise RuntimeError('bind deadline')
    if client=='native-coaptic':cmd=[str(R/'baseline-bench-native-client.exe'),str(p),'64','1000','20','1000','spin',security]+([str(credentials)] if security=='oscore' else [])
    else:cmd=[str(PY),str(S/'tools/benchmark/protected/load.py'),'--host','127.0.0.1','--port',str(p),'--bytes','64','--concurrency','1','--operations','1000','--warmup','20','--timeout-ms','1000','--mode','con','--security','unprotected' if security=='unprotected' else 'OSCORE-AES-CCM-16-64-128','--credentials',str(credentials),'--sequence','0']
    result=subprocess.run(cmd,capture_output=True,text=True,timeout=30)
    if result.returncode:raise RuntimeError({'server':server,'client':client,'security':security,'stdout':result.stdout,'stderr':result.stderr})
    x=json.loads(result.stdout)
    if x.get('completed')!=1000 or x.get('failed',0) or x.get('warmup_failed',0) or x.get('driver_failures',0):raise RuntimeError(x)
    row={'window':window,'server':server,'client':client,'security':security,'bytes':64,'concurrency':1,'mode':'con','summary':stats(x),'raw':x};rows.append(row)
    (R/'crossed-clients.json').write_text(json.dumps(rows));print(json.dumps({k:v for k,v in row.items() if k!='raw'}),flush=True)
   finally:proc.terminate();proc.wait(timeout=5)

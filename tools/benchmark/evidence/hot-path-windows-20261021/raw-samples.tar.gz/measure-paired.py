import hashlib,json,socket,subprocess,tempfile,time,statistics,secrets,sys
from pathlib import Path
R=Path(__file__).resolve().parent; S=Path('D:/codex-work/coaptic-validation')
CLIENT=R/'baseline-bench-load.exe'
PY=Path('D:/CoapticCurrent/matched-benchmark-20261013-venv/Scripts/python.exe')
def stats(x):
 t=sorted(x['latencies_ns']);return {'n':len(t),'p50_ns':statistics.median(t),'p99_ns':t[int(.99*(len(t)-1))],'mean_ns':statistics.mean(t),'elapsed_ns':x.get('elapsed_ns'),'ops_s':len(t)*1e9/x['elapsed_ns'] if x.get('elapsed_ns') else None}
def reserve():
 with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
def run_cell(binary,size,concurrency,ops,mode,security,driver):
 p=reserve()
 with tempfile.TemporaryDirectory(prefix='coaptic-hot-path-') as d:
  cred=Path(d)/'credentials';cred.write_bytes(secrets.token_bytes(24))
  command=[str(binary),'coaptic-reusable','127.0.0.1',str(p),str(size),'1472']
  if security!='unprotected':command.append(str(cred))
  proc=subprocess.Popen(command,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
  try:
   for _ in range(100):
    if proc.poll() is not None:raise RuntimeError(proc.stderr.read())
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:
     try:s.bind(('127.0.0.1',p))
     except OSError:break
    time.sleep(.005)
   else:raise RuntimeError('bind deadline')
   if driver=='rust':args=[str(CLIENT),'127.0.0.1',str(p),str(size),str(concurrency),str(ops),'20','1000',mode]
   else:args=[str(PY),str(S/'tools/benchmark/protected/load.py'),'--host','127.0.0.1','--port',str(p),'--bytes',str(size),'--concurrency',str(concurrency),'--operations',str(ops),'--warmup','20','--timeout-ms','1000','--mode',mode,'--security',security,'--credentials',str(cred),'--sequence','0']
   result=subprocess.run(args,capture_output=True,text=True,timeout=60)
   parsed=json.loads(result.stdout)
   if result.returncode or parsed['failed'] or parsed['warmup_failed'] or parsed['driver_failures']:raise RuntimeError(parsed)
   return parsed
  finally:
   proc.terminate();proc.wait(timeout=5)
cases=[('rust','unprotected',64,1,8000,'con'),('rust','unprotected',64,16,8000,'con'),('rust','unprotected',64,1,8000,'non'),('rust','unprotected',65536,1,128,'con'),('rust','unprotected',65536,16,64,'con'),('python','unprotected',64,1,1000,'con'),('python','OSCORE-AES-CCM-16-64-128',64,1,1000,'con'),('python','OSCORE-AES-CCM-16-64-128',65536,1,16,'con')]
rows=[]
for window in range(5):
 for driver,security,size,c,ops,mode in cases:
  for label in (['baseline','planning'] if window%2==0 else ['planning','baseline']):
   cell=run_cell(R/f'{label}-bench-rust-server.exe',size,c,ops,mode,security,driver)
   row={'window':window,'candidate':label,'driver':driver,'security':security,'bytes':size,'concurrency':c,'mode':mode,'summary':stats(cell),'raw':cell}
   rows.append(row);(R/'paired.json').write_text(json.dumps(rows))
   print(json.dumps({k:v for k,v in row.items() if k!='raw'}),flush=True)
 for label in (['baseline','planning'] if window%2==0 else ['planning','baseline']):
  r=subprocess.run([str(R/f'{label}-bench-core.exe'),'30000'],capture_output=True,text=True,check=True);cell=json.loads(r.stdout)
  (R/f'core-{window}-{label}.json').write_text(r.stdout)
  print(json.dumps({'kind':'in-process','window':window,'candidate':label,'summary':stats(cell)}),flush=True)

import json,sys,subprocess,socket,time,statistics,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent
S=Path('D:/codex-work/coaptic-validation')
sys.path.insert(0,str(S/'tools/benchmark'))
import native_diagnostic as nd
server=R/'baseline-bench-rust-server.exe';client=R/'baseline-bench-native-client.exe';load=R/'baseline-bench-load.exe'
def stats(x):
 t=sorted(x['latencies_ns']);return {'n':len(t),'p50_ns':statistics.median(t),'p99_ns':t[int(.99*(len(t)-1))],'mean_ns':statistics.mean(t),'wall_ns':x.get('elapsed_ns')}
def port():
 with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
for security in ['unprotected','oscore']:
 for size,ops in [(64,2000),(65536,64)]:
  x=nd.measure(server,client,size,ops,20,1000,'spin',security)
  (R/f'baseline-native-{security}-{size}.json').write_text(json.dumps(x))
  print(json.dumps({'kind':'native-complete','security':security,'bytes':size,**stats(x['report'])}),flush=True)
for size,ops in [(64,12000),(65536,256)]:
 p=port();proc=subprocess.Popen(['D:/coaptic-batch-interop-target/release/bench-profile.exe','socket','127.0.0.1',str(p),str(size),'3'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 try:
  time.sleep(.1)
  request=subprocess.run([str(load),'127.0.0.1',str(p),str(size),'1',str(ops),'20','1000','con'],text=True,capture_output=True,check=True)
  out,err=proc.communicate(timeout=6)
  if proc.returncode:raise RuntimeError(err)
  measured=json.loads(request.stdout)
  (R/f'baseline-stage-{size}.json').write_text(json.dumps({'load':measured,'profile':[json.loads(s) for s in out.splitlines() if s.startswith('{')],'stderr':err}))
  print(json.dumps({'kind':'socket-stage','bytes':size,**stats(measured),'profile':[json.loads(s) for s in out.splitlines() if s.startswith('{') and json.loads(s).get('kind') in ['socket','work']]}),flush=True)
 finally:
  if proc.poll() is None:proc.terminate();proc.wait()


D:\CoapticCurrent\borrowed-response-origin-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009b030:     	pushq	%rbp
14009b031:     	pushq	%r15
14009b033:     	pushq	%r14
14009b035:     	pushq	%r13
14009b037:     	pushq	%r12
14009b039:     	pushq	%rsi
14009b03a:     	pushq	%rdi
14009b03b:     	pushq	%rbx
14009b03c:     	subq	$0x318, %rsp            # imm = 0x318
14009b043:     	leaq	0x80(%rsp), %rbp
14009b04b:     	movaps	%xmm7, 0x280(%rbp)
14009b052:     	movaps	%xmm6, 0x270(%rbp)
14009b059:     	leaq	0x30(%rcx), %rdx
14009b05d:     	xorl	%r8d, %r8d
14009b060:     	xorl	%r11d, %r11d
14009b063:     	leaq	(%r11,%r11,4), %r10
14009b067:     	shlq	$0x6, %r10
14009b06b:     	addq	%rdx, %r10
14009b06e:     	movq	%r11, %r9
14009b071:     	jmp	0x14009b094 <.text+0x9a094>
14009b073:     	nopw	%cs:(%rax,%rax)
14009b080:     	incq	%r9
14009b083:     	addq	$0x140, %r10            # imm = 0x140
14009b08a:     	cmpq	$0x4, %r9
14009b08e:     	je	0x14009b11e <.text+0x9a11e>
14009b094:     	cmpb	$0x1, 0x510(%rcx,%r9)
14009b09d:     	jne	0x14009b080 <.text+0x9a080>
14009b09f:     	movq	-0x30(%r10), %rsi
14009b0a3:     	cmpq	$0x2, %rsi
14009b0a7:     	je	0x14009b080 <.text+0x9a080>
14009b0a9:     	movq	(%r10), %r11
14009b0ac:     	cmpl	$0x1, %esi
14009b0af:     	setne	%bl
14009b0b2:     	testq	%r11, %r11
14009b0b5:     	sete	%sil
14009b0b9:     	orb	%bl, %sil
14009b0bc:     	cmpb	$0x1, %sil
14009b0c0:     	je	0x14009b080 <.text+0x9a080>
14009b0c2:     	movq	0x268(%rbp), %rsi
14009b0c9:     	cmpq	%rsi, %r11
14009b0cc:     	setae	%bl
14009b0cf:     	testb	%bl, %r8b
14009b0d2:     	jne	0x14009b104 <.text+0x9a104>
14009b0d4:     	movq	-0x28(%r10), %rax
14009b0d8:     	movd	-0x4(%r10), %xmm6
14009b0de:     	movzbl	-0x5(%r10), %edi
14009b0e3:     	movzbl	-0x6(%r10), %r15d
14009b0e8:     	movzwl	-0x8(%r10), %r12d
14009b0ed:     	movl	-0xc(%r10), %r13d
14009b0f1:     	movl	-0x10(%r10), %r14d
14009b0f5:     	movups	-0x20(%r10), %xmm0
14009b0fa:     	movaps	%xmm0, 0x240(%rbp)
14009b101:     	movq	%r11, %rsi
14009b104:     	movq	%rsi, 0x268(%rbp)
14009b10b:     	leaq	0x1(%r9), %r11
14009b10f:     	movb	$0x1, %r8b
14009b112:     	cmpq	$0x3, %r9
14009b116:     	jb	0x14009b063 <.text+0x9a063>
14009b11c:     	jmp	0x14009b128 <.text+0x9a128>
14009b11e:     	testb	$0x1, %r8b
14009b122:     	je	0x14009b368 <.text+0x9a368>
14009b128:     	cmpq	$0x1, %rax
14009b12c:     	ja	0x14009b184 <.text+0x9a184>
14009b12e:     	cmpb	$0x1, 0x4420(%rcx,%rax)
14009b136:     	jne	0x14009b184 <.text+0x9a184>
14009b138:     	cmpb	$0x0, 0x4422(%rcx,%rax)
14009b140:     	jne	0x14009b184 <.text+0x9a184>
14009b142:     	movb	$0x0, 0x4420(%rcx,%rax)
14009b14a:     	decq	0x4418(%rcx)
14009b151:     	leaq	0x3a98(%rcx), %rdx
14009b158:     	movq	$0x0, 0x4398(%rcx,%rax,8)
14009b164:     	leaq	(%rax,%rax,8), %r8
14009b168:     	leaq	(%r8,%r8,2), %r8
14009b16c:     	addq	%rax, %r8
14009b16f:     	movb	$0x2, 0x95a(%rdx,%r8)
14009b178:     	leaq	(%rax,%rax,2), %rax
14009b17c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009b184:     	movaps	0x240(%rbp), %xmm0
14009b18b:     	movaps	%xmm0, -0x60(%rbp)
14009b18f:     	movl	%r14d, %esi
14009b192:     	movl	%r14d, -0x50(%rbp)
14009b196:     	movl	%r13d, %r14d
14009b199:     	movl	%r13d, -0x4c(%rbp)
14009b19d:     	movl	%r12d, %r13d
14009b1a0:     	movw	%r12w, -0x48(%rbp)
14009b1a5:     	movl	%r15d, %r12d
14009b1a8:     	movb	%r15b, -0x46(%rbp)
14009b1ac:     	movl	%edi, %r15d
14009b1af:     	movb	%dil, -0x45(%rbp)
14009b1b3:     	movd	%xmm6, %edi
14009b1b7:     	movd	%xmm6, -0x44(%rbp)
14009b1bc:     	leaq	-0x60(%rbp), %rdx
14009b1c0:     	movq	%rcx, 0x260(%rbp)
14009b1c7:     	callq	0x140210400 <.text+0x20f400>
14009b1cc:     	xorps	%xmm7, %xmm7
14009b1cf:     	movaps	%xmm7, 0x250(%rbp)
14009b1d6:     	movb	$0x0, 0x222(%rbp)
14009b1dd:     	movw	%di, 0x220(%rbp)
14009b1e4:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009b1ed:     	movq	$0x0, 0x223(%rbp)
14009b1f8:     	movq	$0x8, 0x200(%rbp)
14009b203:     	movq	$0x0, 0x208(%rbp)
14009b20e:     	movq	$0x1, 0x210(%rbp)
14009b219:     	movq	$0x0, 0x218(%rbp)
14009b224:     	leaq	0x230(%rbp), %rcx
14009b22b:     	leaq	0x200(%rbp), %rdx
14009b232:     	leaq	0x250(%rbp), %r8
14009b239:     	movl	$0x10, %r9d
14009b23f:     	callq	0x14010d580 <.text+0x10c580>
14009b244:     	cmpb	$0x0, 0x230(%rbp)
14009b24b:     	jne	0x14009b364 <.text+0x9a364>
14009b251:     	movq	0x238(%rbp), %rdi
14009b258:     	movaps	%xmm7, 0xe0(%rbp)
14009b25f:     	movaps	%xmm7, 0xf0(%rbp)
14009b266:     	movaps	%xmm7, 0x100(%rbp)
14009b26d:     	movaps	%xmm7, 0x110(%rbp)
14009b274:     	movaps	%xmm7, 0x120(%rbp)
14009b27b:     	movaps	%xmm7, 0x130(%rbp)
14009b282:     	movaps	%xmm7, 0x140(%rbp)
14009b289:     	movaps	%xmm7, 0x150(%rbp)
14009b290:     	movaps	%xmm7, 0x160(%rbp)
14009b297:     	movaps	%xmm7, 0x170(%rbp)
14009b29e:     	movaps	%xmm7, 0x180(%rbp)
14009b2a5:     	movaps	%xmm7, 0x190(%rbp)
14009b2ac:     	movaps	%xmm7, 0x1a0(%rbp)
14009b2b3:     	movaps	%xmm7, 0x1b0(%rbp)
14009b2ba:     	movaps	%xmm7, 0x1c0(%rbp)
14009b2c1:     	movaps	%xmm7, 0x1d0(%rbp)
14009b2c8:     	movaps	0x240(%rbp), %xmm0
14009b2cf:     	movups	%xmm0, 0x1f0(%rbp)
14009b2d6:     	cmpq	$0x11, %rdi
14009b2da:     	jae	0x14009b38c <.text+0x9a38c>
14009b2e0:     	leaq	0xe0(%rbp), %rbx
14009b2e7:     	leaq	0x250(%rbp), %rdx
14009b2ee:     	movq	%rbx, %rcx
14009b2f1:     	movq	%rdi, %r8
14009b2f4:     	callq	0x14024ae60 <.text+0x249e60>
14009b2f9:     	movw	%di, 0x1e0(%rbp)
14009b300:     	movq	$0x0, -0x60(%rbp)
14009b308:     	movups	0x1e8(%rbp), %xmm0
14009b30f:     	movups	%xmm0, -0x58(%rbp)
14009b313:     	movq	0x1f8(%rbp), %rax
14009b31a:     	movq	%rax, -0x48(%rbp)
14009b31e:     	movl	%esi, -0x40(%rbp)
14009b321:     	movl	%r14d, -0x3c(%rbp)
14009b325:     	movw	%r13w, -0x38(%rbp)
14009b32a:     	movb	%r12b, -0x36(%rbp)
14009b32e:     	movb	%r15b, -0x35(%rbp)
14009b332:     	movd	%xmm6, -0x34(%rbp)
14009b337:     	movq	0x268(%rbp), %rax
14009b33e:     	movq	%rax, -0x30(%rbp)
14009b342:     	leaq	-0x28(%rbp), %rcx
14009b346:     	movl	$0x108, %r8d            # imm = 0x108
14009b34c:     	movq	%rbx, %rdx
14009b34f:     	callq	0x14024ae60 <.text+0x249e60>
14009b354:     	leaq	-0x60(%rbp), %rdx
14009b358:     	movq	0x260(%rbp), %rcx
14009b35f:     	callq	0x140210170 <.text+0x20f170>
14009b364:     	movb	$0x1, %al
14009b366:     	jmp	0x14009b36a <.text+0x9a36a>
14009b368:     	xorl	%eax, %eax
14009b36a:     	movaps	0x270(%rbp), %xmm6
14009b371:     	movaps	0x280(%rbp), %xmm7
14009b378:     	addq	$0x318, %rsp            # imm = 0x318
14009b37f:     	popq	%rbx
14009b380:     	popq	%rdi
14009b381:     	popq	%rsi
14009b382:     	popq	%r12
14009b384:     	popq	%r13
14009b386:     	popq	%r14
14009b388:     	popq	%r15
14009b38a:     	popq	%rbp
14009b38b:     	retq
14009b38c:     	leaq	0x1c87e5(%rip), %r9     # 0x140263b78
14009b393:     	movl	$0x10, %r8d
14009b399:     	xorl	%ecx, %ecx
14009b39b:     	movq	%rdi, %rdx
14009b39e:     	callq	0x14024b8b0 <.text+0x24a8b0>
14009b3a3:     	ud2

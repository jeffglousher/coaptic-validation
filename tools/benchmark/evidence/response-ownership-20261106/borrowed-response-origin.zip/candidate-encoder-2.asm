
D:\CoapticCurrent\borrowed-response-origin-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140066830:     	pushq	%rbp
140066831:     	pushq	%r15
140066833:     	pushq	%r14
140066835:     	pushq	%r13
140066837:     	pushq	%r12
140066839:     	pushq	%rsi
14006683a:     	pushq	%rdi
14006683b:     	pushq	%rbx
14006683c:     	subq	$0x4f8, %rsp            # imm = 0x4F8
140066843:     	leaq	0x80(%rsp), %rbp
14006684b:     	movq	%r9, %rbx
14006684e:     	movq	%r8, %r14
140066851:     	movq	%rdx, %rdi
140066854:     	movq	%rcx, %rsi
140066857:     	movq	0x4f0(%rbp), %r12
14006685e:     	leaq	-0x10(%rbp), %rcx
140066862:     	movl	$0x400, %r8d            # imm = 0x400
140066868:     	xorl	%edx, %edx
14006686a:     	callq	0x14024ae72 <.text+0x249e72>
14006686f:     	movq	0x8(%r12), %r13
140066874:     	movl	$0x3, %eax
140066879:     	cmpq	$0x3, %r13
14006687d:     	ja	0x140066a9c <.text+0x65a9c>
140066883:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
14006688c:     	jne	0x140066a9c <.text+0x65a9c>
140066892:     	movq	0x2b750(%rdi,%r13,8), %rdx
14006689a:     	cmpq	$0x4001, %rdx           # imm = 0x4001
1400668a1:     	jae	0x140066af8 <.text+0x65af8>
1400668a7:     	movq	0x10(%r12), %rcx
1400668ac:     	movq	0x18(%r12), %r15
1400668b1:     	movq	%r15, %r8
1400668b4:     	movl	$0xb, %eax
1400668b9:     	addq	%rcx, %r8
1400668bc:     	jb	0x140066a9c <.text+0x65a9c>
1400668c2:     	cmpq	$0x400, %r15            # imm = 0x400
1400668c9:     	ja	0x140066a9c <.text+0x65a9c>
1400668cf:     	cmpq	%rdx, %r8
1400668d2:     	ja	0x140066a9c <.text+0x65a9c>
1400668d8:     	movq	%r13, %rax
1400668db:     	shlq	$0xe, %rax
1400668df:     	leaq	(%rdi,%rax), %rdx
1400668e3:     	addq	$0x1b750, %rdx          # imm = 0x1B750
1400668ea:     	addq	%rcx, %rdx
1400668ed:     	leaq	-0x10(%rbp), %rcx
1400668f1:     	movq	%r15, %r8
1400668f4:     	callq	0x14024ae60 <.text+0x249e60>
1400668f9:     	cmpb	$0x0, 0x4f8(%rbp)
140066900:     	je	0x140066918 <.text+0x65918>
140066902:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
140066909:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
140066912:     	jne	0x140066ab7 <.text+0x65ab7>
140066918:     	movq	$0x0, 0x470(%rbp)
140066923:     	movq	%rdi, %rcx
140066926:     	callq	0x1400978c0 <.text+0x968c0>
14006692b:     	testb	$0x1, %al
14006692d:     	je	0x140066aea <.text+0x65aea>
140066933:     	movq	%rdx, %r13
140066936:     	movq	0x500(%rbp), %rdx
14006693d:     	movzwl	0x4e8(%rbp), %ecx
140066944:     	movzbl	0x4e0(%rbp), %eax
14006694b:     	movq	(%r12), %r8
14006694f:     	movq	0x470(%rbp), %r9
140066956:     	movq	%r9, 0x438(%rbp)
14006695d:     	movq	0x468(%rbp), %r9
140066964:     	movq	%r9, 0x440(%rbp)
14006696b:     	movq	%r8, 0x448(%rbp)
140066972:     	movzbl	0x4f8(%rbp), %r8d
14006697a:     	movb	%r8b, 0x450(%rbp)
140066981:     	movups	0x60(%r14), %xmm0
140066986:     	movups	0x6c(%r14), %xmm1
14006698b:     	movups	%xmm1, 0x3fc(%rbp)
140066992:     	movaps	%xmm0, 0x3f0(%rbp)
140066999:     	leaq	0x8e(%r14), %r8
1400669a0:     	movq	0x7e(%r14), %r9
1400669a4:     	movq	0x85(%r14), %r10
1400669ab:     	movq	%r10, 0x45f(%rbp)
1400669b2:     	movq	%r9, 0x458(%rbp)
1400669b9:     	leaq	0x458(%rbp), %r9
1400669c0:     	movq	%r9, 0x68(%rsp)
1400669c5:     	movq	%rdx, 0x60(%rsp)
1400669ca:     	movq	%r14, 0x58(%rsp)
1400669cf:     	leaq	0x438(%rbp), %rdx
1400669d6:     	movq	%rdx, 0x50(%rsp)
1400669db:     	movq	%r15, 0x48(%rsp)
1400669e0:     	leaq	-0x10(%rbp), %rdx
1400669e4:     	movq	%rdx, 0x40(%rsp)
1400669e9:     	movq	%rbx, 0x38(%rsp)
1400669ee:     	movq	%r8, 0x30(%rsp)
1400669f3:     	movw	%cx, 0x28(%rsp)
1400669f8:     	movb	%al, 0x20(%rsp)
1400669fc:     	leaq	0x418(%rbp), %rcx
140066a03:     	leaq	0x3f0(%rbp), %r8
140066a0a:     	movq	%rdi, %rdx
140066a0d:     	movq	%r13, %r9
140066a10:     	callq	0x1400804e0 <.text+0x7f4e0>
140066a15:     	cmpb	$-0x1, 0x418(%rbp)
140066a1c:     	je	0x140066aef <.text+0x65aef>
140066a22:     	cmpb	$0x1, 0x37740(%rdi,%r13)
140066a2b:     	jne	0x140066a85 <.text+0x65a85>
140066a2d:     	cmpb	$0x0, 0x37760(%rdi,%r13)
140066a36:     	jne	0x140066a85 <.text+0x65a85>
140066a38:     	movb	$0x0, 0x37740(%rdi,%r13)
140066a41:     	decq	0x37788(%rdi)
140066a48:     	leaq	0x37740(%rdi), %rax
140066a4f:     	movq	$0x0, 0x43610(%rdi,%r13,8)
140066a5b:     	leaq	(,%r13,8), %rcx
140066a63:     	addq	%r13, %rcx
140066a66:     	leaq	(%rcx,%rcx,2), %rcx
140066a6a:     	addq	%r13, %rcx
140066a6d:     	movb	$0x2, 0x36a(%rax,%rcx)
140066a75:     	leaq	(,%r13,2), %rcx
140066a7d:     	addq	%r13, %rcx
140066a80:     	movb	$0x2, 0x5d(%rax,%rcx,8)
140066a85:     	movups	0x418(%rbp), %xmm0
140066a8c:     	movups	0x428(%rbp), %xmm1
140066a93:     	movups	%xmm1, 0x10(%rsi)
140066a97:     	movups	%xmm0, (%rsi)
140066a9a:     	jmp	0x140066aa3 <.text+0x65aa3>
140066a9c:     	movb	$0xa, (%rsi)
140066a9f:     	movq	%rax, 0x8(%rsi)
140066aa3:     	addq	$0x4f8, %rsp            # imm = 0x4F8
140066aaa:     	popq	%rbx
140066aab:     	popq	%rdi
140066aac:     	popq	%rsi
140066aad:     	popq	%r12
140066aaf:     	popq	%r13
140066ab1:     	popq	%r14
140066ab3:     	popq	%r15
140066ab5:     	popq	%rbp
140066ab6:     	retq
140066ab7:     	addq	%rdi, %rax
140066aba:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
140066ac0:     	movq	0x98(%rax), %rax
140066ac7:     	movq	%rax, 0x468(%rbp)
140066ace:     	movl	$0x1, %eax
140066ad3:     	movq	%rax, 0x470(%rbp)
140066ada:     	movq	%rdi, %rcx
140066add:     	callq	0x1400978c0 <.text+0x968c0>
140066ae2:     	testb	$0x1, %al
140066ae4:     	jne	0x140066933 <.text+0x65933>
140066aea:     	movb	$0x9, (%rsi)
140066aed:     	jmp	0x140066aa3 <.text+0x65aa3>
140066aef:     	movq	%r13, 0x8(%rsi)
140066af3:     	movb	$-0x1, (%rsi)
140066af6:     	jmp	0x140066aa3 <.text+0x65aa3>
140066af8:     	leaq	0x200159(%rip), %r9     # 0x140266c58
140066aff:     	movl	$0x4000, %r8d           # imm = 0x4000
140066b05:     	xorl	%ecx, %ecx
140066b07:     	callq	0x14024b8b0 <.text+0x24a8b0>
140066b0c:     	ud2

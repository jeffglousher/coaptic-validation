
D:\CoapticCurrent\borrowed-response-origin-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140066540:     	pushq	%rbp
140066541:     	pushq	%r15
140066543:     	pushq	%r14
140066545:     	pushq	%r13
140066547:     	pushq	%r12
140066549:     	pushq	%rsi
14006654a:     	pushq	%rdi
14006654b:     	pushq	%rbx
14006654c:     	subq	$0x508, %rsp            # imm = 0x508
140066553:     	leaq	0x80(%rsp), %rbp
14006655b:     	movq	%r9, %rbx
14006655e:     	movq	%r8, %r14
140066561:     	movq	%rdx, %rdi
140066564:     	movq	%rcx, %rsi
140066567:     	movq	0x500(%rbp), %r12
14006656e:     	movq	%rbp, %rcx
140066571:     	movl	$0x400, %r8d            # imm = 0x400
140066577:     	xorl	%edx, %edx
140066579:     	callq	0x14024ae72 <.text+0x249e72>
14006657e:     	movq	0x8(%r12), %r13
140066583:     	movl	$0x3, %eax
140066588:     	cmpq	$0x3, %r13
14006658c:     	ja	0x1400667b5 <.text+0x657b5>
140066592:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
14006659b:     	jne	0x1400667b5 <.text+0x657b5>
1400665a1:     	movq	0x2b750(%rdi,%r13,8), %rdx
1400665a9:     	cmpq	$0x4001, %rdx           # imm = 0x4001
1400665b0:     	jae	0x140066811 <.text+0x65811>
1400665b6:     	movq	0x10(%r12), %rcx
1400665bb:     	movq	0x18(%r12), %r15
1400665c0:     	movq	%r15, %r8
1400665c3:     	movl	$0xb, %eax
1400665c8:     	addq	%rcx, %r8
1400665cb:     	jb	0x1400667b5 <.text+0x657b5>
1400665d1:     	cmpq	$0x400, %r15            # imm = 0x400
1400665d8:     	ja	0x1400667b5 <.text+0x657b5>
1400665de:     	cmpq	%rdx, %r8
1400665e1:     	ja	0x1400667b5 <.text+0x657b5>
1400665e7:     	movq	%r13, %rax
1400665ea:     	shlq	$0xe, %rax
1400665ee:     	leaq	(%rdi,%rax), %rdx
1400665f2:     	addq	$0x1b750, %rdx          # imm = 0x1B750
1400665f9:     	addq	%rcx, %rdx
1400665fc:     	movq	%rbp, %rcx
1400665ff:     	movq	%r15, %r8
140066602:     	callq	0x14024ae60 <.text+0x249e60>
140066607:     	cmpb	$0x0, 0x508(%rbp)
14006660e:     	je	0x140066626 <.text+0x65626>
140066610:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
140066617:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
140066620:     	jne	0x1400667d0 <.text+0x657d0>
140066626:     	movq	$0x0, 0x480(%rbp)
140066631:     	movq	%rdi, %rcx
140066634:     	callq	0x1400978c0 <.text+0x968c0>
140066639:     	testb	$0x1, %al
14006663b:     	je	0x140066803 <.text+0x65803>
140066641:     	movq	%rdx, %r13
140066644:     	movq	0x518(%rbp), %rdx
14006664b:     	movq	0x510(%rbp), %r8
140066652:     	movzwl	0x4f8(%rbp), %ecx
140066659:     	movzbl	0x4f0(%rbp), %eax
140066660:     	movq	(%r12), %r9
140066664:     	movq	0x480(%rbp), %r10
14006666b:     	movq	%r10, 0x448(%rbp)
140066672:     	movq	0x478(%rbp), %r10
140066679:     	movq	%r10, 0x450(%rbp)
140066680:     	movq	%r9, 0x458(%rbp)
140066687:     	movzbl	0x508(%rbp), %r9d
14006668f:     	movb	%r9b, 0x460(%rbp)
140066696:     	movups	0x60(%r14), %xmm0
14006669b:     	movups	0x6c(%r14), %xmm1
1400666a0:     	movups	%xmm1, 0x40c(%rbp)
1400666a7:     	movaps	%xmm0, 0x400(%rbp)
1400666ae:     	leaq	0x8e(%r14), %r9
1400666b5:     	movq	0x7e(%r14), %r10
1400666b9:     	movq	0x85(%r14), %r11
1400666c0:     	movq	%r11, 0x46f(%rbp)
1400666c7:     	movq	%r10, 0x468(%rbp)
1400666ce:     	leaq	0x468(%rbp), %r10
1400666d5:     	movq	%r10, 0x70(%rsp)
1400666da:     	movq	%rdx, 0x68(%rsp)
1400666df:     	movq	%r8, 0x60(%rsp)
1400666e4:     	movq	%r14, 0x58(%rsp)
1400666e9:     	leaq	0x448(%rbp), %rdx
1400666f0:     	movq	%rdx, 0x50(%rsp)
1400666f5:     	movq	%r15, 0x48(%rsp)
1400666fa:     	movq	%rbp, %rdx
1400666fd:     	movq	%rdx, 0x40(%rsp)
140066702:     	movq	%rbx, 0x38(%rsp)
140066707:     	movq	%r9, 0x30(%rsp)
14006670c:     	movw	%cx, 0x28(%rsp)
140066711:     	movb	%al, 0x20(%rsp)
140066715:     	leaq	0x428(%rbp), %rcx
14006671c:     	leaq	0x400(%rbp), %r8
140066723:     	movq	%rdi, %rdx
140066726:     	movq	%r13, %r9
140066729:     	callq	0x14007ecf0 <.text+0x7dcf0>
14006672e:     	cmpb	$-0x1, 0x428(%rbp)
140066735:     	je	0x140066808 <.text+0x65808>
14006673b:     	cmpb	$0x1, 0x37740(%rdi,%r13)
140066744:     	jne	0x14006679e <.text+0x6579e>
140066746:     	cmpb	$0x0, 0x37760(%rdi,%r13)
14006674f:     	jne	0x14006679e <.text+0x6579e>
140066751:     	movb	$0x0, 0x37740(%rdi,%r13)
14006675a:     	decq	0x37788(%rdi)
140066761:     	leaq	0x37740(%rdi), %rax
140066768:     	movq	$0x0, 0x43610(%rdi,%r13,8)
140066774:     	leaq	(,%r13,8), %rcx
14006677c:     	addq	%r13, %rcx
14006677f:     	leaq	(%rcx,%rcx,2), %rcx
140066783:     	addq	%r13, %rcx
140066786:     	movb	$0x2, 0x36a(%rax,%rcx)
14006678e:     	leaq	(,%r13,2), %rcx
140066796:     	addq	%r13, %rcx
140066799:     	movb	$0x2, 0x5d(%rax,%rcx,8)
14006679e:     	movups	0x428(%rbp), %xmm0
1400667a5:     	movups	0x438(%rbp), %xmm1
1400667ac:     	movups	%xmm1, 0x10(%rsi)
1400667b0:     	movups	%xmm0, (%rsi)
1400667b3:     	jmp	0x1400667bc <.text+0x657bc>
1400667b5:     	movb	$0xa, (%rsi)
1400667b8:     	movq	%rax, 0x8(%rsi)
1400667bc:     	addq	$0x508, %rsp            # imm = 0x508
1400667c3:     	popq	%rbx
1400667c4:     	popq	%rdi
1400667c5:     	popq	%rsi
1400667c6:     	popq	%r12
1400667c8:     	popq	%r13
1400667ca:     	popq	%r14
1400667cc:     	popq	%r15
1400667ce:     	popq	%rbp
1400667cf:     	retq
1400667d0:     	addq	%rdi, %rax
1400667d3:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
1400667d9:     	movq	0x98(%rax), %rax
1400667e0:     	movq	%rax, 0x478(%rbp)
1400667e7:     	movl	$0x1, %eax
1400667ec:     	movq	%rax, 0x480(%rbp)
1400667f3:     	movq	%rdi, %rcx
1400667f6:     	callq	0x1400978c0 <.text+0x968c0>
1400667fb:     	testb	$0x1, %al
1400667fd:     	jne	0x140066641 <.text+0x65641>
140066803:     	movb	$0x9, (%rsi)
140066806:     	jmp	0x1400667bc <.text+0x657bc>
140066808:     	movq	%r13, 0x8(%rsi)
14006680c:     	movb	$-0x1, (%rsi)
14006680f:     	jmp	0x1400667bc <.text+0x657bc>
140066811:     	leaq	0x200440(%rip), %r9     # 0x140266c58
140066818:     	movl	$0x4000, %r8d           # imm = 0x4000
14006681e:     	xorl	%ecx, %ecx
140066820:     	callq	0x14024b8b0 <.text+0x24a8b0>
140066825:     	ud2

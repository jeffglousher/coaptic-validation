
D:\CoapticCurrent\borrowed-response-origin-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009b770:     	pushq	%rbp
14009b771:     	pushq	%r15
14009b773:     	pushq	%r14
14009b775:     	pushq	%r13
14009b777:     	pushq	%r12
14009b779:     	pushq	%rsi
14009b77a:     	pushq	%rdi
14009b77b:     	pushq	%rbx
14009b77c:     	subq	$0x318, %rsp            # imm = 0x318
14009b783:     	leaq	0x80(%rsp), %rbp
14009b78b:     	movaps	%xmm7, 0x280(%rbp)
14009b792:     	movdqa	%xmm6, 0x270(%rbp)
14009b79a:     	movq	0xe8(%rcx), %r8
14009b7a1:     	testq	%r8, %r8
14009b7a4:     	je	0x14009bb84 <.text+0x9ab84>
14009b7aa:     	movq	0x88(%rcx), %r11
14009b7b1:     	movq	0xe0(%rcx), %rdx
14009b7b8:     	movq	0xc8(%rcx), %rax
14009b7bf:     	movq	0xd0(%rcx), %r9
14009b7c6:     	leaq	0x30(%rax), %rsi
14009b7ca:     	xorl	%ebx, %ebx
14009b7cc:     	xorl	%edi, %edi
14009b7ce:     	leaq	(%rdi,%rdi,4), %r12
14009b7d2:     	shlq	$0x6, %r12
14009b7d6:     	addq	%rsi, %r12
14009b7d9:     	jmp	0x14009b7f3 <.text+0x9a7f3>
14009b7db:     	nopl	(%rax,%rax)
14009b7e0:     	incq	%rdi
14009b7e3:     	addq	$0x140, %r12            # imm = 0x140
14009b7ea:     	cmpq	%r8, %rdi
14009b7ed:     	jae	0x14009b8bc <.text+0x9a8bc>
14009b7f3:     	cmpq	%r9, %rdi
14009b7f6:     	setb	%r15b
14009b7fa:     	andb	(%rdx,%rdi), %r15b
14009b7fe:     	cmpb	$0x1, %r15b
14009b802:     	jne	0x14009b7e0 <.text+0x9a7e0>
14009b804:     	movq	-0x30(%r12), %r15
14009b809:     	cmpq	$0x2, %r15
14009b80d:     	je	0x14009b7e0 <.text+0x9a7e0>
14009b80f:     	movq	(%r12), %r13
14009b813:     	cmpl	$0x1, %r15d
14009b817:     	setne	%r15b
14009b81b:     	testq	%r13, %r13
14009b81e:     	sete	%r10b
14009b822:     	orb	%r15b, %r10b
14009b825:     	cmpb	$0x1, %r10b
14009b829:     	je	0x14009b7e0 <.text+0x9a7e0>
14009b82b:     	movq	0x260(%rbp), %r15
14009b832:     	cmpq	%r15, %r13
14009b835:     	setae	%r10b
14009b839:     	testb	%r10b, %bl
14009b83c:     	jne	0x14009b8a5 <.text+0x9a8a5>
14009b83e:     	movq	-0x28(%r12), %r10
14009b843:     	movq	%r10, 0x250(%rbp)
14009b84a:     	movq	-0x20(%r12), %r10
14009b84f:     	movq	%r10, 0x248(%rbp)
14009b856:     	movd	-0x4(%r12), %xmm6
14009b85d:     	movzbl	-0x5(%r12), %r10d
14009b863:     	movb	%r10b, 0x26e(%rbp)
14009b86a:     	movzbl	-0x6(%r12), %r10d
14009b870:     	movb	%r10b, 0x26f(%rbp)
14009b877:     	movzwl	-0x8(%r12), %r10d
14009b87d:     	movw	%r10w, 0x26c(%rbp)
14009b885:     	movl	-0xc(%r12), %r10d
14009b88a:     	movl	%r10d, 0x268(%rbp)
14009b891:     	movl	-0x10(%r12), %r14d
14009b896:     	movq	-0x18(%r12), %r10
14009b89b:     	movq	%r10, 0x258(%rbp)
14009b8a2:     	movq	%r13, %r15
14009b8a5:     	movq	%r15, 0x260(%rbp)
14009b8ac:     	incq	%rdi
14009b8af:     	movb	$0x1, %bl
14009b8b1:     	cmpq	%r8, %rdi
14009b8b4:     	jb	0x14009b7ce <.text+0x9a7ce>
14009b8ba:     	jmp	0x14009b8c5 <.text+0x9a8c5>
14009b8bc:     	testb	$0x1, %bl
14009b8bf:     	je	0x14009bb84 <.text+0x9ab84>
14009b8c5:     	movq	0x250(%rbp), %r10
14009b8cc:     	cmpq	%r11, %r10
14009b8cf:     	jae	0x14009b925 <.text+0x9a925>
14009b8d1:     	movq	0x80(%rcx), %r11
14009b8d8:     	cmpb	$0x1, (%r11,%r10)
14009b8dd:     	jne	0x14009b925 <.text+0x9a925>
14009b8df:     	cmpq	0xa0(%rcx), %r10
14009b8e6:     	jae	0x14009b8f6 <.text+0x9a8f6>
14009b8e8:     	movq	0x98(%rcx), %rsi
14009b8ef:     	cmpb	$0x0, (%rsi,%r10)
14009b8f4:     	jne	0x14009b925 <.text+0x9a925>
14009b8f6:     	movb	$0x0, (%r11,%r10)
14009b8fb:     	decq	0xb0(%rcx)
14009b902:     	cmpq	0x70(%rcx), %r10
14009b906:     	jae	0x14009b925 <.text+0x9a925>
14009b908:     	movq	0x68(%rcx), %r11
14009b90c:     	imulq	$0x58, %r10, %r10
14009b910:     	movq	$0x0, 0x30(%r11,%r10)
14009b919:     	movb	$0x2, 0x52(%r11,%r10)
14009b91f:     	movb	$0x2, 0x25(%r11,%r10)
14009b925:     	leaq	0xc0(%rcx), %rsi
14009b92c:     	movd	%xmm6, %r10d
14009b931:     	addq	$0x2c, %rax
14009b935:     	xorl	%r11d, %r11d
14009b938:     	movq	0x248(%rbp), %r15
14009b93f:     	movzbl	0x26e(%rbp), %r12d
14009b947:     	jmp	0x14009b962 <.text+0x9a962>
14009b949:     	nopl	(%rax)
14009b950:     	incq	%r11
14009b953:     	addq	$0x140, %rax            # imm = 0x140
14009b959:     	cmpq	%r11, %r8
14009b95c:     	je	0x14009b9ee <.text+0x9a9ee>
14009b962:     	cmpq	%r9, %r11
14009b965:     	setb	%bl
14009b968:     	andb	(%rdx,%r11), %bl
14009b96c:     	cmpb	$0x1, %bl
14009b96f:     	jne	0x14009b950 <.text+0x9a950>
14009b971:     	cmpl	$0x2, -0x2c(%rax)
14009b975:     	je	0x14009b950 <.text+0x9a950>
14009b977:     	cmpw	%r10w, (%rax)
14009b97b:     	jne	0x14009b950 <.text+0x9a950>
14009b97d:     	cmpl	%r14d, -0xc(%rax)
14009b981:     	jne	0x14009b950 <.text+0x9a950>
14009b983:     	movl	0x268(%rbp), %edi
14009b989:     	cmpl	%edi, -0x8(%rax)
14009b98c:     	jne	0x14009b950 <.text+0x9a950>
14009b98e:     	movzwl	0x26c(%rbp), %edi
14009b995:     	cmpw	%di, -0x4(%rax)
14009b999:     	jne	0x14009b950 <.text+0x9a950>
14009b99b:     	movzbl	0x26f(%rbp), %ebx
14009b9a2:     	cmpb	%bl, -0x2(%rax)
14009b9a5:     	jne	0x14009b950 <.text+0x9a950>
14009b9a7:     	movq	-0x1c(%rax), %rdi
14009b9ab:     	xorq	%r15, %rdi
14009b9ae:     	movq	-0x14(%rax), %rbx
14009b9b2:     	xorq	0x258(%rbp), %rbx
14009b9b9:     	orq	%rdi, %rbx
14009b9bc:     	jne	0x14009b950 <.text+0x9a950>
14009b9be:     	cmpq	%r8, %r11
14009b9c1:     	jae	0x14009b9ee <.text+0x9a9ee>
14009b9c3:     	cmpq	0x100(%rcx), %r11
14009b9ca:     	jae	0x14009b9da <.text+0x9a9da>
14009b9cc:     	movq	0xf8(%rcx), %r8
14009b9d3:     	cmpb	$0x0, (%r8,%r11)
14009b9d8:     	jne	0x14009b9ee <.text+0x9a9ee>
14009b9da:     	movb	$0x0, (%rdx,%r11)
14009b9df:     	decq	0x110(%rcx)
14009b9e6:     	movq	$0x2, -0x2c(%rax)
14009b9ee:     	xorps	%xmm7, %xmm7
14009b9f1:     	movaps	%xmm7, 0x230(%rbp)
14009b9f8:     	movb	$0x0, 0x212(%rbp)
14009b9ff:     	movw	%r10w, 0x210(%rbp)
14009ba07:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
14009ba10:     	movq	$0x0, 0x213(%rbp)
14009ba1b:     	movq	$0x8, 0x1f0(%rbp)
14009ba26:     	movq	$0x0, 0x1f8(%rbp)
14009ba31:     	movq	$0x1, 0x200(%rbp)
14009ba3c:     	movq	$0x0, 0x208(%rbp)
14009ba47:     	leaq	0x220(%rbp), %rcx
14009ba4e:     	leaq	0x1f0(%rbp), %rdx
14009ba55:     	leaq	0x230(%rbp), %r8
14009ba5c:     	movl	$0x10, %r9d
14009ba62:     	callq	0x14010d580 <.text+0x10c580>
14009ba67:     	cmpb	$0x0, 0x220(%rbp)
14009ba6e:     	jne	0x14009bb80 <.text+0x9ab80>
14009ba74:     	movq	0x228(%rbp), %rdi
14009ba7b:     	movaps	%xmm7, 0xe0(%rbp)
14009ba82:     	movaps	%xmm7, 0xf0(%rbp)
14009ba89:     	movaps	%xmm7, 0x100(%rbp)
14009ba90:     	movaps	%xmm7, 0x110(%rbp)
14009ba97:     	movaps	%xmm7, 0x120(%rbp)
14009ba9e:     	movaps	%xmm7, 0x130(%rbp)
14009baa5:     	movaps	%xmm7, 0x140(%rbp)
14009baac:     	movaps	%xmm7, 0x150(%rbp)
14009bab3:     	movaps	%xmm7, 0x160(%rbp)
14009baba:     	movaps	%xmm7, 0x170(%rbp)
14009bac1:     	movaps	%xmm7, 0x180(%rbp)
14009bac8:     	movaps	%xmm7, 0x190(%rbp)
14009bacf:     	movaps	%xmm7, 0x1a0(%rbp)
14009bad6:     	movaps	%xmm7, 0x1b0(%rbp)
14009badd:     	movaps	%xmm7, 0x1c0(%rbp)
14009bae4:     	movaps	%xmm7, 0x1d0(%rbp)
14009baeb:     	cmpq	$0x11, %rdi
14009baef:     	jae	0x14009bba8 <.text+0x9aba8>
14009baf5:     	leaq	0xe0(%rbp), %rbx
14009bafc:     	leaq	0x230(%rbp), %rdx
14009bb03:     	movq	%rbx, %rcx
14009bb06:     	movq	%rdi, %r8
14009bb09:     	callq	0x14024ae60 <.text+0x249e60>
14009bb0e:     	movw	%di, 0x1e0(%rbp)
14009bb15:     	movq	$0x0, -0x60(%rbp)
14009bb1d:     	movq	0x258(%rbp), %rax
14009bb24:     	movq	%rax, -0x48(%rbp)
14009bb28:     	movq	%r15, -0x50(%rbp)
14009bb2c:     	movl	%r14d, -0x40(%rbp)
14009bb30:     	movl	0x268(%rbp), %eax
14009bb36:     	movl	%eax, -0x3c(%rbp)
14009bb39:     	movzwl	0x26c(%rbp), %eax
14009bb40:     	movw	%ax, -0x38(%rbp)
14009bb44:     	movzbl	0x26f(%rbp), %eax
14009bb4b:     	movb	%al, -0x36(%rbp)
14009bb4e:     	movb	%r12b, -0x35(%rbp)
14009bb52:     	movd	%xmm6, -0x34(%rbp)
14009bb57:     	movq	0x260(%rbp), %rax
14009bb5e:     	movq	%rax, -0x30(%rbp)
14009bb62:     	leaq	-0x28(%rbp), %rcx
14009bb66:     	movl	$0x108, %r8d            # imm = 0x108
14009bb6c:     	movq	%rbx, %rdx
14009bb6f:     	callq	0x14024ae60 <.text+0x249e60>
14009bb74:     	leaq	-0x60(%rbp), %rdx
14009bb78:     	movq	%rsi, %rcx
14009bb7b:     	callq	0x1400116e0 <.text+0x106e0>
14009bb80:     	movb	$0x1, %al
14009bb82:     	jmp	0x14009bb86 <.text+0x9ab86>
14009bb84:     	xorl	%eax, %eax
14009bb86:     	movaps	0x270(%rbp), %xmm6
14009bb8d:     	movaps	0x280(%rbp), %xmm7
14009bb94:     	addq	$0x318, %rsp            # imm = 0x318
14009bb9b:     	popq	%rbx
14009bb9c:     	popq	%rdi
14009bb9d:     	popq	%rsi
14009bb9e:     	popq	%r12
14009bba0:     	popq	%r13
14009bba2:     	popq	%r14
14009bba4:     	popq	%r15
14009bba6:     	popq	%rbp
14009bba7:     	retq
14009bba8:     	leaq	0x1c7fc9(%rip), %r9     # 0x140263b78
14009bbaf:     	movl	$0x10, %r8d
14009bbb5:     	xorl	%ecx, %ecx
14009bbb7:     	movq	%rdi, %rdx
14009bbba:     	callq	0x14024b8b0 <.text+0x24a8b0>
14009bbbf:     	ud2

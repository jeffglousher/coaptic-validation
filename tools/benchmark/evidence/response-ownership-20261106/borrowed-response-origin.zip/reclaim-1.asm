
D:\CoapticCurrent\borrowed-response-origin-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009acb0:     	pushq	%rbp
14009acb1:     	pushq	%r15
14009acb3:     	pushq	%r14
14009acb5:     	pushq	%r13
14009acb7:     	pushq	%r12
14009acb9:     	pushq	%rsi
14009acba:     	pushq	%rdi
14009acbb:     	pushq	%rbx
14009acbc:     	subq	$0x318, %rsp            # imm = 0x318
14009acc3:     	leaq	0x80(%rsp), %rbp
14009accb:     	movaps	%xmm7, 0x280(%rbp)
14009acd2:     	movaps	%xmm6, 0x270(%rbp)
14009acd9:     	leaq	0x30(%rcx), %rdx
14009acdd:     	xorl	%r8d, %r8d
14009ace0:     	xorl	%r11d, %r11d
14009ace3:     	leaq	(%r11,%r11,4), %r10
14009ace7:     	shlq	$0x6, %r10
14009aceb:     	addq	%rdx, %r10
14009acee:     	movq	%r11, %r9
14009acf1:     	jmp	0x14009ad14 <.text+0x99d14>
14009acf3:     	nopw	%cs:(%rax,%rax)
14009ad00:     	incq	%r9
14009ad03:     	addq	$0x140, %r10            # imm = 0x140
14009ad0a:     	cmpq	$0x4, %r9
14009ad0e:     	je	0x14009ad9e <.text+0x99d9e>
14009ad14:     	cmpb	$0x1, 0x510(%rcx,%r9)
14009ad1d:     	jne	0x14009ad00 <.text+0x99d00>
14009ad1f:     	movq	-0x30(%r10), %rsi
14009ad23:     	cmpq	$0x2, %rsi
14009ad27:     	je	0x14009ad00 <.text+0x99d00>
14009ad29:     	movq	(%r10), %r11
14009ad2c:     	cmpl	$0x1, %esi
14009ad2f:     	setne	%bl
14009ad32:     	testq	%r11, %r11
14009ad35:     	sete	%sil
14009ad39:     	orb	%bl, %sil
14009ad3c:     	cmpb	$0x1, %sil
14009ad40:     	je	0x14009ad00 <.text+0x99d00>
14009ad42:     	movq	0x268(%rbp), %rsi
14009ad49:     	cmpq	%rsi, %r11
14009ad4c:     	setae	%bl
14009ad4f:     	testb	%bl, %r8b
14009ad52:     	jne	0x14009ad84 <.text+0x99d84>
14009ad54:     	movq	-0x28(%r10), %rax
14009ad58:     	movd	-0x4(%r10), %xmm6
14009ad5e:     	movzbl	-0x5(%r10), %edi
14009ad63:     	movzbl	-0x6(%r10), %r15d
14009ad68:     	movzwl	-0x8(%r10), %r12d
14009ad6d:     	movl	-0xc(%r10), %r13d
14009ad71:     	movl	-0x10(%r10), %r14d
14009ad75:     	movups	-0x20(%r10), %xmm0
14009ad7a:     	movaps	%xmm0, 0x240(%rbp)
14009ad81:     	movq	%r11, %rsi
14009ad84:     	movq	%rsi, 0x268(%rbp)
14009ad8b:     	leaq	0x1(%r9), %r11
14009ad8f:     	movb	$0x1, %r8b
14009ad92:     	cmpq	$0x3, %r9
14009ad96:     	jb	0x14009ace3 <.text+0x99ce3>
14009ad9c:     	jmp	0x14009ada8 <.text+0x99da8>
14009ad9e:     	testb	$0x1, %r8b
14009ada2:     	je	0x14009afe8 <.text+0x99fe8>
14009ada8:     	cmpq	$0x1, %rax
14009adac:     	ja	0x14009ae04 <.text+0x99e04>
14009adae:     	cmpb	$0x1, 0x1e80(%rcx,%rax)
14009adb6:     	jne	0x14009ae04 <.text+0x99e04>
14009adb8:     	cmpb	$0x0, 0x1e82(%rcx,%rax)
14009adc0:     	jne	0x14009ae04 <.text+0x99e04>
14009adc2:     	movb	$0x0, 0x1e80(%rcx,%rax)
14009adca:     	decq	0x1e78(%rcx)
14009add1:     	leaq	0x14f8(%rcx), %rdx
14009add8:     	movq	$0x0, 0x1df8(%rcx,%rax,8)
14009ade4:     	leaq	(%rax,%rax,8), %r8
14009ade8:     	leaq	(%r8,%r8,2), %r8
14009adec:     	addq	%rax, %r8
14009adef:     	movb	$0x2, 0x95a(%rdx,%r8)
14009adf8:     	leaq	(%rax,%rax,2), %rax
14009adfc:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009ae04:     	movaps	0x240(%rbp), %xmm0
14009ae0b:     	movaps	%xmm0, -0x60(%rbp)
14009ae0f:     	movl	%r14d, %esi
14009ae12:     	movl	%r14d, -0x50(%rbp)
14009ae16:     	movl	%r13d, %r14d
14009ae19:     	movl	%r13d, -0x4c(%rbp)
14009ae1d:     	movl	%r12d, %r13d
14009ae20:     	movw	%r12w, -0x48(%rbp)
14009ae25:     	movl	%r15d, %r12d
14009ae28:     	movb	%r15b, -0x46(%rbp)
14009ae2c:     	movl	%edi, %r15d
14009ae2f:     	movb	%dil, -0x45(%rbp)
14009ae33:     	movd	%xmm6, %edi
14009ae37:     	movd	%xmm6, -0x44(%rbp)
14009ae3c:     	leaq	-0x60(%rbp), %rdx
14009ae40:     	movq	%rcx, 0x260(%rbp)
14009ae47:     	callq	0x140210400 <.text+0x20f400>
14009ae4c:     	xorps	%xmm7, %xmm7
14009ae4f:     	movaps	%xmm7, 0x250(%rbp)
14009ae56:     	movb	$0x0, 0x222(%rbp)
14009ae5d:     	movw	%di, 0x220(%rbp)
14009ae64:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009ae6d:     	movq	$0x0, 0x223(%rbp)
14009ae78:     	movq	$0x8, 0x200(%rbp)
14009ae83:     	movq	$0x0, 0x208(%rbp)
14009ae8e:     	movq	$0x1, 0x210(%rbp)
14009ae99:     	movq	$0x0, 0x218(%rbp)
14009aea4:     	leaq	0x230(%rbp), %rcx
14009aeab:     	leaq	0x200(%rbp), %rdx
14009aeb2:     	leaq	0x250(%rbp), %r8
14009aeb9:     	movl	$0x10, %r9d
14009aebf:     	callq	0x14010d580 <.text+0x10c580>
14009aec4:     	cmpb	$0x0, 0x230(%rbp)
14009aecb:     	jne	0x14009afe4 <.text+0x99fe4>
14009aed1:     	movq	0x238(%rbp), %rdi
14009aed8:     	movaps	%xmm7, 0xe0(%rbp)
14009aedf:     	movaps	%xmm7, 0xf0(%rbp)
14009aee6:     	movaps	%xmm7, 0x100(%rbp)
14009aeed:     	movaps	%xmm7, 0x110(%rbp)
14009aef4:     	movaps	%xmm7, 0x120(%rbp)
14009aefb:     	movaps	%xmm7, 0x130(%rbp)
14009af02:     	movaps	%xmm7, 0x140(%rbp)
14009af09:     	movaps	%xmm7, 0x150(%rbp)
14009af10:     	movaps	%xmm7, 0x160(%rbp)
14009af17:     	movaps	%xmm7, 0x170(%rbp)
14009af1e:     	movaps	%xmm7, 0x180(%rbp)
14009af25:     	movaps	%xmm7, 0x190(%rbp)
14009af2c:     	movaps	%xmm7, 0x1a0(%rbp)
14009af33:     	movaps	%xmm7, 0x1b0(%rbp)
14009af3a:     	movaps	%xmm7, 0x1c0(%rbp)
14009af41:     	movaps	%xmm7, 0x1d0(%rbp)
14009af48:     	movaps	0x240(%rbp), %xmm0
14009af4f:     	movups	%xmm0, 0x1f0(%rbp)
14009af56:     	cmpq	$0x11, %rdi
14009af5a:     	jae	0x14009b00c <.text+0x9a00c>
14009af60:     	leaq	0xe0(%rbp), %rbx
14009af67:     	leaq	0x250(%rbp), %rdx
14009af6e:     	movq	%rbx, %rcx
14009af71:     	movq	%rdi, %r8
14009af74:     	callq	0x14024ae60 <.text+0x249e60>
14009af79:     	movw	%di, 0x1e0(%rbp)
14009af80:     	movq	$0x0, -0x60(%rbp)
14009af88:     	movups	0x1e8(%rbp), %xmm0
14009af8f:     	movups	%xmm0, -0x58(%rbp)
14009af93:     	movq	0x1f8(%rbp), %rax
14009af9a:     	movq	%rax, -0x48(%rbp)
14009af9e:     	movl	%esi, -0x40(%rbp)
14009afa1:     	movl	%r14d, -0x3c(%rbp)
14009afa5:     	movw	%r13w, -0x38(%rbp)
14009afaa:     	movb	%r12b, -0x36(%rbp)
14009afae:     	movb	%r15b, -0x35(%rbp)
14009afb2:     	movd	%xmm6, -0x34(%rbp)
14009afb7:     	movq	0x268(%rbp), %rax
14009afbe:     	movq	%rax, -0x30(%rbp)
14009afc2:     	leaq	-0x28(%rbp), %rcx
14009afc6:     	movl	$0x108, %r8d            # imm = 0x108
14009afcc:     	movq	%rbx, %rdx
14009afcf:     	callq	0x14024ae60 <.text+0x249e60>
14009afd4:     	leaq	-0x60(%rbp), %rdx
14009afd8:     	movq	0x260(%rbp), %rcx
14009afdf:     	callq	0x140210170 <.text+0x20f170>
14009afe4:     	movb	$0x1, %al
14009afe6:     	jmp	0x14009afea <.text+0x99fea>
14009afe8:     	xorl	%eax, %eax
14009afea:     	movaps	0x270(%rbp), %xmm6
14009aff1:     	movaps	0x280(%rbp), %xmm7
14009aff8:     	addq	$0x318, %rsp            # imm = 0x318
14009afff:     	popq	%rbx
14009b000:     	popq	%rdi
14009b001:     	popq	%rsi
14009b002:     	popq	%r12
14009b004:     	popq	%r13
14009b006:     	popq	%r14
14009b008:     	popq	%r15
14009b00a:     	popq	%rbp
14009b00b:     	retq
14009b00c:     	leaq	0x1c8b65(%rip), %r9     # 0x140263b78
14009b013:     	movl	$0x10, %r8d
14009b019:     	xorl	%ecx, %ecx
14009b01b:     	movq	%rdi, %rdx
14009b01e:     	callq	0x14024b8b0 <.text+0x24a8b0>
14009b023:     	ud2


D:\CoapticCurrent\borrowed-response-origin-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009b3b0:     	pushq	%rbp
14009b3b1:     	pushq	%r15
14009b3b3:     	pushq	%r14
14009b3b5:     	pushq	%r13
14009b3b7:     	pushq	%r12
14009b3b9:     	pushq	%rsi
14009b3ba:     	pushq	%rdi
14009b3bb:     	pushq	%rbx
14009b3bc:     	subq	$0x308, %rsp            # imm = 0x308
14009b3c3:     	leaq	0x80(%rsp), %rbp
14009b3cb:     	movaps	%xmm7, 0x270(%rbp)
14009b3d2:     	movaps	%xmm6, 0x260(%rbp)
14009b3d9:     	leaq	0x5000(%rcx), %rax
14009b3e0:     	leaq	0x30(%rcx), %r8
14009b3e4:     	xorl	%r9d, %r9d
14009b3e7:     	xorl	%esi, %esi
14009b3e9:     	leaq	(%rsi,%rsi,4), %r11
14009b3ed:     	shlq	$0x6, %r11
14009b3f1:     	addq	%r8, %r11
14009b3f4:     	movq	%rsi, %r10
14009b3f7:     	jmp	0x14009b414 <.text+0x9a414>
14009b3f9:     	nopl	(%rax)
14009b400:     	incq	%r10
14009b403:     	addq	$0x140, %r11            # imm = 0x140
14009b40a:     	cmpq	$0x40, %r10
14009b40e:     	je	0x14009b4ae <.text+0x9a4ae>
14009b414:     	cmpb	$0x1, 0x5000(%rcx,%r10)
14009b41d:     	jne	0x14009b400 <.text+0x9a400>
14009b41f:     	movq	-0x30(%r11), %rdi
14009b423:     	cmpq	$0x2, %rdi
14009b427:     	je	0x14009b400 <.text+0x9a400>
14009b429:     	movq	(%r11), %rsi
14009b42c:     	cmpl	$0x1, %edi
14009b42f:     	setne	%bl
14009b432:     	testq	%rsi, %rsi
14009b435:     	sete	%dil
14009b439:     	orb	%bl, %dil
14009b43c:     	cmpb	$0x1, %dil
14009b440:     	je	0x14009b400 <.text+0x9a400>
14009b442:     	movq	0x250(%rbp), %rdi
14009b449:     	cmpq	%rdi, %rsi
14009b44c:     	setae	%bl
14009b44f:     	testb	%bl, %r9b
14009b452:     	jne	0x14009b494 <.text+0x9a494>
14009b454:     	movd	-0x4(%r11), %xmm6
14009b45a:     	movzbl	-0x5(%r11), %edx
14009b45f:     	movb	%dl, 0x25f(%rbp)
14009b465:     	movzbl	-0x6(%r11), %r15d
14009b46a:     	movzwl	-0x8(%r11), %r12d
14009b46f:     	movl	-0xc(%r11), %r13d
14009b473:     	movl	-0x10(%r11), %r14d
14009b477:     	movq	-0x18(%r11), %rdx
14009b47b:     	movq	%rdx, 0x248(%rbp)
14009b482:     	movq	-0x28(%r11), %rdx
14009b486:     	movq	-0x20(%r11), %r9
14009b48a:     	movq	%r9, 0x240(%rbp)
14009b491:     	movq	%rsi, %rdi
14009b494:     	movq	%rdi, 0x250(%rbp)
14009b49b:     	leaq	0x1(%r10), %rsi
14009b49f:     	movb	$0x1, %r9b
14009b4a2:     	cmpq	$0x3f, %r10
14009b4a6:     	jb	0x14009b3e9 <.text+0x9a3e9>
14009b4ac:     	jmp	0x14009b4b8 <.text+0x9a4b8>
14009b4ae:     	testb	$0x1, %r9b
14009b4b2:     	je	0x14009b730 <.text+0x9a730>
14009b4b8:     	cmpq	$0x1f, %rdx
14009b4bc:     	ja	0x14009b50f <.text+0x9a50f>
14009b4be:     	leaq	0x37740(%rcx), %r8
14009b4c5:     	cmpb	$0x1, (%r8,%rdx)
14009b4ca:     	jne	0x14009b50f <.text+0x9a50f>
14009b4cc:     	cmpb	$0x0, 0x37760(%rcx,%rdx)
14009b4d4:     	jne	0x14009b50f <.text+0x9a50f>
14009b4d6:     	movb	$0x0, 0x37740(%rcx,%rdx)
14009b4de:     	decq	0x37788(%rcx)
14009b4e5:     	movq	$0x0, 0x43610(%rcx,%rdx,8)
14009b4f1:     	leaq	(%rdx,%rdx,8), %r9
14009b4f5:     	leaq	(%r9,%r9,2), %r9
14009b4f9:     	addq	%rdx, %r9
14009b4fc:     	movb	$0x2, 0x36a(%r8,%r9)
14009b505:     	leaq	(%rdx,%rdx,2), %rdx
14009b509:     	movb	$0x2, 0x5d(%r8,%rdx,8)
14009b50f:     	movd	%xmm6, %edx
14009b513:     	movl	$0x2c, %r8d
14009b519:     	movq	0x240(%rbp), %r11
14009b520:     	movq	0x248(%rbp), %rsi
14009b527:     	jmp	0x14009b543 <.text+0x9a543>
14009b529:     	nopl	(%rax)
14009b530:     	incq	%rax
14009b533:     	addq	$0x140, %r8             # imm = 0x140
14009b53a:     	cmpq	$0x502c, %r8            # imm = 0x502C
14009b541:     	je	0x14009b59c <.text+0x9a59c>
14009b543:     	cmpb	$0x1, (%rax)
14009b546:     	jne	0x14009b530 <.text+0x9a530>
14009b548:     	cmpl	$0x2, -0x2c(%rcx,%r8)
14009b54e:     	je	0x14009b530 <.text+0x9a530>
14009b550:     	cmpw	%dx, (%rcx,%r8)
14009b555:     	jne	0x14009b530 <.text+0x9a530>
14009b557:     	cmpl	%r14d, -0xc(%rcx,%r8)
14009b55c:     	jne	0x14009b530 <.text+0x9a530>
14009b55e:     	cmpl	%r13d, -0x8(%rcx,%r8)
14009b563:     	jne	0x14009b530 <.text+0x9a530>
14009b565:     	cmpw	%r12w, -0x4(%rcx,%r8)
14009b56b:     	jne	0x14009b530 <.text+0x9a530>
14009b56d:     	cmpb	%r15b, -0x2(%rcx,%r8)
14009b572:     	jne	0x14009b530 <.text+0x9a530>
14009b574:     	movq	-0x1c(%rcx,%r8), %r9
14009b579:     	xorq	%r11, %r9
14009b57c:     	movq	-0x14(%rcx,%r8), %r10
14009b581:     	xorq	%rsi, %r10
14009b584:     	orq	%r9, %r10
14009b587:     	jne	0x14009b530 <.text+0x9a530>
14009b589:     	movb	$0x0, (%rax)
14009b58c:     	decq	0x5048(%rcx)
14009b593:     	movq	$0x2, -0x2c(%rcx,%r8)
14009b59c:     	movq	%rcx, %rsi
14009b59f:     	xorps	%xmm7, %xmm7
14009b5a2:     	movaps	%xmm7, 0x230(%rbp)
14009b5a9:     	movb	$0x0, 0x212(%rbp)
14009b5b0:     	movw	%dx, 0x210(%rbp)
14009b5b7:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
14009b5c0:     	movq	$0x0, 0x213(%rbp)
14009b5cb:     	movq	$0x8, 0x1f0(%rbp)
14009b5d6:     	movq	$0x0, 0x1f8(%rbp)
14009b5e1:     	movq	$0x1, 0x200(%rbp)
14009b5ec:     	movq	$0x0, 0x208(%rbp)
14009b5f7:     	leaq	0x220(%rbp), %rcx
14009b5fe:     	leaq	0x1f0(%rbp), %rdx
14009b605:     	leaq	0x230(%rbp), %r8
14009b60c:     	movl	$0x10, %r9d
14009b612:     	callq	0x14010d580 <.text+0x10c580>
14009b617:     	cmpb	$0x0, 0x220(%rbp)
14009b61e:     	jne	0x14009b72c <.text+0x9a72c>
14009b624:     	movq	0x228(%rbp), %rdi
14009b62b:     	movaps	%xmm7, 0xe0(%rbp)
14009b632:     	movaps	%xmm7, 0xf0(%rbp)
14009b639:     	movaps	%xmm7, 0x100(%rbp)
14009b640:     	movaps	%xmm7, 0x110(%rbp)
14009b647:     	movaps	%xmm7, 0x120(%rbp)
14009b64e:     	movaps	%xmm7, 0x130(%rbp)
14009b655:     	movaps	%xmm7, 0x140(%rbp)
14009b65c:     	movaps	%xmm7, 0x150(%rbp)
14009b663:     	movaps	%xmm7, 0x160(%rbp)
14009b66a:     	movaps	%xmm7, 0x170(%rbp)
14009b671:     	movaps	%xmm7, 0x180(%rbp)
14009b678:     	movaps	%xmm7, 0x190(%rbp)
14009b67f:     	movaps	%xmm7, 0x1a0(%rbp)
14009b686:     	movaps	%xmm7, 0x1b0(%rbp)
14009b68d:     	movaps	%xmm7, 0x1c0(%rbp)
14009b694:     	movaps	%xmm7, 0x1d0(%rbp)
14009b69b:     	cmpq	$0x11, %rdi
14009b69f:     	jae	0x14009b754 <.text+0x9a754>
14009b6a5:     	leaq	0xe0(%rbp), %rbx
14009b6ac:     	leaq	0x230(%rbp), %rdx
14009b6b3:     	movq	%rbx, %rcx
14009b6b6:     	movq	%rdi, %r8
14009b6b9:     	callq	0x14024ae60 <.text+0x249e60>
14009b6be:     	movw	%di, 0x1e0(%rbp)
14009b6c5:     	movq	$0x0, -0x60(%rbp)
14009b6cd:     	movq	0x248(%rbp), %rax
14009b6d4:     	movq	%rax, -0x48(%rbp)
14009b6d8:     	movq	0x240(%rbp), %rax
14009b6df:     	movq	%rax, -0x50(%rbp)
14009b6e3:     	movl	%r14d, -0x40(%rbp)
14009b6e7:     	movl	%r13d, -0x3c(%rbp)
14009b6eb:     	movw	%r12w, -0x38(%rbp)
14009b6f0:     	movb	%r15b, -0x36(%rbp)
14009b6f4:     	movzbl	0x25f(%rbp), %eax
14009b6fb:     	movb	%al, -0x35(%rbp)
14009b6fe:     	movd	%xmm6, -0x34(%rbp)
14009b703:     	movq	0x250(%rbp), %rax
14009b70a:     	movq	%rax, -0x30(%rbp)
14009b70e:     	leaq	-0x28(%rbp), %rcx
14009b712:     	movl	$0x108, %r8d            # imm = 0x108
14009b718:     	movq	%rbx, %rdx
14009b71b:     	callq	0x14024ae60 <.text+0x249e60>
14009b720:     	leaq	-0x60(%rbp), %rdx
14009b724:     	movq	%rsi, %rcx
14009b727:     	callq	0x14020ffd0 <.text+0x20efd0>
14009b72c:     	movb	$0x1, %al
14009b72e:     	jmp	0x14009b732 <.text+0x9a732>
14009b730:     	xorl	%eax, %eax
14009b732:     	movaps	0x260(%rbp), %xmm6
14009b739:     	movaps	0x270(%rbp), %xmm7
14009b740:     	addq	$0x308, %rsp            # imm = 0x308
14009b747:     	popq	%rbx
14009b748:     	popq	%rdi
14009b749:     	popq	%rsi
14009b74a:     	popq	%r12
14009b74c:     	popq	%r13
14009b74e:     	popq	%r14
14009b750:     	popq	%r15
14009b752:     	popq	%rbp
14009b753:     	retq
14009b754:     	leaq	0x1c841d(%rip), %r9     # 0x140263b78
14009b75b:     	movl	$0x10, %r8d
14009b761:     	xorl	%ecx, %ecx
14009b763:     	movq	%rdi, %rdx
14009b766:     	callq	0x14024b8b0 <.text+0x24a8b0>
14009b76b:     	ud2


D:\CoapticCurrent\unified-reply-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400686c0:     	pushq	%rbp
1400686c1:     	pushq	%r15
1400686c3:     	pushq	%r14
1400686c5:     	pushq	%r13
1400686c7:     	pushq	%r12
1400686c9:     	pushq	%rsi
1400686ca:     	pushq	%rdi
1400686cb:     	pushq	%rbx
1400686cc:     	subq	$0x508, %rsp            # imm = 0x508
1400686d3:     	leaq	0x80(%rsp), %rbp
1400686db:     	movq	%r9, %r15
1400686de:     	movq	%r8, %rbx
1400686e1:     	movq	%rdx, %r14
1400686e4:     	movq	%rcx, %rsi
1400686e7:     	movq	0x500(%rbp), %r12
1400686ee:     	movq	%rbp, %rcx
1400686f1:     	movl	$0x400, %r8d            # imm = 0x400
1400686f7:     	xorl	%edx, %edx
1400686f9:     	callq	0x1402b3672 <.text+0x2b2672>
1400686fe:     	movq	0x8(%r12), %rdi
140068703:     	movl	$0x3, %eax
140068708:     	cmpq	$0x3, %rdi
14006870c:     	ja	0x140068923 <.text+0x67923>
140068712:     	movq	%r15, 0x478(%rbp)
140068719:     	movq	0x30(%r14), %r13
14006871d:     	cmpb	$0x1, 0xad0(%r13,%rdi)
140068726:     	jne	0x140068923 <.text+0x67923>
14006872c:     	movq	0x10ad8(%r13,%rdi,8), %rdx
140068734:     	cmpq	$0x4001, %rdx           # imm = 0x4001
14006873b:     	jae	0x140068972 <.text+0x67972>
140068741:     	movq	0x10(%r12), %rcx
140068746:     	movq	0x18(%r12), %r15
14006874b:     	movq	%r15, %r8
14006874e:     	movl	$0xb, %eax
140068753:     	addq	%rcx, %r8
140068756:     	jb	0x140068923 <.text+0x67923>
14006875c:     	cmpq	$0x400, %r15            # imm = 0x400
140068763:     	ja	0x140068923 <.text+0x67923>
140068769:     	cmpq	%rdx, %r8
14006876c:     	ja	0x140068923 <.text+0x67923>
140068772:     	movq	%rdi, %rax
140068775:     	shlq	$0xe, %rax
140068779:     	leaq	(%rax,%r13), %rdx
14006877d:     	addq	$0xad8, %rdx            # imm = 0xAD8
140068784:     	addq	%rcx, %rdx
140068787:     	movq	%rbp, %rcx
14006878a:     	movq	%r15, %r8
14006878d:     	callq	0x1402b3660 <.text+0x2b2660>
140068792:     	cmpb	$0x0, 0x508(%rbp)
140068799:     	je	0x1400687ae <.text+0x677ae>
14006879b:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
1400687a2:     	cmpq	$0x2, (%r13,%rax)
1400687a8:     	jne	0x14006893e <.text+0x6793e>
1400687ae:     	xorl	%edi, %edi
1400687b0:     	movq	%r14, %rcx
1400687b3:     	callq	0x1400ca830 <.text+0xc9830>
1400687b8:     	testb	$0x1, %al
1400687ba:     	je	0x140068964 <.text+0x67964>
1400687c0:     	movq	%rdx, %r13
1400687c3:     	movq	0x518(%rbp), %rdx
1400687ca:     	movq	0x510(%rbp), %r8
1400687d1:     	movzwl	0x4f8(%rbp), %ecx
1400687d8:     	movzbl	0x4f0(%rbp), %eax
1400687df:     	movq	(%r12), %r9
1400687e3:     	movq	%rdi, 0x448(%rbp)
1400687ea:     	movq	0x480(%rbp), %r10
1400687f1:     	movq	%r10, 0x450(%rbp)
1400687f8:     	movq	%r9, 0x458(%rbp)
1400687ff:     	movzbl	0x508(%rbp), %r9d
140068807:     	movb	%r9b, 0x460(%rbp)
14006880e:     	movups	0x60(%rbx), %xmm0
140068812:     	movups	0x6c(%rbx), %xmm1
140068816:     	movups	%xmm1, 0x40c(%rbp)
14006881d:     	movaps	%xmm0, 0x400(%rbp)
140068824:     	leaq	0x8e(%rbx), %r9
14006882b:     	movq	0x7e(%rbx), %r10
14006882f:     	movq	0x85(%rbx), %r11
140068836:     	movq	%r11, 0x46f(%rbp)
14006883d:     	movq	%r10, 0x468(%rbp)
140068844:     	movq	0x10(%r14), %r14
140068848:     	leaq	0x468(%rbp), %r10
14006884f:     	movq	%r10, 0x70(%rsp)
140068854:     	movq	%rdx, 0x68(%rsp)
140068859:     	movq	%r8, 0x60(%rsp)
14006885e:     	movq	%rbx, 0x58(%rsp)
140068863:     	leaq	0x448(%rbp), %rdx
14006886a:     	movq	%rdx, 0x50(%rsp)
14006886f:     	movq	%r15, 0x48(%rsp)
140068874:     	movq	%rbp, %rdx
140068877:     	movq	%rdx, 0x40(%rsp)
14006887c:     	movq	0x478(%rbp), %rdx
140068883:     	movq	%rdx, 0x38(%rsp)
140068888:     	movq	%r9, 0x30(%rsp)
14006888d:     	movw	%cx, 0x28(%rsp)
140068892:     	movb	%al, 0x20(%rsp)
140068896:     	leaq	0x428(%rbp), %rcx
14006889d:     	leaq	0x400(%rbp), %r8
1400688a4:     	movq	%r14, %rdx
1400688a7:     	movq	%r13, %r9
1400688aa:     	callq	0x1400a0540 <.text+0x9f540>
1400688af:     	cmpb	$-0x1, 0x428(%rbp)
1400688b6:     	je	0x140068969 <.text+0x67969>
1400688bc:     	cmpb	$0x1, (%r14,%r13)
1400688c1:     	jne	0x14006890c <.text+0x6790c>
1400688c3:     	cmpb	$0x0, 0x20(%r14,%r13)
1400688c9:     	jne	0x14006890c <.text+0x6790c>
1400688cb:     	movb	$0x0, (%r14,%r13)
1400688d0:     	decq	0x48(%r14)
1400688d4:     	movq	$0x0, 0xbed0(%r14,%r13,8)
1400688e0:     	leaq	(,%r13,8), %rax
1400688e8:     	addq	%r13, %rax
1400688eb:     	leaq	(%rax,%rax,2), %rax
1400688ef:     	addq	%r13, %rax
1400688f2:     	movb	$0x2, 0x36a(%r14,%rax)
1400688fb:     	leaq	(,%r13,2), %rax
140068903:     	addq	%r13, %rax
140068906:     	movb	$0x2, 0x5d(%r14,%rax,8)
14006890c:     	movups	0x428(%rbp), %xmm0
140068913:     	movups	0x438(%rbp), %xmm1
14006891a:     	movups	%xmm1, 0x10(%rsi)
14006891e:     	movups	%xmm0, (%rsi)
140068921:     	jmp	0x14006892a <.text+0x6792a>
140068923:     	movb	$0xa, (%rsi)
140068926:     	movq	%rax, 0x8(%rsi)
14006892a:     	addq	$0x508, %rsp            # imm = 0x508
140068931:     	popq	%rbx
140068932:     	popq	%rdi
140068933:     	popq	%rsi
140068934:     	popq	%r12
140068936:     	popq	%r13
140068938:     	popq	%r14
14006893a:     	popq	%r15
14006893c:     	popq	%rbp
14006893d:     	retq
14006893e:     	addq	%rax, %r13
140068941:     	movq	0x98(%r13), %rax
140068948:     	movq	%rax, 0x480(%rbp)
14006894f:     	movl	$0x1, %edi
140068954:     	movq	%r14, %rcx
140068957:     	callq	0x1400ca830 <.text+0xc9830>
14006895c:     	testb	$0x1, %al
14006895e:     	jne	0x1400687c0 <.text+0x677c0>
140068964:     	movb	$0x9, (%rsi)
140068967:     	jmp	0x14006892a <.text+0x6792a>
140068969:     	movq	%r13, 0x8(%rsi)
14006896d:     	movb	$-0x1, (%rsi)
140068970:     	jmp	0x14006892a <.text+0x6792a>
140068972:     	leaq	0x26f38f(%rip), %r9     # 0x1402d7d08
140068979:     	movl	$0x4000, %r8d           # imm = 0x4000
14006897f:     	xorl	%ecx, %ecx
140068981:     	callq	0x1402b40b0 <.text+0x2b30b0>
140068986:     	ud2


D:\CoapticCurrent\unified-reply-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068ee0:     	pushq	%rbp
140068ee1:     	pushq	%r15
140068ee3:     	pushq	%r14
140068ee5:     	pushq	%r13
140068ee7:     	pushq	%r12
140068ee9:     	pushq	%rsi
140068eea:     	pushq	%rdi
140068eeb:     	pushq	%rbx
140068eec:     	subq	$0x508, %rsp            # imm = 0x508
140068ef3:     	leaq	0x80(%rsp), %rbp
140068efb:     	movq	%r9, %rbx
140068efe:     	movq	%r8, %r14
140068f01:     	movq	%rdx, %rdi
140068f04:     	movq	%rcx, %rsi
140068f07:     	movq	0x500(%rbp), %r12
140068f0e:     	movq	%rbp, %rcx
140068f11:     	movl	$0x400, %r8d            # imm = 0x400
140068f17:     	xorl	%edx, %edx
140068f19:     	callq	0x1402b3672 <.text+0x2b2672>
140068f1e:     	movq	0x8(%r12), %r13
140068f23:     	movl	$0x3, %eax
140068f28:     	cmpq	$0x3, %r13
140068f2c:     	ja	0x140069155 <.text+0x68155>
140068f32:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
140068f3b:     	jne	0x140069155 <.text+0x68155>
140068f41:     	movq	0x2b750(%rdi,%r13,8), %rdx
140068f49:     	cmpq	$0x4001, %rdx           # imm = 0x4001
140068f50:     	jae	0x1400691b1 <.text+0x681b1>
140068f56:     	movq	0x10(%r12), %rcx
140068f5b:     	movq	0x18(%r12), %r15
140068f60:     	movq	%r15, %r8
140068f63:     	movl	$0xb, %eax
140068f68:     	addq	%rcx, %r8
140068f6b:     	jb	0x140069155 <.text+0x68155>
140068f71:     	cmpq	$0x400, %r15            # imm = 0x400
140068f78:     	ja	0x140069155 <.text+0x68155>
140068f7e:     	cmpq	%rdx, %r8
140068f81:     	ja	0x140069155 <.text+0x68155>
140068f87:     	movq	%r13, %rax
140068f8a:     	shlq	$0xe, %rax
140068f8e:     	leaq	(%rdi,%rax), %rdx
140068f92:     	addq	$0x1b750, %rdx          # imm = 0x1B750
140068f99:     	addq	%rcx, %rdx
140068f9c:     	movq	%rbp, %rcx
140068f9f:     	movq	%r15, %r8
140068fa2:     	callq	0x1402b3660 <.text+0x2b2660>
140068fa7:     	cmpb	$0x0, 0x508(%rbp)
140068fae:     	je	0x140068fc6 <.text+0x67fc6>
140068fb0:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
140068fb7:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
140068fc0:     	jne	0x140069170 <.text+0x68170>
140068fc6:     	movq	$0x0, 0x480(%rbp)
140068fd1:     	movq	%rdi, %rcx
140068fd4:     	callq	0x1400cb430 <.text+0xca430>
140068fd9:     	testb	$0x1, %al
140068fdb:     	je	0x1400691a3 <.text+0x681a3>
140068fe1:     	movq	%rdx, %r13
140068fe4:     	movq	0x518(%rbp), %rdx
140068feb:     	movq	0x510(%rbp), %r8
140068ff2:     	movzwl	0x4f8(%rbp), %ecx
140068ff9:     	movzbl	0x4f0(%rbp), %eax
140069000:     	movq	(%r12), %r9
140069004:     	movq	0x480(%rbp), %r10
14006900b:     	movq	%r10, 0x448(%rbp)
140069012:     	movq	0x478(%rbp), %r10
140069019:     	movq	%r10, 0x450(%rbp)
140069020:     	movq	%r9, 0x458(%rbp)
140069027:     	movzbl	0x508(%rbp), %r9d
14006902f:     	movb	%r9b, 0x460(%rbp)
140069036:     	movups	0x60(%r14), %xmm0
14006903b:     	movups	0x6c(%r14), %xmm1
140069040:     	movups	%xmm1, 0x40c(%rbp)
140069047:     	movaps	%xmm0, 0x400(%rbp)
14006904e:     	leaq	0x8e(%r14), %r9
140069055:     	movq	0x7e(%r14), %r10
140069059:     	movq	0x85(%r14), %r11
140069060:     	movq	%r11, 0x46f(%rbp)
140069067:     	movq	%r10, 0x468(%rbp)
14006906e:     	leaq	0x468(%rbp), %r10
140069075:     	movq	%r10, 0x70(%rsp)
14006907a:     	movq	%rdx, 0x68(%rsp)
14006907f:     	movq	%r8, 0x60(%rsp)
140069084:     	movq	%r14, 0x58(%rsp)
140069089:     	leaq	0x448(%rbp), %rdx
140069090:     	movq	%rdx, 0x50(%rsp)
140069095:     	movq	%r15, 0x48(%rsp)
14006909a:     	movq	%rbp, %rdx
14006909d:     	movq	%rdx, 0x40(%rsp)
1400690a2:     	movq	%rbx, 0x38(%rsp)
1400690a7:     	movq	%r9, 0x30(%rsp)
1400690ac:     	movw	%cx, 0x28(%rsp)
1400690b1:     	movb	%al, 0x20(%rsp)
1400690b5:     	leaq	0x428(%rbp), %rcx
1400690bc:     	leaq	0x400(%rbp), %r8
1400690c3:     	movq	%rdi, %rdx
1400690c6:     	movq	%r13, %r9
1400690c9:     	callq	0x1400a7c00 <.text+0xa6c00>
1400690ce:     	cmpb	$-0x1, 0x428(%rbp)
1400690d5:     	je	0x1400691a8 <.text+0x681a8>
1400690db:     	cmpb	$0x1, 0x37740(%rdi,%r13)
1400690e4:     	jne	0x14006913e <.text+0x6813e>
1400690e6:     	cmpb	$0x0, 0x37760(%rdi,%r13)
1400690ef:     	jne	0x14006913e <.text+0x6813e>
1400690f1:     	movb	$0x0, 0x37740(%rdi,%r13)
1400690fa:     	decq	0x37788(%rdi)
140069101:     	leaq	0x37740(%rdi), %rax
140069108:     	movq	$0x0, 0x43610(%rdi,%r13,8)
140069114:     	leaq	(,%r13,8), %rcx
14006911c:     	addq	%r13, %rcx
14006911f:     	leaq	(%rcx,%rcx,2), %rcx
140069123:     	addq	%r13, %rcx
140069126:     	movb	$0x2, 0x36a(%rax,%rcx)
14006912e:     	leaq	(,%r13,2), %rcx
140069136:     	addq	%r13, %rcx
140069139:     	movb	$0x2, 0x5d(%rax,%rcx,8)
14006913e:     	movups	0x428(%rbp), %xmm0
140069145:     	movups	0x438(%rbp), %xmm1
14006914c:     	movups	%xmm1, 0x10(%rsi)
140069150:     	movups	%xmm0, (%rsi)
140069153:     	jmp	0x14006915c <.text+0x6815c>
140069155:     	movb	$0xa, (%rsi)
140069158:     	movq	%rax, 0x8(%rsi)
14006915c:     	addq	$0x508, %rsp            # imm = 0x508
140069163:     	popq	%rbx
140069164:     	popq	%rdi
140069165:     	popq	%rsi
140069166:     	popq	%r12
140069168:     	popq	%r13
14006916a:     	popq	%r14
14006916c:     	popq	%r15
14006916e:     	popq	%rbp
14006916f:     	retq
140069170:     	addq	%rdi, %rax
140069173:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
140069179:     	movq	0x98(%rax), %rax
140069180:     	movq	%rax, 0x478(%rbp)
140069187:     	movl	$0x1, %eax
14006918c:     	movq	%rax, 0x480(%rbp)
140069193:     	movq	%rdi, %rcx
140069196:     	callq	0x1400cb430 <.text+0xca430>
14006919b:     	testb	$0x1, %al
14006919d:     	jne	0x140068fe1 <.text+0x67fe1>
1400691a3:     	movb	$0x9, (%rsi)
1400691a6:     	jmp	0x14006915c <.text+0x6815c>
1400691a8:     	movq	%r13, 0x8(%rsi)
1400691ac:     	movb	$-0x1, (%rsi)
1400691af:     	jmp	0x14006915c <.text+0x6815c>
1400691b1:     	leaq	0x26eb50(%rip), %r9     # 0x1402d7d08
1400691b8:     	movl	$0x4000, %r8d           # imm = 0x4000
1400691be:     	xorl	%ecx, %ecx
1400691c0:     	callq	0x1402b40b0 <.text+0x2b30b0>
1400691c5:     	ud2

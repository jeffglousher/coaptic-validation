
D:\CoapticCurrent\unified-reply-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400cef20:     	pushq	%rbp
1400cef21:     	pushq	%r15
1400cef23:     	pushq	%r14
1400cef25:     	pushq	%r13
1400cef27:     	pushq	%r12
1400cef29:     	pushq	%rsi
1400cef2a:     	pushq	%rdi
1400cef2b:     	pushq	%rbx
1400cef2c:     	subq	$0x308, %rsp            # imm = 0x308
1400cef33:     	leaq	0x80(%rsp), %rbp
1400cef3b:     	movaps	%xmm7, 0x270(%rbp)
1400cef42:     	movaps	%xmm6, 0x260(%rbp)
1400cef49:     	leaq	0x5000(%rcx), %rax
1400cef50:     	leaq	0x30(%rcx), %r8
1400cef54:     	xorl	%r9d, %r9d
1400cef57:     	xorl	%esi, %esi
1400cef59:     	leaq	(%rsi,%rsi,4), %r11
1400cef5d:     	shlq	$0x6, %r11
1400cef61:     	addq	%r8, %r11
1400cef64:     	movq	%rsi, %r10
1400cef67:     	jmp	0x1400cef84 <.text+0xcdf84>
1400cef69:     	nopl	(%rax)
1400cef70:     	incq	%r10
1400cef73:     	addq	$0x140, %r11            # imm = 0x140
1400cef7a:     	cmpq	$0x40, %r10
1400cef7e:     	je	0x1400cf01e <.text+0xce01e>
1400cef84:     	cmpb	$0x1, 0x5000(%rcx,%r10)
1400cef8d:     	jne	0x1400cef70 <.text+0xcdf70>
1400cef8f:     	movq	-0x30(%r11), %rdi
1400cef93:     	cmpq	$0x2, %rdi
1400cef97:     	je	0x1400cef70 <.text+0xcdf70>
1400cef99:     	movq	(%r11), %rsi
1400cef9c:     	cmpl	$0x1, %edi
1400cef9f:     	setne	%bl
1400cefa2:     	testq	%rsi, %rsi
1400cefa5:     	sete	%dil
1400cefa9:     	orb	%bl, %dil
1400cefac:     	cmpb	$0x1, %dil
1400cefb0:     	je	0x1400cef70 <.text+0xcdf70>
1400cefb2:     	movq	0x250(%rbp), %rdi
1400cefb9:     	cmpq	%rdi, %rsi
1400cefbc:     	setae	%bl
1400cefbf:     	testb	%bl, %r9b
1400cefc2:     	jne	0x1400cf004 <.text+0xce004>
1400cefc4:     	movd	-0x4(%r11), %xmm6
1400cefca:     	movzbl	-0x5(%r11), %edx
1400cefcf:     	movb	%dl, 0x25f(%rbp)
1400cefd5:     	movzbl	-0x6(%r11), %r15d
1400cefda:     	movzwl	-0x8(%r11), %r12d
1400cefdf:     	movl	-0xc(%r11), %r13d
1400cefe3:     	movl	-0x10(%r11), %r14d
1400cefe7:     	movq	-0x18(%r11), %rdx
1400cefeb:     	movq	%rdx, 0x248(%rbp)
1400ceff2:     	movq	-0x28(%r11), %rdx
1400ceff6:     	movq	-0x20(%r11), %r9
1400ceffa:     	movq	%r9, 0x240(%rbp)
1400cf001:     	movq	%rsi, %rdi
1400cf004:     	movq	%rdi, 0x250(%rbp)
1400cf00b:     	leaq	0x1(%r10), %rsi
1400cf00f:     	movb	$0x1, %r9b
1400cf012:     	cmpq	$0x3f, %r10
1400cf016:     	jb	0x1400cef59 <.text+0xcdf59>
1400cf01c:     	jmp	0x1400cf028 <.text+0xce028>
1400cf01e:     	testb	$0x1, %r9b
1400cf022:     	je	0x1400cf2a0 <.text+0xce2a0>
1400cf028:     	cmpq	$0x1f, %rdx
1400cf02c:     	ja	0x1400cf07f <.text+0xce07f>
1400cf02e:     	leaq	0x37740(%rcx), %r8
1400cf035:     	cmpb	$0x1, (%r8,%rdx)
1400cf03a:     	jne	0x1400cf07f <.text+0xce07f>
1400cf03c:     	cmpb	$0x0, 0x37760(%rcx,%rdx)
1400cf044:     	jne	0x1400cf07f <.text+0xce07f>
1400cf046:     	movb	$0x0, 0x37740(%rcx,%rdx)
1400cf04e:     	decq	0x37788(%rcx)
1400cf055:     	movq	$0x0, 0x43610(%rcx,%rdx,8)
1400cf061:     	leaq	(%rdx,%rdx,8), %r9
1400cf065:     	leaq	(%r9,%r9,2), %r9
1400cf069:     	addq	%rdx, %r9
1400cf06c:     	movb	$0x2, 0x36a(%r8,%r9)
1400cf075:     	leaq	(%rdx,%rdx,2), %rdx
1400cf079:     	movb	$0x2, 0x5d(%r8,%rdx,8)
1400cf07f:     	movd	%xmm6, %edx
1400cf083:     	movl	$0x2c, %r8d
1400cf089:     	movq	0x240(%rbp), %r11
1400cf090:     	movq	0x248(%rbp), %rsi
1400cf097:     	jmp	0x1400cf0b3 <.text+0xce0b3>
1400cf099:     	nopl	(%rax)
1400cf0a0:     	incq	%rax
1400cf0a3:     	addq	$0x140, %r8             # imm = 0x140
1400cf0aa:     	cmpq	$0x502c, %r8            # imm = 0x502C
1400cf0b1:     	je	0x1400cf10c <.text+0xce10c>
1400cf0b3:     	cmpb	$0x1, (%rax)
1400cf0b6:     	jne	0x1400cf0a0 <.text+0xce0a0>
1400cf0b8:     	cmpl	$0x2, -0x2c(%rcx,%r8)
1400cf0be:     	je	0x1400cf0a0 <.text+0xce0a0>
1400cf0c0:     	cmpw	%dx, (%rcx,%r8)
1400cf0c5:     	jne	0x1400cf0a0 <.text+0xce0a0>
1400cf0c7:     	cmpl	%r14d, -0xc(%rcx,%r8)
1400cf0cc:     	jne	0x1400cf0a0 <.text+0xce0a0>
1400cf0ce:     	cmpl	%r13d, -0x8(%rcx,%r8)
1400cf0d3:     	jne	0x1400cf0a0 <.text+0xce0a0>
1400cf0d5:     	cmpw	%r12w, -0x4(%rcx,%r8)
1400cf0db:     	jne	0x1400cf0a0 <.text+0xce0a0>
1400cf0dd:     	cmpb	%r15b, -0x2(%rcx,%r8)
1400cf0e2:     	jne	0x1400cf0a0 <.text+0xce0a0>
1400cf0e4:     	movq	-0x1c(%rcx,%r8), %r9
1400cf0e9:     	xorq	%r11, %r9
1400cf0ec:     	movq	-0x14(%rcx,%r8), %r10
1400cf0f1:     	xorq	%rsi, %r10
1400cf0f4:     	orq	%r9, %r10
1400cf0f7:     	jne	0x1400cf0a0 <.text+0xce0a0>
1400cf0f9:     	movb	$0x0, (%rax)
1400cf0fc:     	decq	0x5048(%rcx)
1400cf103:     	movq	$0x2, -0x2c(%rcx,%r8)
1400cf10c:     	movq	%rcx, %rsi
1400cf10f:     	xorps	%xmm7, %xmm7
1400cf112:     	movaps	%xmm7, 0x230(%rbp)
1400cf119:     	movb	$0x0, 0x212(%rbp)
1400cf120:     	movw	%dx, 0x210(%rbp)
1400cf127:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
1400cf130:     	movq	$0x0, 0x213(%rbp)
1400cf13b:     	movq	$0x8, 0x1f0(%rbp)
1400cf146:     	movq	$0x0, 0x1f8(%rbp)
1400cf151:     	movq	$0x1, 0x200(%rbp)
1400cf15c:     	movq	$0x0, 0x208(%rbp)
1400cf167:     	leaq	0x220(%rbp), %rcx
1400cf16e:     	leaq	0x1f0(%rbp), %rdx
1400cf175:     	leaq	0x230(%rbp), %r8
1400cf17c:     	movl	$0x10, %r9d
1400cf182:     	callq	0x14014ae60 <.text+0x149e60>
1400cf187:     	cmpb	$0x0, 0x220(%rbp)
1400cf18e:     	jne	0x1400cf29c <.text+0xce29c>
1400cf194:     	movq	0x228(%rbp), %rdi
1400cf19b:     	movaps	%xmm7, 0xe0(%rbp)
1400cf1a2:     	movaps	%xmm7, 0xf0(%rbp)
1400cf1a9:     	movaps	%xmm7, 0x100(%rbp)
1400cf1b0:     	movaps	%xmm7, 0x110(%rbp)
1400cf1b7:     	movaps	%xmm7, 0x120(%rbp)
1400cf1be:     	movaps	%xmm7, 0x130(%rbp)
1400cf1c5:     	movaps	%xmm7, 0x140(%rbp)
1400cf1cc:     	movaps	%xmm7, 0x150(%rbp)
1400cf1d3:     	movaps	%xmm7, 0x160(%rbp)
1400cf1da:     	movaps	%xmm7, 0x170(%rbp)
1400cf1e1:     	movaps	%xmm7, 0x180(%rbp)
1400cf1e8:     	movaps	%xmm7, 0x190(%rbp)
1400cf1ef:     	movaps	%xmm7, 0x1a0(%rbp)
1400cf1f6:     	movaps	%xmm7, 0x1b0(%rbp)
1400cf1fd:     	movaps	%xmm7, 0x1c0(%rbp)
1400cf204:     	movaps	%xmm7, 0x1d0(%rbp)
1400cf20b:     	cmpq	$0x11, %rdi
1400cf20f:     	jae	0x1400cf2c4 <.text+0xce2c4>
1400cf215:     	leaq	0xe0(%rbp), %rbx
1400cf21c:     	leaq	0x230(%rbp), %rdx
1400cf223:     	movq	%rbx, %rcx
1400cf226:     	movq	%rdi, %r8
1400cf229:     	callq	0x1402b3660 <.text+0x2b2660>
1400cf22e:     	movw	%di, 0x1e0(%rbp)
1400cf235:     	movq	$0x0, -0x60(%rbp)
1400cf23d:     	movq	0x248(%rbp), %rax
1400cf244:     	movq	%rax, -0x48(%rbp)
1400cf248:     	movq	0x240(%rbp), %rax
1400cf24f:     	movq	%rax, -0x50(%rbp)
1400cf253:     	movl	%r14d, -0x40(%rbp)
1400cf257:     	movl	%r13d, -0x3c(%rbp)
1400cf25b:     	movw	%r12w, -0x38(%rbp)
1400cf260:     	movb	%r15b, -0x36(%rbp)
1400cf264:     	movzbl	0x25f(%rbp), %eax
1400cf26b:     	movb	%al, -0x35(%rbp)
1400cf26e:     	movd	%xmm6, -0x34(%rbp)
1400cf273:     	movq	0x250(%rbp), %rax
1400cf27a:     	movq	%rax, -0x30(%rbp)
1400cf27e:     	leaq	-0x28(%rbp), %rcx
1400cf282:     	movl	$0x108, %r8d            # imm = 0x108
1400cf288:     	movq	%rbx, %rdx
1400cf28b:     	callq	0x1402b3660 <.text+0x2b2660>
1400cf290:     	leaq	-0x60(%rbp), %rdx
1400cf294:     	movq	%rsi, %rcx
1400cf297:     	callq	0x1402797b0 <.text+0x2787b0>
1400cf29c:     	movb	$0x1, %al
1400cf29e:     	jmp	0x1400cf2a2 <.text+0xce2a2>
1400cf2a0:     	xorl	%eax, %eax
1400cf2a2:     	movaps	0x260(%rbp), %xmm6
1400cf2a9:     	movaps	0x270(%rbp), %xmm7
1400cf2b0:     	addq	$0x308, %rsp            # imm = 0x308
1400cf2b7:     	popq	%rbx
1400cf2b8:     	popq	%rdi
1400cf2b9:     	popq	%rsi
1400cf2ba:     	popq	%r12
1400cf2bc:     	popq	%r13
1400cf2be:     	popq	%r14
1400cf2c0:     	popq	%r15
1400cf2c2:     	popq	%rbp
1400cf2c3:     	retq
1400cf2c4:     	leaq	0x20588d(%rip), %r9     # 0x1402d4b58
1400cf2cb:     	movl	$0x10, %r8d
1400cf2d1:     	xorl	%ecx, %ecx
1400cf2d3:     	movq	%rdi, %rdx
1400cf2d6:     	callq	0x1402b40b0 <.text+0x2b30b0>
1400cf2db:     	ud2

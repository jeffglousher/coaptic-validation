
D:\CoapticCurrent\unified-reply-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400691d0:     	pushq	%rbp
1400691d1:     	pushq	%r15
1400691d3:     	pushq	%r14
1400691d5:     	pushq	%r13
1400691d7:     	pushq	%r12
1400691d9:     	pushq	%rsi
1400691da:     	pushq	%rdi
1400691db:     	pushq	%rbx
1400691dc:     	subq	$0x4f8, %rsp            # imm = 0x4F8
1400691e3:     	leaq	0x80(%rsp), %rbp
1400691eb:     	movq	%r9, %rbx
1400691ee:     	movq	%r8, %r14
1400691f1:     	movq	%rdx, %rdi
1400691f4:     	movq	%rcx, %rsi
1400691f7:     	movq	0x4f0(%rbp), %r12
1400691fe:     	leaq	-0x10(%rbp), %rcx
140069202:     	movl	$0x400, %r8d            # imm = 0x400
140069208:     	xorl	%edx, %edx
14006920a:     	callq	0x1402b3672 <.text+0x2b2672>
14006920f:     	movq	0x8(%r12), %r13
140069214:     	movl	$0x3, %eax
140069219:     	cmpq	$0x3, %r13
14006921d:     	ja	0x14006943c <.text+0x6843c>
140069223:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
14006922c:     	jne	0x14006943c <.text+0x6843c>
140069232:     	movq	0x2b750(%rdi,%r13,8), %rdx
14006923a:     	cmpq	$0x4001, %rdx           # imm = 0x4001
140069241:     	jae	0x140069498 <.text+0x68498>
140069247:     	movq	0x10(%r12), %rcx
14006924c:     	movq	0x18(%r12), %r15
140069251:     	movq	%r15, %r8
140069254:     	movl	$0xb, %eax
140069259:     	addq	%rcx, %r8
14006925c:     	jb	0x14006943c <.text+0x6843c>
140069262:     	cmpq	$0x400, %r15            # imm = 0x400
140069269:     	ja	0x14006943c <.text+0x6843c>
14006926f:     	cmpq	%rdx, %r8
140069272:     	ja	0x14006943c <.text+0x6843c>
140069278:     	movq	%r13, %rax
14006927b:     	shlq	$0xe, %rax
14006927f:     	leaq	(%rdi,%rax), %rdx
140069283:     	addq	$0x1b750, %rdx          # imm = 0x1B750
14006928a:     	addq	%rcx, %rdx
14006928d:     	leaq	-0x10(%rbp), %rcx
140069291:     	movq	%r15, %r8
140069294:     	callq	0x1402b3660 <.text+0x2b2660>
140069299:     	cmpb	$0x0, 0x4f8(%rbp)
1400692a0:     	je	0x1400692b8 <.text+0x682b8>
1400692a2:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
1400692a9:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
1400692b2:     	jne	0x140069457 <.text+0x68457>
1400692b8:     	movq	$0x0, 0x470(%rbp)
1400692c3:     	movq	%rdi, %rcx
1400692c6:     	callq	0x1400cb430 <.text+0xca430>
1400692cb:     	testb	$0x1, %al
1400692cd:     	je	0x14006948a <.text+0x6848a>
1400692d3:     	movq	%rdx, %r13
1400692d6:     	movq	0x500(%rbp), %rdx
1400692dd:     	movzwl	0x4e8(%rbp), %ecx
1400692e4:     	movzbl	0x4e0(%rbp), %eax
1400692eb:     	movq	(%r12), %r8
1400692ef:     	movq	0x470(%rbp), %r9
1400692f6:     	movq	%r9, 0x438(%rbp)
1400692fd:     	movq	0x468(%rbp), %r9
140069304:     	movq	%r9, 0x440(%rbp)
14006930b:     	movq	%r8, 0x448(%rbp)
140069312:     	movzbl	0x4f8(%rbp), %r8d
14006931a:     	movb	%r8b, 0x450(%rbp)
140069321:     	movups	0x60(%r14), %xmm0
140069326:     	movups	0x6c(%r14), %xmm1
14006932b:     	movups	%xmm1, 0x3fc(%rbp)
140069332:     	movaps	%xmm0, 0x3f0(%rbp)
140069339:     	leaq	0x8e(%r14), %r8
140069340:     	movq	0x7e(%r14), %r9
140069344:     	movq	0x85(%r14), %r10
14006934b:     	movq	%r10, 0x45f(%rbp)
140069352:     	movq	%r9, 0x458(%rbp)
140069359:     	leaq	0x458(%rbp), %r9
140069360:     	movq	%r9, 0x68(%rsp)
140069365:     	movq	%rdx, 0x60(%rsp)
14006936a:     	movq	%r14, 0x58(%rsp)
14006936f:     	leaq	0x438(%rbp), %rdx
140069376:     	movq	%rdx, 0x50(%rsp)
14006937b:     	movq	%r15, 0x48(%rsp)
140069380:     	leaq	-0x10(%rbp), %rdx
140069384:     	movq	%rdx, 0x40(%rsp)
140069389:     	movq	%rbx, 0x38(%rsp)
14006938e:     	movq	%r8, 0x30(%rsp)
140069393:     	movw	%cx, 0x28(%rsp)
140069398:     	movb	%al, 0x20(%rsp)
14006939c:     	leaq	0x418(%rbp), %rcx
1400693a3:     	leaq	0x3f0(%rbp), %r8
1400693aa:     	movq	%rdi, %rdx
1400693ad:     	movq	%r13, %r9
1400693b0:     	callq	0x1400a93f0 <.text+0xa83f0>
1400693b5:     	cmpb	$-0x1, 0x418(%rbp)
1400693bc:     	je	0x14006948f <.text+0x6848f>
1400693c2:     	cmpb	$0x1, 0x37740(%rdi,%r13)
1400693cb:     	jne	0x140069425 <.text+0x68425>
1400693cd:     	cmpb	$0x0, 0x37760(%rdi,%r13)
1400693d6:     	jne	0x140069425 <.text+0x68425>
1400693d8:     	movb	$0x0, 0x37740(%rdi,%r13)
1400693e1:     	decq	0x37788(%rdi)
1400693e8:     	leaq	0x37740(%rdi), %rax
1400693ef:     	movq	$0x0, 0x43610(%rdi,%r13,8)
1400693fb:     	leaq	(,%r13,8), %rcx
140069403:     	addq	%r13, %rcx
140069406:     	leaq	(%rcx,%rcx,2), %rcx
14006940a:     	addq	%r13, %rcx
14006940d:     	movb	$0x2, 0x36a(%rax,%rcx)
140069415:     	leaq	(,%r13,2), %rcx
14006941d:     	addq	%r13, %rcx
140069420:     	movb	$0x2, 0x5d(%rax,%rcx,8)
140069425:     	movups	0x418(%rbp), %xmm0
14006942c:     	movups	0x428(%rbp), %xmm1
140069433:     	movups	%xmm1, 0x10(%rsi)
140069437:     	movups	%xmm0, (%rsi)
14006943a:     	jmp	0x140069443 <.text+0x68443>
14006943c:     	movb	$0xa, (%rsi)
14006943f:     	movq	%rax, 0x8(%rsi)
140069443:     	addq	$0x4f8, %rsp            # imm = 0x4F8
14006944a:     	popq	%rbx
14006944b:     	popq	%rdi
14006944c:     	popq	%rsi
14006944d:     	popq	%r12
14006944f:     	popq	%r13
140069451:     	popq	%r14
140069453:     	popq	%r15
140069455:     	popq	%rbp
140069456:     	retq
140069457:     	addq	%rdi, %rax
14006945a:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
140069460:     	movq	0x98(%rax), %rax
140069467:     	movq	%rax, 0x468(%rbp)
14006946e:     	movl	$0x1, %eax
140069473:     	movq	%rax, 0x470(%rbp)
14006947a:     	movq	%rdi, %rcx
14006947d:     	callq	0x1400cb430 <.text+0xca430>
140069482:     	testb	$0x1, %al
140069484:     	jne	0x1400692d3 <.text+0x682d3>
14006948a:     	movb	$0x9, (%rsi)
14006948d:     	jmp	0x140069443 <.text+0x68443>
14006948f:     	movq	%r13, 0x8(%rsi)
140069493:     	movb	$-0x1, (%rsi)
140069496:     	jmp	0x140069443 <.text+0x68443>
140069498:     	leaq	0x26e869(%rip), %r9     # 0x1402d7d08
14006949f:     	movl	$0x4000, %r8d           # imm = 0x4000
1400694a5:     	xorl	%ecx, %ecx
1400694a7:     	callq	0x1402b40b0 <.text+0x2b30b0>
1400694ac:     	ud2


D:\CoapticCurrent\unified-reply-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400ceba0:     	pushq	%rbp
1400ceba1:     	pushq	%r15
1400ceba3:     	pushq	%r14
1400ceba5:     	pushq	%r13
1400ceba7:     	pushq	%r12
1400ceba9:     	pushq	%rsi
1400cebaa:     	pushq	%rdi
1400cebab:     	pushq	%rbx
1400cebac:     	subq	$0x318, %rsp            # imm = 0x318
1400cebb3:     	leaq	0x80(%rsp), %rbp
1400cebbb:     	movaps	%xmm7, 0x280(%rbp)
1400cebc2:     	movaps	%xmm6, 0x270(%rbp)
1400cebc9:     	leaq	0x30(%rcx), %rdx
1400cebcd:     	xorl	%r8d, %r8d
1400cebd0:     	xorl	%r11d, %r11d
1400cebd3:     	leaq	(%r11,%r11,4), %r10
1400cebd7:     	shlq	$0x6, %r10
1400cebdb:     	addq	%rdx, %r10
1400cebde:     	movq	%r11, %r9
1400cebe1:     	jmp	0x1400cec04 <.text+0xcdc04>
1400cebe3:     	nopw	%cs:(%rax,%rax)
1400cebf0:     	incq	%r9
1400cebf3:     	addq	$0x140, %r10            # imm = 0x140
1400cebfa:     	cmpq	$0x4, %r9
1400cebfe:     	je	0x1400cec8e <.text+0xcdc8e>
1400cec04:     	cmpb	$0x1, 0x510(%rcx,%r9)
1400cec0d:     	jne	0x1400cebf0 <.text+0xcdbf0>
1400cec0f:     	movq	-0x30(%r10), %rsi
1400cec13:     	cmpq	$0x2, %rsi
1400cec17:     	je	0x1400cebf0 <.text+0xcdbf0>
1400cec19:     	movq	(%r10), %r11
1400cec1c:     	cmpl	$0x1, %esi
1400cec1f:     	setne	%bl
1400cec22:     	testq	%r11, %r11
1400cec25:     	sete	%sil
1400cec29:     	orb	%bl, %sil
1400cec2c:     	cmpb	$0x1, %sil
1400cec30:     	je	0x1400cebf0 <.text+0xcdbf0>
1400cec32:     	movq	0x268(%rbp), %rsi
1400cec39:     	cmpq	%rsi, %r11
1400cec3c:     	setae	%bl
1400cec3f:     	testb	%bl, %r8b
1400cec42:     	jne	0x1400cec74 <.text+0xcdc74>
1400cec44:     	movq	-0x28(%r10), %rax
1400cec48:     	movd	-0x4(%r10), %xmm6
1400cec4e:     	movzbl	-0x5(%r10), %edi
1400cec53:     	movzbl	-0x6(%r10), %r15d
1400cec58:     	movzwl	-0x8(%r10), %r12d
1400cec5d:     	movl	-0xc(%r10), %r13d
1400cec61:     	movl	-0x10(%r10), %r14d
1400cec65:     	movups	-0x20(%r10), %xmm0
1400cec6a:     	movaps	%xmm0, 0x240(%rbp)
1400cec71:     	movq	%r11, %rsi
1400cec74:     	movq	%rsi, 0x268(%rbp)
1400cec7b:     	leaq	0x1(%r9), %r11
1400cec7f:     	movb	$0x1, %r8b
1400cec82:     	cmpq	$0x3, %r9
1400cec86:     	jb	0x1400cebd3 <.text+0xcdbd3>
1400cec8c:     	jmp	0x1400cec98 <.text+0xcdc98>
1400cec8e:     	testb	$0x1, %r8b
1400cec92:     	je	0x1400ceed8 <.text+0xcded8>
1400cec98:     	cmpq	$0x1, %rax
1400cec9c:     	ja	0x1400cecf4 <.text+0xcdcf4>
1400cec9e:     	cmpb	$0x1, 0x4420(%rcx,%rax)
1400ceca6:     	jne	0x1400cecf4 <.text+0xcdcf4>
1400ceca8:     	cmpb	$0x0, 0x4422(%rcx,%rax)
1400cecb0:     	jne	0x1400cecf4 <.text+0xcdcf4>
1400cecb2:     	movb	$0x0, 0x4420(%rcx,%rax)
1400cecba:     	decq	0x4418(%rcx)
1400cecc1:     	leaq	0x3a98(%rcx), %rdx
1400cecc8:     	movq	$0x0, 0x4398(%rcx,%rax,8)
1400cecd4:     	leaq	(%rax,%rax,8), %r8
1400cecd8:     	leaq	(%r8,%r8,2), %r8
1400cecdc:     	addq	%rax, %r8
1400cecdf:     	movb	$0x2, 0x95a(%rdx,%r8)
1400cece8:     	leaq	(%rax,%rax,2), %rax
1400cecec:     	movb	$0x2, 0x91d(%rdx,%rax,8)
1400cecf4:     	movaps	0x240(%rbp), %xmm0
1400cecfb:     	movaps	%xmm0, -0x60(%rbp)
1400cecff:     	movl	%r14d, %esi
1400ced02:     	movl	%r14d, -0x50(%rbp)
1400ced06:     	movl	%r13d, %r14d
1400ced09:     	movl	%r13d, -0x4c(%rbp)
1400ced0d:     	movl	%r12d, %r13d
1400ced10:     	movw	%r12w, -0x48(%rbp)
1400ced15:     	movl	%r15d, %r12d
1400ced18:     	movb	%r15b, -0x46(%rbp)
1400ced1c:     	movl	%edi, %r15d
1400ced1f:     	movb	%dil, -0x45(%rbp)
1400ced23:     	movd	%xmm6, %edi
1400ced27:     	movd	%xmm6, -0x44(%rbp)
1400ced2c:     	leaq	-0x60(%rbp), %rdx
1400ced30:     	movq	%rcx, 0x260(%rbp)
1400ced37:     	callq	0x140279be0 <.text+0x278be0>
1400ced3c:     	xorps	%xmm7, %xmm7
1400ced3f:     	movaps	%xmm7, 0x250(%rbp)
1400ced46:     	movb	$0x0, 0x222(%rbp)
1400ced4d:     	movw	%di, 0x220(%rbp)
1400ced54:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
1400ced5d:     	movq	$0x0, 0x223(%rbp)
1400ced68:     	movq	$0x8, 0x200(%rbp)
1400ced73:     	movq	$0x0, 0x208(%rbp)
1400ced7e:     	movq	$0x1, 0x210(%rbp)
1400ced89:     	movq	$0x0, 0x218(%rbp)
1400ced94:     	leaq	0x230(%rbp), %rcx
1400ced9b:     	leaq	0x200(%rbp), %rdx
1400ceda2:     	leaq	0x250(%rbp), %r8
1400ceda9:     	movl	$0x10, %r9d
1400cedaf:     	callq	0x14014ae60 <.text+0x149e60>
1400cedb4:     	cmpb	$0x0, 0x230(%rbp)
1400cedbb:     	jne	0x1400ceed4 <.text+0xcded4>
1400cedc1:     	movq	0x238(%rbp), %rdi
1400cedc8:     	movaps	%xmm7, 0xe0(%rbp)
1400cedcf:     	movaps	%xmm7, 0xf0(%rbp)
1400cedd6:     	movaps	%xmm7, 0x100(%rbp)
1400ceddd:     	movaps	%xmm7, 0x110(%rbp)
1400cede4:     	movaps	%xmm7, 0x120(%rbp)
1400cedeb:     	movaps	%xmm7, 0x130(%rbp)
1400cedf2:     	movaps	%xmm7, 0x140(%rbp)
1400cedf9:     	movaps	%xmm7, 0x150(%rbp)
1400cee00:     	movaps	%xmm7, 0x160(%rbp)
1400cee07:     	movaps	%xmm7, 0x170(%rbp)
1400cee0e:     	movaps	%xmm7, 0x180(%rbp)
1400cee15:     	movaps	%xmm7, 0x190(%rbp)
1400cee1c:     	movaps	%xmm7, 0x1a0(%rbp)
1400cee23:     	movaps	%xmm7, 0x1b0(%rbp)
1400cee2a:     	movaps	%xmm7, 0x1c0(%rbp)
1400cee31:     	movaps	%xmm7, 0x1d0(%rbp)
1400cee38:     	movaps	0x240(%rbp), %xmm0
1400cee3f:     	movups	%xmm0, 0x1f0(%rbp)
1400cee46:     	cmpq	$0x11, %rdi
1400cee4a:     	jae	0x1400ceefc <.text+0xcdefc>
1400cee50:     	leaq	0xe0(%rbp), %rbx
1400cee57:     	leaq	0x250(%rbp), %rdx
1400cee5e:     	movq	%rbx, %rcx
1400cee61:     	movq	%rdi, %r8
1400cee64:     	callq	0x1402b3660 <.text+0x2b2660>
1400cee69:     	movw	%di, 0x1e0(%rbp)
1400cee70:     	movq	$0x0, -0x60(%rbp)
1400cee78:     	movups	0x1e8(%rbp), %xmm0
1400cee7f:     	movups	%xmm0, -0x58(%rbp)
1400cee83:     	movq	0x1f8(%rbp), %rax
1400cee8a:     	movq	%rax, -0x48(%rbp)
1400cee8e:     	movl	%esi, -0x40(%rbp)
1400cee91:     	movl	%r14d, -0x3c(%rbp)
1400cee95:     	movw	%r13w, -0x38(%rbp)
1400cee9a:     	movb	%r12b, -0x36(%rbp)
1400cee9e:     	movb	%r15b, -0x35(%rbp)
1400ceea2:     	movd	%xmm6, -0x34(%rbp)
1400ceea7:     	movq	0x268(%rbp), %rax
1400ceeae:     	movq	%rax, -0x30(%rbp)
1400ceeb2:     	leaq	-0x28(%rbp), %rcx
1400ceeb6:     	movl	$0x108, %r8d            # imm = 0x108
1400ceebc:     	movq	%rbx, %rdx
1400ceebf:     	callq	0x1402b3660 <.text+0x2b2660>
1400ceec4:     	leaq	-0x60(%rbp), %rdx
1400ceec8:     	movq	0x260(%rbp), %rcx
1400ceecf:     	callq	0x140279950 <.text+0x278950>
1400ceed4:     	movb	$0x1, %al
1400ceed6:     	jmp	0x1400ceeda <.text+0xcdeda>
1400ceed8:     	xorl	%eax, %eax
1400ceeda:     	movaps	0x270(%rbp), %xmm6
1400ceee1:     	movaps	0x280(%rbp), %xmm7
1400ceee8:     	addq	$0x318, %rsp            # imm = 0x318
1400ceeef:     	popq	%rbx
1400ceef0:     	popq	%rdi
1400ceef1:     	popq	%rsi
1400ceef2:     	popq	%r12
1400ceef4:     	popq	%r13
1400ceef6:     	popq	%r14
1400ceef8:     	popq	%r15
1400ceefa:     	popq	%rbp
1400ceefb:     	retq
1400ceefc:     	leaq	0x205c55(%rip), %r9     # 0x1402d4b58
1400cef03:     	movl	$0x10, %r8d
1400cef09:     	xorl	%ecx, %ecx
1400cef0b:     	movq	%rdi, %rdx
1400cef0e:     	callq	0x1402b40b0 <.text+0x2b30b0>
1400cef13:     	ud2

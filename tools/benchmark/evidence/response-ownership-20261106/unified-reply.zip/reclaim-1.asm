
D:\CoapticCurrent\unified-reply-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400ce820:     	pushq	%rbp
1400ce821:     	pushq	%r15
1400ce823:     	pushq	%r14
1400ce825:     	pushq	%r13
1400ce827:     	pushq	%r12
1400ce829:     	pushq	%rsi
1400ce82a:     	pushq	%rdi
1400ce82b:     	pushq	%rbx
1400ce82c:     	subq	$0x318, %rsp            # imm = 0x318
1400ce833:     	leaq	0x80(%rsp), %rbp
1400ce83b:     	movaps	%xmm7, 0x280(%rbp)
1400ce842:     	movaps	%xmm6, 0x270(%rbp)
1400ce849:     	leaq	0x30(%rcx), %rdx
1400ce84d:     	xorl	%r8d, %r8d
1400ce850:     	xorl	%r11d, %r11d
1400ce853:     	leaq	(%r11,%r11,4), %r10
1400ce857:     	shlq	$0x6, %r10
1400ce85b:     	addq	%rdx, %r10
1400ce85e:     	movq	%r11, %r9
1400ce861:     	jmp	0x1400ce884 <.text+0xcd884>
1400ce863:     	nopw	%cs:(%rax,%rax)
1400ce870:     	incq	%r9
1400ce873:     	addq	$0x140, %r10            # imm = 0x140
1400ce87a:     	cmpq	$0x4, %r9
1400ce87e:     	je	0x1400ce90e <.text+0xcd90e>
1400ce884:     	cmpb	$0x1, 0x510(%rcx,%r9)
1400ce88d:     	jne	0x1400ce870 <.text+0xcd870>
1400ce88f:     	movq	-0x30(%r10), %rsi
1400ce893:     	cmpq	$0x2, %rsi
1400ce897:     	je	0x1400ce870 <.text+0xcd870>
1400ce899:     	movq	(%r10), %r11
1400ce89c:     	cmpl	$0x1, %esi
1400ce89f:     	setne	%bl
1400ce8a2:     	testq	%r11, %r11
1400ce8a5:     	sete	%sil
1400ce8a9:     	orb	%bl, %sil
1400ce8ac:     	cmpb	$0x1, %sil
1400ce8b0:     	je	0x1400ce870 <.text+0xcd870>
1400ce8b2:     	movq	0x268(%rbp), %rsi
1400ce8b9:     	cmpq	%rsi, %r11
1400ce8bc:     	setae	%bl
1400ce8bf:     	testb	%bl, %r8b
1400ce8c2:     	jne	0x1400ce8f4 <.text+0xcd8f4>
1400ce8c4:     	movq	-0x28(%r10), %rax
1400ce8c8:     	movd	-0x4(%r10), %xmm6
1400ce8ce:     	movzbl	-0x5(%r10), %edi
1400ce8d3:     	movzbl	-0x6(%r10), %r15d
1400ce8d8:     	movzwl	-0x8(%r10), %r12d
1400ce8dd:     	movl	-0xc(%r10), %r13d
1400ce8e1:     	movl	-0x10(%r10), %r14d
1400ce8e5:     	movups	-0x20(%r10), %xmm0
1400ce8ea:     	movaps	%xmm0, 0x240(%rbp)
1400ce8f1:     	movq	%r11, %rsi
1400ce8f4:     	movq	%rsi, 0x268(%rbp)
1400ce8fb:     	leaq	0x1(%r9), %r11
1400ce8ff:     	movb	$0x1, %r8b
1400ce902:     	cmpq	$0x3, %r9
1400ce906:     	jb	0x1400ce853 <.text+0xcd853>
1400ce90c:     	jmp	0x1400ce918 <.text+0xcd918>
1400ce90e:     	testb	$0x1, %r8b
1400ce912:     	je	0x1400ceb58 <.text+0xcdb58>
1400ce918:     	cmpq	$0x1, %rax
1400ce91c:     	ja	0x1400ce974 <.text+0xcd974>
1400ce91e:     	cmpb	$0x1, 0x1e80(%rcx,%rax)
1400ce926:     	jne	0x1400ce974 <.text+0xcd974>
1400ce928:     	cmpb	$0x0, 0x1e82(%rcx,%rax)
1400ce930:     	jne	0x1400ce974 <.text+0xcd974>
1400ce932:     	movb	$0x0, 0x1e80(%rcx,%rax)
1400ce93a:     	decq	0x1e78(%rcx)
1400ce941:     	leaq	0x14f8(%rcx), %rdx
1400ce948:     	movq	$0x0, 0x1df8(%rcx,%rax,8)
1400ce954:     	leaq	(%rax,%rax,8), %r8
1400ce958:     	leaq	(%r8,%r8,2), %r8
1400ce95c:     	addq	%rax, %r8
1400ce95f:     	movb	$0x2, 0x95a(%rdx,%r8)
1400ce968:     	leaq	(%rax,%rax,2), %rax
1400ce96c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
1400ce974:     	movaps	0x240(%rbp), %xmm0
1400ce97b:     	movaps	%xmm0, -0x60(%rbp)
1400ce97f:     	movl	%r14d, %esi
1400ce982:     	movl	%r14d, -0x50(%rbp)
1400ce986:     	movl	%r13d, %r14d
1400ce989:     	movl	%r13d, -0x4c(%rbp)
1400ce98d:     	movl	%r12d, %r13d
1400ce990:     	movw	%r12w, -0x48(%rbp)
1400ce995:     	movl	%r15d, %r12d
1400ce998:     	movb	%r15b, -0x46(%rbp)
1400ce99c:     	movl	%edi, %r15d
1400ce99f:     	movb	%dil, -0x45(%rbp)
1400ce9a3:     	movd	%xmm6, %edi
1400ce9a7:     	movd	%xmm6, -0x44(%rbp)
1400ce9ac:     	leaq	-0x60(%rbp), %rdx
1400ce9b0:     	movq	%rcx, 0x260(%rbp)
1400ce9b7:     	callq	0x140279be0 <.text+0x278be0>
1400ce9bc:     	xorps	%xmm7, %xmm7
1400ce9bf:     	movaps	%xmm7, 0x250(%rbp)
1400ce9c6:     	movb	$0x0, 0x222(%rbp)
1400ce9cd:     	movw	%di, 0x220(%rbp)
1400ce9d4:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
1400ce9dd:     	movq	$0x0, 0x223(%rbp)
1400ce9e8:     	movq	$0x8, 0x200(%rbp)
1400ce9f3:     	movq	$0x0, 0x208(%rbp)
1400ce9fe:     	movq	$0x1, 0x210(%rbp)
1400cea09:     	movq	$0x0, 0x218(%rbp)
1400cea14:     	leaq	0x230(%rbp), %rcx
1400cea1b:     	leaq	0x200(%rbp), %rdx
1400cea22:     	leaq	0x250(%rbp), %r8
1400cea29:     	movl	$0x10, %r9d
1400cea2f:     	callq	0x14014ae60 <.text+0x149e60>
1400cea34:     	cmpb	$0x0, 0x230(%rbp)
1400cea3b:     	jne	0x1400ceb54 <.text+0xcdb54>
1400cea41:     	movq	0x238(%rbp), %rdi
1400cea48:     	movaps	%xmm7, 0xe0(%rbp)
1400cea4f:     	movaps	%xmm7, 0xf0(%rbp)
1400cea56:     	movaps	%xmm7, 0x100(%rbp)
1400cea5d:     	movaps	%xmm7, 0x110(%rbp)
1400cea64:     	movaps	%xmm7, 0x120(%rbp)
1400cea6b:     	movaps	%xmm7, 0x130(%rbp)
1400cea72:     	movaps	%xmm7, 0x140(%rbp)
1400cea79:     	movaps	%xmm7, 0x150(%rbp)
1400cea80:     	movaps	%xmm7, 0x160(%rbp)
1400cea87:     	movaps	%xmm7, 0x170(%rbp)
1400cea8e:     	movaps	%xmm7, 0x180(%rbp)
1400cea95:     	movaps	%xmm7, 0x190(%rbp)
1400cea9c:     	movaps	%xmm7, 0x1a0(%rbp)
1400ceaa3:     	movaps	%xmm7, 0x1b0(%rbp)
1400ceaaa:     	movaps	%xmm7, 0x1c0(%rbp)
1400ceab1:     	movaps	%xmm7, 0x1d0(%rbp)
1400ceab8:     	movaps	0x240(%rbp), %xmm0
1400ceabf:     	movups	%xmm0, 0x1f0(%rbp)
1400ceac6:     	cmpq	$0x11, %rdi
1400ceaca:     	jae	0x1400ceb7c <.text+0xcdb7c>
1400cead0:     	leaq	0xe0(%rbp), %rbx
1400cead7:     	leaq	0x250(%rbp), %rdx
1400ceade:     	movq	%rbx, %rcx
1400ceae1:     	movq	%rdi, %r8
1400ceae4:     	callq	0x1402b3660 <.text+0x2b2660>
1400ceae9:     	movw	%di, 0x1e0(%rbp)
1400ceaf0:     	movq	$0x0, -0x60(%rbp)
1400ceaf8:     	movups	0x1e8(%rbp), %xmm0
1400ceaff:     	movups	%xmm0, -0x58(%rbp)
1400ceb03:     	movq	0x1f8(%rbp), %rax
1400ceb0a:     	movq	%rax, -0x48(%rbp)
1400ceb0e:     	movl	%esi, -0x40(%rbp)
1400ceb11:     	movl	%r14d, -0x3c(%rbp)
1400ceb15:     	movw	%r13w, -0x38(%rbp)
1400ceb1a:     	movb	%r12b, -0x36(%rbp)
1400ceb1e:     	movb	%r15b, -0x35(%rbp)
1400ceb22:     	movd	%xmm6, -0x34(%rbp)
1400ceb27:     	movq	0x268(%rbp), %rax
1400ceb2e:     	movq	%rax, -0x30(%rbp)
1400ceb32:     	leaq	-0x28(%rbp), %rcx
1400ceb36:     	movl	$0x108, %r8d            # imm = 0x108
1400ceb3c:     	movq	%rbx, %rdx
1400ceb3f:     	callq	0x1402b3660 <.text+0x2b2660>
1400ceb44:     	leaq	-0x60(%rbp), %rdx
1400ceb48:     	movq	0x260(%rbp), %rcx
1400ceb4f:     	callq	0x140279950 <.text+0x278950>
1400ceb54:     	movb	$0x1, %al
1400ceb56:     	jmp	0x1400ceb5a <.text+0xcdb5a>
1400ceb58:     	xorl	%eax, %eax
1400ceb5a:     	movaps	0x270(%rbp), %xmm6
1400ceb61:     	movaps	0x280(%rbp), %xmm7
1400ceb68:     	addq	$0x318, %rsp            # imm = 0x318
1400ceb6f:     	popq	%rbx
1400ceb70:     	popq	%rdi
1400ceb71:     	popq	%rsi
1400ceb72:     	popq	%r12
1400ceb74:     	popq	%r13
1400ceb76:     	popq	%r14
1400ceb78:     	popq	%r15
1400ceb7a:     	popq	%rbp
1400ceb7b:     	retq
1400ceb7c:     	leaq	0x205fd5(%rip), %r9     # 0x1402d4b58
1400ceb83:     	movl	$0x10, %r8d
1400ceb89:     	xorl	%ecx, %ecx
1400ceb8b:     	movq	%rdi, %rdx
1400ceb8e:     	callq	0x1402b40b0 <.text+0x2b30b0>
1400ceb93:     	ud2


D:\CoapticCurrent\unified-reply-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068990:     	pushq	%rbp
140068991:     	pushq	%r15
140068993:     	pushq	%r14
140068995:     	pushq	%r13
140068997:     	pushq	%r12
140068999:     	pushq	%rsi
14006899a:     	pushq	%rdi
14006899b:     	pushq	%rbx
14006899c:     	subq	$0x4f8, %rsp            # imm = 0x4F8
1400689a3:     	leaq	0x80(%rsp), %rbp
1400689ab:     	movq	%r9, %r15
1400689ae:     	movq	%r8, %rbx
1400689b1:     	movq	%rdx, %r14
1400689b4:     	movq	%rcx, %rsi
1400689b7:     	movq	0x4f0(%rbp), %r12
1400689be:     	leaq	-0x10(%rbp), %rcx
1400689c2:     	movl	$0x400, %r8d            # imm = 0x400
1400689c8:     	xorl	%edx, %edx
1400689ca:     	callq	0x1402b3672 <.text+0x2b2672>
1400689cf:     	movq	0x8(%r12), %rdi
1400689d4:     	movl	$0x3, %eax
1400689d9:     	cmpq	$0x3, %rdi
1400689dd:     	ja	0x140068bea <.text+0x67bea>
1400689e3:     	movq	%r15, 0x468(%rbp)
1400689ea:     	movq	0x30(%r14), %r13
1400689ee:     	cmpb	$0x1, 0xad0(%r13,%rdi)
1400689f7:     	jne	0x140068bea <.text+0x67bea>
1400689fd:     	movq	0x10ad8(%r13,%rdi,8), %rdx
140068a05:     	cmpq	$0x4001, %rdx           # imm = 0x4001
140068a0c:     	jae	0x140068c39 <.text+0x67c39>
140068a12:     	movq	0x10(%r12), %rcx
140068a17:     	movq	0x18(%r12), %r15
140068a1c:     	movq	%r15, %r8
140068a1f:     	movl	$0xb, %eax
140068a24:     	addq	%rcx, %r8
140068a27:     	jb	0x140068bea <.text+0x67bea>
140068a2d:     	cmpq	$0x400, %r15            # imm = 0x400
140068a34:     	ja	0x140068bea <.text+0x67bea>
140068a3a:     	cmpq	%rdx, %r8
140068a3d:     	ja	0x140068bea <.text+0x67bea>
140068a43:     	movq	%rdi, %rax
140068a46:     	shlq	$0xe, %rax
140068a4a:     	leaq	(%rax,%r13), %rdx
140068a4e:     	addq	$0xad8, %rdx            # imm = 0xAD8
140068a55:     	addq	%rcx, %rdx
140068a58:     	leaq	-0x10(%rbp), %rcx
140068a5c:     	movq	%r15, %r8
140068a5f:     	callq	0x1402b3660 <.text+0x2b2660>
140068a64:     	cmpb	$0x0, 0x4f8(%rbp)
140068a6b:     	je	0x140068a80 <.text+0x67a80>
140068a6d:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
140068a74:     	cmpq	$0x2, (%r13,%rax)
140068a7a:     	jne	0x140068c05 <.text+0x67c05>
140068a80:     	xorl	%edi, %edi
140068a82:     	movq	%r14, %rcx
140068a85:     	callq	0x1400ca830 <.text+0xc9830>
140068a8a:     	testb	$0x1, %al
140068a8c:     	je	0x140068c2b <.text+0x67c2b>
140068a92:     	movq	%rdx, %r13
140068a95:     	movq	0x500(%rbp), %rdx
140068a9c:     	movzwl	0x4e8(%rbp), %ecx
140068aa3:     	movzbl	0x4e0(%rbp), %eax
140068aaa:     	movq	(%r12), %r8
140068aae:     	movq	%rdi, 0x438(%rbp)
140068ab5:     	movq	0x470(%rbp), %r9
140068abc:     	movq	%r9, 0x440(%rbp)
140068ac3:     	movq	%r8, 0x448(%rbp)
140068aca:     	movzbl	0x4f8(%rbp), %r8d
140068ad2:     	movb	%r8b, 0x450(%rbp)
140068ad9:     	movups	0x60(%rbx), %xmm0
140068add:     	movups	0x6c(%rbx), %xmm1
140068ae1:     	movups	%xmm1, 0x3fc(%rbp)
140068ae8:     	movaps	%xmm0, 0x3f0(%rbp)
140068aef:     	leaq	0x8e(%rbx), %r8
140068af6:     	movq	0x7e(%rbx), %r9
140068afa:     	movq	0x85(%rbx), %r10
140068b01:     	movq	%r10, 0x45f(%rbp)
140068b08:     	movq	%r9, 0x458(%rbp)
140068b0f:     	movq	0x10(%r14), %r14
140068b13:     	leaq	0x458(%rbp), %r9
140068b1a:     	movq	%r9, 0x68(%rsp)
140068b1f:     	movq	%rdx, 0x60(%rsp)
140068b24:     	movq	%rbx, 0x58(%rsp)
140068b29:     	leaq	0x438(%rbp), %rdx
140068b30:     	movq	%rdx, 0x50(%rsp)
140068b35:     	movq	%r15, 0x48(%rsp)
140068b3a:     	leaq	-0x10(%rbp), %rdx
140068b3e:     	movq	%rdx, 0x40(%rsp)
140068b43:     	movq	0x468(%rbp), %rdx
140068b4a:     	movq	%rdx, 0x38(%rsp)
140068b4f:     	movq	%r8, 0x30(%rsp)
140068b54:     	movw	%cx, 0x28(%rsp)
140068b59:     	movb	%al, 0x20(%rsp)
140068b5d:     	leaq	0x418(%rbp), %rcx
140068b64:     	leaq	0x3f0(%rbp), %r8
140068b6b:     	movq	%r14, %rdx
140068b6e:     	movq	%r13, %r9
140068b71:     	callq	0x1400a1d30 <.text+0xa0d30>
140068b76:     	cmpb	$-0x1, 0x418(%rbp)
140068b7d:     	je	0x140068c30 <.text+0x67c30>
140068b83:     	cmpb	$0x1, (%r14,%r13)
140068b88:     	jne	0x140068bd3 <.text+0x67bd3>
140068b8a:     	cmpb	$0x0, 0x20(%r14,%r13)
140068b90:     	jne	0x140068bd3 <.text+0x67bd3>
140068b92:     	movb	$0x0, (%r14,%r13)
140068b97:     	decq	0x48(%r14)
140068b9b:     	movq	$0x0, 0xbed0(%r14,%r13,8)
140068ba7:     	leaq	(,%r13,8), %rax
140068baf:     	addq	%r13, %rax
140068bb2:     	leaq	(%rax,%rax,2), %rax
140068bb6:     	addq	%r13, %rax
140068bb9:     	movb	$0x2, 0x36a(%r14,%rax)
140068bc2:     	leaq	(,%r13,2), %rax
140068bca:     	addq	%r13, %rax
140068bcd:     	movb	$0x2, 0x5d(%r14,%rax,8)
140068bd3:     	movups	0x418(%rbp), %xmm0
140068bda:     	movups	0x428(%rbp), %xmm1
140068be1:     	movups	%xmm1, 0x10(%rsi)
140068be5:     	movups	%xmm0, (%rsi)
140068be8:     	jmp	0x140068bf1 <.text+0x67bf1>
140068bea:     	movb	$0xa, (%rsi)
140068bed:     	movq	%rax, 0x8(%rsi)
140068bf1:     	addq	$0x4f8, %rsp            # imm = 0x4F8
140068bf8:     	popq	%rbx
140068bf9:     	popq	%rdi
140068bfa:     	popq	%rsi
140068bfb:     	popq	%r12
140068bfd:     	popq	%r13
140068bff:     	popq	%r14
140068c01:     	popq	%r15
140068c03:     	popq	%rbp
140068c04:     	retq
140068c05:     	addq	%rax, %r13
140068c08:     	movq	0x98(%r13), %rax
140068c0f:     	movq	%rax, 0x470(%rbp)
140068c16:     	movl	$0x1, %edi
140068c1b:     	movq	%r14, %rcx
140068c1e:     	callq	0x1400ca830 <.text+0xc9830>
140068c23:     	testb	$0x1, %al
140068c25:     	jne	0x140068a92 <.text+0x67a92>
140068c2b:     	movb	$0x9, (%rsi)
140068c2e:     	jmp	0x140068bf1 <.text+0x67bf1>
140068c30:     	movq	%r13, 0x8(%rsi)
140068c34:     	movb	$-0x1, (%rsi)
140068c37:     	jmp	0x140068bf1 <.text+0x67bf1>
140068c39:     	leaq	0x26f0c8(%rip), %r9     # 0x1402d7d08
140068c40:     	movl	$0x4000, %r8d           # imm = 0x4000
140068c46:     	xorl	%ecx, %ecx
140068c48:     	callq	0x1402b40b0 <.text+0x2b30b0>
140068c4d:     	ud2

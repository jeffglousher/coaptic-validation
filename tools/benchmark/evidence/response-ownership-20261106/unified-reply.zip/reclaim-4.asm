
D:\CoapticCurrent\unified-reply-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400cf2e0:     	pushq	%rbp
1400cf2e1:     	pushq	%r15
1400cf2e3:     	pushq	%r14
1400cf2e5:     	pushq	%r13
1400cf2e7:     	pushq	%r12
1400cf2e9:     	pushq	%rsi
1400cf2ea:     	pushq	%rdi
1400cf2eb:     	pushq	%rbx
1400cf2ec:     	subq	$0x318, %rsp            # imm = 0x318
1400cf2f3:     	leaq	0x80(%rsp), %rbp
1400cf2fb:     	movaps	%xmm7, 0x280(%rbp)
1400cf302:     	movdqa	%xmm6, 0x270(%rbp)
1400cf30a:     	movq	0xe8(%rcx), %r8
1400cf311:     	testq	%r8, %r8
1400cf314:     	je	0x1400cf6f4 <.text+0xce6f4>
1400cf31a:     	movq	0x88(%rcx), %r11
1400cf321:     	movq	0xe0(%rcx), %rdx
1400cf328:     	movq	0xc8(%rcx), %rax
1400cf32f:     	movq	0xd0(%rcx), %r9
1400cf336:     	leaq	0x30(%rax), %rsi
1400cf33a:     	xorl	%ebx, %ebx
1400cf33c:     	xorl	%edi, %edi
1400cf33e:     	leaq	(%rdi,%rdi,4), %r12
1400cf342:     	shlq	$0x6, %r12
1400cf346:     	addq	%rsi, %r12
1400cf349:     	jmp	0x1400cf363 <.text+0xce363>
1400cf34b:     	nopl	(%rax,%rax)
1400cf350:     	incq	%rdi
1400cf353:     	addq	$0x140, %r12            # imm = 0x140
1400cf35a:     	cmpq	%r8, %rdi
1400cf35d:     	jae	0x1400cf42c <.text+0xce42c>
1400cf363:     	cmpq	%r9, %rdi
1400cf366:     	setb	%r15b
1400cf36a:     	andb	(%rdx,%rdi), %r15b
1400cf36e:     	cmpb	$0x1, %r15b
1400cf372:     	jne	0x1400cf350 <.text+0xce350>
1400cf374:     	movq	-0x30(%r12), %r15
1400cf379:     	cmpq	$0x2, %r15
1400cf37d:     	je	0x1400cf350 <.text+0xce350>
1400cf37f:     	movq	(%r12), %r13
1400cf383:     	cmpl	$0x1, %r15d
1400cf387:     	setne	%r15b
1400cf38b:     	testq	%r13, %r13
1400cf38e:     	sete	%r10b
1400cf392:     	orb	%r15b, %r10b
1400cf395:     	cmpb	$0x1, %r10b
1400cf399:     	je	0x1400cf350 <.text+0xce350>
1400cf39b:     	movq	0x260(%rbp), %r15
1400cf3a2:     	cmpq	%r15, %r13
1400cf3a5:     	setae	%r10b
1400cf3a9:     	testb	%r10b, %bl
1400cf3ac:     	jne	0x1400cf415 <.text+0xce415>
1400cf3ae:     	movq	-0x28(%r12), %r10
1400cf3b3:     	movq	%r10, 0x250(%rbp)
1400cf3ba:     	movq	-0x20(%r12), %r10
1400cf3bf:     	movq	%r10, 0x248(%rbp)
1400cf3c6:     	movd	-0x4(%r12), %xmm6
1400cf3cd:     	movzbl	-0x5(%r12), %r10d
1400cf3d3:     	movb	%r10b, 0x26e(%rbp)
1400cf3da:     	movzbl	-0x6(%r12), %r10d
1400cf3e0:     	movb	%r10b, 0x26f(%rbp)
1400cf3e7:     	movzwl	-0x8(%r12), %r10d
1400cf3ed:     	movw	%r10w, 0x26c(%rbp)
1400cf3f5:     	movl	-0xc(%r12), %r10d
1400cf3fa:     	movl	%r10d, 0x268(%rbp)
1400cf401:     	movl	-0x10(%r12), %r14d
1400cf406:     	movq	-0x18(%r12), %r10
1400cf40b:     	movq	%r10, 0x258(%rbp)
1400cf412:     	movq	%r13, %r15
1400cf415:     	movq	%r15, 0x260(%rbp)
1400cf41c:     	incq	%rdi
1400cf41f:     	movb	$0x1, %bl
1400cf421:     	cmpq	%r8, %rdi
1400cf424:     	jb	0x1400cf33e <.text+0xce33e>
1400cf42a:     	jmp	0x1400cf435 <.text+0xce435>
1400cf42c:     	testb	$0x1, %bl
1400cf42f:     	je	0x1400cf6f4 <.text+0xce6f4>
1400cf435:     	movq	0x250(%rbp), %r10
1400cf43c:     	cmpq	%r11, %r10
1400cf43f:     	jae	0x1400cf495 <.text+0xce495>
1400cf441:     	movq	0x80(%rcx), %r11
1400cf448:     	cmpb	$0x1, (%r11,%r10)
1400cf44d:     	jne	0x1400cf495 <.text+0xce495>
1400cf44f:     	cmpq	0xa0(%rcx), %r10
1400cf456:     	jae	0x1400cf466 <.text+0xce466>
1400cf458:     	movq	0x98(%rcx), %rsi
1400cf45f:     	cmpb	$0x0, (%rsi,%r10)
1400cf464:     	jne	0x1400cf495 <.text+0xce495>
1400cf466:     	movb	$0x0, (%r11,%r10)
1400cf46b:     	decq	0xb0(%rcx)
1400cf472:     	cmpq	0x70(%rcx), %r10
1400cf476:     	jae	0x1400cf495 <.text+0xce495>
1400cf478:     	movq	0x68(%rcx), %r11
1400cf47c:     	imulq	$0x58, %r10, %r10
1400cf480:     	movq	$0x0, 0x30(%r11,%r10)
1400cf489:     	movb	$0x2, 0x52(%r11,%r10)
1400cf48f:     	movb	$0x2, 0x25(%r11,%r10)
1400cf495:     	leaq	0xc0(%rcx), %rsi
1400cf49c:     	movd	%xmm6, %r10d
1400cf4a1:     	addq	$0x2c, %rax
1400cf4a5:     	xorl	%r11d, %r11d
1400cf4a8:     	movq	0x248(%rbp), %r15
1400cf4af:     	movzbl	0x26e(%rbp), %r12d
1400cf4b7:     	jmp	0x1400cf4d2 <.text+0xce4d2>
1400cf4b9:     	nopl	(%rax)
1400cf4c0:     	incq	%r11
1400cf4c3:     	addq	$0x140, %rax            # imm = 0x140
1400cf4c9:     	cmpq	%r11, %r8
1400cf4cc:     	je	0x1400cf55e <.text+0xce55e>
1400cf4d2:     	cmpq	%r9, %r11
1400cf4d5:     	setb	%bl
1400cf4d8:     	andb	(%rdx,%r11), %bl
1400cf4dc:     	cmpb	$0x1, %bl
1400cf4df:     	jne	0x1400cf4c0 <.text+0xce4c0>
1400cf4e1:     	cmpl	$0x2, -0x2c(%rax)
1400cf4e5:     	je	0x1400cf4c0 <.text+0xce4c0>
1400cf4e7:     	cmpw	%r10w, (%rax)
1400cf4eb:     	jne	0x1400cf4c0 <.text+0xce4c0>
1400cf4ed:     	cmpl	%r14d, -0xc(%rax)
1400cf4f1:     	jne	0x1400cf4c0 <.text+0xce4c0>
1400cf4f3:     	movl	0x268(%rbp), %edi
1400cf4f9:     	cmpl	%edi, -0x8(%rax)
1400cf4fc:     	jne	0x1400cf4c0 <.text+0xce4c0>
1400cf4fe:     	movzwl	0x26c(%rbp), %edi
1400cf505:     	cmpw	%di, -0x4(%rax)
1400cf509:     	jne	0x1400cf4c0 <.text+0xce4c0>
1400cf50b:     	movzbl	0x26f(%rbp), %ebx
1400cf512:     	cmpb	%bl, -0x2(%rax)
1400cf515:     	jne	0x1400cf4c0 <.text+0xce4c0>
1400cf517:     	movq	-0x1c(%rax), %rdi
1400cf51b:     	xorq	%r15, %rdi
1400cf51e:     	movq	-0x14(%rax), %rbx
1400cf522:     	xorq	0x258(%rbp), %rbx
1400cf529:     	orq	%rdi, %rbx
1400cf52c:     	jne	0x1400cf4c0 <.text+0xce4c0>
1400cf52e:     	cmpq	%r8, %r11
1400cf531:     	jae	0x1400cf55e <.text+0xce55e>
1400cf533:     	cmpq	0x100(%rcx), %r11
1400cf53a:     	jae	0x1400cf54a <.text+0xce54a>
1400cf53c:     	movq	0xf8(%rcx), %r8
1400cf543:     	cmpb	$0x0, (%r8,%r11)
1400cf548:     	jne	0x1400cf55e <.text+0xce55e>
1400cf54a:     	movb	$0x0, (%rdx,%r11)
1400cf54f:     	decq	0x110(%rcx)
1400cf556:     	movq	$0x2, -0x2c(%rax)
1400cf55e:     	xorps	%xmm7, %xmm7
1400cf561:     	movaps	%xmm7, 0x230(%rbp)
1400cf568:     	movb	$0x0, 0x212(%rbp)
1400cf56f:     	movw	%r10w, 0x210(%rbp)
1400cf577:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
1400cf580:     	movq	$0x0, 0x213(%rbp)
1400cf58b:     	movq	$0x8, 0x1f0(%rbp)
1400cf596:     	movq	$0x0, 0x1f8(%rbp)
1400cf5a1:     	movq	$0x1, 0x200(%rbp)
1400cf5ac:     	movq	$0x0, 0x208(%rbp)
1400cf5b7:     	leaq	0x220(%rbp), %rcx
1400cf5be:     	leaq	0x1f0(%rbp), %rdx
1400cf5c5:     	leaq	0x230(%rbp), %r8
1400cf5cc:     	movl	$0x10, %r9d
1400cf5d2:     	callq	0x14014ae60 <.text+0x149e60>
1400cf5d7:     	cmpb	$0x0, 0x220(%rbp)
1400cf5de:     	jne	0x1400cf6f0 <.text+0xce6f0>
1400cf5e4:     	movq	0x228(%rbp), %rdi
1400cf5eb:     	movaps	%xmm7, 0xe0(%rbp)
1400cf5f2:     	movaps	%xmm7, 0xf0(%rbp)
1400cf5f9:     	movaps	%xmm7, 0x100(%rbp)
1400cf600:     	movaps	%xmm7, 0x110(%rbp)
1400cf607:     	movaps	%xmm7, 0x120(%rbp)
1400cf60e:     	movaps	%xmm7, 0x130(%rbp)
1400cf615:     	movaps	%xmm7, 0x140(%rbp)
1400cf61c:     	movaps	%xmm7, 0x150(%rbp)
1400cf623:     	movaps	%xmm7, 0x160(%rbp)
1400cf62a:     	movaps	%xmm7, 0x170(%rbp)
1400cf631:     	movaps	%xmm7, 0x180(%rbp)
1400cf638:     	movaps	%xmm7, 0x190(%rbp)
1400cf63f:     	movaps	%xmm7, 0x1a0(%rbp)
1400cf646:     	movaps	%xmm7, 0x1b0(%rbp)
1400cf64d:     	movaps	%xmm7, 0x1c0(%rbp)
1400cf654:     	movaps	%xmm7, 0x1d0(%rbp)
1400cf65b:     	cmpq	$0x11, %rdi
1400cf65f:     	jae	0x1400cf718 <.text+0xce718>
1400cf665:     	leaq	0xe0(%rbp), %rbx
1400cf66c:     	leaq	0x230(%rbp), %rdx
1400cf673:     	movq	%rbx, %rcx
1400cf676:     	movq	%rdi, %r8
1400cf679:     	callq	0x1402b3660 <.text+0x2b2660>
1400cf67e:     	movw	%di, 0x1e0(%rbp)
1400cf685:     	movq	$0x0, -0x60(%rbp)
1400cf68d:     	movq	0x258(%rbp), %rax
1400cf694:     	movq	%rax, -0x48(%rbp)
1400cf698:     	movq	%r15, -0x50(%rbp)
1400cf69c:     	movl	%r14d, -0x40(%rbp)
1400cf6a0:     	movl	0x268(%rbp), %eax
1400cf6a6:     	movl	%eax, -0x3c(%rbp)
1400cf6a9:     	movzwl	0x26c(%rbp), %eax
1400cf6b0:     	movw	%ax, -0x38(%rbp)
1400cf6b4:     	movzbl	0x26f(%rbp), %eax
1400cf6bb:     	movb	%al, -0x36(%rbp)
1400cf6be:     	movb	%r12b, -0x35(%rbp)
1400cf6c2:     	movd	%xmm6, -0x34(%rbp)
1400cf6c7:     	movq	0x260(%rbp), %rax
1400cf6ce:     	movq	%rax, -0x30(%rbp)
1400cf6d2:     	leaq	-0x28(%rbp), %rcx
1400cf6d6:     	movl	$0x108, %r8d            # imm = 0x108
1400cf6dc:     	movq	%rbx, %rdx
1400cf6df:     	callq	0x1402b3660 <.text+0x2b2660>
1400cf6e4:     	leaq	-0x60(%rbp), %rdx
1400cf6e8:     	movq	%rsi, %rcx
1400cf6eb:     	callq	0x140011600 <.text+0x10600>
1400cf6f0:     	movb	$0x1, %al
1400cf6f2:     	jmp	0x1400cf6f6 <.text+0xce6f6>
1400cf6f4:     	xorl	%eax, %eax
1400cf6f6:     	movaps	0x270(%rbp), %xmm6
1400cf6fd:     	movaps	0x280(%rbp), %xmm7
1400cf704:     	addq	$0x318, %rsp            # imm = 0x318
1400cf70b:     	popq	%rbx
1400cf70c:     	popq	%rdi
1400cf70d:     	popq	%rsi
1400cf70e:     	popq	%r12
1400cf710:     	popq	%r13
1400cf712:     	popq	%r14
1400cf714:     	popq	%r15
1400cf716:     	popq	%rbp
1400cf717:     	retq
1400cf718:     	leaq	0x205439(%rip), %r9     # 0x1402d4b58
1400cf71f:     	movl	$0x10, %r8d
1400cf725:     	xorl	%ecx, %ecx
1400cf727:     	movq	%rdi, %rdx
1400cf72a:     	callq	0x1402b40b0 <.text+0x2b30b0>
1400cf72f:     	ud2

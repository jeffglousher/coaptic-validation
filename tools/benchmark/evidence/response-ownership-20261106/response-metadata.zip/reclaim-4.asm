
D:\CoapticCurrent\response-metadata-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009b880:     	pushq	%rbp
14009b881:     	pushq	%r15
14009b883:     	pushq	%r14
14009b885:     	pushq	%r13
14009b887:     	pushq	%r12
14009b889:     	pushq	%rsi
14009b88a:     	pushq	%rdi
14009b88b:     	pushq	%rbx
14009b88c:     	subq	$0x318, %rsp            # imm = 0x318
14009b893:     	leaq	0x80(%rsp), %rbp
14009b89b:     	movaps	%xmm7, 0x280(%rbp)
14009b8a2:     	movdqa	%xmm6, 0x270(%rbp)
14009b8aa:     	movq	0xe8(%rcx), %r8
14009b8b1:     	testq	%r8, %r8
14009b8b4:     	je	0x14009bc94 <.text+0x9ac94>
14009b8ba:     	movq	0x88(%rcx), %r11
14009b8c1:     	movq	0xe0(%rcx), %rdx
14009b8c8:     	movq	0xc8(%rcx), %rax
14009b8cf:     	movq	0xd0(%rcx), %r9
14009b8d6:     	leaq	0x30(%rax), %rsi
14009b8da:     	xorl	%ebx, %ebx
14009b8dc:     	xorl	%edi, %edi
14009b8de:     	leaq	(%rdi,%rdi,4), %r12
14009b8e2:     	shlq	$0x6, %r12
14009b8e6:     	addq	%rsi, %r12
14009b8e9:     	jmp	0x14009b903 <.text+0x9a903>
14009b8eb:     	nopl	(%rax,%rax)
14009b8f0:     	incq	%rdi
14009b8f3:     	addq	$0x140, %r12            # imm = 0x140
14009b8fa:     	cmpq	%r8, %rdi
14009b8fd:     	jae	0x14009b9cc <.text+0x9a9cc>
14009b903:     	cmpq	%r9, %rdi
14009b906:     	setb	%r15b
14009b90a:     	andb	(%rdx,%rdi), %r15b
14009b90e:     	cmpb	$0x1, %r15b
14009b912:     	jne	0x14009b8f0 <.text+0x9a8f0>
14009b914:     	movq	-0x30(%r12), %r15
14009b919:     	cmpq	$0x2, %r15
14009b91d:     	je	0x14009b8f0 <.text+0x9a8f0>
14009b91f:     	movq	(%r12), %r13
14009b923:     	cmpl	$0x1, %r15d
14009b927:     	setne	%r15b
14009b92b:     	testq	%r13, %r13
14009b92e:     	sete	%r10b
14009b932:     	orb	%r15b, %r10b
14009b935:     	cmpb	$0x1, %r10b
14009b939:     	je	0x14009b8f0 <.text+0x9a8f0>
14009b93b:     	movq	0x260(%rbp), %r15
14009b942:     	cmpq	%r15, %r13
14009b945:     	setae	%r10b
14009b949:     	testb	%r10b, %bl
14009b94c:     	jne	0x14009b9b5 <.text+0x9a9b5>
14009b94e:     	movq	-0x28(%r12), %r10
14009b953:     	movq	%r10, 0x250(%rbp)
14009b95a:     	movq	-0x20(%r12), %r10
14009b95f:     	movq	%r10, 0x248(%rbp)
14009b966:     	movd	-0x4(%r12), %xmm6
14009b96d:     	movzbl	-0x5(%r12), %r10d
14009b973:     	movb	%r10b, 0x26e(%rbp)
14009b97a:     	movzbl	-0x6(%r12), %r10d
14009b980:     	movb	%r10b, 0x26f(%rbp)
14009b987:     	movzwl	-0x8(%r12), %r10d
14009b98d:     	movw	%r10w, 0x26c(%rbp)
14009b995:     	movl	-0xc(%r12), %r10d
14009b99a:     	movl	%r10d, 0x268(%rbp)
14009b9a1:     	movl	-0x10(%r12), %r14d
14009b9a6:     	movq	-0x18(%r12), %r10
14009b9ab:     	movq	%r10, 0x258(%rbp)
14009b9b2:     	movq	%r13, %r15
14009b9b5:     	movq	%r15, 0x260(%rbp)
14009b9bc:     	incq	%rdi
14009b9bf:     	movb	$0x1, %bl
14009b9c1:     	cmpq	%r8, %rdi
14009b9c4:     	jb	0x14009b8de <.text+0x9a8de>
14009b9ca:     	jmp	0x14009b9d5 <.text+0x9a9d5>
14009b9cc:     	testb	$0x1, %bl
14009b9cf:     	je	0x14009bc94 <.text+0x9ac94>
14009b9d5:     	movq	0x250(%rbp), %r10
14009b9dc:     	cmpq	%r11, %r10
14009b9df:     	jae	0x14009ba35 <.text+0x9aa35>
14009b9e1:     	movq	0x80(%rcx), %r11
14009b9e8:     	cmpb	$0x1, (%r11,%r10)
14009b9ed:     	jne	0x14009ba35 <.text+0x9aa35>
14009b9ef:     	cmpq	0xa0(%rcx), %r10
14009b9f6:     	jae	0x14009ba06 <.text+0x9aa06>
14009b9f8:     	movq	0x98(%rcx), %rsi
14009b9ff:     	cmpb	$0x0, (%rsi,%r10)
14009ba04:     	jne	0x14009ba35 <.text+0x9aa35>
14009ba06:     	movb	$0x0, (%r11,%r10)
14009ba0b:     	decq	0xb0(%rcx)
14009ba12:     	cmpq	0x70(%rcx), %r10
14009ba16:     	jae	0x14009ba35 <.text+0x9aa35>
14009ba18:     	movq	0x68(%rcx), %r11
14009ba1c:     	imulq	$0x58, %r10, %r10
14009ba20:     	movq	$0x0, 0x30(%r11,%r10)
14009ba29:     	movb	$0x2, 0x52(%r11,%r10)
14009ba2f:     	movb	$0x2, 0x25(%r11,%r10)
14009ba35:     	leaq	0xc0(%rcx), %rsi
14009ba3c:     	movd	%xmm6, %r10d
14009ba41:     	addq	$0x2c, %rax
14009ba45:     	xorl	%r11d, %r11d
14009ba48:     	movq	0x248(%rbp), %r15
14009ba4f:     	movzbl	0x26e(%rbp), %r12d
14009ba57:     	jmp	0x14009ba72 <.text+0x9aa72>
14009ba59:     	nopl	(%rax)
14009ba60:     	incq	%r11
14009ba63:     	addq	$0x140, %rax            # imm = 0x140
14009ba69:     	cmpq	%r11, %r8
14009ba6c:     	je	0x14009bafe <.text+0x9aafe>
14009ba72:     	cmpq	%r9, %r11
14009ba75:     	setb	%bl
14009ba78:     	andb	(%rdx,%r11), %bl
14009ba7c:     	cmpb	$0x1, %bl
14009ba7f:     	jne	0x14009ba60 <.text+0x9aa60>
14009ba81:     	cmpl	$0x2, -0x2c(%rax)
14009ba85:     	je	0x14009ba60 <.text+0x9aa60>
14009ba87:     	cmpw	%r10w, (%rax)
14009ba8b:     	jne	0x14009ba60 <.text+0x9aa60>
14009ba8d:     	cmpl	%r14d, -0xc(%rax)
14009ba91:     	jne	0x14009ba60 <.text+0x9aa60>
14009ba93:     	movl	0x268(%rbp), %edi
14009ba99:     	cmpl	%edi, -0x8(%rax)
14009ba9c:     	jne	0x14009ba60 <.text+0x9aa60>
14009ba9e:     	movzwl	0x26c(%rbp), %edi
14009baa5:     	cmpw	%di, -0x4(%rax)
14009baa9:     	jne	0x14009ba60 <.text+0x9aa60>
14009baab:     	movzbl	0x26f(%rbp), %ebx
14009bab2:     	cmpb	%bl, -0x2(%rax)
14009bab5:     	jne	0x14009ba60 <.text+0x9aa60>
14009bab7:     	movq	-0x1c(%rax), %rdi
14009babb:     	xorq	%r15, %rdi
14009babe:     	movq	-0x14(%rax), %rbx
14009bac2:     	xorq	0x258(%rbp), %rbx
14009bac9:     	orq	%rdi, %rbx
14009bacc:     	jne	0x14009ba60 <.text+0x9aa60>
14009bace:     	cmpq	%r8, %r11
14009bad1:     	jae	0x14009bafe <.text+0x9aafe>
14009bad3:     	cmpq	0x100(%rcx), %r11
14009bada:     	jae	0x14009baea <.text+0x9aaea>
14009badc:     	movq	0xf8(%rcx), %r8
14009bae3:     	cmpb	$0x0, (%r8,%r11)
14009bae8:     	jne	0x14009bafe <.text+0x9aafe>
14009baea:     	movb	$0x0, (%rdx,%r11)
14009baef:     	decq	0x110(%rcx)
14009baf6:     	movq	$0x2, -0x2c(%rax)
14009bafe:     	xorps	%xmm7, %xmm7
14009bb01:     	movaps	%xmm7, 0x230(%rbp)
14009bb08:     	movb	$0x0, 0x212(%rbp)
14009bb0f:     	movw	%r10w, 0x210(%rbp)
14009bb17:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
14009bb20:     	movq	$0x0, 0x213(%rbp)
14009bb2b:     	movq	$0x8, 0x1f0(%rbp)
14009bb36:     	movq	$0x0, 0x1f8(%rbp)
14009bb41:     	movq	$0x1, 0x200(%rbp)
14009bb4c:     	movq	$0x0, 0x208(%rbp)
14009bb57:     	leaq	0x220(%rbp), %rcx
14009bb5e:     	leaq	0x1f0(%rbp), %rdx
14009bb65:     	leaq	0x230(%rbp), %r8
14009bb6c:     	movl	$0x10, %r9d
14009bb72:     	callq	0x14010d6e0 <.text+0x10c6e0>
14009bb77:     	cmpb	$0x0, 0x220(%rbp)
14009bb7e:     	jne	0x14009bc90 <.text+0x9ac90>
14009bb84:     	movq	0x228(%rbp), %rdi
14009bb8b:     	movaps	%xmm7, 0xe0(%rbp)
14009bb92:     	movaps	%xmm7, 0xf0(%rbp)
14009bb99:     	movaps	%xmm7, 0x100(%rbp)
14009bba0:     	movaps	%xmm7, 0x110(%rbp)
14009bba7:     	movaps	%xmm7, 0x120(%rbp)
14009bbae:     	movaps	%xmm7, 0x130(%rbp)
14009bbb5:     	movaps	%xmm7, 0x140(%rbp)
14009bbbc:     	movaps	%xmm7, 0x150(%rbp)
14009bbc3:     	movaps	%xmm7, 0x160(%rbp)
14009bbca:     	movaps	%xmm7, 0x170(%rbp)
14009bbd1:     	movaps	%xmm7, 0x180(%rbp)
14009bbd8:     	movaps	%xmm7, 0x190(%rbp)
14009bbdf:     	movaps	%xmm7, 0x1a0(%rbp)
14009bbe6:     	movaps	%xmm7, 0x1b0(%rbp)
14009bbed:     	movaps	%xmm7, 0x1c0(%rbp)
14009bbf4:     	movaps	%xmm7, 0x1d0(%rbp)
14009bbfb:     	cmpq	$0x11, %rdi
14009bbff:     	jae	0x14009bcb8 <.text+0x9acb8>
14009bc05:     	leaq	0xe0(%rbp), %rbx
14009bc0c:     	leaq	0x230(%rbp), %rdx
14009bc13:     	movq	%rbx, %rcx
14009bc16:     	movq	%rdi, %r8
14009bc19:     	callq	0x14024afa0 <.text+0x249fa0>
14009bc1e:     	movw	%di, 0x1e0(%rbp)
14009bc25:     	movq	$0x0, -0x60(%rbp)
14009bc2d:     	movq	0x258(%rbp), %rax
14009bc34:     	movq	%rax, -0x48(%rbp)
14009bc38:     	movq	%r15, -0x50(%rbp)
14009bc3c:     	movl	%r14d, -0x40(%rbp)
14009bc40:     	movl	0x268(%rbp), %eax
14009bc46:     	movl	%eax, -0x3c(%rbp)
14009bc49:     	movzwl	0x26c(%rbp), %eax
14009bc50:     	movw	%ax, -0x38(%rbp)
14009bc54:     	movzbl	0x26f(%rbp), %eax
14009bc5b:     	movb	%al, -0x36(%rbp)
14009bc5e:     	movb	%r12b, -0x35(%rbp)
14009bc62:     	movd	%xmm6, -0x34(%rbp)
14009bc67:     	movq	0x260(%rbp), %rax
14009bc6e:     	movq	%rax, -0x30(%rbp)
14009bc72:     	leaq	-0x28(%rbp), %rcx
14009bc76:     	movl	$0x108, %r8d            # imm = 0x108
14009bc7c:     	movq	%rbx, %rdx
14009bc7f:     	callq	0x14024afa0 <.text+0x249fa0>
14009bc84:     	leaq	-0x60(%rbp), %rdx
14009bc88:     	movq	%rsi, %rcx
14009bc8b:     	callq	0x1400116e0 <.text+0x106e0>
14009bc90:     	movb	$0x1, %al
14009bc92:     	jmp	0x14009bc96 <.text+0x9ac96>
14009bc94:     	xorl	%eax, %eax
14009bc96:     	movaps	0x270(%rbp), %xmm6
14009bc9d:     	movaps	0x280(%rbp), %xmm7
14009bca4:     	addq	$0x318, %rsp            # imm = 0x318
14009bcab:     	popq	%rbx
14009bcac:     	popq	%rdi
14009bcad:     	popq	%rsi
14009bcae:     	popq	%r12
14009bcb0:     	popq	%r13
14009bcb2:     	popq	%r14
14009bcb4:     	popq	%r15
14009bcb6:     	popq	%rbp
14009bcb7:     	retq
14009bcb8:     	leaq	0x1c7ea9(%rip), %r9     # 0x140263b68
14009bcbf:     	movl	$0x10, %r8d
14009bcc5:     	xorl	%ecx, %ecx
14009bcc7:     	movq	%rdi, %rdx
14009bcca:     	callq	0x14024b9f0 <.text+0x24a9f0>
14009bccf:     	ud2

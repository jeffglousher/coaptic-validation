
D:\CoapticCurrent\response-metadata-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140066640:     	pushq	%rbp
140066641:     	pushq	%r15
140066643:     	pushq	%r14
140066645:     	pushq	%r13
140066647:     	pushq	%r12
140066649:     	pushq	%rsi
14006664a:     	pushq	%rdi
14006664b:     	pushq	%rbx
14006664c:     	subq	$0x508, %rsp            # imm = 0x508
140066653:     	leaq	0x80(%rsp), %rbp
14006665b:     	movq	%r9, %rbx
14006665e:     	movq	%r8, %r14
140066661:     	movq	%rdx, %rdi
140066664:     	movq	%rcx, %rsi
140066667:     	movq	0x500(%rbp), %r12
14006666e:     	movq	%rbp, %rcx
140066671:     	movl	$0x400, %r8d            # imm = 0x400
140066677:     	xorl	%edx, %edx
140066679:     	callq	0x14024afb2 <.text+0x249fb2>
14006667e:     	movq	0x8(%r12), %r13
140066683:     	movl	$0x3, %eax
140066688:     	cmpq	$0x3, %r13
14006668c:     	ja	0x1400668b5 <.text+0x658b5>
140066692:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
14006669b:     	jne	0x1400668b5 <.text+0x658b5>
1400666a1:     	movq	0x2b750(%rdi,%r13,8), %rdx
1400666a9:     	cmpq	$0x4001, %rdx           # imm = 0x4001
1400666b0:     	jae	0x140066911 <.text+0x65911>
1400666b6:     	movq	0x10(%r12), %rcx
1400666bb:     	movq	0x18(%r12), %r15
1400666c0:     	movq	%r15, %r8
1400666c3:     	movl	$0xb, %eax
1400666c8:     	addq	%rcx, %r8
1400666cb:     	jb	0x1400668b5 <.text+0x658b5>
1400666d1:     	cmpq	$0x400, %r15            # imm = 0x400
1400666d8:     	ja	0x1400668b5 <.text+0x658b5>
1400666de:     	cmpq	%rdx, %r8
1400666e1:     	ja	0x1400668b5 <.text+0x658b5>
1400666e7:     	movq	%r13, %rax
1400666ea:     	shlq	$0xe, %rax
1400666ee:     	leaq	(%rdi,%rax), %rdx
1400666f2:     	addq	$0x1b750, %rdx          # imm = 0x1B750
1400666f9:     	addq	%rcx, %rdx
1400666fc:     	movq	%rbp, %rcx
1400666ff:     	movq	%r15, %r8
140066702:     	callq	0x14024afa0 <.text+0x249fa0>
140066707:     	cmpb	$0x0, 0x508(%rbp)
14006670e:     	je	0x140066726 <.text+0x65726>
140066710:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
140066717:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
140066720:     	jne	0x1400668d0 <.text+0x658d0>
140066726:     	movq	$0x0, 0x480(%rbp)
140066731:     	movq	%rdi, %rcx
140066734:     	callq	0x1400979d0 <.text+0x969d0>
140066739:     	testb	$0x1, %al
14006673b:     	je	0x140066903 <.text+0x65903>
140066741:     	movq	%rdx, %r13
140066744:     	movq	0x518(%rbp), %rdx
14006674b:     	movq	0x510(%rbp), %r8
140066752:     	movzwl	0x4f8(%rbp), %ecx
140066759:     	movzbl	0x4f0(%rbp), %eax
140066760:     	movq	(%r12), %r9
140066764:     	movq	0x480(%rbp), %r10
14006676b:     	movq	%r10, 0x448(%rbp)
140066772:     	movq	0x478(%rbp), %r10
140066779:     	movq	%r10, 0x450(%rbp)
140066780:     	movq	%r9, 0x458(%rbp)
140066787:     	movzbl	0x508(%rbp), %r9d
14006678f:     	movb	%r9b, 0x460(%rbp)
140066796:     	movups	0x60(%r14), %xmm0
14006679b:     	movups	0x6c(%r14), %xmm1
1400667a0:     	movups	%xmm1, 0x40c(%rbp)
1400667a7:     	movaps	%xmm0, 0x400(%rbp)
1400667ae:     	leaq	0x8e(%r14), %r9
1400667b5:     	movq	0x7e(%r14), %r10
1400667b9:     	movq	0x85(%r14), %r11
1400667c0:     	movq	%r11, 0x46f(%rbp)
1400667c7:     	movq	%r10, 0x468(%rbp)
1400667ce:     	leaq	0x468(%rbp), %r10
1400667d5:     	movq	%r10, 0x70(%rsp)
1400667da:     	movq	%rdx, 0x68(%rsp)
1400667df:     	movq	%r8, 0x60(%rsp)
1400667e4:     	movq	%r14, 0x58(%rsp)
1400667e9:     	leaq	0x448(%rbp), %rdx
1400667f0:     	movq	%rdx, 0x50(%rsp)
1400667f5:     	movq	%r15, 0x48(%rsp)
1400667fa:     	movq	%rbp, %rdx
1400667fd:     	movq	%rdx, 0x40(%rsp)
140066802:     	movq	%rbx, 0x38(%rsp)
140066807:     	movq	%r9, 0x30(%rsp)
14006680c:     	movw	%cx, 0x28(%rsp)
140066811:     	movb	%al, 0x20(%rsp)
140066815:     	leaq	0x428(%rbp), %rcx
14006681c:     	leaq	0x400(%rbp), %r8
140066823:     	movq	%rdi, %rdx
140066826:     	movq	%r13, %r9
140066829:     	callq	0x14007ee00 <.text+0x7de00>
14006682e:     	cmpb	$-0x1, 0x428(%rbp)
140066835:     	je	0x140066908 <.text+0x65908>
14006683b:     	cmpb	$0x1, 0x37740(%rdi,%r13)
140066844:     	jne	0x14006689e <.text+0x6589e>
140066846:     	cmpb	$0x0, 0x37760(%rdi,%r13)
14006684f:     	jne	0x14006689e <.text+0x6589e>
140066851:     	movb	$0x0, 0x37740(%rdi,%r13)
14006685a:     	decq	0x37788(%rdi)
140066861:     	leaq	0x37740(%rdi), %rax
140066868:     	movq	$0x0, 0x43610(%rdi,%r13,8)
140066874:     	leaq	(,%r13,8), %rcx
14006687c:     	addq	%r13, %rcx
14006687f:     	leaq	(%rcx,%rcx,2), %rcx
140066883:     	addq	%r13, %rcx
140066886:     	movb	$0x2, 0x36a(%rax,%rcx)
14006688e:     	leaq	(,%r13,2), %rcx
140066896:     	addq	%r13, %rcx
140066899:     	movb	$0x2, 0x5d(%rax,%rcx,8)
14006689e:     	movups	0x428(%rbp), %xmm0
1400668a5:     	movups	0x438(%rbp), %xmm1
1400668ac:     	movups	%xmm1, 0x10(%rsi)
1400668b0:     	movups	%xmm0, (%rsi)
1400668b3:     	jmp	0x1400668bc <.text+0x658bc>
1400668b5:     	movb	$0xa, (%rsi)
1400668b8:     	movq	%rax, 0x8(%rsi)
1400668bc:     	addq	$0x508, %rsp            # imm = 0x508
1400668c3:     	popq	%rbx
1400668c4:     	popq	%rdi
1400668c5:     	popq	%rsi
1400668c6:     	popq	%r12
1400668c8:     	popq	%r13
1400668ca:     	popq	%r14
1400668cc:     	popq	%r15
1400668ce:     	popq	%rbp
1400668cf:     	retq
1400668d0:     	addq	%rdi, %rax
1400668d3:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
1400668d9:     	movq	0x98(%rax), %rax
1400668e0:     	movq	%rax, 0x478(%rbp)
1400668e7:     	movl	$0x1, %eax
1400668ec:     	movq	%rax, 0x480(%rbp)
1400668f3:     	movq	%rdi, %rcx
1400668f6:     	callq	0x1400979d0 <.text+0x969d0>
1400668fb:     	testb	$0x1, %al
1400668fd:     	jne	0x140066741 <.text+0x65741>
140066903:     	movb	$0x9, (%rsi)
140066906:     	jmp	0x1400668bc <.text+0x658bc>
140066908:     	movq	%r13, 0x8(%rsi)
14006690c:     	movb	$-0x1, (%rsi)
14006690f:     	jmp	0x1400668bc <.text+0x658bc>
140066911:     	leaq	0x200328(%rip), %r9     # 0x140266c40
140066918:     	movl	$0x4000, %r8d           # imm = 0x4000
14006691e:     	xorl	%ecx, %ecx
140066920:     	callq	0x14024b9f0 <.text+0x24a9f0>
140066925:     	ud2

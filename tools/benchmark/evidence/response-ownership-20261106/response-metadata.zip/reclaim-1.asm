
D:\CoapticCurrent\response-metadata-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009adc0:     	pushq	%rbp
14009adc1:     	pushq	%r15
14009adc3:     	pushq	%r14
14009adc5:     	pushq	%r13
14009adc7:     	pushq	%r12
14009adc9:     	pushq	%rsi
14009adca:     	pushq	%rdi
14009adcb:     	pushq	%rbx
14009adcc:     	subq	$0x318, %rsp            # imm = 0x318
14009add3:     	leaq	0x80(%rsp), %rbp
14009addb:     	movaps	%xmm7, 0x280(%rbp)
14009ade2:     	movaps	%xmm6, 0x270(%rbp)
14009ade9:     	leaq	0x30(%rcx), %rdx
14009aded:     	xorl	%r8d, %r8d
14009adf0:     	xorl	%r11d, %r11d
14009adf3:     	leaq	(%r11,%r11,4), %r10
14009adf7:     	shlq	$0x6, %r10
14009adfb:     	addq	%rdx, %r10
14009adfe:     	movq	%r11, %r9
14009ae01:     	jmp	0x14009ae24 <.text+0x99e24>
14009ae03:     	nopw	%cs:(%rax,%rax)
14009ae10:     	incq	%r9
14009ae13:     	addq	$0x140, %r10            # imm = 0x140
14009ae1a:     	cmpq	$0x4, %r9
14009ae1e:     	je	0x14009aeae <.text+0x99eae>
14009ae24:     	cmpb	$0x1, 0x510(%rcx,%r9)
14009ae2d:     	jne	0x14009ae10 <.text+0x99e10>
14009ae2f:     	movq	-0x30(%r10), %rsi
14009ae33:     	cmpq	$0x2, %rsi
14009ae37:     	je	0x14009ae10 <.text+0x99e10>
14009ae39:     	movq	(%r10), %r11
14009ae3c:     	cmpl	$0x1, %esi
14009ae3f:     	setne	%bl
14009ae42:     	testq	%r11, %r11
14009ae45:     	sete	%sil
14009ae49:     	orb	%bl, %sil
14009ae4c:     	cmpb	$0x1, %sil
14009ae50:     	je	0x14009ae10 <.text+0x99e10>
14009ae52:     	movq	0x268(%rbp), %rsi
14009ae59:     	cmpq	%rsi, %r11
14009ae5c:     	setae	%bl
14009ae5f:     	testb	%bl, %r8b
14009ae62:     	jne	0x14009ae94 <.text+0x99e94>
14009ae64:     	movq	-0x28(%r10), %rax
14009ae68:     	movd	-0x4(%r10), %xmm6
14009ae6e:     	movzbl	-0x5(%r10), %edi
14009ae73:     	movzbl	-0x6(%r10), %r15d
14009ae78:     	movzwl	-0x8(%r10), %r12d
14009ae7d:     	movl	-0xc(%r10), %r13d
14009ae81:     	movl	-0x10(%r10), %r14d
14009ae85:     	movups	-0x20(%r10), %xmm0
14009ae8a:     	movaps	%xmm0, 0x240(%rbp)
14009ae91:     	movq	%r11, %rsi
14009ae94:     	movq	%rsi, 0x268(%rbp)
14009ae9b:     	leaq	0x1(%r9), %r11
14009ae9f:     	movb	$0x1, %r8b
14009aea2:     	cmpq	$0x3, %r9
14009aea6:     	jb	0x14009adf3 <.text+0x99df3>
14009aeac:     	jmp	0x14009aeb8 <.text+0x99eb8>
14009aeae:     	testb	$0x1, %r8b
14009aeb2:     	je	0x14009b0f8 <.text+0x9a0f8>
14009aeb8:     	cmpq	$0x1, %rax
14009aebc:     	ja	0x14009af14 <.text+0x99f14>
14009aebe:     	cmpb	$0x1, 0x1e80(%rcx,%rax)
14009aec6:     	jne	0x14009af14 <.text+0x99f14>
14009aec8:     	cmpb	$0x0, 0x1e82(%rcx,%rax)
14009aed0:     	jne	0x14009af14 <.text+0x99f14>
14009aed2:     	movb	$0x0, 0x1e80(%rcx,%rax)
14009aeda:     	decq	0x1e78(%rcx)
14009aee1:     	leaq	0x14f8(%rcx), %rdx
14009aee8:     	movq	$0x0, 0x1df8(%rcx,%rax,8)
14009aef4:     	leaq	(%rax,%rax,8), %r8
14009aef8:     	leaq	(%r8,%r8,2), %r8
14009aefc:     	addq	%rax, %r8
14009aeff:     	movb	$0x2, 0x95a(%rdx,%r8)
14009af08:     	leaq	(%rax,%rax,2), %rax
14009af0c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009af14:     	movaps	0x240(%rbp), %xmm0
14009af1b:     	movaps	%xmm0, -0x60(%rbp)
14009af1f:     	movl	%r14d, %esi
14009af22:     	movl	%r14d, -0x50(%rbp)
14009af26:     	movl	%r13d, %r14d
14009af29:     	movl	%r13d, -0x4c(%rbp)
14009af2d:     	movl	%r12d, %r13d
14009af30:     	movw	%r12w, -0x48(%rbp)
14009af35:     	movl	%r15d, %r12d
14009af38:     	movb	%r15b, -0x46(%rbp)
14009af3c:     	movl	%edi, %r15d
14009af3f:     	movb	%dil, -0x45(%rbp)
14009af43:     	movd	%xmm6, %edi
14009af47:     	movd	%xmm6, -0x44(%rbp)
14009af4c:     	leaq	-0x60(%rbp), %rdx
14009af50:     	movq	%rcx, 0x260(%rbp)
14009af57:     	callq	0x140210540 <.text+0x20f540>
14009af5c:     	xorps	%xmm7, %xmm7
14009af5f:     	movaps	%xmm7, 0x250(%rbp)
14009af66:     	movb	$0x0, 0x222(%rbp)
14009af6d:     	movw	%di, 0x220(%rbp)
14009af74:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009af7d:     	movq	$0x0, 0x223(%rbp)
14009af88:     	movq	$0x8, 0x200(%rbp)
14009af93:     	movq	$0x0, 0x208(%rbp)
14009af9e:     	movq	$0x1, 0x210(%rbp)
14009afa9:     	movq	$0x0, 0x218(%rbp)
14009afb4:     	leaq	0x230(%rbp), %rcx
14009afbb:     	leaq	0x200(%rbp), %rdx
14009afc2:     	leaq	0x250(%rbp), %r8
14009afc9:     	movl	$0x10, %r9d
14009afcf:     	callq	0x14010d6e0 <.text+0x10c6e0>
14009afd4:     	cmpb	$0x0, 0x230(%rbp)
14009afdb:     	jne	0x14009b0f4 <.text+0x9a0f4>
14009afe1:     	movq	0x238(%rbp), %rdi
14009afe8:     	movaps	%xmm7, 0xe0(%rbp)
14009afef:     	movaps	%xmm7, 0xf0(%rbp)
14009aff6:     	movaps	%xmm7, 0x100(%rbp)
14009affd:     	movaps	%xmm7, 0x110(%rbp)
14009b004:     	movaps	%xmm7, 0x120(%rbp)
14009b00b:     	movaps	%xmm7, 0x130(%rbp)
14009b012:     	movaps	%xmm7, 0x140(%rbp)
14009b019:     	movaps	%xmm7, 0x150(%rbp)
14009b020:     	movaps	%xmm7, 0x160(%rbp)
14009b027:     	movaps	%xmm7, 0x170(%rbp)
14009b02e:     	movaps	%xmm7, 0x180(%rbp)
14009b035:     	movaps	%xmm7, 0x190(%rbp)
14009b03c:     	movaps	%xmm7, 0x1a0(%rbp)
14009b043:     	movaps	%xmm7, 0x1b0(%rbp)
14009b04a:     	movaps	%xmm7, 0x1c0(%rbp)
14009b051:     	movaps	%xmm7, 0x1d0(%rbp)
14009b058:     	movaps	0x240(%rbp), %xmm0
14009b05f:     	movups	%xmm0, 0x1f0(%rbp)
14009b066:     	cmpq	$0x11, %rdi
14009b06a:     	jae	0x14009b11c <.text+0x9a11c>
14009b070:     	leaq	0xe0(%rbp), %rbx
14009b077:     	leaq	0x250(%rbp), %rdx
14009b07e:     	movq	%rbx, %rcx
14009b081:     	movq	%rdi, %r8
14009b084:     	callq	0x14024afa0 <.text+0x249fa0>
14009b089:     	movw	%di, 0x1e0(%rbp)
14009b090:     	movq	$0x0, -0x60(%rbp)
14009b098:     	movups	0x1e8(%rbp), %xmm0
14009b09f:     	movups	%xmm0, -0x58(%rbp)
14009b0a3:     	movq	0x1f8(%rbp), %rax
14009b0aa:     	movq	%rax, -0x48(%rbp)
14009b0ae:     	movl	%esi, -0x40(%rbp)
14009b0b1:     	movl	%r14d, -0x3c(%rbp)
14009b0b5:     	movw	%r13w, -0x38(%rbp)
14009b0ba:     	movb	%r12b, -0x36(%rbp)
14009b0be:     	movb	%r15b, -0x35(%rbp)
14009b0c2:     	movd	%xmm6, -0x34(%rbp)
14009b0c7:     	movq	0x268(%rbp), %rax
14009b0ce:     	movq	%rax, -0x30(%rbp)
14009b0d2:     	leaq	-0x28(%rbp), %rcx
14009b0d6:     	movl	$0x108, %r8d            # imm = 0x108
14009b0dc:     	movq	%rbx, %rdx
14009b0df:     	callq	0x14024afa0 <.text+0x249fa0>
14009b0e4:     	leaq	-0x60(%rbp), %rdx
14009b0e8:     	movq	0x260(%rbp), %rcx
14009b0ef:     	callq	0x1402102b0 <.text+0x20f2b0>
14009b0f4:     	movb	$0x1, %al
14009b0f6:     	jmp	0x14009b0fa <.text+0x9a0fa>
14009b0f8:     	xorl	%eax, %eax
14009b0fa:     	movaps	0x270(%rbp), %xmm6
14009b101:     	movaps	0x280(%rbp), %xmm7
14009b108:     	addq	$0x318, %rsp            # imm = 0x318
14009b10f:     	popq	%rbx
14009b110:     	popq	%rdi
14009b111:     	popq	%rsi
14009b112:     	popq	%r12
14009b114:     	popq	%r13
14009b116:     	popq	%r14
14009b118:     	popq	%r15
14009b11a:     	popq	%rbp
14009b11b:     	retq
14009b11c:     	leaq	0x1c8a45(%rip), %r9     # 0x140263b68
14009b123:     	movl	$0x10, %r8d
14009b129:     	xorl	%ecx, %ecx
14009b12b:     	movq	%rdi, %rdx
14009b12e:     	callq	0x14024b9f0 <.text+0x24a9f0>
14009b133:     	ud2

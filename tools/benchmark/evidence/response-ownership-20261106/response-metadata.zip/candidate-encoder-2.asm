
D:\CoapticCurrent\response-metadata-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140066930:     	pushq	%rbp
140066931:     	pushq	%r15
140066933:     	pushq	%r14
140066935:     	pushq	%r13
140066937:     	pushq	%r12
140066939:     	pushq	%rsi
14006693a:     	pushq	%rdi
14006693b:     	pushq	%rbx
14006693c:     	subq	$0x4f8, %rsp            # imm = 0x4F8
140066943:     	leaq	0x80(%rsp), %rbp
14006694b:     	movq	%r9, %rbx
14006694e:     	movq	%r8, %r14
140066951:     	movq	%rdx, %rdi
140066954:     	movq	%rcx, %rsi
140066957:     	movq	0x4f0(%rbp), %r12
14006695e:     	leaq	-0x10(%rbp), %rcx
140066962:     	movl	$0x400, %r8d            # imm = 0x400
140066968:     	xorl	%edx, %edx
14006696a:     	callq	0x14024afb2 <.text+0x249fb2>
14006696f:     	movq	0x8(%r12), %r13
140066974:     	movl	$0x3, %eax
140066979:     	cmpq	$0x3, %r13
14006697d:     	ja	0x140066b9c <.text+0x65b9c>
140066983:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
14006698c:     	jne	0x140066b9c <.text+0x65b9c>
140066992:     	movq	0x2b750(%rdi,%r13,8), %rdx
14006699a:     	cmpq	$0x4001, %rdx           # imm = 0x4001
1400669a1:     	jae	0x140066bf8 <.text+0x65bf8>
1400669a7:     	movq	0x10(%r12), %rcx
1400669ac:     	movq	0x18(%r12), %r15
1400669b1:     	movq	%r15, %r8
1400669b4:     	movl	$0xb, %eax
1400669b9:     	addq	%rcx, %r8
1400669bc:     	jb	0x140066b9c <.text+0x65b9c>
1400669c2:     	cmpq	$0x400, %r15            # imm = 0x400
1400669c9:     	ja	0x140066b9c <.text+0x65b9c>
1400669cf:     	cmpq	%rdx, %r8
1400669d2:     	ja	0x140066b9c <.text+0x65b9c>
1400669d8:     	movq	%r13, %rax
1400669db:     	shlq	$0xe, %rax
1400669df:     	leaq	(%rdi,%rax), %rdx
1400669e3:     	addq	$0x1b750, %rdx          # imm = 0x1B750
1400669ea:     	addq	%rcx, %rdx
1400669ed:     	leaq	-0x10(%rbp), %rcx
1400669f1:     	movq	%r15, %r8
1400669f4:     	callq	0x14024afa0 <.text+0x249fa0>
1400669f9:     	cmpb	$0x0, 0x4f8(%rbp)
140066a00:     	je	0x140066a18 <.text+0x65a18>
140066a02:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
140066a09:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
140066a12:     	jne	0x140066bb7 <.text+0x65bb7>
140066a18:     	movq	$0x0, 0x470(%rbp)
140066a23:     	movq	%rdi, %rcx
140066a26:     	callq	0x1400979d0 <.text+0x969d0>
140066a2b:     	testb	$0x1, %al
140066a2d:     	je	0x140066bea <.text+0x65bea>
140066a33:     	movq	%rdx, %r13
140066a36:     	movq	0x500(%rbp), %rdx
140066a3d:     	movzwl	0x4e8(%rbp), %ecx
140066a44:     	movzbl	0x4e0(%rbp), %eax
140066a4b:     	movq	(%r12), %r8
140066a4f:     	movq	0x470(%rbp), %r9
140066a56:     	movq	%r9, 0x438(%rbp)
140066a5d:     	movq	0x468(%rbp), %r9
140066a64:     	movq	%r9, 0x440(%rbp)
140066a6b:     	movq	%r8, 0x448(%rbp)
140066a72:     	movzbl	0x4f8(%rbp), %r8d
140066a7a:     	movb	%r8b, 0x450(%rbp)
140066a81:     	movups	0x60(%r14), %xmm0
140066a86:     	movups	0x6c(%r14), %xmm1
140066a8b:     	movups	%xmm1, 0x3fc(%rbp)
140066a92:     	movaps	%xmm0, 0x3f0(%rbp)
140066a99:     	leaq	0x8e(%r14), %r8
140066aa0:     	movq	0x7e(%r14), %r9
140066aa4:     	movq	0x85(%r14), %r10
140066aab:     	movq	%r10, 0x45f(%rbp)
140066ab2:     	movq	%r9, 0x458(%rbp)
140066ab9:     	leaq	0x458(%rbp), %r9
140066ac0:     	movq	%r9, 0x68(%rsp)
140066ac5:     	movq	%rdx, 0x60(%rsp)
140066aca:     	movq	%r14, 0x58(%rsp)
140066acf:     	leaq	0x438(%rbp), %rdx
140066ad6:     	movq	%rdx, 0x50(%rsp)
140066adb:     	movq	%r15, 0x48(%rsp)
140066ae0:     	leaq	-0x10(%rbp), %rdx
140066ae4:     	movq	%rdx, 0x40(%rsp)
140066ae9:     	movq	%rbx, 0x38(%rsp)
140066aee:     	movq	%r8, 0x30(%rsp)
140066af3:     	movw	%cx, 0x28(%rsp)
140066af8:     	movb	%al, 0x20(%rsp)
140066afc:     	leaq	0x418(%rbp), %rcx
140066b03:     	leaq	0x3f0(%rbp), %r8
140066b0a:     	movq	%rdi, %rdx
140066b0d:     	movq	%r13, %r9
140066b10:     	callq	0x1400805f0 <.text+0x7f5f0>
140066b15:     	cmpb	$-0x1, 0x418(%rbp)
140066b1c:     	je	0x140066bef <.text+0x65bef>
140066b22:     	cmpb	$0x1, 0x37740(%rdi,%r13)
140066b2b:     	jne	0x140066b85 <.text+0x65b85>
140066b2d:     	cmpb	$0x0, 0x37760(%rdi,%r13)
140066b36:     	jne	0x140066b85 <.text+0x65b85>
140066b38:     	movb	$0x0, 0x37740(%rdi,%r13)
140066b41:     	decq	0x37788(%rdi)
140066b48:     	leaq	0x37740(%rdi), %rax
140066b4f:     	movq	$0x0, 0x43610(%rdi,%r13,8)
140066b5b:     	leaq	(,%r13,8), %rcx
140066b63:     	addq	%r13, %rcx
140066b66:     	leaq	(%rcx,%rcx,2), %rcx
140066b6a:     	addq	%r13, %rcx
140066b6d:     	movb	$0x2, 0x36a(%rax,%rcx)
140066b75:     	leaq	(,%r13,2), %rcx
140066b7d:     	addq	%r13, %rcx
140066b80:     	movb	$0x2, 0x5d(%rax,%rcx,8)
140066b85:     	movups	0x418(%rbp), %xmm0
140066b8c:     	movups	0x428(%rbp), %xmm1
140066b93:     	movups	%xmm1, 0x10(%rsi)
140066b97:     	movups	%xmm0, (%rsi)
140066b9a:     	jmp	0x140066ba3 <.text+0x65ba3>
140066b9c:     	movb	$0xa, (%rsi)
140066b9f:     	movq	%rax, 0x8(%rsi)
140066ba3:     	addq	$0x4f8, %rsp            # imm = 0x4F8
140066baa:     	popq	%rbx
140066bab:     	popq	%rdi
140066bac:     	popq	%rsi
140066bad:     	popq	%r12
140066baf:     	popq	%r13
140066bb1:     	popq	%r14
140066bb3:     	popq	%r15
140066bb5:     	popq	%rbp
140066bb6:     	retq
140066bb7:     	addq	%rdi, %rax
140066bba:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
140066bc0:     	movq	0x98(%rax), %rax
140066bc7:     	movq	%rax, 0x468(%rbp)
140066bce:     	movl	$0x1, %eax
140066bd3:     	movq	%rax, 0x470(%rbp)
140066bda:     	movq	%rdi, %rcx
140066bdd:     	callq	0x1400979d0 <.text+0x969d0>
140066be2:     	testb	$0x1, %al
140066be4:     	jne	0x140066a33 <.text+0x65a33>
140066bea:     	movb	$0x9, (%rsi)
140066bed:     	jmp	0x140066ba3 <.text+0x65ba3>
140066bef:     	movq	%r13, 0x8(%rsi)
140066bf3:     	movb	$-0x1, (%rsi)
140066bf6:     	jmp	0x140066ba3 <.text+0x65ba3>
140066bf8:     	leaq	0x200041(%rip), %r9     # 0x140266c40
140066bff:     	movl	$0x4000, %r8d           # imm = 0x4000
140066c05:     	xorl	%ecx, %ecx
140066c07:     	callq	0x14024b9f0 <.text+0x24a9f0>
140066c0c:     	ud2

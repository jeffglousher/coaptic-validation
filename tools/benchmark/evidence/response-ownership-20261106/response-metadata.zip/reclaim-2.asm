
D:\CoapticCurrent\response-metadata-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009b140:     	pushq	%rbp
14009b141:     	pushq	%r15
14009b143:     	pushq	%r14
14009b145:     	pushq	%r13
14009b147:     	pushq	%r12
14009b149:     	pushq	%rsi
14009b14a:     	pushq	%rdi
14009b14b:     	pushq	%rbx
14009b14c:     	subq	$0x318, %rsp            # imm = 0x318
14009b153:     	leaq	0x80(%rsp), %rbp
14009b15b:     	movaps	%xmm7, 0x280(%rbp)
14009b162:     	movaps	%xmm6, 0x270(%rbp)
14009b169:     	leaq	0x30(%rcx), %rdx
14009b16d:     	xorl	%r8d, %r8d
14009b170:     	xorl	%r11d, %r11d
14009b173:     	leaq	(%r11,%r11,4), %r10
14009b177:     	shlq	$0x6, %r10
14009b17b:     	addq	%rdx, %r10
14009b17e:     	movq	%r11, %r9
14009b181:     	jmp	0x14009b1a4 <.text+0x9a1a4>
14009b183:     	nopw	%cs:(%rax,%rax)
14009b190:     	incq	%r9
14009b193:     	addq	$0x140, %r10            # imm = 0x140
14009b19a:     	cmpq	$0x4, %r9
14009b19e:     	je	0x14009b22e <.text+0x9a22e>
14009b1a4:     	cmpb	$0x1, 0x510(%rcx,%r9)
14009b1ad:     	jne	0x14009b190 <.text+0x9a190>
14009b1af:     	movq	-0x30(%r10), %rsi
14009b1b3:     	cmpq	$0x2, %rsi
14009b1b7:     	je	0x14009b190 <.text+0x9a190>
14009b1b9:     	movq	(%r10), %r11
14009b1bc:     	cmpl	$0x1, %esi
14009b1bf:     	setne	%bl
14009b1c2:     	testq	%r11, %r11
14009b1c5:     	sete	%sil
14009b1c9:     	orb	%bl, %sil
14009b1cc:     	cmpb	$0x1, %sil
14009b1d0:     	je	0x14009b190 <.text+0x9a190>
14009b1d2:     	movq	0x268(%rbp), %rsi
14009b1d9:     	cmpq	%rsi, %r11
14009b1dc:     	setae	%bl
14009b1df:     	testb	%bl, %r8b
14009b1e2:     	jne	0x14009b214 <.text+0x9a214>
14009b1e4:     	movq	-0x28(%r10), %rax
14009b1e8:     	movd	-0x4(%r10), %xmm6
14009b1ee:     	movzbl	-0x5(%r10), %edi
14009b1f3:     	movzbl	-0x6(%r10), %r15d
14009b1f8:     	movzwl	-0x8(%r10), %r12d
14009b1fd:     	movl	-0xc(%r10), %r13d
14009b201:     	movl	-0x10(%r10), %r14d
14009b205:     	movups	-0x20(%r10), %xmm0
14009b20a:     	movaps	%xmm0, 0x240(%rbp)
14009b211:     	movq	%r11, %rsi
14009b214:     	movq	%rsi, 0x268(%rbp)
14009b21b:     	leaq	0x1(%r9), %r11
14009b21f:     	movb	$0x1, %r8b
14009b222:     	cmpq	$0x3, %r9
14009b226:     	jb	0x14009b173 <.text+0x9a173>
14009b22c:     	jmp	0x14009b238 <.text+0x9a238>
14009b22e:     	testb	$0x1, %r8b
14009b232:     	je	0x14009b478 <.text+0x9a478>
14009b238:     	cmpq	$0x1, %rax
14009b23c:     	ja	0x14009b294 <.text+0x9a294>
14009b23e:     	cmpb	$0x1, 0x4420(%rcx,%rax)
14009b246:     	jne	0x14009b294 <.text+0x9a294>
14009b248:     	cmpb	$0x0, 0x4422(%rcx,%rax)
14009b250:     	jne	0x14009b294 <.text+0x9a294>
14009b252:     	movb	$0x0, 0x4420(%rcx,%rax)
14009b25a:     	decq	0x4418(%rcx)
14009b261:     	leaq	0x3a98(%rcx), %rdx
14009b268:     	movq	$0x0, 0x4398(%rcx,%rax,8)
14009b274:     	leaq	(%rax,%rax,8), %r8
14009b278:     	leaq	(%r8,%r8,2), %r8
14009b27c:     	addq	%rax, %r8
14009b27f:     	movb	$0x2, 0x95a(%rdx,%r8)
14009b288:     	leaq	(%rax,%rax,2), %rax
14009b28c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009b294:     	movaps	0x240(%rbp), %xmm0
14009b29b:     	movaps	%xmm0, -0x60(%rbp)
14009b29f:     	movl	%r14d, %esi
14009b2a2:     	movl	%r14d, -0x50(%rbp)
14009b2a6:     	movl	%r13d, %r14d
14009b2a9:     	movl	%r13d, -0x4c(%rbp)
14009b2ad:     	movl	%r12d, %r13d
14009b2b0:     	movw	%r12w, -0x48(%rbp)
14009b2b5:     	movl	%r15d, %r12d
14009b2b8:     	movb	%r15b, -0x46(%rbp)
14009b2bc:     	movl	%edi, %r15d
14009b2bf:     	movb	%dil, -0x45(%rbp)
14009b2c3:     	movd	%xmm6, %edi
14009b2c7:     	movd	%xmm6, -0x44(%rbp)
14009b2cc:     	leaq	-0x60(%rbp), %rdx
14009b2d0:     	movq	%rcx, 0x260(%rbp)
14009b2d7:     	callq	0x140210540 <.text+0x20f540>
14009b2dc:     	xorps	%xmm7, %xmm7
14009b2df:     	movaps	%xmm7, 0x250(%rbp)
14009b2e6:     	movb	$0x0, 0x222(%rbp)
14009b2ed:     	movw	%di, 0x220(%rbp)
14009b2f4:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009b2fd:     	movq	$0x0, 0x223(%rbp)
14009b308:     	movq	$0x8, 0x200(%rbp)
14009b313:     	movq	$0x0, 0x208(%rbp)
14009b31e:     	movq	$0x1, 0x210(%rbp)
14009b329:     	movq	$0x0, 0x218(%rbp)
14009b334:     	leaq	0x230(%rbp), %rcx
14009b33b:     	leaq	0x200(%rbp), %rdx
14009b342:     	leaq	0x250(%rbp), %r8
14009b349:     	movl	$0x10, %r9d
14009b34f:     	callq	0x14010d6e0 <.text+0x10c6e0>
14009b354:     	cmpb	$0x0, 0x230(%rbp)
14009b35b:     	jne	0x14009b474 <.text+0x9a474>
14009b361:     	movq	0x238(%rbp), %rdi
14009b368:     	movaps	%xmm7, 0xe0(%rbp)
14009b36f:     	movaps	%xmm7, 0xf0(%rbp)
14009b376:     	movaps	%xmm7, 0x100(%rbp)
14009b37d:     	movaps	%xmm7, 0x110(%rbp)
14009b384:     	movaps	%xmm7, 0x120(%rbp)
14009b38b:     	movaps	%xmm7, 0x130(%rbp)
14009b392:     	movaps	%xmm7, 0x140(%rbp)
14009b399:     	movaps	%xmm7, 0x150(%rbp)
14009b3a0:     	movaps	%xmm7, 0x160(%rbp)
14009b3a7:     	movaps	%xmm7, 0x170(%rbp)
14009b3ae:     	movaps	%xmm7, 0x180(%rbp)
14009b3b5:     	movaps	%xmm7, 0x190(%rbp)
14009b3bc:     	movaps	%xmm7, 0x1a0(%rbp)
14009b3c3:     	movaps	%xmm7, 0x1b0(%rbp)
14009b3ca:     	movaps	%xmm7, 0x1c0(%rbp)
14009b3d1:     	movaps	%xmm7, 0x1d0(%rbp)
14009b3d8:     	movaps	0x240(%rbp), %xmm0
14009b3df:     	movups	%xmm0, 0x1f0(%rbp)
14009b3e6:     	cmpq	$0x11, %rdi
14009b3ea:     	jae	0x14009b49c <.text+0x9a49c>
14009b3f0:     	leaq	0xe0(%rbp), %rbx
14009b3f7:     	leaq	0x250(%rbp), %rdx
14009b3fe:     	movq	%rbx, %rcx
14009b401:     	movq	%rdi, %r8
14009b404:     	callq	0x14024afa0 <.text+0x249fa0>
14009b409:     	movw	%di, 0x1e0(%rbp)
14009b410:     	movq	$0x0, -0x60(%rbp)
14009b418:     	movups	0x1e8(%rbp), %xmm0
14009b41f:     	movups	%xmm0, -0x58(%rbp)
14009b423:     	movq	0x1f8(%rbp), %rax
14009b42a:     	movq	%rax, -0x48(%rbp)
14009b42e:     	movl	%esi, -0x40(%rbp)
14009b431:     	movl	%r14d, -0x3c(%rbp)
14009b435:     	movw	%r13w, -0x38(%rbp)
14009b43a:     	movb	%r12b, -0x36(%rbp)
14009b43e:     	movb	%r15b, -0x35(%rbp)
14009b442:     	movd	%xmm6, -0x34(%rbp)
14009b447:     	movq	0x268(%rbp), %rax
14009b44e:     	movq	%rax, -0x30(%rbp)
14009b452:     	leaq	-0x28(%rbp), %rcx
14009b456:     	movl	$0x108, %r8d            # imm = 0x108
14009b45c:     	movq	%rbx, %rdx
14009b45f:     	callq	0x14024afa0 <.text+0x249fa0>
14009b464:     	leaq	-0x60(%rbp), %rdx
14009b468:     	movq	0x260(%rbp), %rcx
14009b46f:     	callq	0x1402102b0 <.text+0x20f2b0>
14009b474:     	movb	$0x1, %al
14009b476:     	jmp	0x14009b47a <.text+0x9a47a>
14009b478:     	xorl	%eax, %eax
14009b47a:     	movaps	0x270(%rbp), %xmm6
14009b481:     	movaps	0x280(%rbp), %xmm7
14009b488:     	addq	$0x318, %rsp            # imm = 0x318
14009b48f:     	popq	%rbx
14009b490:     	popq	%rdi
14009b491:     	popq	%rsi
14009b492:     	popq	%r12
14009b494:     	popq	%r13
14009b496:     	popq	%r14
14009b498:     	popq	%r15
14009b49a:     	popq	%rbp
14009b49b:     	retq
14009b49c:     	leaq	0x1c86c5(%rip), %r9     # 0x140263b68
14009b4a3:     	movl	$0x10, %r8d
14009b4a9:     	xorl	%ecx, %ecx
14009b4ab:     	movq	%rdi, %rdx
14009b4ae:     	callq	0x14024b9f0 <.text+0x24a9f0>
14009b4b3:     	ud2


D:\CoapticCurrent\response-metadata-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009b4c0:     	pushq	%rbp
14009b4c1:     	pushq	%r15
14009b4c3:     	pushq	%r14
14009b4c5:     	pushq	%r13
14009b4c7:     	pushq	%r12
14009b4c9:     	pushq	%rsi
14009b4ca:     	pushq	%rdi
14009b4cb:     	pushq	%rbx
14009b4cc:     	subq	$0x308, %rsp            # imm = 0x308
14009b4d3:     	leaq	0x80(%rsp), %rbp
14009b4db:     	movaps	%xmm7, 0x270(%rbp)
14009b4e2:     	movaps	%xmm6, 0x260(%rbp)
14009b4e9:     	leaq	0x5000(%rcx), %rax
14009b4f0:     	leaq	0x30(%rcx), %r8
14009b4f4:     	xorl	%r9d, %r9d
14009b4f7:     	xorl	%esi, %esi
14009b4f9:     	leaq	(%rsi,%rsi,4), %r11
14009b4fd:     	shlq	$0x6, %r11
14009b501:     	addq	%r8, %r11
14009b504:     	movq	%rsi, %r10
14009b507:     	jmp	0x14009b524 <.text+0x9a524>
14009b509:     	nopl	(%rax)
14009b510:     	incq	%r10
14009b513:     	addq	$0x140, %r11            # imm = 0x140
14009b51a:     	cmpq	$0x40, %r10
14009b51e:     	je	0x14009b5be <.text+0x9a5be>
14009b524:     	cmpb	$0x1, 0x5000(%rcx,%r10)
14009b52d:     	jne	0x14009b510 <.text+0x9a510>
14009b52f:     	movq	-0x30(%r11), %rdi
14009b533:     	cmpq	$0x2, %rdi
14009b537:     	je	0x14009b510 <.text+0x9a510>
14009b539:     	movq	(%r11), %rsi
14009b53c:     	cmpl	$0x1, %edi
14009b53f:     	setne	%bl
14009b542:     	testq	%rsi, %rsi
14009b545:     	sete	%dil
14009b549:     	orb	%bl, %dil
14009b54c:     	cmpb	$0x1, %dil
14009b550:     	je	0x14009b510 <.text+0x9a510>
14009b552:     	movq	0x250(%rbp), %rdi
14009b559:     	cmpq	%rdi, %rsi
14009b55c:     	setae	%bl
14009b55f:     	testb	%bl, %r9b
14009b562:     	jne	0x14009b5a4 <.text+0x9a5a4>
14009b564:     	movd	-0x4(%r11), %xmm6
14009b56a:     	movzbl	-0x5(%r11), %edx
14009b56f:     	movb	%dl, 0x25f(%rbp)
14009b575:     	movzbl	-0x6(%r11), %r15d
14009b57a:     	movzwl	-0x8(%r11), %r12d
14009b57f:     	movl	-0xc(%r11), %r13d
14009b583:     	movl	-0x10(%r11), %r14d
14009b587:     	movq	-0x18(%r11), %rdx
14009b58b:     	movq	%rdx, 0x248(%rbp)
14009b592:     	movq	-0x28(%r11), %rdx
14009b596:     	movq	-0x20(%r11), %r9
14009b59a:     	movq	%r9, 0x240(%rbp)
14009b5a1:     	movq	%rsi, %rdi
14009b5a4:     	movq	%rdi, 0x250(%rbp)
14009b5ab:     	leaq	0x1(%r10), %rsi
14009b5af:     	movb	$0x1, %r9b
14009b5b2:     	cmpq	$0x3f, %r10
14009b5b6:     	jb	0x14009b4f9 <.text+0x9a4f9>
14009b5bc:     	jmp	0x14009b5c8 <.text+0x9a5c8>
14009b5be:     	testb	$0x1, %r9b
14009b5c2:     	je	0x14009b840 <.text+0x9a840>
14009b5c8:     	cmpq	$0x1f, %rdx
14009b5cc:     	ja	0x14009b61f <.text+0x9a61f>
14009b5ce:     	leaq	0x37740(%rcx), %r8
14009b5d5:     	cmpb	$0x1, (%r8,%rdx)
14009b5da:     	jne	0x14009b61f <.text+0x9a61f>
14009b5dc:     	cmpb	$0x0, 0x37760(%rcx,%rdx)
14009b5e4:     	jne	0x14009b61f <.text+0x9a61f>
14009b5e6:     	movb	$0x0, 0x37740(%rcx,%rdx)
14009b5ee:     	decq	0x37788(%rcx)
14009b5f5:     	movq	$0x0, 0x43610(%rcx,%rdx,8)
14009b601:     	leaq	(%rdx,%rdx,8), %r9
14009b605:     	leaq	(%r9,%r9,2), %r9
14009b609:     	addq	%rdx, %r9
14009b60c:     	movb	$0x2, 0x36a(%r8,%r9)
14009b615:     	leaq	(%rdx,%rdx,2), %rdx
14009b619:     	movb	$0x2, 0x5d(%r8,%rdx,8)
14009b61f:     	movd	%xmm6, %edx
14009b623:     	movl	$0x2c, %r8d
14009b629:     	movq	0x240(%rbp), %r11
14009b630:     	movq	0x248(%rbp), %rsi
14009b637:     	jmp	0x14009b653 <.text+0x9a653>
14009b639:     	nopl	(%rax)
14009b640:     	incq	%rax
14009b643:     	addq	$0x140, %r8             # imm = 0x140
14009b64a:     	cmpq	$0x502c, %r8            # imm = 0x502C
14009b651:     	je	0x14009b6ac <.text+0x9a6ac>
14009b653:     	cmpb	$0x1, (%rax)
14009b656:     	jne	0x14009b640 <.text+0x9a640>
14009b658:     	cmpl	$0x2, -0x2c(%rcx,%r8)
14009b65e:     	je	0x14009b640 <.text+0x9a640>
14009b660:     	cmpw	%dx, (%rcx,%r8)
14009b665:     	jne	0x14009b640 <.text+0x9a640>
14009b667:     	cmpl	%r14d, -0xc(%rcx,%r8)
14009b66c:     	jne	0x14009b640 <.text+0x9a640>
14009b66e:     	cmpl	%r13d, -0x8(%rcx,%r8)
14009b673:     	jne	0x14009b640 <.text+0x9a640>
14009b675:     	cmpw	%r12w, -0x4(%rcx,%r8)
14009b67b:     	jne	0x14009b640 <.text+0x9a640>
14009b67d:     	cmpb	%r15b, -0x2(%rcx,%r8)
14009b682:     	jne	0x14009b640 <.text+0x9a640>
14009b684:     	movq	-0x1c(%rcx,%r8), %r9
14009b689:     	xorq	%r11, %r9
14009b68c:     	movq	-0x14(%rcx,%r8), %r10
14009b691:     	xorq	%rsi, %r10
14009b694:     	orq	%r9, %r10
14009b697:     	jne	0x14009b640 <.text+0x9a640>
14009b699:     	movb	$0x0, (%rax)
14009b69c:     	decq	0x5048(%rcx)
14009b6a3:     	movq	$0x2, -0x2c(%rcx,%r8)
14009b6ac:     	movq	%rcx, %rsi
14009b6af:     	xorps	%xmm7, %xmm7
14009b6b2:     	movaps	%xmm7, 0x230(%rbp)
14009b6b9:     	movb	$0x0, 0x212(%rbp)
14009b6c0:     	movw	%dx, 0x210(%rbp)
14009b6c7:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
14009b6d0:     	movq	$0x0, 0x213(%rbp)
14009b6db:     	movq	$0x8, 0x1f0(%rbp)
14009b6e6:     	movq	$0x0, 0x1f8(%rbp)
14009b6f1:     	movq	$0x1, 0x200(%rbp)
14009b6fc:     	movq	$0x0, 0x208(%rbp)
14009b707:     	leaq	0x220(%rbp), %rcx
14009b70e:     	leaq	0x1f0(%rbp), %rdx
14009b715:     	leaq	0x230(%rbp), %r8
14009b71c:     	movl	$0x10, %r9d
14009b722:     	callq	0x14010d6e0 <.text+0x10c6e0>
14009b727:     	cmpb	$0x0, 0x220(%rbp)
14009b72e:     	jne	0x14009b83c <.text+0x9a83c>
14009b734:     	movq	0x228(%rbp), %rdi
14009b73b:     	movaps	%xmm7, 0xe0(%rbp)
14009b742:     	movaps	%xmm7, 0xf0(%rbp)
14009b749:     	movaps	%xmm7, 0x100(%rbp)
14009b750:     	movaps	%xmm7, 0x110(%rbp)
14009b757:     	movaps	%xmm7, 0x120(%rbp)
14009b75e:     	movaps	%xmm7, 0x130(%rbp)
14009b765:     	movaps	%xmm7, 0x140(%rbp)
14009b76c:     	movaps	%xmm7, 0x150(%rbp)
14009b773:     	movaps	%xmm7, 0x160(%rbp)
14009b77a:     	movaps	%xmm7, 0x170(%rbp)
14009b781:     	movaps	%xmm7, 0x180(%rbp)
14009b788:     	movaps	%xmm7, 0x190(%rbp)
14009b78f:     	movaps	%xmm7, 0x1a0(%rbp)
14009b796:     	movaps	%xmm7, 0x1b0(%rbp)
14009b79d:     	movaps	%xmm7, 0x1c0(%rbp)
14009b7a4:     	movaps	%xmm7, 0x1d0(%rbp)
14009b7ab:     	cmpq	$0x11, %rdi
14009b7af:     	jae	0x14009b864 <.text+0x9a864>
14009b7b5:     	leaq	0xe0(%rbp), %rbx
14009b7bc:     	leaq	0x230(%rbp), %rdx
14009b7c3:     	movq	%rbx, %rcx
14009b7c6:     	movq	%rdi, %r8
14009b7c9:     	callq	0x14024afa0 <.text+0x249fa0>
14009b7ce:     	movw	%di, 0x1e0(%rbp)
14009b7d5:     	movq	$0x0, -0x60(%rbp)
14009b7dd:     	movq	0x248(%rbp), %rax
14009b7e4:     	movq	%rax, -0x48(%rbp)
14009b7e8:     	movq	0x240(%rbp), %rax
14009b7ef:     	movq	%rax, -0x50(%rbp)
14009b7f3:     	movl	%r14d, -0x40(%rbp)
14009b7f7:     	movl	%r13d, -0x3c(%rbp)
14009b7fb:     	movw	%r12w, -0x38(%rbp)
14009b800:     	movb	%r15b, -0x36(%rbp)
14009b804:     	movzbl	0x25f(%rbp), %eax
14009b80b:     	movb	%al, -0x35(%rbp)
14009b80e:     	movd	%xmm6, -0x34(%rbp)
14009b813:     	movq	0x250(%rbp), %rax
14009b81a:     	movq	%rax, -0x30(%rbp)
14009b81e:     	leaq	-0x28(%rbp), %rcx
14009b822:     	movl	$0x108, %r8d            # imm = 0x108
14009b828:     	movq	%rbx, %rdx
14009b82b:     	callq	0x14024afa0 <.text+0x249fa0>
14009b830:     	leaq	-0x60(%rbp), %rdx
14009b834:     	movq	%rsi, %rcx
14009b837:     	callq	0x140210110 <.text+0x20f110>
14009b83c:     	movb	$0x1, %al
14009b83e:     	jmp	0x14009b842 <.text+0x9a842>
14009b840:     	xorl	%eax, %eax
14009b842:     	movaps	0x260(%rbp), %xmm6
14009b849:     	movaps	0x270(%rbp), %xmm7
14009b850:     	addq	$0x308, %rsp            # imm = 0x308
14009b857:     	popq	%rbx
14009b858:     	popq	%rdi
14009b859:     	popq	%rsi
14009b85a:     	popq	%r12
14009b85c:     	popq	%r13
14009b85e:     	popq	%r14
14009b860:     	popq	%r15
14009b862:     	popq	%rbp
14009b863:     	retq
14009b864:     	leaq	0x1c82fd(%rip), %r9     # 0x140263b68
14009b86b:     	movl	$0x10, %r8d
14009b871:     	xorl	%ecx, %ecx
14009b873:     	movq	%rdi, %rdx
14009b876:     	callq	0x14024b9f0 <.text+0x24a9f0>
14009b87b:     	ud2

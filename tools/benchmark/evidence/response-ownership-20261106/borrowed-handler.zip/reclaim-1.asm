
D:\CoapticCurrent\borrowed-handler-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400ddfd0:     	pushq	%rbp
1400ddfd1:     	pushq	%r15
1400ddfd3:     	pushq	%r14
1400ddfd5:     	pushq	%r13
1400ddfd7:     	pushq	%r12
1400ddfd9:     	pushq	%rsi
1400ddfda:     	pushq	%rdi
1400ddfdb:     	pushq	%rbx
1400ddfdc:     	subq	$0x318, %rsp            # imm = 0x318
1400ddfe3:     	leaq	0x80(%rsp), %rbp
1400ddfeb:     	movaps	%xmm7, 0x280(%rbp)
1400ddff2:     	movaps	%xmm6, 0x270(%rbp)
1400ddff9:     	leaq	0x30(%rcx), %rdx
1400ddffd:     	xorl	%r8d, %r8d
1400de000:     	xorl	%r11d, %r11d
1400de003:     	leaq	(%r11,%r11,4), %r10
1400de007:     	shlq	$0x6, %r10
1400de00b:     	addq	%rdx, %r10
1400de00e:     	movq	%r11, %r9
1400de011:     	jmp	0x1400de034 <.text+0xdd034>
1400de013:     	nopw	%cs:(%rax,%rax)
1400de020:     	incq	%r9
1400de023:     	addq	$0x140, %r10            # imm = 0x140
1400de02a:     	cmpq	$0x4, %r9
1400de02e:     	je	0x1400de0be <.text+0xdd0be>
1400de034:     	cmpb	$0x1, 0x510(%rcx,%r9)
1400de03d:     	jne	0x1400de020 <.text+0xdd020>
1400de03f:     	movq	-0x30(%r10), %rsi
1400de043:     	cmpq	$0x2, %rsi
1400de047:     	je	0x1400de020 <.text+0xdd020>
1400de049:     	movq	(%r10), %r11
1400de04c:     	cmpl	$0x1, %esi
1400de04f:     	setne	%bl
1400de052:     	testq	%r11, %r11
1400de055:     	sete	%sil
1400de059:     	orb	%bl, %sil
1400de05c:     	cmpb	$0x1, %sil
1400de060:     	je	0x1400de020 <.text+0xdd020>
1400de062:     	movq	0x268(%rbp), %rsi
1400de069:     	cmpq	%rsi, %r11
1400de06c:     	setae	%bl
1400de06f:     	testb	%bl, %r8b
1400de072:     	jne	0x1400de0a4 <.text+0xdd0a4>
1400de074:     	movq	-0x28(%r10), %rax
1400de078:     	movd	-0x4(%r10), %xmm6
1400de07e:     	movzbl	-0x5(%r10), %edi
1400de083:     	movzbl	-0x6(%r10), %r15d
1400de088:     	movzwl	-0x8(%r10), %r12d
1400de08d:     	movl	-0xc(%r10), %r13d
1400de091:     	movl	-0x10(%r10), %r14d
1400de095:     	movups	-0x20(%r10), %xmm0
1400de09a:     	movaps	%xmm0, 0x240(%rbp)
1400de0a1:     	movq	%r11, %rsi
1400de0a4:     	movq	%rsi, 0x268(%rbp)
1400de0ab:     	leaq	0x1(%r9), %r11
1400de0af:     	movb	$0x1, %r8b
1400de0b2:     	cmpq	$0x3, %r9
1400de0b6:     	jb	0x1400de003 <.text+0xdd003>
1400de0bc:     	jmp	0x1400de0c8 <.text+0xdd0c8>
1400de0be:     	testb	$0x1, %r8b
1400de0c2:     	je	0x1400de308 <.text+0xdd308>
1400de0c8:     	cmpq	$0x1, %rax
1400de0cc:     	ja	0x1400de124 <.text+0xdd124>
1400de0ce:     	cmpb	$0x1, 0x1e80(%rcx,%rax)
1400de0d6:     	jne	0x1400de124 <.text+0xdd124>
1400de0d8:     	cmpb	$0x0, 0x1e82(%rcx,%rax)
1400de0e0:     	jne	0x1400de124 <.text+0xdd124>
1400de0e2:     	movb	$0x0, 0x1e80(%rcx,%rax)
1400de0ea:     	decq	0x1e78(%rcx)
1400de0f1:     	leaq	0x14f8(%rcx), %rdx
1400de0f8:     	movq	$0x0, 0x1df8(%rcx,%rax,8)
1400de104:     	leaq	(%rax,%rax,8), %r8
1400de108:     	leaq	(%r8,%r8,2), %r8
1400de10c:     	addq	%rax, %r8
1400de10f:     	movb	$0x2, 0x95a(%rdx,%r8)
1400de118:     	leaq	(%rax,%rax,2), %rax
1400de11c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
1400de124:     	movaps	0x240(%rbp), %xmm0
1400de12b:     	movaps	%xmm0, -0x60(%rbp)
1400de12f:     	movl	%r14d, %esi
1400de132:     	movl	%r14d, -0x50(%rbp)
1400de136:     	movl	%r13d, %r14d
1400de139:     	movl	%r13d, -0x4c(%rbp)
1400de13d:     	movl	%r12d, %r13d
1400de140:     	movw	%r12w, -0x48(%rbp)
1400de145:     	movl	%r15d, %r12d
1400de148:     	movb	%r15b, -0x46(%rbp)
1400de14c:     	movl	%edi, %r15d
1400de14f:     	movb	%dil, -0x45(%rbp)
1400de153:     	movd	%xmm6, %edi
1400de157:     	movd	%xmm6, -0x44(%rbp)
1400de15c:     	leaq	-0x60(%rbp), %rdx
1400de160:     	movq	%rcx, 0x260(%rbp)
1400de167:     	callq	0x14029aef0 <.text+0x299ef0>
1400de16c:     	xorps	%xmm7, %xmm7
1400de16f:     	movaps	%xmm7, 0x250(%rbp)
1400de176:     	movb	$0x0, 0x222(%rbp)
1400de17d:     	movw	%di, 0x220(%rbp)
1400de184:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
1400de18d:     	movq	$0x0, 0x223(%rbp)
1400de198:     	movq	$0x8, 0x200(%rbp)
1400de1a3:     	movq	$0x0, 0x208(%rbp)
1400de1ae:     	movq	$0x1, 0x210(%rbp)
1400de1b9:     	movq	$0x0, 0x218(%rbp)
1400de1c4:     	leaq	0x230(%rbp), %rcx
1400de1cb:     	leaq	0x200(%rbp), %rdx
1400de1d2:     	leaq	0x250(%rbp), %r8
1400de1d9:     	movl	$0x10, %r9d
1400de1df:     	callq	0x14015afc0 <.text+0x159fc0>
1400de1e4:     	cmpb	$0x0, 0x230(%rbp)
1400de1eb:     	jne	0x1400de304 <.text+0xdd304>
1400de1f1:     	movq	0x238(%rbp), %rdi
1400de1f8:     	movaps	%xmm7, 0xe0(%rbp)
1400de1ff:     	movaps	%xmm7, 0xf0(%rbp)
1400de206:     	movaps	%xmm7, 0x100(%rbp)
1400de20d:     	movaps	%xmm7, 0x110(%rbp)
1400de214:     	movaps	%xmm7, 0x120(%rbp)
1400de21b:     	movaps	%xmm7, 0x130(%rbp)
1400de222:     	movaps	%xmm7, 0x140(%rbp)
1400de229:     	movaps	%xmm7, 0x150(%rbp)
1400de230:     	movaps	%xmm7, 0x160(%rbp)
1400de237:     	movaps	%xmm7, 0x170(%rbp)
1400de23e:     	movaps	%xmm7, 0x180(%rbp)
1400de245:     	movaps	%xmm7, 0x190(%rbp)
1400de24c:     	movaps	%xmm7, 0x1a0(%rbp)
1400de253:     	movaps	%xmm7, 0x1b0(%rbp)
1400de25a:     	movaps	%xmm7, 0x1c0(%rbp)
1400de261:     	movaps	%xmm7, 0x1d0(%rbp)
1400de268:     	movaps	0x240(%rbp), %xmm0
1400de26f:     	movups	%xmm0, 0x1f0(%rbp)
1400de276:     	cmpq	$0x11, %rdi
1400de27a:     	jae	0x1400de32c <.text+0xdd32c>
1400de280:     	leaq	0xe0(%rbp), %rbx
1400de287:     	leaq	0x250(%rbp), %rdx
1400de28e:     	movq	%rbx, %rcx
1400de291:     	movq	%rdi, %r8
1400de294:     	callq	0x1402d4830 <.text+0x2d3830>
1400de299:     	movw	%di, 0x1e0(%rbp)
1400de2a0:     	movq	$0x0, -0x60(%rbp)
1400de2a8:     	movups	0x1e8(%rbp), %xmm0
1400de2af:     	movups	%xmm0, -0x58(%rbp)
1400de2b3:     	movq	0x1f8(%rbp), %rax
1400de2ba:     	movq	%rax, -0x48(%rbp)
1400de2be:     	movl	%esi, -0x40(%rbp)
1400de2c1:     	movl	%r14d, -0x3c(%rbp)
1400de2c5:     	movw	%r13w, -0x38(%rbp)
1400de2ca:     	movb	%r12b, -0x36(%rbp)
1400de2ce:     	movb	%r15b, -0x35(%rbp)
1400de2d2:     	movd	%xmm6, -0x34(%rbp)
1400de2d7:     	movq	0x268(%rbp), %rax
1400de2de:     	movq	%rax, -0x30(%rbp)
1400de2e2:     	leaq	-0x28(%rbp), %rcx
1400de2e6:     	movl	$0x108, %r8d            # imm = 0x108
1400de2ec:     	movq	%rbx, %rdx
1400de2ef:     	callq	0x1402d4830 <.text+0x2d3830>
1400de2f4:     	leaq	-0x60(%rbp), %rdx
1400de2f8:     	movq	0x260(%rbp), %rcx
1400de2ff:     	callq	0x14029ac60 <.text+0x299c60>
1400de304:     	movb	$0x1, %al
1400de306:     	jmp	0x1400de30a <.text+0xdd30a>
1400de308:     	xorl	%eax, %eax
1400de30a:     	movaps	0x270(%rbp), %xmm6
1400de311:     	movaps	0x280(%rbp), %xmm7
1400de318:     	addq	$0x318, %rsp            # imm = 0x318
1400de31f:     	popq	%rbx
1400de320:     	popq	%rdi
1400de321:     	popq	%rsi
1400de322:     	popq	%r12
1400de324:     	popq	%r13
1400de326:     	popq	%r14
1400de328:     	popq	%r15
1400de32a:     	popq	%rbp
1400de32b:     	retq
1400de32c:     	leaq	0x217825(%rip), %r9     # 0x1402f5b58
1400de333:     	movl	$0x10, %r8d
1400de339:     	xorl	%ecx, %ecx
1400de33b:     	movq	%rdi, %rdx
1400de33e:     	callq	0x1402d5280 <.text+0x2d4280>
1400de343:     	ud2

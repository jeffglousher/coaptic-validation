
D:\CoapticCurrent\borrowed-handler-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14006afb0:     	pushq	%rbp
14006afb1:     	pushq	%r15
14006afb3:     	pushq	%r14
14006afb5:     	pushq	%r13
14006afb7:     	pushq	%r12
14006afb9:     	pushq	%rsi
14006afba:     	pushq	%rdi
14006afbb:     	pushq	%rbx
14006afbc:     	subq	$0x508, %rsp            # imm = 0x508
14006afc3:     	leaq	0x80(%rsp), %rbp
14006afcb:     	movq	%r9, %rbx
14006afce:     	movq	%r8, %r14
14006afd1:     	movq	%rdx, %rdi
14006afd4:     	movq	%rcx, %rsi
14006afd7:     	movq	0x500(%rbp), %r12
14006afde:     	movq	%rbp, %rcx
14006afe1:     	movl	$0x400, %r8d            # imm = 0x400
14006afe7:     	xorl	%edx, %edx
14006afe9:     	callq	0x1402d4842 <.text+0x2d3842>
14006afee:     	movq	0x8(%r12), %r13
14006aff3:     	movl	$0x3, %eax
14006aff8:     	cmpq	$0x3, %r13
14006affc:     	ja	0x14006b225 <.text+0x6a225>
14006b002:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
14006b00b:     	jne	0x14006b225 <.text+0x6a225>
14006b011:     	movq	0x2b750(%rdi,%r13,8), %rdx
14006b019:     	cmpq	$0x4001, %rdx           # imm = 0x4001
14006b020:     	jae	0x14006b281 <.text+0x6a281>
14006b026:     	movq	0x10(%r12), %rcx
14006b02b:     	movq	0x18(%r12), %r15
14006b030:     	movq	%r15, %r8
14006b033:     	movl	$0xb, %eax
14006b038:     	addq	%rcx, %r8
14006b03b:     	jb	0x14006b225 <.text+0x6a225>
14006b041:     	cmpq	$0x400, %r15            # imm = 0x400
14006b048:     	ja	0x14006b225 <.text+0x6a225>
14006b04e:     	cmpq	%rdx, %r8
14006b051:     	ja	0x14006b225 <.text+0x6a225>
14006b057:     	movq	%r13, %rax
14006b05a:     	shlq	$0xe, %rax
14006b05e:     	leaq	(%rdi,%rax), %rdx
14006b062:     	addq	$0x1b750, %rdx          # imm = 0x1B750
14006b069:     	addq	%rcx, %rdx
14006b06c:     	movq	%rbp, %rcx
14006b06f:     	movq	%r15, %r8
14006b072:     	callq	0x1402d4830 <.text+0x2d3830>
14006b077:     	cmpb	$0x0, 0x508(%rbp)
14006b07e:     	je	0x14006b096 <.text+0x6a096>
14006b080:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
14006b087:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
14006b090:     	jne	0x14006b240 <.text+0x6a240>
14006b096:     	movq	$0x0, 0x480(%rbp)
14006b0a1:     	movq	%rdi, %rcx
14006b0a4:     	callq	0x1400dabe0 <.text+0xd9be0>
14006b0a9:     	testb	$0x1, %al
14006b0ab:     	je	0x14006b273 <.text+0x6a273>
14006b0b1:     	movq	%rdx, %r13
14006b0b4:     	movq	0x518(%rbp), %rdx
14006b0bb:     	movq	0x510(%rbp), %r8
14006b0c2:     	movzwl	0x4f8(%rbp), %ecx
14006b0c9:     	movzbl	0x4f0(%rbp), %eax
14006b0d0:     	movq	(%r12), %r9
14006b0d4:     	movq	0x480(%rbp), %r10
14006b0db:     	movq	%r10, 0x448(%rbp)
14006b0e2:     	movq	0x478(%rbp), %r10
14006b0e9:     	movq	%r10, 0x450(%rbp)
14006b0f0:     	movq	%r9, 0x458(%rbp)
14006b0f7:     	movzbl	0x508(%rbp), %r9d
14006b0ff:     	movb	%r9b, 0x460(%rbp)
14006b106:     	movups	0x60(%r14), %xmm0
14006b10b:     	movups	0x6c(%r14), %xmm1
14006b110:     	movups	%xmm1, 0x40c(%rbp)
14006b117:     	movaps	%xmm0, 0x400(%rbp)
14006b11e:     	leaq	0x8e(%r14), %r9
14006b125:     	movq	0x7e(%r14), %r10
14006b129:     	movq	0x85(%r14), %r11
14006b130:     	movq	%r11, 0x46f(%rbp)
14006b137:     	movq	%r10, 0x468(%rbp)
14006b13e:     	leaq	0x468(%rbp), %r10
14006b145:     	movq	%r10, 0x70(%rsp)
14006b14a:     	movq	%rdx, 0x68(%rsp)
14006b14f:     	movq	%r8, 0x60(%rsp)
14006b154:     	movq	%r14, 0x58(%rsp)
14006b159:     	leaq	0x448(%rbp), %rdx
14006b160:     	movq	%rdx, 0x50(%rsp)
14006b165:     	movq	%r15, 0x48(%rsp)
14006b16a:     	movq	%rbp, %rdx
14006b16d:     	movq	%rdx, 0x40(%rsp)
14006b172:     	movq	%rbx, 0x38(%rsp)
14006b177:     	movq	%r9, 0x30(%rsp)
14006b17c:     	movw	%cx, 0x28(%rsp)
14006b181:     	movb	%al, 0x20(%rsp)
14006b185:     	leaq	0x428(%rbp), %rcx
14006b18c:     	leaq	0x400(%rbp), %r8
14006b193:     	movq	%rdi, %rdx
14006b196:     	movq	%r13, %r9
14006b199:     	callq	0x1400b73a0 <.text+0xb63a0>
14006b19e:     	cmpb	$-0x1, 0x428(%rbp)
14006b1a5:     	je	0x14006b278 <.text+0x6a278>
14006b1ab:     	cmpb	$0x1, 0x37740(%rdi,%r13)
14006b1b4:     	jne	0x14006b20e <.text+0x6a20e>
14006b1b6:     	cmpb	$0x0, 0x37760(%rdi,%r13)
14006b1bf:     	jne	0x14006b20e <.text+0x6a20e>
14006b1c1:     	movb	$0x0, 0x37740(%rdi,%r13)
14006b1ca:     	decq	0x37788(%rdi)
14006b1d1:     	leaq	0x37740(%rdi), %rax
14006b1d8:     	movq	$0x0, 0x43610(%rdi,%r13,8)
14006b1e4:     	leaq	(,%r13,8), %rcx
14006b1ec:     	addq	%r13, %rcx
14006b1ef:     	leaq	(%rcx,%rcx,2), %rcx
14006b1f3:     	addq	%r13, %rcx
14006b1f6:     	movb	$0x2, 0x36a(%rax,%rcx)
14006b1fe:     	leaq	(,%r13,2), %rcx
14006b206:     	addq	%r13, %rcx
14006b209:     	movb	$0x2, 0x5d(%rax,%rcx,8)
14006b20e:     	movups	0x428(%rbp), %xmm0
14006b215:     	movups	0x438(%rbp), %xmm1
14006b21c:     	movups	%xmm1, 0x10(%rsi)
14006b220:     	movups	%xmm0, (%rsi)
14006b223:     	jmp	0x14006b22c <.text+0x6a22c>
14006b225:     	movb	$0xa, (%rsi)
14006b228:     	movq	%rax, 0x8(%rsi)
14006b22c:     	addq	$0x508, %rsp            # imm = 0x508
14006b233:     	popq	%rbx
14006b234:     	popq	%rdi
14006b235:     	popq	%rsi
14006b236:     	popq	%r12
14006b238:     	popq	%r13
14006b23a:     	popq	%r14
14006b23c:     	popq	%r15
14006b23e:     	popq	%rbp
14006b23f:     	retq
14006b240:     	addq	%rdi, %rax
14006b243:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
14006b249:     	movq	0x98(%rax), %rax
14006b250:     	movq	%rax, 0x478(%rbp)
14006b257:     	movl	$0x1, %eax
14006b25c:     	movq	%rax, 0x480(%rbp)
14006b263:     	movq	%rdi, %rcx
14006b266:     	callq	0x1400dabe0 <.text+0xd9be0>
14006b26b:     	testb	$0x1, %al
14006b26d:     	jne	0x14006b0b1 <.text+0x6a0b1>
14006b273:     	movb	$0x9, (%rsi)
14006b276:     	jmp	0x14006b22c <.text+0x6a22c>
14006b278:     	movq	%r13, 0x8(%rsi)
14006b27c:     	movb	$-0x1, (%rsi)
14006b27f:     	jmp	0x14006b22c <.text+0x6a22c>
14006b281:     	leaq	0x28da80(%rip), %r9     # 0x1402f8d08
14006b288:     	movl	$0x4000, %r8d           # imm = 0x4000
14006b28e:     	xorl	%ecx, %ecx
14006b290:     	callq	0x1402d5280 <.text+0x2d4280>
14006b295:     	ud2

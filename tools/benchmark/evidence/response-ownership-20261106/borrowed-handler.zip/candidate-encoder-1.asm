
D:\CoapticCurrent\borrowed-handler-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14006a790:     	pushq	%rbp
14006a791:     	pushq	%r15
14006a793:     	pushq	%r14
14006a795:     	pushq	%r13
14006a797:     	pushq	%r12
14006a799:     	pushq	%rsi
14006a79a:     	pushq	%rdi
14006a79b:     	pushq	%rbx
14006a79c:     	subq	$0x508, %rsp            # imm = 0x508
14006a7a3:     	leaq	0x80(%rsp), %rbp
14006a7ab:     	movq	%r9, %r15
14006a7ae:     	movq	%r8, %rbx
14006a7b1:     	movq	%rdx, %r14
14006a7b4:     	movq	%rcx, %rsi
14006a7b7:     	movq	0x500(%rbp), %r12
14006a7be:     	movq	%rbp, %rcx
14006a7c1:     	movl	$0x400, %r8d            # imm = 0x400
14006a7c7:     	xorl	%edx, %edx
14006a7c9:     	callq	0x1402d4842 <.text+0x2d3842>
14006a7ce:     	movq	0x8(%r12), %rdi
14006a7d3:     	movl	$0x3, %eax
14006a7d8:     	cmpq	$0x3, %rdi
14006a7dc:     	ja	0x14006a9f3 <.text+0x699f3>
14006a7e2:     	movq	%r15, 0x478(%rbp)
14006a7e9:     	movq	0x30(%r14), %r13
14006a7ed:     	cmpb	$0x1, 0xad0(%r13,%rdi)
14006a7f6:     	jne	0x14006a9f3 <.text+0x699f3>
14006a7fc:     	movq	0x10ad8(%r13,%rdi,8), %rdx
14006a804:     	cmpq	$0x4001, %rdx           # imm = 0x4001
14006a80b:     	jae	0x14006aa42 <.text+0x69a42>
14006a811:     	movq	0x10(%r12), %rcx
14006a816:     	movq	0x18(%r12), %r15
14006a81b:     	movq	%r15, %r8
14006a81e:     	movl	$0xb, %eax
14006a823:     	addq	%rcx, %r8
14006a826:     	jb	0x14006a9f3 <.text+0x699f3>
14006a82c:     	cmpq	$0x400, %r15            # imm = 0x400
14006a833:     	ja	0x14006a9f3 <.text+0x699f3>
14006a839:     	cmpq	%rdx, %r8
14006a83c:     	ja	0x14006a9f3 <.text+0x699f3>
14006a842:     	movq	%rdi, %rax
14006a845:     	shlq	$0xe, %rax
14006a849:     	leaq	(%rax,%r13), %rdx
14006a84d:     	addq	$0xad8, %rdx            # imm = 0xAD8
14006a854:     	addq	%rcx, %rdx
14006a857:     	movq	%rbp, %rcx
14006a85a:     	movq	%r15, %r8
14006a85d:     	callq	0x1402d4830 <.text+0x2d3830>
14006a862:     	cmpb	$0x0, 0x508(%rbp)
14006a869:     	je	0x14006a87e <.text+0x6987e>
14006a86b:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
14006a872:     	cmpq	$0x2, (%r13,%rax)
14006a878:     	jne	0x14006aa0e <.text+0x69a0e>
14006a87e:     	xorl	%edi, %edi
14006a880:     	movq	%r14, %rcx
14006a883:     	callq	0x1400d9fe0 <.text+0xd8fe0>
14006a888:     	testb	$0x1, %al
14006a88a:     	je	0x14006aa34 <.text+0x69a34>
14006a890:     	movq	%rdx, %r13
14006a893:     	movq	0x518(%rbp), %rdx
14006a89a:     	movq	0x510(%rbp), %r8
14006a8a1:     	movzwl	0x4f8(%rbp), %ecx
14006a8a8:     	movzbl	0x4f0(%rbp), %eax
14006a8af:     	movq	(%r12), %r9
14006a8b3:     	movq	%rdi, 0x448(%rbp)
14006a8ba:     	movq	0x480(%rbp), %r10
14006a8c1:     	movq	%r10, 0x450(%rbp)
14006a8c8:     	movq	%r9, 0x458(%rbp)
14006a8cf:     	movzbl	0x508(%rbp), %r9d
14006a8d7:     	movb	%r9b, 0x460(%rbp)
14006a8de:     	movups	0x60(%rbx), %xmm0
14006a8e2:     	movups	0x6c(%rbx), %xmm1
14006a8e6:     	movups	%xmm1, 0x40c(%rbp)
14006a8ed:     	movaps	%xmm0, 0x400(%rbp)
14006a8f4:     	leaq	0x8e(%rbx), %r9
14006a8fb:     	movq	0x7e(%rbx), %r10
14006a8ff:     	movq	0x85(%rbx), %r11
14006a906:     	movq	%r11, 0x46f(%rbp)
14006a90d:     	movq	%r10, 0x468(%rbp)
14006a914:     	movq	0x10(%r14), %r14
14006a918:     	leaq	0x468(%rbp), %r10
14006a91f:     	movq	%r10, 0x70(%rsp)
14006a924:     	movq	%rdx, 0x68(%rsp)
14006a929:     	movq	%r8, 0x60(%rsp)
14006a92e:     	movq	%rbx, 0x58(%rsp)
14006a933:     	leaq	0x448(%rbp), %rdx
14006a93a:     	movq	%rdx, 0x50(%rsp)
14006a93f:     	movq	%r15, 0x48(%rsp)
14006a944:     	movq	%rbp, %rdx
14006a947:     	movq	%rdx, 0x40(%rsp)
14006a94c:     	movq	0x478(%rbp), %rdx
14006a953:     	movq	%rdx, 0x38(%rsp)
14006a958:     	movq	%r9, 0x30(%rsp)
14006a95d:     	movw	%cx, 0x28(%rsp)
14006a962:     	movb	%al, 0x20(%rsp)
14006a966:     	leaq	0x428(%rbp), %rcx
14006a96d:     	leaq	0x400(%rbp), %r8
14006a974:     	movq	%r14, %rdx
14006a977:     	movq	%r13, %r9
14006a97a:     	callq	0x1400afce0 <.text+0xaece0>
14006a97f:     	cmpb	$-0x1, 0x428(%rbp)
14006a986:     	je	0x14006aa39 <.text+0x69a39>
14006a98c:     	cmpb	$0x1, (%r14,%r13)
14006a991:     	jne	0x14006a9dc <.text+0x699dc>
14006a993:     	cmpb	$0x0, 0x20(%r14,%r13)
14006a999:     	jne	0x14006a9dc <.text+0x699dc>
14006a99b:     	movb	$0x0, (%r14,%r13)
14006a9a0:     	decq	0x48(%r14)
14006a9a4:     	movq	$0x0, 0xbed0(%r14,%r13,8)
14006a9b0:     	leaq	(,%r13,8), %rax
14006a9b8:     	addq	%r13, %rax
14006a9bb:     	leaq	(%rax,%rax,2), %rax
14006a9bf:     	addq	%r13, %rax
14006a9c2:     	movb	$0x2, 0x36a(%r14,%rax)
14006a9cb:     	leaq	(,%r13,2), %rax
14006a9d3:     	addq	%r13, %rax
14006a9d6:     	movb	$0x2, 0x5d(%r14,%rax,8)
14006a9dc:     	movups	0x428(%rbp), %xmm0
14006a9e3:     	movups	0x438(%rbp), %xmm1
14006a9ea:     	movups	%xmm1, 0x10(%rsi)
14006a9ee:     	movups	%xmm0, (%rsi)
14006a9f1:     	jmp	0x14006a9fa <.text+0x699fa>
14006a9f3:     	movb	$0xa, (%rsi)
14006a9f6:     	movq	%rax, 0x8(%rsi)
14006a9fa:     	addq	$0x508, %rsp            # imm = 0x508
14006aa01:     	popq	%rbx
14006aa02:     	popq	%rdi
14006aa03:     	popq	%rsi
14006aa04:     	popq	%r12
14006aa06:     	popq	%r13
14006aa08:     	popq	%r14
14006aa0a:     	popq	%r15
14006aa0c:     	popq	%rbp
14006aa0d:     	retq
14006aa0e:     	addq	%rax, %r13
14006aa11:     	movq	0x98(%r13), %rax
14006aa18:     	movq	%rax, 0x480(%rbp)
14006aa1f:     	movl	$0x1, %edi
14006aa24:     	movq	%r14, %rcx
14006aa27:     	callq	0x1400d9fe0 <.text+0xd8fe0>
14006aa2c:     	testb	$0x1, %al
14006aa2e:     	jne	0x14006a890 <.text+0x69890>
14006aa34:     	movb	$0x9, (%rsi)
14006aa37:     	jmp	0x14006a9fa <.text+0x699fa>
14006aa39:     	movq	%r13, 0x8(%rsi)
14006aa3d:     	movb	$-0x1, (%rsi)
14006aa40:     	jmp	0x14006a9fa <.text+0x699fa>
14006aa42:     	leaq	0x28e2bf(%rip), %r9     # 0x1402f8d08
14006aa49:     	movl	$0x4000, %r8d           # imm = 0x4000
14006aa4f:     	xorl	%ecx, %ecx
14006aa51:     	callq	0x1402d5280 <.text+0x2d4280>
14006aa56:     	ud2

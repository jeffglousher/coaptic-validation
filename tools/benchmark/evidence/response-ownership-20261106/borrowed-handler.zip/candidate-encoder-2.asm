
D:\CoapticCurrent\borrowed-handler-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14006aa60:     	pushq	%rbp
14006aa61:     	pushq	%r15
14006aa63:     	pushq	%r14
14006aa65:     	pushq	%r13
14006aa67:     	pushq	%r12
14006aa69:     	pushq	%rsi
14006aa6a:     	pushq	%rdi
14006aa6b:     	pushq	%rbx
14006aa6c:     	subq	$0x4f8, %rsp            # imm = 0x4F8
14006aa73:     	leaq	0x80(%rsp), %rbp
14006aa7b:     	movq	%r9, %r15
14006aa7e:     	movq	%r8, %rbx
14006aa81:     	movq	%rdx, %r14
14006aa84:     	movq	%rcx, %rsi
14006aa87:     	movq	0x4f0(%rbp), %r12
14006aa8e:     	leaq	-0x10(%rbp), %rcx
14006aa92:     	movl	$0x400, %r8d            # imm = 0x400
14006aa98:     	xorl	%edx, %edx
14006aa9a:     	callq	0x1402d4842 <.text+0x2d3842>
14006aa9f:     	movq	0x8(%r12), %rdi
14006aaa4:     	movl	$0x3, %eax
14006aaa9:     	cmpq	$0x3, %rdi
14006aaad:     	ja	0x14006acba <.text+0x69cba>
14006aab3:     	movq	%r15, 0x468(%rbp)
14006aaba:     	movq	0x30(%r14), %r13
14006aabe:     	cmpb	$0x1, 0xad0(%r13,%rdi)
14006aac7:     	jne	0x14006acba <.text+0x69cba>
14006aacd:     	movq	0x10ad8(%r13,%rdi,8), %rdx
14006aad5:     	cmpq	$0x4001, %rdx           # imm = 0x4001
14006aadc:     	jae	0x14006ad09 <.text+0x69d09>
14006aae2:     	movq	0x10(%r12), %rcx
14006aae7:     	movq	0x18(%r12), %r15
14006aaec:     	movq	%r15, %r8
14006aaef:     	movl	$0xb, %eax
14006aaf4:     	addq	%rcx, %r8
14006aaf7:     	jb	0x14006acba <.text+0x69cba>
14006aafd:     	cmpq	$0x400, %r15            # imm = 0x400
14006ab04:     	ja	0x14006acba <.text+0x69cba>
14006ab0a:     	cmpq	%rdx, %r8
14006ab0d:     	ja	0x14006acba <.text+0x69cba>
14006ab13:     	movq	%rdi, %rax
14006ab16:     	shlq	$0xe, %rax
14006ab1a:     	leaq	(%rax,%r13), %rdx
14006ab1e:     	addq	$0xad8, %rdx            # imm = 0xAD8
14006ab25:     	addq	%rcx, %rdx
14006ab28:     	leaq	-0x10(%rbp), %rcx
14006ab2c:     	movq	%r15, %r8
14006ab2f:     	callq	0x1402d4830 <.text+0x2d3830>
14006ab34:     	cmpb	$0x0, 0x4f8(%rbp)
14006ab3b:     	je	0x14006ab50 <.text+0x69b50>
14006ab3d:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
14006ab44:     	cmpq	$0x2, (%r13,%rax)
14006ab4a:     	jne	0x14006acd5 <.text+0x69cd5>
14006ab50:     	xorl	%edi, %edi
14006ab52:     	movq	%r14, %rcx
14006ab55:     	callq	0x1400d9fe0 <.text+0xd8fe0>
14006ab5a:     	testb	$0x1, %al
14006ab5c:     	je	0x14006acfb <.text+0x69cfb>
14006ab62:     	movq	%rdx, %r13
14006ab65:     	movq	0x500(%rbp), %rdx
14006ab6c:     	movzwl	0x4e8(%rbp), %ecx
14006ab73:     	movzbl	0x4e0(%rbp), %eax
14006ab7a:     	movq	(%r12), %r8
14006ab7e:     	movq	%rdi, 0x438(%rbp)
14006ab85:     	movq	0x470(%rbp), %r9
14006ab8c:     	movq	%r9, 0x440(%rbp)
14006ab93:     	movq	%r8, 0x448(%rbp)
14006ab9a:     	movzbl	0x4f8(%rbp), %r8d
14006aba2:     	movb	%r8b, 0x450(%rbp)
14006aba9:     	movups	0x60(%rbx), %xmm0
14006abad:     	movups	0x6c(%rbx), %xmm1
14006abb1:     	movups	%xmm1, 0x3fc(%rbp)
14006abb8:     	movaps	%xmm0, 0x3f0(%rbp)
14006abbf:     	leaq	0x8e(%rbx), %r8
14006abc6:     	movq	0x7e(%rbx), %r9
14006abca:     	movq	0x85(%rbx), %r10
14006abd1:     	movq	%r10, 0x45f(%rbp)
14006abd8:     	movq	%r9, 0x458(%rbp)
14006abdf:     	movq	0x10(%r14), %r14
14006abe3:     	leaq	0x458(%rbp), %r9
14006abea:     	movq	%r9, 0x68(%rsp)
14006abef:     	movq	%rdx, 0x60(%rsp)
14006abf4:     	movq	%rbx, 0x58(%rsp)
14006abf9:     	leaq	0x438(%rbp), %rdx
14006ac00:     	movq	%rdx, 0x50(%rsp)
14006ac05:     	movq	%r15, 0x48(%rsp)
14006ac0a:     	leaq	-0x10(%rbp), %rdx
14006ac0e:     	movq	%rdx, 0x40(%rsp)
14006ac13:     	movq	0x468(%rbp), %rdx
14006ac1a:     	movq	%rdx, 0x38(%rsp)
14006ac1f:     	movq	%r8, 0x30(%rsp)
14006ac24:     	movw	%cx, 0x28(%rsp)
14006ac29:     	movb	%al, 0x20(%rsp)
14006ac2d:     	leaq	0x418(%rbp), %rcx
14006ac34:     	leaq	0x3f0(%rbp), %r8
14006ac3b:     	movq	%r14, %rdx
14006ac3e:     	movq	%r13, %r9
14006ac41:     	callq	0x1400b14d0 <.text+0xb04d0>
14006ac46:     	cmpb	$-0x1, 0x418(%rbp)
14006ac4d:     	je	0x14006ad00 <.text+0x69d00>
14006ac53:     	cmpb	$0x1, (%r14,%r13)
14006ac58:     	jne	0x14006aca3 <.text+0x69ca3>
14006ac5a:     	cmpb	$0x0, 0x20(%r14,%r13)
14006ac60:     	jne	0x14006aca3 <.text+0x69ca3>
14006ac62:     	movb	$0x0, (%r14,%r13)
14006ac67:     	decq	0x48(%r14)
14006ac6b:     	movq	$0x0, 0xbed0(%r14,%r13,8)
14006ac77:     	leaq	(,%r13,8), %rax
14006ac7f:     	addq	%r13, %rax
14006ac82:     	leaq	(%rax,%rax,2), %rax
14006ac86:     	addq	%r13, %rax
14006ac89:     	movb	$0x2, 0x36a(%r14,%rax)
14006ac92:     	leaq	(,%r13,2), %rax
14006ac9a:     	addq	%r13, %rax
14006ac9d:     	movb	$0x2, 0x5d(%r14,%rax,8)
14006aca3:     	movups	0x418(%rbp), %xmm0
14006acaa:     	movups	0x428(%rbp), %xmm1
14006acb1:     	movups	%xmm1, 0x10(%rsi)
14006acb5:     	movups	%xmm0, (%rsi)
14006acb8:     	jmp	0x14006acc1 <.text+0x69cc1>
14006acba:     	movb	$0xa, (%rsi)
14006acbd:     	movq	%rax, 0x8(%rsi)
14006acc1:     	addq	$0x4f8, %rsp            # imm = 0x4F8
14006acc8:     	popq	%rbx
14006acc9:     	popq	%rdi
14006acca:     	popq	%rsi
14006accb:     	popq	%r12
14006accd:     	popq	%r13
14006accf:     	popq	%r14
14006acd1:     	popq	%r15
14006acd3:     	popq	%rbp
14006acd4:     	retq
14006acd5:     	addq	%rax, %r13
14006acd8:     	movq	0x98(%r13), %rax
14006acdf:     	movq	%rax, 0x470(%rbp)
14006ace6:     	movl	$0x1, %edi
14006aceb:     	movq	%r14, %rcx
14006acee:     	callq	0x1400d9fe0 <.text+0xd8fe0>
14006acf3:     	testb	$0x1, %al
14006acf5:     	jne	0x14006ab62 <.text+0x69b62>
14006acfb:     	movb	$0x9, (%rsi)
14006acfe:     	jmp	0x14006acc1 <.text+0x69cc1>
14006ad00:     	movq	%r13, 0x8(%rsi)
14006ad04:     	movb	$-0x1, (%rsi)
14006ad07:     	jmp	0x14006acc1 <.text+0x69cc1>
14006ad09:     	leaq	0x28dff8(%rip), %r9     # 0x1402f8d08
14006ad10:     	movl	$0x4000, %r8d           # imm = 0x4000
14006ad16:     	xorl	%ecx, %ecx
14006ad18:     	callq	0x1402d5280 <.text+0x2d4280>
14006ad1d:     	ud2

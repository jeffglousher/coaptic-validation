
D:\CoapticCurrent\borrowed-handler-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400dea90:     	pushq	%rbp
1400dea91:     	pushq	%r15
1400dea93:     	pushq	%r14
1400dea95:     	pushq	%r13
1400dea97:     	pushq	%r12
1400dea99:     	pushq	%rsi
1400dea9a:     	pushq	%rdi
1400dea9b:     	pushq	%rbx
1400dea9c:     	subq	$0x318, %rsp            # imm = 0x318
1400deaa3:     	leaq	0x80(%rsp), %rbp
1400deaab:     	movaps	%xmm7, 0x280(%rbp)
1400deab2:     	movdqa	%xmm6, 0x270(%rbp)
1400deaba:     	movq	0xe8(%rcx), %r8
1400deac1:     	testq	%r8, %r8
1400deac4:     	je	0x1400deea4 <.text+0xddea4>
1400deaca:     	movq	0x88(%rcx), %r11
1400dead1:     	movq	0xe0(%rcx), %rdx
1400dead8:     	movq	0xc8(%rcx), %rax
1400deadf:     	movq	0xd0(%rcx), %r9
1400deae6:     	leaq	0x30(%rax), %rsi
1400deaea:     	xorl	%ebx, %ebx
1400deaec:     	xorl	%edi, %edi
1400deaee:     	leaq	(%rdi,%rdi,4), %r12
1400deaf2:     	shlq	$0x6, %r12
1400deaf6:     	addq	%rsi, %r12
1400deaf9:     	jmp	0x1400deb13 <.text+0xddb13>
1400deafb:     	nopl	(%rax,%rax)
1400deb00:     	incq	%rdi
1400deb03:     	addq	$0x140, %r12            # imm = 0x140
1400deb0a:     	cmpq	%r8, %rdi
1400deb0d:     	jae	0x1400debdc <.text+0xddbdc>
1400deb13:     	cmpq	%r9, %rdi
1400deb16:     	setb	%r15b
1400deb1a:     	andb	(%rdx,%rdi), %r15b
1400deb1e:     	cmpb	$0x1, %r15b
1400deb22:     	jne	0x1400deb00 <.text+0xddb00>
1400deb24:     	movq	-0x30(%r12), %r15
1400deb29:     	cmpq	$0x2, %r15
1400deb2d:     	je	0x1400deb00 <.text+0xddb00>
1400deb2f:     	movq	(%r12), %r13
1400deb33:     	cmpl	$0x1, %r15d
1400deb37:     	setne	%r15b
1400deb3b:     	testq	%r13, %r13
1400deb3e:     	sete	%r10b
1400deb42:     	orb	%r15b, %r10b
1400deb45:     	cmpb	$0x1, %r10b
1400deb49:     	je	0x1400deb00 <.text+0xddb00>
1400deb4b:     	movq	0x260(%rbp), %r15
1400deb52:     	cmpq	%r15, %r13
1400deb55:     	setae	%r10b
1400deb59:     	testb	%r10b, %bl
1400deb5c:     	jne	0x1400debc5 <.text+0xddbc5>
1400deb5e:     	movq	-0x28(%r12), %r10
1400deb63:     	movq	%r10, 0x250(%rbp)
1400deb6a:     	movq	-0x20(%r12), %r10
1400deb6f:     	movq	%r10, 0x248(%rbp)
1400deb76:     	movd	-0x4(%r12), %xmm6
1400deb7d:     	movzbl	-0x5(%r12), %r10d
1400deb83:     	movb	%r10b, 0x26e(%rbp)
1400deb8a:     	movzbl	-0x6(%r12), %r10d
1400deb90:     	movb	%r10b, 0x26f(%rbp)
1400deb97:     	movzwl	-0x8(%r12), %r10d
1400deb9d:     	movw	%r10w, 0x26c(%rbp)
1400deba5:     	movl	-0xc(%r12), %r10d
1400debaa:     	movl	%r10d, 0x268(%rbp)
1400debb1:     	movl	-0x10(%r12), %r14d
1400debb6:     	movq	-0x18(%r12), %r10
1400debbb:     	movq	%r10, 0x258(%rbp)
1400debc2:     	movq	%r13, %r15
1400debc5:     	movq	%r15, 0x260(%rbp)
1400debcc:     	incq	%rdi
1400debcf:     	movb	$0x1, %bl
1400debd1:     	cmpq	%r8, %rdi
1400debd4:     	jb	0x1400deaee <.text+0xddaee>
1400debda:     	jmp	0x1400debe5 <.text+0xddbe5>
1400debdc:     	testb	$0x1, %bl
1400debdf:     	je	0x1400deea4 <.text+0xddea4>
1400debe5:     	movq	0x250(%rbp), %r10
1400debec:     	cmpq	%r11, %r10
1400debef:     	jae	0x1400dec45 <.text+0xddc45>
1400debf1:     	movq	0x80(%rcx), %r11
1400debf8:     	cmpb	$0x1, (%r11,%r10)
1400debfd:     	jne	0x1400dec45 <.text+0xddc45>
1400debff:     	cmpq	0xa0(%rcx), %r10
1400dec06:     	jae	0x1400dec16 <.text+0xddc16>
1400dec08:     	movq	0x98(%rcx), %rsi
1400dec0f:     	cmpb	$0x0, (%rsi,%r10)
1400dec14:     	jne	0x1400dec45 <.text+0xddc45>
1400dec16:     	movb	$0x0, (%r11,%r10)
1400dec1b:     	decq	0xb0(%rcx)
1400dec22:     	cmpq	0x70(%rcx), %r10
1400dec26:     	jae	0x1400dec45 <.text+0xddc45>
1400dec28:     	movq	0x68(%rcx), %r11
1400dec2c:     	imulq	$0x58, %r10, %r10
1400dec30:     	movq	$0x0, 0x30(%r11,%r10)
1400dec39:     	movb	$0x2, 0x52(%r11,%r10)
1400dec3f:     	movb	$0x2, 0x25(%r11,%r10)
1400dec45:     	leaq	0xc0(%rcx), %rsi
1400dec4c:     	movd	%xmm6, %r10d
1400dec51:     	addq	$0x2c, %rax
1400dec55:     	xorl	%r11d, %r11d
1400dec58:     	movq	0x248(%rbp), %r15
1400dec5f:     	movzbl	0x26e(%rbp), %r12d
1400dec67:     	jmp	0x1400dec82 <.text+0xddc82>
1400dec69:     	nopl	(%rax)
1400dec70:     	incq	%r11
1400dec73:     	addq	$0x140, %rax            # imm = 0x140
1400dec79:     	cmpq	%r11, %r8
1400dec7c:     	je	0x1400ded0e <.text+0xddd0e>
1400dec82:     	cmpq	%r9, %r11
1400dec85:     	setb	%bl
1400dec88:     	andb	(%rdx,%r11), %bl
1400dec8c:     	cmpb	$0x1, %bl
1400dec8f:     	jne	0x1400dec70 <.text+0xddc70>
1400dec91:     	cmpl	$0x2, -0x2c(%rax)
1400dec95:     	je	0x1400dec70 <.text+0xddc70>
1400dec97:     	cmpw	%r10w, (%rax)
1400dec9b:     	jne	0x1400dec70 <.text+0xddc70>
1400dec9d:     	cmpl	%r14d, -0xc(%rax)
1400deca1:     	jne	0x1400dec70 <.text+0xddc70>
1400deca3:     	movl	0x268(%rbp), %edi
1400deca9:     	cmpl	%edi, -0x8(%rax)
1400decac:     	jne	0x1400dec70 <.text+0xddc70>
1400decae:     	movzwl	0x26c(%rbp), %edi
1400decb5:     	cmpw	%di, -0x4(%rax)
1400decb9:     	jne	0x1400dec70 <.text+0xddc70>
1400decbb:     	movzbl	0x26f(%rbp), %ebx
1400decc2:     	cmpb	%bl, -0x2(%rax)
1400decc5:     	jne	0x1400dec70 <.text+0xddc70>
1400decc7:     	movq	-0x1c(%rax), %rdi
1400deccb:     	xorq	%r15, %rdi
1400decce:     	movq	-0x14(%rax), %rbx
1400decd2:     	xorq	0x258(%rbp), %rbx
1400decd9:     	orq	%rdi, %rbx
1400decdc:     	jne	0x1400dec70 <.text+0xddc70>
1400decde:     	cmpq	%r8, %r11
1400dece1:     	jae	0x1400ded0e <.text+0xddd0e>
1400dece3:     	cmpq	0x100(%rcx), %r11
1400decea:     	jae	0x1400decfa <.text+0xddcfa>
1400decec:     	movq	0xf8(%rcx), %r8
1400decf3:     	cmpb	$0x0, (%r8,%r11)
1400decf8:     	jne	0x1400ded0e <.text+0xddd0e>
1400decfa:     	movb	$0x0, (%rdx,%r11)
1400decff:     	decq	0x110(%rcx)
1400ded06:     	movq	$0x2, -0x2c(%rax)
1400ded0e:     	xorps	%xmm7, %xmm7
1400ded11:     	movaps	%xmm7, 0x230(%rbp)
1400ded18:     	movb	$0x0, 0x212(%rbp)
1400ded1f:     	movw	%r10w, 0x210(%rbp)
1400ded27:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
1400ded30:     	movq	$0x0, 0x213(%rbp)
1400ded3b:     	movq	$0x8, 0x1f0(%rbp)
1400ded46:     	movq	$0x0, 0x1f8(%rbp)
1400ded51:     	movq	$0x1, 0x200(%rbp)
1400ded5c:     	movq	$0x0, 0x208(%rbp)
1400ded67:     	leaq	0x220(%rbp), %rcx
1400ded6e:     	leaq	0x1f0(%rbp), %rdx
1400ded75:     	leaq	0x230(%rbp), %r8
1400ded7c:     	movl	$0x10, %r9d
1400ded82:     	callq	0x14015afc0 <.text+0x159fc0>
1400ded87:     	cmpb	$0x0, 0x220(%rbp)
1400ded8e:     	jne	0x1400deea0 <.text+0xddea0>
1400ded94:     	movq	0x228(%rbp), %rdi
1400ded9b:     	movaps	%xmm7, 0xe0(%rbp)
1400deda2:     	movaps	%xmm7, 0xf0(%rbp)
1400deda9:     	movaps	%xmm7, 0x100(%rbp)
1400dedb0:     	movaps	%xmm7, 0x110(%rbp)
1400dedb7:     	movaps	%xmm7, 0x120(%rbp)
1400dedbe:     	movaps	%xmm7, 0x130(%rbp)
1400dedc5:     	movaps	%xmm7, 0x140(%rbp)
1400dedcc:     	movaps	%xmm7, 0x150(%rbp)
1400dedd3:     	movaps	%xmm7, 0x160(%rbp)
1400dedda:     	movaps	%xmm7, 0x170(%rbp)
1400dede1:     	movaps	%xmm7, 0x180(%rbp)
1400dede8:     	movaps	%xmm7, 0x190(%rbp)
1400dedef:     	movaps	%xmm7, 0x1a0(%rbp)
1400dedf6:     	movaps	%xmm7, 0x1b0(%rbp)
1400dedfd:     	movaps	%xmm7, 0x1c0(%rbp)
1400dee04:     	movaps	%xmm7, 0x1d0(%rbp)
1400dee0b:     	cmpq	$0x11, %rdi
1400dee0f:     	jae	0x1400deec8 <.text+0xddec8>
1400dee15:     	leaq	0xe0(%rbp), %rbx
1400dee1c:     	leaq	0x230(%rbp), %rdx
1400dee23:     	movq	%rbx, %rcx
1400dee26:     	movq	%rdi, %r8
1400dee29:     	callq	0x1402d4830 <.text+0x2d3830>
1400dee2e:     	movw	%di, 0x1e0(%rbp)
1400dee35:     	movq	$0x0, -0x60(%rbp)
1400dee3d:     	movq	0x258(%rbp), %rax
1400dee44:     	movq	%rax, -0x48(%rbp)
1400dee48:     	movq	%r15, -0x50(%rbp)
1400dee4c:     	movl	%r14d, -0x40(%rbp)
1400dee50:     	movl	0x268(%rbp), %eax
1400dee56:     	movl	%eax, -0x3c(%rbp)
1400dee59:     	movzwl	0x26c(%rbp), %eax
1400dee60:     	movw	%ax, -0x38(%rbp)
1400dee64:     	movzbl	0x26f(%rbp), %eax
1400dee6b:     	movb	%al, -0x36(%rbp)
1400dee6e:     	movb	%r12b, -0x35(%rbp)
1400dee72:     	movd	%xmm6, -0x34(%rbp)
1400dee77:     	movq	0x260(%rbp), %rax
1400dee7e:     	movq	%rax, -0x30(%rbp)
1400dee82:     	leaq	-0x28(%rbp), %rcx
1400dee86:     	movl	$0x108, %r8d            # imm = 0x108
1400dee8c:     	movq	%rbx, %rdx
1400dee8f:     	callq	0x1402d4830 <.text+0x2d3830>
1400dee94:     	leaq	-0x60(%rbp), %rdx
1400dee98:     	movq	%rsi, %rcx
1400dee9b:     	callq	0x140011600 <.text+0x10600>
1400deea0:     	movb	$0x1, %al
1400deea2:     	jmp	0x1400deea6 <.text+0xddea6>
1400deea4:     	xorl	%eax, %eax
1400deea6:     	movaps	0x270(%rbp), %xmm6
1400deead:     	movaps	0x280(%rbp), %xmm7
1400deeb4:     	addq	$0x318, %rsp            # imm = 0x318
1400deebb:     	popq	%rbx
1400deebc:     	popq	%rdi
1400deebd:     	popq	%rsi
1400deebe:     	popq	%r12
1400deec0:     	popq	%r13
1400deec2:     	popq	%r14
1400deec4:     	popq	%r15
1400deec6:     	popq	%rbp
1400deec7:     	retq
1400deec8:     	leaq	0x216c89(%rip), %r9     # 0x1402f5b58
1400deecf:     	movl	$0x10, %r8d
1400deed5:     	xorl	%ecx, %ecx
1400deed7:     	movq	%rdi, %rdx
1400deeda:     	callq	0x1402d5280 <.text+0x2d4280>
1400deedf:     	ud2

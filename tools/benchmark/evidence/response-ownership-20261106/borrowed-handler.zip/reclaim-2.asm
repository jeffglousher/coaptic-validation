
D:\CoapticCurrent\borrowed-handler-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400de350:     	pushq	%rbp
1400de351:     	pushq	%r15
1400de353:     	pushq	%r14
1400de355:     	pushq	%r13
1400de357:     	pushq	%r12
1400de359:     	pushq	%rsi
1400de35a:     	pushq	%rdi
1400de35b:     	pushq	%rbx
1400de35c:     	subq	$0x318, %rsp            # imm = 0x318
1400de363:     	leaq	0x80(%rsp), %rbp
1400de36b:     	movaps	%xmm7, 0x280(%rbp)
1400de372:     	movaps	%xmm6, 0x270(%rbp)
1400de379:     	leaq	0x30(%rcx), %rdx
1400de37d:     	xorl	%r8d, %r8d
1400de380:     	xorl	%r11d, %r11d
1400de383:     	leaq	(%r11,%r11,4), %r10
1400de387:     	shlq	$0x6, %r10
1400de38b:     	addq	%rdx, %r10
1400de38e:     	movq	%r11, %r9
1400de391:     	jmp	0x1400de3b4 <.text+0xdd3b4>
1400de393:     	nopw	%cs:(%rax,%rax)
1400de3a0:     	incq	%r9
1400de3a3:     	addq	$0x140, %r10            # imm = 0x140
1400de3aa:     	cmpq	$0x4, %r9
1400de3ae:     	je	0x1400de43e <.text+0xdd43e>
1400de3b4:     	cmpb	$0x1, 0x510(%rcx,%r9)
1400de3bd:     	jne	0x1400de3a0 <.text+0xdd3a0>
1400de3bf:     	movq	-0x30(%r10), %rsi
1400de3c3:     	cmpq	$0x2, %rsi
1400de3c7:     	je	0x1400de3a0 <.text+0xdd3a0>
1400de3c9:     	movq	(%r10), %r11
1400de3cc:     	cmpl	$0x1, %esi
1400de3cf:     	setne	%bl
1400de3d2:     	testq	%r11, %r11
1400de3d5:     	sete	%sil
1400de3d9:     	orb	%bl, %sil
1400de3dc:     	cmpb	$0x1, %sil
1400de3e0:     	je	0x1400de3a0 <.text+0xdd3a0>
1400de3e2:     	movq	0x268(%rbp), %rsi
1400de3e9:     	cmpq	%rsi, %r11
1400de3ec:     	setae	%bl
1400de3ef:     	testb	%bl, %r8b
1400de3f2:     	jne	0x1400de424 <.text+0xdd424>
1400de3f4:     	movq	-0x28(%r10), %rax
1400de3f8:     	movd	-0x4(%r10), %xmm6
1400de3fe:     	movzbl	-0x5(%r10), %edi
1400de403:     	movzbl	-0x6(%r10), %r15d
1400de408:     	movzwl	-0x8(%r10), %r12d
1400de40d:     	movl	-0xc(%r10), %r13d
1400de411:     	movl	-0x10(%r10), %r14d
1400de415:     	movups	-0x20(%r10), %xmm0
1400de41a:     	movaps	%xmm0, 0x240(%rbp)
1400de421:     	movq	%r11, %rsi
1400de424:     	movq	%rsi, 0x268(%rbp)
1400de42b:     	leaq	0x1(%r9), %r11
1400de42f:     	movb	$0x1, %r8b
1400de432:     	cmpq	$0x3, %r9
1400de436:     	jb	0x1400de383 <.text+0xdd383>
1400de43c:     	jmp	0x1400de448 <.text+0xdd448>
1400de43e:     	testb	$0x1, %r8b
1400de442:     	je	0x1400de688 <.text+0xdd688>
1400de448:     	cmpq	$0x1, %rax
1400de44c:     	ja	0x1400de4a4 <.text+0xdd4a4>
1400de44e:     	cmpb	$0x1, 0x4420(%rcx,%rax)
1400de456:     	jne	0x1400de4a4 <.text+0xdd4a4>
1400de458:     	cmpb	$0x0, 0x4422(%rcx,%rax)
1400de460:     	jne	0x1400de4a4 <.text+0xdd4a4>
1400de462:     	movb	$0x0, 0x4420(%rcx,%rax)
1400de46a:     	decq	0x4418(%rcx)
1400de471:     	leaq	0x3a98(%rcx), %rdx
1400de478:     	movq	$0x0, 0x4398(%rcx,%rax,8)
1400de484:     	leaq	(%rax,%rax,8), %r8
1400de488:     	leaq	(%r8,%r8,2), %r8
1400de48c:     	addq	%rax, %r8
1400de48f:     	movb	$0x2, 0x95a(%rdx,%r8)
1400de498:     	leaq	(%rax,%rax,2), %rax
1400de49c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
1400de4a4:     	movaps	0x240(%rbp), %xmm0
1400de4ab:     	movaps	%xmm0, -0x60(%rbp)
1400de4af:     	movl	%r14d, %esi
1400de4b2:     	movl	%r14d, -0x50(%rbp)
1400de4b6:     	movl	%r13d, %r14d
1400de4b9:     	movl	%r13d, -0x4c(%rbp)
1400de4bd:     	movl	%r12d, %r13d
1400de4c0:     	movw	%r12w, -0x48(%rbp)
1400de4c5:     	movl	%r15d, %r12d
1400de4c8:     	movb	%r15b, -0x46(%rbp)
1400de4cc:     	movl	%edi, %r15d
1400de4cf:     	movb	%dil, -0x45(%rbp)
1400de4d3:     	movd	%xmm6, %edi
1400de4d7:     	movd	%xmm6, -0x44(%rbp)
1400de4dc:     	leaq	-0x60(%rbp), %rdx
1400de4e0:     	movq	%rcx, 0x260(%rbp)
1400de4e7:     	callq	0x14029aef0 <.text+0x299ef0>
1400de4ec:     	xorps	%xmm7, %xmm7
1400de4ef:     	movaps	%xmm7, 0x250(%rbp)
1400de4f6:     	movb	$0x0, 0x222(%rbp)
1400de4fd:     	movw	%di, 0x220(%rbp)
1400de504:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
1400de50d:     	movq	$0x0, 0x223(%rbp)
1400de518:     	movq	$0x8, 0x200(%rbp)
1400de523:     	movq	$0x0, 0x208(%rbp)
1400de52e:     	movq	$0x1, 0x210(%rbp)
1400de539:     	movq	$0x0, 0x218(%rbp)
1400de544:     	leaq	0x230(%rbp), %rcx
1400de54b:     	leaq	0x200(%rbp), %rdx
1400de552:     	leaq	0x250(%rbp), %r8
1400de559:     	movl	$0x10, %r9d
1400de55f:     	callq	0x14015afc0 <.text+0x159fc0>
1400de564:     	cmpb	$0x0, 0x230(%rbp)
1400de56b:     	jne	0x1400de684 <.text+0xdd684>
1400de571:     	movq	0x238(%rbp), %rdi
1400de578:     	movaps	%xmm7, 0xe0(%rbp)
1400de57f:     	movaps	%xmm7, 0xf0(%rbp)
1400de586:     	movaps	%xmm7, 0x100(%rbp)
1400de58d:     	movaps	%xmm7, 0x110(%rbp)
1400de594:     	movaps	%xmm7, 0x120(%rbp)
1400de59b:     	movaps	%xmm7, 0x130(%rbp)
1400de5a2:     	movaps	%xmm7, 0x140(%rbp)
1400de5a9:     	movaps	%xmm7, 0x150(%rbp)
1400de5b0:     	movaps	%xmm7, 0x160(%rbp)
1400de5b7:     	movaps	%xmm7, 0x170(%rbp)
1400de5be:     	movaps	%xmm7, 0x180(%rbp)
1400de5c5:     	movaps	%xmm7, 0x190(%rbp)
1400de5cc:     	movaps	%xmm7, 0x1a0(%rbp)
1400de5d3:     	movaps	%xmm7, 0x1b0(%rbp)
1400de5da:     	movaps	%xmm7, 0x1c0(%rbp)
1400de5e1:     	movaps	%xmm7, 0x1d0(%rbp)
1400de5e8:     	movaps	0x240(%rbp), %xmm0
1400de5ef:     	movups	%xmm0, 0x1f0(%rbp)
1400de5f6:     	cmpq	$0x11, %rdi
1400de5fa:     	jae	0x1400de6ac <.text+0xdd6ac>
1400de600:     	leaq	0xe0(%rbp), %rbx
1400de607:     	leaq	0x250(%rbp), %rdx
1400de60e:     	movq	%rbx, %rcx
1400de611:     	movq	%rdi, %r8
1400de614:     	callq	0x1402d4830 <.text+0x2d3830>
1400de619:     	movw	%di, 0x1e0(%rbp)
1400de620:     	movq	$0x0, -0x60(%rbp)
1400de628:     	movups	0x1e8(%rbp), %xmm0
1400de62f:     	movups	%xmm0, -0x58(%rbp)
1400de633:     	movq	0x1f8(%rbp), %rax
1400de63a:     	movq	%rax, -0x48(%rbp)
1400de63e:     	movl	%esi, -0x40(%rbp)
1400de641:     	movl	%r14d, -0x3c(%rbp)
1400de645:     	movw	%r13w, -0x38(%rbp)
1400de64a:     	movb	%r12b, -0x36(%rbp)
1400de64e:     	movb	%r15b, -0x35(%rbp)
1400de652:     	movd	%xmm6, -0x34(%rbp)
1400de657:     	movq	0x268(%rbp), %rax
1400de65e:     	movq	%rax, -0x30(%rbp)
1400de662:     	leaq	-0x28(%rbp), %rcx
1400de666:     	movl	$0x108, %r8d            # imm = 0x108
1400de66c:     	movq	%rbx, %rdx
1400de66f:     	callq	0x1402d4830 <.text+0x2d3830>
1400de674:     	leaq	-0x60(%rbp), %rdx
1400de678:     	movq	0x260(%rbp), %rcx
1400de67f:     	callq	0x14029ac60 <.text+0x299c60>
1400de684:     	movb	$0x1, %al
1400de686:     	jmp	0x1400de68a <.text+0xdd68a>
1400de688:     	xorl	%eax, %eax
1400de68a:     	movaps	0x270(%rbp), %xmm6
1400de691:     	movaps	0x280(%rbp), %xmm7
1400de698:     	addq	$0x318, %rsp            # imm = 0x318
1400de69f:     	popq	%rbx
1400de6a0:     	popq	%rdi
1400de6a1:     	popq	%rsi
1400de6a2:     	popq	%r12
1400de6a4:     	popq	%r13
1400de6a6:     	popq	%r14
1400de6a8:     	popq	%r15
1400de6aa:     	popq	%rbp
1400de6ab:     	retq
1400de6ac:     	leaq	0x2174a5(%rip), %r9     # 0x1402f5b58
1400de6b3:     	movl	$0x10, %r8d
1400de6b9:     	xorl	%ecx, %ecx
1400de6bb:     	movq	%rdi, %rdx
1400de6be:     	callq	0x1402d5280 <.text+0x2d4280>
1400de6c3:     	ud2

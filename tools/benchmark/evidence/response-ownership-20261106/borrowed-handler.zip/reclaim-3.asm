
D:\CoapticCurrent\borrowed-handler-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400de6d0:     	pushq	%rbp
1400de6d1:     	pushq	%r15
1400de6d3:     	pushq	%r14
1400de6d5:     	pushq	%r13
1400de6d7:     	pushq	%r12
1400de6d9:     	pushq	%rsi
1400de6da:     	pushq	%rdi
1400de6db:     	pushq	%rbx
1400de6dc:     	subq	$0x308, %rsp            # imm = 0x308
1400de6e3:     	leaq	0x80(%rsp), %rbp
1400de6eb:     	movaps	%xmm7, 0x270(%rbp)
1400de6f2:     	movaps	%xmm6, 0x260(%rbp)
1400de6f9:     	leaq	0x5000(%rcx), %rax
1400de700:     	leaq	0x30(%rcx), %r8
1400de704:     	xorl	%r9d, %r9d
1400de707:     	xorl	%esi, %esi
1400de709:     	leaq	(%rsi,%rsi,4), %r11
1400de70d:     	shlq	$0x6, %r11
1400de711:     	addq	%r8, %r11
1400de714:     	movq	%rsi, %r10
1400de717:     	jmp	0x1400de734 <.text+0xdd734>
1400de719:     	nopl	(%rax)
1400de720:     	incq	%r10
1400de723:     	addq	$0x140, %r11            # imm = 0x140
1400de72a:     	cmpq	$0x40, %r10
1400de72e:     	je	0x1400de7ce <.text+0xdd7ce>
1400de734:     	cmpb	$0x1, 0x5000(%rcx,%r10)
1400de73d:     	jne	0x1400de720 <.text+0xdd720>
1400de73f:     	movq	-0x30(%r11), %rdi
1400de743:     	cmpq	$0x2, %rdi
1400de747:     	je	0x1400de720 <.text+0xdd720>
1400de749:     	movq	(%r11), %rsi
1400de74c:     	cmpl	$0x1, %edi
1400de74f:     	setne	%bl
1400de752:     	testq	%rsi, %rsi
1400de755:     	sete	%dil
1400de759:     	orb	%bl, %dil
1400de75c:     	cmpb	$0x1, %dil
1400de760:     	je	0x1400de720 <.text+0xdd720>
1400de762:     	movq	0x250(%rbp), %rdi
1400de769:     	cmpq	%rdi, %rsi
1400de76c:     	setae	%bl
1400de76f:     	testb	%bl, %r9b
1400de772:     	jne	0x1400de7b4 <.text+0xdd7b4>
1400de774:     	movd	-0x4(%r11), %xmm6
1400de77a:     	movzbl	-0x5(%r11), %edx
1400de77f:     	movb	%dl, 0x25f(%rbp)
1400de785:     	movzbl	-0x6(%r11), %r15d
1400de78a:     	movzwl	-0x8(%r11), %r12d
1400de78f:     	movl	-0xc(%r11), %r13d
1400de793:     	movl	-0x10(%r11), %r14d
1400de797:     	movq	-0x18(%r11), %rdx
1400de79b:     	movq	%rdx, 0x248(%rbp)
1400de7a2:     	movq	-0x28(%r11), %rdx
1400de7a6:     	movq	-0x20(%r11), %r9
1400de7aa:     	movq	%r9, 0x240(%rbp)
1400de7b1:     	movq	%rsi, %rdi
1400de7b4:     	movq	%rdi, 0x250(%rbp)
1400de7bb:     	leaq	0x1(%r10), %rsi
1400de7bf:     	movb	$0x1, %r9b
1400de7c2:     	cmpq	$0x3f, %r10
1400de7c6:     	jb	0x1400de709 <.text+0xdd709>
1400de7cc:     	jmp	0x1400de7d8 <.text+0xdd7d8>
1400de7ce:     	testb	$0x1, %r9b
1400de7d2:     	je	0x1400dea50 <.text+0xdda50>
1400de7d8:     	cmpq	$0x1f, %rdx
1400de7dc:     	ja	0x1400de82f <.text+0xdd82f>
1400de7de:     	leaq	0x37740(%rcx), %r8
1400de7e5:     	cmpb	$0x1, (%r8,%rdx)
1400de7ea:     	jne	0x1400de82f <.text+0xdd82f>
1400de7ec:     	cmpb	$0x0, 0x37760(%rcx,%rdx)
1400de7f4:     	jne	0x1400de82f <.text+0xdd82f>
1400de7f6:     	movb	$0x0, 0x37740(%rcx,%rdx)
1400de7fe:     	decq	0x37788(%rcx)
1400de805:     	movq	$0x0, 0x43610(%rcx,%rdx,8)
1400de811:     	leaq	(%rdx,%rdx,8), %r9
1400de815:     	leaq	(%r9,%r9,2), %r9
1400de819:     	addq	%rdx, %r9
1400de81c:     	movb	$0x2, 0x36a(%r8,%r9)
1400de825:     	leaq	(%rdx,%rdx,2), %rdx
1400de829:     	movb	$0x2, 0x5d(%r8,%rdx,8)
1400de82f:     	movd	%xmm6, %edx
1400de833:     	movl	$0x2c, %r8d
1400de839:     	movq	0x240(%rbp), %r11
1400de840:     	movq	0x248(%rbp), %rsi
1400de847:     	jmp	0x1400de863 <.text+0xdd863>
1400de849:     	nopl	(%rax)
1400de850:     	incq	%rax
1400de853:     	addq	$0x140, %r8             # imm = 0x140
1400de85a:     	cmpq	$0x502c, %r8            # imm = 0x502C
1400de861:     	je	0x1400de8bc <.text+0xdd8bc>
1400de863:     	cmpb	$0x1, (%rax)
1400de866:     	jne	0x1400de850 <.text+0xdd850>
1400de868:     	cmpl	$0x2, -0x2c(%rcx,%r8)
1400de86e:     	je	0x1400de850 <.text+0xdd850>
1400de870:     	cmpw	%dx, (%rcx,%r8)
1400de875:     	jne	0x1400de850 <.text+0xdd850>
1400de877:     	cmpl	%r14d, -0xc(%rcx,%r8)
1400de87c:     	jne	0x1400de850 <.text+0xdd850>
1400de87e:     	cmpl	%r13d, -0x8(%rcx,%r8)
1400de883:     	jne	0x1400de850 <.text+0xdd850>
1400de885:     	cmpw	%r12w, -0x4(%rcx,%r8)
1400de88b:     	jne	0x1400de850 <.text+0xdd850>
1400de88d:     	cmpb	%r15b, -0x2(%rcx,%r8)
1400de892:     	jne	0x1400de850 <.text+0xdd850>
1400de894:     	movq	-0x1c(%rcx,%r8), %r9
1400de899:     	xorq	%r11, %r9
1400de89c:     	movq	-0x14(%rcx,%r8), %r10
1400de8a1:     	xorq	%rsi, %r10
1400de8a4:     	orq	%r9, %r10
1400de8a7:     	jne	0x1400de850 <.text+0xdd850>
1400de8a9:     	movb	$0x0, (%rax)
1400de8ac:     	decq	0x5048(%rcx)
1400de8b3:     	movq	$0x2, -0x2c(%rcx,%r8)
1400de8bc:     	movq	%rcx, %rsi
1400de8bf:     	xorps	%xmm7, %xmm7
1400de8c2:     	movaps	%xmm7, 0x230(%rbp)
1400de8c9:     	movb	$0x0, 0x212(%rbp)
1400de8d0:     	movw	%dx, 0x210(%rbp)
1400de8d7:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
1400de8e0:     	movq	$0x0, 0x213(%rbp)
1400de8eb:     	movq	$0x8, 0x1f0(%rbp)
1400de8f6:     	movq	$0x0, 0x1f8(%rbp)
1400de901:     	movq	$0x1, 0x200(%rbp)
1400de90c:     	movq	$0x0, 0x208(%rbp)
1400de917:     	leaq	0x220(%rbp), %rcx
1400de91e:     	leaq	0x1f0(%rbp), %rdx
1400de925:     	leaq	0x230(%rbp), %r8
1400de92c:     	movl	$0x10, %r9d
1400de932:     	callq	0x14015afc0 <.text+0x159fc0>
1400de937:     	cmpb	$0x0, 0x220(%rbp)
1400de93e:     	jne	0x1400dea4c <.text+0xdda4c>
1400de944:     	movq	0x228(%rbp), %rdi
1400de94b:     	movaps	%xmm7, 0xe0(%rbp)
1400de952:     	movaps	%xmm7, 0xf0(%rbp)
1400de959:     	movaps	%xmm7, 0x100(%rbp)
1400de960:     	movaps	%xmm7, 0x110(%rbp)
1400de967:     	movaps	%xmm7, 0x120(%rbp)
1400de96e:     	movaps	%xmm7, 0x130(%rbp)
1400de975:     	movaps	%xmm7, 0x140(%rbp)
1400de97c:     	movaps	%xmm7, 0x150(%rbp)
1400de983:     	movaps	%xmm7, 0x160(%rbp)
1400de98a:     	movaps	%xmm7, 0x170(%rbp)
1400de991:     	movaps	%xmm7, 0x180(%rbp)
1400de998:     	movaps	%xmm7, 0x190(%rbp)
1400de99f:     	movaps	%xmm7, 0x1a0(%rbp)
1400de9a6:     	movaps	%xmm7, 0x1b0(%rbp)
1400de9ad:     	movaps	%xmm7, 0x1c0(%rbp)
1400de9b4:     	movaps	%xmm7, 0x1d0(%rbp)
1400de9bb:     	cmpq	$0x11, %rdi
1400de9bf:     	jae	0x1400dea74 <.text+0xdda74>
1400de9c5:     	leaq	0xe0(%rbp), %rbx
1400de9cc:     	leaq	0x230(%rbp), %rdx
1400de9d3:     	movq	%rbx, %rcx
1400de9d6:     	movq	%rdi, %r8
1400de9d9:     	callq	0x1402d4830 <.text+0x2d3830>
1400de9de:     	movw	%di, 0x1e0(%rbp)
1400de9e5:     	movq	$0x0, -0x60(%rbp)
1400de9ed:     	movq	0x248(%rbp), %rax
1400de9f4:     	movq	%rax, -0x48(%rbp)
1400de9f8:     	movq	0x240(%rbp), %rax
1400de9ff:     	movq	%rax, -0x50(%rbp)
1400dea03:     	movl	%r14d, -0x40(%rbp)
1400dea07:     	movl	%r13d, -0x3c(%rbp)
1400dea0b:     	movw	%r12w, -0x38(%rbp)
1400dea10:     	movb	%r15b, -0x36(%rbp)
1400dea14:     	movzbl	0x25f(%rbp), %eax
1400dea1b:     	movb	%al, -0x35(%rbp)
1400dea1e:     	movd	%xmm6, -0x34(%rbp)
1400dea23:     	movq	0x250(%rbp), %rax
1400dea2a:     	movq	%rax, -0x30(%rbp)
1400dea2e:     	leaq	-0x28(%rbp), %rcx
1400dea32:     	movl	$0x108, %r8d            # imm = 0x108
1400dea38:     	movq	%rbx, %rdx
1400dea3b:     	callq	0x1402d4830 <.text+0x2d3830>
1400dea40:     	leaq	-0x60(%rbp), %rdx
1400dea44:     	movq	%rsi, %rcx
1400dea47:     	callq	0x14029aac0 <.text+0x299ac0>
1400dea4c:     	movb	$0x1, %al
1400dea4e:     	jmp	0x1400dea52 <.text+0xdda52>
1400dea50:     	xorl	%eax, %eax
1400dea52:     	movaps	0x260(%rbp), %xmm6
1400dea59:     	movaps	0x270(%rbp), %xmm7
1400dea60:     	addq	$0x308, %rsp            # imm = 0x308
1400dea67:     	popq	%rbx
1400dea68:     	popq	%rdi
1400dea69:     	popq	%rsi
1400dea6a:     	popq	%r12
1400dea6c:     	popq	%r13
1400dea6e:     	popq	%r14
1400dea70:     	popq	%r15
1400dea72:     	popq	%rbp
1400dea73:     	retq
1400dea74:     	leaq	0x2170dd(%rip), %r9     # 0x1402f5b58
1400dea7b:     	movl	$0x10, %r8d
1400dea81:     	xorl	%ecx, %ecx
1400dea83:     	movq	%rdi, %rdx
1400dea86:     	callq	0x1402d5280 <.text+0x2d4280>
1400dea8b:     	ud2

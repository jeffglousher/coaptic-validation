from pathlib import Path
import subprocess,os,json
r=Path(__file__).resolve().parent
p=r'D:/CoapticCurrent/esphome-venv/Scripts/python.exe'
for name in ['build.py','inspect.py','layout32/audit.py']:
 with (r/('stage-'+Path(name).stem+'-2.log')).open('wb') as out:
  result=subprocess.run([p,'-B',str(r/name)],stdout=out,stderr=subprocess.STDOUT)
 print(name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)

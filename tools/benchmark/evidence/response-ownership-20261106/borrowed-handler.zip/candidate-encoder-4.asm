
D:\CoapticCurrent\borrowed-handler-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14006b2a0:     	pushq	%rbp
14006b2a1:     	pushq	%r15
14006b2a3:     	pushq	%r14
14006b2a5:     	pushq	%r13
14006b2a7:     	pushq	%r12
14006b2a9:     	pushq	%rsi
14006b2aa:     	pushq	%rdi
14006b2ab:     	pushq	%rbx
14006b2ac:     	subq	$0x4f8, %rsp            # imm = 0x4F8
14006b2b3:     	leaq	0x80(%rsp), %rbp
14006b2bb:     	movq	%r9, %rbx
14006b2be:     	movq	%r8, %r14
14006b2c1:     	movq	%rdx, %rdi
14006b2c4:     	movq	%rcx, %rsi
14006b2c7:     	movq	0x4f0(%rbp), %r12
14006b2ce:     	leaq	-0x10(%rbp), %rcx
14006b2d2:     	movl	$0x400, %r8d            # imm = 0x400
14006b2d8:     	xorl	%edx, %edx
14006b2da:     	callq	0x1402d4842 <.text+0x2d3842>
14006b2df:     	movq	0x8(%r12), %r13
14006b2e4:     	movl	$0x3, %eax
14006b2e9:     	cmpq	$0x3, %r13
14006b2ed:     	ja	0x14006b50c <.text+0x6a50c>
14006b2f3:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
14006b2fc:     	jne	0x14006b50c <.text+0x6a50c>
14006b302:     	movq	0x2b750(%rdi,%r13,8), %rdx
14006b30a:     	cmpq	$0x4001, %rdx           # imm = 0x4001
14006b311:     	jae	0x14006b568 <.text+0x6a568>
14006b317:     	movq	0x10(%r12), %rcx
14006b31c:     	movq	0x18(%r12), %r15
14006b321:     	movq	%r15, %r8
14006b324:     	movl	$0xb, %eax
14006b329:     	addq	%rcx, %r8
14006b32c:     	jb	0x14006b50c <.text+0x6a50c>
14006b332:     	cmpq	$0x400, %r15            # imm = 0x400
14006b339:     	ja	0x14006b50c <.text+0x6a50c>
14006b33f:     	cmpq	%rdx, %r8
14006b342:     	ja	0x14006b50c <.text+0x6a50c>
14006b348:     	movq	%r13, %rax
14006b34b:     	shlq	$0xe, %rax
14006b34f:     	leaq	(%rdi,%rax), %rdx
14006b353:     	addq	$0x1b750, %rdx          # imm = 0x1B750
14006b35a:     	addq	%rcx, %rdx
14006b35d:     	leaq	-0x10(%rbp), %rcx
14006b361:     	movq	%r15, %r8
14006b364:     	callq	0x1402d4830 <.text+0x2d3830>
14006b369:     	cmpb	$0x0, 0x4f8(%rbp)
14006b370:     	je	0x14006b388 <.text+0x6a388>
14006b372:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
14006b379:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
14006b382:     	jne	0x14006b527 <.text+0x6a527>
14006b388:     	movq	$0x0, 0x470(%rbp)
14006b393:     	movq	%rdi, %rcx
14006b396:     	callq	0x1400dabe0 <.text+0xd9be0>
14006b39b:     	testb	$0x1, %al
14006b39d:     	je	0x14006b55a <.text+0x6a55a>
14006b3a3:     	movq	%rdx, %r13
14006b3a6:     	movq	0x500(%rbp), %rdx
14006b3ad:     	movzwl	0x4e8(%rbp), %ecx
14006b3b4:     	movzbl	0x4e0(%rbp), %eax
14006b3bb:     	movq	(%r12), %r8
14006b3bf:     	movq	0x470(%rbp), %r9
14006b3c6:     	movq	%r9, 0x438(%rbp)
14006b3cd:     	movq	0x468(%rbp), %r9
14006b3d4:     	movq	%r9, 0x440(%rbp)
14006b3db:     	movq	%r8, 0x448(%rbp)
14006b3e2:     	movzbl	0x4f8(%rbp), %r8d
14006b3ea:     	movb	%r8b, 0x450(%rbp)
14006b3f1:     	movups	0x60(%r14), %xmm0
14006b3f6:     	movups	0x6c(%r14), %xmm1
14006b3fb:     	movups	%xmm1, 0x3fc(%rbp)
14006b402:     	movaps	%xmm0, 0x3f0(%rbp)
14006b409:     	leaq	0x8e(%r14), %r8
14006b410:     	movq	0x7e(%r14), %r9
14006b414:     	movq	0x85(%r14), %r10
14006b41b:     	movq	%r10, 0x45f(%rbp)
14006b422:     	movq	%r9, 0x458(%rbp)
14006b429:     	leaq	0x458(%rbp), %r9
14006b430:     	movq	%r9, 0x68(%rsp)
14006b435:     	movq	%rdx, 0x60(%rsp)
14006b43a:     	movq	%r14, 0x58(%rsp)
14006b43f:     	leaq	0x438(%rbp), %rdx
14006b446:     	movq	%rdx, 0x50(%rsp)
14006b44b:     	movq	%r15, 0x48(%rsp)
14006b450:     	leaq	-0x10(%rbp), %rdx
14006b454:     	movq	%rdx, 0x40(%rsp)
14006b459:     	movq	%rbx, 0x38(%rsp)
14006b45e:     	movq	%r8, 0x30(%rsp)
14006b463:     	movw	%cx, 0x28(%rsp)
14006b468:     	movb	%al, 0x20(%rsp)
14006b46c:     	leaq	0x418(%rbp), %rcx
14006b473:     	leaq	0x3f0(%rbp), %r8
14006b47a:     	movq	%rdi, %rdx
14006b47d:     	movq	%r13, %r9
14006b480:     	callq	0x1400b8b90 <.text+0xb7b90>
14006b485:     	cmpb	$-0x1, 0x418(%rbp)
14006b48c:     	je	0x14006b55f <.text+0x6a55f>
14006b492:     	cmpb	$0x1, 0x37740(%rdi,%r13)
14006b49b:     	jne	0x14006b4f5 <.text+0x6a4f5>
14006b49d:     	cmpb	$0x0, 0x37760(%rdi,%r13)
14006b4a6:     	jne	0x14006b4f5 <.text+0x6a4f5>
14006b4a8:     	movb	$0x0, 0x37740(%rdi,%r13)
14006b4b1:     	decq	0x37788(%rdi)
14006b4b8:     	leaq	0x37740(%rdi), %rax
14006b4bf:     	movq	$0x0, 0x43610(%rdi,%r13,8)
14006b4cb:     	leaq	(,%r13,8), %rcx
14006b4d3:     	addq	%r13, %rcx
14006b4d6:     	leaq	(%rcx,%rcx,2), %rcx
14006b4da:     	addq	%r13, %rcx
14006b4dd:     	movb	$0x2, 0x36a(%rax,%rcx)
14006b4e5:     	leaq	(,%r13,2), %rcx
14006b4ed:     	addq	%r13, %rcx
14006b4f0:     	movb	$0x2, 0x5d(%rax,%rcx,8)
14006b4f5:     	movups	0x418(%rbp), %xmm0
14006b4fc:     	movups	0x428(%rbp), %xmm1
14006b503:     	movups	%xmm1, 0x10(%rsi)
14006b507:     	movups	%xmm0, (%rsi)
14006b50a:     	jmp	0x14006b513 <.text+0x6a513>
14006b50c:     	movb	$0xa, (%rsi)
14006b50f:     	movq	%rax, 0x8(%rsi)
14006b513:     	addq	$0x4f8, %rsp            # imm = 0x4F8
14006b51a:     	popq	%rbx
14006b51b:     	popq	%rdi
14006b51c:     	popq	%rsi
14006b51d:     	popq	%r12
14006b51f:     	popq	%r13
14006b521:     	popq	%r14
14006b523:     	popq	%r15
14006b525:     	popq	%rbp
14006b526:     	retq
14006b527:     	addq	%rdi, %rax
14006b52a:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
14006b530:     	movq	0x98(%rax), %rax
14006b537:     	movq	%rax, 0x468(%rbp)
14006b53e:     	movl	$0x1, %eax
14006b543:     	movq	%rax, 0x470(%rbp)
14006b54a:     	movq	%rdi, %rcx
14006b54d:     	callq	0x1400dabe0 <.text+0xd9be0>
14006b552:     	testb	$0x1, %al
14006b554:     	jne	0x14006b3a3 <.text+0x6a3a3>
14006b55a:     	movb	$0x9, (%rsi)
14006b55d:     	jmp	0x14006b513 <.text+0x6a513>
14006b55f:     	movq	%r13, 0x8(%rsi)
14006b563:     	movb	$-0x1, (%rsi)
14006b566:     	jmp	0x14006b513 <.text+0x6a513>
14006b568:     	leaq	0x28d799(%rip), %r9     # 0x1402f8d08
14006b56f:     	movl	$0x4000, %r8d           # imm = 0x4000
14006b575:     	xorl	%ecx, %ecx
14006b577:     	callq	0x1402d5280 <.text+0x2d4280>
14006b57c:     	ud2

//! Temporary host diagnostic, never a production API or acceptance build.
use core::sync::atomic::{AtomicU64, Ordering};
use std::sync::OnceLock;
static CLOCK: OnceLock<fn() -> u64> = OnceLock::new();
static CYCLES: [AtomicU64; 4] = [const { AtomicU64::new(0) }; 4];
static CALLS: [AtomicU64; 4] = [const { AtomicU64::new(0) }; 4];
pub fn set_clock(clock: fn() -> u64) { assert!(CLOCK.set(clock).is_ok()); }
fn now() -> u64 { CLOCK.get().expect("diagnostic clock")() }
pub struct Guard { kind: usize, start: u64 }
impl Guard {
    pub fn begin(kind: usize, selected: bool) -> Option<Self> {
        selected.then(|| Self { kind, start: now() })
    }
}
impl Drop for Guard {
    fn drop(&mut self) {
        let elapsed = now().checked_sub(self.start).expect("thread clock regressed");
        CYCLES[self.kind].fetch_add(elapsed, Ordering::Relaxed);
        CALLS[self.kind].fetch_add(1, Ordering::Relaxed);
    }
}
pub fn snapshot() -> [[u64; 2]; 4] {
    core::array::from_fn(|i| [CYCLES[i].load(Ordering::Relaxed), CALLS[i].load(Ordering::Relaxed)])
}
pub fn empty_intervals() -> u64 {
    let mut sum = 0;
    for _ in 0..4096 { let start = now(); sum += now() - start; }
    sum
}

static WIRE_MIN: AtomicU64 = AtomicU64::new(u64::MAX);
static WIRE_MAX: AtomicU64 = AtomicU64::new(0);
static WIRE_COUNT: AtomicU64 = AtomicU64::new(0);
pub fn record_wire(len: usize) {
 WIRE_MIN.fetch_min(len as u64, Ordering::Relaxed);
 WIRE_MAX.fetch_max(len as u64, Ordering::Relaxed);
 WIRE_COUNT.fetch_add(1, Ordering::Relaxed);
}
pub fn wire_lengths() -> [u64;3] { [WIRE_MIN.load(Ordering::Relaxed), WIRE_MAX.load(Ordering::Relaxed), WIRE_COUNT.load(Ordering::Relaxed)] }

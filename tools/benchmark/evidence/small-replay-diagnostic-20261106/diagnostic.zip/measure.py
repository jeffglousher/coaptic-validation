from pathlib import Path
import subprocess, json, os, time, hashlib, statistics, math, psutil
r=Path(__file__).resolve().parent
assert not (r/'result.json').exists()
cells=[(mode,security) for mode in ['sync','async'] for security in ['unprotected','oscore']]
method={'purpose':'Diagnostic only; no production qualification or repeated acceptance hypothesis','sources':{'A':'bd63199b652193b4c0a882e5840e72d992cf1362','B':'6760b72a8ed07b6a108cde24eeb36e552a0f076d'},'cells':cells,'storage':'SmallDevice fixed, unchanged4 replay rows','operations':1024,'warmup':128,'pairs':16,'orders':['AB','BA','BA','AB']*4,'cpu':0,'phases':['store','construct_replay','lookup','expiry'],'counter':'Existing QueryThreadCycleTime passed as safe function pointer; RAII inclusive phase intervals; SmallDevice server only, no client App','limits':'Phase counts/sums include128 warmups; outer App samples exclude warmup. Clock/call overhead retained. Do not sum nested phases or infer uninstrumented CPU shares. Instrumentation changes code placement and execution. No replacement samples. Original black_box denotes optimizer barriers, not absence of instrumentation. Wire lengths recorded during response verification outside outer App clock.','empty_intervals':4096,'binaries':{a:hashlib.sha256((r/a/'dispatch-probe.exe').read_bytes()).hexdigest() for a in 'AB'}}
(r/'METHOD.json').write_text(json.dumps(method,indent=2)+'\n')
rows=[];events=[];proc=psutil.Process();affinity=proc.cpu_affinity();proc.cpu_affinity([0]);started=time.monotonic()
try:
    for pair,order in enumerate(method['orders']):
        for mode,security in cells:
            values={}
            for arm in order:
                env=dict(os.environ);env.pop('COAPTIC_DISPATCH_ASYNC',None)
                if mode=='async':env['COAPTIC_DISPATCH_ASYNC']='1'
                label=f'{pair}-{mode}-{security}-{arm}'
                with (r/(label+'.json')).open('wb') as out,(r/(label+'.stderr')).open('wb') as err:
                    child=subprocess.run([str(r/arm/'dispatch-probe.exe'),'1024',security,'--small-device'],env=env,stdout=out,stderr=err,timeout=15)
                events.append({'label':label,'exit_code':child.returncode});assert child.returncode==0
                v=json.loads((r/(label+'.json')).read_bytes())
                assert v['operations']==1024 and v['verified']==1152 and v['dedup']==4 and v['payload_bytes']==32
                assert len(v['phase_cost_including_warmup'])==4
                assert 0<v['wire_lengths_min_max_count'][0]<=v['wire_lengths_min_max_count'][1]<=1152
                assert v['wire_lengths_min_max_count'][2]==1152
                values[arm]=v
            for key in ['routes','calls','deferred','associations','security_requests','blockwise','rx_slots','tx_slots','rx_datagram_bytes','tx_datagram_bytes','dedup','observe','rx_body_slots','tx_body_slots']:
                assert values['A'][key]==values['B'][key]
            row={'pair':pair,'mode':mode,'security':security,'phases':{}}
            for i,name in enumerate(method['phases']):
                a,b=[values[arm]['phase_cost_including_warmup'][i] for arm in 'AB']
                assert a[1]>0 and b[1]>0
                row['phases'][name]={'A_calls':a[1],'B_calls':b[1],'A_cycles_per_call':a[0]/a[1],'B_cycles_per_call':b[0]/b[1],'ratio':(b[0]/b[1])/(a[0]/a[1])}
            row['empty_interval_cycles']={a:values[a]['phase_empty_4096_cycles']/4096 for a in 'AB'}
            row['instrumented_App_mean_cycles']={a:statistics.mean(values[a]['latencies_cycles']) for a in 'AB'}
            row['wire_lengths_min_max_count']={a:values[a]['wire_lengths_min_max_count'] for a in 'AB'}
            rows.append(row)
    summary=[]
    for mode,security in cells:
        subset=[v for v in rows if v['mode']==mode and v['security']==security]
        for name in method['phases']:
            summary.append({'mode':mode,'security':security,'phase':name,'A_mean_cycles_per_call':statistics.mean(v['phases'][name]['A_cycles_per_call'] for v in subset),'B_mean_cycles_per_call':statistics.mean(v['phases'][name]['B_cycles_per_call'] for v in subset),'paired_geomean_ratio':math.exp(statistics.mean(math.log(v['phases'][name]['ratio']) for v in subset)),'A_call_counts':sorted({v['phases'][name]['A_calls'] for v in subset}),'B_call_counts':sorted({v['phases'][name]['B_calls'] for v in subset})})
    result={'status':'complete','rows':rows,'summary':summary,'process_exits':events,'seconds':time.monotonic()-started,'acceptance_claim':False}
    (r/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(summary,indent=2))
except BaseException as error:
    (r/'result.json').write_text(json.dumps({'status':'failed','error':str(error),'rows':rows,'process_exits':events},indent=2)+'\n');raise
finally:
    proc.cpu_affinity(affinity)

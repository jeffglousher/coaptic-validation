from pathlib import Path
import subprocess, json, os, shutil, hashlib, difflib
r=Path(__file__).resolve().parent
repo=Path('C:/Users/jeffg/.t3/worktrees/coaptic/t3-a578955c')
fixture=Path('D:/CoapticCurrent/replay-active-copy-20261105/fixture')
core=fixture/'coaptic'
prior=Path('D:/CoapticCurrent/short-inline-replay-20261106/active-bytes')
verification=json.loads((prior/'source-verification.json').read_text())
names=list(verification['source_file_hashes'])
candidate=verification['source'];baseline=verification['baseline']
bench=fixture/'tools/benchmark/native/servers/src/bin/bench-core.rs'
original_bench=bench.read_bytes()
assert hashlib.sha256(original_bench).hexdigest()==json.loads((prior/'fixture-sha256.json').read_text())['bench-core.rs']
assert not (core/'src/cost_probe.rs').exists()
wrapper=str(Path.home()/'.cargo/bin/agent-resources.exe')
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR='D:/coaptic-batch-interop-target',RUSTFLAGS='-Cforce-frame-pointers=yes')
env.pop('RUSTC_BOOTSTRAP',None)
results=[]
def overlay(sha):
    hashes={}
    for name in names:
        data=subprocess.check_output(['git','-C',str(repo),'show',sha+':'+name]).replace(b'\r\n',b'\n')
        p=core/name
        if p.read_bytes()!=data:p.write_bytes(data)
        hashes[name]=hashlib.sha256(data).hexdigest()
    return hashes
try:
    for arm,sha in [('A',baseline),('B',candidate)]:
        hashes=overlay(sha)
        originals={n:(core/n).read_text(encoding='utf-8') for n in ['src/lib.rs','src/storage/memory.rs','src/storage/table.rs','src/app/mod.rs']}
        (core/'src/lib.rs').write_text(originals['src/lib.rs']+'\n#[cfg(feature = "std")]\npub mod cost_probe;\n',encoding='utf-8')
        s=originals['src/storage/memory.rs']
        needle='    fn try_store_app_dedup(&mut self, entry: DedupEntry) -> Option<bool> {\n';assert s.count(needle)==1
        s=s.replace(needle,needle+'        let _cost = crate::cost_probe::Guard::begin(0, true);\n')
        (core/'src/storage/memory.rs').write_text(s,encoding='utf-8')
        s=originals['src/storage/table.rs']
        for needle,index in [('    pub fn with_replay(mut self, bytes: &[u8]) -> Self {\n',1),('    pub fn lookup(&self, key: DedupKey) -> Option<SlotId> {\n',2)]:
            assert s.count(needle)==1
            s=s.replace(needle,needle+f'        let _cost = crate::cost_probe::Guard::begin({index}, true);\n')
        (core/'src/storage/table.rs').write_text(s,encoding='utf-8')
        s=originals['src/app/mod.rs'];start=s.index('fn expire_request_dedup<');body=s.index('{\n',start)+2
        s=s[:body]+'    let _cost = crate::cost_probe::Guard::begin(3, true);\n'+s[body:]
        (core/'src/app/mod.rs').write_text(s,encoding='utf-8')
        shutil.copyfile(r/'cost_probe.rs',core/'src/cost_probe.rs')
        b=original_bench.decode('utf-8').replace('\r\n','\n')
        needle='fn main() -> Result<(), Failure> {\n';assert b.count(needle)==1
        b=b.replace(needle,needle+'    coaptic::cost_probe::set_clock(|| thread_cycles().expect("clock").try_into().unwrap());\n')
        needle='        print!("],");\n        small_device_ledger(';assert b.count(needle)==1
        b=b.replace(needle,'        print!("],\\\"phase_cost_including_warmup\\\":{:?},\\\"phase_empty_4096_cycles\\\":{},\\\"wire_lengths_min_max_count\\\":{:?},", coaptic::cost_probe::snapshot(), coaptic::cost_probe::empty_intervals(), coaptic::cost_probe::wire_lengths());\n        small_device_ledger(')
        needle='    let n = io.output_len.take().ok_or("missing response")?;\n';assert needle in b
        b=b.replace(needle,needle+'    coaptic::cost_probe::record_wire(n);\n',1)
        bench.write_text(b,encoding='utf-8')
        patch=''.join(''.join(difflib.unified_diff(originals[n].splitlines(True),(core/n).read_text(encoding='utf-8').splitlines(True),fromfile='a/'+n,tofile='b/'+n)) for n in originals)
        (r/arm/'instrumentation.patch').write_text(patch,encoding='utf-8')
        (r/arm/'probe.patch').write_text(''.join(difflib.unified_diff(original_bench.decode().splitlines(True),b.splitlines(True),fromfile='a/bench-core.rs',tofile='b/bench-core.rs')),encoding='utf-8')
        (r/arm/'source.json').write_text(json.dumps({'source':sha,'base_hashes':hashes,'instrumented_hashes':{n:hashlib.sha256((core/n).read_bytes()).hexdigest() for n in [*originals,'src/cost_probe.rs']},'probe_sha256':hashlib.sha256(bench.read_bytes()).hexdigest()},indent=2)+'\n')
        cmd=[wrapper,'run','--id','coaptic-core-reusable','--directory',str(fixture/'probe'),'--','cargo','build','--locked','--offline','--release','--bin','dispatch-probe']
        with (r/arm/'build.log').open('wb') as log:p=subprocess.run(cmd,cwd=fixture/'probe',env=env,stdout=log,stderr=subprocess.STDOUT)
        results.append({'arm':arm,'source':sha,'exit_code':p.returncode,'command':cmd});print(results[-1],flush=True)
        assert p.returncode==0
        lane=Path(env['CARGO_TARGET_DIR'])/'release'
        shutil.copyfile(lane/'dispatch-probe.exe',r/arm/'dispatch-probe.exe')
        shutil.copyfile(lane/'dispatch_probe.pdb',r/arm/'dispatch-probe.pdb')
finally:
    assert overlay(candidate)==verification['source_file_hashes']
    bench.write_bytes(original_bench)
    generated=core/'src/cost_probe.rs'
    if generated.exists():
        assert generated.read_bytes()==(r/'cost_probe.rs').read_bytes()
        generated.unlink()
    (r/'build-results.json').write_text(json.dumps(results,indent=2)+'\n')

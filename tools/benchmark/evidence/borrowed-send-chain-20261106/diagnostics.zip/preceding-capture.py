from pathlib import Path
import os,subprocess,json,hashlib
r=Path(__file__).resolve().parent
source=Path('D:/CoapticCurrent/replay-scratch-original-inbox-20261106/source-verification.json');v=json.loads(source.read_text());fixture=Path(v['fixture_root'])
assert all(hashlib.sha256((fixture/'coaptic'/n).read_bytes()).hexdigest()==h for n,h in v['source_file_hashes'].items())
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',RUSTFLAGS='-Cforce-frame-pointers=yes',RUSTC_BOOTSTRAP='1',TMP='D:/CoapticCurrent/replay-scratch-original-inbox-20261106/tmp',TEMP='D:/CoapticCurrent/replay-scratch-original-inbox-20261106/tmp')
cmd=[str(Path.home()/'.cargo/bin/agent-resources.exe'),'run','--id','coaptic-core-reusable','--directory',str(fixture/'probe'),'--','cargo','rustc','--locked','--offline','--release','--bin','dispatch-probe','--','-Zprint-type-sizes','--emit=llvm-ir']
keep=False;size=0
with (r/'nested-layout.txt').open('w') as out,(r/'build.log').open('w') as err:
 p=subprocess.Popen(cmd,cwd=fixture/'probe',env=env,stdout=subprocess.PIPE,stderr=err,text=True,encoding='utf-8',errors='replace')
 for line in p.stdout:
  if line.startswith('print-type-size type:'):
   keep=('async fn body' in line and ('app::' in line or 'coaptic::' in line) and ('Service' in line or 'SendResponse' in line)) or any(t in line for t in ['`coaptic::app::SendResponse<','`coaptic::app::SendResponse`','`coaptic::message::decode::ParsedMessage<'])
  if keep:
   size+=len(line.encode())
   if size<=2*1024*1024:out.write(line)
 code=p.wait()
record={'source':v['source'],'command':cmd,'exit_code':code,'layout_bytes':size,'scope':'Compiler layouts of selected nested futures and metadata; not CPU attribution or peak stack'}
(r/'result.json').write_text(json.dumps(record,indent=2));print(record);assert code==0 and 0<size<=2*1024*1024

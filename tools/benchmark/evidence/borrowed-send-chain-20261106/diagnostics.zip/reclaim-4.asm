
D:\CoapticCurrent\borrowed-send-chain-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009e790:     	pushq	%rbp
14009e791:     	pushq	%r15
14009e793:     	pushq	%r14
14009e795:     	pushq	%r13
14009e797:     	pushq	%r12
14009e799:     	pushq	%rsi
14009e79a:     	pushq	%rdi
14009e79b:     	pushq	%rbx
14009e79c:     	subq	$0x218, %rsp            # imm = 0x218
14009e7a3:     	leaq	0x80(%rsp), %rbp
14009e7ab:     	movaps	%xmm6, 0x180(%rbp)
14009e7b2:     	movq	0xe8(%rcx), %r8
14009e7b9:     	testq	%r8, %r8
14009e7bc:     	je	0x14009eaa9 <.text+0x9daa9>
14009e7c2:     	leaq	0xc0(%rcx), %r13
14009e7c9:     	leaq	0xd8(%rcx), %rdi
14009e7d0:     	movq	0xc8(%rcx), %rbx
14009e7d7:     	movq	0xd0(%rcx), %r10
14009e7de:     	leaq	0x28(%rbx), %rax
14009e7e2:     	xorl	%r11d, %r11d
14009e7e5:     	xorl	%r15d, %r15d
14009e7e8:     	imulq	$0x130, %r15, %r12      # imm = 0x130
14009e7ef:     	addq	%rax, %r12
14009e7f2:     	jmp	0x14009e80f <.text+0x9d80f>
14009e7f4:     	nopw	%cs:(%rax,%rax)
14009e800:     	incq	%r15
14009e803:     	addq	$0x130, %r12            # imm = 0x130
14009e80a:     	cmpq	%r8, %r15
14009e80d:     	jae	0x14009e87a <.text+0x9d87a>
14009e80f:     	cmpq	%r10, %r15
14009e812:     	jae	0x14009e800 <.text+0x9d800>
14009e814:     	cmpb	$0x2, -0xe(%r12)
14009e81a:     	je	0x14009e800 <.text+0x9d800>
14009e81c:     	movq	%r13, %rdi
14009e81f:     	movq	-0x8(%r12), %r13
14009e824:     	cmpb	$0x3, (%r12)
14009e829:     	setne	%r12b
14009e82d:     	testq	%r13, %r13
14009e830:     	sete	%sil
14009e834:     	orb	%r12b, %sil
14009e837:     	cmpq	%r14, %r13
14009e83a:     	setae	%r12b
14009e83e:     	andb	%r11b, %r12b
14009e841:     	testb	%sil, %sil
14009e844:     	movq	%r14, %rdx
14009e847:     	movq	%rax, %r14
14009e84a:     	movl	$0x1, %eax
14009e84f:     	cmoveq	%rax, %r11
14009e853:     	movq	%r14, %rax
14009e856:     	movq	%rdx, %r14
14009e859:     	orb	%sil, %r12b
14009e85c:     	cmoveq	%r15, %r9
14009e860:     	cmoveq	%r13, %r14
14009e864:     	movq	%rdi, %r13
14009e867:     	leaq	0xd8(%rcx), %rdi
14009e86e:     	incq	%r15
14009e871:     	cmpq	%r8, %r15
14009e874:     	jb	0x14009e7e8 <.text+0x9d7e8>
14009e87a:     	xorl	%eax, %eax
14009e87c:     	cmpq	$0x1, %r11
14009e880:     	jne	0x14009eaab <.text+0x9daab>
14009e886:     	cmpq	%r10, %r9
14009e889:     	jae	0x14009eaab <.text+0x9daab>
14009e88f:     	imulq	$0x130, %r9, %rax       # imm = 0x130
14009e896:     	movzbl	0x1a(%rbx,%rax), %r15d
14009e89c:     	cmpb	$0x2, %r15b
14009e8a0:     	je	0x14009eaa9 <.text+0x9daa9>
14009e8a6:     	addq	%rax, %rbx
14009e8a9:     	cmpb	$0x3, 0x28(%rbx)
14009e8ad:     	jne	0x14009eaa9 <.text+0x9daa9>
14009e8b3:     	movq	0x30(%rbx), %r10
14009e8b7:     	movups	(%rbx), %xmm0
14009e8ba:     	movups	0xa(%rbx), %xmm1
14009e8be:     	movups	%xmm1, 0x11a(%rbp)
14009e8c5:     	movaps	%xmm0, 0x110(%rbp)
14009e8cc:     	movzbl	0x1b(%rbx), %r12d
14009e8d1:     	movss	0x1c(%rbx), %xmm6
14009e8d6:     	movzwl	0x1c(%rbx), %eax
14009e8da:     	cmpq	0x88(%rcx), %r10
14009e8e1:     	jae	0x14009e937 <.text+0x9d937>
14009e8e3:     	movq	0x80(%rcx), %r11
14009e8ea:     	cmpb	$0x1, (%r11,%r10)
14009e8ef:     	jne	0x14009e937 <.text+0x9d937>
14009e8f1:     	cmpq	0xa0(%rcx), %r10
14009e8f8:     	jae	0x14009e908 <.text+0x9d908>
14009e8fa:     	movq	0x98(%rcx), %rsi
14009e901:     	cmpb	$0x0, (%rsi,%r10)
14009e906:     	jne	0x14009e937 <.text+0x9d937>
14009e908:     	movb	$0x0, (%r11,%r10)
14009e90d:     	decq	0xb0(%rcx)
14009e914:     	cmpq	0x70(%rcx), %r10
14009e918:     	jae	0x14009e937 <.text+0x9d937>
14009e91a:     	movq	0x68(%rcx), %r11
14009e91e:     	imulq	$0x58, %r10, %r10
14009e922:     	movq	$0x0, 0x30(%r11,%r10)
14009e92b:     	movb	$0x2, 0x52(%r11,%r10)
14009e931:     	movb	$0x2, 0x25(%r11,%r10)
14009e937:     	cmpq	%r8, %r9
14009e93a:     	jae	0x14009e95d <.text+0x9d95d>
14009e93c:     	movq	0xe0(%rcx), %r8
14009e943:     	cmpl	$0x0, (%r8,%r9,4)
14009e948:     	je	0x14009e95d <.text+0x9d95d>
14009e94a:     	movl	$0x0, (%r8,%r9,4)
14009e952:     	decq	0xf8(%rcx)
14009e959:     	movb	$0x2, 0x1a(%rbx)
14009e95d:     	xorps	%xmm0, %xmm0
14009e960:     	movaps	%xmm0, 0x170(%rbp)
14009e967:     	movb	$0x0, 0x152(%rbp)
14009e96e:     	movw	%ax, 0x150(%rbp)
14009e975:     	leaq	0x153(%rbp), %rcx
14009e97c:     	movw	$0x200, 0x15b(%rbp)     # imm = 0x200
14009e985:     	movq	$0x0, 0x153(%rbp)
14009e990:     	movq	$0x8, 0x130(%rbp)
14009e99b:     	movq	$0x0, 0x138(%rbp)
14009e9a6:     	movq	$0x1, 0x140(%rbp)
14009e9b1:     	movq	$0x0, 0x148(%rbp)
14009e9bc:     	movq	%rcx, 0x30(%rsp)
14009e9c1:     	movw	%ax, 0x28(%rsp)
14009e9c6:     	movq	$0x0, 0x58(%rsp)
14009e9cf:     	movq	$0x1, 0x50(%rsp)
14009e9d8:     	movq	$0x8, 0x48(%rsp)
14009e9e1:     	movq	$0x8, 0x40(%rsp)
14009e9ea:     	movq	$0x0, 0x38(%rsp)
14009e9f3:     	movb	$0x0, 0x20(%rsp)
14009e9f8:     	leaq	0x160(%rbp), %rcx
14009e9ff:     	leaq	0x170(%rbp), %rdx
14009ea06:     	movl	$0x10, %r8d
14009ea0c:     	movb	$0x2, %r9b
14009ea0f:     	callq	0x140005590 <.text+0x4590>
14009ea14:     	movq	0x168(%rbp), %rbx
14009ea1b:     	cmpq	$0x11, %rbx
14009ea1f:     	setae	%al
14009ea22:     	orb	0x160(%rbp), %al
14009ea28:     	jne	0x14009ead6 <.text+0x9dad6>
14009ea2e:     	movq	%rdi, %rcx
14009ea31:     	callq	0x140217c10 <.text+0x216c10>
14009ea36:     	cmpq	$0x1, %rax
14009ea3a:     	jne	0x14009ead6 <.text+0x9dad6>
14009ea40:     	movups	0x11a(%rbp), %xmm0
14009ea47:     	movups	%xmm0, -0x16(%rbp)
14009ea4b:     	movaps	0x110(%rbp), %xmm0
14009ea52:     	movaps	%xmm0, -0x20(%rbp)
14009ea56:     	movb	%r15b, -0x6(%rbp)
14009ea5a:     	movb	%r12b, -0x5(%rbp)
14009ea5e:     	movss	%xmm6, -0x4(%rbp)
14009ea63:     	movq	%r14, (%rbp)
14009ea67:     	testq	%rbx, %rbx
14009ea6a:     	je	0x14009eac6 <.text+0x9dac6>
14009ea6c:     	movb	$0x1, 0x8(%rbp)
14009ea70:     	movb	%bl, 0x9(%rbp)
14009ea73:     	leaq	0xa(%rbp), %rdi
14009ea77:     	movl	$0x80, %r8d
14009ea7d:     	subq	%rbx, %r8
14009ea80:     	leaq	(%rbx,%rbp), %rcx
14009ea84:     	addq	$0xa, %rcx
14009ea88:     	movq	%rdx, %r14
14009ea8b:     	xorl	%edx, %edx
14009ea8d:     	callq	0x14024fcf2 <.text+0x24ecf2>
14009ea92:     	leaq	0x170(%rbp), %rdx
14009ea99:     	movq	%rdi, %rcx
14009ea9c:     	movq	%rbx, %r8
14009ea9f:     	callq	0x14024fce0 <.text+0x24ece0>
14009eaa4:     	movq	%r14, %rdx
14009eaa7:     	jmp	0x14009eaca <.text+0x9daca>
14009eaa9:     	xorl	%eax, %eax
14009eaab:     	movaps	0x180(%rbp), %xmm6
14009eab2:     	addq	$0x218, %rsp            # imm = 0x218
14009eab9:     	popq	%rbx
14009eaba:     	popq	%rdi
14009eabb:     	popq	%rsi
14009eabc:     	popq	%r12
14009eabe:     	popq	%r13
14009eac0:     	popq	%r14
14009eac2:     	popq	%r15
14009eac4:     	popq	%rbp
14009eac5:     	retq
14009eac6:     	movb	$0x0, 0x8(%rbp)
14009eaca:     	leaq	-0x20(%rbp), %r8
14009eace:     	movq	%r13, %rcx
14009ead1:     	callq	0x14000b620 <.text+0xa620>
14009ead6:     	movb	$0x1, %al
14009ead8:     	jmp	0x14009eaab <.text+0x9daab>

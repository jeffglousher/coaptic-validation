
D:\CoapticCurrent\borrowed-send-chain-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009e160:     	pushq	%rbp
14009e161:     	pushq	%r15
14009e163:     	pushq	%r14
14009e165:     	pushq	%r13
14009e167:     	pushq	%r12
14009e169:     	pushq	%rsi
14009e16a:     	pushq	%rdi
14009e16b:     	pushq	%rbx
14009e16c:     	subq	$0x218, %rsp            # imm = 0x218
14009e173:     	leaq	0x80(%rsp), %rbp
14009e17b:     	movaps	%xmm6, 0x180(%rbp)
14009e182:     	leaq	0x3f7f0(%rcx), %rsi
14009e189:     	leaq	0x3f818(%rcx), %r8
14009e190:     	movl	$0x40, %r11d
14009e196:     	xorl	%eax, %eax
14009e198:     	movl	$0x1, %r9d
14009e19e:     	xorl	%r10d, %r10d
14009e1a1:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009e1a8:     	addq	%r8, %rdi
14009e1ab:     	nopl	(%rax,%rax)
14009e1b0:     	cmpb	$0x2, -0xe(%rdi)
14009e1b4:     	jne	0x14009e1d0 <.text+0x9d1d0>
14009e1b6:     	incq	%r10
14009e1b9:     	addq	$0x130, %rdi            # imm = 0x130
14009e1c0:     	cmpq	%r10, %r11
14009e1c3:     	jne	0x14009e1b0 <.text+0x9d1b0>
14009e1c5:     	jmp	0x14009e215 <.text+0x9d215>
14009e1c7:     	nopw	(%rax,%rax)
14009e1d0:     	movq	-0x8(%rdi), %r11
14009e1d4:     	cmpb	$0x3, (%rdi)
14009e1d7:     	setne	%bl
14009e1da:     	testq	%r11, %r11
14009e1dd:     	sete	%dil
14009e1e1:     	orb	%bl, %dil
14009e1e4:     	cmpq	%r14, %r11
14009e1e7:     	setae	%bl
14009e1ea:     	andb	%al, %bl
14009e1ec:     	testb	%dil, %dil
14009e1ef:     	cmoveq	%r9, %rax
14009e1f3:     	orb	%dil, %bl
14009e1f6:     	cmoveq	%r10, %rdx
14009e1fa:     	cmoveq	%r11, %r14
14009e1fe:     	incq	%r10
14009e201:     	cmpq	$0x41, %r10
14009e205:     	movl	$0x40, %r11d
14009e20b:     	cmovaeq	%r10, %r11
14009e20f:     	cmpq	$0x3f, %r10
14009e213:     	jbe	0x14009e1a1 <.text+0x9d1a1>
14009e215:     	testb	$0x1, %al
14009e217:     	je	0x14009e38f <.text+0x9d38f>
14009e21d:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009e224:     	movzbl	0x1a(%rsi,%rax), %r15d
14009e22a:     	cmpb	$0x2, %r15b
14009e22e:     	je	0x14009e38f <.text+0x9d38f>
14009e234:     	addq	%rsi, %rax
14009e237:     	cmpb	$0x3, 0x28(%rax)
14009e23b:     	jne	0x14009e38f <.text+0x9d38f>
14009e241:     	movq	0x30(%rax), %r8
14009e245:     	movq	(%rax), %rdx
14009e248:     	movq	%rdx, 0x168(%rbp)
14009e24f:     	movq	0x8(%rax), %rdx
14009e253:     	movq	%rdx, 0x170(%rbp)
14009e25a:     	movl	0x10(%rax), %edi
14009e25d:     	movl	0x14(%rax), %edx
14009e260:     	movl	%edx, 0x178(%rbp)
14009e266:     	movzwl	0x18(%rax), %edx
14009e26a:     	movw	%dx, 0x17c(%rbp)
14009e271:     	movzbl	0x1b(%rax), %edx
14009e275:     	movb	%dl, 0x17f(%rbp)
14009e27b:     	movss	0x1c(%rax), %xmm6
14009e280:     	movzwl	0x1c(%rax), %eax
14009e284:     	movzwl	%ax, %edx
14009e287:     	cmpq	$0x1f, %r8
14009e28b:     	ja	0x14009e2e0 <.text+0x9d2e0>
14009e28d:     	leaq	0x326f0(%rcx), %r9
14009e294:     	cmpb	$0x1, (%r9,%r8)
14009e299:     	jne	0x14009e2e0 <.text+0x9d2e0>
14009e29b:     	cmpb	$0x0, 0x32710(%rcx,%r8)
14009e2a4:     	jne	0x14009e2e0 <.text+0x9d2e0>
14009e2a6:     	movb	$0x0, 0x326f0(%rcx,%r8)
14009e2af:     	decq	0x32738(%rcx)
14009e2b6:     	movq	$0x0, 0x3e5c0(%rcx,%r8,8)
14009e2c2:     	leaq	(%r8,%r8,8), %r10
14009e2c6:     	leaq	(%r10,%r10,2), %r10
14009e2ca:     	addq	%r8, %r10
14009e2cd:     	movb	$0x2, 0x36a(%r9,%r10)
14009e2d6:     	leaq	(%r8,%r8,2), %r8
14009e2da:     	movb	$0x2, 0x5d(%r9,%r8,8)
14009e2e0:     	leaq	0x443f0(%rcx), %r12
14009e2e7:     	addl	$0x2, %edx
14009e2ea:     	leaq	0x3f80c(%rcx), %r9
14009e2f1:     	xorl	%r10d, %r10d
14009e2f4:     	xorl	%r8d, %r8d
14009e2f7:     	jmp	0x14009e317 <.text+0x9d317>
14009e2f9:     	nopl	(%rax)
14009e300:     	movq	%r13, %r11
14009e303:     	incq	%r10
14009e306:     	addq	$0x130, %r9             # imm = 0x130
14009e30d:     	cmpq	$0x40, %r10
14009e311:     	je	0x14009e3ac <.text+0x9d3ac>
14009e317:     	movq	%r11, %r13
14009e31a:     	cmpl	%edx, (%r12,%r10,4)
14009e31e:     	jne	0x14009e300 <.text+0x9d300>
14009e320:     	movzbl	-0x2(%r9), %r11d
14009e325:     	cmpb	$0x2, %r11b
14009e329:     	je	0x14009e300 <.text+0x9d300>
14009e32b:     	cmpb	%r15b, %r11b
14009e32e:     	jne	0x14009e300 <.text+0x9d300>
14009e330:     	cmpw	%ax, (%r9)
14009e334:     	jne	0x14009e300 <.text+0x9d300>
14009e336:     	cmpl	%edi, -0xc(%r9)
14009e33a:     	jne	0x14009e300 <.text+0x9d300>
14009e33c:     	movl	0x178(%rbp), %r11d
14009e343:     	cmpl	%r11d, -0x8(%r9)
14009e347:     	jne	0x14009e300 <.text+0x9d300>
14009e349:     	movzwl	0x17c(%rbp), %r11d
14009e351:     	cmpw	%r11w, -0x4(%r9)
14009e356:     	jne	0x14009e300 <.text+0x9d300>
14009e358:     	movq	-0x1c(%r9), %r11
14009e35c:     	xorq	0x168(%rbp), %r11
14009e363:     	movq	-0x14(%r9), %rbx
14009e367:     	xorq	0x170(%rbp), %rbx
14009e36e:     	orq	%r11, %rbx
14009e371:     	jne	0x14009e300 <.text+0x9d300>
14009e373:     	movq	%r10, %r11
14009e376:     	cmpq	$0x1, %r8
14009e37a:     	movl	$0x1, %r8d
14009e380:     	jne	0x14009e303 <.text+0x9d303>
14009e382:     	movb	$0x1, %bl
14009e384:     	movq	%r13, %r11
14009e387:     	cmpq	$0x3f, %r13
14009e38b:     	jbe	0x14009e3ba <.text+0x9d3ba>
14009e38d:     	jmp	0x14009e3e0 <.text+0x9d3e0>
14009e38f:     	xorl	%eax, %eax
14009e391:     	movaps	0x180(%rbp), %xmm6
14009e398:     	addq	$0x218, %rsp            # imm = 0x218
14009e39f:     	popq	%rbx
14009e3a0:     	popq	%rdi
14009e3a1:     	popq	%rsi
14009e3a2:     	popq	%r12
14009e3a4:     	popq	%r13
14009e3a6:     	popq	%r14
14009e3a8:     	popq	%r15
14009e3aa:     	popq	%rbp
14009e3ab:     	retq
14009e3ac:     	cmpq	$0x40, %r11
14009e3b0:     	setb	%dl
14009e3b3:     	xorl	%ebx, %ebx
14009e3b5:     	testb	%dl, %r8b
14009e3b8:     	je	0x14009e3e0 <.text+0x9d3e0>
14009e3ba:     	cmpl	$0x0, (%r12,%r11,4)
14009e3bf:     	je	0x14009e3e0 <.text+0x9d3e0>
14009e3c1:     	movl	$0x0, 0x443f0(%rcx,%r11,4)
14009e3cd:     	decq	0x444f8(%rcx)
14009e3d4:     	imulq	$0x130, %r11, %rdx      # imm = 0x130
14009e3db:     	movb	$0x2, 0x1a(%rsi,%rdx)
14009e3e0:     	pxor	%xmm0, %xmm0
14009e3e4:     	movdqa	%xmm0, 0x150(%rbp)
14009e3ec:     	movb	$0x0, 0x132(%rbp)
14009e3f3:     	movw	%ax, 0x130(%rbp)
14009e3fa:     	leaq	0x133(%rbp), %rdx
14009e401:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009e40a:     	movq	$0x0, 0x133(%rbp)
14009e415:     	movq	$0x8, 0x110(%rbp)
14009e420:     	movq	$0x0, 0x118(%rbp)
14009e42b:     	movq	$0x1, 0x120(%rbp)
14009e436:     	movq	$0x0, 0x128(%rbp)
14009e441:     	movq	%rdx, 0x30(%rsp)
14009e446:     	movw	%ax, 0x28(%rsp)
14009e44b:     	movq	$0x0, 0x58(%rsp)
14009e454:     	movq	$0x1, 0x50(%rsp)
14009e45d:     	movq	$0x8, 0x48(%rsp)
14009e466:     	movq	$0x8, 0x40(%rsp)
14009e46f:     	movq	$0x0, 0x38(%rsp)
14009e478:     	movb	$0x0, 0x20(%rsp)
14009e47d:     	leaq	0x140(%rbp), %rax
14009e484:     	leaq	0x150(%rbp), %rdx
14009e48b:     	movl	$0x10, %r8d
14009e491:     	movq	%rcx, %r13
14009e494:     	movq	%rax, %rcx
14009e497:     	movb	$0x2, %r9b
14009e49a:     	callq	0x140005590 <.text+0x4590>
14009e49f:     	movq	%r13, %rax
14009e4a2:     	movq	0x148(%rbp), %r13
14009e4a9:     	cmpq	$0x11, %r13
14009e4ad:     	setae	%cl
14009e4b0:     	orb	%bl, %cl
14009e4b2:     	orb	0x140(%rbp), %cl
14009e4b8:     	testb	$0x1, %cl
14009e4bb:     	jne	0x14009e4c7 <.text+0x9d4c7>
14009e4bd:     	cmpq	$0x40, 0x444f8(%rax)
14009e4c5:     	jne	0x14009e4ce <.text+0x9d4ce>
14009e4c7:     	movb	$0x1, %al
14009e4c9:     	jmp	0x14009e391 <.text+0x9d391>
14009e4ce:     	movq	0x444f0(%rax), %rbx
14009e4d5:     	cmpq	$0x3f, %rbx
14009e4d9:     	ja	0x14009e779 <.text+0x9d779>
14009e4df:     	cmpl	$0x0, (%r12,%rbx,4)
14009e4e4:     	je	0x14009e550 <.text+0x9d550>
14009e4e6:     	leaq	(,%rbx,4), %rdx
14009e4ee:     	leaq	(%r12,%rbx,4), %rcx
14009e4f2:     	xorl	%r8d, %r8d
14009e4f5:     	movq	%rdx, %r9
14009e4f8:     	nopl	(%rax,%rax)
14009e500:     	cmpl	$0x0, (%r12,%r9)
14009e505:     	je	0x14009e543 <.text+0x9d543>
14009e507:     	addq	$0x4, %r9
14009e50b:     	decq	%r8
14009e50e:     	cmpq	$0x100, %r9             # imm = 0x100
14009e515:     	jne	0x14009e500 <.text+0x9d500>
14009e517:     	testq	%rbx, %rbx
14009e51a:     	je	0x14009e4c7 <.text+0x9d4c7>
14009e51c:     	addq	$-0x4, %rdx
14009e520:     	cmpq	$0xc, %rdx
14009e524:     	jae	0x14009e6bd <.text+0x9d6bd>
14009e52a:     	xorl	%ebx, %ebx
14009e52c:     	movq	%r12, %r9
14009e52f:     	cmpl	$0x0, (%r9)
14009e533:     	je	0x14009e546 <.text+0x9d546>
14009e535:     	addq	$0x4, %r9
14009e539:     	incq	%rbx
14009e53c:     	cmpq	%rcx, %r9
14009e53f:     	jne	0x14009e52f <.text+0x9d52f>
14009e541:     	jmp	0x14009e4c7 <.text+0x9d4c7>
14009e543:     	subq	%r8, %rbx
14009e546:     	cmpq	$0x40, %rbx
14009e54a:     	jae	0x14009e763 <.text+0x9d763>
14009e550:     	movl	$0x1, 0x443f0(%rax,%rbx,4)
14009e55b:     	incq	0x444f8(%rax)
14009e562:     	leaq	0x1(%rbx), %rcx
14009e566:     	xorl	%edx, %edx
14009e568:     	cmpq	$0x40, %rcx
14009e56c:     	cmovneq	%rcx, %rdx
14009e570:     	movq	%rdx, 0x444f0(%rax)
14009e577:     	movq	0x170(%rbp), %rax
14009e57e:     	movq	%rax, -0x18(%rbp)
14009e582:     	movq	0x168(%rbp), %rax
14009e589:     	movq	%rax, -0x20(%rbp)
14009e58d:     	movl	%edi, -0x10(%rbp)
14009e590:     	movl	0x178(%rbp), %eax
14009e596:     	movl	%eax, -0xc(%rbp)
14009e599:     	movzwl	0x17c(%rbp), %eax
14009e5a0:     	movw	%ax, -0x8(%rbp)
14009e5a4:     	movb	%r15b, -0x6(%rbp)
14009e5a8:     	movzbl	0x17f(%rbp), %eax
14009e5af:     	movb	%al, -0x5(%rbp)
14009e5b2:     	movss	%xmm6, -0x4(%rbp)
14009e5b7:     	movq	%r14, (%rbp)
14009e5bb:     	testq	%r13, %r13
14009e5be:     	je	0x14009e622 <.text+0x9d622>
14009e5c0:     	movb	$0x1, 0x8(%rbp)
14009e5c4:     	movb	%r13b, 0x9(%rbp)
14009e5c8:     	leaq	0xa(%rbp), %r14
14009e5cc:     	movl	$0x80, %r8d
14009e5d2:     	subq	%r13, %r8
14009e5d5:     	leaq	0xa(,%r13), %rcx
14009e5dd:     	addq	%rbp, %rcx
14009e5e0:     	xorl	%edx, %edx
14009e5e2:     	callq	0x14024fcf2 <.text+0x24ecf2>
14009e5e7:     	leaq	0x150(%rbp), %rdx
14009e5ee:     	movq	%r14, %rcx
14009e5f1:     	movq	%r13, %r8
14009e5f4:     	callq	0x14024fce0 <.text+0x24ece0>
14009e5f9:     	movzwl	-0x4(%rbp), %eax
14009e5fd:     	addl	$0x2, %eax
14009e600:     	movl	%eax, (%r12,%rbx,4)
14009e604:     	imulq	$0x130, %rbx, %rax      # imm = 0x130
14009e60b:     	addq	%rax, %rsi
14009e60e:     	movzbl	0x8(%rbp), %eax
14009e612:     	leaq	0x1cfc37(%rip), %rcx    # 0x14026e250
14009e619:     	movslq	(%rcx,%rax,4), %rax
14009e61d:     	addq	%rcx, %rax
14009e620:     	jmpq	*%rax
14009e622:     	movb	$0x0, 0x8(%rbp)
14009e626:     	movzwl	-0x4(%rbp), %eax
14009e62a:     	addl	$0x2, %eax
14009e62d:     	movl	%eax, (%r12,%rbx,4)
14009e631:     	imulq	$0x130, %rbx, %rax      # imm = 0x130
14009e638:     	addq	%rax, %rsi
14009e63b:     	movzbl	0x8(%rbp), %eax
14009e63f:     	leaq	0x1cfc0a(%rip), %rcx    # 0x14026e250
14009e646:     	movslq	(%rcx,%rax,4), %rax
14009e64a:     	addq	%rcx, %rax
14009e64d:     	jmpq	*%rax
14009e64f:     	movdqa	-0x20(%rbp), %xmm0
14009e654:     	movdqa	-0x10(%rbp), %xmm1
14009e659:     	movdqu	%xmm1, 0x10(%rsi)
14009e65e:     	movdqu	%xmm0, (%rsi)
14009e662:     	movb	$0x0, 0x28(%rsi)
14009e666:     	movq	(%rbp), %rax
14009e66a:     	movq	%rax, 0x20(%rsi)
14009e66e:     	jmp	0x14009e4c7 <.text+0x9d4c7>
14009e673:     	leaq	-0x20(%rbp), %rdx
14009e677:     	movl	$0x130, %r8d            # imm = 0x130
14009e67d:     	movq	%rsi, %rcx
14009e680:     	callq	0x14024fce0 <.text+0x24ece0>
14009e685:     	jmp	0x14009e4c7 <.text+0x9d4c7>
14009e68a:     	movq	(%rbp), %r8
14009e68e:     	movq	0x10(%rbp), %r9
14009e692:     	leaq	-0x20(%rbp), %rdx
14009e696:     	movq	%rsi, %rcx
14009e699:     	callq	0x14000b2d0 <.text+0xa2d0>
14009e69e:     	jmp	0x14009e4c7 <.text+0x9d4c7>
14009e6a3:     	leaq	0xa(%rbp), %r8
14009e6a7:     	movzbl	0x9(%rbp), %r9d
14009e6ac:     	leaq	-0x20(%rbp), %rdx
14009e6b0:     	movq	%rsi, %rcx
14009e6b3:     	callq	0x14000b1c0 <.text+0xa1c0>
14009e6b8:     	jmp	0x14009e4c7 <.text+0x9d4c7>
14009e6bd:     	shrq	$0x2, %rdx
14009e6c1:     	incq	%rdx
14009e6c4:     	movq	%rdx, %rbx
14009e6c7:     	andq	$-0x4, %rbx
14009e6cb:     	leaq	(%r12,%rbx,4), %r9
14009e6cf:     	xorl	%r8d, %r8d
14009e6d2:     	pxor	%xmm1, %xmm1
14009e6d6:     	movdqu	(%r12,%r8,4), %xmm0
14009e6dc:     	movdqa	%xmm0, %xmm2
14009e6e0:     	pcmpeqd	%xmm1, %xmm2
14009e6e4:     	movmskps	%xmm2, %r10d
14009e6e8:     	testl	%r10d, %r10d
14009e6eb:     	jne	0x14009e704 <.text+0x9d704>
14009e6ed:     	addq	$0x4, %r8
14009e6f1:     	cmpq	%r8, %rbx
14009e6f4:     	jne	0x14009e6d6 <.text+0x9d6d6>
14009e6f6:     	cmpq	%rbx, %rdx
14009e6f9:     	jne	0x14009e52f <.text+0x9d52f>
14009e6ff:     	jmp	0x14009e4c7 <.text+0x9d4c7>
14009e704:     	pxor	%xmm1, %xmm1
14009e708:     	pcmpeqd	%xmm1, %xmm0
14009e70c:     	pand	0x1c367c(%rip), %xmm0   # 0x140261d90
14009e714:     	movdqa	0x1c1574(%rip), %xmm1   # 0x14025fc90
14009e71c:     	movdqa	%xmm0, %xmm2
14009e720:     	por	%xmm1, %xmm2
14009e724:     	pshufd	$0xee, %xmm0, %xmm3     # xmm3 = xmm0[2,3,2,3]
14009e729:     	por	%xmm3, %xmm1
14009e72d:     	pcmpgtd	%xmm1, %xmm2
14009e731:     	pand	%xmm2, %xmm0
14009e735:     	pandn	%xmm3, %xmm2
14009e739:     	por	%xmm0, %xmm2
14009e73d:     	movd	%xmm2, %ecx
14009e741:     	pshufd	$0x55, %xmm2, %xmm0     # xmm0 = xmm2[1,1,1,1]
14009e746:     	movd	%xmm0, %edx
14009e74a:     	cmpl	%edx, %ecx
14009e74c:     	cmoval	%ecx, %edx
14009e74f:     	movl	$0x4, %ebx
14009e754:     	subl	%edx, %ebx
14009e756:     	addq	%r8, %rbx
14009e759:     	cmpq	$0x40, %rbx
14009e75d:     	jb	0x14009e550 <.text+0x9d550>
14009e763:     	leaq	0x1cc64e(%rip), %r8     # 0x14026adb8
14009e76a:     	movl	$0x40, %edx
14009e76f:     	movq	%rbx, %rcx
14009e772:     	callq	0x140250563 <.text+0x24f563>
14009e777:     	ud2
14009e779:     	leaq	0x1cc620(%rip), %r8     # 0x14026ada0
14009e780:     	movl	$0x40, %edx
14009e785:     	movq	%rbx, %rcx
14009e788:     	callq	0x140250563 <.text+0x24f563>
14009e78d:     	ud2


D:\CoapticCurrent\borrowed-send-chain-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009d9d0:     	pushq	%rbp
14009d9d1:     	pushq	%r15
14009d9d3:     	pushq	%r14
14009d9d5:     	pushq	%r13
14009d9d7:     	pushq	%r12
14009d9d9:     	pushq	%rsi
14009d9da:     	pushq	%rdi
14009d9db:     	pushq	%rbx
14009d9dc:     	subq	$0x218, %rsp            # imm = 0x218
14009d9e3:     	leaq	0x80(%rsp), %rbp
14009d9eb:     	movaps	%xmm6, 0x180(%rbp)
14009d9f2:     	leaq	0x3f10(%rcx), %rsi
14009d9f9:     	leaq	0x3f38(%rcx), %r8
14009da00:     	movl	$0x4, %r11d
14009da06:     	xorl	%eax, %eax
14009da08:     	movl	$0x1, %r9d
14009da0e:     	xorl	%r10d, %r10d
14009da11:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009da18:     	addq	%r8, %rdi
14009da1b:     	nopl	(%rax,%rax)
14009da20:     	cmpb	$0x2, -0xe(%rdi)
14009da24:     	jne	0x14009da40 <.text+0x9ca40>
14009da26:     	incq	%r10
14009da29:     	addq	$0x130, %rdi            # imm = 0x130
14009da30:     	cmpq	%r10, %r11
14009da33:     	jne	0x14009da20 <.text+0x9ca20>
14009da35:     	jmp	0x14009da85 <.text+0x9ca85>
14009da37:     	nopw	(%rax,%rax)
14009da40:     	movq	-0x8(%rdi), %r11
14009da44:     	cmpb	$0x3, (%rdi)
14009da47:     	setne	%bl
14009da4a:     	testq	%r11, %r11
14009da4d:     	sete	%dil
14009da51:     	orb	%bl, %dil
14009da54:     	cmpq	%r14, %r11
14009da57:     	setae	%bl
14009da5a:     	andb	%al, %bl
14009da5c:     	testb	%dil, %dil
14009da5f:     	cmoveq	%r9, %rax
14009da63:     	orb	%dil, %bl
14009da66:     	cmoveq	%r10, %rdx
14009da6a:     	cmoveq	%r11, %r14
14009da6e:     	incq	%r10
14009da71:     	cmpq	$0x5, %r10
14009da75:     	movl	$0x4, %r11d
14009da7b:     	cmovaeq	%r10, %r11
14009da7f:     	cmpq	$0x3, %r10
14009da83:     	jbe	0x14009da11 <.text+0x9ca11>
14009da85:     	testb	$0x1, %al
14009da87:     	je	0x14009db81 <.text+0x9cb81>
14009da8d:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009da94:     	movzbl	0x1a(%rsi,%rax), %r15d
14009da9a:     	cmpb	$0x2, %r15b
14009da9e:     	je	0x14009db81 <.text+0x9cb81>
14009daa4:     	addq	%rsi, %rax
14009daa7:     	cmpb	$0x3, 0x28(%rax)
14009daab:     	jne	0x14009db81 <.text+0x9cb81>
14009dab1:     	movq	0x30(%rax), %r8
14009dab5:     	movq	(%rax), %rdx
14009dab8:     	movq	%rdx, 0x168(%rbp)
14009dabf:     	movq	0x8(%rax), %rdx
14009dac3:     	movq	%rdx, 0x170(%rbp)
14009daca:     	movl	0x10(%rax), %ebx
14009dacd:     	movl	0x14(%rax), %r12d
14009dad1:     	movzwl	0x18(%rax), %edi
14009dad5:     	movzbl	0x1b(%rax), %edx
14009dad9:     	movb	%dl, 0x17f(%rbp)
14009dadf:     	movss	0x1c(%rax), %xmm6
14009dae4:     	movzwl	0x1c(%rax), %eax
14009dae8:     	movzwl	%ax, %edx
14009daeb:     	cmpq	$0x1, %r8
14009daef:     	ja	0x14009db4b <.text+0x9cb4b>
14009daf1:     	cmpb	$0x1, 0x3f08(%rcx,%r8)
14009dafa:     	jne	0x14009db4b <.text+0x9cb4b>
14009dafc:     	cmpb	$0x0, 0x3f0a(%rcx,%r8)
14009db05:     	jne	0x14009db4b <.text+0x9cb4b>
14009db07:     	movb	$0x0, 0x3f08(%rcx,%r8)
14009db10:     	decq	0x3f00(%rcx)
14009db17:     	leaq	0x3580(%rcx), %r9
14009db1e:     	movq	$0x0, 0x3e80(%rcx,%r8,8)
14009db2a:     	leaq	(%r8,%r8,8), %r10
14009db2e:     	leaq	(%r10,%r10,2), %r10
14009db32:     	addq	%r8, %r10
14009db35:     	movb	$0x2, 0x95a(%r9,%r10)
14009db3e:     	leaq	(%r8,%r8,2), %r8
14009db42:     	movb	$0x2, 0x91d(%r9,%r8,8)
14009db4b:     	addl	$0x2, %edx
14009db4e:     	movb	$0x1, %r9b
14009db51:     	cmpl	%edx, 0x43d0(%rcx)
14009db57:     	jne	0x14009db67 <.text+0x9cb67>
14009db59:     	movzbl	0x3f2a(%rcx), %r8d
14009db61:     	cmpb	$0x2, %r8b
14009db65:     	jne	0x14009db9e <.text+0x9cb9e>
14009db67:     	xorl	%r8d, %r8d
14009db6a:     	cmpl	%edx, 0x43d4(%rcx)
14009db70:     	movl	%ebx, 0x178(%rbp)
14009db76:     	jne	0x14009dc2d <.text+0x9cc2d>
14009db7c:     	jmp	0x14009dc1b <.text+0x9cc1b>
14009db81:     	xorl	%eax, %eax
14009db83:     	movaps	0x180(%rbp), %xmm6
14009db8a:     	addq	$0x218, %rsp            # imm = 0x218
14009db91:     	popq	%rbx
14009db92:     	popq	%rdi
14009db93:     	popq	%rsi
14009db94:     	popq	%r12
14009db96:     	popq	%r13
14009db98:     	popq	%r14
14009db9a:     	popq	%r15
14009db9c:     	popq	%rbp
14009db9d:     	retq
14009db9e:     	cmpw	%ax, 0x3f2c(%rcx)
14009dba5:     	sete	%r9b
14009dba9:     	cmpl	%ebx, 0x3f20(%rcx)
14009dbaf:     	sete	%r10b
14009dbb3:     	andb	%r9b, %r10b
14009dbb6:     	cmpl	%r12d, 0x3f24(%rcx)
14009dbbd:     	sete	%r9b
14009dbc1:     	cmpw	%di, 0x3f28(%rcx)
14009dbc8:     	sete	%r11b
14009dbcc:     	andb	%r9b, %r11b
14009dbcf:     	andb	%r10b, %r11b
14009dbd2:     	cmpb	%r15b, %r8b
14009dbd5:     	sete	%r8b
14009dbd9:     	movq	0x3f18(%rcx), %r9
14009dbe0:     	xorq	0x170(%rbp), %r9
14009dbe7:     	movq	0x3f10(%rcx), %r10
14009dbee:     	xorq	0x168(%rbp), %r10
14009dbf5:     	orq	%r9, %r10
14009dbf8:     	sete	%r9b
14009dbfc:     	andb	%r8b, %r9b
14009dbff:     	andb	%r11b, %r9b
14009dc02:     	movzbl	%r9b, %r8d
14009dc06:     	movl	%r8d, %r9d
14009dc09:     	xorb	$0x1, %r9b
14009dc0d:     	cmpl	%edx, 0x43d4(%rcx)
14009dc13:     	movl	%ebx, 0x178(%rbp)
14009dc19:     	jne	0x14009dc2d <.text+0x9cc2d>
14009dc1b:     	movzbl	0x405a(%rcx), %r10d
14009dc23:     	cmpb	$0x2, %r10b
14009dc27:     	jne	0x14009dcde <.text+0x9ccde>
14009dc2d:     	xorl	%r9d, %r9d
14009dc30:     	cmpl	%edx, 0x43d8(%rcx)
14009dc36:     	jne	0x14009dd84 <.text+0x9cd84>
14009dc3c:     	movzbl	0x418a(%rcx), %r10d
14009dc44:     	cmpb	$0x2, %r10b
14009dc48:     	je	0x14009dd84 <.text+0x9cd84>
14009dc4e:     	cmpb	%r15b, %r10b
14009dc51:     	jne	0x14009dd84 <.text+0x9cd84>
14009dc57:     	cmpw	%ax, 0x418c(%rcx)
14009dc5e:     	jne	0x14009dd84 <.text+0x9cd84>
14009dc64:     	cmpl	%ebx, 0x4180(%rcx)
14009dc6a:     	jne	0x14009dd84 <.text+0x9cd84>
14009dc70:     	cmpl	%r12d, 0x4184(%rcx)
14009dc77:     	jne	0x14009dd84 <.text+0x9cd84>
14009dc7d:     	cmpw	%di, 0x4188(%rcx)
14009dc84:     	jne	0x14009dd84 <.text+0x9cd84>
14009dc8a:     	movq	0x4170(%rcx), %r10
14009dc91:     	xorq	0x168(%rbp), %r10
14009dc98:     	movq	0x4178(%rcx), %r11
14009dc9f:     	xorq	0x170(%rbp), %r11
14009dca6:     	orq	%r10, %r11
14009dca9:     	jne	0x14009dd84 <.text+0x9cd84>
14009dcaf:     	movl	%r12d, %r13d
14009dcb2:     	movl	%edi, %r12d
14009dcb5:     	movb	$0x1, %dil
14009dcb8:     	testq	%r8, %r8
14009dcbb:     	jne	0x14009de10 <.text+0x9ce10>
14009dcc1:     	movl	$0x1, %r8d
14009dcc7:     	movl	$0x2, %r9d
14009dccd:     	movl	%r12d, %edi
14009dcd0:     	movl	%r13d, %r12d
14009dcd3:     	movl	0x178(%rbp), %ebx
14009dcd9:     	jmp	0x14009dd84 <.text+0x9cd84>
14009dcde:     	cmpw	%ax, 0x405c(%rcx)
14009dce5:     	setne	%r11b
14009dce9:     	cmpl	%ebx, 0x4050(%rcx)
14009dcef:     	setne	%bl
14009dcf2:     	orb	%r11b, %bl
14009dcf5:     	movl	%r12d, %r13d
14009dcf8:     	cmpl	%r12d, 0x4054(%rcx)
14009dcff:     	setne	%r11b
14009dd03:     	movl	%edi, %r12d
14009dd06:     	cmpw	%di, 0x4058(%rcx)
14009dd0d:     	setne	%dil
14009dd11:     	orb	%r11b, %dil
14009dd14:     	orb	%bl, %dil
14009dd17:     	cmpb	%r15b, %r10b
14009dd1a:     	setne	%r11b
14009dd1e:     	movq	0x4048(%rcx), %r10
14009dd25:     	xorq	0x170(%rbp), %r10
14009dd2c:     	movq	0x4040(%rcx), %rbx
14009dd33:     	xorq	0x168(%rbp), %rbx
14009dd3a:     	orq	%r10, %rbx
14009dd3d:     	setne	%r10b
14009dd41:     	orb	%r11b, %r10b
14009dd44:     	orb	%dil, %r10b
14009dd47:     	orb	%r10b, %r9b
14009dd4a:     	testb	%r10b, %r10b
14009dd4d:     	movl	$0x1, %r11d
14009dd53:     	cmoveq	%r11, %r8
14009dd57:     	testb	$0x1, %r9b
14009dd5b:     	je	0x14009de0a <.text+0x9ce0a>
14009dd61:     	notb	%r10b
14009dd64:     	movzbl	%r10b, %r9d
14009dd68:     	andl	$0x1, %r9d
14009dd6c:     	movl	%r12d, %edi
14009dd6f:     	movl	%r13d, %r12d
14009dd72:     	movl	0x178(%rbp), %ebx
14009dd78:     	cmpl	%edx, 0x43d8(%rcx)
14009dd7e:     	je	0x14009dc3c <.text+0x9cc3c>
14009dd84:     	cmpl	%edx, 0x43dc(%rcx)
14009dd8a:     	jne	0x14009dd98 <.text+0x9cd98>
14009dd8c:     	movzbl	0x42ba(%rcx), %edx
14009dd93:     	cmpb	$0x2, %dl
14009dd96:     	jne	0x14009ddaa <.text+0x9cdaa>
14009dd98:     	movl	%r12d, %r13d
14009dd9b:     	movl	%edi, %r12d
14009dd9e:     	xorl	%edi, %edi
14009dda0:     	testq	%r8, %r8
14009dda3:     	jne	0x14009de10 <.text+0x9ce10>
14009dda5:     	jmp	0x14009de3a <.text+0x9ce3a>
14009ddaa:     	cmpb	%r15b, %dl
14009ddad:     	jne	0x14009dd98 <.text+0x9cd98>
14009ddaf:     	cmpw	%ax, 0x42bc(%rcx)
14009ddb6:     	jne	0x14009dd98 <.text+0x9cd98>
14009ddb8:     	cmpl	%ebx, 0x42b0(%rcx)
14009ddbe:     	jne	0x14009dd98 <.text+0x9cd98>
14009ddc0:     	cmpl	%r12d, 0x42b4(%rcx)
14009ddc7:     	jne	0x14009dd98 <.text+0x9cd98>
14009ddc9:     	cmpw	%di, 0x42b8(%rcx)
14009ddd0:     	jne	0x14009dd98 <.text+0x9cd98>
14009ddd2:     	movq	0x42a0(%rcx), %rdx
14009ddd9:     	xorq	0x168(%rbp), %rdx
14009dde0:     	movq	0x42a8(%rcx), %r10
14009dde7:     	xorq	0x170(%rbp), %r10
14009ddee:     	orq	%rdx, %r10
14009ddf1:     	jne	0x14009dd98 <.text+0x9cd98>
14009ddf3:     	movl	%r12d, %r13d
14009ddf6:     	movl	%edi, %r12d
14009ddf9:     	testq	%r8, %r8
14009ddfc:     	movl	$0x3, %edx
14009de01:     	cmoveq	%rdx, %r9
14009de05:     	movl	%r8d, %edi
14009de08:     	jmp	0x14009de10 <.text+0x9ce10>
14009de0a:     	movb	$0x1, %dil
14009de0d:     	xorl	%r9d, %r9d
14009de10:     	cmpl	$0x0, 0x43d0(%rcx,%r9,4)
14009de19:     	je	0x14009de3a <.text+0x9ce3a>
14009de1b:     	movl	$0x0, 0x43d0(%rcx,%r9,4)
14009de27:     	decq	0x43e8(%rcx)
14009de2e:     	imulq	$0x130, %r9, %rdx       # imm = 0x130
14009de35:     	movb	$0x2, 0x1a(%rsi,%rdx)
14009de3a:     	xorps	%xmm0, %xmm0
14009de3d:     	movaps	%xmm0, 0x150(%rbp)
14009de44:     	movb	$0x0, 0x132(%rbp)
14009de4b:     	movw	%ax, 0x130(%rbp)
14009de52:     	leaq	0x133(%rbp), %rdx
14009de59:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009de62:     	movq	$0x0, 0x133(%rbp)
14009de6d:     	movq	$0x8, 0x110(%rbp)
14009de78:     	movq	$0x0, 0x118(%rbp)
14009de83:     	movq	$0x1, 0x120(%rbp)
14009de8e:     	movq	$0x0, 0x128(%rbp)
14009de99:     	movq	%rdx, 0x30(%rsp)
14009de9e:     	movw	%ax, 0x28(%rsp)
14009dea3:     	movq	$0x0, 0x58(%rsp)
14009deac:     	movq	$0x1, 0x50(%rsp)
14009deb5:     	movq	$0x8, 0x48(%rsp)
14009debe:     	movq	$0x8, 0x40(%rsp)
14009dec7:     	movq	$0x0, 0x38(%rsp)
14009ded0:     	movb	$0x0, 0x20(%rsp)
14009ded5:     	leaq	0x140(%rbp), %rax
14009dedc:     	leaq	0x150(%rbp), %rdx
14009dee3:     	movl	$0x10, %r8d
14009dee9:     	movq	%rcx, %rbx
14009deec:     	movq	%rax, %rcx
14009deef:     	movb	$0x2, %r9b
14009def2:     	callq	0x140005590 <.text+0x4590>
14009def7:     	cmpb	$0x0, 0x140(%rbp)
14009defe:     	jne	0x14009df1f <.text+0x9cf1f>
14009df00:     	testb	%dil, %dil
14009df03:     	jne	0x14009df1f <.text+0x9cf1f>
14009df05:     	movq	%rbx, %rax
14009df08:     	movq	0x148(%rbp), %rbx
14009df0f:     	cmpq	$0x10, %rbx
14009df13:     	ja	0x14009df1f <.text+0x9cf1f>
14009df15:     	cmpq	$0x4, 0x43e8(%rax)
14009df1d:     	jne	0x14009df26 <.text+0x9cf26>
14009df1f:     	movb	$0x1, %al
14009df21:     	jmp	0x14009db83 <.text+0x9cb83>
14009df26:     	movq	0x43e0(%rax), %rdi
14009df2d:     	cmpq	$0x3, %rdi
14009df31:     	ja	0x14009e12d <.text+0x9d12d>
14009df37:     	cmpl	$0x0, 0x43d0(%rax,%rdi,4)
14009df3f:     	je	0x14009dfb2 <.text+0x9cfb2>
14009df41:     	leaq	(,%rdi,4), %rdx
14009df49:     	xorl	%ecx, %ecx
14009df4b:     	nopl	(%rax,%rax)
14009df50:     	cmpl	$0x0, 0x43d0(%rax,%rdx)
14009df58:     	je	0x14009dfa5 <.text+0x9cfa5>
14009df5a:     	addq	$0x4, %rdx
14009df5e:     	decq	%rcx
14009df61:     	cmpq	$0x10, %rdx
14009df65:     	jne	0x14009df50 <.text+0x9cf50>
14009df67:     	testq	%rdi, %rdi
14009df6a:     	je	0x14009df1f <.text+0x9cf1f>
14009df6c:     	cmpl	$0x0, 0x43d0(%rax)
14009df73:     	je	0x14009e11c <.text+0x9d11c>
14009df79:     	cmpq	$0x1, %rdi
14009df7d:     	je	0x14009df1f <.text+0x9cf1f>
14009df7f:     	cmpl	$0x0, 0x43d4(%rax)
14009df86:     	je	0x14009e123 <.text+0x9d123>
14009df8c:     	cmpq	$0x2, %rdi
14009df90:     	je	0x14009df1f <.text+0x9cf1f>
14009df92:     	movl	$0x2, %edi
14009df97:     	cmpl	$0x0, 0x43d8(%rax)
14009df9e:     	je	0x14009dfa8 <.text+0x9cfa8>
14009dfa0:     	jmp	0x14009df1f <.text+0x9cf1f>
14009dfa5:     	subq	%rcx, %rdi
14009dfa8:     	cmpq	$0x4, %rdi
14009dfac:     	jae	0x14009e143 <.text+0x9d143>
14009dfb2:     	movl	$0x1, 0x43d0(%rax,%rdi,4)
14009dfbd:     	incq	0x43e8(%rax)
14009dfc4:     	leaq	0x1(%rdi), %rcx
14009dfc8:     	xorl	%edx, %edx
14009dfca:     	cmpq	$0x4, %rcx
14009dfce:     	cmovneq	%rcx, %rdx
14009dfd2:     	movq	%rdx, 0x43e0(%rax)
14009dfd9:     	movq	0x170(%rbp), %rcx
14009dfe0:     	movq	%rcx, -0x18(%rbp)
14009dfe4:     	movq	0x168(%rbp), %rcx
14009dfeb:     	movq	%rcx, -0x20(%rbp)
14009dfef:     	movl	0x178(%rbp), %ecx
14009dff5:     	movl	%ecx, -0x10(%rbp)
14009dff8:     	movl	%r13d, -0xc(%rbp)
14009dffc:     	movw	%r12w, -0x8(%rbp)
14009e001:     	movb	%r15b, -0x6(%rbp)
14009e005:     	movzbl	0x17f(%rbp), %ecx
14009e00c:     	movb	%cl, -0x5(%rbp)
14009e00f:     	movss	%xmm6, -0x4(%rbp)
14009e014:     	movq	%r14, (%rbp)
14009e018:     	testq	%rbx, %rbx
14009e01b:     	je	0x14009e082 <.text+0x9d082>
14009e01d:     	movb	$0x1, 0x8(%rbp)
14009e021:     	movb	%bl, 0x9(%rbp)
14009e024:     	leaq	0xa(%rbp), %r14
14009e028:     	movl	$0x80, %r8d
14009e02e:     	subq	%rbx, %r8
14009e031:     	leaq	(%rbx,%rbp), %rcx
14009e035:     	addq	$0xa, %rcx
14009e039:     	movq	%rax, %r15
14009e03c:     	xorl	%edx, %edx
14009e03e:     	callq	0x14024fcf2 <.text+0x24ecf2>
14009e043:     	leaq	0x150(%rbp), %rdx
14009e04a:     	movq	%r14, %rcx
14009e04d:     	movq	%rbx, %r8
14009e050:     	callq	0x14024fce0 <.text+0x24ece0>
14009e055:     	movzwl	-0x4(%rbp), %eax
14009e059:     	addl	$0x2, %eax
14009e05c:     	movl	%eax, 0x43d0(%r15,%rdi,4)
14009e064:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009e06b:     	addq	%rax, %rsi
14009e06e:     	movzbl	0x8(%rbp), %eax
14009e072:     	leaq	0x1d01c7(%rip), %rcx    # 0x14026e240
14009e079:     	movslq	(%rcx,%rax,4), %rax
14009e07d:     	addq	%rcx, %rax
14009e080:     	jmpq	*%rax
14009e082:     	movb	$0x0, 0x8(%rbp)
14009e086:     	movzwl	-0x4(%rbp), %ecx
14009e08a:     	addl	$0x2, %ecx
14009e08d:     	movl	%ecx, 0x43d0(%rax,%rdi,4)
14009e094:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009e09b:     	addq	%rax, %rsi
14009e09e:     	movzbl	0x8(%rbp), %eax
14009e0a2:     	leaq	0x1d0197(%rip), %rcx    # 0x14026e240
14009e0a9:     	movslq	(%rcx,%rax,4), %rax
14009e0ad:     	addq	%rcx, %rax
14009e0b0:     	jmpq	*%rax
14009e0b2:     	movaps	-0x20(%rbp), %xmm0
14009e0b6:     	movaps	-0x10(%rbp), %xmm1
14009e0ba:     	movups	%xmm1, 0x10(%rsi)
14009e0be:     	movups	%xmm0, (%rsi)
14009e0c1:     	movb	$0x0, 0x28(%rsi)
14009e0c5:     	movq	(%rbp), %rax
14009e0c9:     	movq	%rax, 0x20(%rsi)
14009e0cd:     	jmp	0x14009df1f <.text+0x9cf1f>
14009e0d2:     	leaq	-0x20(%rbp), %rdx
14009e0d6:     	movl	$0x130, %r8d            # imm = 0x130
14009e0dc:     	movq	%rsi, %rcx
14009e0df:     	callq	0x14024fce0 <.text+0x24ece0>
14009e0e4:     	jmp	0x14009df1f <.text+0x9cf1f>
14009e0e9:     	movq	(%rbp), %r8
14009e0ed:     	movq	0x10(%rbp), %r9
14009e0f1:     	leaq	-0x20(%rbp), %rdx
14009e0f5:     	movq	%rsi, %rcx
14009e0f8:     	callq	0x14000b2d0 <.text+0xa2d0>
14009e0fd:     	jmp	0x14009df1f <.text+0x9cf1f>
14009e102:     	leaq	0xa(%rbp), %r8
14009e106:     	movzbl	0x9(%rbp), %r9d
14009e10b:     	leaq	-0x20(%rbp), %rdx
14009e10f:     	movq	%rsi, %rcx
14009e112:     	callq	0x14000b1c0 <.text+0xa1c0>
14009e117:     	jmp	0x14009df1f <.text+0x9cf1f>
14009e11c:     	xorl	%edi, %edi
14009e11e:     	jmp	0x14009dfa8 <.text+0x9cfa8>
14009e123:     	movl	$0x1, %edi
14009e128:     	jmp	0x14009dfa8 <.text+0x9cfa8>
14009e12d:     	leaq	0x1ccc6c(%rip), %r8     # 0x14026ada0
14009e134:     	movl	$0x4, %edx
14009e139:     	movq	%rdi, %rcx
14009e13c:     	callq	0x140250563 <.text+0x24f563>
14009e141:     	ud2
14009e143:     	leaq	0x1ccc6e(%rip), %r8     # 0x14026adb8
14009e14a:     	movl	$0x4, %edx
14009e14f:     	movq	%rdi, %rcx
14009e152:     	callq	0x140250563 <.text+0x24f563>
14009e157:     	ud2

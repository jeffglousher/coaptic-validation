from pathlib import Path
import re,json
r=Path(__file__).resolve().parent

def records(path):
 result={}
 for block in re.split(r'(?m)(?=^print-type-size type:)',path.read_text(encoding='utf-8')):
  lines=block.splitlines()
  if not lines:continue
  head=lines[0]
  if not head.startswith('print-type-size type: `{async fn body of coaptic::app::'):continue
  name=next((n for n in ['issue_q_window_async','issue_q_selection_async','send_issued_async','q_response_mid_async'] if '::'+n+'<' in head),None)
  if name and 'ServiceIo' in head:
   arm='allocated' if 'coaptic::storage::AllocMemory' in head else 'fixed' if 'coaptic::storage::Memory<' in head else None
   if arm:
    key=name+'/'+arm;assert key not in result
    result[key]={'bytes':int(re.search(r'`: (\d+) bytes',head)[1]),'record':head,'metadata_fields':[line for line in lines if 'var `.meta`' in line or 'local `.meta`' in line]}
 return result
before=records(r/'preceding-nested-layout.txt');after=records(r/'owner-layout.txt');assert before.keys()==after.keys() and len(before)==8
rows=[{'helper':k,'before':before[k],'candidate':after[k]} for k in sorted(before)]
assert all(x['candidate']['bytes']<x['before']['bytes'] for x in rows)
x={'predecessor':'ecf1747849fdd5f95224ff58995cbb4ef6d38f59','candidate':'995ae9379c6ab5c8d0608edfda970a674efbbc9b','rows':rows,'scope':'Selected compiler future owners; alternatives overlap and child fields are nested. Do not sum with complete futures or infer CPU cost/peak stack.'}
(r/'nested-comparison.json').write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
for row in rows:print(row['helper'],row['before']['bytes'],row['candidate']['bytes'])

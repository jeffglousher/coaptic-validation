
D:\CoapticCurrent\borrowed-send-chain-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009d240:     	pushq	%rbp
14009d241:     	pushq	%r15
14009d243:     	pushq	%r14
14009d245:     	pushq	%r13
14009d247:     	pushq	%r12
14009d249:     	pushq	%rsi
14009d24a:     	pushq	%rdi
14009d24b:     	pushq	%rbx
14009d24c:     	subq	$0x218, %rsp            # imm = 0x218
14009d253:     	leaq	0x80(%rsp), %rbp
14009d25b:     	movaps	%xmm6, 0x180(%rbp)
14009d262:     	leaq	0x1970(%rcx), %rsi
14009d269:     	leaq	0x1998(%rcx), %r8
14009d270:     	movl	$0x4, %r11d
14009d276:     	xorl	%eax, %eax
14009d278:     	movl	$0x1, %r9d
14009d27e:     	xorl	%r10d, %r10d
14009d281:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009d288:     	addq	%r8, %rdi
14009d28b:     	nopl	(%rax,%rax)
14009d290:     	cmpb	$0x2, -0xe(%rdi)
14009d294:     	jne	0x14009d2b0 <.text+0x9c2b0>
14009d296:     	incq	%r10
14009d299:     	addq	$0x130, %rdi            # imm = 0x130
14009d2a0:     	cmpq	%r10, %r11
14009d2a3:     	jne	0x14009d290 <.text+0x9c290>
14009d2a5:     	jmp	0x14009d2f5 <.text+0x9c2f5>
14009d2a7:     	nopw	(%rax,%rax)
14009d2b0:     	movq	-0x8(%rdi), %r11
14009d2b4:     	cmpb	$0x3, (%rdi)
14009d2b7:     	setne	%bl
14009d2ba:     	testq	%r11, %r11
14009d2bd:     	sete	%dil
14009d2c1:     	orb	%bl, %dil
14009d2c4:     	cmpq	%r14, %r11
14009d2c7:     	setae	%bl
14009d2ca:     	andb	%al, %bl
14009d2cc:     	testb	%dil, %dil
14009d2cf:     	cmoveq	%r9, %rax
14009d2d3:     	orb	%dil, %bl
14009d2d6:     	cmoveq	%r10, %rdx
14009d2da:     	cmoveq	%r11, %r14
14009d2de:     	incq	%r10
14009d2e1:     	cmpq	$0x5, %r10
14009d2e5:     	movl	$0x4, %r11d
14009d2eb:     	cmovaeq	%r10, %r11
14009d2ef:     	cmpq	$0x3, %r10
14009d2f3:     	jbe	0x14009d281 <.text+0x9c281>
14009d2f5:     	testb	$0x1, %al
14009d2f7:     	je	0x14009d3f1 <.text+0x9c3f1>
14009d2fd:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009d304:     	movzbl	0x1a(%rsi,%rax), %r15d
14009d30a:     	cmpb	$0x2, %r15b
14009d30e:     	je	0x14009d3f1 <.text+0x9c3f1>
14009d314:     	addq	%rsi, %rax
14009d317:     	cmpb	$0x3, 0x28(%rax)
14009d31b:     	jne	0x14009d3f1 <.text+0x9c3f1>
14009d321:     	movq	0x30(%rax), %r8
14009d325:     	movq	(%rax), %rdx
14009d328:     	movq	%rdx, 0x168(%rbp)
14009d32f:     	movq	0x8(%rax), %rdx
14009d333:     	movq	%rdx, 0x170(%rbp)
14009d33a:     	movl	0x10(%rax), %ebx
14009d33d:     	movl	0x14(%rax), %r12d
14009d341:     	movzwl	0x18(%rax), %edi
14009d345:     	movzbl	0x1b(%rax), %edx
14009d349:     	movb	%dl, 0x17f(%rbp)
14009d34f:     	movss	0x1c(%rax), %xmm6
14009d354:     	movzwl	0x1c(%rax), %eax
14009d358:     	movzwl	%ax, %edx
14009d35b:     	cmpq	$0x1, %r8
14009d35f:     	ja	0x14009d3bb <.text+0x9c3bb>
14009d361:     	cmpb	$0x1, 0x1968(%rcx,%r8)
14009d36a:     	jne	0x14009d3bb <.text+0x9c3bb>
14009d36c:     	cmpb	$0x0, 0x196a(%rcx,%r8)
14009d375:     	jne	0x14009d3bb <.text+0x9c3bb>
14009d377:     	movb	$0x0, 0x1968(%rcx,%r8)
14009d380:     	decq	0x1960(%rcx)
14009d387:     	leaq	0xfe0(%rcx), %r9
14009d38e:     	movq	$0x0, 0x18e0(%rcx,%r8,8)
14009d39a:     	leaq	(%r8,%r8,8), %r10
14009d39e:     	leaq	(%r10,%r10,2), %r10
14009d3a2:     	addq	%r8, %r10
14009d3a5:     	movb	$0x2, 0x95a(%r9,%r10)
14009d3ae:     	leaq	(%r8,%r8,2), %r8
14009d3b2:     	movb	$0x2, 0x91d(%r9,%r8,8)
14009d3bb:     	addl	$0x2, %edx
14009d3be:     	movb	$0x1, %r9b
14009d3c1:     	cmpl	%edx, 0x1e30(%rcx)
14009d3c7:     	jne	0x14009d3d7 <.text+0x9c3d7>
14009d3c9:     	movzbl	0x198a(%rcx), %r8d
14009d3d1:     	cmpb	$0x2, %r8b
14009d3d5:     	jne	0x14009d40e <.text+0x9c40e>
14009d3d7:     	xorl	%r8d, %r8d
14009d3da:     	cmpl	%edx, 0x1e34(%rcx)
14009d3e0:     	movl	%ebx, 0x178(%rbp)
14009d3e6:     	jne	0x14009d49d <.text+0x9c49d>
14009d3ec:     	jmp	0x14009d48b <.text+0x9c48b>
14009d3f1:     	xorl	%eax, %eax
14009d3f3:     	movaps	0x180(%rbp), %xmm6
14009d3fa:     	addq	$0x218, %rsp            # imm = 0x218
14009d401:     	popq	%rbx
14009d402:     	popq	%rdi
14009d403:     	popq	%rsi
14009d404:     	popq	%r12
14009d406:     	popq	%r13
14009d408:     	popq	%r14
14009d40a:     	popq	%r15
14009d40c:     	popq	%rbp
14009d40d:     	retq
14009d40e:     	cmpw	%ax, 0x198c(%rcx)
14009d415:     	sete	%r9b
14009d419:     	cmpl	%ebx, 0x1980(%rcx)
14009d41f:     	sete	%r10b
14009d423:     	andb	%r9b, %r10b
14009d426:     	cmpl	%r12d, 0x1984(%rcx)
14009d42d:     	sete	%r9b
14009d431:     	cmpw	%di, 0x1988(%rcx)
14009d438:     	sete	%r11b
14009d43c:     	andb	%r9b, %r11b
14009d43f:     	andb	%r10b, %r11b
14009d442:     	cmpb	%r15b, %r8b
14009d445:     	sete	%r8b
14009d449:     	movq	0x1978(%rcx), %r9
14009d450:     	xorq	0x170(%rbp), %r9
14009d457:     	movq	0x1970(%rcx), %r10
14009d45e:     	xorq	0x168(%rbp), %r10
14009d465:     	orq	%r9, %r10
14009d468:     	sete	%r9b
14009d46c:     	andb	%r8b, %r9b
14009d46f:     	andb	%r11b, %r9b
14009d472:     	movzbl	%r9b, %r8d
14009d476:     	movl	%r8d, %r9d
14009d479:     	xorb	$0x1, %r9b
14009d47d:     	cmpl	%edx, 0x1e34(%rcx)
14009d483:     	movl	%ebx, 0x178(%rbp)
14009d489:     	jne	0x14009d49d <.text+0x9c49d>
14009d48b:     	movzbl	0x1aba(%rcx), %r10d
14009d493:     	cmpb	$0x2, %r10b
14009d497:     	jne	0x14009d54e <.text+0x9c54e>
14009d49d:     	xorl	%r9d, %r9d
14009d4a0:     	cmpl	%edx, 0x1e38(%rcx)
14009d4a6:     	jne	0x14009d5f4 <.text+0x9c5f4>
14009d4ac:     	movzbl	0x1bea(%rcx), %r10d
14009d4b4:     	cmpb	$0x2, %r10b
14009d4b8:     	je	0x14009d5f4 <.text+0x9c5f4>
14009d4be:     	cmpb	%r15b, %r10b
14009d4c1:     	jne	0x14009d5f4 <.text+0x9c5f4>
14009d4c7:     	cmpw	%ax, 0x1bec(%rcx)
14009d4ce:     	jne	0x14009d5f4 <.text+0x9c5f4>
14009d4d4:     	cmpl	%ebx, 0x1be0(%rcx)
14009d4da:     	jne	0x14009d5f4 <.text+0x9c5f4>
14009d4e0:     	cmpl	%r12d, 0x1be4(%rcx)
14009d4e7:     	jne	0x14009d5f4 <.text+0x9c5f4>
14009d4ed:     	cmpw	%di, 0x1be8(%rcx)
14009d4f4:     	jne	0x14009d5f4 <.text+0x9c5f4>
14009d4fa:     	movq	0x1bd0(%rcx), %r10
14009d501:     	xorq	0x168(%rbp), %r10
14009d508:     	movq	0x1bd8(%rcx), %r11
14009d50f:     	xorq	0x170(%rbp), %r11
14009d516:     	orq	%r10, %r11
14009d519:     	jne	0x14009d5f4 <.text+0x9c5f4>
14009d51f:     	movl	%r12d, %r13d
14009d522:     	movl	%edi, %r12d
14009d525:     	movb	$0x1, %dil
14009d528:     	testq	%r8, %r8
14009d52b:     	jne	0x14009d680 <.text+0x9c680>
14009d531:     	movl	$0x1, %r8d
14009d537:     	movl	$0x2, %r9d
14009d53d:     	movl	%r12d, %edi
14009d540:     	movl	%r13d, %r12d
14009d543:     	movl	0x178(%rbp), %ebx
14009d549:     	jmp	0x14009d5f4 <.text+0x9c5f4>
14009d54e:     	cmpw	%ax, 0x1abc(%rcx)
14009d555:     	setne	%r11b
14009d559:     	cmpl	%ebx, 0x1ab0(%rcx)
14009d55f:     	setne	%bl
14009d562:     	orb	%r11b, %bl
14009d565:     	movl	%r12d, %r13d
14009d568:     	cmpl	%r12d, 0x1ab4(%rcx)
14009d56f:     	setne	%r11b
14009d573:     	movl	%edi, %r12d
14009d576:     	cmpw	%di, 0x1ab8(%rcx)
14009d57d:     	setne	%dil
14009d581:     	orb	%r11b, %dil
14009d584:     	orb	%bl, %dil
14009d587:     	cmpb	%r15b, %r10b
14009d58a:     	setne	%r11b
14009d58e:     	movq	0x1aa8(%rcx), %r10
14009d595:     	xorq	0x170(%rbp), %r10
14009d59c:     	movq	0x1aa0(%rcx), %rbx
14009d5a3:     	xorq	0x168(%rbp), %rbx
14009d5aa:     	orq	%r10, %rbx
14009d5ad:     	setne	%r10b
14009d5b1:     	orb	%r11b, %r10b
14009d5b4:     	orb	%dil, %r10b
14009d5b7:     	orb	%r10b, %r9b
14009d5ba:     	testb	%r10b, %r10b
14009d5bd:     	movl	$0x1, %r11d
14009d5c3:     	cmoveq	%r11, %r8
14009d5c7:     	testb	$0x1, %r9b
14009d5cb:     	je	0x14009d67a <.text+0x9c67a>
14009d5d1:     	notb	%r10b
14009d5d4:     	movzbl	%r10b, %r9d
14009d5d8:     	andl	$0x1, %r9d
14009d5dc:     	movl	%r12d, %edi
14009d5df:     	movl	%r13d, %r12d
14009d5e2:     	movl	0x178(%rbp), %ebx
14009d5e8:     	cmpl	%edx, 0x1e38(%rcx)
14009d5ee:     	je	0x14009d4ac <.text+0x9c4ac>
14009d5f4:     	cmpl	%edx, 0x1e3c(%rcx)
14009d5fa:     	jne	0x14009d608 <.text+0x9c608>
14009d5fc:     	movzbl	0x1d1a(%rcx), %edx
14009d603:     	cmpb	$0x2, %dl
14009d606:     	jne	0x14009d61a <.text+0x9c61a>
14009d608:     	movl	%r12d, %r13d
14009d60b:     	movl	%edi, %r12d
14009d60e:     	xorl	%edi, %edi
14009d610:     	testq	%r8, %r8
14009d613:     	jne	0x14009d680 <.text+0x9c680>
14009d615:     	jmp	0x14009d6aa <.text+0x9c6aa>
14009d61a:     	cmpb	%r15b, %dl
14009d61d:     	jne	0x14009d608 <.text+0x9c608>
14009d61f:     	cmpw	%ax, 0x1d1c(%rcx)
14009d626:     	jne	0x14009d608 <.text+0x9c608>
14009d628:     	cmpl	%ebx, 0x1d10(%rcx)
14009d62e:     	jne	0x14009d608 <.text+0x9c608>
14009d630:     	cmpl	%r12d, 0x1d14(%rcx)
14009d637:     	jne	0x14009d608 <.text+0x9c608>
14009d639:     	cmpw	%di, 0x1d18(%rcx)
14009d640:     	jne	0x14009d608 <.text+0x9c608>
14009d642:     	movq	0x1d00(%rcx), %rdx
14009d649:     	xorq	0x168(%rbp), %rdx
14009d650:     	movq	0x1d08(%rcx), %r10
14009d657:     	xorq	0x170(%rbp), %r10
14009d65e:     	orq	%rdx, %r10
14009d661:     	jne	0x14009d608 <.text+0x9c608>
14009d663:     	movl	%r12d, %r13d
14009d666:     	movl	%edi, %r12d
14009d669:     	testq	%r8, %r8
14009d66c:     	movl	$0x3, %edx
14009d671:     	cmoveq	%rdx, %r9
14009d675:     	movl	%r8d, %edi
14009d678:     	jmp	0x14009d680 <.text+0x9c680>
14009d67a:     	movb	$0x1, %dil
14009d67d:     	xorl	%r9d, %r9d
14009d680:     	cmpl	$0x0, 0x1e30(%rcx,%r9,4)
14009d689:     	je	0x14009d6aa <.text+0x9c6aa>
14009d68b:     	movl	$0x0, 0x1e30(%rcx,%r9,4)
14009d697:     	decq	0x1e48(%rcx)
14009d69e:     	imulq	$0x130, %r9, %rdx       # imm = 0x130
14009d6a5:     	movb	$0x2, 0x1a(%rsi,%rdx)
14009d6aa:     	xorps	%xmm0, %xmm0
14009d6ad:     	movaps	%xmm0, 0x150(%rbp)
14009d6b4:     	movb	$0x0, 0x132(%rbp)
14009d6bb:     	movw	%ax, 0x130(%rbp)
14009d6c2:     	leaq	0x133(%rbp), %rdx
14009d6c9:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009d6d2:     	movq	$0x0, 0x133(%rbp)
14009d6dd:     	movq	$0x8, 0x110(%rbp)
14009d6e8:     	movq	$0x0, 0x118(%rbp)
14009d6f3:     	movq	$0x1, 0x120(%rbp)
14009d6fe:     	movq	$0x0, 0x128(%rbp)
14009d709:     	movq	%rdx, 0x30(%rsp)
14009d70e:     	movw	%ax, 0x28(%rsp)
14009d713:     	movq	$0x0, 0x58(%rsp)
14009d71c:     	movq	$0x1, 0x50(%rsp)
14009d725:     	movq	$0x8, 0x48(%rsp)
14009d72e:     	movq	$0x8, 0x40(%rsp)
14009d737:     	movq	$0x0, 0x38(%rsp)
14009d740:     	movb	$0x0, 0x20(%rsp)
14009d745:     	leaq	0x140(%rbp), %rax
14009d74c:     	leaq	0x150(%rbp), %rdx
14009d753:     	movl	$0x10, %r8d
14009d759:     	movq	%rcx, %rbx
14009d75c:     	movq	%rax, %rcx
14009d75f:     	movb	$0x2, %r9b
14009d762:     	callq	0x140005590 <.text+0x4590>
14009d767:     	cmpb	$0x0, 0x140(%rbp)
14009d76e:     	jne	0x14009d78f <.text+0x9c78f>
14009d770:     	testb	%dil, %dil
14009d773:     	jne	0x14009d78f <.text+0x9c78f>
14009d775:     	movq	%rbx, %rax
14009d778:     	movq	0x148(%rbp), %rbx
14009d77f:     	cmpq	$0x10, %rbx
14009d783:     	ja	0x14009d78f <.text+0x9c78f>
14009d785:     	cmpq	$0x4, 0x1e48(%rax)
14009d78d:     	jne	0x14009d796 <.text+0x9c796>
14009d78f:     	movb	$0x1, %al
14009d791:     	jmp	0x14009d3f3 <.text+0x9c3f3>
14009d796:     	movq	0x1e40(%rax), %rdi
14009d79d:     	cmpq	$0x3, %rdi
14009d7a1:     	ja	0x14009d99d <.text+0x9c99d>
14009d7a7:     	cmpl	$0x0, 0x1e30(%rax,%rdi,4)
14009d7af:     	je	0x14009d822 <.text+0x9c822>
14009d7b1:     	leaq	(,%rdi,4), %rdx
14009d7b9:     	xorl	%ecx, %ecx
14009d7bb:     	nopl	(%rax,%rax)
14009d7c0:     	cmpl	$0x0, 0x1e30(%rax,%rdx)
14009d7c8:     	je	0x14009d815 <.text+0x9c815>
14009d7ca:     	addq	$0x4, %rdx
14009d7ce:     	decq	%rcx
14009d7d1:     	cmpq	$0x10, %rdx
14009d7d5:     	jne	0x14009d7c0 <.text+0x9c7c0>
14009d7d7:     	testq	%rdi, %rdi
14009d7da:     	je	0x14009d78f <.text+0x9c78f>
14009d7dc:     	cmpl	$0x0, 0x1e30(%rax)
14009d7e3:     	je	0x14009d98c <.text+0x9c98c>
14009d7e9:     	cmpq	$0x1, %rdi
14009d7ed:     	je	0x14009d78f <.text+0x9c78f>
14009d7ef:     	cmpl	$0x0, 0x1e34(%rax)
14009d7f6:     	je	0x14009d993 <.text+0x9c993>
14009d7fc:     	cmpq	$0x2, %rdi
14009d800:     	je	0x14009d78f <.text+0x9c78f>
14009d802:     	movl	$0x2, %edi
14009d807:     	cmpl	$0x0, 0x1e38(%rax)
14009d80e:     	je	0x14009d818 <.text+0x9c818>
14009d810:     	jmp	0x14009d78f <.text+0x9c78f>
14009d815:     	subq	%rcx, %rdi
14009d818:     	cmpq	$0x4, %rdi
14009d81c:     	jae	0x14009d9b3 <.text+0x9c9b3>
14009d822:     	movl	$0x1, 0x1e30(%rax,%rdi,4)
14009d82d:     	incq	0x1e48(%rax)
14009d834:     	leaq	0x1(%rdi), %rcx
14009d838:     	xorl	%edx, %edx
14009d83a:     	cmpq	$0x4, %rcx
14009d83e:     	cmovneq	%rcx, %rdx
14009d842:     	movq	%rdx, 0x1e40(%rax)
14009d849:     	movq	0x170(%rbp), %rcx
14009d850:     	movq	%rcx, -0x18(%rbp)
14009d854:     	movq	0x168(%rbp), %rcx
14009d85b:     	movq	%rcx, -0x20(%rbp)
14009d85f:     	movl	0x178(%rbp), %ecx
14009d865:     	movl	%ecx, -0x10(%rbp)
14009d868:     	movl	%r13d, -0xc(%rbp)
14009d86c:     	movw	%r12w, -0x8(%rbp)
14009d871:     	movb	%r15b, -0x6(%rbp)
14009d875:     	movzbl	0x17f(%rbp), %ecx
14009d87c:     	movb	%cl, -0x5(%rbp)
14009d87f:     	movss	%xmm6, -0x4(%rbp)
14009d884:     	movq	%r14, (%rbp)
14009d888:     	testq	%rbx, %rbx
14009d88b:     	je	0x14009d8f2 <.text+0x9c8f2>
14009d88d:     	movb	$0x1, 0x8(%rbp)
14009d891:     	movb	%bl, 0x9(%rbp)
14009d894:     	leaq	0xa(%rbp), %r14
14009d898:     	movl	$0x80, %r8d
14009d89e:     	subq	%rbx, %r8
14009d8a1:     	leaq	(%rbx,%rbp), %rcx
14009d8a5:     	addq	$0xa, %rcx
14009d8a9:     	movq	%rax, %r15
14009d8ac:     	xorl	%edx, %edx
14009d8ae:     	callq	0x14024fcf2 <.text+0x24ecf2>
14009d8b3:     	leaq	0x150(%rbp), %rdx
14009d8ba:     	movq	%r14, %rcx
14009d8bd:     	movq	%rbx, %r8
14009d8c0:     	callq	0x14024fce0 <.text+0x24ece0>
14009d8c5:     	movzwl	-0x4(%rbp), %eax
14009d8c9:     	addl	$0x2, %eax
14009d8cc:     	movl	%eax, 0x1e30(%r15,%rdi,4)
14009d8d4:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009d8db:     	addq	%rax, %rsi
14009d8de:     	movzbl	0x8(%rbp), %eax
14009d8e2:     	leaq	0x1d0947(%rip), %rcx    # 0x14026e230
14009d8e9:     	movslq	(%rcx,%rax,4), %rax
14009d8ed:     	addq	%rcx, %rax
14009d8f0:     	jmpq	*%rax
14009d8f2:     	movb	$0x0, 0x8(%rbp)
14009d8f6:     	movzwl	-0x4(%rbp), %ecx
14009d8fa:     	addl	$0x2, %ecx
14009d8fd:     	movl	%ecx, 0x1e30(%rax,%rdi,4)
14009d904:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009d90b:     	addq	%rax, %rsi
14009d90e:     	movzbl	0x8(%rbp), %eax
14009d912:     	leaq	0x1d0917(%rip), %rcx    # 0x14026e230
14009d919:     	movslq	(%rcx,%rax,4), %rax
14009d91d:     	addq	%rcx, %rax
14009d920:     	jmpq	*%rax
14009d922:     	movaps	-0x20(%rbp), %xmm0
14009d926:     	movaps	-0x10(%rbp), %xmm1
14009d92a:     	movups	%xmm1, 0x10(%rsi)
14009d92e:     	movups	%xmm0, (%rsi)
14009d931:     	movb	$0x0, 0x28(%rsi)
14009d935:     	movq	(%rbp), %rax
14009d939:     	movq	%rax, 0x20(%rsi)
14009d93d:     	jmp	0x14009d78f <.text+0x9c78f>
14009d942:     	leaq	-0x20(%rbp), %rdx
14009d946:     	movl	$0x130, %r8d            # imm = 0x130
14009d94c:     	movq	%rsi, %rcx
14009d94f:     	callq	0x14024fce0 <.text+0x24ece0>
14009d954:     	jmp	0x14009d78f <.text+0x9c78f>
14009d959:     	movq	(%rbp), %r8
14009d95d:     	movq	0x10(%rbp), %r9
14009d961:     	leaq	-0x20(%rbp), %rdx
14009d965:     	movq	%rsi, %rcx
14009d968:     	callq	0x14000b2d0 <.text+0xa2d0>
14009d96d:     	jmp	0x14009d78f <.text+0x9c78f>
14009d972:     	leaq	0xa(%rbp), %r8
14009d976:     	movzbl	0x9(%rbp), %r9d
14009d97b:     	leaq	-0x20(%rbp), %rdx
14009d97f:     	movq	%rsi, %rcx
14009d982:     	callq	0x14000b1c0 <.text+0xa1c0>
14009d987:     	jmp	0x14009d78f <.text+0x9c78f>
14009d98c:     	xorl	%edi, %edi
14009d98e:     	jmp	0x14009d818 <.text+0x9c818>
14009d993:     	movl	$0x1, %edi
14009d998:     	jmp	0x14009d818 <.text+0x9c818>
14009d99d:     	leaq	0x1cd3fc(%rip), %r8     # 0x14026ada0
14009d9a4:     	movl	$0x4, %edx
14009d9a9:     	movq	%rdi, %rcx
14009d9ac:     	callq	0x140250563 <.text+0x24f563>
14009d9b1:     	ud2
14009d9b3:     	leaq	0x1cd3fe(%rip), %r8     # 0x14026adb8
14009d9ba:     	movl	$0x4, %edx
14009d9bf:     	movq	%rdi, %rcx
14009d9c2:     	callq	0x140250563 <.text+0x24f563>
14009d9c7:     	ud2

import os,sys,json,subprocess,hashlib
from pathlib import Path
root=Path(r'C:/Users/jeffg/AppData/Local/CoapticQualification/protected-path-20261022');suite=Path(r'D:/codex-work/coaptic-validation')
sys.path.insert(0,str(suite/'tools/benchmark'))
import campaign
from prepare import source_identity
exe=Path(r'D:/coaptic-batch-interop-target/bench-go-patched.exe');go=r'D:/coaptic-tools/benchmark-go-1.26.0/go/bin/go.exe'
env=dict(os.environ,GOCACHE='D:/coaptic-batch-interop-target/go-build',GOMODCACHE='D:/coaptic-batch-interop-target/go-mod',GOTOOLCHAIN='go1.26.9')
version=subprocess.check_output([go,'version'],env=env,text=True).strip();assert version=='go version go1.26.9 windows/amd64',version
cmd=[go,'-C',str(suite/'tools/benchmark/peers/go'),'build','-mod=readonly','-trimpath','-o',str(exe),'.']
with (root/'patched-go-build.log').open('x',encoding='utf-8') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
manifest=campaign.read(root/'matched-prepared.json');native=campaign.read(root/'native-prepared.json');tasks=[]
for p in manifest['peers']:
 if p['security'].startswith('DTLS'):
  for m in ['con','non']:tasks.append(('dtls',p,m))
 if p['id']=='go-coap':
  for m in ['con','non']:tasks.append(('matched',p,m))
 if p['id']=='http3':
  for m in ['warm','cold']:tasks.append(('http3',p,m))
for p in native['peers']:
 if p['id']=='go-coap':
  for m in ['con','non']:tasks.append(('native',p,m))
rows=[]
for stratum,peer,mode in tasks:
 peer=json.loads(json.dumps(peer))
 for field in ['server','driver']:
  if Path(peer[field][0]).name=='bench-go.exe':peer[field][0]=str(exe)
 case=dict(id=f'{stratum}-{peer["id"]}-{mode}-65536-16',protocol=peer['protocol'],security=peer['security'],bytes=65536,concurrency=16,mode=mode,operations=16,warmup=1,timeout_ms=1000)
 record=dict(stratum=stratum,peer=peer['id'],case=case,identities=campaign.peer_identity(peer),started=campaign.utc())
 try:record.update(campaign.run_cell(peer,case))
 except Exception as error:record.update(error=repr(error),finished=campaign.utc())
 campaign.write_new(root/'patched-go-qualification'/f'{case["id"]}.json',record);rows.append(record)
 print(json.dumps({'case':case['id'],'completed':record.get('sample',{}).get('completed'),'failed':record.get('sample',{}).get('failed'),'error':record.get('error')}),flush=True)
value=dict(schema='coaptic-patched-go-qualification/1',scope='focused finite source-matched functional check; not a repeated comparative timing window; raw timing not pooled into original statistics',performance_inference=False,toolchain=version,command=cmd,compiler_environment={k:env[k] for k in ['GOTOOLCHAIN','GOCACHE','GOMODCACHE']},binary_sha256=campaign.digest(exe),sources={'core':source_identity(suite/'coaptic'),'suite':source_identity(suite)},source_file_sha256={f:campaign.digest(suite/f) for f in ['tools/benchmark/peers/go/go.mod','tools/benchmark/peers/go/go.sum','tools/benchmark/peers/go/main.go','tools/benchmark/peers/go/dtls.go','tools/benchmark/peers/go/clock_windows.go']},cells=rows)
value['summary']=dict(cells=len(rows),invalid=sum('sample' not in r for r in rows),attempted=sum(r.get('sample',{}).get('attempted',0) for r in rows),completed=sum(r.get('sample',{}).get('completed',0) for r in rows),failed=sum(r.get('sample',{}).get('failed',0) for r in rows),warmup_failed=sum(r.get('sample',{}).get('warmup_failed',0) for r in rows))
campaign.write_new(root/'patched-go-qualification.json',value);print(json.dumps(value['summary']),flush=True)

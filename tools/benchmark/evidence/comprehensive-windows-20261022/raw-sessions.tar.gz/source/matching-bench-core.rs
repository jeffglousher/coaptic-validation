//! Socket-free, diagnostics-disabled request-path diagnostic.
//!
//! Identical fixtures can link different Coaptic revisions to isolate core work
//! from OS socket scheduling. Request preparation and complete reply validation
//! are outside each timed poll. Per-call clocks perturb these measurements;
//! they are not production latency or throughput estimates.
use coaptic::message::{Message, MessageId, Opt, Token, Type, decode};
use coaptic::storage::{Capacities, DatagramIo};
use coaptic::{App, Code, ContentFormat, Endpoint, Request, Response, get};
use std::hint::black_box;
use std::time::Instant;

const BODY: [u8; 64] = [0x5a; 64];
const PEER: Endpoint = Endpoint::v4([127, 0, 0, 1], 30000);

struct CoreIo {
    input: [u8; 1472],
    input_len: Option<usize>,
    output: [u8; 1472],
    output_len: Option<usize>,
}

impl coaptic::storage::DatagramTransport for CoreIo {
    type Error = &'static str;
}
impl DatagramIo for CoreIo {
    fn recv(&mut self, buf: &mut [u8]) -> Result<Option<(usize, Endpoint)>, Self::Error> {
        let Some(n) = self.input_len.take() else {
            return Ok(None);
        };
        if n > buf.len() {
            return Err("receive capacity");
        }
        buf[..n].copy_from_slice(&self.input[..n]);
        Ok(Some((n, PEER)))
    }

    fn send(&mut self, peer: Endpoint, bytes: &[u8]) -> Result<usize, Self::Error> {
        if peer != PEER || self.output_len.is_some() || bytes.len() > self.output.len() {
            return Err("unexpected response");
        }
        self.output[..bytes.len()].copy_from_slice(bytes);
        self.output_len = Some(bytes.len());
        Ok(bytes.len())
    }
}

fn representation(_: Request<'_>) -> Response<'static> {
    Response::content(&BODY)
        .content_format(ContentFormat::OCTET_STREAM)
        .etag(b"fixture")
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = std::env::args().collect();
    if !(2..=3).contains(&args.len()) {
        return Err("usage: bench-core OPERATIONS (1..=60000) [unprotected|oscore]".into());
    }
    let operations: usize = args[1].parse()?;
    if !(1..=60000).contains(&operations) {
        return Err("operation limit".into());
    }
    let security = args.get(2).map_or("unprotected", String::as_str);
    let (client_context, server_context) = match security {
        "unprotected" => (None, None),
        "oscore" => {
            let mut material = [0; 24];
            getrandom::fill(&mut material)?;
            let derive = |sender_id, recipient_id| {
                coaptic::oscore::SecurityContext::derive(coaptic::oscore::DeriveParams {
                    master_secret: &material[..16],
                    master_salt: &material[16..],
                    sender_id,
                    recipient_id,
                    id_context: &[],
                })
            };
            let pair = (Some(derive(&[], &[1])?), Some(derive(&[1], &[])?));
            material.fill(0);
            pair
        }
        _ => return Err("security selection".into()),
    };
    let mut client_context = client_context;
    let builder = App::builder()
        .routes::<1>()
        .block_wise::<true>()
        .randomness(|bytes| getrandom::fill(bytes).is_ok())
        .route("bench", get(representation));
    let builder = if let Some(context) = server_context {
        builder.oscore(context)
    } else {
        builder.allow_unprotected()
    };
    let mut app = builder.bind_alloc(
        CoreIo {
            input: [0; 1472],
            input_len: None,
            output: [0; 1472],
            output_len: None,
        },
        Capacities {
            rx_datagram_slots: 4,
            rx_datagram_bytes: 1472,
            tx_datagram_slots: 4,
            tx_datagram_bytes: 1472,
            dedup_entries: 8,
            observe_entries: 4,
            rx_body_slots: Some(1),
            rx_body_bytes: Some(1024),
            tx_body_slots: Some(2),
            tx_body_bytes: Some(1024),
        },
    )?;
    let mut latencies = Vec::with_capacity(operations);
    let mut clock_calibration = Vec::with_capacity(4096);
    for sample in 0..4096 {
        let started = Instant::now();
        black_box(sample);
        clock_calibration.push(started.elapsed().as_nanos());
    }
    let mut opened = [0; 1472];
    let clock = Instant::now();
    for operation in 0..operations + 128 {
        let mid = MessageId::new(operation as u16);
        let token = Token::new(&(operation as u64).to_be_bytes()).ok_or("token")?;
        let options = [Opt::uri_path("bench")];
        let request = Message::con(Code::GET, mid, token).with_options(&options);
        let io = app.transport_mut();
        io.input_len = Some(match client_context.as_mut() {
            Some(context) => context.protect_request(&request, &mut io.input)?,
            None => request.encode(&mut io.input)?,
        });
        let now = clock.elapsed().as_millis() as u64;
        let started = Instant::now();
        let outcome = black_box(black_box(&mut app).poll(black_box(now)));
        let elapsed = started.elapsed().as_nanos();
        outcome.map_err(|_| "poll failure")?;
        let io = app.transport_mut();
        let n = io.output_len.take().ok_or("missing response")?;
        let wire = decode(black_box(&io.output[..n]))?;
        let reply = match client_context.as_mut() {
            Some(context) => {
                let binding = context.take(token).ok_or("request binding")?;
                context.unprotect_response(&wire, binding, &mut opened)?
            }
            None => wire,
        };
        let mut etags = reply.etag();
        if reply.message_id() != mid
            || reply.token() != token
            || reply.ty() != Type::Acknowledgement
            || reply.code() != Code::CONTENT
            || reply.payload() != BODY
            || reply.block2().is_some()
            || reply.content_format().and_then(Result::ok) != Some(ContentFormat::OCTET_STREAM)
            || etags.next() != Some(&b"fixture"[..])
            || etags.next().is_some()
        {
            return Err("response mismatch".into());
        }
        if operation >= 128 {
            latencies.push(elapsed);
        }
    }
    print!(
        "{{\"operations\":{operations},\"warmup\":128,\"security\":\"{security}\",\"black_box\":true,\"measurement\":\"server App::poll with optimizer barriers; request preparation and complete response verification outside clock; OSCORE responses authenticated; timer calibration separate and never subtracted\",\"latencies_ns\":["
    );
    for (i, elapsed) in latencies.iter().enumerate() {
        if i > 0 {
            print!(",");
        }
        print!("{elapsed}");
    }
    print!("],\"clock_calibration_ns\":[");
    for (i, elapsed) in clock_calibration.iter().enumerate() {
        if i > 0 {
            print!(",");
        }
        print!("{elapsed}");
    }
    println!("]}}");
    Ok(())
}

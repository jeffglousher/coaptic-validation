import os,json,subprocess,hashlib
from pathlib import Path
root=Path(r'C:/Users/jeffg/AppData/Local/CoapticQualification/protected-path-20261022');suite=Path(r'D:/codex-work/coaptic-validation')
env=dict(os.environ,RUSTUP_TOOLCHAIN='1.99.0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_RELEASE_DEBUG='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
prefix=[r'C:/Users/jeffg/.cargo/bin/agent-resources.exe','run','--id','coaptic-core-reusable','--directory',str(suite),'--']
with (root/'resource-artifacts.jsonl').open('w',encoding='utf-8') as out,(root/'resource-build.log').open('w',encoding='utf-8') as log:
 r=subprocess.run(prefix+['cargo','build','--release','--locked','--manifest-path','tools/benchmark/native/Cargo.toml','-p','bench-rust-server','--bin','bench-rust-server','--message-format=json'],env=env,cwd=suite,stdout=out,stderr=log)
 if r.returncode:raise SystemExit(r.returncode)
rows=[json.loads(l) for l in (root/'resource-artifacts.jsonl').read_text().splitlines()]
libs=[r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='coaptic' and set(r['features'])=={'alloc','oscore','std'}]
assert len(libs)==1,[(r.get('features'),r.get('filenames')) for r in libs]
rlib=next(f for f in libs[0]['filenames'] if f.endswith('.rlib'))
cmd=['rustc','--edition=2024','-Copt-level=3','-Clto=thin','-Ccodegen-units=1','-Cdebuginfo=0',str(root/'resource-probe.rs'),'--extern','coaptic='+rlib,'-L','dependency='+str(Path(rlib).parent),'-o',str(root/'resource-probe.exe')]
r=subprocess.run(cmd,env=env,cwd=suite,capture_output=True,text=True,encoding='utf-8')
(root/'resource-probe-compile.log').write_text(r.stdout+r.stderr,encoding='utf-8')
if r.returncode:raise SystemExit(r.returncode)
r=subprocess.run([str(root/'resource-probe.exe')],capture_output=True,text=True,encoding='utf-8',check=True)
(root/'resource-layout.jsonl').write_text(r.stdout,encoding='utf-8')
meta={'features':libs[0]['features'],'rlib':rlib,'rlib_sha256':hashlib.sha256(Path(rlib).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256((root/'resource-probe.rs').read_bytes()).hexdigest(),'command':cmd,'core':subprocess.check_output(['git','-C',str(suite/'coaptic'),'rev-parse','HEAD'],text=True).strip()}
(root/'resource-layout-meta.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
print(r.stdout,flush=True)

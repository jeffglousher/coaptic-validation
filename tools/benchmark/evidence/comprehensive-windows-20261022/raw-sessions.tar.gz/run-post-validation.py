import os,sys,json,subprocess,collections,hashlib
from pathlib import Path
root=Path(r'C:/Users/jeffg/AppData/Local/CoapticQualification/protected-path-20261022');suite=Path(r'D:/codex-work/coaptic-validation')
sys.path.insert(0,str(suite/'tools/benchmark'))
import campaign,packet_trace
assert all((root/n/f'window-{w}.json').exists() for n in ['native','matched','dtls','http3'] for w in range(5)), 'wait for full matrix'
py=sys.executable
with (root/'small-device.log').open('x',encoding='utf-8') as log:
 cmd=[py,'tools/benchmark/small_device_quick.py','--server','D:/coaptic-batch-interop-target/release/bench-rust-server.exe','--output',str(root/'small-device.json')]
 r=subprocess.run(cmd,cwd=suite,stdout=log,stderr=subprocess.STDOUT)
 print(json.dumps({'small_device_exit':r.returncode}),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
r=subprocess.run([py,str(root/'go-mid-diagnostic.py')],cwd=suite,capture_output=True,text=True,encoding='utf-8')
(root/'go-mid-diagnostic.log').write_text(r.stdout+r.stderr,encoding='utf-8')
print(json.dumps({'go_mid_exit':r.returncode,'output':r.stdout.strip()}),flush=True)
manifest=root/'matched-prepared.json';data=campaign.validate_manifest(campaign.read(manifest))
output=root/'packet-captures';output.mkdir(exist_ok=False)
base=sum(p.stat().st_size for p in root.rglob('*') if p.is_file())
campaign.write_new(output/'OWNER.json',dict(owner='Coaptic9092fd',project='fd7a7c8d-18b2-4e77-9ff0-a328e106adb1',budget_bytes=256*1024*1024,scope='total private task directory; max16MiB additional per capture case',release='preserve synthetic test credentials and raw captures for offline regrading; never installed device keys',timing=False))
results=[];receipts=[];used=base
for peer in data['peers']:
 if peer['protocol']!='coap':continue
 for size in (64,65536):
  for mode in ('con','non'):
   if used+16*1024*1024+8*1024*1024>256*1024*1024:raise ValueError('private task output budget would be exceeded')
   case=dict(id=f"{peer['id']}-{mode}-{size}",protocol='coap',security=peer['security'],bytes=size,mode=mode,operations=3,warmup=1,concurrency=1,timeout_ms=5000)
   target=output/case['id'];result=packet_trace.capture_case(peer,case,target,campaign.digest(manifest))
   used+=sum(p.stat().st_size for p in target.rglob('*') if p.is_file())
   receipt=campaign.read(target/'capture.json')
   results.append(dict(id=case['id'],peer=peer['id'],security=peer['security'],**result))
   receipts.append(dict(case=case,peer=peer['id'],capture=receipt,grade=result))
   print(json.dumps({'capture':case['id'],'passed':result['passed'],'error':result.get('error'),'frames':receipt.get('frames')}),flush=True)
campaign.write_new(output/'results.json',results)
campaign.write_new(root/'packet-capture-receipts.json',receipts)
summary=[]
for security in ['unprotected','OSCORE-AES-CCM-16-64-128','DTLS1.2-PSK-AES128-CCM8']:
 rows=[r for r in results if r['security']==security]
 proof='Record framing only; online Go independently checks authenticated complete bodies' if security.startswith('DTLS') else 'Independent authentication, complete body and exchange/control checks' if security.startswith('OSCORE') else 'Complete body and exchange/control checks'
 summary.append(dict(security=security,cases=len(rows),passed=sum(r['passed'] for r in rows),complete_bodies=None if security.startswith('DTLS') else sum(r.get('completed_including_warmup',0) for r in rows),proof=proof))
value=dict(note='60 untimed socket-boundary cases across all15 CoAP fixtures,64/65536B andCON/NON. Kernel capture was unavailable: no installed Npcap/Wireshark; pktmon returned Access is denied. No administrator prompt or capture-driver installation was attempted.',summary=summary,results=results,frames=sum(r['capture'].get('frames',0) for r in receipts),private_output_path=str(output),private_task_bytes=used,all_passed=all(r['passed'] for r in results))
campaign.write_new(root/'capture-summary.json',value)
print(json.dumps({'capture_cases':len(results),'passed':sum(r['passed'] for r in results),'frames':value['frames'],'private_task_bytes':used}),flush=True)

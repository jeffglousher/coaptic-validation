import sys,json
from pathlib import Path
root=Path(r'C:/Users/jeffg/AppData/Local/CoapticQualification/protected-path-20261022');suite=Path(r'D:/codex-work/coaptic-validation')
sys.path.insert(0,str(suite/'tools/benchmark'))
import campaign,packet_trace
manifest=root/'matched-prepared.json';data=campaign.read(manifest)
out=root/'packet-captures-dtls-r2';out.mkdir(exist_ok=False)
rows=[];receipts=[]
for peer in data['peers']:
 if not peer['security'].startswith('DTLS'):continue
 for size in (64,65536):
  for mode in ('con','non'):
   case=dict(id=f"{peer['id']}-{mode}-{size}",protocol='coap',security=peer['security'],bytes=size,mode=mode,operations=3,warmup=1,concurrency=1,timeout_ms=5000)
   folder=out/case['id'];r=packet_trace.capture_case(peer,case,folder,campaign.digest(manifest))
   rows.append(dict(id=case['id'],peer=peer['id'],security=peer['security'],**r));receipts.append(dict(case=case,peer=peer['id'],capture=campaign.read(folder/'capture.json'),grade=r))
   print(json.dumps({'case':case['id'],'passed':r['passed'],'error':r.get('error')}),flush=True)
campaign.write_new(out/'results.json',rows)
campaign.write_new(root/'packet-capture-dtls-r2-receipts.json',receipts)
initial=campaign.read(root/'capture-summary.json')
merged=[r for r in initial['results'] if not r['security'].startswith('DTLS')]+rows
summary=[]
for security in ['unprotected','OSCORE-AES-CCM-16-64-128','DTLS1.2-PSK-AES128-CCM8']:
 group=[r for r in merged if r['security']==security]
 summary.append(dict(security=security,cases=len(group),passed=sum(r['passed'] for r in group),complete_bodies=None if security.startswith('DTLS') else sum(r.get('completed_including_warmup',0) for r in group),proof='Record framing only; online Go authenticated complete bodies' if security.startswith('DTLS') else 'Authenticated complete body and control identity' if security.startswith('OSCORE') else 'Complete body and exchange/control checks'))
initial.update(note=initial['note']+' Initial16 DTLS traces retained Windows closed-client ICMP resets as capture failures; after the client-facing relay socket fix, a fresh16-case DTLS validation runs separately. All old receipts remain.',summary=summary,results=merged,all_passed=all(r['passed'] for r in merged),initial_failed_cases=16,dtls_r2_directory=str(out),dtls_r2_grader_sha256=campaign.digest(packet_trace.__file__))
campaign.write_new(root/'capture-summary-final.json',initial)
print(json.dumps({'passed':sum(r['passed'] for r in merged),'cases':len(merged)}),flush=True)

import os,sys,json,subprocess,time,datetime,contextlib,traceback
from pathlib import Path
root=Path(r'C:/Users/jeffg/AppData/Local/CoapticQualification/protected-path-20261022');suite=Path(r'D:/codex-work/coaptic-validation')
py=sys.executable
sys.path.insert(0,str(suite/'tools/benchmark'))
import campaign
if campaign.read(root/'qualification-dtls-recheck/window-0.json').get('resumed'):raise ValueError('qualification interrupted')
env=dict(os.environ,RUSTUP_TOOLCHAIN='1.99.0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_RELEASE_DEBUG='0',GOCACHE='D:/coaptic-batch-interop-target/go-build',GOMODCACHE='D:/coaptic-batch-interop-target/go-mod')
base=[py,'tools/benchmark/prepare.py','--build-root','D:/coaptic-batch-interop-target','--python',py,'--go','D:/coaptic-tools/benchmark-go-1.26.0/go/bin/go.exe','--cmake','D:/coaptic-tools/python/cmake/data/bin/cmake.exe','--libcoap-source','D:/coaptic-tools/libcoap-4.3.5b','--libcoap-build','D:/coaptic-batch-interop-target/benchmark-libcoap','--libcoap-security','--libcoap-dtls-backend','mbedtls','--libcoap-crypto-prefix','D:/coaptic-batch-interop-target/benchmark-mbedtls-3.6.7/install','--peers','coaptic,coaptic-reusable,coap-rs,coap-lite-codec,aiocoap,libcoap,go-coap,http3']
with (root/'execution.log').open('x',encoding='utf-8') as log:
 for name,extra in [('native-prepared',[]),('matched-prepared',['--matched-oscore','--dtls'])]:
  cmd=base+['--output',str(root/(name+'.json'))]+extra
  log.write(json.dumps({'command':cmd,'utc':campaign.utc()})+'\n');log.flush()
  r=subprocess.run(cmd,cwd=suite,env=env,stdout=log,stderr=subprocess.STDOUT)
  print(json.dumps({'stage':name,'exit':r.returncode}),flush=True)
  if r.returncode:raise SystemExit(r.returncode)
 native=campaign.read(root/'native-prepared.json');matched=campaign.read(root/'matched-prepared.json')
 for m in (native,matched):
  assert not m['sources']['library']['status'] and not m['sources']['suite']['status'],m['sources']
 definitions=[('native',native,lambda p:p['protocol']=='coap'),('matched',matched,lambda p:p['security'] in ('unprotected','OSCORE-AES-CCM-16-64-128')),('dtls',matched,lambda p:p['security']=='DTLS1.2-PSK-AES128-CCM8'),('http3',native,lambda p:p['protocol']=='http3')]
 for name,source,predicate in definitions:
  m=json.loads(json.dumps(source));m['peers']=[p for p in m['peers'] if predicate(p)]
  strata={(p['protocol'],p['security']) for p in m['peers']};m['cases']=[c for c in m['cases'] if (c['protocol'],c['security']) in strata]
  campaign.write_new(root/(name+'-manifest.json'),m)
  campaign.write_new(root/name/'plan.json',campaign.create_plan(m,5,20261022))
  print(json.dumps({'plan':name,'peers':len(m['peers']),'cases':len(m['cases']),'cells_per_window':len(campaign.read(root/name/'plan.json')['schedule'][0])}),flush=True)
 for window in range(5):
  names=['native','matched','dtls','http3'];names=names[window%4:]+names[:window%4]
  for name in names:
   path=root/name
   latest=max((datetime.datetime.fromisoformat(campaign.read(p)['finished']).timestamp() for p in path.glob('window-*.json')),default=0)
   while time.time()-latest<61:
    delay=min(30,61-(time.time()-latest));print(json.dumps({'waiting_session_gap':name,'seconds':round(delay,2)}),flush=True);time.sleep(delay)
   started=time.monotonic();print(json.dumps({'running':name,'window':window,'utc':campaign.utc()}),flush=True)
   with contextlib.redirect_stdout(log):campaign.run_window(path,window)
   log.flush()
   index=campaign.read(path/f'window-{window}.json');rows=[campaign.read(path/i['path']) for i in index['cells']]
   stats={'finished':name,'window':window,'seconds':round(time.monotonic()-started,2),'cells':len(rows),'invalid':sum('sample' not in r for r in rows),'attempted':sum(r.get('sample',{}).get('attempted',0) for r in rows),'completed':sum(r.get('sample',{}).get('completed',0) for r in rows),'failed':sum(r.get('sample',{}).get('failed',0) for r in rows),'warmup_failed':sum(r.get('sample',{}).get('warmup_failed',0) for r in rows)}
   print(json.dumps(stats),flush=True)
 print(json.dumps({'complete':True,'utc':campaign.utc()}),flush=True)

import json,sys,statistics,datetime,hashlib
from pathlib import Path
root=Path(r'C:/Users/jeffg/AppData/Local/CoapticQualification/protected-path-20261022');suite=Path(r'D:/codex-work/coaptic-validation')
sys.path.insert(0,str(suite/'tools/benchmark'))
import campaign

def text(p):
 b=p.read_bytes();return b.decode('utf-16') if b[:2] in (b'\xff\xfe',b'\xfe\xff') else b.decode('utf-8-sig')
def read(p):return json.loads(text(p))
def median(v):return statistics.median(v) if v else None

def resources(rows):
 cpu=[];rss=[];private=[];threads=[];valid=0
 for r in rows:
  s=r.get('server_cpu',{});before=s.get('before');after=s.get('after')
  if not before or not after:continue
  valid+=1
  memory=after.get('memory',{})
  if memory.get('rss') is not None:rss.append(memory['rss'])
  if memory.get('private') is not None:private.append(memory['private'])
  if after.get('threads') is not None:threads.append(after['threads'])
  identities=lambda x:{(p['pid'],p['created_seconds']) for p in x['processes']}
  if identities(before)==identities(after):
   delta=after['user_seconds']+after['system_seconds']-before['user_seconds']-before['system_seconds']
   if delta>=0 and s.get('driver_process_wall_seconds',0)>0:cpu.append(100*delta/s['driver_process_wall_seconds'])
 return dict(cpu_wall_percent=median(cpu),after_rss_bytes=median(rss),after_private_bytes=median(private),after_threads=median(threads),valid_windows=valid,cpu_windows=len(cpu))
coverage=dict(cells=0,attempted=0,completed=0,failed=0,warmup_failed=0,invalid_cells=0,verified_bytes=0)
allrows={};starts=[];ends=[];bycampaign={};failures=[]
for name in ['native','matched','dtls','http3']:
 plan=read(root/name/'plan.json');rows=[];counter={k:0 for k in coverage}
 for window in range(5):
  index=read(root/name/f'window-{window}.json')
  assert not index.get('resumed'),'interrupted sessions must remain descriptive'
  assert len(index['cells'])==len(plan['schedule'][window])
  starts.append(index['started']);ends.append(index['finished'])
  for item in index['cells']:
   p=root/name/item['path'];assert campaign.digest(p)==item['sha256']
   r=read(p);rows.append(r);coverage['cells']+=1;counter['cells']+=1
   if 'sample' not in r:
    coverage['invalid_cells']+=1;counter['invalid_cells']+=1;failures.append(dict(campaign=name,window=window,case=r['case'],peer=r['peer'],error=r.get('error'),kind='invalid'));continue
   for key in ['attempted','completed','failed','warmup_failed','verified_bytes']:coverage[key]+=r['sample'][key];counter[key]+=r['sample'][key]
   if r['sample']['failed'] or r['sample']['warmup_failed']:failures.append(dict(campaign=name,window=window,case=r['case'],peer=r['peer'],sample=r['sample'],kind='counted'))
 allrows[name]=rows;bycampaign[name]=counter
coverage.update(started=min(starts),finished=max(ends),planned_operations=276000,unaccounted_planned_operations=276000-coverage['attempted'],attempted_scope='valid load-driver records only; activity in invalid cells is unknown');assert coverage['cells']==2070 and coverage['attempted']<=276000
reports={}
for kind,name,reference,security in [('native','native','coaptic','unprotected'),('matched','matched','coaptic','unprotected'),('oscore','matched','coaptic-oscore','OSCORE-AES-CCM-16-64-128'),('dtls','dtls','coaptic-dtls','DTLS1.2-PSK-AES128-CCM8'),('http3','http3','http3','TLS1.3')]:
 report=campaign.analyze(root/name,reference)
 report_path=root/(kind+'-report.json')
 if report_path.exists():assert campaign.read(report_path)==report,'existing raw analysis differs'
 else:campaign.write_new(report_path,report)
 report['summary']=[r for r in report['summary'] if r['security']==security]
 for r in report['summary']:
  rows=[x for x in allrows[name] if x['case']==r['case'] and x['peer']==r['peer']]
  values=[v for x in rows if 'sample' in x for v in x['sample']['latencies_ns']]
  r['successful_request_latency_ns'].update(p50=campaign.quantile(values,.5),p95=campaign.quantile(values,.95))
  r['resources']=resources(rows)
 reports[kind]=report
micro=[]
for mode in ['unprotected','oscore']:
 values={name:[read(root/'micro-windows'/f'{w}-{mode}-{name}.json') for w in range(5)] for name in ['baseline','candidate']}
 micro.append(dict(security=mode,before_median_p50_ns=median([campaign.quantile(v['latencies_ns'],.5) for v in values['baseline']]),after_median_p50_ns=median([campaign.quantile(v['latencies_ns'],.5) for v in values['candidate']]),windows=5,operations_per_window=30000,per_window=[dict(window=w,before=campaign.descriptive(values['baseline'][w]['latencies_ns']),after=campaign.descriptive(values['candidate'][w]['latencies_ns']),before_p50=campaign.quantile(values['baseline'][w]['latencies_ns'],.5),after_p50=campaign.quantile(values['candidate'][w]['latencies_ns'],.5),before_clock=campaign.descriptive(values['baseline'][w]['clock_calibration_ns']),after_clock=campaign.descriptive(values['candidate'][w]['clock_calibration_ns'])) for w in range(5)]))
layout=[json.loads(l) for l in text(root/'resource-layout.jsonl').splitlines() if l]
small=read(root/'small-device.json')
for c in small['cells']:
 c['summary'].update(completed_per_second=c['summary']['verified_operations_per_second'],p50_ns=c['summary']['p50_us']*1000,p95_ns=c['summary']['p95_us']*1000)
trace=read(root/'capture-summary-final.json')
source=read(root/'native/plan.json')['manifest']['sources']
hardware=read(root/'hardware.json')
data=dict(schema='coaptic-comprehensive-sitrep/1',sources=source,host=hardware,coverage=coverage,bycampaign=bycampaign,reports=reports,micro=micro,micro_binaries=read(root/'micro-binaries.json'),layout=dict(inline=layout[0],pools=layout[1:],meta=read(root/'resource-layout-meta.json')),small=small,capture=trace,failures=failures)
data['strata']={'native':'Seven servers; common independent Rust wire client. Coaptic bare and reusable UDP Apps; coap-lite is a narrower codec endpoint. Volatile/unprotected GET workload only.','matched':'Seven servers; common independent Python wire client with complete-byte validation. Bootstrap/warmup precede timing. Python/GIL limits belong to this stratum.','oscore':'Four native OSCORE endpoints: Coaptic bare/reusable, aiocoap and libcoap. Common independent aiocoap cryptography authenticates complete responses; replay32, one shared context.','dtls':'Four endpoints; common independent Go CoAP wire client over PionDTLS. Coaptic/coap-rs adapters are test-only. Per-session App ownership and runtime differ from UDP; setup handshakes precede timing.','http3':'quic-go HTTP/3 with verified fixture certificate and TLS1.3. Warm/cold connection cases; separate protocol/client, not a like-for-like CoAP encryption-cost control.'}
data['host_note']='Ryzen7 5800X3D,8 cores/16 logical;34266349568 OS-reported RAM bytes;Windows11 Pro26200 x86_64. Rust1.99.0 release thinLTO/codegen-units1/debug0;Go1.26.0;Python3.14.4;aiocoap0.4.16;cryptography50.0.2;cbor2 6.1.5;psutil7.0.0. libcoap4.3.5b@851533c3, MbedTLS3.6.7;go-coap3.5.4;coap-rs0.28.1;coap-lite0.13.3. Builds and capture never overlapped measured cells; shared-host noise is retained.'
data['allocation_note']='Separate diagnostics-enabled, OSCORE-disabled profiler:64B/1000 operations and65536B/32 complete operations. Each bind requested32 allocations (23326B/216862B respectively); measured polls requested0 allocations,0 reallocations and0 allocated bytes. These diagnostic heap totals differ from the OSCORE-enabled comparison ABI above. Supported UDP receive probes likewise allocated0 bytes; bareUDP2048 was explicitly refused as InvalidInput. Instrumentation perturbs timing; this is not protected allocation or full-system peak evidence.'
data['validation']='Local validation:1169 core all-feature library tests; strict core all-target Clippy with all features and no default features;73 benchmark Python tests;24 native workspace tests;Go tests;formatting and diff checks passed. General independent correctness/security reviews passed. Read-only source-matched layout probe used std,alloc,oscore without diagnostics. Main comparison binaries keep diagnostics disabled.'
data['qualification_note']='All timing observations are retained, including any failed/slower cells shown above. Initial functional qualification had4 libcoap protected setup failures:2 OSCORE Echo/body-oracle mismatches and2 absent DTLS identity hints. The next recheck exposed2 DTLS BadRecordMac failures from early clearing of a borrowed PSK. Authenticated Echo setup, role-specific optional-hint handling and PSK lifetime fixes passed affected-cell qualification before the source freeze. Earlier failed qualification logs/rows remain in the raw archive; they are not measured final-source success samples.'
if (root/'go-mid-collision-r2.json').exists():data['go_mid_collision']=read(root/'go-mid-collision-r2.json')
data['go_mid_note']='The separate untimed five-frame diagnostic proves go-coap3.5.4 returns stale token1 for a fresh NON request carrying token2 when the new client MID equals the prior server response MID. Both client MIDs are distinct. It verifies two1024B blocks, not complete64KiB operations. Tracked in companion#146. One separate Go1.26.0 Windows DTLS driver/runtime access violation is retained as an invalid cell; consistent with a known upstream Windows I/O regression, exact attribution unproved (companion#147). A patched-toolchain recheck is separate evidence, never substituted into these five-window statistics.'
if (root/'patched-go-qualification.json').exists():data['patched_go']=read(root/'patched-go-qualification.json')
data['post_validation_source']={'suite':'5b414b0938dd6bcb0c6dd1ebafa4c1f688b49caa','scope':'capture socket fix and Go minimum guard; no changes to main matrix samples or Go wire-driver logic'}
data['coaptic_matrix_operations']=sum(r['sample']['completed'] for rows in allrows.values() for r in rows if r['peer'].startswith('coaptic') and 'sample' in r)
(root/'comparison-data.json').write_text(json.dumps(data,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')
view=dict(data);view['reports']={}
for k,r in reports.items():view['reports'][k]={'reference':r['reference'],'summary':[{key:row[key] for key in ['case','peer','security','sessions','invalid_sessions','failed_requests','warmup_failures','median_completed_per_second','median_goodput_bytes_per_second','median_session_p50_ns','successful_request_latency_ns','completed_rate_vs_reference','comparison_eligible','successful_latency_samples','resources']} for row in r['summary']]}
view['small']=dict(cells=[{k:c[k] for k in ['peer','security','summary','profile','server_process_tree','attempted','completed','failed'] if k in c} for c in small['cells']])
encoded=json.dumps(view,separators=(',',':'),ensure_ascii=True)
html=text(root/'report-template.html').replace('__DATA__',encoded.replace('</','<\\/'))
(root/'comprehensive-report.html').write_text(html,encoding='utf-8')
print(json.dumps({'coverage':coverage,'bycampaign':bycampaign,'failures':[{k:v for k,v in r.items() if k!='sample'}|({'failed':r['sample']['failed']} if 'sample'in r else {}) for r in failures],'html_bytes':len(html)}),flush=True)
for kind in reports:
 case=('http3-warm-' if kind=='http3' else 'coap-'+('oscore-' if kind=='oscore' else 'dtls-' if kind=='dtls' else '')+'con-')+'64-1'
 print(kind,[(r['peer'],round(r['median_completed_per_second'],1),round(r['median_session_p50_ns']/1000,1),r['failed_requests']) for r in reports[kind]['summary'] if r['case']==case],flush=True)

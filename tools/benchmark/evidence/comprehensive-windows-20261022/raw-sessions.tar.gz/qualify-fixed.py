import os,subprocess,json,time
from pathlib import Path
root=Path(r'C:/Users/jeffg/AppData/Local/CoapticQualification/protected-path-20261022')
suite=Path(r'D:/codex-work/coaptic-validation')
py=r'D:/CoapticCurrent/matched-benchmark-20261013-venv/Scripts/python.exe'
env=dict(os.environ,RUSTUP_TOOLCHAIN='1.99.0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_RELEASE_DEBUG='0',GOCACHE='D:/coaptic-batch-interop-target/go-build',GOMODCACHE='D:/coaptic-batch-interop-target/go-mod')
cmd=[r'C:/Users/jeffg/.cargo/bin/agent-resources.exe','run','--id','coaptic-core-reusable','--directory',str(suite),'--',py,'tools/benchmark/prepare.py','--output',str(root/'qualification-fixed-manifest.json'),'--build-root','D:/coaptic-batch-interop-target','--python',py,'--go','D:/coaptic-tools/benchmark-go-1.26.0/go/bin/go.exe','--cmake','D:/coaptic-tools/python/cmake/data/bin/cmake.exe','--libcoap-source','D:/coaptic-tools/libcoap-4.3.5b','--libcoap-build','D:/coaptic-batch-interop-target/benchmark-libcoap','--libcoap-security','--libcoap-dtls-backend','mbedtls','--libcoap-crypto-prefix','D:/coaptic-batch-interop-target/benchmark-mbedtls-3.6.7/install','--peers','coaptic,coaptic-reusable,coap-rs,coap-lite-codec,aiocoap,libcoap,go-coap,http3','--matched-oscore','--dtls']
with (root/'prepare-fixed.log').open('w',encoding='utf-8') as log:
 result=subprocess.run(cmd,cwd=suite,env=env,stdout=log,stderr=subprocess.STDOUT)
print(json.dumps({'prepare_exit':result.returncode}),flush=True)
if result.returncode:raise SystemExit(result.returncode)
import sys
sys.path.insert(0,str(suite/'tools/benchmark'))
import campaign
m=campaign.read(root/'qualification-fixed-manifest.json')
m['peers']=[p for p in m['peers'] if p['id'] in ('libcoap-oscore','libcoap-dtls')]
m['cases']=[c for c in m['cases'] if c['security'] in {p['security'] for p in m['peers']}]
q=root/'qualification-recheck';campaign.write_new(q/'plan.json',campaign.create_plan(m,1,20261022,True))
campaign.run_window(q,0)
rows=[campaign.read(q/i['path']) for i in campaign.read(q/'window-0.json')['cells']]
bad=[{'case':r['case'],'peer':r['peer'],'error':r.get('error'),'sample':r.get('sample')} for r in rows if 'sample' not in r or r['sample']['failed'] or r['sample']['warmup_failed']]
print(json.dumps({'cells':len(rows),'bad':bad}),flush=True)
raise SystemExit(bool(bad))

//! Target-ABI layout and requested-pool budget only; no sockets or Apps are created.
use coaptic::storage::{AllocMemory, Capacities, Memory, UdpSocketIo};
use coaptic::{App, profiles};
use std::mem::size_of;
use std::net::UdpSocket;

type SmallIo = UdpSocketIo<[u8; 1153]>;
type Small = App<profiles::Constrained, SmallIo, 4, false, Memory<profiles::Constrained>, 0, 1, 4, 1>;
type Broad<T> = App<profiles::Default, T, 1, true, AllocMemory>;

fn main() {
    println!(
        "{{\"scope\":\"target ABI inline layouts and requested heap arrays; no stack, allocator rounding, kernel or runtime peak\",\"pointer_bytes\":{},\"small_fixed_app_including_adapter_bytes\":{},\"small_adapter_bytes\":{},\"small_packet_payload_bytes\":4608,\"small_external_static_body_bytes\":32,\"alloc_storage_inline_bytes\":{},\"broad_app_without_transport_inline_bytes\":{},\"broad_bare_udp_app_inline_bytes\":{},\"broad_reusable_udp_app_inline_bytes\":{},\"broad_reusable_udp_adapter_bytes\":{}}}",
        size_of::<usize>(), size_of::<Small>(), size_of::<SmallIo>(),
        size_of::<AllocMemory>(), size_of::<Broad<()>>(), size_of::<Broad<UdpSocket>>(),
        size_of::<Broad<UdpSocketIo<[u8; 2049]>>>(), size_of::<UdpSocketIo<[u8; 2049]>>(),
    );
    for body in [64_usize, 1024, 65536] {
        let rounded = body.div_ceil(1024) * 1024;
        let capacities = Capacities {
            rx_datagram_slots: 4, rx_datagram_bytes: 1472,
            tx_datagram_slots: 4, tx_datagram_bytes: 1472,
            dedup_entries: 8, observe_entries: 4,
            rx_body_slots: Some(1), rx_body_bytes: Some(rounded),
            tx_body_slots: Some(2), tx_body_bytes: Some(rounded),
        };
        let heap = AllocMemory::<coaptic::message::Token>::required_heap_bytes(capacities)
            .expect("bounded fixture capacities");
        println!(
            "{{\"body_bytes\":{body},\"rounded_body_slot_bytes\":{rounded},\"requested_pool_heap_bytes\":{heap},\"pool_payload_bytes\":{},\"external_original_body_bytes\":{body}}}",
            8 * 1472 + 3 * rounded,
        );
    }
}

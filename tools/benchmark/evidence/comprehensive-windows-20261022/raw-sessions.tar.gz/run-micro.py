import subprocess,json,time,datetime,statistics,hashlib
from pathlib import Path
root=Path(r'C:/Users/jeffg/AppData/Local/CoapticQualification/protected-path-20261022')
out=root/'micro-windows';out.mkdir(exist_ok=False)
for window in range(5):
    order=['baseline','candidate'] if window%2==0 else ['candidate','baseline']
    for security in ['unprotected','oscore']:
        for name in order:
            started=datetime.datetime.now(datetime.timezone.utc).isoformat()
            run=subprocess.run([str(root/f'{name}-bench-core.exe'),'30000',security],capture_output=True,text=True,encoding='utf-8',timeout=60)
            (out/f'{window}-{security}-{name}.stderr.txt').write_text(run.stderr,encoding='utf-8')
            if run.returncode: raise RuntimeError((name,security,run.returncode,run.stderr))
            value=json.loads(run.stdout)
            value['window']=window;value['binary_label']=name;value['started_utc']=started
            (out/f'{window}-{security}-{name}.json').write_text(json.dumps(value,separators=(',',':')),encoding='utf-8')
            print(json.dumps({'window':window,'name':name,'security':security,'keys':list(value.keys())}),flush=True)
    if window<4: time.sleep(2)

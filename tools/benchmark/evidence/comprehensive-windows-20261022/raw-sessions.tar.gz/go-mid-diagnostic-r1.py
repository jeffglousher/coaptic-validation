"""Untimed two-block-request diagnostic; run only after the timing matrix ends.

This does not complete a 64 KiB representation and is not a benchmark sample.
Two distinct client-originated NON GET MIDs exercise independent MID namespaces.
ACKs merely echo server-originated CON MIDs, as required by CoAP.
"""
import hashlib
import json
from pathlib import Path
import socket
import sys
import time

SUITE = Path(r'D:/codex-work/coaptic-validation')
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(SUITE / 'tools/benchmark'))
sys.path.insert(0, str(SUITE / 'tools/benchmark/protected'))
import aiocoap
import campaign
import packet_trace
from load import check_body

SERVER = Path(r'D:/coaptic-batch-interop-target/bench-go.exe')
SERVER_SHA256 = 'cff79f697874506d8ccceb17369e0c82f199673de08ca65eb4cc61cad233f073'
SOURCE_PINS = {
    'tools/benchmark/packet_trace.py': '64b62ea6c573050c0f591c6f5b42aa46050a5d8964ff6932568432fc5f0a3b47',
    'tools/benchmark/campaign.py': 'ed4742054de2516b6012f094ec3d03fe1047bd18f91e5480e3fe9405ea27cf65',
    'tools/benchmark/protected/load.py': '04fb8641e5eed8751c18893f1aa0b5794ed59a4586cfbf729f29a5c290d27ca7',
    'tools/benchmark/peers/go/main.go': '6d158ed3c2c6195b6b0ac711489aaa01aa0402010599c063095d19a2a1e795c0',
    'tools/benchmark/peers/go/dtls.go': 'cde8736a46da5e0bcd17849f5eed9dbe51041a1fe135307192d6f8d5429bd882',
    'tools/benchmark/peers/go/go.mod': '3d93a2cb01e88118931eef969d052f2e07eb5dfa6f3164f6149907038d09038a',
    'tools/benchmark/peers/go/go.sum': 'dfb2b031b6c7a932909a7076004b45638d4ca5874c7027e906028a681e922ce7',
}
UPSTREAM = Path(r'D:/coaptic-batch-interop-target/go-mod/github.com/plgd-dev/go-coap/v3@v3.5.4/udp/client/conn.go')
UPSTREAM_SHA256 = '3a3b2fb7591f0e44e4b34128db521d502ea39e53bea8b429f65b06bdd31764e5'
TOKEN1, TOKEN2 = b'mid00001', b'mid00002'
TRACE = ROOT / 'go-mid-diagnostic-trace'
RECEIPT = ROOT / 'go-mid-collision.json'


def require(value, reason):
    if not value:
        raise ValueError(reason)


def verify_pins():
    require(campaign.digest(SERVER) == SERVER_SHA256, 'server binary changed')
    require(campaign.digest(UPSTREAM) == UPSTREAM_SHA256, 'pinned upstream source changed')
    for name, digest in SOURCE_PINS.items():
        require(campaign.digest(SUITE / name) == digest, f'source changed: {name}')


def request(mid, token):
    message = aiocoap.Message(code=aiocoap.GET, uri_path=('bench',), block2=(0, False, 6))
    message.mid, message.mtype, message.token = mid, aiocoap.NON, token
    return message.encode()


def block_description(wire):
    message = aiocoap.Message.decode(wire)
    require(message.encode() == wire, 'noncanonical/truncated CoAP response')
    require(message.mtype in (aiocoap.CON, aiocoap.NON), 'unexpected NON-request response type')
    require(message.opt.oscore is None, 'unexpected protection')
    end, block, etag = check_body(message, 0, 65536, None, (0, False, 6))
    require(end == 1024 and block == (1, False, 6), 'not the requested 1024-byte first block')
    require(etag == (b'fixture',), 'fixture ETag changed')
    return message, dict(code=int(message.code), code_text=str(message.code),
                         type=int(message.mtype), mid=message.mid, token_hex=message.token.hex(),
                         block2=dict(num=message.opt.block2.block_number, more=message.opt.block2.more,
                                     szx=message.opt.block2.size_exponent),
                         content_format=int(message.opt.content_format), etag_hex=[v.hex() for v in etag],
                         body_bytes=len(message.payload), body_sha256=hashlib.sha256(message.payload).hexdigest(),
                         all_body_bytes_verified=True, wire_sha256=hashlib.sha256(wire).hexdigest())


def receive(sock, deadline):
    remaining = deadline - time.monotonic()
    require(remaining > 0, 'two-request network deadline exceeded')
    sock.settimeout(remaining)
    wire = sock.recv(65535)
    message, description = block_description(wire)
    if message.mtype == aiocoap.CON:
        ack = bytes((0x60, 0, message.mid >> 8, message.mid & 255))
        require(sock.send(ack) == len(ack), 'short response ACK')
    return message, description


def wait_bound(captured, port, deadline):
    # No extra readiness datagrams: exactly two GETs reach the Go fixture.
    while time.monotonic() < deadline:
        require(captured.process.poll() is None and not captured.overflow.is_set(), 'server failed during startup')
        require(captured.owned_root is not None, 'missing owned server identity')
        if any(c.laddr == ('127.0.0.1', port) for c in captured.owned_root.net_connections(kind='udp4')):
            return
        time.sleep(.01)
    raise TimeoutError('server did not bind within the shared two-second network deadline')


def check_trace(receipt):
    frames = list(packet_trace.records(TRACE, receipt))
    requests, responses, controls = [], [], []
    endpoints = set()
    for row, wire in frames:
        message = aiocoap.Message.decode(wire)
        endpoints.add(tuple(row['client']))
        if message.code == aiocoap.EMPTY:
            require(row['direction'] == 'request' and wire == bytes((0x60, 0, message.mid >> 8, message.mid & 255)),
                    'invalid diagnostic control')
            controls.append(message.mid)
        elif row['direction'] == 'request':
            require(message.mtype == aiocoap.NON and message.code == aiocoap.GET and
                    message.opt.uri_path == ('bench',) and not message.opt.uri_query and not message.payload and
                    message.opt.block2 == (0, False, 6), 'wrong diagnostic request')
            requests.append(message)
        else:
            responses.append(block_description(wire))
    require(len(endpoints) == 1 and len(requests) == len(responses) == 2, 'not exactly two exchanges on one endpoint')
    require([r.token for r in requests] == [TOKEN1, TOKEN2], 'request tokens not distinct')
    require(requests[0].mid == 0 and requests[1].mid != 0 and requests[1].mid == responses[0][0].mid,
            'not a fresh client MID alias of the first server response MID')
    require(responses[0][0].token == TOKEN1 and responses[1][0].token in (TOKEN1, TOKEN2), 'unexpected response token')
    expected_acks = [message.mid for message, _ in responses if message.mtype == aiocoap.CON]
    require(controls == expected_acks, 'missing/unmatched CON response ACK')
    return dict(client_request_mids=[r.mid for r in requests], client_request_mids_unique=True,
                client_request_tokens=[r.token.hex() for r in requests], response_ack_mids=controls,
                stale_first_token_returned_for_second_request=responses[1][0].token == TOKEN1,
                responses=[description for _, description in responses], offline_trace_verified=True)


def main():
    require(not TRACE.exists() and not RECEIPT.exists(), 'diagnostic outputs already exist; refuse overwrite')
    verify_pins()
    plan_path = ROOT / 'native/plan.json'
    plan = campaign.read(plan_path)
    identity = plan['identities']['go-coap']['server']
    require(identity[0]['sha256'] == SERVER_SHA256, 'campaign server identity differs')
    TRACE.mkdir()
    packet_trace.MAX_FRAMES, packet_trace.MAX_BYTES = 8, 65536
    receipt = dict(schema='coaptic-go-mid-diagnostic/1', created=campaign.utc(),
                   scope='two NON GET requests for Block2 NUM0/SZX6 from a 65536-byte static representation; two 1024-byte blocks, not complete operations',
                   timing_valid=False, benchmark_sample=False, complete_representation_operations=0,
                   network_deadline_seconds=2, capture_budget_bytes=65536, capture_budget_frames=8,
                   capture_boundary='received UDP payloads through userspace Relay; DLT_USER0, no IP/kernel capture',
                   script_sha256=campaign.digest(__file__), plan_sha256=campaign.digest(plan_path),
                   sources=plan['manifest']['sources'], source_file_sha256=SOURCE_PINS,
                   server_sha256=SERVER_SHA256, upstream_library='plgd/go-coap v3.5.4',
                   upstream_conn_sha256=UPSTREAM_SHA256, collision_proven=False, capture_complete=False)
    captured, relay = None, None
    errors = []
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as reserve:
            reserve.bind(('127.0.0.1', 0))
            port = reserve.getsockname()[1]
        deadline = time.monotonic() + 2
        captured = campaign.CapturedProcess([str(SERVER), 'server', 'coap', '127.0.0.1', str(port), '65536', '-'])
        wait_bound(captured, port, deadline)
        with packet_trace.Relay(TRACE, ('127.0.0.1', port)) as relay:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                sock.bind(('127.0.0.1', 0))
                sock.connect(relay.address)
                first_wire = request(0, TOKEN1)
                require(sock.send(first_wire) == len(first_wire), 'short first request')
                first, _ = receive(sock, deadline)
                require(first.token == TOKEN1, 'wrong first response token')
                require(first.mid != 0, 'first server MID is zero; no fresh alias available, diagnostic inconclusive')
                second_wire = request(first.mid, TOKEN2)
                require(sock.send(second_wire) == len(second_wire), 'short second request')
                receive(sock, deadline)
        require(relay.error is None, f'relay failed: {relay.error}')
        receipt['capture_complete'] = True
    except Exception as error:
        errors.append(repr(error))
    finally:
        if captured is not None:
            try:
                captured.close()
                receipt['owned_server_cleanup_complete'] = True
            except Exception as error:
                receipt['owned_server_cleanup_complete'] = False
                errors.append('cleanup: ' + repr(error))
            receipt['server_stdout_tail'] = bytes(captured.output[-2048:]).decode(errors='replace')
            receipt['server_stderr_tail'] = bytes(captured.errors[-2048:]).decode(errors='replace')
            receipt['server_output_overflow'] = captured.overflow.is_set()
            if captured.overflow.is_set():
                errors.append('server output overflow')
        if relay is not None:
            receipt['frames'] = relay.writer.count
            receipt['hashes'] = {name: campaign.digest(TRACE / name) for name in ('datagrams.pcap', 'frames.jsonl')}
        try:
            verify_pins()
        except Exception as error:
            errors.append('final source/binary pins: ' + repr(error))
    if receipt['capture_complete'] and not errors:
        try:
            receipt.update(check_trace(receipt))
            receipt['collision_proven'] = receipt['stale_first_token_returned_for_second_request']
        except Exception as error:
            errors.append('offline trace: ' + repr(error))
    receipt['errors'] = errors
    receipt['finished'] = campaign.utc()
    receipt['outcome'] = ('stale_cached_response_proven' if receipt['collision_proven'] else
                          'diagnostic_failed_or_inconclusive' if errors else 'fresh_response_no_collision')
    campaign.write_new(RECEIPT, receipt)
    print(json.dumps({key: receipt[key] for key in ('outcome', 'collision_proven', 'errors')}))
    return 0 if receipt['collision_proven'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

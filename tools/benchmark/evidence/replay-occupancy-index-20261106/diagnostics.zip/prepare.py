from pathlib import Path
import json, subprocess, hashlib, shutil
r = Path(__file__).resolve().parent
prior = Path('D:/CoapticCurrent/deadline-cache-20261106')
repo = Path('C:/Users/jeffg/.t3/worktrees/coaptic/t3-a578955c')
sha = '42c823463b1d7eac5cca31df58e1dac7b243d610'
old = '55388e3caf1345afd50706661030eadf00e0c15f'
v = json.loads((prior/'source-verification.json').read_text())
v['source'] = sha
fixture = Path(v['fixture_root'])/'coaptic'
for name in v['source_file_hashes']:
    data = subprocess.check_output(['git','-C',str(repo),'show',sha+':'+name]).replace(b'\r\n',b'\n')
    p = fixture/name
    if p.read_bytes() != data: p.write_bytes(data)
    v['source_file_hashes'][name] = hashlib.sha256(data).hexdigest()
patch = subprocess.check_output(['git','-C',str(repo),'diff','--binary',v['baseline'],sha,'--','src','crates','tests','Cargo.toml','Cargo.lock'])
(r/'candidate.patch').write_bytes(patch)
v['patch_sha256'] = hashlib.sha256(patch).hexdigest()
(r/'source-verification.json').write_text(json.dumps(v,indent=2)+'\n')
for name in ['build-preflight.py','build.py','layout.py','inspect.py','measure.py','qualify.py']:
    text = (prior/name).read_text().replace(old,sha).replace('::DedupDeadline','::DedupIndex')
    (r/name).write_text(text)
for name in ['audit.py','Cargo.toml','Cargo.lock','lib.rs','baseline-build.log','baseline-constants.txt','baseline-layout.txt','baseline-source.json']:
    data = (prior/'layout32'/name).read_bytes()
    if name == 'audit.py': data = data.replace(b'::DedupDeadline',b'::DedupIndex')
    (r/'layout32'/name).write_bytes(data)
shutil.copyfile(prior/'fixture-sha256.json',r/'fixture-sha256.json')
for source, dest in [('occupancy-index-tests.log','test-invocation-failure.log'),('occupancy-index-tests-corrected.log','tests.log')]:
    shutil.copyfile(prior/source,r/dest)
m = json.loads((prior/'METHOD-BEFORE.json').read_text())
m['candidate'] = sha
hyp = 'Replace boolean occupancy plus separately allocated8B deadline cache with one4B-per-slot occupancy/message-ID index. Values0/1 distinguish free/acquired-empty; mid+2 covers every16-bit ID. Exact endpoint/key remains authoritative. This restores cheap MID rejection while removing the extra allocation and redundant cache owner; expiry reads full-width row deadlines. Compact replay and direct full-chunk initialization remain. Source operation/layout hypothesis, not causal attribution from prior separate cohorts.'
m['source_hypothesis'] = m['hypothesis'] = hyp
m['tradeoffs'] = 'Original startup allocation count restored, no automatic growth. Occupancy consumes4B/slot instead of1B, replacing the separate8B deadline cache. Full-width expiry scans again read payload rows. Preserve behavior and configured capacities; target and host whole owners must nongrow.'
m['preflight_repair'] = 'Deadline-only55388e3 fails6CPU bounds. New occupancy/MID integration is distinct source and ownership model; do not resample failed source.'
(r/'METHOD-BEFORE.json').write_text(json.dumps(m,indent=2)+'\n')
print({'source':sha,'verified_files':len(v['source_file_hashes'])},flush=True)

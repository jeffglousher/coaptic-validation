"""Render the retained final integration; never build or resample."""
from pathlib import Path
import json, subprocess, sys
out = Path('D:/codex-work/coaptic-validation/tools/benchmark/evidence/replay-occupancy-index-20261106')
prior = out.parent/'deadline-cache-20261106'
v = (prior/'render.py').read_text(encoding='utf-8')
v = v.replace('Coaptic deadline cache comparison', 'Coaptic replay occupancy comparison')
v = v.replace('55388e3', '42c8234')
v = v.replace("('deadline-cache-20261106','Replay deadline cache / chunk initialization')", "('deadline-cache-20261106','Replay deadline cache / chunk initialization'),('replay-occupancy-index-20261106','Combined occupancy / message-ID filter')")
v = v.replace('Compact replay owners save 16 bytes per row; the full-width deadline cache consumes 8 of those bytes. Net reduction: 8 bytes per configured replay row. Allocated storage exchanges an unused pin-vector header for the deadline-vector header, keeping App size unchanged.', 'Compact replay owners save 16 bytes per row. Occupancy and message-ID filtering share a four-byte state, adding three bytes per slot over the original boolean occupancy. This removes the separate deadline cache. Net row reduction: 13 bytes, before whole-object padding. The unused allocated pin-vector header is also removed.')
v = v.replace('One additional startup allocation per nonempty allocated replay table.', 'The original startup allocation count is preserved; there is no separate deadline-cache allocation.')
v = v.replace('32-bit layout audit: unchanged owners', '32-bit layout audit: smaller owners')
v = v.replace('The 8-byte deadline cache exactly offsets the smaller replay owner on this target. App and replay-table sizes are preserved; no 32-bit memory reduction is claimed.', 'The replay owner shrinks eight bytes on this target while combined occupancy adds three bytes per slot. Whole-object alignment is included in these actual compiler sizes. The allocated App header also shrinks.')
v = v.replace('Exact candidate passes 926 library tests', 'Exact candidate passes 927 library tests')
start = v.index('<p>The previous integration failed one CPU bound')
end = v.index('<p>Sync and actual async progress', start)
v = v[:start] + '<p>The preceding deadline-only integration failed six CPU bounds despite smaller host memory. This integration combines slot state and the full 16-bit message ID in one existing occupancy owner. Values 0 and 1 distinguish free and acquired-empty slots; populated slots use mid + 2. Every filter match still requires the exact endpoint/key. Full-width deadlines remain in payload rows. The original allocation count is restored.</p><p>Every 16-bit ID and an independent rotation/reserved-slot model are tested. This changed-source cohort uses no old or replacement samples. Earlier failed sources and their decisions remain retained.</p>' + v[end:]
(out/'render.py').write_text(v,encoding='utf-8')
subprocess.run([sys.executable,'-B',str(out/'render.py')],check=True)
r=json.loads((out/'measurement.json').read_text())
state='passes the frozen CPU preservation rule' if r['runtime_accepted'] else 'fails the frozen CPU preservation rule and is rejected'
text=f'''# Combined replay occupancy and message-ID filter

Exact candidate `42c823463b1d7eac5cca31df58e1dac7b243d610` versus pinned baseline
`bd63199b652193b4c0a882e5840e72d992cf1362` {state}.
All64 paired runs across28 workloads are retained; {len(r['failed_point_guards'])}
cell upper bounds exceed1.02. `comparison.html` contains the comparable tables
and CPU chart. No failed source was resampled or reclassified.

The integration retains compact inline/TX replay ownership, scalar active-owner
writes and direct initialization of full retained chunks. One u32 per replay
slot now combines occupancy and a message-ID rejection filter. Values0/1 mean
free/acquired-empty; mid+2 represents all16-bit IDs. A filter match still requires
the exact endpoint/key. Full-u64 deadlines stay in rows, with unchanged expiry,
duplicate-key behavior and TX release ordering. No capacity is reduced.

The compact replay type explicitly defines equality/hashing by key, deadline and
current replay owner. Discarded inactive replay bytes no longer affect identity;
this observable pre-release value-semantic change is documented in rustdoc.
Protocol replay selection and authenticated retained bytes remain covered by
the regression checks; this is not a claim of identical inactive-byte identity.

Host SmallDevice App saves56 bytes; fixed Service App saves832. Allocated Service
saves24 inline bytes plus832 requested pool bytes. Selected complete futures and
encoder frames are unchanged. Actual Thumbv7EM unit-transport Apps save24 bytes
SmallDevice,320 fixed Service,16 allocated Service. Static layout is not device
execution. Startup allocation counts match baseline, including failure recovery.
Requested heap excludes allocator metadata and rounding; this is not peak RAM.

Run `python -B verify.py` here to independently recompute all paired results and
check retained hashes, capacities, exit records and owner ledgers without running
native probes. Use `python prepare.py CORE_REPO NEW_OUTPUT candidate` for source
reconstruction. The unchanged fixture is in sibling
`dispatch-scratch-20261104/fixture`. `observations.zip` retains exact binaries,
PDBs, methods, raw outputs and exits; `diagnostics.zip` contains tests, review and
selected disassembly; `layout32.zip` retains the audit fixture, actual layouts,
source hashes and LLVM constants. The pinned32-bit baseline is reused unchanged.

Before timing:927 library,11 allocation/failure-injection,27 retained-Q and13
footprint checks passed. General read-only review found no actionable issue.
An initial command used the wrong test-target spelling and did not compile;
that invocation failure and the corrected passing run are both retained.

The benchmark measures complete server-App thread CPU cycles with immediate
memory transport, actual synchronous or asynchronous progress and a pending
timer. Client preparation/authentication and verification are outside the server
interval. No network latency, throughput, hardware or new libcoap ranking claim.
Earlier failures are retained in the sibling evidence folders, especially
`deadline-cache-20261106`, `replay-chunk-staging-20261106` and
`replay-scan-index-20261106`. Separate cohorts do not establish causal CPU
attribution. No trimming, early stopping or replacement samples are permitted.
'''
(out/'README.md').write_text(text,encoding='utf-8')


D:\CoapticCurrent\replay-occupancy-index-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068850:     	pushq	%rbp
140068851:     	pushq	%r15
140068853:     	pushq	%r14
140068855:     	pushq	%r13
140068857:     	pushq	%r12
140068859:     	pushq	%rsi
14006885a:     	pushq	%rdi
14006885b:     	pushq	%rbx
14006885c:     	subq	$0x4f8, %rsp            # imm = 0x4F8
140068863:     	leaq	0x80(%rsp), %rbp
14006886b:     	movq	0x4f0(%rbp), %r12
140068872:     	movq	0x8(%r12), %rdi
140068877:     	movl	$0x3, %r10d
14006887d:     	cmpq	$0x3, %rdi
140068881:     	ja	0x140068963 <.text+0x67963>
140068887:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
14006888f:     	jne	0x140068963 <.text+0x67963>
140068895:     	movq	0x26700(%rdx,%rdi,8), %rax
14006889d:     	cmpq	$0x4001, %rax           # imm = 0x4001
1400688a3:     	jae	0x140068b35 <.text+0x67b35>
1400688a9:     	movq	0x10(%r12), %r11
1400688ae:     	movq	0x18(%r12), %r15
1400688b3:     	movq	%r15, %rsi
1400688b6:     	movl	$0xb, %r10d
1400688bc:     	addq	%r11, %rsi
1400688bf:     	jb	0x140068963 <.text+0x67963>
1400688c5:     	cmpq	$0x400, %r15            # imm = 0x400
1400688cc:     	ja	0x140068963 <.text+0x67963>
1400688d2:     	cmpq	%rax, %rsi
1400688d5:     	ja	0x140068963 <.text+0x67963>
1400688db:     	movq	%r8, %r13
1400688de:     	movq	%r9, 0x460(%rbp)
1400688e5:     	movq	%rcx, 0x470(%rbp)
1400688ec:     	movzbl	0x4f8(%rbp), %r14d
1400688f4:     	movq	%rdi, %rax
1400688f7:     	shlq	$0xe, %rax
1400688fb:     	movq	%rdx, %rsi
1400688fe:     	leaq	(%rdx,%rax), %rbx
140068902:     	addq	$0x16700, %rbx          # imm = 0x16700
140068909:     	addq	%r11, %rbx
14006890c:     	movl	$0x400, %r8d            # imm = 0x400
140068912:     	cmpq	$0x400, %r15            # imm = 0x400
140068919:     	je	0x140068929 <.text+0x67929>
14006891b:     	leaq	-0x10(%rbp), %rcx
14006891f:     	xorl	%edx, %edx
140068921:     	callq	0x140250d72 <.text+0x24fd72>
140068926:     	movq	%r15, %r8
140068929:     	leaq	-0x10(%rbp), %rcx
14006892d:     	movq	%rbx, %rdx
140068930:     	callq	0x140250d60 <.text+0x24fd60>
140068935:     	testb	%r14b, %r14b
140068938:     	je	0x14006897e <.text+0x6797e>
14006893a:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
140068941:     	movq	%rsi, %rcx
140068944:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
14006894d:     	jne	0x140068aea <.text+0x67aea>
140068953:     	xorl	%edi, %edi
140068955:     	callq	0x14009af10 <.text+0x99f10>
14006895a:     	testb	$0x1, %al
14006895c:     	jne	0x140068990 <.text+0x67990>
14006895e:     	jmp	0x140068b13 <.text+0x67b13>
140068963:     	movb	$0xa, (%rcx)
140068966:     	movq	%r10, 0x8(%rcx)
14006896a:     	addq	$0x4f8, %rsp            # imm = 0x4F8
140068971:     	popq	%rbx
140068972:     	popq	%rdi
140068973:     	popq	%rsi
140068974:     	popq	%r12
140068976:     	popq	%r13
140068978:     	popq	%r14
14006897a:     	popq	%r15
14006897c:     	popq	%rbp
14006897d:     	retq
14006897e:     	xorl	%edi, %edi
140068980:     	movq	%rsi, %rcx
140068983:     	callq	0x14009af10 <.text+0x99f10>
140068988:     	testb	$0x1, %al
14006898a:     	je	0x140068b13 <.text+0x67b13>
140068990:     	movq	%rdx, %rbx
140068993:     	movq	0x500(%rbp), %rdx
14006899a:     	movzwl	0x4e8(%rbp), %ecx
1400689a1:     	movzbl	0x4e0(%rbp), %eax
1400689a8:     	movq	(%r12), %r8
1400689ac:     	movq	%rdi, 0x430(%rbp)
1400689b3:     	movq	0x468(%rbp), %r9
1400689ba:     	movq	%r9, 0x438(%rbp)
1400689c1:     	movq	%r8, 0x440(%rbp)
1400689c8:     	movb	%r14b, 0x448(%rbp)
1400689cf:     	movups	0x60(%r13), %xmm0
1400689d4:     	movups	0x6c(%r13), %xmm1
1400689d9:     	movups	%xmm1, 0x3fc(%rbp)
1400689e0:     	movaps	%xmm0, 0x3f0(%rbp)
1400689e7:     	leaq	0x8e(%r13), %r8
1400689ee:     	movq	0x7e(%r13), %r9
1400689f2:     	movq	0x85(%r13), %r10
1400689f9:     	movq	%r10, 0x457(%rbp)
140068a00:     	movq	%r9, 0x450(%rbp)
140068a07:     	leaq	0x450(%rbp), %r9
140068a0e:     	movq	%r9, 0x68(%rsp)
140068a13:     	movq	%rdx, 0x60(%rsp)
140068a18:     	movq	%r13, 0x58(%rsp)
140068a1d:     	leaq	0x430(%rbp), %rdx
140068a24:     	movq	%rdx, 0x50(%rsp)
140068a29:     	movq	%r15, 0x48(%rsp)
140068a2e:     	leaq	-0x10(%rbp), %rdx
140068a32:     	movq	%rdx, 0x40(%rsp)
140068a37:     	movq	0x460(%rbp), %rdx
140068a3e:     	movq	%rdx, 0x38(%rsp)
140068a43:     	movq	%r8, 0x30(%rsp)
140068a48:     	movw	%cx, 0x28(%rsp)
140068a4d:     	movb	%al, 0x20(%rsp)
140068a51:     	leaq	0x410(%rbp), %rcx
140068a58:     	leaq	0x3f0(%rbp), %r8
140068a5f:     	movq	%rsi, %rdx
140068a62:     	movq	%rbx, %r9
140068a65:     	callq	0x140082cd0 <.text+0x81cd0>
140068a6a:     	cmpb	$-0x1, 0x410(%rbp)
140068a71:     	je	0x140068b22 <.text+0x67b22>
140068a77:     	cmpb	$0x1, 0x37400(%rsi,%rbx)
140068a7f:     	movq	0x470(%rbp), %rax
140068a86:     	jne	0x140068ad0 <.text+0x67ad0>
140068a88:     	cmpb	$0x0, 0x37420(%rsi,%rbx)
140068a90:     	jne	0x140068ad0 <.text+0x67ad0>
140068a92:     	movb	$0x0, 0x37400(%rsi,%rbx)
140068a9a:     	decq	0x37448(%rsi)
140068aa1:     	leaq	0x37400(%rsi), %rcx
140068aa8:     	movq	$0x0, 0x432d0(%rsi,%rbx,8)
140068ab4:     	leaq	(%rbx,%rbx,8), %rdx
140068ab8:     	leaq	(%rdx,%rdx,2), %rdx
140068abc:     	addq	%rbx, %rdx
140068abf:     	movb	$0x2, 0x36a(%rcx,%rdx)
140068ac7:     	leaq	(%rbx,%rbx,2), %rdx
140068acb:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140068ad0:     	movups	0x410(%rbp), %xmm0
140068ad7:     	movups	0x420(%rbp), %xmm1
140068ade:     	movups	%xmm1, 0x10(%rax)
140068ae2:     	movups	%xmm0, (%rax)
140068ae5:     	jmp	0x14006896a <.text+0x6796a>
140068aea:     	addq	%rcx, %rax
140068aed:     	addq	$0x15c28, %rax          # imm = 0x15C28
140068af3:     	movq	0x98(%rax), %rax
140068afa:     	movq	%rax, 0x468(%rbp)
140068b01:     	movl	$0x1, %edi
140068b06:     	callq	0x14009af10 <.text+0x99f10>
140068b0b:     	testb	$0x1, %al
140068b0d:     	jne	0x140068990 <.text+0x67990>
140068b13:     	movq	0x470(%rbp), %rax
140068b1a:     	movb	$0x9, (%rax)
140068b1d:     	jmp	0x14006896a <.text+0x6796a>
140068b22:     	movq	0x470(%rbp), %rax
140068b29:     	movq	%rbx, 0x8(%rax)
140068b2d:     	movb	$-0x1, (%rax)
140068b30:     	jmp	0x14006896a <.text+0x6796a>
140068b35:     	leaq	0x20311c(%rip), %r9     # 0x14026bc58
140068b3c:     	movl	$0x4000, %r8d           # imm = 0x4000
140068b42:     	xorl	%ecx, %ecx
140068b44:     	movq	%rax, %rdx
140068b47:     	callq	0x1402517f0 <.text+0x2507f0>
140068b4c:     	ud2

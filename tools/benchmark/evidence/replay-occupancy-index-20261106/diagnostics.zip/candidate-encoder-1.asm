
D:\CoapticCurrent\replay-occupancy-index-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068540:     	pushq	%rbp
140068541:     	pushq	%r15
140068543:     	pushq	%r14
140068545:     	pushq	%r13
140068547:     	pushq	%r12
140068549:     	pushq	%rsi
14006854a:     	pushq	%rdi
14006854b:     	pushq	%rbx
14006854c:     	subq	$0x508, %rsp            # imm = 0x508
140068553:     	leaq	0x80(%rsp), %rbp
14006855b:     	movq	0x500(%rbp), %r12
140068562:     	movq	0x8(%r12), %rdi
140068567:     	movl	$0x3, %r10d
14006856d:     	cmpq	$0x3, %rdi
140068571:     	ja	0x140068651 <.text+0x67651>
140068577:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
14006857f:     	jne	0x140068651 <.text+0x67651>
140068585:     	movq	0x26700(%rdx,%rdi,8), %rax
14006858d:     	cmpq	$0x4001, %rax           # imm = 0x4001
140068593:     	jae	0x14006882e <.text+0x6782e>
140068599:     	movq	0x10(%r12), %r11
14006859e:     	movq	0x18(%r12), %r15
1400685a3:     	movq	%r15, %rsi
1400685a6:     	movl	$0xb, %r10d
1400685ac:     	addq	%r11, %rsi
1400685af:     	jb	0x140068651 <.text+0x67651>
1400685b5:     	cmpq	$0x400, %r15            # imm = 0x400
1400685bc:     	ja	0x140068651 <.text+0x67651>
1400685c2:     	cmpq	%rax, %rsi
1400685c5:     	ja	0x140068651 <.text+0x67651>
1400685cb:     	movq	%r8, %r13
1400685ce:     	movq	%r9, 0x470(%rbp)
1400685d5:     	movq	%rcx, 0x480(%rbp)
1400685dc:     	movzbl	0x508(%rbp), %r14d
1400685e4:     	movq	%rdi, %rax
1400685e7:     	shlq	$0xe, %rax
1400685eb:     	movq	%rdx, %rsi
1400685ee:     	leaq	(%rdx,%rax), %rbx
1400685f2:     	addq	$0x16700, %rbx          # imm = 0x16700
1400685f9:     	addq	%r11, %rbx
1400685fc:     	movl	$0x400, %r8d            # imm = 0x400
140068602:     	cmpq	$0x400, %r15            # imm = 0x400
140068609:     	je	0x140068618 <.text+0x67618>
14006860b:     	movq	%rbp, %rcx
14006860e:     	xorl	%edx, %edx
140068610:     	callq	0x140250d72 <.text+0x24fd72>
140068615:     	movq	%r15, %r8
140068618:     	movq	%rbp, %rcx
14006861b:     	movq	%rbx, %rdx
14006861e:     	callq	0x140250d60 <.text+0x24fd60>
140068623:     	testb	%r14b, %r14b
140068626:     	je	0x14006866c <.text+0x6766c>
140068628:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
14006862f:     	movq	%rsi, %rcx
140068632:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
14006863b:     	jne	0x1400687e3 <.text+0x677e3>
140068641:     	xorl	%edi, %edi
140068643:     	callq	0x14009af10 <.text+0x99f10>
140068648:     	testb	$0x1, %al
14006864a:     	jne	0x14006867e <.text+0x6767e>
14006864c:     	jmp	0x14006880c <.text+0x6780c>
140068651:     	movb	$0xa, (%rcx)
140068654:     	movq	%r10, 0x8(%rcx)
140068658:     	addq	$0x508, %rsp            # imm = 0x508
14006865f:     	popq	%rbx
140068660:     	popq	%rdi
140068661:     	popq	%rsi
140068662:     	popq	%r12
140068664:     	popq	%r13
140068666:     	popq	%r14
140068668:     	popq	%r15
14006866a:     	popq	%rbp
14006866b:     	retq
14006866c:     	xorl	%edi, %edi
14006866e:     	movq	%rsi, %rcx
140068671:     	callq	0x14009af10 <.text+0x99f10>
140068676:     	testb	$0x1, %al
140068678:     	je	0x14006880c <.text+0x6780c>
14006867e:     	movq	%rdx, %rbx
140068681:     	movq	0x518(%rbp), %rdx
140068688:     	movq	0x510(%rbp), %r8
14006868f:     	movzwl	0x4f8(%rbp), %ecx
140068696:     	movzbl	0x4f0(%rbp), %eax
14006869d:     	movq	(%r12), %r9
1400686a1:     	movq	%rdi, 0x440(%rbp)
1400686a8:     	movq	0x478(%rbp), %r10
1400686af:     	movq	%r10, 0x448(%rbp)
1400686b6:     	movq	%r9, 0x450(%rbp)
1400686bd:     	movb	%r14b, 0x458(%rbp)
1400686c4:     	movups	0x60(%r13), %xmm0
1400686c9:     	movups	0x6c(%r13), %xmm1
1400686ce:     	movups	%xmm1, 0x40c(%rbp)
1400686d5:     	movaps	%xmm0, 0x400(%rbp)
1400686dc:     	leaq	0x8e(%r13), %r9
1400686e3:     	movq	0x7e(%r13), %r10
1400686e7:     	movq	0x85(%r13), %r11
1400686ee:     	movq	%r11, 0x467(%rbp)
1400686f5:     	movq	%r10, 0x460(%rbp)
1400686fc:     	leaq	0x460(%rbp), %r10
140068703:     	movq	%r10, 0x70(%rsp)
140068708:     	movq	%rdx, 0x68(%rsp)
14006870d:     	movq	%r8, 0x60(%rsp)
140068712:     	movq	%r13, 0x58(%rsp)
140068717:     	leaq	0x440(%rbp), %rdx
14006871e:     	movq	%rdx, 0x50(%rsp)
140068723:     	movq	%r15, 0x48(%rsp)
140068728:     	movq	%rbp, %rdx
14006872b:     	movq	%rdx, 0x40(%rsp)
140068730:     	movq	0x470(%rbp), %rdx
140068737:     	movq	%rdx, 0x38(%rsp)
14006873c:     	movq	%r9, 0x30(%rsp)
140068741:     	movw	%cx, 0x28(%rsp)
140068746:     	movb	%al, 0x20(%rsp)
14006874a:     	leaq	0x420(%rbp), %rcx
140068751:     	leaq	0x400(%rbp), %r8
140068758:     	movq	%rsi, %rdx
14006875b:     	movq	%rbx, %r9
14006875e:     	callq	0x1400814e0 <.text+0x804e0>
140068763:     	cmpb	$-0x1, 0x420(%rbp)
14006876a:     	je	0x14006881b <.text+0x6781b>
140068770:     	cmpb	$0x1, 0x37400(%rsi,%rbx)
140068778:     	movq	0x480(%rbp), %rax
14006877f:     	jne	0x1400687c9 <.text+0x677c9>
140068781:     	cmpb	$0x0, 0x37420(%rsi,%rbx)
140068789:     	jne	0x1400687c9 <.text+0x677c9>
14006878b:     	movb	$0x0, 0x37400(%rsi,%rbx)
140068793:     	decq	0x37448(%rsi)
14006879a:     	leaq	0x37400(%rsi), %rcx
1400687a1:     	movq	$0x0, 0x432d0(%rsi,%rbx,8)
1400687ad:     	leaq	(%rbx,%rbx,8), %rdx
1400687b1:     	leaq	(%rdx,%rdx,2), %rdx
1400687b5:     	addq	%rbx, %rdx
1400687b8:     	movb	$0x2, 0x36a(%rcx,%rdx)
1400687c0:     	leaq	(%rbx,%rbx,2), %rdx
1400687c4:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
1400687c9:     	movups	0x420(%rbp), %xmm0
1400687d0:     	movups	0x430(%rbp), %xmm1
1400687d7:     	movups	%xmm1, 0x10(%rax)
1400687db:     	movups	%xmm0, (%rax)
1400687de:     	jmp	0x140068658 <.text+0x67658>
1400687e3:     	addq	%rcx, %rax
1400687e6:     	addq	$0x15c28, %rax          # imm = 0x15C28
1400687ec:     	movq	0x98(%rax), %rax
1400687f3:     	movq	%rax, 0x478(%rbp)
1400687fa:     	movl	$0x1, %edi
1400687ff:     	callq	0x14009af10 <.text+0x99f10>
140068804:     	testb	$0x1, %al
140068806:     	jne	0x14006867e <.text+0x6767e>
14006880c:     	movq	0x480(%rbp), %rax
140068813:     	movb	$0x9, (%rax)
140068816:     	jmp	0x140068658 <.text+0x67658>
14006881b:     	movq	0x480(%rbp), %rax
140068822:     	movq	%rbx, 0x8(%rax)
140068826:     	movb	$-0x1, (%rax)
140068829:     	jmp	0x140068658 <.text+0x67658>
14006882e:     	leaq	0x203423(%rip), %r9     # 0x14026bc58
140068835:     	movl	$0x4000, %r8d           # imm = 0x4000
14006883b:     	xorl	%ecx, %ecx
14006883d:     	movq	%rax, %rdx
140068840:     	callq	0x1402517f0 <.text+0x2507f0>
140068845:     	ud2


D:\CoapticCurrent\replay-row-presence-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009f8b0:     	pushq	%rbp
14009f8b1:     	pushq	%r15
14009f8b3:     	pushq	%r14
14009f8b5:     	pushq	%r13
14009f8b7:     	pushq	%r12
14009f8b9:     	pushq	%rsi
14009f8ba:     	pushq	%rdi
14009f8bb:     	pushq	%rbx
14009f8bc:     	subq	$0x218, %rsp            # imm = 0x218
14009f8c3:     	leaq	0x80(%rsp), %rbp
14009f8cb:     	movaps	%xmm6, 0x180(%rbp)
14009f8d2:     	movq	0xe8(%rcx), %r8
14009f8d9:     	testq	%r8, %r8
14009f8dc:     	je	0x14009fbc9 <.text+0x9ebc9>
14009f8e2:     	leaq	0xc0(%rcx), %r13
14009f8e9:     	leaq	0xd8(%rcx), %rdi
14009f8f0:     	movq	0xc8(%rcx), %rbx
14009f8f7:     	movq	0xd0(%rcx), %r10
14009f8fe:     	leaq	0x28(%rbx), %rax
14009f902:     	xorl	%r11d, %r11d
14009f905:     	xorl	%r15d, %r15d
14009f908:     	imulq	$0x130, %r15, %r12      # imm = 0x130
14009f90f:     	addq	%rax, %r12
14009f912:     	jmp	0x14009f92f <.text+0x9e92f>
14009f914:     	nopw	%cs:(%rax,%rax)
14009f920:     	incq	%r15
14009f923:     	addq	$0x130, %r12            # imm = 0x130
14009f92a:     	cmpq	%r8, %r15
14009f92d:     	jae	0x14009f99a <.text+0x9e99a>
14009f92f:     	cmpq	%r10, %r15
14009f932:     	jae	0x14009f920 <.text+0x9e920>
14009f934:     	cmpb	$0x2, -0xe(%r12)
14009f93a:     	je	0x14009f920 <.text+0x9e920>
14009f93c:     	movq	%r13, %rdi
14009f93f:     	movq	-0x8(%r12), %r13
14009f944:     	cmpb	$0x3, (%r12)
14009f949:     	setne	%r12b
14009f94d:     	testq	%r13, %r13
14009f950:     	sete	%sil
14009f954:     	orb	%r12b, %sil
14009f957:     	cmpq	%r14, %r13
14009f95a:     	setae	%r12b
14009f95e:     	andb	%r11b, %r12b
14009f961:     	testb	%sil, %sil
14009f964:     	movq	%r14, %rdx
14009f967:     	movq	%rax, %r14
14009f96a:     	movl	$0x1, %eax
14009f96f:     	cmoveq	%rax, %r11
14009f973:     	movq	%r14, %rax
14009f976:     	movq	%rdx, %r14
14009f979:     	orb	%sil, %r12b
14009f97c:     	cmoveq	%r15, %r9
14009f980:     	cmoveq	%r13, %r14
14009f984:     	movq	%rdi, %r13
14009f987:     	leaq	0xd8(%rcx), %rdi
14009f98e:     	incq	%r15
14009f991:     	cmpq	%r8, %r15
14009f994:     	jb	0x14009f908 <.text+0x9e908>
14009f99a:     	xorl	%eax, %eax
14009f99c:     	cmpq	$0x1, %r11
14009f9a0:     	jne	0x14009fbcb <.text+0x9ebcb>
14009f9a6:     	cmpq	%r10, %r9
14009f9a9:     	jae	0x14009fbcb <.text+0x9ebcb>
14009f9af:     	imulq	$0x130, %r9, %rax       # imm = 0x130
14009f9b6:     	movzbl	0x1a(%rbx,%rax), %r15d
14009f9bc:     	cmpb	$0x2, %r15b
14009f9c0:     	je	0x14009fbc9 <.text+0x9ebc9>
14009f9c6:     	addq	%rax, %rbx
14009f9c9:     	cmpb	$0x3, 0x28(%rbx)
14009f9cd:     	jne	0x14009fbc9 <.text+0x9ebc9>
14009f9d3:     	movq	0x30(%rbx), %r10
14009f9d7:     	movups	(%rbx), %xmm0
14009f9da:     	movups	0xa(%rbx), %xmm1
14009f9de:     	movups	%xmm1, 0x11a(%rbp)
14009f9e5:     	movaps	%xmm0, 0x110(%rbp)
14009f9ec:     	movzbl	0x1b(%rbx), %r12d
14009f9f1:     	movss	0x1c(%rbx), %xmm6
14009f9f6:     	movzwl	0x1c(%rbx), %eax
14009f9fa:     	cmpq	0x88(%rcx), %r10
14009fa01:     	jae	0x14009fa57 <.text+0x9ea57>
14009fa03:     	movq	0x80(%rcx), %r11
14009fa0a:     	cmpb	$0x1, (%r11,%r10)
14009fa0f:     	jne	0x14009fa57 <.text+0x9ea57>
14009fa11:     	cmpq	0xa0(%rcx), %r10
14009fa18:     	jae	0x14009fa28 <.text+0x9ea28>
14009fa1a:     	movq	0x98(%rcx), %rsi
14009fa21:     	cmpb	$0x0, (%rsi,%r10)
14009fa26:     	jne	0x14009fa57 <.text+0x9ea57>
14009fa28:     	movb	$0x0, (%r11,%r10)
14009fa2d:     	decq	0xb0(%rcx)
14009fa34:     	cmpq	0x70(%rcx), %r10
14009fa38:     	jae	0x14009fa57 <.text+0x9ea57>
14009fa3a:     	movq	0x68(%rcx), %r11
14009fa3e:     	imulq	$0x58, %r10, %r10
14009fa42:     	movq	$0x0, 0x30(%r11,%r10)
14009fa4b:     	movb	$0x2, 0x52(%r11,%r10)
14009fa51:     	movb	$0x2, 0x25(%r11,%r10)
14009fa57:     	cmpq	%r8, %r9
14009fa5a:     	jae	0x14009fa7d <.text+0x9ea7d>
14009fa5c:     	movq	0xe0(%rcx), %r8
14009fa63:     	cmpl	$0x0, (%r8,%r9,4)
14009fa68:     	je	0x14009fa7d <.text+0x9ea7d>
14009fa6a:     	movl	$0x0, (%r8,%r9,4)
14009fa72:     	decq	0xf8(%rcx)
14009fa79:     	movb	$0x2, 0x1a(%rbx)
14009fa7d:     	xorps	%xmm0, %xmm0
14009fa80:     	movaps	%xmm0, 0x170(%rbp)
14009fa87:     	movb	$0x0, 0x152(%rbp)
14009fa8e:     	movw	%ax, 0x150(%rbp)
14009fa95:     	leaq	0x153(%rbp), %rcx
14009fa9c:     	movw	$0x200, 0x15b(%rbp)     # imm = 0x200
14009faa5:     	movq	$0x0, 0x153(%rbp)
14009fab0:     	movq	$0x8, 0x130(%rbp)
14009fabb:     	movq	$0x0, 0x138(%rbp)
14009fac6:     	movq	$0x1, 0x140(%rbp)
14009fad1:     	movq	$0x0, 0x148(%rbp)
14009fadc:     	movq	%rcx, 0x30(%rsp)
14009fae1:     	movw	%ax, 0x28(%rsp)
14009fae6:     	movq	$0x0, 0x58(%rsp)
14009faef:     	movq	$0x1, 0x50(%rsp)
14009faf8:     	movq	$0x8, 0x48(%rsp)
14009fb01:     	movq	$0x8, 0x40(%rsp)
14009fb0a:     	movq	$0x0, 0x38(%rsp)
14009fb13:     	movb	$0x0, 0x20(%rsp)
14009fb18:     	leaq	0x160(%rbp), %rcx
14009fb1f:     	leaq	0x170(%rbp), %rdx
14009fb26:     	movl	$0x10, %r8d
14009fb2c:     	movb	$0x2, %r9b
14009fb2f:     	callq	0x140005590 <.text+0x4590>
14009fb34:     	movq	0x168(%rbp), %rbx
14009fb3b:     	cmpq	$0x11, %rbx
14009fb3f:     	setae	%al
14009fb42:     	orb	0x160(%rbp), %al
14009fb48:     	jne	0x14009fbf6 <.text+0x9ebf6>
14009fb4e:     	movq	%rdi, %rcx
14009fb51:     	callq	0x140219540 <.text+0x218540>
14009fb56:     	cmpq	$0x1, %rax
14009fb5a:     	jne	0x14009fbf6 <.text+0x9ebf6>
14009fb60:     	movups	0x11a(%rbp), %xmm0
14009fb67:     	movups	%xmm0, -0x16(%rbp)
14009fb6b:     	movaps	0x110(%rbp), %xmm0
14009fb72:     	movaps	%xmm0, -0x20(%rbp)
14009fb76:     	movb	%r15b, -0x6(%rbp)
14009fb7a:     	movb	%r12b, -0x5(%rbp)
14009fb7e:     	movss	%xmm6, -0x4(%rbp)
14009fb83:     	movq	%r14, (%rbp)
14009fb87:     	testq	%rbx, %rbx
14009fb8a:     	je	0x14009fbe6 <.text+0x9ebe6>
14009fb8c:     	movb	$0x1, 0x8(%rbp)
14009fb90:     	movb	%bl, 0x9(%rbp)
14009fb93:     	leaq	0xa(%rbp), %rdi
14009fb97:     	movl	$0x80, %r8d
14009fb9d:     	subq	%rbx, %r8
14009fba0:     	leaq	(%rbx,%rbp), %rcx
14009fba4:     	addq	$0xa, %rcx
14009fba8:     	movq	%rdx, %r14
14009fbab:     	xorl	%edx, %edx
14009fbad:     	callq	0x1402515b2 <.text+0x2505b2>
14009fbb2:     	leaq	0x170(%rbp), %rdx
14009fbb9:     	movq	%rdi, %rcx
14009fbbc:     	movq	%rbx, %r8
14009fbbf:     	callq	0x1402515a0 <.text+0x2505a0>
14009fbc4:     	movq	%r14, %rdx
14009fbc7:     	jmp	0x14009fbea <.text+0x9ebea>
14009fbc9:     	xorl	%eax, %eax
14009fbcb:     	movaps	0x180(%rbp), %xmm6
14009fbd2:     	addq	$0x218, %rsp            # imm = 0x218
14009fbd9:     	popq	%rbx
14009fbda:     	popq	%rdi
14009fbdb:     	popq	%rsi
14009fbdc:     	popq	%r12
14009fbde:     	popq	%r13
14009fbe0:     	popq	%r14
14009fbe2:     	popq	%r15
14009fbe4:     	popq	%rbp
14009fbe5:     	retq
14009fbe6:     	movb	$0x0, 0x8(%rbp)
14009fbea:     	leaq	-0x20(%rbp), %r8
14009fbee:     	movq	%r13, %rcx
14009fbf1:     	callq	0x14000b620 <.text+0xa620>
14009fbf6:     	movb	$0x1, %al
14009fbf8:     	jmp	0x14009fbcb <.text+0x9ebcb>

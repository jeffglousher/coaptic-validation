"""Render the retained borrowed-encoding cohort without executing probes."""
from pathlib import Path
import json, subprocess, sys
out=Path('D:/codex-work/coaptic-validation/tools/benchmark/evidence/replay-row-presence-20261106')
prior=out.parent/'owned-replay-reclaim-20261106'
v=(prior/'render.py').read_text(encoding='utf-8')
v=v.replace('Coaptic owned replay reclaim comparison','Coaptic replay row presence comparison')
v=v.replace('32c32d1','8fc41ea')
v=v.replace("('owned-replay-reclaim-20261106','Owned reclaim / occupancy fast path')", "('owned-replay-reclaim-20261106','Owned reclaim / occupancy fast path'),('borrowed-reclaim-encoding-20261106','Borrowed reclaim encoding'),('short-inline-replay-20261106','Short replay128'),('replay-row-presence-20261106','Replay row presence')")
v=v.replace('Candidate production code passes 929 library tests','Exact candidate passes 931 library tests')
start=v.index('<p class="bad">Additional emitted reclaim frame check:')
end=v.index('<h2>32-bit layout audit:',start)
v=v[:start]+'''<h2>Selected reclaim frames</h2><table><thead><tr><th>Compiler frame / bytes</th><th>Baseline</th><th>Candidate</th><th>Change</th></tr></thead><tbody><tr><td>SmallDevice</td><td>800</td><td>544</td><td>-256</td></tr><tr><td>Constrained with bodies</td><td>800</td><td>544</td><td>-256</td></tr><tr><td>Service fixed</td><td>784</td><td>544</td><td>-240</td></tr><tr><td>Service allocated</td><td>800</td><td>544</td><td>-256</td></tr></tbody></table><p>Encoding now fills a borrowed 16-byte buffer and returns only its length. Storage constructs the replay row. This removes the preceding candidate's extra 304-byte row-return copy. These selected compiler reservations do not establish peak stack.</p>'''+v[end:]
start=v.index('<p>The preceding occupancy integration failed five CPU bounds.')
end=v.index('<p>Sync and actual async progress',start)
v=v[:start]+'''<p>The preceding owned-reclaim integration failed three fixed-Service 16 KiB CPU bounds and grew its fixed reclaim frame by 32 bytes. Its full-row return boundary introduced an extra emitted 304-byte copy. This candidate replaces that boundary with borrowed encoding and checked length, while retaining the search reduction and immediate-free-cursor acquisition.</p><p>931 library, 11 allocation, 27 retained-transfer and 13 footprint tests pass. General review found no issue. A dedicated regression checks callback invocation count and release-before-encoding; models cover refusal, excessive lengths, zero-length replay, duplicates, failed TX release and slot rotation. One fresh cohort, no replacement samples.</p>'''+v[end:]
(out/'render.py').write_text(v,encoding='utf-8')
subprocess.run([sys.executable,'-B',str(out/'render.py')],check=True)
r=json.loads((out/'measurement.json').read_text())
state='passes the frozen runtime preservation rule; broader qualification and merge remain separate' if r['runtime_accepted'] else 'fails the frozen runtime preservation rule and is rejected'
readme=(prior/'README.md').read_text(encoding='utf-8')
start=readme.index('Exact candidate');end=readme.index('The bounded diagnostic',start)
readme=readme[:start]+f'''Exact candidate `8fc41ead4790e25051ae90c395b012b4c8518f72` versus pinned baseline
`bd63199b652193b4c0a882e5840e72d992cf1362` {state}.
All64 pairs across28 workloads are retained; {len(r['failed_point_guards'])} cell
upper bounds exceed1.02. `comparison.html` contains CPU charts and comparable
tables. Earlier failures remain rejected; no unchanged candidate was resampled.

The previous candidate returned a complete replay row across the callback,
introducing an extra304-byte copy. The new callback fills borrowed16-byte scratch
and returns only an optional length. Storage validates the length and constructs
the same-key/deadline replay row. Callbacks returningNone or an excessive length
skip insertion after release/removal. An empty encoding retains the ordinary
empty replay behavior. Public fixed-table duplicate and rotating cursor behavior
are unchanged; allocated unique-key storage still avoids both repeated searches.

'''+readme[end:]
readme=readme.replace('# Owned replay reclaim integration','# Replay row presence integration')
start=readme.index('Host SmallDevice App');end=readme.index('Run `python -B verify.py`',start)
readme=readme[:start]+'''Host SmallDevice App saves56 bytes; fixed Service App saves832. Allocated
Service saves24 inline bytes plus832 requested pool bytes. Selected complete
futures and encoder frames are unchanged. Selected reclaim frames become544
bytes in all four monomorphizations: baseline800 SmallDevice/Constrained with
bodies/allocated Service and784 fixed Service. The extra304-byte row-return
copy is absent. These reservations are not peak stack.

Actual Thumbv7EM unit-transport App reductions are24/320/16 bytes for SmallDevice,
fixed Service and allocated Service. Startup allocation counts match baseline.
These are exact owners, not peak RAM; heap excludes allocator metadata/rounding.
Static target layout does not establish device execution. Capacities/security
remain matched.

Before timing:931 library,11 allocation/failure-injection,27 retained-Q and13
footprint checks pass. General static review of32c32d1 to8fc41ea found no
actionable issue. Dedicated callback order/count checks close the previous
coverage gap; models exercise None, zero and excessive encoding lengths.

'''+readme[end:]
(out/'README.md').write_text(readme,encoding='utf-8')

extra="""
This integration also retains the short128-byte replay writer, key/deadline
metadata prefix and full256-byte capacity. The preceding6760b72 cohort failed
two SmallDevice CPU bounds despite lower aggregate CPU. Its two untimed compiler
lowering failures are preserved in sibling short-inline-replay-20261106.
The bounded SmallDevice diagnostic is retained in sibling
small-replay-diagnostic-20261106:1152 requests cause1152 constructions/stores/expiry
passes and2300 lookups, with55/66-byte unprotected/protected replies. Clock
interval overhead dominates tiny phase timings; no causal CPU-share claim.

The new change removes repeated occupancy reads from fixed and allocated
entry_ref. Initialization/acquisition/release clear rows, and every write follows
acquisition or a checked set_entry. Thus Option presence already establishes
occupancy; acquired-empty, invalid and released ids still return None. Existing
shared borrowed/default-copy tests exercise these states; stateful models cover
duplicate keys, reclaim, expiry and failed TX release. General review of0c30dad
to8fc41ea found no actionable defect; earlier full integrated review is retained.
No buffer threshold or capacity change. Compact equality/hash describes current
active replay, excluding discarded inactive bytes. Native binaries, focused tests
and layout evidence all use exact8fc41ea.
"""
with (out/'README.md').open('a',encoding='utf-8') as f:f.write(extra)
p=out/'README.md';s=p.read_text(encoding='utf-8').replace('General static review of32c32d1 to8fc41ea','General static review of0c30dad to8fc41ea');p.write_text(s,encoding='utf-8')
p=out/'render.py';s=p.read_text(encoding='utf-8').replace('<h2>Selected reclaim frames</h2>','<h2>Row access and short replay</h2><p>Fixed and allocated row borrowing now uses Option presence directly: acquire/release clear rows, so a present payload already proves occupancy. Invalid and reserved empty rows still return None. The integrated short writer copies128 payload bytes plus metadata with an8-byte helper; write_into is now inlined and all eight emitted caller frames match or shrink; full256-byte capacity remains. The preceding6760b72 failed two SmallDevice CPU bounds and remains rejected.</p><h2>Selected reclaim frames</h2>');p.write_text(s,encoding='utf-8');subprocess.run([sys.executable,'-B',str(p)],check=True)


D:\CoapticCurrent\replay-row-presence-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009f280:     	pushq	%rbp
14009f281:     	pushq	%r15
14009f283:     	pushq	%r14
14009f285:     	pushq	%r13
14009f287:     	pushq	%r12
14009f289:     	pushq	%rsi
14009f28a:     	pushq	%rdi
14009f28b:     	pushq	%rbx
14009f28c:     	subq	$0x218, %rsp            # imm = 0x218
14009f293:     	leaq	0x80(%rsp), %rbp
14009f29b:     	movaps	%xmm6, 0x180(%rbp)
14009f2a2:     	leaq	0x3f7f0(%rcx), %rsi
14009f2a9:     	leaq	0x3f818(%rcx), %r8
14009f2b0:     	movl	$0x40, %r11d
14009f2b6:     	xorl	%eax, %eax
14009f2b8:     	movl	$0x1, %r9d
14009f2be:     	xorl	%r10d, %r10d
14009f2c1:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009f2c8:     	addq	%r8, %rdi
14009f2cb:     	nopl	(%rax,%rax)
14009f2d0:     	cmpb	$0x2, -0xe(%rdi)
14009f2d4:     	jne	0x14009f2f0 <.text+0x9e2f0>
14009f2d6:     	incq	%r10
14009f2d9:     	addq	$0x130, %rdi            # imm = 0x130
14009f2e0:     	cmpq	%r10, %r11
14009f2e3:     	jne	0x14009f2d0 <.text+0x9e2d0>
14009f2e5:     	jmp	0x14009f335 <.text+0x9e335>
14009f2e7:     	nopw	(%rax,%rax)
14009f2f0:     	movq	-0x8(%rdi), %r11
14009f2f4:     	cmpb	$0x3, (%rdi)
14009f2f7:     	setne	%bl
14009f2fa:     	testq	%r11, %r11
14009f2fd:     	sete	%dil
14009f301:     	orb	%bl, %dil
14009f304:     	cmpq	%r14, %r11
14009f307:     	setae	%bl
14009f30a:     	andb	%al, %bl
14009f30c:     	testb	%dil, %dil
14009f30f:     	cmoveq	%r9, %rax
14009f313:     	orb	%dil, %bl
14009f316:     	cmoveq	%r10, %rdx
14009f31a:     	cmoveq	%r11, %r14
14009f31e:     	incq	%r10
14009f321:     	cmpq	$0x41, %r10
14009f325:     	movl	$0x40, %r11d
14009f32b:     	cmovaeq	%r10, %r11
14009f32f:     	cmpq	$0x3f, %r10
14009f333:     	jbe	0x14009f2c1 <.text+0x9e2c1>
14009f335:     	testb	$0x1, %al
14009f337:     	je	0x14009f4af <.text+0x9e4af>
14009f33d:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009f344:     	movzbl	0x1a(%rsi,%rax), %r15d
14009f34a:     	cmpb	$0x2, %r15b
14009f34e:     	je	0x14009f4af <.text+0x9e4af>
14009f354:     	addq	%rsi, %rax
14009f357:     	cmpb	$0x3, 0x28(%rax)
14009f35b:     	jne	0x14009f4af <.text+0x9e4af>
14009f361:     	movq	0x30(%rax), %r8
14009f365:     	movq	(%rax), %rdx
14009f368:     	movq	%rdx, 0x168(%rbp)
14009f36f:     	movq	0x8(%rax), %rdx
14009f373:     	movq	%rdx, 0x170(%rbp)
14009f37a:     	movl	0x10(%rax), %edi
14009f37d:     	movl	0x14(%rax), %edx
14009f380:     	movl	%edx, 0x178(%rbp)
14009f386:     	movzwl	0x18(%rax), %edx
14009f38a:     	movw	%dx, 0x17c(%rbp)
14009f391:     	movzbl	0x1b(%rax), %edx
14009f395:     	movb	%dl, 0x17f(%rbp)
14009f39b:     	movss	0x1c(%rax), %xmm6
14009f3a0:     	movzwl	0x1c(%rax), %eax
14009f3a4:     	movzwl	%ax, %edx
14009f3a7:     	cmpq	$0x1f, %r8
14009f3ab:     	ja	0x14009f400 <.text+0x9e400>
14009f3ad:     	leaq	0x326f0(%rcx), %r9
14009f3b4:     	cmpb	$0x1, (%r9,%r8)
14009f3b9:     	jne	0x14009f400 <.text+0x9e400>
14009f3bb:     	cmpb	$0x0, 0x32710(%rcx,%r8)
14009f3c4:     	jne	0x14009f400 <.text+0x9e400>
14009f3c6:     	movb	$0x0, 0x326f0(%rcx,%r8)
14009f3cf:     	decq	0x32738(%rcx)
14009f3d6:     	movq	$0x0, 0x3e5c0(%rcx,%r8,8)
14009f3e2:     	leaq	(%r8,%r8,8), %r10
14009f3e6:     	leaq	(%r10,%r10,2), %r10
14009f3ea:     	addq	%r8, %r10
14009f3ed:     	movb	$0x2, 0x36a(%r9,%r10)
14009f3f6:     	leaq	(%r8,%r8,2), %r8
14009f3fa:     	movb	$0x2, 0x5d(%r9,%r8,8)
14009f400:     	leaq	0x443f0(%rcx), %r12
14009f407:     	addl	$0x2, %edx
14009f40a:     	leaq	0x3f80c(%rcx), %r9
14009f411:     	xorl	%r10d, %r10d
14009f414:     	xorl	%r8d, %r8d
14009f417:     	jmp	0x14009f437 <.text+0x9e437>
14009f419:     	nopl	(%rax)
14009f420:     	movq	%r13, %r11
14009f423:     	incq	%r10
14009f426:     	addq	$0x130, %r9             # imm = 0x130
14009f42d:     	cmpq	$0x40, %r10
14009f431:     	je	0x14009f4cc <.text+0x9e4cc>
14009f437:     	movq	%r11, %r13
14009f43a:     	cmpl	%edx, (%r12,%r10,4)
14009f43e:     	jne	0x14009f420 <.text+0x9e420>
14009f440:     	movzbl	-0x2(%r9), %r11d
14009f445:     	cmpb	$0x2, %r11b
14009f449:     	je	0x14009f420 <.text+0x9e420>
14009f44b:     	cmpb	%r15b, %r11b
14009f44e:     	jne	0x14009f420 <.text+0x9e420>
14009f450:     	cmpw	%ax, (%r9)
14009f454:     	jne	0x14009f420 <.text+0x9e420>
14009f456:     	cmpl	%edi, -0xc(%r9)
14009f45a:     	jne	0x14009f420 <.text+0x9e420>
14009f45c:     	movl	0x178(%rbp), %r11d
14009f463:     	cmpl	%r11d, -0x8(%r9)
14009f467:     	jne	0x14009f420 <.text+0x9e420>
14009f469:     	movzwl	0x17c(%rbp), %r11d
14009f471:     	cmpw	%r11w, -0x4(%r9)
14009f476:     	jne	0x14009f420 <.text+0x9e420>
14009f478:     	movq	-0x1c(%r9), %r11
14009f47c:     	xorq	0x168(%rbp), %r11
14009f483:     	movq	-0x14(%r9), %rbx
14009f487:     	xorq	0x170(%rbp), %rbx
14009f48e:     	orq	%r11, %rbx
14009f491:     	jne	0x14009f420 <.text+0x9e420>
14009f493:     	movq	%r10, %r11
14009f496:     	cmpq	$0x1, %r8
14009f49a:     	movl	$0x1, %r8d
14009f4a0:     	jne	0x14009f423 <.text+0x9e423>
14009f4a2:     	movb	$0x1, %bl
14009f4a4:     	movq	%r13, %r11
14009f4a7:     	cmpq	$0x3f, %r13
14009f4ab:     	jbe	0x14009f4da <.text+0x9e4da>
14009f4ad:     	jmp	0x14009f500 <.text+0x9e500>
14009f4af:     	xorl	%eax, %eax
14009f4b1:     	movaps	0x180(%rbp), %xmm6
14009f4b8:     	addq	$0x218, %rsp            # imm = 0x218
14009f4bf:     	popq	%rbx
14009f4c0:     	popq	%rdi
14009f4c1:     	popq	%rsi
14009f4c2:     	popq	%r12
14009f4c4:     	popq	%r13
14009f4c6:     	popq	%r14
14009f4c8:     	popq	%r15
14009f4ca:     	popq	%rbp
14009f4cb:     	retq
14009f4cc:     	cmpq	$0x40, %r11
14009f4d0:     	setb	%dl
14009f4d3:     	xorl	%ebx, %ebx
14009f4d5:     	testb	%dl, %r8b
14009f4d8:     	je	0x14009f500 <.text+0x9e500>
14009f4da:     	cmpl	$0x0, (%r12,%r11,4)
14009f4df:     	je	0x14009f500 <.text+0x9e500>
14009f4e1:     	movl	$0x0, 0x443f0(%rcx,%r11,4)
14009f4ed:     	decq	0x444f8(%rcx)
14009f4f4:     	imulq	$0x130, %r11, %rdx      # imm = 0x130
14009f4fb:     	movb	$0x2, 0x1a(%rsi,%rdx)
14009f500:     	pxor	%xmm0, %xmm0
14009f504:     	movdqa	%xmm0, 0x150(%rbp)
14009f50c:     	movb	$0x0, 0x132(%rbp)
14009f513:     	movw	%ax, 0x130(%rbp)
14009f51a:     	leaq	0x133(%rbp), %rdx
14009f521:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009f52a:     	movq	$0x0, 0x133(%rbp)
14009f535:     	movq	$0x8, 0x110(%rbp)
14009f540:     	movq	$0x0, 0x118(%rbp)
14009f54b:     	movq	$0x1, 0x120(%rbp)
14009f556:     	movq	$0x0, 0x128(%rbp)
14009f561:     	movq	%rdx, 0x30(%rsp)
14009f566:     	movw	%ax, 0x28(%rsp)
14009f56b:     	movq	$0x0, 0x58(%rsp)
14009f574:     	movq	$0x1, 0x50(%rsp)
14009f57d:     	movq	$0x8, 0x48(%rsp)
14009f586:     	movq	$0x8, 0x40(%rsp)
14009f58f:     	movq	$0x0, 0x38(%rsp)
14009f598:     	movb	$0x0, 0x20(%rsp)
14009f59d:     	leaq	0x140(%rbp), %rax
14009f5a4:     	leaq	0x150(%rbp), %rdx
14009f5ab:     	movl	$0x10, %r8d
14009f5b1:     	movq	%rcx, %r13
14009f5b4:     	movq	%rax, %rcx
14009f5b7:     	movb	$0x2, %r9b
14009f5ba:     	callq	0x140005590 <.text+0x4590>
14009f5bf:     	movq	%r13, %rax
14009f5c2:     	movq	0x148(%rbp), %r13
14009f5c9:     	cmpq	$0x11, %r13
14009f5cd:     	setae	%cl
14009f5d0:     	orb	%bl, %cl
14009f5d2:     	orb	0x140(%rbp), %cl
14009f5d8:     	testb	$0x1, %cl
14009f5db:     	jne	0x14009f5e7 <.text+0x9e5e7>
14009f5dd:     	cmpq	$0x40, 0x444f8(%rax)
14009f5e5:     	jne	0x14009f5ee <.text+0x9e5ee>
14009f5e7:     	movb	$0x1, %al
14009f5e9:     	jmp	0x14009f4b1 <.text+0x9e4b1>
14009f5ee:     	movq	0x444f0(%rax), %rbx
14009f5f5:     	cmpq	$0x3f, %rbx
14009f5f9:     	ja	0x14009f899 <.text+0x9e899>
14009f5ff:     	cmpl	$0x0, (%r12,%rbx,4)
14009f604:     	je	0x14009f670 <.text+0x9e670>
14009f606:     	leaq	(,%rbx,4), %rdx
14009f60e:     	leaq	(%r12,%rbx,4), %rcx
14009f612:     	xorl	%r8d, %r8d
14009f615:     	movq	%rdx, %r9
14009f618:     	nopl	(%rax,%rax)
14009f620:     	cmpl	$0x0, (%r12,%r9)
14009f625:     	je	0x14009f663 <.text+0x9e663>
14009f627:     	addq	$0x4, %r9
14009f62b:     	decq	%r8
14009f62e:     	cmpq	$0x100, %r9             # imm = 0x100
14009f635:     	jne	0x14009f620 <.text+0x9e620>
14009f637:     	testq	%rbx, %rbx
14009f63a:     	je	0x14009f5e7 <.text+0x9e5e7>
14009f63c:     	addq	$-0x4, %rdx
14009f640:     	cmpq	$0xc, %rdx
14009f644:     	jae	0x14009f7dd <.text+0x9e7dd>
14009f64a:     	xorl	%ebx, %ebx
14009f64c:     	movq	%r12, %r9
14009f64f:     	cmpl	$0x0, (%r9)
14009f653:     	je	0x14009f666 <.text+0x9e666>
14009f655:     	addq	$0x4, %r9
14009f659:     	incq	%rbx
14009f65c:     	cmpq	%rcx, %r9
14009f65f:     	jne	0x14009f64f <.text+0x9e64f>
14009f661:     	jmp	0x14009f5e7 <.text+0x9e5e7>
14009f663:     	subq	%r8, %rbx
14009f666:     	cmpq	$0x40, %rbx
14009f66a:     	jae	0x14009f883 <.text+0x9e883>
14009f670:     	movl	$0x1, 0x443f0(%rax,%rbx,4)
14009f67b:     	incq	0x444f8(%rax)
14009f682:     	leaq	0x1(%rbx), %rcx
14009f686:     	xorl	%edx, %edx
14009f688:     	cmpq	$0x40, %rcx
14009f68c:     	cmovneq	%rcx, %rdx
14009f690:     	movq	%rdx, 0x444f0(%rax)
14009f697:     	movq	0x170(%rbp), %rax
14009f69e:     	movq	%rax, -0x18(%rbp)
14009f6a2:     	movq	0x168(%rbp), %rax
14009f6a9:     	movq	%rax, -0x20(%rbp)
14009f6ad:     	movl	%edi, -0x10(%rbp)
14009f6b0:     	movl	0x178(%rbp), %eax
14009f6b6:     	movl	%eax, -0xc(%rbp)
14009f6b9:     	movzwl	0x17c(%rbp), %eax
14009f6c0:     	movw	%ax, -0x8(%rbp)
14009f6c4:     	movb	%r15b, -0x6(%rbp)
14009f6c8:     	movzbl	0x17f(%rbp), %eax
14009f6cf:     	movb	%al, -0x5(%rbp)
14009f6d2:     	movss	%xmm6, -0x4(%rbp)
14009f6d7:     	movq	%r14, (%rbp)
14009f6db:     	testq	%r13, %r13
14009f6de:     	je	0x14009f742 <.text+0x9e742>
14009f6e0:     	movb	$0x1, 0x8(%rbp)
14009f6e4:     	movb	%r13b, 0x9(%rbp)
14009f6e8:     	leaq	0xa(%rbp), %r14
14009f6ec:     	movl	$0x80, %r8d
14009f6f2:     	subq	%r13, %r8
14009f6f5:     	leaq	0xa(,%r13), %rcx
14009f6fd:     	addq	%rbp, %rcx
14009f700:     	xorl	%edx, %edx
14009f702:     	callq	0x1402515b2 <.text+0x2505b2>
14009f707:     	leaq	0x150(%rbp), %rdx
14009f70e:     	movq	%r14, %rcx
14009f711:     	movq	%r13, %r8
14009f714:     	callq	0x1402515a0 <.text+0x2505a0>
14009f719:     	movzwl	-0x4(%rbp), %eax
14009f71d:     	addl	$0x2, %eax
14009f720:     	movl	%eax, (%r12,%rbx,4)
14009f724:     	imulq	$0x130, %rbx, %rax      # imm = 0x130
14009f72b:     	addq	%rax, %rsi
14009f72e:     	movzbl	0x8(%rbp), %eax
14009f732:     	leaq	0x1d0b17(%rip), %rcx    # 0x140270250
14009f739:     	movslq	(%rcx,%rax,4), %rax
14009f73d:     	addq	%rcx, %rax
14009f740:     	jmpq	*%rax
14009f742:     	movb	$0x0, 0x8(%rbp)
14009f746:     	movzwl	-0x4(%rbp), %eax
14009f74a:     	addl	$0x2, %eax
14009f74d:     	movl	%eax, (%r12,%rbx,4)
14009f751:     	imulq	$0x130, %rbx, %rax      # imm = 0x130
14009f758:     	addq	%rax, %rsi
14009f75b:     	movzbl	0x8(%rbp), %eax
14009f75f:     	leaq	0x1d0aea(%rip), %rcx    # 0x140270250
14009f766:     	movslq	(%rcx,%rax,4), %rax
14009f76a:     	addq	%rcx, %rax
14009f76d:     	jmpq	*%rax
14009f76f:     	movdqa	-0x20(%rbp), %xmm0
14009f774:     	movdqa	-0x10(%rbp), %xmm1
14009f779:     	movdqu	%xmm1, 0x10(%rsi)
14009f77e:     	movdqu	%xmm0, (%rsi)
14009f782:     	movb	$0x0, 0x28(%rsi)
14009f786:     	movq	(%rbp), %rax
14009f78a:     	movq	%rax, 0x20(%rsi)
14009f78e:     	jmp	0x14009f5e7 <.text+0x9e5e7>
14009f793:     	leaq	-0x20(%rbp), %rdx
14009f797:     	movl	$0x130, %r8d            # imm = 0x130
14009f79d:     	movq	%rsi, %rcx
14009f7a0:     	callq	0x1402515a0 <.text+0x2505a0>
14009f7a5:     	jmp	0x14009f5e7 <.text+0x9e5e7>
14009f7aa:     	movq	(%rbp), %r8
14009f7ae:     	movq	0x10(%rbp), %r9
14009f7b2:     	leaq	-0x20(%rbp), %rdx
14009f7b6:     	movq	%rsi, %rcx
14009f7b9:     	callq	0x14000b2d0 <.text+0xa2d0>
14009f7be:     	jmp	0x14009f5e7 <.text+0x9e5e7>
14009f7c3:     	leaq	0xa(%rbp), %r8
14009f7c7:     	movzbl	0x9(%rbp), %r9d
14009f7cc:     	leaq	-0x20(%rbp), %rdx
14009f7d0:     	movq	%rsi, %rcx
14009f7d3:     	callq	0x14000b1c0 <.text+0xa1c0>
14009f7d8:     	jmp	0x14009f5e7 <.text+0x9e5e7>
14009f7dd:     	shrq	$0x2, %rdx
14009f7e1:     	incq	%rdx
14009f7e4:     	movq	%rdx, %rbx
14009f7e7:     	andq	$-0x4, %rbx
14009f7eb:     	leaq	(%r12,%rbx,4), %r9
14009f7ef:     	xorl	%r8d, %r8d
14009f7f2:     	pxor	%xmm1, %xmm1
14009f7f6:     	movdqu	(%r12,%r8,4), %xmm0
14009f7fc:     	movdqa	%xmm0, %xmm2
14009f800:     	pcmpeqd	%xmm1, %xmm2
14009f804:     	movmskps	%xmm2, %r10d
14009f808:     	testl	%r10d, %r10d
14009f80b:     	jne	0x14009f824 <.text+0x9e824>
14009f80d:     	addq	$0x4, %r8
14009f811:     	cmpq	%r8, %rbx
14009f814:     	jne	0x14009f7f6 <.text+0x9e7f6>
14009f816:     	cmpq	%rbx, %rdx
14009f819:     	jne	0x14009f64f <.text+0x9e64f>
14009f81f:     	jmp	0x14009f5e7 <.text+0x9e5e7>
14009f824:     	pxor	%xmm1, %xmm1
14009f828:     	pcmpeqd	%xmm1, %xmm0
14009f82c:     	pand	0x1c455c(%rip), %xmm0   # 0x140263d90
14009f834:     	movdqa	0x1c2454(%rip), %xmm1   # 0x140261c90
14009f83c:     	movdqa	%xmm0, %xmm2
14009f840:     	por	%xmm1, %xmm2
14009f844:     	pshufd	$0xee, %xmm0, %xmm3     # xmm3 = xmm0[2,3,2,3]
14009f849:     	por	%xmm3, %xmm1
14009f84d:     	pcmpgtd	%xmm1, %xmm2
14009f851:     	pand	%xmm2, %xmm0
14009f855:     	pandn	%xmm3, %xmm2
14009f859:     	por	%xmm0, %xmm2
14009f85d:     	movd	%xmm2, %ecx
14009f861:     	pshufd	$0x55, %xmm2, %xmm0     # xmm0 = xmm2[1,1,1,1]
14009f866:     	movd	%xmm0, %edx
14009f86a:     	cmpl	%edx, %ecx
14009f86c:     	cmoval	%ecx, %edx
14009f86f:     	movl	$0x4, %ebx
14009f874:     	subl	%edx, %ebx
14009f876:     	addq	%r8, %rbx
14009f879:     	cmpq	$0x40, %rbx
14009f87d:     	jb	0x14009f670 <.text+0x9e670>
14009f883:     	leaq	0x1cd52e(%rip), %r8     # 0x14026cdb8
14009f88a:     	movl	$0x40, %edx
14009f88f:     	movq	%rbx, %rcx
14009f892:     	callq	0x140251e23 <.text+0x250e23>
14009f897:     	ud2
14009f899:     	leaq	0x1cd500(%rip), %r8     # 0x14026cda0
14009f8a0:     	movl	$0x40, %edx
14009f8a5:     	movq	%rbx, %rcx
14009f8a8:     	callq	0x140251e23 <.text+0x250e23>
14009f8ad:     	ud2

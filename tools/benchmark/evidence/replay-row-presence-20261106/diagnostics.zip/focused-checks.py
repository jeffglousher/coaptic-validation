from pathlib import Path
import os, subprocess, json
r=Path(__file__).resolve().parent
repo=Path('C:/Users/jeffg/.t3/worktrees/coaptic/t3-a578955c')
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR='D:/coaptic-batch-interop-target')
env.pop('RUSTFLAGS',None);env.pop('RUSTC_BOOTSTRAP',None)
checks=[('fmt',['fmt','--all','--','--check']),('tests',['test','--locked','--offline','--no-default-features','--features','alloc,oscore','--lib','--test','allocation_budget','--test','deferred_qblock2','--test','footprint']),('clippy-all',['clippy','--locked','--offline','--all-targets','--all-features','--','-D','warnings'])]
results=[]
for name,args in checks:
 cmd=[str(Path.home()/'.cargo/bin/agent-resources.exe'),'run','--id','coaptic-core-reusable','--directory',str(repo),'--','cargo',*args]
 with (r/(name+'.log')).open('wb') as log:p=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=cmd,exit_code=p.returncode));(r/'focused-checks.json').write_text(json.dumps(results,indent=2)+'\n');print(results[-1],flush=True)
 if p.returncode:raise SystemExit(p.returncode)

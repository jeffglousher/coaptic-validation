
D:\CoapticCurrent\replay-row-presence-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009e360:     	pushq	%rbp
14009e361:     	pushq	%r15
14009e363:     	pushq	%r14
14009e365:     	pushq	%r13
14009e367:     	pushq	%r12
14009e369:     	pushq	%rsi
14009e36a:     	pushq	%rdi
14009e36b:     	pushq	%rbx
14009e36c:     	subq	$0x218, %rsp            # imm = 0x218
14009e373:     	leaq	0x80(%rsp), %rbp
14009e37b:     	movaps	%xmm6, 0x180(%rbp)
14009e382:     	leaq	0x1970(%rcx), %rsi
14009e389:     	leaq	0x1998(%rcx), %r8
14009e390:     	movl	$0x4, %r11d
14009e396:     	xorl	%eax, %eax
14009e398:     	movl	$0x1, %r9d
14009e39e:     	xorl	%r10d, %r10d
14009e3a1:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009e3a8:     	addq	%r8, %rdi
14009e3ab:     	nopl	(%rax,%rax)
14009e3b0:     	cmpb	$0x2, -0xe(%rdi)
14009e3b4:     	jne	0x14009e3d0 <.text+0x9d3d0>
14009e3b6:     	incq	%r10
14009e3b9:     	addq	$0x130, %rdi            # imm = 0x130
14009e3c0:     	cmpq	%r10, %r11
14009e3c3:     	jne	0x14009e3b0 <.text+0x9d3b0>
14009e3c5:     	jmp	0x14009e415 <.text+0x9d415>
14009e3c7:     	nopw	(%rax,%rax)
14009e3d0:     	movq	-0x8(%rdi), %r11
14009e3d4:     	cmpb	$0x3, (%rdi)
14009e3d7:     	setne	%bl
14009e3da:     	testq	%r11, %r11
14009e3dd:     	sete	%dil
14009e3e1:     	orb	%bl, %dil
14009e3e4:     	cmpq	%r14, %r11
14009e3e7:     	setae	%bl
14009e3ea:     	andb	%al, %bl
14009e3ec:     	testb	%dil, %dil
14009e3ef:     	cmoveq	%r9, %rax
14009e3f3:     	orb	%dil, %bl
14009e3f6:     	cmoveq	%r10, %rdx
14009e3fa:     	cmoveq	%r11, %r14
14009e3fe:     	incq	%r10
14009e401:     	cmpq	$0x5, %r10
14009e405:     	movl	$0x4, %r11d
14009e40b:     	cmovaeq	%r10, %r11
14009e40f:     	cmpq	$0x3, %r10
14009e413:     	jbe	0x14009e3a1 <.text+0x9d3a1>
14009e415:     	testb	$0x1, %al
14009e417:     	je	0x14009e511 <.text+0x9d511>
14009e41d:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009e424:     	movzbl	0x1a(%rsi,%rax), %r15d
14009e42a:     	cmpb	$0x2, %r15b
14009e42e:     	je	0x14009e511 <.text+0x9d511>
14009e434:     	addq	%rsi, %rax
14009e437:     	cmpb	$0x3, 0x28(%rax)
14009e43b:     	jne	0x14009e511 <.text+0x9d511>
14009e441:     	movq	0x30(%rax), %r8
14009e445:     	movq	(%rax), %rdx
14009e448:     	movq	%rdx, 0x168(%rbp)
14009e44f:     	movq	0x8(%rax), %rdx
14009e453:     	movq	%rdx, 0x170(%rbp)
14009e45a:     	movl	0x10(%rax), %ebx
14009e45d:     	movl	0x14(%rax), %r12d
14009e461:     	movzwl	0x18(%rax), %edi
14009e465:     	movzbl	0x1b(%rax), %edx
14009e469:     	movb	%dl, 0x17f(%rbp)
14009e46f:     	movss	0x1c(%rax), %xmm6
14009e474:     	movzwl	0x1c(%rax), %eax
14009e478:     	movzwl	%ax, %edx
14009e47b:     	cmpq	$0x1, %r8
14009e47f:     	ja	0x14009e4db <.text+0x9d4db>
14009e481:     	cmpb	$0x1, 0x1968(%rcx,%r8)
14009e48a:     	jne	0x14009e4db <.text+0x9d4db>
14009e48c:     	cmpb	$0x0, 0x196a(%rcx,%r8)
14009e495:     	jne	0x14009e4db <.text+0x9d4db>
14009e497:     	movb	$0x0, 0x1968(%rcx,%r8)
14009e4a0:     	decq	0x1960(%rcx)
14009e4a7:     	leaq	0xfe0(%rcx), %r9
14009e4ae:     	movq	$0x0, 0x18e0(%rcx,%r8,8)
14009e4ba:     	leaq	(%r8,%r8,8), %r10
14009e4be:     	leaq	(%r10,%r10,2), %r10
14009e4c2:     	addq	%r8, %r10
14009e4c5:     	movb	$0x2, 0x95a(%r9,%r10)
14009e4ce:     	leaq	(%r8,%r8,2), %r8
14009e4d2:     	movb	$0x2, 0x91d(%r9,%r8,8)
14009e4db:     	addl	$0x2, %edx
14009e4de:     	movb	$0x1, %r9b
14009e4e1:     	cmpl	%edx, 0x1e30(%rcx)
14009e4e7:     	jne	0x14009e4f7 <.text+0x9d4f7>
14009e4e9:     	movzbl	0x198a(%rcx), %r8d
14009e4f1:     	cmpb	$0x2, %r8b
14009e4f5:     	jne	0x14009e52e <.text+0x9d52e>
14009e4f7:     	xorl	%r8d, %r8d
14009e4fa:     	cmpl	%edx, 0x1e34(%rcx)
14009e500:     	movl	%ebx, 0x178(%rbp)
14009e506:     	jne	0x14009e5bd <.text+0x9d5bd>
14009e50c:     	jmp	0x14009e5ab <.text+0x9d5ab>
14009e511:     	xorl	%eax, %eax
14009e513:     	movaps	0x180(%rbp), %xmm6
14009e51a:     	addq	$0x218, %rsp            # imm = 0x218
14009e521:     	popq	%rbx
14009e522:     	popq	%rdi
14009e523:     	popq	%rsi
14009e524:     	popq	%r12
14009e526:     	popq	%r13
14009e528:     	popq	%r14
14009e52a:     	popq	%r15
14009e52c:     	popq	%rbp
14009e52d:     	retq
14009e52e:     	cmpw	%ax, 0x198c(%rcx)
14009e535:     	sete	%r9b
14009e539:     	cmpl	%ebx, 0x1980(%rcx)
14009e53f:     	sete	%r10b
14009e543:     	andb	%r9b, %r10b
14009e546:     	cmpl	%r12d, 0x1984(%rcx)
14009e54d:     	sete	%r9b
14009e551:     	cmpw	%di, 0x1988(%rcx)
14009e558:     	sete	%r11b
14009e55c:     	andb	%r9b, %r11b
14009e55f:     	andb	%r10b, %r11b
14009e562:     	cmpb	%r15b, %r8b
14009e565:     	sete	%r8b
14009e569:     	movq	0x1978(%rcx), %r9
14009e570:     	xorq	0x170(%rbp), %r9
14009e577:     	movq	0x1970(%rcx), %r10
14009e57e:     	xorq	0x168(%rbp), %r10
14009e585:     	orq	%r9, %r10
14009e588:     	sete	%r9b
14009e58c:     	andb	%r8b, %r9b
14009e58f:     	andb	%r11b, %r9b
14009e592:     	movzbl	%r9b, %r8d
14009e596:     	movl	%r8d, %r9d
14009e599:     	xorb	$0x1, %r9b
14009e59d:     	cmpl	%edx, 0x1e34(%rcx)
14009e5a3:     	movl	%ebx, 0x178(%rbp)
14009e5a9:     	jne	0x14009e5bd <.text+0x9d5bd>
14009e5ab:     	movzbl	0x1aba(%rcx), %r10d
14009e5b3:     	cmpb	$0x2, %r10b
14009e5b7:     	jne	0x14009e66e <.text+0x9d66e>
14009e5bd:     	xorl	%r9d, %r9d
14009e5c0:     	cmpl	%edx, 0x1e38(%rcx)
14009e5c6:     	jne	0x14009e714 <.text+0x9d714>
14009e5cc:     	movzbl	0x1bea(%rcx), %r10d
14009e5d4:     	cmpb	$0x2, %r10b
14009e5d8:     	je	0x14009e714 <.text+0x9d714>
14009e5de:     	cmpb	%r15b, %r10b
14009e5e1:     	jne	0x14009e714 <.text+0x9d714>
14009e5e7:     	cmpw	%ax, 0x1bec(%rcx)
14009e5ee:     	jne	0x14009e714 <.text+0x9d714>
14009e5f4:     	cmpl	%ebx, 0x1be0(%rcx)
14009e5fa:     	jne	0x14009e714 <.text+0x9d714>
14009e600:     	cmpl	%r12d, 0x1be4(%rcx)
14009e607:     	jne	0x14009e714 <.text+0x9d714>
14009e60d:     	cmpw	%di, 0x1be8(%rcx)
14009e614:     	jne	0x14009e714 <.text+0x9d714>
14009e61a:     	movq	0x1bd0(%rcx), %r10
14009e621:     	xorq	0x168(%rbp), %r10
14009e628:     	movq	0x1bd8(%rcx), %r11
14009e62f:     	xorq	0x170(%rbp), %r11
14009e636:     	orq	%r10, %r11
14009e639:     	jne	0x14009e714 <.text+0x9d714>
14009e63f:     	movl	%r12d, %r13d
14009e642:     	movl	%edi, %r12d
14009e645:     	movb	$0x1, %dil
14009e648:     	testq	%r8, %r8
14009e64b:     	jne	0x14009e7a0 <.text+0x9d7a0>
14009e651:     	movl	$0x1, %r8d
14009e657:     	movl	$0x2, %r9d
14009e65d:     	movl	%r12d, %edi
14009e660:     	movl	%r13d, %r12d
14009e663:     	movl	0x178(%rbp), %ebx
14009e669:     	jmp	0x14009e714 <.text+0x9d714>
14009e66e:     	cmpw	%ax, 0x1abc(%rcx)
14009e675:     	setne	%r11b
14009e679:     	cmpl	%ebx, 0x1ab0(%rcx)
14009e67f:     	setne	%bl
14009e682:     	orb	%r11b, %bl
14009e685:     	movl	%r12d, %r13d
14009e688:     	cmpl	%r12d, 0x1ab4(%rcx)
14009e68f:     	setne	%r11b
14009e693:     	movl	%edi, %r12d
14009e696:     	cmpw	%di, 0x1ab8(%rcx)
14009e69d:     	setne	%dil
14009e6a1:     	orb	%r11b, %dil
14009e6a4:     	orb	%bl, %dil
14009e6a7:     	cmpb	%r15b, %r10b
14009e6aa:     	setne	%r11b
14009e6ae:     	movq	0x1aa8(%rcx), %r10
14009e6b5:     	xorq	0x170(%rbp), %r10
14009e6bc:     	movq	0x1aa0(%rcx), %rbx
14009e6c3:     	xorq	0x168(%rbp), %rbx
14009e6ca:     	orq	%r10, %rbx
14009e6cd:     	setne	%r10b
14009e6d1:     	orb	%r11b, %r10b
14009e6d4:     	orb	%dil, %r10b
14009e6d7:     	orb	%r10b, %r9b
14009e6da:     	testb	%r10b, %r10b
14009e6dd:     	movl	$0x1, %r11d
14009e6e3:     	cmoveq	%r11, %r8
14009e6e7:     	testb	$0x1, %r9b
14009e6eb:     	je	0x14009e79a <.text+0x9d79a>
14009e6f1:     	notb	%r10b
14009e6f4:     	movzbl	%r10b, %r9d
14009e6f8:     	andl	$0x1, %r9d
14009e6fc:     	movl	%r12d, %edi
14009e6ff:     	movl	%r13d, %r12d
14009e702:     	movl	0x178(%rbp), %ebx
14009e708:     	cmpl	%edx, 0x1e38(%rcx)
14009e70e:     	je	0x14009e5cc <.text+0x9d5cc>
14009e714:     	cmpl	%edx, 0x1e3c(%rcx)
14009e71a:     	jne	0x14009e728 <.text+0x9d728>
14009e71c:     	movzbl	0x1d1a(%rcx), %edx
14009e723:     	cmpb	$0x2, %dl
14009e726:     	jne	0x14009e73a <.text+0x9d73a>
14009e728:     	movl	%r12d, %r13d
14009e72b:     	movl	%edi, %r12d
14009e72e:     	xorl	%edi, %edi
14009e730:     	testq	%r8, %r8
14009e733:     	jne	0x14009e7a0 <.text+0x9d7a0>
14009e735:     	jmp	0x14009e7ca <.text+0x9d7ca>
14009e73a:     	cmpb	%r15b, %dl
14009e73d:     	jne	0x14009e728 <.text+0x9d728>
14009e73f:     	cmpw	%ax, 0x1d1c(%rcx)
14009e746:     	jne	0x14009e728 <.text+0x9d728>
14009e748:     	cmpl	%ebx, 0x1d10(%rcx)
14009e74e:     	jne	0x14009e728 <.text+0x9d728>
14009e750:     	cmpl	%r12d, 0x1d14(%rcx)
14009e757:     	jne	0x14009e728 <.text+0x9d728>
14009e759:     	cmpw	%di, 0x1d18(%rcx)
14009e760:     	jne	0x14009e728 <.text+0x9d728>
14009e762:     	movq	0x1d00(%rcx), %rdx
14009e769:     	xorq	0x168(%rbp), %rdx
14009e770:     	movq	0x1d08(%rcx), %r10
14009e777:     	xorq	0x170(%rbp), %r10
14009e77e:     	orq	%rdx, %r10
14009e781:     	jne	0x14009e728 <.text+0x9d728>
14009e783:     	movl	%r12d, %r13d
14009e786:     	movl	%edi, %r12d
14009e789:     	testq	%r8, %r8
14009e78c:     	movl	$0x3, %edx
14009e791:     	cmoveq	%rdx, %r9
14009e795:     	movl	%r8d, %edi
14009e798:     	jmp	0x14009e7a0 <.text+0x9d7a0>
14009e79a:     	movb	$0x1, %dil
14009e79d:     	xorl	%r9d, %r9d
14009e7a0:     	cmpl	$0x0, 0x1e30(%rcx,%r9,4)
14009e7a9:     	je	0x14009e7ca <.text+0x9d7ca>
14009e7ab:     	movl	$0x0, 0x1e30(%rcx,%r9,4)
14009e7b7:     	decq	0x1e48(%rcx)
14009e7be:     	imulq	$0x130, %r9, %rdx       # imm = 0x130
14009e7c5:     	movb	$0x2, 0x1a(%rsi,%rdx)
14009e7ca:     	xorps	%xmm0, %xmm0
14009e7cd:     	movaps	%xmm0, 0x150(%rbp)
14009e7d4:     	movb	$0x0, 0x132(%rbp)
14009e7db:     	movw	%ax, 0x130(%rbp)
14009e7e2:     	leaq	0x133(%rbp), %rdx
14009e7e9:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009e7f2:     	movq	$0x0, 0x133(%rbp)
14009e7fd:     	movq	$0x8, 0x110(%rbp)
14009e808:     	movq	$0x0, 0x118(%rbp)
14009e813:     	movq	$0x1, 0x120(%rbp)
14009e81e:     	movq	$0x0, 0x128(%rbp)
14009e829:     	movq	%rdx, 0x30(%rsp)
14009e82e:     	movw	%ax, 0x28(%rsp)
14009e833:     	movq	$0x0, 0x58(%rsp)
14009e83c:     	movq	$0x1, 0x50(%rsp)
14009e845:     	movq	$0x8, 0x48(%rsp)
14009e84e:     	movq	$0x8, 0x40(%rsp)
14009e857:     	movq	$0x0, 0x38(%rsp)
14009e860:     	movb	$0x0, 0x20(%rsp)
14009e865:     	leaq	0x140(%rbp), %rax
14009e86c:     	leaq	0x150(%rbp), %rdx
14009e873:     	movl	$0x10, %r8d
14009e879:     	movq	%rcx, %rbx
14009e87c:     	movq	%rax, %rcx
14009e87f:     	movb	$0x2, %r9b
14009e882:     	callq	0x140005590 <.text+0x4590>
14009e887:     	cmpb	$0x0, 0x140(%rbp)
14009e88e:     	jne	0x14009e8af <.text+0x9d8af>
14009e890:     	testb	%dil, %dil
14009e893:     	jne	0x14009e8af <.text+0x9d8af>
14009e895:     	movq	%rbx, %rax
14009e898:     	movq	0x148(%rbp), %rbx
14009e89f:     	cmpq	$0x10, %rbx
14009e8a3:     	ja	0x14009e8af <.text+0x9d8af>
14009e8a5:     	cmpq	$0x4, 0x1e48(%rax)
14009e8ad:     	jne	0x14009e8b6 <.text+0x9d8b6>
14009e8af:     	movb	$0x1, %al
14009e8b1:     	jmp	0x14009e513 <.text+0x9d513>
14009e8b6:     	movq	0x1e40(%rax), %rdi
14009e8bd:     	cmpq	$0x3, %rdi
14009e8c1:     	ja	0x14009eabd <.text+0x9dabd>
14009e8c7:     	cmpl	$0x0, 0x1e30(%rax,%rdi,4)
14009e8cf:     	je	0x14009e942 <.text+0x9d942>
14009e8d1:     	leaq	(,%rdi,4), %rdx
14009e8d9:     	xorl	%ecx, %ecx
14009e8db:     	nopl	(%rax,%rax)
14009e8e0:     	cmpl	$0x0, 0x1e30(%rax,%rdx)
14009e8e8:     	je	0x14009e935 <.text+0x9d935>
14009e8ea:     	addq	$0x4, %rdx
14009e8ee:     	decq	%rcx
14009e8f1:     	cmpq	$0x10, %rdx
14009e8f5:     	jne	0x14009e8e0 <.text+0x9d8e0>
14009e8f7:     	testq	%rdi, %rdi
14009e8fa:     	je	0x14009e8af <.text+0x9d8af>
14009e8fc:     	cmpl	$0x0, 0x1e30(%rax)
14009e903:     	je	0x14009eaac <.text+0x9daac>
14009e909:     	cmpq	$0x1, %rdi
14009e90d:     	je	0x14009e8af <.text+0x9d8af>
14009e90f:     	cmpl	$0x0, 0x1e34(%rax)
14009e916:     	je	0x14009eab3 <.text+0x9dab3>
14009e91c:     	cmpq	$0x2, %rdi
14009e920:     	je	0x14009e8af <.text+0x9d8af>
14009e922:     	movl	$0x2, %edi
14009e927:     	cmpl	$0x0, 0x1e38(%rax)
14009e92e:     	je	0x14009e938 <.text+0x9d938>
14009e930:     	jmp	0x14009e8af <.text+0x9d8af>
14009e935:     	subq	%rcx, %rdi
14009e938:     	cmpq	$0x4, %rdi
14009e93c:     	jae	0x14009ead3 <.text+0x9dad3>
14009e942:     	movl	$0x1, 0x1e30(%rax,%rdi,4)
14009e94d:     	incq	0x1e48(%rax)
14009e954:     	leaq	0x1(%rdi), %rcx
14009e958:     	xorl	%edx, %edx
14009e95a:     	cmpq	$0x4, %rcx
14009e95e:     	cmovneq	%rcx, %rdx
14009e962:     	movq	%rdx, 0x1e40(%rax)
14009e969:     	movq	0x170(%rbp), %rcx
14009e970:     	movq	%rcx, -0x18(%rbp)
14009e974:     	movq	0x168(%rbp), %rcx
14009e97b:     	movq	%rcx, -0x20(%rbp)
14009e97f:     	movl	0x178(%rbp), %ecx
14009e985:     	movl	%ecx, -0x10(%rbp)
14009e988:     	movl	%r13d, -0xc(%rbp)
14009e98c:     	movw	%r12w, -0x8(%rbp)
14009e991:     	movb	%r15b, -0x6(%rbp)
14009e995:     	movzbl	0x17f(%rbp), %ecx
14009e99c:     	movb	%cl, -0x5(%rbp)
14009e99f:     	movss	%xmm6, -0x4(%rbp)
14009e9a4:     	movq	%r14, (%rbp)
14009e9a8:     	testq	%rbx, %rbx
14009e9ab:     	je	0x14009ea12 <.text+0x9da12>
14009e9ad:     	movb	$0x1, 0x8(%rbp)
14009e9b1:     	movb	%bl, 0x9(%rbp)
14009e9b4:     	leaq	0xa(%rbp), %r14
14009e9b8:     	movl	$0x80, %r8d
14009e9be:     	subq	%rbx, %r8
14009e9c1:     	leaq	(%rbx,%rbp), %rcx
14009e9c5:     	addq	$0xa, %rcx
14009e9c9:     	movq	%rax, %r15
14009e9cc:     	xorl	%edx, %edx
14009e9ce:     	callq	0x1402515b2 <.text+0x2505b2>
14009e9d3:     	leaq	0x150(%rbp), %rdx
14009e9da:     	movq	%r14, %rcx
14009e9dd:     	movq	%rbx, %r8
14009e9e0:     	callq	0x1402515a0 <.text+0x2505a0>
14009e9e5:     	movzwl	-0x4(%rbp), %eax
14009e9e9:     	addl	$0x2, %eax
14009e9ec:     	movl	%eax, 0x1e30(%r15,%rdi,4)
14009e9f4:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009e9fb:     	addq	%rax, %rsi
14009e9fe:     	movzbl	0x8(%rbp), %eax
14009ea02:     	leaq	0x1d1827(%rip), %rcx    # 0x140270230
14009ea09:     	movslq	(%rcx,%rax,4), %rax
14009ea0d:     	addq	%rcx, %rax
14009ea10:     	jmpq	*%rax
14009ea12:     	movb	$0x0, 0x8(%rbp)
14009ea16:     	movzwl	-0x4(%rbp), %ecx
14009ea1a:     	addl	$0x2, %ecx
14009ea1d:     	movl	%ecx, 0x1e30(%rax,%rdi,4)
14009ea24:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009ea2b:     	addq	%rax, %rsi
14009ea2e:     	movzbl	0x8(%rbp), %eax
14009ea32:     	leaq	0x1d17f7(%rip), %rcx    # 0x140270230
14009ea39:     	movslq	(%rcx,%rax,4), %rax
14009ea3d:     	addq	%rcx, %rax
14009ea40:     	jmpq	*%rax
14009ea42:     	movaps	-0x20(%rbp), %xmm0
14009ea46:     	movaps	-0x10(%rbp), %xmm1
14009ea4a:     	movups	%xmm1, 0x10(%rsi)
14009ea4e:     	movups	%xmm0, (%rsi)
14009ea51:     	movb	$0x0, 0x28(%rsi)
14009ea55:     	movq	(%rbp), %rax
14009ea59:     	movq	%rax, 0x20(%rsi)
14009ea5d:     	jmp	0x14009e8af <.text+0x9d8af>
14009ea62:     	leaq	-0x20(%rbp), %rdx
14009ea66:     	movl	$0x130, %r8d            # imm = 0x130
14009ea6c:     	movq	%rsi, %rcx
14009ea6f:     	callq	0x1402515a0 <.text+0x2505a0>
14009ea74:     	jmp	0x14009e8af <.text+0x9d8af>
14009ea79:     	movq	(%rbp), %r8
14009ea7d:     	movq	0x10(%rbp), %r9
14009ea81:     	leaq	-0x20(%rbp), %rdx
14009ea85:     	movq	%rsi, %rcx
14009ea88:     	callq	0x14000b2d0 <.text+0xa2d0>
14009ea8d:     	jmp	0x14009e8af <.text+0x9d8af>
14009ea92:     	leaq	0xa(%rbp), %r8
14009ea96:     	movzbl	0x9(%rbp), %r9d
14009ea9b:     	leaq	-0x20(%rbp), %rdx
14009ea9f:     	movq	%rsi, %rcx
14009eaa2:     	callq	0x14000b1c0 <.text+0xa1c0>
14009eaa7:     	jmp	0x14009e8af <.text+0x9d8af>
14009eaac:     	xorl	%edi, %edi
14009eaae:     	jmp	0x14009e938 <.text+0x9d938>
14009eab3:     	movl	$0x1, %edi
14009eab8:     	jmp	0x14009e938 <.text+0x9d938>
14009eabd:     	leaq	0x1ce2dc(%rip), %r8     # 0x14026cda0
14009eac4:     	movl	$0x4, %edx
14009eac9:     	movq	%rdi, %rcx
14009eacc:     	callq	0x140251e23 <.text+0x250e23>
14009ead1:     	ud2
14009ead3:     	leaq	0x1ce2de(%rip), %r8     # 0x14026cdb8
14009eada:     	movl	$0x4, %edx
14009eadf:     	movq	%rdi, %rcx
14009eae2:     	callq	0x140251e23 <.text+0x250e23>
14009eae7:     	ud2

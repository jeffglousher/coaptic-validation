from pathlib import Path
import subprocess,json,hashlib,shutil
r=Path(__file__).resolve().parent
p=Path('D:/CoapticCurrent/short-inline-replay-20261106/active-bytes')
repo=Path('C:/Users/jeffg/.t3/worktrees/coaptic/t3-a578955c')
sha='8fc41ead4790e25051ae90c395b012b4c8518f72';old='6760b72a8ed07b6a108cde24eeb36e552a0f076d'
v=json.loads((p/'source-verification.json').read_text());v['source']=sha
core=Path(v['fixture_root'])/'coaptic'
for name in v['source_file_hashes']:
 data=subprocess.check_output(['git','-C',str(repo),'show',sha+':'+name]).replace(b'\r\n',b'\n')
 if (core/name).read_bytes()!=data:(core/name).write_bytes(data)
 v['source_file_hashes'][name]=hashlib.sha256(data).hexdigest()
patch=subprocess.check_output(['git','-C',str(repo),'diff','--binary',v['baseline'],sha,'--','src','crates','tests','Cargo.toml','Cargo.lock'])
(r/'candidate.patch').write_bytes(patch);v['patch_sha256']=hashlib.sha256(patch).hexdigest()
(r/'source-verification.json').write_text(json.dumps(v,indent=2)+'\n')
for name in ['build-preflight.py','build.py','layout.py','inspect.py','inspect-inline.py','inspect-reclaim.py','check-preflight.py','baseline-reclaim-symbols.txt','measure.py','qualify.py','focused-checks.py','fixture-sha256.json']:
 (r/name).write_text((p/name).read_text().replace(old,sha))
(r/'B').mkdir(exist_ok=True);(r/'layout32').mkdir(exist_ok=True)
for name in ['audit.py','Cargo.toml','Cargo.lock','lib.rs','baseline-build.log','baseline-constants.txt','baseline-layout.txt','baseline-source.json']:
 (r/'layout32'/name).write_bytes((p/'layout32'/name).read_bytes())
m=json.loads((p/'METHOD-BEFORE.json').read_text());m['candidate']=sha
m['hypothesis']=m['source_hypothesis']='Use initialized Option row presence instead of repeating occupancy reads in fixed and allocated entry_ref. Acquire/release clear rows; an acquired-empty slot remains None. No capacity, layout, initialization or public refusal change. Keep previous short128-byte writer, compact owner, reclaimed lookup and full-chunk improvements integrated.'
m['tradeoffs']='Relies explicitly on existing private row/occupancy coherence invariant. Complete state models and focused general review cover every write/reset/release path. No buffer threshold changes or new metadata.'
m['preflight_repair']='Preceding6760b72 failed two SmallDevice CPU bounds; preserve it. This candidate changes row-access checks, not the failed cohort sampling. Repeat changed-code regressions and selected emitted frames, then one64-pair cohort with unchanged rules.'
(r/'METHOD-BEFORE.json').write_text(json.dumps(m,indent=2)+'\n');print({'source':sha,'verified_files':len(v['source_file_hashes'])})


D:\CoapticCurrent\replay-row-presence-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068260:     	pushq	%rbp
140068261:     	pushq	%r15
140068263:     	pushq	%r14
140068265:     	pushq	%r13
140068267:     	pushq	%r12
140068269:     	pushq	%rsi
14006826a:     	pushq	%rdi
14006826b:     	pushq	%rbx
14006826c:     	subq	$0x508, %rsp            # imm = 0x508
140068273:     	leaq	0x80(%rsp), %rbp
14006827b:     	movq	0x500(%rbp), %r12
140068282:     	movq	0x8(%r12), %rdi
140068287:     	movl	$0x3, %r10d
14006828d:     	cmpq	$0x3, %rdi
140068291:     	ja	0x140068371 <.text+0x67371>
140068297:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
14006829f:     	jne	0x140068371 <.text+0x67371>
1400682a5:     	movq	0x26700(%rdx,%rdi,8), %rax
1400682ad:     	cmpq	$0x4001, %rax           # imm = 0x4001
1400682b3:     	jae	0x14006854e <.text+0x6754e>
1400682b9:     	movq	0x10(%r12), %r11
1400682be:     	movq	0x18(%r12), %r15
1400682c3:     	movq	%r15, %rsi
1400682c6:     	movl	$0xb, %r10d
1400682cc:     	addq	%r11, %rsi
1400682cf:     	jb	0x140068371 <.text+0x67371>
1400682d5:     	cmpq	$0x400, %r15            # imm = 0x400
1400682dc:     	ja	0x140068371 <.text+0x67371>
1400682e2:     	cmpq	%rax, %rsi
1400682e5:     	ja	0x140068371 <.text+0x67371>
1400682eb:     	movq	%r8, %r13
1400682ee:     	movq	%r9, 0x470(%rbp)
1400682f5:     	movq	%rcx, 0x480(%rbp)
1400682fc:     	movzbl	0x508(%rbp), %r14d
140068304:     	movq	%rdi, %rax
140068307:     	shlq	$0xe, %rax
14006830b:     	movq	%rdx, %rsi
14006830e:     	leaq	(%rdx,%rax), %rbx
140068312:     	addq	$0x16700, %rbx          # imm = 0x16700
140068319:     	addq	%r11, %rbx
14006831c:     	movl	$0x400, %r8d            # imm = 0x400
140068322:     	cmpq	$0x400, %r15            # imm = 0x400
140068329:     	je	0x140068338 <.text+0x67338>
14006832b:     	movq	%rbp, %rcx
14006832e:     	xorl	%edx, %edx
140068330:     	callq	0x1402515b2 <.text+0x2505b2>
140068335:     	movq	%r15, %r8
140068338:     	movq	%rbp, %rcx
14006833b:     	movq	%rbx, %rdx
14006833e:     	callq	0x1402515a0 <.text+0x2505a0>
140068343:     	testb	%r14b, %r14b
140068346:     	je	0x14006838c <.text+0x6738c>
140068348:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
14006834f:     	movq	%rsi, %rcx
140068352:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
14006835b:     	jne	0x140068503 <.text+0x67503>
140068361:     	xorl	%edi, %edi
140068363:     	callq	0x14009af90 <.text+0x99f90>
140068368:     	testb	$0x1, %al
14006836a:     	jne	0x14006839e <.text+0x6739e>
14006836c:     	jmp	0x14006852c <.text+0x6752c>
140068371:     	movb	$0xa, (%rcx)
140068374:     	movq	%r10, 0x8(%rcx)
140068378:     	addq	$0x508, %rsp            # imm = 0x508
14006837f:     	popq	%rbx
140068380:     	popq	%rdi
140068381:     	popq	%rsi
140068382:     	popq	%r12
140068384:     	popq	%r13
140068386:     	popq	%r14
140068388:     	popq	%r15
14006838a:     	popq	%rbp
14006838b:     	retq
14006838c:     	xorl	%edi, %edi
14006838e:     	movq	%rsi, %rcx
140068391:     	callq	0x14009af90 <.text+0x99f90>
140068396:     	testb	$0x1, %al
140068398:     	je	0x14006852c <.text+0x6752c>
14006839e:     	movq	%rdx, %rbx
1400683a1:     	movq	0x518(%rbp), %rdx
1400683a8:     	movq	0x510(%rbp), %r8
1400683af:     	movzwl	0x4f8(%rbp), %ecx
1400683b6:     	movzbl	0x4f0(%rbp), %eax
1400683bd:     	movq	(%r12), %r9
1400683c1:     	movq	%rdi, 0x440(%rbp)
1400683c8:     	movq	0x478(%rbp), %r10
1400683cf:     	movq	%r10, 0x448(%rbp)
1400683d6:     	movq	%r9, 0x450(%rbp)
1400683dd:     	movb	%r14b, 0x458(%rbp)
1400683e4:     	movups	0x60(%r13), %xmm0
1400683e9:     	movups	0x6c(%r13), %xmm1
1400683ee:     	movups	%xmm1, 0x40c(%rbp)
1400683f5:     	movaps	%xmm0, 0x400(%rbp)
1400683fc:     	leaq	0x8e(%r13), %r9
140068403:     	movq	0x7e(%r13), %r10
140068407:     	movq	0x85(%r13), %r11
14006840e:     	movq	%r11, 0x467(%rbp)
140068415:     	movq	%r10, 0x460(%rbp)
14006841c:     	leaq	0x460(%rbp), %r10
140068423:     	movq	%r10, 0x70(%rsp)
140068428:     	movq	%rdx, 0x68(%rsp)
14006842d:     	movq	%r8, 0x60(%rsp)
140068432:     	movq	%r13, 0x58(%rsp)
140068437:     	leaq	0x440(%rbp), %rdx
14006843e:     	movq	%rdx, 0x50(%rsp)
140068443:     	movq	%r15, 0x48(%rsp)
140068448:     	movq	%rbp, %rdx
14006844b:     	movq	%rdx, 0x40(%rsp)
140068450:     	movq	0x470(%rbp), %rdx
140068457:     	movq	%rdx, 0x38(%rsp)
14006845c:     	movq	%r9, 0x30(%rsp)
140068461:     	movw	%cx, 0x28(%rsp)
140068466:     	movb	%al, 0x20(%rsp)
14006846a:     	leaq	0x420(%rbp), %rcx
140068471:     	leaq	0x400(%rbp), %r8
140068478:     	movq	%rsi, %rdx
14006847b:     	movq	%rbx, %r9
14006847e:     	callq	0x1400811c0 <.text+0x801c0>
140068483:     	cmpb	$-0x1, 0x420(%rbp)
14006848a:     	je	0x14006853b <.text+0x6753b>
140068490:     	cmpb	$0x1, 0x326f0(%rsi,%rbx)
140068498:     	movq	0x480(%rbp), %rax
14006849f:     	jne	0x1400684e9 <.text+0x674e9>
1400684a1:     	cmpb	$0x0, 0x32710(%rsi,%rbx)
1400684a9:     	jne	0x1400684e9 <.text+0x674e9>
1400684ab:     	movb	$0x0, 0x326f0(%rsi,%rbx)
1400684b3:     	decq	0x32738(%rsi)
1400684ba:     	leaq	0x326f0(%rsi), %rcx
1400684c1:     	movq	$0x0, 0x3e5c0(%rsi,%rbx,8)
1400684cd:     	leaq	(%rbx,%rbx,8), %rdx
1400684d1:     	leaq	(%rdx,%rdx,2), %rdx
1400684d5:     	addq	%rbx, %rdx
1400684d8:     	movb	$0x2, 0x36a(%rcx,%rdx)
1400684e0:     	leaq	(%rbx,%rbx,2), %rdx
1400684e4:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
1400684e9:     	movups	0x420(%rbp), %xmm0
1400684f0:     	movups	0x430(%rbp), %xmm1
1400684f7:     	movups	%xmm1, 0x10(%rax)
1400684fb:     	movups	%xmm0, (%rax)
1400684fe:     	jmp	0x140068378 <.text+0x67378>
140068503:     	addq	%rcx, %rax
140068506:     	addq	$0x15c28, %rax          # imm = 0x15C28
14006850c:     	movq	0x98(%rax), %rax
140068513:     	movq	%rax, 0x478(%rbp)
14006851a:     	movl	$0x1, %edi
14006851f:     	callq	0x14009af90 <.text+0x99f90>
140068524:     	testb	$0x1, %al
140068526:     	jne	0x14006839e <.text+0x6739e>
14006852c:     	movq	0x480(%rbp), %rax
140068533:     	movb	$0x9, (%rax)
140068536:     	jmp	0x140068378 <.text+0x67378>
14006853b:     	movq	0x480(%rbp), %rax
140068542:     	movq	%rbx, 0x8(%rax)
140068546:     	movb	$-0x1, (%rax)
140068549:     	jmp	0x140068378 <.text+0x67378>
14006854e:     	leaq	0x2046fb(%rip), %r9     # 0x14026cc50
140068555:     	movl	$0x4000, %r8d           # imm = 0x4000
14006855b:     	xorl	%ecx, %ecx
14006855d:     	movq	%rax, %rdx
140068560:     	callq	0x140252030 <.text+0x251030>
140068565:     	ud2

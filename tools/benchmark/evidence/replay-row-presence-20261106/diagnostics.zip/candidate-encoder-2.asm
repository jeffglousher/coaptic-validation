
D:\CoapticCurrent\replay-row-presence-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068570:     	pushq	%rbp
140068571:     	pushq	%r15
140068573:     	pushq	%r14
140068575:     	pushq	%r13
140068577:     	pushq	%r12
140068579:     	pushq	%rsi
14006857a:     	pushq	%rdi
14006857b:     	pushq	%rbx
14006857c:     	subq	$0x4f8, %rsp            # imm = 0x4F8
140068583:     	leaq	0x80(%rsp), %rbp
14006858b:     	movq	0x4f0(%rbp), %r12
140068592:     	movq	0x8(%r12), %rdi
140068597:     	movl	$0x3, %r10d
14006859d:     	cmpq	$0x3, %rdi
1400685a1:     	ja	0x140068683 <.text+0x67683>
1400685a7:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
1400685af:     	jne	0x140068683 <.text+0x67683>
1400685b5:     	movq	0x26700(%rdx,%rdi,8), %rax
1400685bd:     	cmpq	$0x4001, %rax           # imm = 0x4001
1400685c3:     	jae	0x140068855 <.text+0x67855>
1400685c9:     	movq	0x10(%r12), %r11
1400685ce:     	movq	0x18(%r12), %r15
1400685d3:     	movq	%r15, %rsi
1400685d6:     	movl	$0xb, %r10d
1400685dc:     	addq	%r11, %rsi
1400685df:     	jb	0x140068683 <.text+0x67683>
1400685e5:     	cmpq	$0x400, %r15            # imm = 0x400
1400685ec:     	ja	0x140068683 <.text+0x67683>
1400685f2:     	cmpq	%rax, %rsi
1400685f5:     	ja	0x140068683 <.text+0x67683>
1400685fb:     	movq	%r8, %r13
1400685fe:     	movq	%r9, 0x460(%rbp)
140068605:     	movq	%rcx, 0x470(%rbp)
14006860c:     	movzbl	0x4f8(%rbp), %r14d
140068614:     	movq	%rdi, %rax
140068617:     	shlq	$0xe, %rax
14006861b:     	movq	%rdx, %rsi
14006861e:     	leaq	(%rdx,%rax), %rbx
140068622:     	addq	$0x16700, %rbx          # imm = 0x16700
140068629:     	addq	%r11, %rbx
14006862c:     	movl	$0x400, %r8d            # imm = 0x400
140068632:     	cmpq	$0x400, %r15            # imm = 0x400
140068639:     	je	0x140068649 <.text+0x67649>
14006863b:     	leaq	-0x10(%rbp), %rcx
14006863f:     	xorl	%edx, %edx
140068641:     	callq	0x1402515b2 <.text+0x2505b2>
140068646:     	movq	%r15, %r8
140068649:     	leaq	-0x10(%rbp), %rcx
14006864d:     	movq	%rbx, %rdx
140068650:     	callq	0x1402515a0 <.text+0x2505a0>
140068655:     	testb	%r14b, %r14b
140068658:     	je	0x14006869e <.text+0x6769e>
14006865a:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
140068661:     	movq	%rsi, %rcx
140068664:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
14006866d:     	jne	0x14006880a <.text+0x6780a>
140068673:     	xorl	%edi, %edi
140068675:     	callq	0x14009af90 <.text+0x99f90>
14006867a:     	testb	$0x1, %al
14006867c:     	jne	0x1400686b0 <.text+0x676b0>
14006867e:     	jmp	0x140068833 <.text+0x67833>
140068683:     	movb	$0xa, (%rcx)
140068686:     	movq	%r10, 0x8(%rcx)
14006868a:     	addq	$0x4f8, %rsp            # imm = 0x4F8
140068691:     	popq	%rbx
140068692:     	popq	%rdi
140068693:     	popq	%rsi
140068694:     	popq	%r12
140068696:     	popq	%r13
140068698:     	popq	%r14
14006869a:     	popq	%r15
14006869c:     	popq	%rbp
14006869d:     	retq
14006869e:     	xorl	%edi, %edi
1400686a0:     	movq	%rsi, %rcx
1400686a3:     	callq	0x14009af90 <.text+0x99f90>
1400686a8:     	testb	$0x1, %al
1400686aa:     	je	0x140068833 <.text+0x67833>
1400686b0:     	movq	%rdx, %rbx
1400686b3:     	movq	0x500(%rbp), %rdx
1400686ba:     	movzwl	0x4e8(%rbp), %ecx
1400686c1:     	movzbl	0x4e0(%rbp), %eax
1400686c8:     	movq	(%r12), %r8
1400686cc:     	movq	%rdi, 0x430(%rbp)
1400686d3:     	movq	0x468(%rbp), %r9
1400686da:     	movq	%r9, 0x438(%rbp)
1400686e1:     	movq	%r8, 0x440(%rbp)
1400686e8:     	movb	%r14b, 0x448(%rbp)
1400686ef:     	movups	0x60(%r13), %xmm0
1400686f4:     	movups	0x6c(%r13), %xmm1
1400686f9:     	movups	%xmm1, 0x3fc(%rbp)
140068700:     	movaps	%xmm0, 0x3f0(%rbp)
140068707:     	leaq	0x8e(%r13), %r8
14006870e:     	movq	0x7e(%r13), %r9
140068712:     	movq	0x85(%r13), %r10
140068719:     	movq	%r10, 0x457(%rbp)
140068720:     	movq	%r9, 0x450(%rbp)
140068727:     	leaq	0x450(%rbp), %r9
14006872e:     	movq	%r9, 0x68(%rsp)
140068733:     	movq	%rdx, 0x60(%rsp)
140068738:     	movq	%r13, 0x58(%rsp)
14006873d:     	leaq	0x430(%rbp), %rdx
140068744:     	movq	%rdx, 0x50(%rsp)
140068749:     	movq	%r15, 0x48(%rsp)
14006874e:     	leaq	-0x10(%rbp), %rdx
140068752:     	movq	%rdx, 0x40(%rsp)
140068757:     	movq	0x460(%rbp), %rdx
14006875e:     	movq	%rdx, 0x38(%rsp)
140068763:     	movq	%r8, 0x30(%rsp)
140068768:     	movw	%cx, 0x28(%rsp)
14006876d:     	movb	%al, 0x20(%rsp)
140068771:     	leaq	0x410(%rbp), %rcx
140068778:     	leaq	0x3f0(%rbp), %r8
14006877f:     	movq	%rsi, %rdx
140068782:     	movq	%rbx, %r9
140068785:     	callq	0x1400829b0 <.text+0x819b0>
14006878a:     	cmpb	$-0x1, 0x410(%rbp)
140068791:     	je	0x140068842 <.text+0x67842>
140068797:     	cmpb	$0x1, 0x326f0(%rsi,%rbx)
14006879f:     	movq	0x470(%rbp), %rax
1400687a6:     	jne	0x1400687f0 <.text+0x677f0>
1400687a8:     	cmpb	$0x0, 0x32710(%rsi,%rbx)
1400687b0:     	jne	0x1400687f0 <.text+0x677f0>
1400687b2:     	movb	$0x0, 0x326f0(%rsi,%rbx)
1400687ba:     	decq	0x32738(%rsi)
1400687c1:     	leaq	0x326f0(%rsi), %rcx
1400687c8:     	movq	$0x0, 0x3e5c0(%rsi,%rbx,8)
1400687d4:     	leaq	(%rbx,%rbx,8), %rdx
1400687d8:     	leaq	(%rdx,%rdx,2), %rdx
1400687dc:     	addq	%rbx, %rdx
1400687df:     	movb	$0x2, 0x36a(%rcx,%rdx)
1400687e7:     	leaq	(%rbx,%rbx,2), %rdx
1400687eb:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
1400687f0:     	movups	0x410(%rbp), %xmm0
1400687f7:     	movups	0x420(%rbp), %xmm1
1400687fe:     	movups	%xmm1, 0x10(%rax)
140068802:     	movups	%xmm0, (%rax)
140068805:     	jmp	0x14006868a <.text+0x6768a>
14006880a:     	addq	%rcx, %rax
14006880d:     	addq	$0x15c28, %rax          # imm = 0x15C28
140068813:     	movq	0x98(%rax), %rax
14006881a:     	movq	%rax, 0x468(%rbp)
140068821:     	movl	$0x1, %edi
140068826:     	callq	0x14009af90 <.text+0x99f90>
14006882b:     	testb	$0x1, %al
14006882d:     	jne	0x1400686b0 <.text+0x676b0>
140068833:     	movq	0x470(%rbp), %rax
14006883a:     	movb	$0x9, (%rax)
14006883d:     	jmp	0x14006868a <.text+0x6768a>
140068842:     	movq	0x470(%rbp), %rax
140068849:     	movq	%rbx, 0x8(%rax)
14006884d:     	movb	$-0x1, (%rax)
140068850:     	jmp	0x14006868a <.text+0x6768a>
140068855:     	leaq	0x2043f4(%rip), %r9     # 0x14026cc50
14006885c:     	movl	$0x4000, %r8d           # imm = 0x4000
140068862:     	xorl	%ecx, %ecx
140068864:     	movq	%rax, %rdx
140068867:     	callq	0x140252030 <.text+0x251030>
14006886c:     	ud2

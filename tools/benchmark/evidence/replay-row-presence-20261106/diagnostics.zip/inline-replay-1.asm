
D:\CoapticCurrent\replay-row-presence-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14000b1c0:     	pushq	%rbp
14000b1c1:     	movq	%rsp, %rbp
14000b1c4:     	movq	0x20(%rdx), %rax
14000b1c8:     	movups	(%rdx), %xmm0
14000b1cb:     	movups	0x10(%rdx), %xmm1
14000b1cf:     	movups	%xmm1, 0x10(%rcx)
14000b1d3:     	movups	%xmm0, (%rcx)
14000b1d6:     	movq	%rax, 0x20(%rcx)
14000b1da:     	movb	$0x1, 0x28(%rcx)
14000b1de:     	movb	%r9b, 0x29(%rcx)
14000b1e2:     	movups	(%r8), %xmm0
14000b1e6:     	movups	0x10(%r8), %xmm1
14000b1eb:     	movups	0x20(%r8), %xmm2
14000b1f0:     	movups	0x30(%r8), %xmm3
14000b1f5:     	movups	%xmm0, 0x2a(%rcx)
14000b1f9:     	movups	%xmm1, 0x3a(%rcx)
14000b1fd:     	movups	%xmm2, 0x4a(%rcx)
14000b201:     	movups	%xmm3, 0x5a(%rcx)
14000b205:     	movups	0x40(%r8), %xmm0
14000b20a:     	movups	%xmm0, 0x6a(%rcx)
14000b20e:     	movups	0x50(%r8), %xmm0
14000b213:     	movups	%xmm0, 0x7a(%rcx)
14000b217:     	movups	0x60(%r8), %xmm0
14000b21c:     	movups	%xmm0, 0x8a(%rcx)
14000b223:     	movups	0x70(%r8), %xmm0
14000b228:     	movups	%xmm0, 0x9a(%rcx)
14000b22f:     	popq	%rbp
14000b230:     	retq

from pathlib import Path
import subprocess,re,json
r=Path(__file__).resolve().parent
arms={'candidate':r/'B','previous':Path('D:/CoapticCurrent/short-inline-replay-20261106/active-bytes/B'),'baseline':Path('D:/CoapticCurrent/oscore-packet-staging-20261104/option-reuse/B')}
records={}
for arm,path in arms.items():
 pdb=path/('dispatch_probe.pdb' if arm=='baseline' else 'dispatch-probe.pdb')
 p=subprocess.Popen(['llvm-pdbutil','dump','--symbols',str(pdb)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace')
 rows=[];row=None;frame=False
 for line in p.stdout:
  if 'S_GPROC32' in line or 'S_LPROC32' in line:
   if row and 'start' in row:rows.append(row)
   row={'name':line.split('`',1)[1].rsplit('`',1)[0]};frame=False
  elif row:
   m=re.search(r'addr = 0001:(\d+), code size = (\d+)',line)
   if m:row.update(start=0x140001000+int(m[1]),size=int(m[2]))
   if 'S_FRAMEPROC' in line:frame=True
   elif frame:
    m=re.search(r'size = (\d+), padding',line)
    if m:row['frame']=int(m[1]);frame=False
 if row and 'start' in row:rows.append(row)
 assert p.wait()==0;records[arm]=rows
 (r/(arm+'-procedures.json')).write_text(json.dumps(rows,indent=2)+'\n')
targets=[x for x in records['candidate'] if 'DedupEntry::write_short' in x['name']];assert len(targets)==1
target=targets[0];calls=[]
p=subprocess.Popen(['llvm-objdump','-d','--no-show-raw-insn',str(arms['candidate']/'dispatch-probe.exe')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace')
for line in p.stdout:
 if ('callq' in line or 'jmp' in line) and hex(target['start']) in line:
  address=int(line.strip().split(':')[0],16)
  owner=next(x for x in records['candidate'] if x['start']<=address<x['start']+x['size'])
  others={arm:[x for x in records[arm] if x['name']==owner['name']] for arm in ['previous','baseline']}
  calls.append({'instruction':line.strip(),'candidate':owner,**others})
assert p.wait()==0 and calls
(r/'short-writer-callers.json').write_text(json.dumps(calls,indent=2)+'\n')
for c in calls:print({a:([(x['name'],x.get('frame')) for x in v] if isinstance(v,list) else (v['name'],v.get('frame')) if isinstance(v,dict) else v) for a,v in c.items()})

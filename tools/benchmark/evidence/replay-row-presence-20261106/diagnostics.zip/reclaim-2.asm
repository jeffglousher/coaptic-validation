
D:\CoapticCurrent\replay-row-presence-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009eaf0:     	pushq	%rbp
14009eaf1:     	pushq	%r15
14009eaf3:     	pushq	%r14
14009eaf5:     	pushq	%r13
14009eaf7:     	pushq	%r12
14009eaf9:     	pushq	%rsi
14009eafa:     	pushq	%rdi
14009eafb:     	pushq	%rbx
14009eafc:     	subq	$0x218, %rsp            # imm = 0x218
14009eb03:     	leaq	0x80(%rsp), %rbp
14009eb0b:     	movaps	%xmm6, 0x180(%rbp)
14009eb12:     	leaq	0x3f10(%rcx), %rsi
14009eb19:     	leaq	0x3f38(%rcx), %r8
14009eb20:     	movl	$0x4, %r11d
14009eb26:     	xorl	%eax, %eax
14009eb28:     	movl	$0x1, %r9d
14009eb2e:     	xorl	%r10d, %r10d
14009eb31:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009eb38:     	addq	%r8, %rdi
14009eb3b:     	nopl	(%rax,%rax)
14009eb40:     	cmpb	$0x2, -0xe(%rdi)
14009eb44:     	jne	0x14009eb60 <.text+0x9db60>
14009eb46:     	incq	%r10
14009eb49:     	addq	$0x130, %rdi            # imm = 0x130
14009eb50:     	cmpq	%r10, %r11
14009eb53:     	jne	0x14009eb40 <.text+0x9db40>
14009eb55:     	jmp	0x14009eba5 <.text+0x9dba5>
14009eb57:     	nopw	(%rax,%rax)
14009eb60:     	movq	-0x8(%rdi), %r11
14009eb64:     	cmpb	$0x3, (%rdi)
14009eb67:     	setne	%bl
14009eb6a:     	testq	%r11, %r11
14009eb6d:     	sete	%dil
14009eb71:     	orb	%bl, %dil
14009eb74:     	cmpq	%r14, %r11
14009eb77:     	setae	%bl
14009eb7a:     	andb	%al, %bl
14009eb7c:     	testb	%dil, %dil
14009eb7f:     	cmoveq	%r9, %rax
14009eb83:     	orb	%dil, %bl
14009eb86:     	cmoveq	%r10, %rdx
14009eb8a:     	cmoveq	%r11, %r14
14009eb8e:     	incq	%r10
14009eb91:     	cmpq	$0x5, %r10
14009eb95:     	movl	$0x4, %r11d
14009eb9b:     	cmovaeq	%r10, %r11
14009eb9f:     	cmpq	$0x3, %r10
14009eba3:     	jbe	0x14009eb31 <.text+0x9db31>
14009eba5:     	testb	$0x1, %al
14009eba7:     	je	0x14009eca1 <.text+0x9dca1>
14009ebad:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009ebb4:     	movzbl	0x1a(%rsi,%rax), %r15d
14009ebba:     	cmpb	$0x2, %r15b
14009ebbe:     	je	0x14009eca1 <.text+0x9dca1>
14009ebc4:     	addq	%rsi, %rax
14009ebc7:     	cmpb	$0x3, 0x28(%rax)
14009ebcb:     	jne	0x14009eca1 <.text+0x9dca1>
14009ebd1:     	movq	0x30(%rax), %r8
14009ebd5:     	movq	(%rax), %rdx
14009ebd8:     	movq	%rdx, 0x168(%rbp)
14009ebdf:     	movq	0x8(%rax), %rdx
14009ebe3:     	movq	%rdx, 0x170(%rbp)
14009ebea:     	movl	0x10(%rax), %ebx
14009ebed:     	movl	0x14(%rax), %r12d
14009ebf1:     	movzwl	0x18(%rax), %edi
14009ebf5:     	movzbl	0x1b(%rax), %edx
14009ebf9:     	movb	%dl, 0x17f(%rbp)
14009ebff:     	movss	0x1c(%rax), %xmm6
14009ec04:     	movzwl	0x1c(%rax), %eax
14009ec08:     	movzwl	%ax, %edx
14009ec0b:     	cmpq	$0x1, %r8
14009ec0f:     	ja	0x14009ec6b <.text+0x9dc6b>
14009ec11:     	cmpb	$0x1, 0x3f08(%rcx,%r8)
14009ec1a:     	jne	0x14009ec6b <.text+0x9dc6b>
14009ec1c:     	cmpb	$0x0, 0x3f0a(%rcx,%r8)
14009ec25:     	jne	0x14009ec6b <.text+0x9dc6b>
14009ec27:     	movb	$0x0, 0x3f08(%rcx,%r8)
14009ec30:     	decq	0x3f00(%rcx)
14009ec37:     	leaq	0x3580(%rcx), %r9
14009ec3e:     	movq	$0x0, 0x3e80(%rcx,%r8,8)
14009ec4a:     	leaq	(%r8,%r8,8), %r10
14009ec4e:     	leaq	(%r10,%r10,2), %r10
14009ec52:     	addq	%r8, %r10
14009ec55:     	movb	$0x2, 0x95a(%r9,%r10)
14009ec5e:     	leaq	(%r8,%r8,2), %r8
14009ec62:     	movb	$0x2, 0x91d(%r9,%r8,8)
14009ec6b:     	addl	$0x2, %edx
14009ec6e:     	movb	$0x1, %r9b
14009ec71:     	cmpl	%edx, 0x43d0(%rcx)
14009ec77:     	jne	0x14009ec87 <.text+0x9dc87>
14009ec79:     	movzbl	0x3f2a(%rcx), %r8d
14009ec81:     	cmpb	$0x2, %r8b
14009ec85:     	jne	0x14009ecbe <.text+0x9dcbe>
14009ec87:     	xorl	%r8d, %r8d
14009ec8a:     	cmpl	%edx, 0x43d4(%rcx)
14009ec90:     	movl	%ebx, 0x178(%rbp)
14009ec96:     	jne	0x14009ed4d <.text+0x9dd4d>
14009ec9c:     	jmp	0x14009ed3b <.text+0x9dd3b>
14009eca1:     	xorl	%eax, %eax
14009eca3:     	movaps	0x180(%rbp), %xmm6
14009ecaa:     	addq	$0x218, %rsp            # imm = 0x218
14009ecb1:     	popq	%rbx
14009ecb2:     	popq	%rdi
14009ecb3:     	popq	%rsi
14009ecb4:     	popq	%r12
14009ecb6:     	popq	%r13
14009ecb8:     	popq	%r14
14009ecba:     	popq	%r15
14009ecbc:     	popq	%rbp
14009ecbd:     	retq
14009ecbe:     	cmpw	%ax, 0x3f2c(%rcx)
14009ecc5:     	sete	%r9b
14009ecc9:     	cmpl	%ebx, 0x3f20(%rcx)
14009eccf:     	sete	%r10b
14009ecd3:     	andb	%r9b, %r10b
14009ecd6:     	cmpl	%r12d, 0x3f24(%rcx)
14009ecdd:     	sete	%r9b
14009ece1:     	cmpw	%di, 0x3f28(%rcx)
14009ece8:     	sete	%r11b
14009ecec:     	andb	%r9b, %r11b
14009ecef:     	andb	%r10b, %r11b
14009ecf2:     	cmpb	%r15b, %r8b
14009ecf5:     	sete	%r8b
14009ecf9:     	movq	0x3f18(%rcx), %r9
14009ed00:     	xorq	0x170(%rbp), %r9
14009ed07:     	movq	0x3f10(%rcx), %r10
14009ed0e:     	xorq	0x168(%rbp), %r10
14009ed15:     	orq	%r9, %r10
14009ed18:     	sete	%r9b
14009ed1c:     	andb	%r8b, %r9b
14009ed1f:     	andb	%r11b, %r9b
14009ed22:     	movzbl	%r9b, %r8d
14009ed26:     	movl	%r8d, %r9d
14009ed29:     	xorb	$0x1, %r9b
14009ed2d:     	cmpl	%edx, 0x43d4(%rcx)
14009ed33:     	movl	%ebx, 0x178(%rbp)
14009ed39:     	jne	0x14009ed4d <.text+0x9dd4d>
14009ed3b:     	movzbl	0x405a(%rcx), %r10d
14009ed43:     	cmpb	$0x2, %r10b
14009ed47:     	jne	0x14009edfe <.text+0x9ddfe>
14009ed4d:     	xorl	%r9d, %r9d
14009ed50:     	cmpl	%edx, 0x43d8(%rcx)
14009ed56:     	jne	0x14009eea4 <.text+0x9dea4>
14009ed5c:     	movzbl	0x418a(%rcx), %r10d
14009ed64:     	cmpb	$0x2, %r10b
14009ed68:     	je	0x14009eea4 <.text+0x9dea4>
14009ed6e:     	cmpb	%r15b, %r10b
14009ed71:     	jne	0x14009eea4 <.text+0x9dea4>
14009ed77:     	cmpw	%ax, 0x418c(%rcx)
14009ed7e:     	jne	0x14009eea4 <.text+0x9dea4>
14009ed84:     	cmpl	%ebx, 0x4180(%rcx)
14009ed8a:     	jne	0x14009eea4 <.text+0x9dea4>
14009ed90:     	cmpl	%r12d, 0x4184(%rcx)
14009ed97:     	jne	0x14009eea4 <.text+0x9dea4>
14009ed9d:     	cmpw	%di, 0x4188(%rcx)
14009eda4:     	jne	0x14009eea4 <.text+0x9dea4>
14009edaa:     	movq	0x4170(%rcx), %r10
14009edb1:     	xorq	0x168(%rbp), %r10
14009edb8:     	movq	0x4178(%rcx), %r11
14009edbf:     	xorq	0x170(%rbp), %r11
14009edc6:     	orq	%r10, %r11
14009edc9:     	jne	0x14009eea4 <.text+0x9dea4>
14009edcf:     	movl	%r12d, %r13d
14009edd2:     	movl	%edi, %r12d
14009edd5:     	movb	$0x1, %dil
14009edd8:     	testq	%r8, %r8
14009eddb:     	jne	0x14009ef30 <.text+0x9df30>
14009ede1:     	movl	$0x1, %r8d
14009ede7:     	movl	$0x2, %r9d
14009eded:     	movl	%r12d, %edi
14009edf0:     	movl	%r13d, %r12d
14009edf3:     	movl	0x178(%rbp), %ebx
14009edf9:     	jmp	0x14009eea4 <.text+0x9dea4>
14009edfe:     	cmpw	%ax, 0x405c(%rcx)
14009ee05:     	setne	%r11b
14009ee09:     	cmpl	%ebx, 0x4050(%rcx)
14009ee0f:     	setne	%bl
14009ee12:     	orb	%r11b, %bl
14009ee15:     	movl	%r12d, %r13d
14009ee18:     	cmpl	%r12d, 0x4054(%rcx)
14009ee1f:     	setne	%r11b
14009ee23:     	movl	%edi, %r12d
14009ee26:     	cmpw	%di, 0x4058(%rcx)
14009ee2d:     	setne	%dil
14009ee31:     	orb	%r11b, %dil
14009ee34:     	orb	%bl, %dil
14009ee37:     	cmpb	%r15b, %r10b
14009ee3a:     	setne	%r11b
14009ee3e:     	movq	0x4048(%rcx), %r10
14009ee45:     	xorq	0x170(%rbp), %r10
14009ee4c:     	movq	0x4040(%rcx), %rbx
14009ee53:     	xorq	0x168(%rbp), %rbx
14009ee5a:     	orq	%r10, %rbx
14009ee5d:     	setne	%r10b
14009ee61:     	orb	%r11b, %r10b
14009ee64:     	orb	%dil, %r10b
14009ee67:     	orb	%r10b, %r9b
14009ee6a:     	testb	%r10b, %r10b
14009ee6d:     	movl	$0x1, %r11d
14009ee73:     	cmoveq	%r11, %r8
14009ee77:     	testb	$0x1, %r9b
14009ee7b:     	je	0x14009ef2a <.text+0x9df2a>
14009ee81:     	notb	%r10b
14009ee84:     	movzbl	%r10b, %r9d
14009ee88:     	andl	$0x1, %r9d
14009ee8c:     	movl	%r12d, %edi
14009ee8f:     	movl	%r13d, %r12d
14009ee92:     	movl	0x178(%rbp), %ebx
14009ee98:     	cmpl	%edx, 0x43d8(%rcx)
14009ee9e:     	je	0x14009ed5c <.text+0x9dd5c>
14009eea4:     	cmpl	%edx, 0x43dc(%rcx)
14009eeaa:     	jne	0x14009eeb8 <.text+0x9deb8>
14009eeac:     	movzbl	0x42ba(%rcx), %edx
14009eeb3:     	cmpb	$0x2, %dl
14009eeb6:     	jne	0x14009eeca <.text+0x9deca>
14009eeb8:     	movl	%r12d, %r13d
14009eebb:     	movl	%edi, %r12d
14009eebe:     	xorl	%edi, %edi
14009eec0:     	testq	%r8, %r8
14009eec3:     	jne	0x14009ef30 <.text+0x9df30>
14009eec5:     	jmp	0x14009ef5a <.text+0x9df5a>
14009eeca:     	cmpb	%r15b, %dl
14009eecd:     	jne	0x14009eeb8 <.text+0x9deb8>
14009eecf:     	cmpw	%ax, 0x42bc(%rcx)
14009eed6:     	jne	0x14009eeb8 <.text+0x9deb8>
14009eed8:     	cmpl	%ebx, 0x42b0(%rcx)
14009eede:     	jne	0x14009eeb8 <.text+0x9deb8>
14009eee0:     	cmpl	%r12d, 0x42b4(%rcx)
14009eee7:     	jne	0x14009eeb8 <.text+0x9deb8>
14009eee9:     	cmpw	%di, 0x42b8(%rcx)
14009eef0:     	jne	0x14009eeb8 <.text+0x9deb8>
14009eef2:     	movq	0x42a0(%rcx), %rdx
14009eef9:     	xorq	0x168(%rbp), %rdx
14009ef00:     	movq	0x42a8(%rcx), %r10
14009ef07:     	xorq	0x170(%rbp), %r10
14009ef0e:     	orq	%rdx, %r10
14009ef11:     	jne	0x14009eeb8 <.text+0x9deb8>
14009ef13:     	movl	%r12d, %r13d
14009ef16:     	movl	%edi, %r12d
14009ef19:     	testq	%r8, %r8
14009ef1c:     	movl	$0x3, %edx
14009ef21:     	cmoveq	%rdx, %r9
14009ef25:     	movl	%r8d, %edi
14009ef28:     	jmp	0x14009ef30 <.text+0x9df30>
14009ef2a:     	movb	$0x1, %dil
14009ef2d:     	xorl	%r9d, %r9d
14009ef30:     	cmpl	$0x0, 0x43d0(%rcx,%r9,4)
14009ef39:     	je	0x14009ef5a <.text+0x9df5a>
14009ef3b:     	movl	$0x0, 0x43d0(%rcx,%r9,4)
14009ef47:     	decq	0x43e8(%rcx)
14009ef4e:     	imulq	$0x130, %r9, %rdx       # imm = 0x130
14009ef55:     	movb	$0x2, 0x1a(%rsi,%rdx)
14009ef5a:     	xorps	%xmm0, %xmm0
14009ef5d:     	movaps	%xmm0, 0x150(%rbp)
14009ef64:     	movb	$0x0, 0x132(%rbp)
14009ef6b:     	movw	%ax, 0x130(%rbp)
14009ef72:     	leaq	0x133(%rbp), %rdx
14009ef79:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009ef82:     	movq	$0x0, 0x133(%rbp)
14009ef8d:     	movq	$0x8, 0x110(%rbp)
14009ef98:     	movq	$0x0, 0x118(%rbp)
14009efa3:     	movq	$0x1, 0x120(%rbp)
14009efae:     	movq	$0x0, 0x128(%rbp)
14009efb9:     	movq	%rdx, 0x30(%rsp)
14009efbe:     	movw	%ax, 0x28(%rsp)
14009efc3:     	movq	$0x0, 0x58(%rsp)
14009efcc:     	movq	$0x1, 0x50(%rsp)
14009efd5:     	movq	$0x8, 0x48(%rsp)
14009efde:     	movq	$0x8, 0x40(%rsp)
14009efe7:     	movq	$0x0, 0x38(%rsp)
14009eff0:     	movb	$0x0, 0x20(%rsp)
14009eff5:     	leaq	0x140(%rbp), %rax
14009effc:     	leaq	0x150(%rbp), %rdx
14009f003:     	movl	$0x10, %r8d
14009f009:     	movq	%rcx, %rbx
14009f00c:     	movq	%rax, %rcx
14009f00f:     	movb	$0x2, %r9b
14009f012:     	callq	0x140005590 <.text+0x4590>
14009f017:     	cmpb	$0x0, 0x140(%rbp)
14009f01e:     	jne	0x14009f03f <.text+0x9e03f>
14009f020:     	testb	%dil, %dil
14009f023:     	jne	0x14009f03f <.text+0x9e03f>
14009f025:     	movq	%rbx, %rax
14009f028:     	movq	0x148(%rbp), %rbx
14009f02f:     	cmpq	$0x10, %rbx
14009f033:     	ja	0x14009f03f <.text+0x9e03f>
14009f035:     	cmpq	$0x4, 0x43e8(%rax)
14009f03d:     	jne	0x14009f046 <.text+0x9e046>
14009f03f:     	movb	$0x1, %al
14009f041:     	jmp	0x14009eca3 <.text+0x9dca3>
14009f046:     	movq	0x43e0(%rax), %rdi
14009f04d:     	cmpq	$0x3, %rdi
14009f051:     	ja	0x14009f24d <.text+0x9e24d>
14009f057:     	cmpl	$0x0, 0x43d0(%rax,%rdi,4)
14009f05f:     	je	0x14009f0d2 <.text+0x9e0d2>
14009f061:     	leaq	(,%rdi,4), %rdx
14009f069:     	xorl	%ecx, %ecx
14009f06b:     	nopl	(%rax,%rax)
14009f070:     	cmpl	$0x0, 0x43d0(%rax,%rdx)
14009f078:     	je	0x14009f0c5 <.text+0x9e0c5>
14009f07a:     	addq	$0x4, %rdx
14009f07e:     	decq	%rcx
14009f081:     	cmpq	$0x10, %rdx
14009f085:     	jne	0x14009f070 <.text+0x9e070>
14009f087:     	testq	%rdi, %rdi
14009f08a:     	je	0x14009f03f <.text+0x9e03f>
14009f08c:     	cmpl	$0x0, 0x43d0(%rax)
14009f093:     	je	0x14009f23c <.text+0x9e23c>
14009f099:     	cmpq	$0x1, %rdi
14009f09d:     	je	0x14009f03f <.text+0x9e03f>
14009f09f:     	cmpl	$0x0, 0x43d4(%rax)
14009f0a6:     	je	0x14009f243 <.text+0x9e243>
14009f0ac:     	cmpq	$0x2, %rdi
14009f0b0:     	je	0x14009f03f <.text+0x9e03f>
14009f0b2:     	movl	$0x2, %edi
14009f0b7:     	cmpl	$0x0, 0x43d8(%rax)
14009f0be:     	je	0x14009f0c8 <.text+0x9e0c8>
14009f0c0:     	jmp	0x14009f03f <.text+0x9e03f>
14009f0c5:     	subq	%rcx, %rdi
14009f0c8:     	cmpq	$0x4, %rdi
14009f0cc:     	jae	0x14009f263 <.text+0x9e263>
14009f0d2:     	movl	$0x1, 0x43d0(%rax,%rdi,4)
14009f0dd:     	incq	0x43e8(%rax)
14009f0e4:     	leaq	0x1(%rdi), %rcx
14009f0e8:     	xorl	%edx, %edx
14009f0ea:     	cmpq	$0x4, %rcx
14009f0ee:     	cmovneq	%rcx, %rdx
14009f0f2:     	movq	%rdx, 0x43e0(%rax)
14009f0f9:     	movq	0x170(%rbp), %rcx
14009f100:     	movq	%rcx, -0x18(%rbp)
14009f104:     	movq	0x168(%rbp), %rcx
14009f10b:     	movq	%rcx, -0x20(%rbp)
14009f10f:     	movl	0x178(%rbp), %ecx
14009f115:     	movl	%ecx, -0x10(%rbp)
14009f118:     	movl	%r13d, -0xc(%rbp)
14009f11c:     	movw	%r12w, -0x8(%rbp)
14009f121:     	movb	%r15b, -0x6(%rbp)
14009f125:     	movzbl	0x17f(%rbp), %ecx
14009f12c:     	movb	%cl, -0x5(%rbp)
14009f12f:     	movss	%xmm6, -0x4(%rbp)
14009f134:     	movq	%r14, (%rbp)
14009f138:     	testq	%rbx, %rbx
14009f13b:     	je	0x14009f1a2 <.text+0x9e1a2>
14009f13d:     	movb	$0x1, 0x8(%rbp)
14009f141:     	movb	%bl, 0x9(%rbp)
14009f144:     	leaq	0xa(%rbp), %r14
14009f148:     	movl	$0x80, %r8d
14009f14e:     	subq	%rbx, %r8
14009f151:     	leaq	(%rbx,%rbp), %rcx
14009f155:     	addq	$0xa, %rcx
14009f159:     	movq	%rax, %r15
14009f15c:     	xorl	%edx, %edx
14009f15e:     	callq	0x1402515b2 <.text+0x2505b2>
14009f163:     	leaq	0x150(%rbp), %rdx
14009f16a:     	movq	%r14, %rcx
14009f16d:     	movq	%rbx, %r8
14009f170:     	callq	0x1402515a0 <.text+0x2505a0>
14009f175:     	movzwl	-0x4(%rbp), %eax
14009f179:     	addl	$0x2, %eax
14009f17c:     	movl	%eax, 0x43d0(%r15,%rdi,4)
14009f184:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009f18b:     	addq	%rax, %rsi
14009f18e:     	movzbl	0x8(%rbp), %eax
14009f192:     	leaq	0x1d10a7(%rip), %rcx    # 0x140270240
14009f199:     	movslq	(%rcx,%rax,4), %rax
14009f19d:     	addq	%rcx, %rax
14009f1a0:     	jmpq	*%rax
14009f1a2:     	movb	$0x0, 0x8(%rbp)
14009f1a6:     	movzwl	-0x4(%rbp), %ecx
14009f1aa:     	addl	$0x2, %ecx
14009f1ad:     	movl	%ecx, 0x43d0(%rax,%rdi,4)
14009f1b4:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009f1bb:     	addq	%rax, %rsi
14009f1be:     	movzbl	0x8(%rbp), %eax
14009f1c2:     	leaq	0x1d1077(%rip), %rcx    # 0x140270240
14009f1c9:     	movslq	(%rcx,%rax,4), %rax
14009f1cd:     	addq	%rcx, %rax
14009f1d0:     	jmpq	*%rax
14009f1d2:     	movaps	-0x20(%rbp), %xmm0
14009f1d6:     	movaps	-0x10(%rbp), %xmm1
14009f1da:     	movups	%xmm1, 0x10(%rsi)
14009f1de:     	movups	%xmm0, (%rsi)
14009f1e1:     	movb	$0x0, 0x28(%rsi)
14009f1e5:     	movq	(%rbp), %rax
14009f1e9:     	movq	%rax, 0x20(%rsi)
14009f1ed:     	jmp	0x14009f03f <.text+0x9e03f>
14009f1f2:     	leaq	-0x20(%rbp), %rdx
14009f1f6:     	movl	$0x130, %r8d            # imm = 0x130
14009f1fc:     	movq	%rsi, %rcx
14009f1ff:     	callq	0x1402515a0 <.text+0x2505a0>
14009f204:     	jmp	0x14009f03f <.text+0x9e03f>
14009f209:     	movq	(%rbp), %r8
14009f20d:     	movq	0x10(%rbp), %r9
14009f211:     	leaq	-0x20(%rbp), %rdx
14009f215:     	movq	%rsi, %rcx
14009f218:     	callq	0x14000b2d0 <.text+0xa2d0>
14009f21d:     	jmp	0x14009f03f <.text+0x9e03f>
14009f222:     	leaq	0xa(%rbp), %r8
14009f226:     	movzbl	0x9(%rbp), %r9d
14009f22b:     	leaq	-0x20(%rbp), %rdx
14009f22f:     	movq	%rsi, %rcx
14009f232:     	callq	0x14000b1c0 <.text+0xa1c0>
14009f237:     	jmp	0x14009f03f <.text+0x9e03f>
14009f23c:     	xorl	%edi, %edi
14009f23e:     	jmp	0x14009f0c8 <.text+0x9e0c8>
14009f243:     	movl	$0x1, %edi
14009f248:     	jmp	0x14009f0c8 <.text+0x9e0c8>
14009f24d:     	leaq	0x1cdb4c(%rip), %r8     # 0x14026cda0
14009f254:     	movl	$0x4, %edx
14009f259:     	movq	%rdi, %rcx
14009f25c:     	callq	0x140251e23 <.text+0x250e23>
14009f261:     	ud2
14009f263:     	leaq	0x1cdb4e(%rip), %r8     # 0x14026cdb8
14009f26a:     	movl	$0x4, %edx
14009f26f:     	movq	%rdi, %rcx
14009f272:     	callq	0x140251e23 <.text+0x250e23>
14009f277:     	ud2

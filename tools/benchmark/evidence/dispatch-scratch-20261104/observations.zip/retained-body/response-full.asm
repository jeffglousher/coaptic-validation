﻿
D:/CoapticCurrent/dispatch-memory-20261104/body-borrow/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14008a860: 55                          	pushq	%rbp
14008a861: 41 57                       	pushq	%r15
14008a863: 41 56                       	pushq	%r14
14008a865: 41 55                       	pushq	%r13
14008a867: 41 54                       	pushq	%r12
14008a869: 56                          	pushq	%rsi
14008a86a: 57                          	pushq	%rdi
14008a86b: 53                          	pushq	%rbx
14008a86c: 48 81 ec a8 05 00 00        	subq	$0x5a8, %rsp            # imm = 0x5A8
14008a873: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
14008a87b: 48 89 ce                    	movq	%rcx, %rsi
14008a87e: 4c 8b bd a8 05 00 00        	movq	0x5a8(%rbp), %r15
14008a885: 41 0f b6 87 54 02 00 00     	movzbl	0x254(%r15), %eax
14008a88d: 3c ff                       	cmpb	$-0x1, %al
14008a88f: 75 27                       	jne	0x14008a8b8 <.text+0x898b8>
14008a891: 48 89 d3                    	movq	%rdx, %rbx
14008a894: 41 0f b7 47 20              	movzwl	0x20(%r15), %eax
14008a899: 48 8d 0d 40 da 1d 00        	leaq	0x1dda40(%rip), %rcx    # 0x1402682e0
14008a8a0: 48 63 14 81                 	movslq	(%rcx,%rax,4), %rdx
14008a8a4: 48 01 ca                    	addq	%rcx, %rdx
14008a8a7: ff e2                       	jmpq	*%rdx
14008a8a9: 49 8b 47 30                 	movq	0x30(%r15), %rax
14008a8ad: 49 39 87 f0 01 00 00        	cmpq	%rax, 0x1f0(%r15)
14008a8b4: 76 2a                       	jbe	0x14008a8e0 <.text+0x898e0>
14008a8b6: 31 c0                       	xorl	%eax, %eax
14008a8b8: c6 06 03                    	movb	$0x3, (%rsi)
14008a8bb: 88 46 01                    	movb	%al, 0x1(%rsi)
14008a8be: 48 81 c4 a8 05 00 00        	addq	$0x5a8, %rsp            # imm = 0x5A8
14008a8c5: 5b                          	popq	%rbx
14008a8c6: 5f                          	popq	%rdi
14008a8c7: 5e                          	popq	%rsi
14008a8c8: 41 5c                       	popq	%r12
14008a8ca: 41 5d                       	popq	%r13
14008a8cc: 41 5e                       	popq	%r14
14008a8ce: 41 5f                       	popq	%r15
14008a8d0: 5d                          	popq	%rbp
14008a8d1: c3                          	retq
14008a8d2: 41 0f b7 47 22              	movzwl	0x22(%r15), %eax
14008a8d7: 49 39 87 f0 01 00 00        	cmpq	%rax, 0x1f0(%r15)
14008a8de: 77 d6                       	ja	0x14008a8b6 <.text+0x898b6>
14008a8e0: 66 41 83 bf f8 01 00 00 01  	cmpw	$0x1, 0x1f8(%r15)
14008a8e9: 75 29                       	jne	0x14008a914 <.text+0x89914>
14008a8eb: 41 0f b7 87 fa 01 00 00     	movzwl	0x1fa(%r15), %eax
14008a8f3: 89 c1                       	movl	%eax, %ecx
14008a8f5: 0f c9                       	bswapl	%ecx
14008a8f7: 89 4d 10                    	movl	%ecx, 0x10(%rbp)
14008a8fa: f7 c1 00 00 ff 00           	testl	$0xff0000, %ecx         # imm = 0xFF0000
14008a900: 74 3d                       	je	0x14008a93f <.text+0x8993f>
14008a902: 4d 89 c6                    	movq	%r8, %r14
14008a905: 4c 89 cf                    	movq	%r9, %rdi
14008a908: 48 8d 55 12                 	leaq	0x12(%rbp), %rdx
14008a90c: 41 bc 02 00 00 00           	movl	$0x2, %r12d
14008a912: eb 44                       	jmp	0x14008a958 <.text+0x89958>
14008a914: 45 31 e4                    	xorl	%r12d, %r12d
14008a917: 31 c0                       	xorl	%eax, %eax
14008a919: 48 89 85 20 05 00 00        	movq	%rax, 0x520(%rbp)
14008a920: 88 85 0e 05 00 00           	movb	%al, 0x50e(%rbp)
14008a926: 41 83 7f 10 01              	cmpl	$0x1, 0x10(%r15)
14008a92b: 74 73                       	je	0x14008a9a0 <.text+0x899a0>
14008a92d: 48 c7 85 d0 04 00 00 00 00 00 00    	movq	$0x0, 0x4d0(%rbp)
14008a938: 31 c0                       	xorl	%eax, %eax
14008a93a: e9 10 01 00 00              	jmp	0x14008aa4f <.text+0x89a4f>
14008a93f: 66 85 c0                    	testw	%ax, %ax
14008a942: 0f 84 93 00 00 00           	je	0x14008a9db <.text+0x899db>
14008a948: 4d 89 c6                    	movq	%r8, %r14
14008a94b: 4c 89 cf                    	movq	%r9, %rdi
14008a94e: 48 8d 55 13                 	leaq	0x13(%rbp), %rdx
14008a952: 41 bc 01 00 00 00           	movl	$0x1, %r12d
14008a958: c7 85 78 02 00 00 00 00 00 00       	movl	$0x0, 0x278(%rbp)
14008a962: 48 8d 8d 78 02 00 00        	leaq	0x278(%rbp), %rcx
14008a969: 4d 89 e0                    	movq	%r12, %r8
14008a96c: e8 6f 84 1c 00              	callq	0x140252de0 <.text+0x251de0>
14008a971: 8b 85 78 02 00 00           	movl	0x278(%rbp), %eax
14008a977: 49 89 f9                    	movq	%rdi, %r9
14008a97a: 4d 89 f0                    	movq	%r14, %r8
14008a97d: 89 85 0f 05 00 00           	movl	%eax, 0x50f(%rbp)
14008a983: 44 88 a5 13 05 00 00        	movb	%r12b, 0x513(%rbp)
14008a98a: b0 01                       	movb	$0x1, %al
14008a98c: 48 89 85 20 05 00 00        	movq	%rax, 0x520(%rbp)
14008a993: 88 85 0e 05 00 00           	movb	%al, 0x50e(%rbp)
14008a999: 41 83 7f 10 01              	cmpl	$0x1, 0x10(%r15)
14008a99e: 75 8d                       	jne	0x14008a92d <.text+0x8992d>
14008a9a0: 41 8b 47 14                 	movl	0x14(%r15), %eax
14008a9a4: 89 c1                       	movl	%eax, %ecx
14008a9a6: 0f c9                       	bswapl	%ecx
14008a9a8: 89 4d 10                    	movl	%ecx, 0x10(%rbp)
14008a9ab: 84 c9                       	testb	%cl, %cl
14008a9ad: 74 12                       	je	0x14008a9c1 <.text+0x899c1>
14008a9af: 4d 89 c6                    	movq	%r8, %r14
14008a9b2: 4c 89 cf                    	movq	%r9, %rdi
14008a9b5: 41 bd 04 00 00 00           	movl	$0x4, %r13d
14008a9bb: 48 8d 55 10                 	leaq	0x10(%rbp), %rdx
14008a9bf: eb 53                       	jmp	0x14008aa14 <.text+0x89a14>
14008a9c1: f7 c1 00 ff 00 00           	testl	$0xff00, %ecx           # imm = 0xFF00
14008a9c7: 74 19                       	je	0x14008a9e2 <.text+0x899e2>
14008a9c9: 4d 89 c6                    	movq	%r8, %r14
14008a9cc: 4c 89 cf                    	movq	%r9, %rdi
14008a9cf: 48 8d 55 11                 	leaq	0x11(%rbp), %rdx
14008a9d3: 41 bd 03 00 00 00           	movl	$0x3, %r13d
14008a9d9: eb 39                       	jmp	0x14008aa14 <.text+0x89a14>
14008a9db: 45 31 e4                    	xorl	%r12d, %r12d
14008a9de: 31 c0                       	xorl	%eax, %eax
14008a9e0: eb 9b                       	jmp	0x14008a97d <.text+0x8997d>
14008a9e2: f7 c1 00 00 ff 00           	testl	$0xff0000, %ecx         # imm = 0xFF0000
14008a9e8: 74 12                       	je	0x14008a9fc <.text+0x899fc>
14008a9ea: 4d 89 c6                    	movq	%r8, %r14
14008a9ed: 4c 89 cf                    	movq	%r9, %rdi
14008a9f0: 48 8d 55 12                 	leaq	0x12(%rbp), %rdx
14008a9f4: 41 bd 02 00 00 00           	movl	$0x2, %r13d
14008a9fa: eb 18                       	jmp	0x14008aa14 <.text+0x89a14>
14008a9fc: 85 c0                       	testl	%eax, %eax
14008a9fe: 0f 84 00 12 00 00           	je	0x14008bc04 <.text+0x8ac04>
14008aa04: 4d 89 c6                    	movq	%r8, %r14
14008aa07: 4c 89 cf                    	movq	%r9, %rdi
14008aa0a: 48 8d 55 13                 	leaq	0x13(%rbp), %rdx
14008aa0e: 41 bd 01 00 00 00           	movl	$0x1, %r13d
14008aa14: c7 85 78 02 00 00 00 00 00 00       	movl	$0x0, 0x278(%rbp)
14008aa1e: 48 8d 8d 78 02 00 00        	leaq	0x278(%rbp), %rcx
14008aa25: 4d 89 e8                    	movq	%r13, %r8
14008aa28: e8 b3 83 1c 00              	callq	0x140252de0 <.text+0x251de0>
14008aa2d: 8b 85 78 02 00 00           	movl	0x278(%rbp), %eax
14008aa33: 49 89 f9                    	movq	%rdi, %r9
14008aa36: 4d 89 f0                    	movq	%r14, %r8
14008aa39: 89 85 09 05 00 00           	movl	%eax, 0x509(%rbp)
14008aa3f: 4c 89 ad d0 04 00 00        	movq	%r13, 0x4d0(%rbp)
14008aa46: 44 88 ad 0d 05 00 00        	movb	%r13b, 0x50d(%rbp)
14008aa4d: b0 01                       	movb	$0x1, %al
14008aa4f: 4c 8b ad b8 05 00 00        	movq	0x5b8(%rbp), %r13
14008aa56: 48 89 85 c0 04 00 00        	movq	%rax, 0x4c0(%rbp)
14008aa5d: 88 85 08 05 00 00           	movb	%al, 0x508(%rbp)
14008aa63: 41 8b 47 18                 	movl	0x18(%r15), %eax
14008aa67: 89 85 dc 04 00 00           	movl	%eax, 0x4dc(%rbp)
14008aa6d: 83 f8 01                    	cmpl	$0x1, %eax
14008aa70: 4c 89 8d f0 04 00 00        	movq	%r9, 0x4f0(%rbp)
14008aa77: 4c 89 85 e0 04 00 00        	movq	%r8, 0x4e0(%rbp)
14008aa7e: 4c 89 a5 50 02 00 00        	movq	%r12, 0x250(%rbp)
14008aa85: 75 21                       	jne	0x14008aaa8 <.text+0x89aa8>
14008aa87: b8 ff ff ff 00              	movl	$0xffffff, %eax         # imm = 0xFFFFFF
14008aa8c: 41 23 47 1c                 	andl	0x1c(%r15), %eax
14008aa90: 89 c1                       	movl	%eax, %ecx
14008aa92: 0f c9                       	bswapl	%ecx
14008aa94: 89 4d 10                    	movl	%ecx, 0x10(%rbp)
14008aa97: 66 85 c9                    	testw	%cx, %cx
14008aa9a: 74 13                       	je	0x14008aaaf <.text+0x89aaf>
14008aa9c: 48 8d 55 11                 	leaq	0x11(%rbp), %rdx
14008aaa0: 41 bc 03 00 00 00           	movl	$0x3, %r12d
14008aaa6: eb 2d                       	jmp	0x14008aad5 <.text+0x89ad5>
14008aaa8: 45 31 e4                    	xorl	%r12d, %r12d
14008aaab: 31 ff                       	xorl	%edi, %edi
14008aaad: eb 55                       	jmp	0x14008ab04 <.text+0x89b04>
14008aaaf: f7 c1 00 00 ff 00           	testl	$0xff0000, %ecx         # imm = 0xFF0000
14008aab5: 74 0c                       	je	0x14008aac3 <.text+0x89ac3>
14008aab7: 48 8d 55 12                 	leaq	0x12(%rbp), %rdx
14008aabb: 41 bc 02 00 00 00           	movl	$0x2, %r12d
14008aac1: eb 12                       	jmp	0x14008aad5 <.text+0x89ad5>
14008aac3: 85 c0                       	testl	%eax, %eax
14008aac5: 0f 84 c4 00 00 00           	je	0x14008ab8f <.text+0x89b8f>
14008aacb: 48 8d 55 13                 	leaq	0x13(%rbp), %rdx
14008aacf: 41 bc 01 00 00 00           	movl	$0x1, %r12d
14008aad5: c7 85 78 02 00 00 00 00 00 00       	movl	$0x0, 0x278(%rbp)
14008aadf: 48 8d 8d 78 02 00 00        	leaq	0x278(%rbp), %rcx
14008aae6: 4d 89 e0                    	movq	%r12, %r8
14008aae9: e8 f2 82 1c 00              	callq	0x140252de0 <.text+0x251de0>
14008aaee: 8b 85 78 02 00 00           	movl	0x278(%rbp), %eax
14008aaf4: 89 85 1b 05 00 00           	movl	%eax, 0x51b(%rbp)
14008aafa: 44 88 a5 1f 05 00 00        	movb	%r12b, 0x51f(%rbp)
14008ab01: 40 b7 01                    	movb	$0x1, %dil
14008ab04: 4c 8b 85 c0 05 00 00        	movq	0x5c0(%rbp), %r8
14008ab0b: 40 88 bd 1a 05 00 00        	movb	%dil, 0x51a(%rbp)
14008ab12: 49 8b 4d 00                 	movq	(%r13), %rcx
14008ab16: 48 89 8d e8 04 00 00        	movq	%rcx, 0x4e8(%rbp)
14008ab1d: 48 83 f9 02                 	cmpq	$0x2, %rcx
14008ab21: 74 35                       	je	0x14008ab58 <.text+0x89b58>
14008ab23: 49 8b 4d 10                 	movq	0x10(%r13), %rcx
14008ab27: 48 89 c8                    	movq	%rcx, %rax
14008ab2a: 48 c1 e8 20                 	shrq	$0x20, %rax
14008ab2e: 89 ca                       	movl	%ecx, %edx
14008ab30: c1 e2 04                    	shll	$0x4, %edx
14008ab33: 48 c1 e9 25                 	shrq	$0x25, %rcx
14008ab37: 83 e1 08                    	andl	$0x8, %ecx
14008ab3a: 09 d1                       	orl	%edx, %ecx
14008ab3c: 0f b6 c0                    	movzbl	%al, %eax
14008ab3f: 09 c8                       	orl	%ecx, %eax
14008ab41: 89 c1                       	movl	%eax, %ecx
14008ab43: 0f c9                       	bswapl	%ecx
14008ab45: 89 4d 10                    	movl	%ecx, 0x10(%rbp)
14008ab48: 84 c9                       	testb	%cl, %cl
14008ab4a: 74 1b                       	je	0x14008ab67 <.text+0x89b67>
14008ab4c: 41 be 04 00 00 00           	movl	$0x4, %r14d
14008ab52: 48 8d 55 10                 	leaq	0x10(%rbp), %rdx
14008ab56: eb 53                       	jmp	0x14008abab <.text+0x89bab>
14008ab58: c6 85 14 05 00 00 00        	movb	$0x0, 0x514(%rbp)
14008ab5f: 45 31 f6                    	xorl	%r14d, %r14d
14008ab62: e9 ac 00 00 00              	jmp	0x14008ac13 <.text+0x89c13>
14008ab67: f7 c1 00 ff 00 00           	testl	$0xff00, %ecx           # imm = 0xFF00
14008ab6d: 74 0c                       	je	0x14008ab7b <.text+0x89b7b>
14008ab6f: 48 8d 55 11                 	leaq	0x11(%rbp), %rdx
14008ab73: 41 be 03 00 00 00           	movl	$0x3, %r14d
14008ab79: eb 30                       	jmp	0x14008abab <.text+0x89bab>
14008ab7b: f7 c1 00 00 ff 00           	testl	$0xff0000, %ecx         # imm = 0xFF0000
14008ab81: 74 16                       	je	0x14008ab99 <.text+0x89b99>
14008ab83: 48 8d 55 12                 	leaq	0x12(%rbp), %rdx
14008ab87: 41 be 02 00 00 00           	movl	$0x2, %r14d
14008ab8d: eb 1c                       	jmp	0x14008abab <.text+0x89bab>
14008ab8f: 45 31 e4                    	xorl	%r12d, %r12d
14008ab92: 31 c0                       	xorl	%eax, %eax
14008ab94: e9 5b ff ff ff              	jmp	0x14008aaf4 <.text+0x89af4>
14008ab99: 85 c0                       	testl	%eax, %eax
14008ab9b: 0f 84 6d 10 00 00           	je	0x14008bc0e <.text+0x8ac0e>
14008aba1: 48 8d 55 13                 	leaq	0x13(%rbp), %rdx
14008aba5: 41 be 01 00 00 00           	movl	$0x1, %r14d
14008abab: c7 85 78 02 00 00 00 00 00 00       	movl	$0x0, 0x278(%rbp)
14008abb5: 48 8d 8d 78 02 00 00        	leaq	0x278(%rbp), %rcx
14008abbc: 4d 89 f0                    	movq	%r14, %r8
14008abbf: e8 1c 82 1c 00              	callq	0x140252de0 <.text+0x251de0>
14008abc4: 8b 85 78 02 00 00           	movl	0x278(%rbp), %eax
14008abca: 4c 8b 85 c0 05 00 00        	movq	0x5c0(%rbp), %r8
14008abd1: 89 85 15 05 00 00           	movl	%eax, 0x515(%rbp)
14008abd7: 44 88 b5 19 05 00 00        	movb	%r14b, 0x519(%rbp)
14008abde: c6 85 14 05 00 00 01        	movb	$0x1, 0x514(%rbp)
14008abe5: f6 85 e8 04 00 00 01        	testb	$0x1, 0x4e8(%rbp)
14008abec: 74 25                       	je	0x14008ac13 <.text+0x89c13>
14008abee: 49 8b 45 08                 	movq	0x8(%r13), %rax
14008abf2: b9 ff ff ff ff              	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
14008abf7: 48 39 c8                    	cmpq	%rcx, %rax
14008abfa: 48 0f 42 c8                 	cmovbq	%rax, %rcx
14008abfe: 0f c9                       	bswapl	%ecx
14008ac00: 89 4d 10                    	movl	%ecx, 0x10(%rbp)
14008ac03: 84 c9                       	testb	%cl, %cl
14008ac05: 74 13                       	je	0x14008ac1a <.text+0x89c1a>
14008ac07: 41 bd 04 00 00 00           	movl	$0x4, %r13d
14008ac0d: 48 8d 55 10                 	leaq	0x10(%rbp), %rdx
14008ac11: eb 42                       	jmp	0x14008ac55 <.text+0x89c55>
14008ac13: 45 31 ed                    	xorl	%r13d, %r13d
14008ac16: 31 c0                       	xorl	%eax, %eax
14008ac18: eb 70                       	jmp	0x14008ac8a <.text+0x89c8a>
14008ac1a: f7 c1 00 ff 00 00           	testl	$0xff00, %ecx           # imm = 0xFF00
14008ac20: 74 0c                       	je	0x14008ac2e <.text+0x89c2e>
14008ac22: 48 8d 55 11                 	leaq	0x11(%rbp), %rdx
14008ac26: 41 bd 03 00 00 00           	movl	$0x3, %r13d
14008ac2c: eb 27                       	jmp	0x14008ac55 <.text+0x89c55>
14008ac2e: f7 c1 00 00 ff 00           	testl	$0xff0000, %ecx         # imm = 0xFF0000
14008ac34: 74 0c                       	je	0x14008ac42 <.text+0x89c42>
14008ac36: 48 8d 55 12                 	leaq	0x12(%rbp), %rdx
14008ac3a: 41 bd 02 00 00 00           	movl	$0x2, %r13d
14008ac40: eb 13                       	jmp	0x14008ac55 <.text+0x89c55>
14008ac42: 48 85 c0                    	testq	%rax, %rax
14008ac45: 0f 84 9b 10 00 00           	je	0x14008bce6 <.text+0x8ace6>
14008ac4b: 48 8d 55 13                 	leaq	0x13(%rbp), %rdx
14008ac4f: 41 bd 01 00 00 00           	movl	$0x1, %r13d
14008ac55: c7 85 78 02 00 00 00 00 00 00       	movl	$0x0, 0x278(%rbp)
14008ac5f: 48 8d 8d 78 02 00 00        	leaq	0x278(%rbp), %rcx
14008ac66: 4d 89 e8                    	movq	%r13, %r8
14008ac69: e8 72 81 1c 00              	callq	0x140252de0 <.text+0x251de0>
14008ac6e: 8b 85 78 02 00 00           	movl	0x278(%rbp), %eax
14008ac74: 4c 8b 85 c0 05 00 00        	movq	0x5c0(%rbp), %r8
14008ac7b: 89 85 03 05 00 00           	movl	%eax, 0x503(%rbp)
14008ac81: 44 88 ad 07 05 00 00        	movb	%r13b, 0x507(%rbp)
14008ac88: b0 01                       	movb	$0x1, %al
14008ac8a: 4c 89 b5 68 02 00 00        	movq	%r14, 0x268(%rbp)
14008ac91: 48 89 85 60 02 00 00        	movq	%rax, 0x260(%rbp)
14008ac98: 88 85 02 05 00 00           	movb	%al, 0x502(%rbp)
14008ac9e: 49 8b 08                    	movq	(%r8), %rcx
14008aca1: 48 89 8d 58 02 00 00        	movq	%rcx, 0x258(%rbp)
14008aca8: 48 83 f9 02                 	cmpq	$0x2, %rcx
14008acac: 4c 89 ad 70 02 00 00        	movq	%r13, 0x270(%rbp)
14008acb3: 75 0a                       	jne	0x14008acbf <.text+0x89cbf>
14008acb5: 45 31 f6                    	xorl	%r14d, %r14d
14008acb8: 31 c0                       	xorl	%eax, %eax
14008acba: e9 9d 00 00 00              	jmp	0x14008ad5c <.text+0x89d5c>
14008acbf: 49 8b 48 10                 	movq	0x10(%r8), %rcx
14008acc3: 48 89 c8                    	movq	%rcx, %rax
14008acc6: 48 c1 e8 20                 	shrq	$0x20, %rax
14008acca: 89 ca                       	movl	%ecx, %edx
14008accc: c1 e2 04                    	shll	$0x4, %edx
14008accf: 48 c1 e9 25                 	shrq	$0x25, %rcx
14008acd3: 83 e1 08                    	andl	$0x8, %ecx
14008acd6: 09 d1                       	orl	%edx, %ecx
14008acd8: 0f b6 c0                    	movzbl	%al, %eax
14008acdb: 09 c8                       	orl	%ecx, %eax
14008acdd: 89 c1                       	movl	%eax, %ecx
14008acdf: 0f c9                       	bswapl	%ecx
14008ace1: 89 4d 10                    	movl	%ecx, 0x10(%rbp)
14008ace4: 84 c9                       	testb	%cl, %cl
14008ace6: 74 0c                       	je	0x14008acf4 <.text+0x89cf4>
14008ace8: 41 be 04 00 00 00           	movl	$0x4, %r14d
14008acee: 48 8d 55 10                 	leaq	0x10(%rbp), %rdx
14008acf2: eb 3a                       	jmp	0x14008ad2e <.text+0x89d2e>
14008acf4: f7 c1 00 ff 00 00           	testl	$0xff00, %ecx           # imm = 0xFF00
14008acfa: 74 0c                       	je	0x14008ad08 <.text+0x89d08>
14008acfc: 48 8d 55 11                 	leaq	0x11(%rbp), %rdx
14008ad00: 41 be 03 00 00 00           	movl	$0x3, %r14d
14008ad06: eb 26                       	jmp	0x14008ad2e <.text+0x89d2e>
14008ad08: f7 c1 00 00 ff 00           	testl	$0xff0000, %ecx         # imm = 0xFF0000
14008ad0e: 74 0c                       	je	0x14008ad1c <.text+0x89d1c>
14008ad10: 48 8d 55 12                 	leaq	0x12(%rbp), %rdx
14008ad14: 41 be 02 00 00 00           	movl	$0x2, %r14d
14008ad1a: eb 12                       	jmp	0x14008ad2e <.text+0x89d2e>
14008ad1c: 85 c0                       	testl	%eax, %eax
14008ad1e: 0f 84 f4 0e 00 00           	je	0x14008bc18 <.text+0x8ac18>
14008ad24: 48 8d 55 13                 	leaq	0x13(%rbp), %rdx
14008ad28: 41 be 01 00 00 00           	movl	$0x1, %r14d
14008ad2e: c7 85 78 02 00 00 00 00 00 00       	movl	$0x0, 0x278(%rbp)
14008ad38: 48 8d 8d 78 02 00 00        	leaq	0x278(%rbp), %rcx
14008ad3f: 4d 89 f0                    	movq	%r14, %r8
14008ad42: e8 99 80 1c 00              	callq	0x140252de0 <.text+0x251de0>
14008ad47: 8b 85 78 02 00 00           	movl	0x278(%rbp), %eax
14008ad4d: 89 85 fd 04 00 00           	movl	%eax, 0x4fd(%rbp)
14008ad53: 44 88 b5 01 05 00 00        	movb	%r14b, 0x501(%rbp)
14008ad5a: b0 01                       	movb	$0x1, %al
14008ad5c: 48 89 85 c8 04 00 00        	movq	%rax, 0x4c8(%rbp)
14008ad63: 88 85 fc 04 00 00           	movb	%al, 0x4fc(%rbp)
14008ad69: 41 0f 10 87 26 02 00 00     	movups	0x226(%r15), %xmm0
14008ad71: 41 0f 10 8f 36 02 00 00     	movups	0x236(%r15), %xmm1
14008ad79: 41 0f 10 97 40 02 00 00     	movups	0x240(%r15), %xmm2
14008ad81: 0f 11 55 fa                 	movups	%xmm2, -0x6(%rbp)
14008ad85: 0f 29 4d f0                 	movaps	%xmm1, -0x10(%rbp)
14008ad89: 0f 29 45 e0                 	movaps	%xmm0, -0x20(%rbp)
14008ad8d: 0f 10 05 fc 67 1d 00        	movups	0x1d67fc(%rip), %xmm0   # 0x140261590
14008ad94: 0f 29 45 10                 	movaps	%xmm0, 0x10(%rbp)
14008ad98: 48 c7 45 20 00 00 00 00     	movq	$0x0, 0x20(%rbp)
14008ada0: 0f 11 45 28                 	movups	%xmm0, 0x28(%rbp)
14008ada4: 48 c7 45 38 00 00 00 00     	movq	$0x0, 0x38(%rbp)
14008adac: 0f 29 45 40                 	movaps	%xmm0, 0x40(%rbp)
14008adb0: 48 c7 45 50 00 00 00 00     	movq	$0x0, 0x50(%rbp)
14008adb8: 0f 11 45 58                 	movups	%xmm0, 0x58(%rbp)
14008adbc: 48 c7 45 68 00 00 00 00     	movq	$0x0, 0x68(%rbp)
14008adc4: 0f 29 45 70                 	movaps	%xmm0, 0x70(%rbp)
14008adc8: 48 c7 85 80 00 00 00 00 00 00 00    	movq	$0x0, 0x80(%rbp)
14008add3: 0f 11 85 88 00 00 00        	movups	%xmm0, 0x88(%rbp)
14008adda: 48 c7 85 98 00 00 00 00 00 00 00    	movq	$0x0, 0x98(%rbp)
14008ade5: 0f 29 85 a0 00 00 00        	movaps	%xmm0, 0xa0(%rbp)
14008adec: 48 c7 85 b0 00 00 00 00 00 00 00    	movq	$0x0, 0xb0(%rbp)
14008adf7: 0f 11 85 b8 00 00 00        	movups	%xmm0, 0xb8(%rbp)
14008adfe: 48 c7 85 c8 00 00 00 00 00 00 00    	movq	$0x0, 0xc8(%rbp)
14008ae09: 0f 29 85 d0 00 00 00        	movaps	%xmm0, 0xd0(%rbp)
14008ae10: 48 c7 85 e0 00 00 00 00 00 00 00    	movq	$0x0, 0xe0(%rbp)
14008ae1b: 0f 11 85 e8 00 00 00        	movups	%xmm0, 0xe8(%rbp)
14008ae22: 48 c7 85 f8 00 00 00 00 00 00 00    	movq	$0x0, 0xf8(%rbp)
14008ae2d: 0f 29 85 00 01 00 00        	movaps	%xmm0, 0x100(%rbp)
14008ae34: 48 c7 85 10 01 00 00 00 00 00 00    	movq	$0x0, 0x110(%rbp)
14008ae3f: 0f 11 85 18 01 00 00        	movups	%xmm0, 0x118(%rbp)
14008ae46: 48 c7 85 28 01 00 00 00 00 00 00    	movq	$0x0, 0x128(%rbp)
14008ae51: 0f 29 85 30 01 00 00        	movaps	%xmm0, 0x130(%rbp)
14008ae58: 48 c7 85 40 01 00 00 00 00 00 00    	movq	$0x0, 0x140(%rbp)
14008ae63: 0f 11 85 48 01 00 00        	movups	%xmm0, 0x148(%rbp)
14008ae6a: 48 c7 85 58 01 00 00 00 00 00 00    	movq	$0x0, 0x158(%rbp)
14008ae75: 0f 29 85 60 01 00 00        	movaps	%xmm0, 0x160(%rbp)
14008ae7c: 48 c7 85 70 01 00 00 00 00 00 00    	movq	$0x0, 0x170(%rbp)
14008ae87: 0f 11 85 78 01 00 00        	movups	%xmm0, 0x178(%rbp)
14008ae8e: 48 c7 85 88 01 00 00 00 00 00 00    	movq	$0x0, 0x188(%rbp)
14008ae99: 0f 29 85 90 01 00 00        	movaps	%xmm0, 0x190(%rbp)
14008aea0: 48 c7 85 a0 01 00 00 00 00 00 00    	movq	$0x0, 0x1a0(%rbp)
14008aeab: 0f 11 85 a8 01 00 00        	movups	%xmm0, 0x1a8(%rbp)
14008aeb2: 48 c7 85 b8 01 00 00 00 00 00 00    	movq	$0x0, 0x1b8(%rbp)
14008aebd: 0f 29 85 c0 01 00 00        	movaps	%xmm0, 0x1c0(%rbp)
14008aec4: 48 c7 85 d0 01 00 00 00 00 00 00    	movq	$0x0, 0x1d0(%rbp)
14008aecf: 0f 11 85 d8 01 00 00        	movups	%xmm0, 0x1d8(%rbp)
14008aed6: 48 c7 85 e8 01 00 00 00 00 00 00    	movq	$0x0, 0x1e8(%rbp)
14008aee1: 0f 29 85 f0 01 00 00        	movaps	%xmm0, 0x1f0(%rbp)
14008aee8: 48 c7 85 00 02 00 00 00 00 00 00    	movq	$0x0, 0x200(%rbp)
14008aef3: 0f 11 85 08 02 00 00        	movups	%xmm0, 0x208(%rbp)
14008aefa: 48 c7 85 18 02 00 00 00 00 00 00    	movq	$0x0, 0x218(%rbp)
14008af05: 0f 29 85 20 02 00 00        	movaps	%xmm0, 0x220(%rbp)
14008af0c: 48 c7 85 30 02 00 00 00 00 00 00    	movq	$0x0, 0x230(%rbp)
14008af17: 0f 11 85 38 02 00 00        	movups	%xmm0, 0x238(%rbp)
14008af1e: 48 c7 85 48 02 00 00 00 00 00 00    	movq	$0x0, 0x248(%rbp)
14008af29: 4c 8d ad 78 02 00 00        	leaq	0x278(%rbp), %r13
14008af30: 48 8d 55 10                 	leaq	0x10(%rbp), %rdx
14008af34: 41 b8 40 02 00 00           	movl	$0x240, %r8d            # imm = 0x240
14008af3a: 4c 89 e9                    	movq	%r13, %rcx
14008af3d: e8 9e 7e 1c 00              	callq	0x140252de0 <.text+0x251de0>
14008af42: 48 c7 85 b8 04 00 00 00 00 00 00    	movq	$0x0, 0x4b8(%rbp)
14008af4d: 41 0f b6 97 56 02 00 00     	movzbl	0x256(%r15), %edx
14008af55: 48 85 d2                    	testq	%rdx, %rdx
14008af58: 74 6b                       	je	0x14008afc5 <.text+0x89fc5>
14008af5a: 80 fa 09                    	cmpb	$0x9, %dl
14008af5d: 0f 83 a6 0d 00 00           	jae	0x14008bd09 <.text+0x8ad09>
14008af63: 49 8d 87 d8 01 00 00        	leaq	0x1d8(%r15), %rax
14008af6a: 48 89 85 78 02 00 00        	movq	%rax, 0x278(%rbp)
14008af71: 48 89 95 80 02 00 00        	movq	%rdx, 0x280(%rbp)
14008af78: 66 c7 85 88 02 00 00 04 00  	movw	$0x4, 0x288(%rbp)
14008af81: 48 c7 85 b8 04 00 00 01 00 00 00    	movq	$0x1, 0x4b8(%rbp)
14008af8c: ba 01 00 00 00              	movl	$0x1, %edx
14008af91: 40 84 ff                    	testb	%dil, %dil
14008af94: 74 68                       	je	0x14008affe <.text+0x89ffe>
14008af96: 48 8d 85 1b 05 00 00        	leaq	0x51b(%rbp), %rax
14008af9d: 66 83 bd 88 02 00 00 07     	cmpw	$0x7, 0x288(%rbp)
14008afa5: 72 30                       	jb	0x14008afd7 <.text+0x89fd7>
14008afa7: 48 8b 8d 88 02 00 00        	movq	0x288(%rbp), %rcx
14008afae: 48 89 8d a0 02 00 00        	movq	%rcx, 0x2a0(%rbp)
14008afb5: 0f 10 85 78 02 00 00        	movups	0x278(%rbp), %xmm0
14008afbc: 0f 11 85 90 02 00 00        	movups	%xmm0, 0x290(%rbp)
14008afc3: eb 19                       	jmp	0x14008afde <.text+0x89fde>
14008afc5: 40 84 ff                    	testb	%dil, %dil
14008afc8: 74 09                       	je	0x14008afd3 <.text+0x89fd3>
14008afca: 48 8d 85 1b 05 00 00        	leaq	0x51b(%rbp), %rax
14008afd1: eb 0b                       	jmp	0x14008afde <.text+0x89fde>
14008afd3: 31 d2                       	xorl	%edx, %edx
14008afd5: eb 27                       	jmp	0x14008affe <.text+0x89ffe>
14008afd7: 4c 8d ad 90 02 00 00        	leaq	0x290(%rbp), %r13
14008afde: 49 89 45 00                 	movq	%rax, (%r13)
14008afe2: 4d 89 65 08                 	movq	%r12, 0x8(%r13)
14008afe6: 66 41 c7 45 10 06 00        	movw	$0x6, 0x10(%r13)
14008afed: 48 8b 95 b8 04 00 00        	movq	0x4b8(%rbp), %rdx
14008aff4: 48 ff c2                    	incq	%rdx
14008aff7: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008affe: 41 0f b6 87 57 02 00 00     	movzbl	0x257(%r15), %eax
14008b006: 48 83 f8 09                 	cmpq	$0x9, %rax
14008b00a: 0f 83 f0 0c 00 00           	jae	0x14008bd00 <.text+0x8ad00>
14008b010: 48 8b bd c8 05 00 00        	movq	0x5c8(%rbp), %rdi
14008b017: 4c 8b a5 a0 05 00 00        	movq	0x5a0(%rbp), %r12
14008b01e: 44 0f b7 ad 98 05 00 00     	movzwl	0x598(%rbp), %r13d
14008b026: 84 c0                       	testb	%al, %al
14008b028: 0f 84 93 00 00 00           	je	0x14008b0c1 <.text+0x8a0c1>
14008b02e: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008b032: 0f 87 84 09 00 00           	ja	0x14008b9bc <.text+0x8a9bc>
14008b038: 49 8b 8f d8 00 00 00        	movq	0xd8(%r15), %rcx
14008b03f: 4d 8b 87 e0 00 00 00        	movq	0xe0(%r15), %r8
14008b046: 48 85 d2                    	testq	%rdx, %rdx
14008b049: 74 3c                       	je	0x14008b087 <.text+0x8a087>
14008b04b: 4c 8d 0c 52                 	leaq	(%rdx,%rdx,2), %r9
14008b04f: 4e 8d 0c cd 78 02 00 00     	leaq	0x278(,%r9,8), %r9
14008b057: 49 01 e9                    	addq	%rbp, %r9
14008b05a: 66 0f 1f 44 00 00           	nopw	(%rax,%rax)
14008b060: 66 41 83 79 f8 09           	cmpw	$0x9, -0x8(%r9)
14008b066: 72 21                       	jb	0x14008b089 <.text+0x8a089>
14008b068: 48 ff ca                    	decq	%rdx
14008b06b: 4d 8d 51 e8                 	leaq	-0x18(%r9), %r10
14008b06f: 4d 8b 5a 10                 	movq	0x10(%r10), %r11
14008b073: 4d 89 59 10                 	movq	%r11, 0x10(%r9)
14008b077: 41 0f 10 02                 	movups	(%r10), %xmm0
14008b07b: 41 0f 11 01                 	movups	%xmm0, (%r9)
14008b07f: 4d 89 d1                    	movq	%r10, %r9
14008b082: 48 85 d2                    	testq	%rdx, %rdx
14008b085: 75 d9                       	jne	0x14008b060 <.text+0x8a060>
14008b087: 31 d2                       	xorl	%edx, %edx
14008b089: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008b08d: 48 89 8c d5 78 02 00 00     	movq	%rcx, 0x278(%rbp,%rdx,8)
14008b095: 4c 89 84 d5 80 02 00 00     	movq	%r8, 0x280(%rbp,%rdx,8)
14008b09d: 66 c7 84 d5 88 02 00 00 08 00       	movw	$0x8, 0x288(%rbp,%rdx,8)
14008b0a7: 4c 8b 8d b8 04 00 00        	movq	0x4b8(%rbp), %r9
14008b0ae: 49 8d 51 01                 	leaq	0x1(%r9), %rdx
14008b0b2: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008b0b9: 3c 01                       	cmpb	$0x1, %al
14008b0bb: 0f 85 9a 02 00 00           	jne	0x14008b35b <.text+0x8a35b>
14008b0c1: 48 8b 85 20 05 00 00        	movq	0x520(%rbp), %rax
14008b0c8: 84 c0                       	testb	%al, %al
14008b0ca: 0f 84 8d 00 00 00           	je	0x14008b15d <.text+0x8a15d>
14008b0d0: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008b0d4: 0f 87 e2 08 00 00           	ja	0x14008b9bc <.text+0x8a9bc>
14008b0da: 48 8d 85 0f 05 00 00        	leaq	0x50f(%rbp), %rax
14008b0e1: 48 85 d2                    	testq	%rdx, %rdx
14008b0e4: 74 3f                       	je	0x14008b125 <.text+0x8a125>
14008b0e6: 48 8d 0c 52                 	leaq	(%rdx,%rdx,2), %rcx
14008b0ea: 48 8d 0c cd 78 02 00 00     	leaq	0x278(,%rcx,8), %rcx
14008b0f2: 48 01 e9                    	addq	%rbp, %rcx
14008b0f5: 66 66 2e 0f 1f 84 00 00 00 00 00    	nopw	%cs:(%rax,%rax)
14008b100: 66 83 79 f8 0d              	cmpw	$0xd, -0x8(%rcx)
14008b105: 72 20                       	jb	0x14008b127 <.text+0x8a127>
14008b107: 48 ff ca                    	decq	%rdx
14008b10a: 4c 8d 41 e8                 	leaq	-0x18(%rcx), %r8
14008b10e: 4d 8b 48 10                 	movq	0x10(%r8), %r9
14008b112: 4c 89 49 10                 	movq	%r9, 0x10(%rcx)
14008b116: 41 0f 10 00                 	movups	(%r8), %xmm0
14008b11a: 0f 11 01                    	movups	%xmm0, (%rcx)
14008b11d: 4c 89 c1                    	movq	%r8, %rcx
14008b120: 48 85 d2                    	testq	%rdx, %rdx
14008b123: 75 db                       	jne	0x14008b100 <.text+0x8a100>
14008b125: 31 d2                       	xorl	%edx, %edx
14008b127: 48 8d 0c 52                 	leaq	(%rdx,%rdx,2), %rcx
14008b12b: 48 89 84 cd 78 02 00 00     	movq	%rax, 0x278(%rbp,%rcx,8)
14008b133: 48 8b 85 50 02 00 00        	movq	0x250(%rbp), %rax
14008b13a: 48 89 84 cd 80 02 00 00     	movq	%rax, 0x280(%rbp,%rcx,8)
14008b142: 66 c7 84 cd 88 02 00 00 0c 00       	movw	$0xc, 0x288(%rbp,%rcx,8)
14008b14c: 48 8b 95 b8 04 00 00        	movq	0x4b8(%rbp), %rdx
14008b153: 48 ff c2                    	incq	%rdx
14008b156: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008b15d: 48 8b 85 c0 04 00 00        	movq	0x4c0(%rbp), %rax
14008b164: 84 c0                       	testb	%al, %al
14008b166: 0f 84 91 00 00 00           	je	0x14008b1fd <.text+0x8a1fd>
14008b16c: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008b170: 0f 87 46 08 00 00           	ja	0x14008b9bc <.text+0x8a9bc>
14008b176: 48 8d 85 09 05 00 00        	leaq	0x509(%rbp), %rax
14008b17d: 48 85 d2                    	testq	%rdx, %rdx
14008b180: 74 43                       	je	0x14008b1c5 <.text+0x8a1c5>
14008b182: 48 8d 0c 52                 	leaq	(%rdx,%rdx,2), %rcx
14008b186: 48 8d 0c cd 78 02 00 00     	leaq	0x278(,%rcx,8), %rcx
14008b18e: 48 01 e9                    	addq	%rbp, %rcx
14008b191: 66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00	nopw	%cs:(%rax,%rax)
14008b1a0: 66 83 79 f8 0f              	cmpw	$0xf, -0x8(%rcx)
14008b1a5: 72 20                       	jb	0x14008b1c7 <.text+0x8a1c7>
14008b1a7: 48 ff ca                    	decq	%rdx
14008b1aa: 4c 8d 41 e8                 	leaq	-0x18(%rcx), %r8
14008b1ae: 4d 8b 48 10                 	movq	0x10(%r8), %r9
14008b1b2: 4c 89 49 10                 	movq	%r9, 0x10(%rcx)
14008b1b6: 41 0f 10 00                 	movups	(%r8), %xmm0
14008b1ba: 0f 11 01                    	movups	%xmm0, (%rcx)
14008b1bd: 4c 89 c1                    	movq	%r8, %rcx
14008b1c0: 48 85 d2                    	testq	%rdx, %rdx
14008b1c3: 75 db                       	jne	0x14008b1a0 <.text+0x8a1a0>
14008b1c5: 31 d2                       	xorl	%edx, %edx
14008b1c7: 48 8d 0c 52                 	leaq	(%rdx,%rdx,2), %rcx
14008b1cb: 48 89 84 cd 78 02 00 00     	movq	%rax, 0x278(%rbp,%rcx,8)
14008b1d3: 48 8b 85 d0 04 00 00        	movq	0x4d0(%rbp), %rax
14008b1da: 48 89 84 cd 80 02 00 00     	movq	%rax, 0x280(%rbp,%rcx,8)
14008b1e2: 66 c7 84 cd 88 02 00 00 0e 00       	movw	$0xe, 0x288(%rbp,%rcx,8)
14008b1ec: 48 8b 95 b8 04 00 00        	movq	0x4b8(%rbp), %rdx
14008b1f3: 48 ff c2                    	incq	%rdx
14008b1f6: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008b1fd: 41 0f b6 87 58 02 00 00     	movzbl	0x258(%r15), %eax
14008b205: 48 83 f8 09                 	cmpq	$0x9, %rax
14008b209: 0f 83 10 0b 00 00           	jae	0x14008bd1f <.text+0x8ad1f>
14008b20f: 84 c0                       	testb	%al, %al
14008b211: 0f 84 8d 00 00 00           	je	0x14008b2a4 <.text+0x8a2a4>
14008b217: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008b21b: 0f 87 9b 07 00 00           	ja	0x14008b9bc <.text+0x8a9bc>
14008b221: 49 8b 8f 58 01 00 00        	movq	0x158(%r15), %rcx
14008b228: 4d 8b 87 60 01 00 00        	movq	0x160(%r15), %r8
14008b22f: 48 85 d2                    	testq	%rdx, %rdx
14008b232: 74 36                       	je	0x14008b26a <.text+0x8a26a>
14008b234: 4c 8d 0c 52                 	leaq	(%rdx,%rdx,2), %r9
14008b238: 4e 8d 0c cd 78 02 00 00     	leaq	0x278(,%r9,8), %r9
14008b240: 49 01 e9                    	addq	%rbp, %r9
14008b243: 66 41 83 79 f8 15           	cmpw	$0x15, -0x8(%r9)
14008b249: 72 21                       	jb	0x14008b26c <.text+0x8a26c>
14008b24b: 48 ff ca                    	decq	%rdx
14008b24e: 4d 8d 51 e8                 	leaq	-0x18(%r9), %r10
14008b252: 4d 8b 5a 10                 	movq	0x10(%r10), %r11
14008b256: 4d 89 59 10                 	movq	%r11, 0x10(%r9)
14008b25a: 41 0f 10 02                 	movups	(%r10), %xmm0
14008b25e: 41 0f 11 01                 	movups	%xmm0, (%r9)
14008b262: 4d 89 d1                    	movq	%r10, %r9
14008b265: 48 85 d2                    	testq	%rdx, %rdx
14008b268: 75 d9                       	jne	0x14008b243 <.text+0x8a243>
14008b26a: 31 d2                       	xorl	%edx, %edx
14008b26c: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008b270: 48 89 8c d5 78 02 00 00     	movq	%rcx, 0x278(%rbp,%rdx,8)
14008b278: 4c 89 84 d5 80 02 00 00     	movq	%r8, 0x280(%rbp,%rdx,8)
14008b280: 66 c7 84 d5 88 02 00 00 14 00       	movw	$0x14, 0x288(%rbp,%rdx,8)
14008b28a: 4c 8b 8d b8 04 00 00        	movq	0x4b8(%rbp), %r9
14008b291: 49 8d 51 01                 	leaq	0x1(%r9), %rdx
14008b295: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008b29c: 3c 01                       	cmpb	$0x1, %al
14008b29e: 0f 85 84 03 00 00           	jne	0x14008b628 <.text+0x8a628>
14008b2a4: 83 bd e8 04 00 00 02        	cmpl	$0x2, 0x4e8(%rbp)
14008b2ab: 0f 84 3b 06 00 00           	je	0x14008b8ec <.text+0x8a8ec>
14008b2b1: 48 8b 85 b8 05 00 00        	movq	0x5b8(%rbp), %rax
14008b2b8: f6 40 18 01                 	testb	$0x1, 0x18(%rax)
14008b2bc: 0f 84 a6 05 00 00           	je	0x14008b868 <.text+0x8a868>
14008b2c2: 80 bd 60 02 00 00 00        	cmpb	$0x0, 0x260(%rbp)
14008b2c9: 74 35                       	je	0x14008b300 <.text+0x8a300>
14008b2cb: 48 8d 85 03 05 00 00        	leaq	0x503(%rbp), %rax
14008b2d2: 66 c7 45 20 1c 00           	movw	$0x1c, 0x20(%rbp)
14008b2d8: 48 89 45 10                 	movq	%rax, 0x10(%rbp)
14008b2dc: 48 8b 85 70 02 00 00        	movq	0x270(%rbp), %rax
14008b2e3: 48 89 45 18                 	movq	%rax, 0x18(%rbp)
14008b2e7: 48 8d 8d 78 02 00 00        	leaq	0x278(%rbp), %rcx
14008b2ee: 48 8d 55 10                 	leaq	0x10(%rbp), %rdx
14008b2f2: e8 49 a3 16 00              	callq	0x1401f5640 <.text+0x1f4640>
14008b2f7: 48 85 c0                    	testq	%rax, %rax
14008b2fa: 0f 84 bc 06 00 00           	je	0x14008b9bc <.text+0x8a9bc>
14008b300: 48 8b 95 b8 04 00 00        	movq	0x4b8(%rbp), %rdx
14008b307: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008b30b: 0f 87 ab 06 00 00           	ja	0x14008b9bc <.text+0x8a9bc>
14008b311: 66 b8 1f 00                 	movw	$0x1f, %ax
14008b315: 48 85 d2                    	testq	%rdx, %rdx
14008b318: 0f 84 91 05 00 00           	je	0x14008b8af <.text+0x8a8af>
14008b31e: 48 8d 0c 52                 	leaq	(%rdx,%rdx,2), %rcx
14008b322: 48 8d 0c cd 78 02 00 00     	leaq	0x278(,%rcx,8), %rcx
14008b32a: 48 01 e9                    	addq	%rbp, %rcx
14008b32d: 66 83 79 f8 20              	cmpw	$0x20, -0x8(%rcx)
14008b332: 0f 82 79 05 00 00           	jb	0x14008b8b1 <.text+0x8a8b1>
14008b338: 48 ff ca                    	decq	%rdx
14008b33b: 4c 8d 41 e8                 	leaq	-0x18(%rcx), %r8
14008b33f: 4d 8b 48 10                 	movq	0x10(%r8), %r9
14008b343: 4c 89 49 10                 	movq	%r9, 0x10(%rcx)
14008b347: 41 0f 10 00                 	movups	(%r8), %xmm0
14008b34b: 0f 11 01                    	movups	%xmm0, (%rcx)
14008b34e: 4c 89 c1                    	movq	%r8, %rcx
14008b351: 48 85 d2                    	testq	%rdx, %rdx
14008b354: 75 d7                       	jne	0x14008b32d <.text+0x8a32d>
14008b356: e9 54 05 00 00              	jmp	0x14008b8af <.text+0x8a8af>
14008b35b: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008b35f: 0f 87 57 06 00 00           	ja	0x14008b9bc <.text+0x8a9bc>
14008b365: 49 8b 8f e8 00 00 00        	movq	0xe8(%r15), %rcx
14008b36c: 4d 8b 87 f0 00 00 00        	movq	0xf0(%r15), %r8
14008b373: 48 85 d2                    	testq	%rdx, %rdx
14008b376: 74 36                       	je	0x14008b3ae <.text+0x8a3ae>
14008b378: 4f 8d 0c 49                 	leaq	(%r9,%r9,2), %r9
14008b37c: 4e 8d 0c cd 90 02 00 00     	leaq	0x290(,%r9,8), %r9
14008b384: 49 01 e9                    	addq	%rbp, %r9
14008b387: 66 41 83 79 f8 09           	cmpw	$0x9, -0x8(%r9)
14008b38d: 72 21                       	jb	0x14008b3b0 <.text+0x8a3b0>
14008b38f: 48 ff ca                    	decq	%rdx
14008b392: 4d 8d 51 e8                 	leaq	-0x18(%r9), %r10
14008b396: 4d 8b 5a 10                 	movq	0x10(%r10), %r11
14008b39a: 4d 89 59 10                 	movq	%r11, 0x10(%r9)
14008b39e: 41 0f 10 02                 	movups	(%r10), %xmm0
14008b3a2: 41 0f 11 01                 	movups	%xmm0, (%r9)
14008b3a6: 4d 89 d1                    	movq	%r10, %r9
14008b3a9: 48 85 d2                    	testq	%rdx, %rdx
14008b3ac: 75 d9                       	jne	0x14008b387 <.text+0x8a387>
14008b3ae: 31 d2                       	xorl	%edx, %edx
14008b3b0: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008b3b4: 48 89 8c d5 78 02 00 00     	movq	%rcx, 0x278(%rbp,%rdx,8)
14008b3bc: 4c 89 84 d5 80 02 00 00     	movq	%r8, 0x280(%rbp,%rdx,8)
14008b3c4: 66 c7 84 d5 88 02 00 00 08 00       	movw	$0x8, 0x288(%rbp,%rdx,8)
14008b3ce: 4c 8b 8d b8 04 00 00        	movq	0x4b8(%rbp), %r9
14008b3d5: 49 8d 51 01                 	leaq	0x1(%r9), %rdx
14008b3d9: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008b3e0: 3c 02                       	cmpb	$0x2, %al
14008b3e2: 0f 84 d9 fc ff ff           	je	0x14008b0c1 <.text+0x8a0c1>
14008b3e8: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008b3ec: 0f 87 ca 05 00 00           	ja	0x14008b9bc <.text+0x8a9bc>
14008b3f2: 49 8b 8f f8 00 00 00        	movq	0xf8(%r15), %rcx
14008b3f9: 4d 8b 87 00 01 00 00        	movq	0x100(%r15), %r8
14008b400: 48 85 d2                    	testq	%rdx, %rdx
14008b403: 74 36                       	je	0x14008b43b <.text+0x8a43b>
14008b405: 4f 8d 0c 49                 	leaq	(%r9,%r9,2), %r9
14008b409: 4e 8d 0c cd 90 02 00 00     	leaq	0x290(,%r9,8), %r9
14008b411: 49 01 e9                    	addq	%rbp, %r9
14008b414: 66 41 83 79 f8 09           	cmpw	$0x9, -0x8(%r9)
14008b41a: 72 21                       	jb	0x14008b43d <.text+0x8a43d>
14008b41c: 48 ff ca                    	decq	%rdx
14008b41f: 4d 8d 51 e8                 	leaq	-0x18(%r9), %r10
14008b423: 4d 8b 5a 10                 	movq	0x10(%r10), %r11
14008b427: 4d 89 59 10                 	movq	%r11, 0x10(%r9)
14008b42b: 41 0f 10 02                 	movups	(%r10), %xmm0
14008b42f: 41 0f 11 01                 	movups	%xmm0, (%r9)
14008b433: 4d 89 d1                    	movq	%r10, %r9
14008b436: 48 85 d2                    	testq	%rdx, %rdx
14008b439: 75 d9                       	jne	0x14008b414 <.text+0x8a414>
14008b43b: 31 d2                       	xorl	%edx, %edx
14008b43d: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008b441: 48 89 8c d5 78 02 00 00     	movq	%rcx, 0x278(%rbp,%rdx,8)
14008b449: 4c 89 84 d5 80 02 00 00     	movq	%r8, 0x280(%rbp,%rdx,8)
14008b451: 66 c7 84 d5 88 02 00 00 08 00       	movw	$0x8, 0x288(%rbp,%rdx,8)
14008b45b: 4c 8b 8d b8 04 00 00        	movq	0x4b8(%rbp), %r9
14008b462: 49 8d 51 01                 	leaq	0x1(%r9), %rdx
14008b466: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008b46d: 3c 03                       	cmpb	$0x3, %al
14008b46f: 0f 84 4c fc ff ff           	je	0x14008b0c1 <.text+0x8a0c1>
14008b475: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008b479: 0f 87 3d 05 00 00           	ja	0x14008b9bc <.text+0x8a9bc>
14008b47f: 49 8b 8f 08 01 00 00        	movq	0x108(%r15), %rcx
14008b486: 4d 8b 87 10 01 00 00        	movq	0x110(%r15), %r8
14008b48d: 48 85 d2                    	testq	%rdx, %rdx
14008b490: 74 36                       	je	0x14008b4c8 <.text+0x8a4c8>
14008b492: 4f 8d 0c 49                 	leaq	(%r9,%r9,2), %r9
14008b496: 4e 8d 0c cd 90 02 00 00     	leaq	0x290(,%r9,8), %r9
14008b49e: 49 01 e9                    	addq	%rbp, %r9
14008b4a1: 66 41 83 79 f8 09           	cmpw	$0x9, -0x8(%r9)
14008b4a7: 72 21                       	jb	0x14008b4ca <.text+0x8a4ca>
14008b4a9: 48 ff ca                    	decq	%rdx
14008b4ac: 4d 8d 51 e8                 	leaq	-0x18(%r9), %r10
14008b4b0: 4d 8b 5a 10                 	movq	0x10(%r10), %r11
14008b4b4: 4d 89 59 10                 	movq	%r11, 0x10(%r9)
14008b4b8: 41 0f 10 02                 	movups	(%r10), %xmm0
14008b4bc: 41 0f 11 01                 	movups	%xmm0, (%r9)
14008b4c0: 4d 89 d1                    	movq	%r10, %r9
14008b4c3: 48 85 d2                    	testq	%rdx, %rdx
14008b4c6: 75 d9                       	jne	0x14008b4a1 <.text+0x8a4a1>
14008b4c8: 31 d2                       	xorl	%edx, %edx
14008b4ca: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008b4ce: 48 89 8c d5 78 02 00 00     	movq	%rcx, 0x278(%rbp,%rdx,8)
14008b4d6: 4c 89 84 d5 80 02 00 00     	movq	%r8, 0x280(%rbp,%rdx,8)
14008b4de: 66 c7 84 d5 88 02 00 00 08 00       	movw	$0x8, 0x288(%rbp,%rdx,8)
14008b4e8: 4c 8b 8d b8 04 00 00        	movq	0x4b8(%rbp), %r9
14008b4ef: 49 8d 51 01                 	leaq	0x1(%r9), %rdx
14008b4f3: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008b4fa: 3c 04                       	cmpb	$0x4, %al
14008b4fc: 0f 84 bf fb ff ff           	je	0x14008b0c1 <.text+0x8a0c1>
14008b502: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008b506: 0f 87 b0 04 00 00           	ja	0x14008b9bc <.text+0x8a9bc>
14008b50c: 49 8b 8f 18 01 00 00        	movq	0x118(%r15), %rcx
14008b513: 4d 8b 87 20 01 00 00        	movq	0x120(%r15), %r8
14008b51a: 48 85 d2                    	testq	%rdx, %rdx
14008b51d: 74 36                       	je	0x14008b555 <.text+0x8a555>
14008b51f: 4f 8d 0c 49                 	leaq	(%r9,%r9,2), %r9
14008b523: 4e 8d 0c cd 90 02 00 00     	leaq	0x290(,%r9,8), %r9
14008b52b: 49 01 e9                    	addq	%rbp, %r9
14008b52e: 66 41 83 79 f8 09           	cmpw	$0x9, -0x8(%r9)
14008b534: 72 21                       	jb	0x14008b557 <.text+0x8a557>
14008b536: 48 ff ca                    	decq	%rdx
14008b539: 4d 8d 51 e8                 	leaq	-0x18(%r9), %r10
14008b53d: 4d 8b 5a 10                 	movq	0x10(%r10), %r11
14008b541: 4d 89 59 10                 	movq	%r11, 0x10(%r9)
14008b545: 41 0f 10 02                 	movups	(%r10), %xmm0
14008b549: 41 0f 11 01                 	movups	%xmm0, (%r9)
14008b54d: 4d 89 d1                    	movq	%r10, %r9
14008b550: 48 85 d2                    	testq	%rdx, %rdx
14008b553: 75 d9                       	jne	0x14008b52e <.text+0x8a52e>
14008b555: 31 d2                       	xorl	%edx, %edx
14008b557: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008b55b: 48 89 8c d5 78 02 00 00     	movq	%rcx, 0x278(%rbp,%rdx,8)
14008b563: 4c 89 84 d5 80 02 00 00     	movq	%r8, 0x280(%rbp,%rdx,8)
14008b56b: 66 c7 84 d5 88 02 00 00 08 00       	movw	$0x8, 0x288(%rbp,%rdx,8)
14008b575: 4c 8b 8d b8 04 00 00        	movq	0x4b8(%rbp), %r9
14008b57c: 49 8d 51 01                 	leaq	0x1(%r9), %rdx
14008b580: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008b587: 3c 05                       	cmpb	$0x5, %al
14008b589: 0f 84 32 fb ff ff           	je	0x14008b0c1 <.text+0x8a0c1>
14008b58f: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008b593: 0f 87 23 04 00 00           	ja	0x14008b9bc <.text+0x8a9bc>
14008b599: 49 8b 8f 28 01 00 00        	movq	0x128(%r15), %rcx
14008b5a0: 4d 8b 87 30 01 00 00        	movq	0x130(%r15), %r8
14008b5a7: 48 85 d2                    	testq	%rdx, %rdx
14008b5aa: 74 36                       	je	0x14008b5e2 <.text+0x8a5e2>
14008b5ac: 4f 8d 0c 49                 	leaq	(%r9,%r9,2), %r9
14008b5b0: 4e 8d 0c cd 90 02 00 00     	leaq	0x290(,%r9,8), %r9
14008b5b8: 49 01 e9                    	addq	%rbp, %r9
14008b5bb: 66 41 83 79 f8 09           	cmpw	$0x9, -0x8(%r9)
14008b5c1: 72 21                       	jb	0x14008b5e4 <.text+0x8a5e4>
14008b5c3: 48 ff ca                    	decq	%rdx
14008b5c6: 4d 8d 51 e8                 	leaq	-0x18(%r9), %r10
14008b5ca: 4d 8b 5a 10                 	movq	0x10(%r10), %r11
14008b5ce: 4d 89 59 10                 	movq	%r11, 0x10(%r9)
14008b5d2: 41 0f 10 02                 	movups	(%r10), %xmm0
14008b5d6: 41 0f 11 01                 	movups	%xmm0, (%r9)
14008b5da: 4d 89 d1                    	movq	%r10, %r9
14008b5dd: 48 85 d2                    	testq	%rdx, %rdx
14008b5e0: 75 d9                       	jne	0x14008b5bb <.text+0x8a5bb>
14008b5e2: 31 d2                       	xorl	%edx, %edx
14008b5e4: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008b5e8: 48 89 8c d5 78 02 00 00     	movq	%rcx, 0x278(%rbp,%rdx,8)
14008b5f0: 4c 89 84 d5 80 02 00 00     	movq	%r8, 0x280(%rbp,%rdx,8)
14008b5f8: 66 c7 84 d5 88 02 00 00 08 00       	movw	$0x8, 0x288(%rbp,%rdx,8)
14008b602: 4c 8b 8d b8 04 00 00        	movq	0x4b8(%rbp), %r9
14008b609: 49 8d 51 01                 	leaq	0x1(%r9), %rdx
14008b60d: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008b614: 3c 06                       	cmpb	$0x6, %al
14008b616: 0f 85 d4 08 00 00           	jne	0x14008bef0 <.text+0x8aef0>
14008b61c: 48 8b bd c8 05 00 00        	movq	0x5c8(%rbp), %rdi
14008b623: e9 99 fa ff ff              	jmp	0x14008b0c1 <.text+0x8a0c1>
14008b628: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008b62c: 0f 87 8a 03 00 00           	ja	0x14008b9bc <.text+0x8a9bc>
14008b632: 49 8b 8f 68 01 00 00        	movq	0x168(%r15), %rcx
14008b639: 4d 8b 87 70 01 00 00        	movq	0x170(%r15), %r8
14008b640: 48 85 d2                    	testq	%rdx, %rdx
14008b643: 74 36                       	je	0x14008b67b <.text+0x8a67b>
14008b645: 4f 8d 0c 49                 	leaq	(%r9,%r9,2), %r9
14008b649: 4e 8d 0c cd 90 02 00 00     	leaq	0x290(,%r9,8), %r9
14008b651: 49 01 e9                    	addq	%rbp, %r9
14008b654: 66 41 83 79 f8 15           	cmpw	$0x15, -0x8(%r9)
14008b65a: 72 21                       	jb	0x14008b67d <.text+0x8a67d>
14008b65c: 48 ff ca                    	decq	%rdx
14008b65f: 4d 8d 51 e8                 	leaq	-0x18(%r9), %r10
14008b663: 4d 8b 5a 10                 	movq	0x10(%r10), %r11
14008b667: 4d 89 59 10                 	movq	%r11, 0x10(%r9)
14008b66b: 41 0f 10 02                 	movups	(%r10), %xmm0
14008b66f: 41 0f 11 01                 	movups	%xmm0, (%r9)
14008b673: 4d 89 d1                    	movq	%r10, %r9
14008b676: 48 85 d2                    	testq	%rdx, %rdx
14008b679: 75 d9                       	jne	0x14008b654 <.text+0x8a654>
14008b67b: 31 d2                       	xorl	%edx, %edx
14008b67d: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008b681: 48 89 8c d5 78 02 00 00     	movq	%rcx, 0x278(%rbp,%rdx,8)
14008b689: 4c 89 84 d5 80 02 00 00     	movq	%r8, 0x280(%rbp,%rdx,8)
14008b691: 66 c7 84 d5 88 02 00 00 14 00       	movw	$0x14, 0x288(%rbp,%rdx,8)
14008b69b: 4c 8b 8d b8 04 00 00        	movq	0x4b8(%rbp), %r9
14008b6a2: 49 8d 51 01                 	leaq	0x1(%r9), %rdx
14008b6a6: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008b6ad: 3c 02                       	cmpb	$0x2, %al
14008b6af: 0f 84 ef fb ff ff           	je	0x14008b2a4 <.text+0x8a2a4>
14008b6b5: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008b6b9: 0f 87 fd 02 00 00           	ja	0x14008b9bc <.text+0x8a9bc>
14008b6bf: 49 8b 8f 78 01 00 00        	movq	0x178(%r15), %rcx
14008b6c6: 4d 8b 87 80 01 00 00        	movq	0x180(%r15), %r8
14008b6cd: 48 85 d2                    	testq	%rdx, %rdx
14008b6d0: 74 36                       	je	0x14008b708 <.text+0x8a708>
14008b6d2: 4f 8d 0c 49                 	leaq	(%r9,%r9,2), %r9
14008b6d6: 4e 8d 0c cd 90 02 00 00     	leaq	0x290(,%r9,8), %r9
14008b6de: 49 01 e9                    	addq	%rbp, %r9
14008b6e1: 66 41 83 79 f8 15           	cmpw	$0x15, -0x8(%r9)
14008b6e7: 72 21                       	jb	0x14008b70a <.text+0x8a70a>
14008b6e9: 48 ff ca                    	decq	%rdx
14008b6ec: 4d 8d 51 e8                 	leaq	-0x18(%r9), %r10
14008b6f0: 4d 8b 5a 10                 	movq	0x10(%r10), %r11
14008b6f4: 4d 89 59 10                 	movq	%r11, 0x10(%r9)
14008b6f8: 41 0f 10 02                 	movups	(%r10), %xmm0
14008b6fc: 41 0f 11 01                 	movups	%xmm0, (%r9)
14008b700: 4d 89 d1                    	movq	%r10, %r9
14008b703: 48 85 d2                    	testq	%rdx, %rdx
14008b706: 75 d9                       	jne	0x14008b6e1 <.text+0x8a6e1>
14008b708: 31 d2                       	xorl	%edx, %edx
14008b70a: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008b70e: 48 89 8c d5 78 02 00 00     	movq	%rcx, 0x278(%rbp,%rdx,8)
14008b716: 4c 89 84 d5 80 02 00 00     	movq	%r8, 0x280(%rbp,%rdx,8)
14008b71e: 66 c7 84 d5 88 02 00 00 14 00       	movw	$0x14, 0x288(%rbp,%rdx,8)
14008b728: 4c 8b 8d b8 04 00 00        	movq	0x4b8(%rbp), %r9
14008b72f: 49 8d 51 01                 	leaq	0x1(%r9), %rdx
14008b733: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008b73a: 3c 03                       	cmpb	$0x3, %al
14008b73c: 0f 84 62 fb ff ff           	je	0x14008b2a4 <.text+0x8a2a4>
14008b742: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008b746: 0f 87 70 02 00 00           	ja	0x14008b9bc <.text+0x8a9bc>
14008b74c: 49 8b 8f 88 01 00 00        	movq	0x188(%r15), %rcx
14008b753: 4d 8b 87 90 01 00 00        	movq	0x190(%r15), %r8
14008b75a: 48 85 d2                    	testq	%rdx, %rdx
14008b75d: 74 36                       	je	0x14008b795 <.text+0x8a795>
14008b75f: 4f 8d 0c 49                 	leaq	(%r9,%r9,2), %r9
14008b763: 4e 8d 0c cd 90 02 00 00     	leaq	0x290(,%r9,8), %r9
14008b76b: 49 01 e9                    	addq	%rbp, %r9
14008b76e: 66 41 83 79 f8 15           	cmpw	$0x15, -0x8(%r9)
14008b774: 72 21                       	jb	0x14008b797 <.text+0x8a797>
14008b776: 48 ff ca                    	decq	%rdx
14008b779: 4d 8d 51 e8                 	leaq	-0x18(%r9), %r10
14008b77d: 4d 8b 5a 10                 	movq	0x10(%r10), %r11
14008b781: 4d 89 59 10                 	movq	%r11, 0x10(%r9)
14008b785: 41 0f 10 02                 	movups	(%r10), %xmm0
14008b789: 41 0f 11 01                 	movups	%xmm0, (%r9)
14008b78d: 4d 89 d1                    	movq	%r10, %r9
14008b790: 48 85 d2                    	testq	%rdx, %rdx
14008b793: 75 d9                       	jne	0x14008b76e <.text+0x8a76e>
14008b795: 31 d2                       	xorl	%edx, %edx
14008b797: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008b79b: 48 89 8c d5 78 02 00 00     	movq	%rcx, 0x278(%rbp,%rdx,8)
14008b7a3: 4c 89 84 d5 80 02 00 00     	movq	%r8, 0x280(%rbp,%rdx,8)
14008b7ab: 66 c7 84 d5 88 02 00 00 14 00       	movw	$0x14, 0x288(%rbp,%rdx,8)
14008b7b5: 4c 8b 8d b8 04 00 00        	movq	0x4b8(%rbp), %r9
14008b7bc: 49 8d 51 01                 	leaq	0x1(%r9), %rdx
14008b7c0: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008b7c7: 3c 04                       	cmpb	$0x4, %al
14008b7c9: 0f 84 d5 fa ff ff           	je	0x14008b2a4 <.text+0x8a2a4>
14008b7cf: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008b7d3: 0f 87 e3 01 00 00           	ja	0x14008b9bc <.text+0x8a9bc>
14008b7d9: 49 8b 8f 98 01 00 00        	movq	0x198(%r15), %rcx
14008b7e0: 4d 8b 87 a0 01 00 00        	movq	0x1a0(%r15), %r8
14008b7e7: 48 85 d2                    	testq	%rdx, %rdx
14008b7ea: 74 36                       	je	0x14008b822 <.text+0x8a822>
14008b7ec: 4f 8d 0c 49                 	leaq	(%r9,%r9,2), %r9
14008b7f0: 4e 8d 0c cd 90 02 00 00     	leaq	0x290(,%r9,8), %r9
14008b7f8: 49 01 e9                    	addq	%rbp, %r9
14008b7fb: 66 41 83 79 f8 15           	cmpw	$0x15, -0x8(%r9)
14008b801: 72 21                       	jb	0x14008b824 <.text+0x8a824>
14008b803: 48 ff ca                    	decq	%rdx
14008b806: 4d 8d 51 e8                 	leaq	-0x18(%r9), %r10
14008b80a: 4d 8b 5a 10                 	movq	0x10(%r10), %r11
14008b80e: 4d 89 59 10                 	movq	%r11, 0x10(%r9)
14008b812: 41 0f 10 02                 	movups	(%r10), %xmm0
14008b816: 41 0f 11 01                 	movups	%xmm0, (%r9)
14008b81a: 4d 89 d1                    	movq	%r10, %r9
14008b81d: 48 85 d2                    	testq	%rdx, %rdx
14008b820: 75 d9                       	jne	0x14008b7fb <.text+0x8a7fb>
14008b822: 31 d2                       	xorl	%edx, %edx
14008b824: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008b828: 48 89 8c d5 78 02 00 00     	movq	%rcx, 0x278(%rbp,%rdx,8)
14008b830: 4c 89 84 d5 80 02 00 00     	movq	%r8, 0x280(%rbp,%rdx,8)
14008b838: 66 c7 84 d5 88 02 00 00 14 00       	movw	$0x14, 0x288(%rbp,%rdx,8)
14008b842: 4c 8b 8d b8 04 00 00        	movq	0x4b8(%rbp), %r9
14008b849: 49 8d 51 01                 	leaq	0x1(%r9), %rdx
14008b84d: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008b854: 3c 05                       	cmpb	$0x5, %al
14008b856: 0f 85 dc 04 00 00           	jne	0x14008bd38 <.text+0x8ad38>
14008b85c: 48 8b bd c8 05 00 00        	movq	0x5c8(%rbp), %rdi
14008b863: e9 3c fa ff ff              	jmp	0x14008b2a4 <.text+0x8a2a4>
14008b868: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008b86c: 0f 87 4a 01 00 00           	ja	0x14008b9bc <.text+0x8a9bc>
14008b872: 66 b8 17 00                 	movw	$0x17, %ax
14008b876: 48 85 d2                    	testq	%rdx, %rdx
14008b879: 74 34                       	je	0x14008b8af <.text+0x8a8af>
14008b87b: 48 8d 0c 52                 	leaq	(%rdx,%rdx,2), %rcx
14008b87f: 48 8d 0c cd 78 02 00 00     	leaq	0x278(,%rcx,8), %rcx
14008b887: 48 01 e9                    	addq	%rbp, %rcx
14008b88a: 66 83 79 f8 18              	cmpw	$0x18, -0x8(%rcx)
14008b88f: 72 20                       	jb	0x14008b8b1 <.text+0x8a8b1>
14008b891: 48 ff ca                    	decq	%rdx
14008b894: 4c 8d 41 e8                 	leaq	-0x18(%rcx), %r8
14008b898: 4d 8b 48 10                 	movq	0x10(%r8), %r9
14008b89c: 4c 89 49 10                 	movq	%r9, 0x10(%rcx)
14008b8a0: 41 0f 10 00                 	movups	(%r8), %xmm0
14008b8a4: 0f 11 01                    	movups	%xmm0, (%rcx)
14008b8a7: 4c 89 c1                    	movq	%r8, %rcx
14008b8aa: 48 85 d2                    	testq	%rdx, %rdx
14008b8ad: 75 db                       	jne	0x14008b88a <.text+0x8a88a>
14008b8af: 31 d2                       	xorl	%edx, %edx
14008b8b1: 48 8d 8d 15 05 00 00        	leaq	0x515(%rbp), %rcx
14008b8b8: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008b8bc: 48 89 8c d5 78 02 00 00     	movq	%rcx, 0x278(%rbp,%rdx,8)
14008b8c4: 48 8b 8d 68 02 00 00        	movq	0x268(%rbp), %rcx
14008b8cb: 48 89 8c d5 80 02 00 00     	movq	%rcx, 0x280(%rbp,%rdx,8)
14008b8d3: 66 89 84 d5 88 02 00 00     	movw	%ax, 0x288(%rbp,%rdx,8)
14008b8db: 48 8b 95 b8 04 00 00        	movq	0x4b8(%rbp), %rdx
14008b8e2: 48 ff c2                    	incq	%rdx
14008b8e5: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008b8ec: 48 8b 85 c8 04 00 00        	movq	0x4c8(%rbp), %rax
14008b8f3: 84 c0                       	testb	%al, %al
14008b8f5: 0f 84 a3 00 00 00           	je	0x14008b99e <.text+0x8a99e>
14008b8fb: 83 bd 58 02 00 00 02        	cmpl	$0x2, 0x258(%rbp)
14008b902: 0f 94 c1                    	sete	%cl
14008b905: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008b909: 0f 87 ad 00 00 00           	ja	0x14008b9bc <.text+0x8a9bc>
14008b90f: 48 8d 85 fd 04 00 00        	leaq	0x4fd(%rbp), %rax
14008b916: 4c 8b 85 c0 05 00 00        	movq	0x5c0(%rbp), %r8
14008b91d: 45 0f b6 40 18              	movzbl	0x18(%r8), %r8d
14008b922: 41 f6 d0                    	notb	%r8b
14008b925: 44 08 c1                    	orb	%r8b, %cl
14008b928: 0f b6 c9                    	movzbl	%cl, %ecx
14008b92b: 83 e1 01                    	andl	$0x1, %ecx
14008b92e: 8d 0c cd 13 00 00 00        	leal	0x13(,%rcx,8), %ecx
14008b935: 48 85 d2                    	testq	%rdx, %rdx
14008b938: 74 35                       	je	0x14008b96f <.text+0x8a96f>
14008b93a: 4c 8d 04 52                 	leaq	(%rdx,%rdx,2), %r8
14008b93e: 4e 8d 04 c5 78 02 00 00     	leaq	0x278(,%r8,8), %r8
14008b946: 49 01 e8                    	addq	%rbp, %r8
14008b949: 66 41 39 48 f8              	cmpw	%cx, -0x8(%r8)
14008b94e: 76 21                       	jbe	0x14008b971 <.text+0x8a971>
14008b950: 48 ff ca                    	decq	%rdx
14008b953: 4d 8d 48 e8                 	leaq	-0x18(%r8), %r9
14008b957: 4d 8b 51 10                 	movq	0x10(%r9), %r10
14008b95b: 4d 89 50 10                 	movq	%r10, 0x10(%r8)
14008b95f: 41 0f 10 01                 	movups	(%r9), %xmm0
14008b963: 41 0f 11 00                 	movups	%xmm0, (%r8)
14008b967: 4d 89 c8                    	movq	%r9, %r8
14008b96a: 48 85 d2                    	testq	%rdx, %rdx
14008b96d: 75 da                       	jne	0x14008b949 <.text+0x8a949>
14008b96f: 31 d2                       	xorl	%edx, %edx
14008b971: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008b975: 48 89 84 d5 78 02 00 00     	movq	%rax, 0x278(%rbp,%rdx,8)
14008b97d: 4c 89 b4 d5 80 02 00 00     	movq	%r14, 0x280(%rbp,%rdx,8)
14008b985: 66 89 8c d5 88 02 00 00     	movw	%cx, 0x288(%rbp,%rdx,8)
14008b98d: 48 8b 95 b8 04 00 00        	movq	0x4b8(%rbp), %rdx
14008b994: 48 ff c2                    	incq	%rdx
14008b997: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008b99e: f6 45 e0 01                 	testb	$0x1, -0x20(%rbp)
14008b9a2: 0f 84 e7 00 00 00           	je	0x14008ba8f <.text+0x8aa8f>
14008b9a8: 0f b6 45 09                 	movzbl	0x9(%rbp), %eax
14008b9ac: 48 83 f8 29                 	cmpq	$0x29, %rax
14008b9b0: 0f 83 7b 06 00 00           	jae	0x14008c031 <.text+0x8b031>
14008b9b6: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008b9ba: 76 62                       	jbe	0x14008ba1e <.text+0x8aa1e>
14008b9bc: 48 8b 85 e0 04 00 00        	movq	0x4e0(%rbp), %rax
14008b9c3: 44 8b 40 14                 	movl	0x14(%rax), %r8d
14008b9c7: 4c 8b b5 d0 05 00 00        	movq	0x5d0(%rbp), %r14
14008b9ce: 49 8b 46 18                 	movq	0x18(%r14), %rax
14008b9d2: 49 8b 4e 50                 	movq	0x50(%r14), %rcx
14008b9d6: 48 8b 95 d8 05 00 00        	movq	0x5d8(%rbp), %rdx
14008b9dd: 48 89 54 24 50              	movq	%rdx, 0x50(%rsp)
14008b9e2: 48 89 4c 24 48              	movq	%rcx, 0x48(%rsp)
14008b9e7: 48 89 44 24 40              	movq	%rax, 0x40(%rsp)
14008b9ec: 48 89 7c 24 38              	movq	%rdi, 0x38(%rsp)
14008b9f1: 4c 89 64 24 30              	movq	%r12, 0x30(%rsp)
14008b9f6: 66 44 89 6c 24 28           	movw	%r13w, 0x28(%rsp)
14008b9fc: 0f b6 85 90 05 00 00        	movzbl	0x590(%rbp), %eax
14008ba03: 88 44 24 20                 	movb	%al, 0x20(%rsp)
14008ba07: 48 89 f1                    	movq	%rsi, %rcx
14008ba0a: 48 89 da                    	movq	%rbx, %rdx
14008ba0d: 4c 8b 8d f0 04 00 00        	movq	0x4f0(%rbp), %r9
14008ba14: e8 c7 bf 02 00              	callq	0x1400b79e0 <.text+0xb69e0>
14008ba19: e9 a0 ee ff ff              	jmp	0x14008a8be <.text+0x898be>
14008ba1e: 48 8d 4d e1                 	leaq	-0x1f(%rbp), %rcx
14008ba22: 48 85 d2                    	testq	%rdx, %rdx
14008ba25: 74 37                       	je	0x14008ba5e <.text+0x8aa5e>
14008ba27: 4c 8d 04 52                 	leaq	(%rdx,%rdx,2), %r8
14008ba2b: 4e 8d 04 c5 78 02 00 00     	leaq	0x278(,%r8,8), %r8
14008ba33: 49 01 e8                    	addq	%rbp, %r8
14008ba36: 66 41 81 78 f8 fd 00        	cmpw	$0xfd, -0x8(%r8)
14008ba3d: 72 21                       	jb	0x14008ba60 <.text+0x8aa60>
14008ba3f: 48 ff ca                    	decq	%rdx
14008ba42: 4d 8d 48 e8                 	leaq	-0x18(%r8), %r9
14008ba46: 4d 8b 51 10                 	movq	0x10(%r9), %r10
14008ba4a: 4d 89 50 10                 	movq	%r10, 0x10(%r8)
14008ba4e: 41 0f 10 01                 	movups	(%r9), %xmm0
14008ba52: 41 0f 11 00                 	movups	%xmm0, (%r8)
14008ba56: 4d 89 c8                    	movq	%r9, %r8
14008ba59: 48 85 d2                    	testq	%rdx, %rdx
14008ba5c: 75 d8                       	jne	0x14008ba36 <.text+0x8aa36>
14008ba5e: 31 d2                       	xorl	%edx, %edx
14008ba60: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008ba64: 48 89 8c d5 78 02 00 00     	movq	%rcx, 0x278(%rbp,%rdx,8)
14008ba6c: 48 89 84 d5 80 02 00 00     	movq	%rax, 0x280(%rbp,%rdx,8)
14008ba74: 66 c7 84 d5 88 02 00 00 fc 00       	movw	$0xfc, 0x288(%rbp,%rdx,8)
14008ba7e: 48 8b 95 b8 04 00 00        	movq	0x4b8(%rbp), %rdx
14008ba85: 48 ff c2                    	incq	%rdx
14008ba88: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008ba8f: 48 83 fa 19                 	cmpq	$0x19, %rdx
14008ba93: 0f 83 82 05 00 00           	jae	0x14008c01b <.text+0x8b01b>
14008ba99: 48 8b 85 b0 05 00 00        	movq	0x5b0(%rbp), %rax
14008baa0: 41 0f b6 8f 55 02 00 00     	movzbl	0x255(%r15), %ecx
14008baa8: 83 bd e8 04 00 00 02        	cmpl	$0x2, 0x4e8(%rbp)
14008baaf: 41 0f 95 c0                 	setne	%r8b
14008bab3: 41 80 bf 52 02 00 00 00     	cmpb	$0x0, 0x252(%r15)
14008babb: 75 6a                       	jne	0x14008bb27 <.text+0x8ab27>
14008babd: 4c 8b 8d b8 05 00 00        	movq	0x5b8(%rbp), %r9
14008bac4: 45 22 41 18                 	andb	0x18(%r9), %r8b
14008bac8: 75 5d                       	jne	0x14008bb27 <.text+0x8ab27>
14008baca: 44 0f b6 00                 	movzbl	(%rax), %r8d
14008bace: 83 bd dc 04 00 00 00        	cmpl	$0x0, 0x4dc(%rbp)
14008bad5: 0f 84 d3 00 00 00           	je	0x14008bbae <.text+0x8abae>
14008badb: 45 84 c0                    	testb	%r8b, %r8b
14008bade: 0f 85 d3 00 00 00           	jne	0x14008bbb7 <.text+0x8abb7>
14008bae4: 0f 10 40 08                 	movups	0x8(%rax), %xmm0
14008bae8: 48 8d 85 78 02 00 00        	leaq	0x278(%rbp), %rax
14008baef: 48 89 45 10                 	movq	%rax, 0x10(%rbp)
14008baf3: 48 89 55 18                 	movq	%rdx, 0x18(%rbp)
14008baf7: 0f 11 45 20                 	movups	%xmm0, 0x20(%rbp)
14008bafb: 66 44 89 6d 30              	movw	%r13w, 0x30(%rbp)
14008bb00: 88 4d 32                    	movb	%cl, 0x32(%rbp)
14008bb03: 49 8b 04 24                 	movq	(%r12), %rax
14008bb07: 48 89 45 33                 	movq	%rax, 0x33(%rbp)
14008bb0b: 41 0f b6 44 24 08           	movzbl	0x8(%r12), %eax
14008bb11: 88 45 3b                    	movb	%al, 0x3b(%rbp)
14008bb14: 0f b6 85 90 05 00 00        	movzbl	0x590(%rbp), %eax
14008bb1b: 88 45 3c                    	movb	%al, 0x3c(%rbp)
14008bb1e: 3c 02                       	cmpb	$0x2, %al
14008bb20: 75 48                       	jne	0x14008bb6a <.text+0x8ab6a>
14008bb22: e9 6c 01 00 00              	jmp	0x14008bc93 <.text+0x8ac93>
14008bb27: 80 38 00                    	cmpb	$0x0, (%rax)
14008bb2a: 0f 85 87 00 00 00           	jne	0x14008bbb7 <.text+0x8abb7>
14008bb30: 0f 10 40 08                 	movups	0x8(%rax), %xmm0
14008bb34: 48 8d 85 78 02 00 00        	leaq	0x278(%rbp), %rax
14008bb3b: 48 89 45 10                 	movq	%rax, 0x10(%rbp)
14008bb3f: 48 89 55 18                 	movq	%rdx, 0x18(%rbp)
14008bb43: 0f 11 45 20                 	movups	%xmm0, 0x20(%rbp)
14008bb47: 66 44 89 6d 30              	movw	%r13w, 0x30(%rbp)
14008bb4c: 88 4d 32                    	movb	%cl, 0x32(%rbp)
14008bb4f: 49 8b 04 24                 	movq	(%r12), %rax
14008bb53: 48 89 45 33                 	movq	%rax, 0x33(%rbp)
14008bb57: 41 0f b6 44 24 08           	movzbl	0x8(%r12), %eax
14008bb5d: 88 45 3b                    	movb	%al, 0x3b(%rbp)
14008bb60: 0f b6 85 90 05 00 00        	movzbl	0x590(%rbp), %eax
14008bb67: 88 45 3c                    	movb	%al, 0x3c(%rbp)
14008bb6a: 48 8d 45 10                 	leaq	0x10(%rbp), %rax
14008bb6e: 48 89 44 24 38              	movq	%rax, 0x38(%rsp)
14008bb73: 48 8b 85 f0 04 00 00        	movq	0x4f0(%rbp), %rax
14008bb7a: 48 89 44 24 30              	movq	%rax, 0x30(%rsp)
14008bb7f: 48 89 5c 24 28              	movq	%rbx, 0x28(%rsp)
14008bb84: 48 8b 85 d8 05 00 00        	movq	0x5d8(%rbp), %rax
14008bb8b: 48 89 44 24 20              	movq	%rax, 0x20(%rsp)
14008bb90: 48 89 f1                    	movq	%rsi, %rcx
14008bb93: 48 89 fa                    	movq	%rdi, %rdx
14008bb96: 4c 8b 85 d0 05 00 00        	movq	0x5d0(%rbp), %r8
14008bb9d: 4c 8b 8d e0 04 00 00        	movq	0x4e0(%rbp), %r9
14008bba4: e8 f7 96 07 00              	callq	0x1401052a0 <.text+0x1042a0>
14008bba9: e9 10 ed ff ff              	jmp	0x14008a8be <.text+0x898be>
14008bbae: 45 84 c0                    	testb	%r8b, %r8b
14008bbb1: 0f 84 a2 00 00 00           	je	0x14008bc59 <.text+0x8ac59>
14008bbb7: 48 8b 8d f0 04 00 00        	movq	0x4f0(%rbp), %rcx
14008bbbe: 80 bc 0b 80 1e 00 00 01     	cmpb	$0x1, 0x1e80(%rbx,%rcx)
14008bbc6: 75 32                       	jne	0x14008bbfa <.text+0x8abfa>
14008bbc8: 48 8b 94 cb f8 1d 00 00     	movq	0x1df8(%rbx,%rcx,8), %rdx
14008bbd0: 48 81 fa 81 04 00 00        	cmpq	$0x481, %rdx            # imm = 0x481
14008bbd7: 0f 83 6d 04 00 00           	jae	0x14008c04a <.text+0x8b04a>
14008bbdd: 48 85 d2                    	testq	%rdx, %rdx
14008bbe0: 0f 85 7a 04 00 00           	jne	0x14008c060 <.text+0x8b060>
14008bbe6: 80 bc 0b 82 1e 00 00 00     	cmpb	$0x0, 0x1e82(%rbx,%rcx)
14008bbee: 74 32                       	je	0x14008bc22 <.text+0x8ac22>
14008bbf0: 66 c7 06 07 03              	movw	$0x307, (%rsi)          # imm = 0x307
14008bbf5: e9 c4 ec ff ff              	jmp	0x14008a8be <.text+0x898be>
14008bbfa: 66 c7 06 07 01              	movw	$0x107, (%rsi)          # imm = 0x107
14008bbff: e9 ba ec ff ff              	jmp	0x14008a8be <.text+0x898be>
14008bc04: 45 31 ed                    	xorl	%r13d, %r13d
14008bc07: 31 c0                       	xorl	%eax, %eax
14008bc09: e9 2b ee ff ff              	jmp	0x14008aa39 <.text+0x89a39>
14008bc0e: 45 31 f6                    	xorl	%r14d, %r14d
14008bc11: 31 c0                       	xorl	%eax, %eax
14008bc13: e9 b9 ef ff ff              	jmp	0x14008abd1 <.text+0x89bd1>
14008bc18: 45 31 f6                    	xorl	%r14d, %r14d
14008bc1b: 31 c0                       	xorl	%eax, %eax
14008bc1d: e9 2b f1 ff ff              	jmp	0x14008ad4d <.text+0x89d4d>
14008bc22: 48 89 f9                    	movq	%rdi, %rcx
14008bc25: 48 8b 78 10                 	movq	0x10(%rax), %rdi
14008bc29: 48 8b 58 18                 	movq	0x18(%rax), %rbx
14008bc2d: 48 8b 85 d0 05 00 00        	movq	0x5d0(%rbp), %rax
14008bc34: ff 50 50                    	callq	*0x50(%rax)
14008bc37: 48 29 fb                    	subq	%rdi, %rbx
14008bc3a: 0f 93 c0                    	setae	%al
14008bc3d: 48 81 fb 01 04 00 00        	cmpq	$0x401, %rbx            # imm = 0x401
14008bc44: 0f 92 c1                    	setb	%cl
14008bc47: 84 c8                       	testb	%cl, %al
14008bc49: 0f 84 a1 00 00 00           	je	0x14008bcf0 <.text+0x8acf0>
14008bc4f: 66 c7 06 07 00              	movw	$0x7, (%rsi)
14008bc54: e9 65 ec ff ff              	jmp	0x14008a8be <.text+0x898be>
14008bc59: 0f 10 40 08                 	movups	0x8(%rax), %xmm0
14008bc5d: 48 8d 85 78 02 00 00        	leaq	0x278(%rbp), %rax
14008bc64: 48 89 45 10                 	movq	%rax, 0x10(%rbp)
14008bc68: 48 89 55 18                 	movq	%rdx, 0x18(%rbp)
14008bc6c: 0f 11 45 20                 	movups	%xmm0, 0x20(%rbp)
14008bc70: 66 44 89 6d 30              	movw	%r13w, 0x30(%rbp)
14008bc75: 88 4d 32                    	movb	%cl, 0x32(%rbp)
14008bc78: 49 8b 04 24                 	movq	(%r12), %rax
14008bc7c: 48 89 45 33                 	movq	%rax, 0x33(%rbp)
14008bc80: 41 0f b6 44 24 08           	movzbl	0x8(%r12), %eax
14008bc86: 88 45 3b                    	movb	%al, 0x3b(%rbp)
14008bc89: 0f b6 85 90 05 00 00        	movzbl	0x590(%rbp), %eax
14008bc90: 88 45 3c                    	movb	%al, 0x3c(%rbp)
14008bc93: 4c 8b b5 d0 05 00 00        	movq	0x5d0(%rbp), %r14
14008bc9a: 4d 8b 46 18                 	movq	0x18(%r14), %r8
14008bc9e: 4d 8b 4e 50                 	movq	0x50(%r14), %r9
14008bca2: 48 8b 85 e0 04 00 00        	movq	0x4e0(%rbp), %rax
14008bca9: 8b 40 14                    	movl	0x14(%rax), %eax
14008bcac: 48 8d 4d 10                 	leaq	0x10(%rbp), %rcx
14008bcb0: 48 89 4c 24 40              	movq	%rcx, 0x40(%rsp)
14008bcb5: 48 8b 8d f0 04 00 00        	movq	0x4f0(%rbp), %rcx
14008bcbc: 48 89 4c 24 38              	movq	%rcx, 0x38(%rsp)
14008bcc1: 48 89 5c 24 30              	movq	%rbx, 0x30(%rsp)
14008bcc6: 48 8b 8d d8 05 00 00        	movq	0x5d8(%rbp), %rcx
14008bccd: 48 89 4c 24 28              	movq	%rcx, 0x28(%rsp)
14008bcd2: 89 44 24 20                 	movl	%eax, 0x20(%rsp)
14008bcd6: 48 89 f1                    	movq	%rsi, %rcx
14008bcd9: 48 89 fa                    	movq	%rdi, %rdx
14008bcdc: e8 2f 6a 07 00              	callq	0x140102710 <.text+0x101710>
14008bce1: e9 d8 eb ff ff              	jmp	0x14008a8be <.text+0x898be>
14008bce6: 45 31 ed                    	xorl	%r13d, %r13d
14008bce9: 31 c0                       	xorl	%eax, %eax
14008bceb: e9 8b ef ff ff              	jmp	0x14008ac7b <.text+0x89c7b>
14008bcf0: c6 06 0a                    	movb	$0xa, (%rsi)
14008bcf3: 48 c7 46 08 0b 00 00 00     	movq	$0xb, 0x8(%rsi)
14008bcfb: e9 be eb ff ff              	jmp	0x14008a8be <.text+0x898be>
14008bd00: 4c 8d 0d 81 88 1d 00        	leaq	0x1d8881(%rip), %r9     # 0x140264588
14008bd07: eb 1d                       	jmp	0x14008bd26 <.text+0x8ad26>
14008bd09: 4c 8d 0d 60 88 1d 00        	leaq	0x1d8860(%rip), %r9     # 0x140264570
14008bd10: 41 b8 08 00 00 00           	movl	$0x8, %r8d
14008bd16: 31 c9                       	xorl	%ecx, %ecx
14008bd18: e8 13 7b 1c 00              	callq	0x140253830 <.text+0x252830>
14008bd1d: 0f 0b                       	ud2
14008bd1f: 4c 8d 0d 7a 88 1d 00        	leaq	0x1d887a(%rip), %r9     # 0x1402645a0
14008bd26: 41 b8 08 00 00 00           	movl	$0x8, %r8d
14008bd2c: 31 c9                       	xorl	%ecx, %ecx
14008bd2e: 48 89 c2                    	movq	%rax, %rdx
14008bd31: e8 fa 7a 1c 00              	callq	0x140253830 <.text+0x252830>
14008bd36: 0f 0b                       	ud2
14008bd38: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008bd3c: 48 8b bd c8 05 00 00        	movq	0x5c8(%rbp), %rdi
14008bd43: 0f 87 73 fc ff ff           	ja	0x14008b9bc <.text+0x8a9bc>
14008bd49: 49 8b 8f a8 01 00 00        	movq	0x1a8(%r15), %rcx
14008bd50: 4d 8b 87 b0 01 00 00        	movq	0x1b0(%r15), %r8
14008bd57: 48 85 d2                    	testq	%rdx, %rdx
14008bd5a: 74 36                       	je	0x14008bd92 <.text+0x8ad92>
14008bd5c: 4f 8d 0c 49                 	leaq	(%r9,%r9,2), %r9
14008bd60: 4e 8d 0c cd 90 02 00 00     	leaq	0x290(,%r9,8), %r9
14008bd68: 49 01 e9                    	addq	%rbp, %r9
14008bd6b: 66 41 83 79 f8 15           	cmpw	$0x15, -0x8(%r9)
14008bd71: 72 21                       	jb	0x14008bd94 <.text+0x8ad94>
14008bd73: 48 ff ca                    	decq	%rdx
14008bd76: 4d 8d 51 e8                 	leaq	-0x18(%r9), %r10
14008bd7a: 4d 8b 5a 10                 	movq	0x10(%r10), %r11
14008bd7e: 4d 89 59 10                 	movq	%r11, 0x10(%r9)
14008bd82: 41 0f 10 02                 	movups	(%r10), %xmm0
14008bd86: 41 0f 11 01                 	movups	%xmm0, (%r9)
14008bd8a: 4d 89 d1                    	movq	%r10, %r9
14008bd8d: 48 85 d2                    	testq	%rdx, %rdx
14008bd90: 75 d9                       	jne	0x14008bd6b <.text+0x8ad6b>
14008bd92: 31 d2                       	xorl	%edx, %edx
14008bd94: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008bd98: 48 89 8c d5 78 02 00 00     	movq	%rcx, 0x278(%rbp,%rdx,8)
14008bda0: 4c 89 84 d5 80 02 00 00     	movq	%r8, 0x280(%rbp,%rdx,8)
14008bda8: 66 c7 84 d5 88 02 00 00 14 00       	movw	$0x14, 0x288(%rbp,%rdx,8)
14008bdb2: 4c 8b 8d b8 04 00 00        	movq	0x4b8(%rbp), %r9
14008bdb9: 49 8d 51 01                 	leaq	0x1(%r9), %rdx
14008bdbd: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008bdc4: 3c 06                       	cmpb	$0x6, %al
14008bdc6: 0f 84 90 fa ff ff           	je	0x14008b85c <.text+0x8a85c>
14008bdcc: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008bdd0: 48 8b bd c8 05 00 00        	movq	0x5c8(%rbp), %rdi
14008bdd7: 0f 87 df fb ff ff           	ja	0x14008b9bc <.text+0x8a9bc>
14008bddd: 49 8b 8f b8 01 00 00        	movq	0x1b8(%r15), %rcx
14008bde4: 4d 8b 87 c0 01 00 00        	movq	0x1c0(%r15), %r8
14008bdeb: 48 85 d2                    	testq	%rdx, %rdx
14008bdee: 74 36                       	je	0x14008be26 <.text+0x8ae26>
14008bdf0: 4f 8d 0c 49                 	leaq	(%r9,%r9,2), %r9
14008bdf4: 4e 8d 0c cd 90 02 00 00     	leaq	0x290(,%r9,8), %r9
14008bdfc: 49 01 e9                    	addq	%rbp, %r9
14008bdff: 66 41 83 79 f8 15           	cmpw	$0x15, -0x8(%r9)
14008be05: 72 21                       	jb	0x14008be28 <.text+0x8ae28>
14008be07: 48 ff ca                    	decq	%rdx
14008be0a: 4d 8d 51 e8                 	leaq	-0x18(%r9), %r10
14008be0e: 4d 8b 5a 10                 	movq	0x10(%r10), %r11
14008be12: 4d 89 59 10                 	movq	%r11, 0x10(%r9)
14008be16: 41 0f 10 02                 	movups	(%r10), %xmm0
14008be1a: 41 0f 11 01                 	movups	%xmm0, (%r9)
14008be1e: 4d 89 d1                    	movq	%r10, %r9
14008be21: 48 85 d2                    	testq	%rdx, %rdx
14008be24: 75 d9                       	jne	0x14008bdff <.text+0x8adff>
14008be26: 31 d2                       	xorl	%edx, %edx
14008be28: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008be2c: 48 89 8c d5 78 02 00 00     	movq	%rcx, 0x278(%rbp,%rdx,8)
14008be34: 4c 89 84 d5 80 02 00 00     	movq	%r8, 0x280(%rbp,%rdx,8)
14008be3c: 66 c7 84 d5 88 02 00 00 14 00       	movw	$0x14, 0x288(%rbp,%rdx,8)
14008be46: 4c 8b 85 b8 04 00 00        	movq	0x4b8(%rbp), %r8
14008be4d: 49 8d 50 01                 	leaq	0x1(%r8), %rdx
14008be51: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008be58: 3c 07                       	cmpb	$0x7, %al
14008be5a: 0f 84 fc f9 ff ff           	je	0x14008b85c <.text+0x8a85c>
14008be60: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008be64: 48 8b bd c8 05 00 00        	movq	0x5c8(%rbp), %rdi
14008be6b: 0f 87 4b fb ff ff           	ja	0x14008b9bc <.text+0x8a9bc>
14008be71: 49 8b 87 c8 01 00 00        	movq	0x1c8(%r15), %rax
14008be78: 49 8b 8f d0 01 00 00        	movq	0x1d0(%r15), %rcx
14008be7f: 48 85 d2                    	testq	%rdx, %rdx
14008be82: 74 36                       	je	0x14008beba <.text+0x8aeba>
14008be84: 4f 8d 04 40                 	leaq	(%r8,%r8,2), %r8
14008be88: 4e 8d 04 c5 90 02 00 00     	leaq	0x290(,%r8,8), %r8
14008be90: 49 01 e8                    	addq	%rbp, %r8
14008be93: 66 41 83 78 f8 15           	cmpw	$0x15, -0x8(%r8)
14008be99: 72 21                       	jb	0x14008bebc <.text+0x8aebc>
14008be9b: 48 ff ca                    	decq	%rdx
14008be9e: 4d 8d 48 e8                 	leaq	-0x18(%r8), %r9
14008bea2: 4d 8b 51 10                 	movq	0x10(%r9), %r10
14008bea6: 4d 89 50 10                 	movq	%r10, 0x10(%r8)
14008beaa: 41 0f 10 01                 	movups	(%r9), %xmm0
14008beae: 41 0f 11 00                 	movups	%xmm0, (%r8)
14008beb2: 4d 89 c8                    	movq	%r9, %r8
14008beb5: 48 85 d2                    	testq	%rdx, %rdx
14008beb8: 75 d9                       	jne	0x14008be93 <.text+0x8ae93>
14008beba: 31 d2                       	xorl	%edx, %edx
14008bebc: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008bec0: 48 89 84 d5 78 02 00 00     	movq	%rax, 0x278(%rbp,%rdx,8)
14008bec8: 48 89 8c d5 80 02 00 00     	movq	%rcx, 0x280(%rbp,%rdx,8)
14008bed0: 66 c7 84 d5 88 02 00 00 14 00       	movw	$0x14, 0x288(%rbp,%rdx,8)
14008beda: 48 8b 95 b8 04 00 00        	movq	0x4b8(%rbp), %rdx
14008bee1: 48 ff c2                    	incq	%rdx
14008bee4: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008beeb: e9 6c f9 ff ff              	jmp	0x14008b85c <.text+0x8a85c>
14008bef0: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008bef4: 48 8b bd c8 05 00 00        	movq	0x5c8(%rbp), %rdi
14008befb: 0f 87 bb fa ff ff           	ja	0x14008b9bc <.text+0x8a9bc>
14008bf01: 49 8b 8f 38 01 00 00        	movq	0x138(%r15), %rcx
14008bf08: 4d 8b 87 40 01 00 00        	movq	0x140(%r15), %r8
14008bf0f: 48 85 d2                    	testq	%rdx, %rdx
14008bf12: 74 36                       	je	0x14008bf4a <.text+0x8af4a>
14008bf14: 4f 8d 0c 49                 	leaq	(%r9,%r9,2), %r9
14008bf18: 4e 8d 0c cd 90 02 00 00     	leaq	0x290(,%r9,8), %r9
14008bf20: 49 01 e9                    	addq	%rbp, %r9
14008bf23: 66 41 83 79 f8 09           	cmpw	$0x9, -0x8(%r9)
14008bf29: 72 21                       	jb	0x14008bf4c <.text+0x8af4c>
14008bf2b: 48 ff ca                    	decq	%rdx
14008bf2e: 4d 8d 51 e8                 	leaq	-0x18(%r9), %r10
14008bf32: 4d 8b 5a 10                 	movq	0x10(%r10), %r11
14008bf36: 4d 89 59 10                 	movq	%r11, 0x10(%r9)
14008bf3a: 41 0f 10 02                 	movups	(%r10), %xmm0
14008bf3e: 41 0f 11 01                 	movups	%xmm0, (%r9)
14008bf42: 4d 89 d1                    	movq	%r10, %r9
14008bf45: 48 85 d2                    	testq	%rdx, %rdx
14008bf48: 75 d9                       	jne	0x14008bf23 <.text+0x8af23>
14008bf4a: 31 d2                       	xorl	%edx, %edx
14008bf4c: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008bf50: 48 89 8c d5 78 02 00 00     	movq	%rcx, 0x278(%rbp,%rdx,8)
14008bf58: 4c 89 84 d5 80 02 00 00     	movq	%r8, 0x280(%rbp,%rdx,8)
14008bf60: 66 c7 84 d5 88 02 00 00 08 00       	movw	$0x8, 0x288(%rbp,%rdx,8)
14008bf6a: 4c 8b 85 b8 04 00 00        	movq	0x4b8(%rbp), %r8
14008bf71: 49 8d 50 01                 	leaq	0x1(%r8), %rdx
14008bf75: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008bf7c: 3c 07                       	cmpb	$0x7, %al
14008bf7e: 0f 84 98 f6 ff ff           	je	0x14008b61c <.text+0x8a61c>
14008bf84: 48 83 fa 17                 	cmpq	$0x17, %rdx
14008bf88: 48 8b bd c8 05 00 00        	movq	0x5c8(%rbp), %rdi
14008bf8f: 0f 87 27 fa ff ff           	ja	0x14008b9bc <.text+0x8a9bc>
14008bf95: 49 8b 87 48 01 00 00        	movq	0x148(%r15), %rax
14008bf9c: 49 8b 8f 50 01 00 00        	movq	0x150(%r15), %rcx
14008bfa3: 48 85 d2                    	testq	%rdx, %rdx
14008bfa6: 74 36                       	je	0x14008bfde <.text+0x8afde>
14008bfa8: 4f 8d 04 40                 	leaq	(%r8,%r8,2), %r8
14008bfac: 4e 8d 04 c5 90 02 00 00     	leaq	0x290(,%r8,8), %r8
14008bfb4: 49 01 e8                    	addq	%rbp, %r8
14008bfb7: 66 41 83 78 f8 09           	cmpw	$0x9, -0x8(%r8)
14008bfbd: 72 21                       	jb	0x14008bfe0 <.text+0x8afe0>
14008bfbf: 48 ff ca                    	decq	%rdx
14008bfc2: 4d 8d 48 e8                 	leaq	-0x18(%r8), %r9
14008bfc6: 4d 8b 51 10                 	movq	0x10(%r9), %r10
14008bfca: 4d 89 50 10                 	movq	%r10, 0x10(%r8)
14008bfce: 41 0f 10 01                 	movups	(%r9), %xmm0
14008bfd2: 41 0f 11 00                 	movups	%xmm0, (%r8)
14008bfd6: 4d 89 c8                    	movq	%r9, %r8
14008bfd9: 48 85 d2                    	testq	%rdx, %rdx
14008bfdc: 75 d9                       	jne	0x14008bfb7 <.text+0x8afb7>
14008bfde: 31 d2                       	xorl	%edx, %edx
14008bfe0: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008bfe4: 48 89 84 d5 78 02 00 00     	movq	%rax, 0x278(%rbp,%rdx,8)
14008bfec: 48 89 8c d5 80 02 00 00     	movq	%rcx, 0x280(%rbp,%rdx,8)
14008bff4: 66 c7 84 d5 88 02 00 00 08 00       	movw	$0x8, 0x288(%rbp,%rdx,8)
14008bffe: 48 8b 95 b8 04 00 00        	movq	0x4b8(%rbp), %rdx
14008c005: 48 ff c2                    	incq	%rdx
14008c008: 48 89 95 b8 04 00 00        	movq	%rdx, 0x4b8(%rbp)
14008c00f: 48 8b bd c8 05 00 00        	movq	0x5c8(%rbp), %rdi
14008c016: e9 a6 f0 ff ff              	jmp	0x14008b0c1 <.text+0x8a0c1>
14008c01b: 4c 8d 0d 4e 84 1d 00        	leaq	0x1d844e(%rip), %r9     # 0x140264470
14008c022: 41 b8 18 00 00 00           	movl	$0x18, %r8d
14008c028: 31 c9                       	xorl	%ecx, %ecx
14008c02a: e8 01 78 1c 00              	callq	0x140253830 <.text+0x252830>
14008c02f: 0f 0b                       	ud2
14008c031: 4c 8d 0d 48 be 1c 00        	leaq	0x1cbe48(%rip), %r9     # 0x140257e80
14008c038: 41 b8 28 00 00 00           	movl	$0x28, %r8d
14008c03e: 31 c9                       	xorl	%ecx, %ecx
14008c040: 48 89 c2                    	movq	%rax, %rdx
14008c043: e8 e8 77 1c 00              	callq	0x140253830 <.text+0x252830>
14008c048: 0f 0b                       	ud2
14008c04a: 4c 8d 0d 07 89 1d 00        	leaq	0x1d8907(%rip), %r9     # 0x140264958
14008c051: 41 b8 80 04 00 00           	movl	$0x480, %r8d            # imm = 0x480
14008c057: 31 c9                       	xorl	%ecx, %ecx
14008c059: e8 d2 77 1c 00              	callq	0x140253830 <.text+0x252830>
14008c05e: 0f 0b                       	ud2
14008c060: 48 89 f1                    	movq	%rsi, %rcx
14008c063: e8 18 8c 1c 00              	callq	0x140254c80 <.text+0x253c80>
14008c068: e9 51 e8 ff ff              	jmp	0x14008a8be <.text+0x898be>

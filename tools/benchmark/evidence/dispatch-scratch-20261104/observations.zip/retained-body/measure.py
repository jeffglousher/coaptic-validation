from pathlib import Path
import subprocess,json,hashlib,statistics,math,time,psutil
ROOT=Path(__file__).resolve().parent
CELLS=[(storage,security,mode) for storage in ['fixed','allocated'] for security in ['unprotected','oscore'] for mode in ['sync','async']]
N=1024
assert not (ROOT/'measurement.json').exists(),'Never replace an observed cohort'
def run(arm,cell,count,label):
 storage,security,mode=cell
 r=subprocess.run([str(ROOT/arm/'retained-probe.exe'),str(count),security,mode,storage],capture_output=True,timeout=15)
 (ROOT/(label+'.json')).write_bytes(r.stdout);(ROOT/(label+'.stderr')).write_bytes(r.stderr)
 assert r.returncode==0,(label,r.stderr.decode())
 x=json.loads(r.stdout)
 assert x['operations']==count and x['verified']==count+128 and x['warmup']==128
 assert (x['storage'],x['security'],x['mode'])==cell and x['payload_bytes']==11264
 assert x['requests_per_operation']==2 and x['data_packets_per_operation']==11
 assert len(x['cycles'])==count and all(type(v)==int and v>0 for v in x['cycles'])
 return statistics.mean(x['cycles']),x
hashes={arm:hashlib.sha256((ROOT/arm/'retained-probe.exe').read_bytes()).hexdigest() for arm in ['A','B']}
assert hashes['A']!=hashes['B']
method=json.loads((ROOT/'fixture.json').read_text())
method.update(baseline='dcf82cbb75d903bd9ab44ccd64ba3e6584bd6f93',candidate='07c616e29e25cba805df6f2fa098b6f437a66d97',binaries=hashes,cpu=0,features='coaptic std,alloc,oscore; diagnostics DISABLED',probe_sha256=hashlib.sha256((ROOT.parent/'fixture/probe/retained.rs').read_bytes()).hexdigest())
(ROOT/'METHOD.json').write_text(json.dumps(method,indent=2),encoding='utf-8')
process=psutil.Process();affinity=process.cpu_affinity();process.cpu_affinity([0])
rows=[];start=time.monotonic()
try:
 for cell in CELLS:
  _,a=run('A',cell,8,'qualify-A-'+'-'.join(cell));_,b=run('B',cell,8,'qualify-B-'+'-'.join(cell))
  assert a['app_inline_bytes']==b['app_inline_bytes']
 for pair,order in enumerate(['AB','BA','BA','AB']):
  for cell in CELLS:
   means={}
   for arm in order:
    assert time.monotonic()-start<180
    means[arm],_=run(arm,cell,N,f'measure-{pair}-'+'-'.join(cell)+'-'+arm)
   rows.append(dict(pair=pair,cell=cell,means=means,ratio=means['B']/means['A']))
 def interval(values):
  logs=list(map(math.log,values));mean=statistics.mean(logs)
  return dict(ratio=math.exp(mean),upper95=math.exp(mean+2.3533634348*statistics.stdev(logs)/math.sqrt(len(logs))))
 summary=[dict(cell=cell,**interval([r['ratio'] for r in rows if r['cell']==cell])) for cell in CELLS]
 groups={}
 for mode in ['sync','async','all']:
  groups[mode]=interval([math.exp(statistics.mean(math.log(r['ratio']) for r in rows if r['pair']==pair and (mode=='all' or r['cell'][2]==mode))) for pair in range(4)])
 result=dict(status='complete',rows=rows,summary=summary,groups=groups,seconds=time.monotonic()-start)
 (ROOT/'measurement.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 print(json.dumps(dict(summary=summary,groups=groups),indent=2))
except BaseException as e:
 (ROOT/'measurement.json').write_text(json.dumps(dict(status='failed',error=str(e),rows=rows),indent=2),encoding='utf-8');raise
finally: process.cpu_affinity(affinity)

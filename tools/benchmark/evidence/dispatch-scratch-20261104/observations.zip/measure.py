﻿from pathlib import Path
import subprocess,json,os,hashlib,shutil,statistics,math,time,psutil
ROOT=Path(__file__).resolve().parent
N=2048
PROFILES=['small-device','service-fixed','service-allocated']
CELLS=[(p,s,m) for p in PROFILES for s in ['unprotected','oscore'] for m in ['sync','async']]
def run(arm,cell,count,label):
 p,s,m=cell
 env=dict(os.environ);env.pop('COAPTIC_DISPATCH_ASYNC',None);env['COAPTIC_EXPIRY_PROBE']='steady'
 if m=='async':env['COAPTIC_DISPATCH_ASYNC']='1'
 cmd=[str(ROOT/arm/'dispatch-probe.exe'),str(count),s,'--'+p]+([] if p=='small-device' else ['1024'])
 r=subprocess.run(cmd,env=env,capture_output=True,timeout=10)
 (ROOT/(label+'.json')).write_bytes(r.stdout);(ROOT/(label+'.stderr')).write_bytes(r.stderr)
 assert r.returncode==0,(label,r.stderr.decode())
 x=json.loads(r.stdout);assert x['operations']==count and x['security']==s and x['black_box']
 if p=='small-device':
  values=x['latencies_cycles'];assert x['dedup']==4 and x['payload_bytes']==32
 else:
  values=x['server_poll_cpu_cycles_sum'];assert x['verified']==count+128
  assert x['server_poll_counts']==[1]*count and x['expiry_probe']=='steady'
  assert x['server_capacities']['dedup']==64 and x['payload_bytes']==1024
 assert len(values)==count and all(type(v)==int and v>=0 for v in values)
 return statistics.mean(values),x
assert not (ROOT/'measurement.json').exists(),'Never replace a measured cohort'
B=ROOT/'B';B.mkdir(exist_ok=True)
for name in ['dispatch-probe.exe','dispatch_probe.pdb']:shutil.copyfile(Path('D:/coaptic-batch-interop-target/release')/name,B/name)
hashes={arm:hashlib.sha256((ROOT/arm/'dispatch-probe.exe').read_bytes()).hexdigest() for arm in ['A','B']}
assert hashes['A']!=hashes['B'],'Candidate executable unchanged'
method={'baseline':'dcf82cbb75d903bd9ab44ccd64ba3e6584bd6f93','candidate':(ROOT/'candidate-source.txt').read_text(encoding='utf-8-sig').strip(),'operations':N,'warmup':128,'process_pairs':4,'orders':['AB','BA','BA','AB'],'cells':CELLS,'cpu':0,'binaries':hashes,'primary':'Geometric mean of12 equally weighted complete-server-App cell ratios, plus separate sync and async groups. Scoped development evidence, not sockets or peak memory.','guard':'Each cell point ratio<=1.02; four-pair one-sided95% Student-t(log-ratio) upper bounds reported, not hidden. Runtime benefit requires aggregate upper<1 in both execution modes.'}
(ROOT/'METHOD.json').write_text(json.dumps(method,indent=2),encoding='utf-8')
process=psutil.Process();original=process.cpu_affinity();process.cpu_affinity([0])
rows=[];start=time.monotonic()
try:
 for cell in CELLS:
  _,b=run('B',cell,8,'qualify-B-'+'-'.join(cell))
  a=json.loads((ROOT/('qualify-A-'+'-'.join(cell)+'.json')).read_bytes())
  for key in ['server_capacities','client_capacities','memory','routes','calls','deferred','security_requests','associations']:
   if key in a:assert a[key]==b[key],(cell,key)
 for pair,order in enumerate(method['orders']):
  for cell in CELLS:
   means={}
   for arm in order:
    assert time.monotonic()-start<180,'bounded measurement deadline'
    means[arm],_=run(arm,cell,N,f'measure-{pair}-'+ '-'.join(cell)+'-'+arm)
   rows.append({'pair':pair,'cell':cell,'means':means,'ratio':means['B']/means['A']})
 summary=[]
 def interval(values):
  logs=[math.log(v) for v in values];mean=statistics.mean(logs)
  return {'ratio':math.exp(mean),'upper95':math.exp(mean+2.3533634348*statistics.stdev(logs)/math.sqrt(len(logs)))}
 for cell in CELLS:
  result=interval([r['ratio'] for r in rows if r['cell']==cell]);result['cell']=cell;summary.append(result)
 groups={}
 for mode in ['sync','async','all']:
  values=[]
  for pair in range(4):
   selected=[r['ratio'] for r in rows if r['pair']==pair and (mode=='all' or r['cell'][2]==mode)]
   values.append(math.exp(statistics.mean(map(math.log,selected))))
  groups[mode]=interval(values)
 result={'status':'complete','seconds':time.monotonic()-start,'rows':rows,'summary':summary,'groups':groups}
 (ROOT/'measurement.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 print(json.dumps({'summary':summary,'groups':groups},indent=2))
except BaseException as e:
 (ROOT/'measurement.json').write_text(json.dumps({'status':'failed','error':str(e),'rows':rows},indent=2),encoding='utf-8')
 raise
finally:process.cpu_affinity(original)


D:\CoapticCurrent\dispatch-memory-20261104\response-scratch\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14008a4e0: 55                          	pushq	%rbp
14008a4e1: 41 57                       	pushq	%r15
14008a4e3: 41 56                       	pushq	%r14
14008a4e5: 41 55                       	pushq	%r13
14008a4e7: 41 54                       	pushq	%r12
14008a4e9: 56                          	pushq	%rsi
14008a4ea: 57                          	pushq	%rdi
14008a4eb: 53                          	pushq	%rbx
14008a4ec: 48 81 ec f8 02 00 00        	subq	$0x2f8, %rsp            # imm = 0x2F8
14008a4f3: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
14008a4fb: 49 89 d2                    	movq	%rdx, %r10
14008a4fe: 4c 8b a5 f8 02 00 00        	movq	0x2f8(%rbp), %r12
14008a505: 41 0f b6 94 24 57 02 00 00  	movzbl	0x257(%r12), %edx
14008a50e: 48 83 fa 09                 	cmpq	$0x9, %rdx
14008a512: 0f 83 b7 16 00 00           	jae	0x14008bbcf <.text+0x8abcf>
14008a518: 48 89 ce                    	movq	%rcx, %rsi
14008a51b: 48 85 d2                    	testq	%rdx, %rdx
14008a51e: 0f 85 c1 16 00 00           	jne	0x14008bbe5 <.text+0x8abe5>
14008a524: 41 0f b6 94 24 58 02 00 00  	movzbl	0x258(%r12), %edx
14008a52d: 48 83 fa 09                 	cmpq	$0x9, %rdx
14008a531: 0f 83 cc 16 00 00           	jae	0x14008bc03 <.text+0x8ac03>
14008a537: 48 85 d2                    	testq	%rdx, %rdx
14008a53a: 0f 85 a5 16 00 00           	jne	0x14008bbe5 <.text+0x8abe5>
14008a540: 41 0f b6 84 24 54 02 00 00  	movzbl	0x254(%r12), %eax
14008a549: 3c ff                       	cmpb	$-0x1, %al
14008a54b: 75 27                       	jne	0x14008a574 <.text+0x89574>
14008a54d: 41 0f b7 44 24 20           	movzwl	0x20(%r12), %eax
14008a553: 48 8d 0d ce 6d 1e 00        	leaq	0x1e6dce(%rip), %rcx    # 0x140271328
14008a55a: 48 63 14 81                 	movslq	(%rcx,%rax,4), %rdx
14008a55e: 48 01 ca                    	addq	%rcx, %rdx
14008a561: ff e2                       	jmpq	*%rdx
14008a563: 49 8b 44 24 30              	movq	0x30(%r12), %rax
14008a568: 49 39 84 24 f0 01 00 00     	cmpq	%rax, 0x1f0(%r12)
14008a570: 76 2c                       	jbe	0x14008a59e <.text+0x8959e>
14008a572: 31 c0                       	xorl	%eax, %eax
14008a574: c6 06 03                    	movb	$0x3, (%rsi)
14008a577: 88 46 01                    	movb	%al, 0x1(%rsi)
14008a57a: 48 81 c4 f8 02 00 00        	addq	$0x2f8, %rsp            # imm = 0x2F8
14008a581: 5b                          	popq	%rbx
14008a582: 5f                          	popq	%rdi
14008a583: 5e                          	popq	%rsi
14008a584: 41 5c                       	popq	%r12
14008a586: 41 5d                       	popq	%r13
14008a588: 41 5e                       	popq	%r14
14008a58a: 41 5f                       	popq	%r15
14008a58c: 5d                          	popq	%rbp
14008a58d: c3                          	retq
14008a58e: 41 0f b7 44 24 22           	movzwl	0x22(%r12), %eax
14008a594: 49 39 84 24 f0 01 00 00     	cmpq	%rax, 0x1f0(%r12)
14008a59c: 77 d4                       	ja	0x14008a572 <.text+0x89572>
14008a59e: 4c 89 85 48 01 00 00        	movq	%r8, 0x148(%rbp)
14008a5a5: 4c 89 95 40 01 00 00        	movq	%r10, 0x140(%rbp)
14008a5ac: 48 8b 85 30 03 00 00        	movq	0x330(%rbp), %rax
14008a5b3: 48 89 85 58 01 00 00        	movq	%rax, 0x158(%rbp)
14008a5ba: 48 8b 85 28 03 00 00        	movq	0x328(%rbp), %rax
14008a5c1: 48 89 85 60 01 00 00        	movq	%rax, 0x160(%rbp)
14008a5c8: 48 8b 85 20 03 00 00        	movq	0x320(%rbp), %rax
14008a5cf: 48 89 85 50 01 00 00        	movq	%rax, 0x150(%rbp)
14008a5d6: 48 8b 85 18 03 00 00        	movq	0x318(%rbp), %rax
14008a5dd: 48 89 85 08 01 00 00        	movq	%rax, 0x108(%rbp)
14008a5e4: 4c 8b b5 10 03 00 00        	movq	0x310(%rbp), %r14
14008a5eb: 48 8b 85 08 03 00 00        	movq	0x308(%rbp), %rax
14008a5f2: 48 89 45 20                 	movq	%rax, 0x20(%rbp)
14008a5f6: 48 8b 85 00 03 00 00        	movq	0x300(%rbp), %rax
14008a5fd: 48 89 45 28                 	movq	%rax, 0x28(%rbp)
14008a601: 4c 8b ad f0 02 00 00        	movq	0x2f0(%rbp), %r13
14008a608: 0f b7 85 e8 02 00 00        	movzwl	0x2e8(%rbp), %eax
14008a60f: 66 89 85 66 02 00 00        	movw	%ax, 0x266(%rbp)
14008a616: 0f b6 85 e0 02 00 00        	movzbl	0x2e0(%rbp), %eax
14008a61d: 88 85 77 02 00 00           	movb	%al, 0x277(%rbp)
14008a623: 66 41 83 bc 24 f8 01 00 00 01       	cmpw	$0x1, 0x1f8(%r12)
14008a62d: 4c 89 cb                    	movq	%r9, %rbx
14008a630: 75 24                       	jne	0x14008a656 <.text+0x89656>
14008a632: 41 0f b7 84 24 fa 01 00 00  	movzwl	0x1fa(%r12), %eax
14008a63b: 89 c1                       	movl	%eax, %ecx
14008a63d: 0f c9                       	bswapl	%ecx
14008a63f: 89 4d 40                    	movl	%ecx, 0x40(%rbp)
14008a642: f7 c1 00 00 ff 00           	testl	$0xff0000, %ecx         # imm = 0xFF0000
14008a648: 74 2e                       	je	0x14008a678 <.text+0x89678>
14008a64a: 48 8d 55 42                 	leaq	0x42(%rbp), %rdx
14008a64e: 41 bf 02 00 00 00           	movl	$0x2, %r15d
14008a654: eb 31                       	jmp	0x14008a687 <.text+0x89687>
14008a656: 45 31 ff                    	xorl	%r15d, %r15d
14008a659: 31 ff                       	xorl	%edi, %edi
14008a65b: 40 88 bd 86 01 00 00        	movb	%dil, 0x186(%rbp)
14008a662: 41 83 7c 24 10 01           	cmpl	$0x1, 0x10(%r12)
14008a668: 4c 89 7d 18                 	movq	%r15, 0x18(%rbp)
14008a66c: 74 5b                       	je	0x14008a6c9 <.text+0x896c9>
14008a66e: 45 31 ff                    	xorl	%r15d, %r15d
14008a671: 31 d2                       	xorl	%edx, %edx
14008a673: e9 dc 00 00 00              	jmp	0x14008a754 <.text+0x89754>
14008a678: 66 85 c0                    	testw	%ax, %ax
14008a67b: 74 7c                       	je	0x14008a6f9 <.text+0x896f9>
14008a67d: 48 8d 55 43                 	leaq	0x43(%rbp), %rdx
14008a681: 41 bf 01 00 00 00           	movl	$0x1, %r15d
14008a687: c7 85 98 01 00 00 00 00 00 00       	movl	$0x0, 0x198(%rbp)
14008a691: 48 8d 8d 98 01 00 00        	leaq	0x198(%rbp), %rcx
14008a698: 4d 89 f8                    	movq	%r15, %r8
14008a69b: e8 70 7a 1c 00              	callq	0x140252110 <.text+0x251110>
14008a6a0: 8b 85 98 01 00 00           	movl	0x198(%rbp), %eax
14008a6a6: 89 85 87 01 00 00           	movl	%eax, 0x187(%rbp)
14008a6ac: 44 88 bd 8b 01 00 00        	movb	%r15b, 0x18b(%rbp)
14008a6b3: 40 b7 01                    	movb	$0x1, %dil
14008a6b6: 40 88 bd 86 01 00 00        	movb	%dil, 0x186(%rbp)
14008a6bd: 41 83 7c 24 10 01           	cmpl	$0x1, 0x10(%r12)
14008a6c3: 4c 89 7d 18                 	movq	%r15, 0x18(%rbp)
14008a6c7: 75 a5                       	jne	0x14008a66e <.text+0x8966e>
14008a6c9: 41 8b 44 24 14              	movl	0x14(%r12), %eax
14008a6ce: 89 c1                       	movl	%eax, %ecx
14008a6d0: 0f c9                       	bswapl	%ecx
14008a6d2: 89 4d 40                    	movl	%ecx, 0x40(%rbp)
14008a6d5: 84 c9                       	testb	%cl, %cl
14008a6d7: 74 0c                       	je	0x14008a6e5 <.text+0x896e5>
14008a6d9: 41 bf 04 00 00 00           	movl	$0x4, %r15d
14008a6df: 48 8d 55 40                 	leaq	0x40(%rbp), %rdx
14008a6e3: eb 41                       	jmp	0x14008a726 <.text+0x89726>
14008a6e5: f7 c1 00 ff 00 00           	testl	$0xff00, %ecx           # imm = 0xFF00
14008a6eb: 74 13                       	je	0x14008a700 <.text+0x89700>
14008a6ed: 48 8d 55 41                 	leaq	0x41(%rbp), %rdx
14008a6f1: 41 bf 03 00 00 00           	movl	$0x3, %r15d
14008a6f7: eb 2d                       	jmp	0x14008a726 <.text+0x89726>
14008a6f9: 45 31 ff                    	xorl	%r15d, %r15d
14008a6fc: 31 c0                       	xorl	%eax, %eax
14008a6fe: eb a6                       	jmp	0x14008a6a6 <.text+0x896a6>
14008a700: f7 c1 00 00 ff 00           	testl	$0xff0000, %ecx         # imm = 0xFF0000
14008a706: 74 0c                       	je	0x14008a714 <.text+0x89714>
14008a708: 48 8d 55 42                 	leaq	0x42(%rbp), %rdx
14008a70c: 41 bf 02 00 00 00           	movl	$0x2, %r15d
14008a712: eb 12                       	jmp	0x14008a726 <.text+0x89726>
14008a714: 85 c0                       	testl	%eax, %eax
14008a716: 0f 84 96 14 00 00           	je	0x14008bbb2 <.text+0x8abb2>
14008a71c: 48 8d 55 43                 	leaq	0x43(%rbp), %rdx
14008a720: 41 bf 01 00 00 00           	movl	$0x1, %r15d
14008a726: c7 85 98 01 00 00 00 00 00 00       	movl	$0x0, 0x198(%rbp)
14008a730: 48 8d 8d 98 01 00 00        	leaq	0x198(%rbp), %rcx
14008a737: 4d 89 f8                    	movq	%r15, %r8
14008a73a: e8 d1 79 1c 00              	callq	0x140252110 <.text+0x251110>
14008a73f: 8b 85 98 01 00 00           	movl	0x198(%rbp), %eax
14008a745: 89 85 81 01 00 00           	movl	%eax, 0x181(%rbp)
14008a74b: 44 88 bd 85 01 00 00        	movb	%r15b, 0x185(%rbp)
14008a752: b2 01                       	movb	$0x1, %dl
14008a754: 88 95 80 01 00 00           	movb	%dl, 0x180(%rbp)
14008a75a: 41 8b 44 24 18              	movl	0x18(%r12), %eax
14008a75f: 89 85 2c 01 00 00           	movl	%eax, 0x12c(%rbp)
14008a765: 83 f8 01                    	cmpl	$0x1, %eax
14008a768: 4c 89 b5 68 02 00 00        	movq	%r14, 0x268(%rbp)
14008a76f: 4c 89 ad 10 01 00 00        	movq	%r13, 0x110(%rbp)
14008a776: 48 89 55 10                 	movq	%rdx, 0x10(%rbp)
14008a77a: 75 22                       	jne	0x14008a79e <.text+0x8979e>
14008a77c: b8 ff ff ff 00              	movl	$0xffffff, %eax         # imm = 0xFFFFFF
14008a781: 41 23 44 24 1c              	andl	0x1c(%r12), %eax
14008a786: 89 c1                       	movl	%eax, %ecx
14008a788: 0f c9                       	bswapl	%ecx
14008a78a: 89 4d 40                    	movl	%ecx, 0x40(%rbp)
14008a78d: 66 85 c9                    	testw	%cx, %cx
14008a790: 74 14                       	je	0x14008a7a6 <.text+0x897a6>
14008a792: 48 8d 55 41                 	leaq	0x41(%rbp), %rdx
14008a796: 41 bd 03 00 00 00           	movl	$0x3, %r13d
14008a79c: eb 2e                       	jmp	0x14008a7cc <.text+0x897cc>
14008a79e: 45 31 ed                    	xorl	%r13d, %r13d
14008a7a1: 45 31 f6                    	xorl	%r14d, %r14d
14008a7a4: eb 55                       	jmp	0x14008a7fb <.text+0x897fb>
14008a7a6: f7 c1 00 00 ff 00           	testl	$0xff0000, %ecx         # imm = 0xFF0000
14008a7ac: 74 0c                       	je	0x14008a7ba <.text+0x897ba>
14008a7ae: 48 8d 55 42                 	leaq	0x42(%rbp), %rdx
14008a7b2: 41 bd 02 00 00 00           	movl	$0x2, %r13d
14008a7b8: eb 12                       	jmp	0x14008a7cc <.text+0x897cc>
14008a7ba: 85 c0                       	testl	%eax, %eax
14008a7bc: 0f 84 d6 00 00 00           	je	0x14008a898 <.text+0x89898>
14008a7c2: 48 8d 55 43                 	leaq	0x43(%rbp), %rdx
14008a7c6: 41 bd 01 00 00 00           	movl	$0x1, %r13d
14008a7cc: c7 85 98 01 00 00 00 00 00 00       	movl	$0x0, 0x198(%rbp)
14008a7d6: 48 8d 8d 98 01 00 00        	leaq	0x198(%rbp), %rcx
14008a7dd: 4d 89 e8                    	movq	%r13, %r8
14008a7e0: e8 2b 79 1c 00              	callq	0x140252110 <.text+0x251110>
14008a7e5: 8b 85 98 01 00 00           	movl	0x198(%rbp), %eax
14008a7eb: 89 85 93 01 00 00           	movl	%eax, 0x193(%rbp)
14008a7f1: 44 88 ad 97 01 00 00        	movb	%r13b, 0x197(%rbp)
14008a7f8: 41 b6 01                    	movb	$0x1, %r14b
14008a7fb: 44 88 b5 92 01 00 00        	movb	%r14b, 0x192(%rbp)
14008a802: 48 8b 85 68 02 00 00        	movq	0x268(%rbp), %rax
14008a809: 48 8b 10                    	movq	(%rax), %rdx
14008a80c: 48 89 95 30 01 00 00        	movq	%rdx, 0x130(%rbp)
14008a813: 48 83 fa 02                 	cmpq	$0x2, %rdx
14008a817: 4c 89 7d 38                 	movq	%r15, 0x38(%rbp)
14008a81b: 48 89 9d 38 01 00 00        	movq	%rbx, 0x138(%rbp)
14008a822: 74 35                       	je	0x14008a859 <.text+0x89859>
14008a824: 48 8b 48 10                 	movq	0x10(%rax), %rcx
14008a828: 48 89 c8                    	movq	%rcx, %rax
14008a82b: 48 c1 e8 20                 	shrq	$0x20, %rax
14008a82f: 89 ca                       	movl	%ecx, %edx
14008a831: c1 e2 04                    	shll	$0x4, %edx
14008a834: 48 c1 e9 25                 	shrq	$0x25, %rcx
14008a838: 83 e1 08                    	andl	$0x8, %ecx
14008a83b: 09 d1                       	orl	%edx, %ecx
14008a83d: 0f b6 c0                    	movzbl	%al, %eax
14008a840: 09 c8                       	orl	%ecx, %eax
14008a842: 89 c1                       	movl	%eax, %ecx
14008a844: 0f c9                       	bswapl	%ecx
14008a846: 89 4d 40                    	movl	%ecx, 0x40(%rbp)
14008a849: 84 c9                       	testb	%cl, %cl
14008a84b: 74 23                       	je	0x14008a870 <.text+0x89870>
14008a84d: 41 bf 04 00 00 00           	movl	$0x4, %r15d
14008a853: 48 8d 55 40                 	leaq	0x40(%rbp), %rdx
14008a857: eb 5b                       	jmp	0x14008a8b4 <.text+0x898b4>
14008a859: c6 85 8c 01 00 00 00        	movb	$0x0, 0x18c(%rbp)
14008a860: 48 c7 85 18 01 00 00 00 00 00 00    	movq	$0x0, 0x118(%rbp)
14008a86b: e9 b3 00 00 00              	jmp	0x14008a923 <.text+0x89923>
14008a870: f7 c1 00 ff 00 00           	testl	$0xff00, %ecx           # imm = 0xFF00
14008a876: 74 0c                       	je	0x14008a884 <.text+0x89884>
14008a878: 48 8d 55 41                 	leaq	0x41(%rbp), %rdx
14008a87c: 41 bf 03 00 00 00           	movl	$0x3, %r15d
14008a882: eb 30                       	jmp	0x14008a8b4 <.text+0x898b4>
14008a884: f7 c1 00 00 ff 00           	testl	$0xff0000, %ecx         # imm = 0xFF0000
14008a88a: 74 16                       	je	0x14008a8a2 <.text+0x898a2>
14008a88c: 48 8d 55 42                 	leaq	0x42(%rbp), %rdx
14008a890: 41 bf 02 00 00 00           	movl	$0x2, %r15d
14008a896: eb 1c                       	jmp	0x14008a8b4 <.text+0x898b4>
14008a898: 45 31 ed                    	xorl	%r13d, %r13d
14008a89b: 31 c0                       	xorl	%eax, %eax
14008a89d: e9 49 ff ff ff              	jmp	0x14008a7eb <.text+0x897eb>
14008a8a2: 85 c0                       	testl	%eax, %eax
14008a8a4: 0f 84 12 13 00 00           	je	0x14008bbbc <.text+0x8abbc>
14008a8aa: 48 8d 55 43                 	leaq	0x43(%rbp), %rdx
14008a8ae: 41 bf 01 00 00 00           	movl	$0x1, %r15d
14008a8b4: c7 85 98 01 00 00 00 00 00 00       	movl	$0x0, 0x198(%rbp)
14008a8be: 48 8d 8d 98 01 00 00        	leaq	0x198(%rbp), %rcx
14008a8c5: 4d 89 f8                    	movq	%r15, %r8
14008a8c8: e8 43 78 1c 00              	callq	0x140252110 <.text+0x251110>
14008a8cd: 8b 85 98 01 00 00           	movl	0x198(%rbp), %eax
14008a8d3: 89 85 8d 01 00 00           	movl	%eax, 0x18d(%rbp)
14008a8d9: 4c 89 bd 18 01 00 00        	movq	%r15, 0x118(%rbp)
14008a8e0: 44 88 bd 91 01 00 00        	movb	%r15b, 0x191(%rbp)
14008a8e7: c6 85 8c 01 00 00 01        	movb	$0x1, 0x18c(%rbp)
14008a8ee: f6 85 30 01 00 00 01        	testb	$0x1, 0x130(%rbp)
14008a8f5: 74 2c                       	je	0x14008a923 <.text+0x89923>
14008a8f7: 48 8b 85 68 02 00 00        	movq	0x268(%rbp), %rax
14008a8fe: 48 8b 40 08                 	movq	0x8(%rax), %rax
14008a902: b9 ff ff ff ff              	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
14008a907: 48 39 c8                    	cmpq	%rcx, %rax
14008a90a: 48 0f 42 c8                 	cmovbq	%rax, %rcx
14008a90e: 0f c9                       	bswapl	%ecx
14008a910: 89 4d 40                    	movl	%ecx, 0x40(%rbp)
14008a913: 84 c9                       	testb	%cl, %cl
14008a915: 74 13                       	je	0x14008a92a <.text+0x8992a>
14008a917: 41 bf 04 00 00 00           	movl	$0x4, %r15d
14008a91d: 48 8d 55 40                 	leaq	0x40(%rbp), %rdx
14008a921: eb 42                       	jmp	0x14008a965 <.text+0x89965>
14008a923: 45 31 ff                    	xorl	%r15d, %r15d
14008a926: 31 db                       	xorl	%ebx, %ebx
14008a928: eb 69                       	jmp	0x14008a993 <.text+0x89993>
14008a92a: f7 c1 00 ff 00 00           	testl	$0xff00, %ecx           # imm = 0xFF00
14008a930: 74 0c                       	je	0x14008a93e <.text+0x8993e>
14008a932: 48 8d 55 41                 	leaq	0x41(%rbp), %rdx
14008a936: 41 bf 03 00 00 00           	movl	$0x3, %r15d
14008a93c: eb 27                       	jmp	0x14008a965 <.text+0x89965>
14008a93e: f7 c1 00 00 ff 00           	testl	$0xff0000, %ecx         # imm = 0xFF0000
14008a944: 74 0c                       	je	0x14008a952 <.text+0x89952>
14008a946: 48 8d 55 42                 	leaq	0x42(%rbp), %rdx
14008a94a: 41 bf 02 00 00 00           	movl	$0x2, %r15d
14008a950: eb 13                       	jmp	0x14008a965 <.text+0x89965>
14008a952: 48 85 c0                    	testq	%rax, %rax
14008a955: 0f 84 be 12 00 00           	je	0x14008bc19 <.text+0x8ac19>
14008a95b: 48 8d 55 43                 	leaq	0x43(%rbp), %rdx
14008a95f: 41 bf 01 00 00 00           	movl	$0x1, %r15d
14008a965: c7 85 98 01 00 00 00 00 00 00       	movl	$0x0, 0x198(%rbp)
14008a96f: 48 8d 8d 98 01 00 00        	leaq	0x198(%rbp), %rcx
14008a976: 4d 89 f8                    	movq	%r15, %r8
14008a979: e8 92 77 1c 00              	callq	0x140252110 <.text+0x251110>
14008a97e: 8b 85 98 01 00 00           	movl	0x198(%rbp), %eax
14008a984: 89 85 7b 01 00 00           	movl	%eax, 0x17b(%rbp)
14008a98a: 44 88 bd 7f 01 00 00        	movb	%r15b, 0x17f(%rbp)
14008a991: b3 01                       	movb	$0x1, %bl
14008a993: 88 9d 7a 01 00 00           	movb	%bl, 0x17a(%rbp)
14008a999: 48 8b 85 08 01 00 00        	movq	0x108(%rbp), %rax
14008a9a0: 4c 8b 00                    	movq	(%rax), %r8
14008a9a3: 49 83 f8 02                 	cmpq	$0x2, %r8
14008a9a7: 4c 89 45 30                 	movq	%r8, 0x30(%rbp)
14008a9ab: 75 12                       	jne	0x14008a9bf <.text+0x899bf>
14008a9ad: 48 c7 85 20 01 00 00 00 00 00 00    	movq	$0x0, 0x120(%rbp)
14008a9b8: 31 c0                       	xorl	%eax, %eax
14008a9ba: e9 c5 00 00 00              	jmp	0x14008aa84 <.text+0x89a84>
14008a9bf: 48 89 b5 68 01 00 00        	movq	%rsi, 0x168(%rbp)
14008a9c6: 4c 89 f6                    	movq	%r14, %rsi
14008a9c9: 48 8b 48 10                 	movq	0x10(%rax), %rcx
14008a9cd: 48 89 c8                    	movq	%rcx, %rax
14008a9d0: 48 c1 e8 20                 	shrq	$0x20, %rax
14008a9d4: 89 ca                       	movl	%ecx, %edx
14008a9d6: c1 e2 04                    	shll	$0x4, %edx
14008a9d9: 48 c1 e9 25                 	shrq	$0x25, %rcx
14008a9dd: 83 e1 08                    	andl	$0x8, %ecx
14008a9e0: 09 d1                       	orl	%edx, %ecx
14008a9e2: 0f b6 c0                    	movzbl	%al, %eax
14008a9e5: 09 c8                       	orl	%ecx, %eax
14008a9e7: 89 c1                       	movl	%eax, %ecx
14008a9e9: 0f c9                       	bswapl	%ecx
14008a9eb: 89 4d 40                    	movl	%ecx, 0x40(%rbp)
14008a9ee: 4d 89 ee                    	movq	%r13, %r14
14008a9f1: 49 89 fd                    	movq	%rdi, %r13
14008a9f4: 48 89 df                    	movq	%rbx, %rdi
14008a9f7: 84 c9                       	testb	%cl, %cl
14008a9f9: 74 0b                       	je	0x14008aa06 <.text+0x89a06>
14008a9fb: bb 04 00 00 00              	movl	$0x4, %ebx
14008aa00: 48 8d 55 40                 	leaq	0x40(%rbp), %rdx
14008aa04: eb 37                       	jmp	0x14008aa3d <.text+0x89a3d>
14008aa06: f7 c1 00 ff 00 00           	testl	$0xff00, %ecx           # imm = 0xFF00
14008aa0c: 74 0b                       	je	0x14008aa19 <.text+0x89a19>
14008aa0e: 48 8d 55 41                 	leaq	0x41(%rbp), %rdx
14008aa12: bb 03 00 00 00              	movl	$0x3, %ebx
14008aa17: eb 24                       	jmp	0x14008aa3d <.text+0x89a3d>
14008aa19: f7 c1 00 00 ff 00           	testl	$0xff0000, %ecx         # imm = 0xFF0000
14008aa1f: 74 0b                       	je	0x14008aa2c <.text+0x89a2c>
14008aa21: 48 8d 55 42                 	leaq	0x42(%rbp), %rdx
14008aa25: bb 02 00 00 00              	movl	$0x2, %ebx
14008aa2a: eb 11                       	jmp	0x14008aa3d <.text+0x89a3d>
14008aa2c: 85 c0                       	testl	%eax, %eax
14008aa2e: 0f 84 92 11 00 00           	je	0x14008bbc6 <.text+0x8abc6>
14008aa34: 48 8d 55 43                 	leaq	0x43(%rbp), %rdx
14008aa38: bb 01 00 00 00              	movl	$0x1, %ebx
14008aa3d: c7 85 98 01 00 00 00 00 00 00       	movl	$0x0, 0x198(%rbp)
14008aa47: 48 8d 8d 98 01 00 00        	leaq	0x198(%rbp), %rcx
14008aa4e: 49 89 d8                    	movq	%rbx, %r8
14008aa51: e8 ba 76 1c 00              	callq	0x140252110 <.text+0x251110>
14008aa56: 8b 85 98 01 00 00           	movl	0x198(%rbp), %eax
14008aa5c: 89 85 75 01 00 00           	movl	%eax, 0x175(%rbp)
14008aa62: 48 89 9d 20 01 00 00        	movq	%rbx, 0x120(%rbp)
14008aa69: 88 9d 79 01 00 00           	movb	%bl, 0x179(%rbp)
14008aa6f: b0 01                       	movb	$0x1, %al
14008aa71: 48 89 fb                    	movq	%rdi, %rbx
14008aa74: 4c 89 ef                    	movq	%r13, %rdi
14008aa77: 4d 89 f5                    	movq	%r14, %r13
14008aa7a: 49 89 f6                    	movq	%rsi, %r14
14008aa7d: 48 8b b5 68 01 00 00        	movq	0x168(%rbp), %rsi
14008aa84: 48 89 85 68 01 00 00        	movq	%rax, 0x168(%rbp)
14008aa8b: 88 85 74 01 00 00           	movb	%al, 0x174(%rbp)
14008aa91: 41 0f 10 84 24 26 02 00 00  	movups	0x226(%r12), %xmm0
14008aa9a: 41 0f 10 8c 24 36 02 00 00  	movups	0x236(%r12), %xmm1
14008aaa3: 41 0f 10 94 24 40 02 00 00  	movups	0x240(%r12), %xmm2
14008aaac: 0f 11 55 fa                 	movups	%xmm2, -0x6(%rbp)
14008aab0: 0f 29 4d f0                 	movaps	%xmm1, -0x10(%rbp)
14008aab4: 0f 29 45 e0                 	movaps	%xmm0, -0x20(%rbp)
14008aab8: 0f 10 05 d1 fa 1d 00        	movups	0x1dfad1(%rip), %xmm0   # 0x14026a590
14008aabf: 0f 29 45 40                 	movaps	%xmm0, 0x40(%rbp)
14008aac3: 48 c7 45 50 00 00 00 00     	movq	$0x0, 0x50(%rbp)
14008aacb: 0f 11 45 58                 	movups	%xmm0, 0x58(%rbp)
14008aacf: 48 c7 45 68 00 00 00 00     	movq	$0x0, 0x68(%rbp)
14008aad7: 0f 29 45 70                 	movaps	%xmm0, 0x70(%rbp)
14008aadb: 48 c7 85 80 00 00 00 00 00 00 00    	movq	$0x0, 0x80(%rbp)
14008aae6: 0f 11 85 88 00 00 00        	movups	%xmm0, 0x88(%rbp)
14008aaed: 48 c7 85 98 00 00 00 00 00 00 00    	movq	$0x0, 0x98(%rbp)
14008aaf8: 0f 29 85 a0 00 00 00        	movaps	%xmm0, 0xa0(%rbp)
14008aaff: 48 c7 85 b0 00 00 00 00 00 00 00    	movq	$0x0, 0xb0(%rbp)
14008ab0a: 0f 11 85 b8 00 00 00        	movups	%xmm0, 0xb8(%rbp)
14008ab11: 48 c7 85 c8 00 00 00 00 00 00 00    	movq	$0x0, 0xc8(%rbp)
14008ab1c: 0f 29 85 d0 00 00 00        	movaps	%xmm0, 0xd0(%rbp)
14008ab23: 48 c7 85 e0 00 00 00 00 00 00 00    	movq	$0x0, 0xe0(%rbp)
14008ab2e: 0f 11 85 e8 00 00 00        	movups	%xmm0, 0xe8(%rbp)
14008ab35: 48 c7 85 f8 00 00 00 00 00 00 00    	movq	$0x0, 0xf8(%rbp)
14008ab40: 48 8d 8d 98 01 00 00        	leaq	0x198(%rbp), %rcx
14008ab47: 48 8d 55 40                 	leaq	0x40(%rbp), %rdx
14008ab4b: 41 b8 c0 00 00 00           	movl	$0xc0, %r8d
14008ab51: e8 ba 75 1c 00              	callq	0x140252110 <.text+0x251110>
14008ab56: 48 c7 85 58 02 00 00 00 00 00 00    	movq	$0x0, 0x258(%rbp)
14008ab61: 41 0f b6 94 24 56 02 00 00  	movzbl	0x256(%r12), %edx
14008ab6a: 48 85 d2                    	testq	%rdx, %rdx
14008ab6d: 74 4d                       	je	0x14008abbc <.text+0x89bbc>
14008ab6f: 80 fa 09                    	cmpb	$0x9, %dl
14008ab72: 0f 83 b3 10 00 00           	jae	0x14008bc2b <.text+0x8ac2b>
14008ab78: 49 8d 84 24 d8 01 00 00     	leaq	0x1d8(%r12), %rax
14008ab80: 48 89 85 98 01 00 00        	movq	%rax, 0x198(%rbp)
14008ab87: 48 89 95 a0 01 00 00        	movq	%rdx, 0x1a0(%rbp)
14008ab8e: 66 c7 85 a8 01 00 00 04 00  	movw	$0x4, 0x1a8(%rbp)
14008ab97: 48 c7 85 58 02 00 00 01 00 00 00    	movq	$0x1, 0x258(%rbp)
14008aba2: ba 01 00 00 00              	movl	$0x1, %edx
14008aba7: 45 84 f6                    	testb	%r14b, %r14b
14008abaa: 74 45                       	je	0x14008abf1 <.text+0x89bf1>
14008abac: 48 8d 85 b0 01 00 00        	leaq	0x1b0(%rbp), %rax
14008abb3: 48 8d 8d 93 01 00 00        	leaq	0x193(%rbp), %rcx
14008abba: eb 17                       	jmp	0x14008abd3 <.text+0x89bd3>
14008abbc: 45 84 f6                    	testb	%r14b, %r14b
14008abbf: 0f 84 4e 02 00 00           	je	0x14008ae13 <.text+0x89e13>
14008abc5: 48 8d 8d 93 01 00 00        	leaq	0x193(%rbp), %rcx
14008abcc: 48 8d 85 98 01 00 00        	leaq	0x198(%rbp), %rax
14008abd3: 48 89 08                    	movq	%rcx, (%rax)
14008abd6: 4c 89 68 08                 	movq	%r13, 0x8(%rax)
14008abda: 66 c7 40 10 06 00           	movw	$0x6, 0x10(%rax)
14008abe0: 48 8b 95 58 02 00 00        	movq	0x258(%rbp), %rdx
14008abe7: 48 ff c2                    	incq	%rdx
14008abea: 48 89 95 58 02 00 00        	movq	%rdx, 0x258(%rbp)
14008abf1: 40 84 ff                    	testb	%dil, %dil
14008abf4: 0f 84 24 02 00 00           	je	0x14008ae1e <.text+0x89e1e>
14008abfa: 48 83 fa 07                 	cmpq	$0x7, %rdx
14008abfe: 4c 8b ad 68 02 00 00        	movq	0x268(%rbp), %r13
14008ac05: 0f 87 bc 0b 00 00           	ja	0x14008b7c7 <.text+0x8a7c7>
14008ac0b: 48 8d 85 87 01 00 00        	leaq	0x187(%rbp), %rax
14008ac12: 48 85 d2                    	testq	%rdx, %rdx
14008ac15: 0f 84 f0 01 00 00           	je	0x14008ae0b <.text+0x89e0b>
14008ac1b: 4c 8d 42 ff                 	leaq	-0x1(%rdx), %r8
14008ac1f: 4f 8d 14 40                 	leaq	(%r8,%r8,2), %r10
14008ac23: 66 42 83 bc d5 a8 01 00 00 0d       	cmpw	$0xd, 0x1a8(%rbp,%r10,8)
14008ac2d: 0f 82 0e 04 00 00           	jb	0x14008b041 <.text+0x8a041>
14008ac33: 4e 8d 0c d5 98 01 00 00     	leaq	0x198(,%r10,8), %r9
14008ac3b: 49 01 e9                    	addq	%rbp, %r9
14008ac3e: 48 8d 0c 52                 	leaq	(%rdx,%rdx,2), %rcx
14008ac42: 4d 8b 59 10                 	movq	0x10(%r9), %r11
14008ac46: 4c 89 9c cd a8 01 00 00     	movq	%r11, 0x1a8(%rbp,%rcx,8)
14008ac4e: 41 0f 10 01                 	movups	(%r9), %xmm0
14008ac52: 0f 11 84 cd 98 01 00 00     	movups	%xmm0, 0x198(%rbp,%rcx,8)
14008ac5a: 4d 85 c0                    	testq	%r8, %r8
14008ac5d: 0f 84 a8 01 00 00           	je	0x14008ae0b <.text+0x89e0b>
14008ac63: 4c 8d 5a fe                 	leaq	-0x2(%rdx), %r11
14008ac67: 4f 8d 0c 5b                 	leaq	(%r11,%r11,2), %r9
14008ac6b: 66 42 83 bc cd a8 01 00 00 0d       	cmpw	$0xd, 0x1a8(%rbp,%r9,8)
14008ac75: 0f 82 c9 03 00 00           	jb	0x14008b044 <.text+0x8a044>
14008ac7b: 4e 8d 04 cd 98 01 00 00     	leaq	0x198(,%r9,8), %r8
14008ac83: 49 01 e8                    	addq	%rbp, %r8
14008ac86: 49 8b 78 10                 	movq	0x10(%r8), %rdi
14008ac8a: 4a 89 bc d5 a8 01 00 00     	movq	%rdi, 0x1a8(%rbp,%r10,8)
14008ac92: 41 0f 10 00                 	movups	(%r8), %xmm0
14008ac96: 42 0f 11 84 d5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r10,8)
14008ac9f: 4d 85 db                    	testq	%r11, %r11
14008aca2: 0f 84 63 01 00 00           	je	0x14008ae0b <.text+0x89e0b>
14008aca8: 48 8d 7a fd                 	leaq	-0x3(%rdx), %rdi
14008acac: 4c 8d 14 7f                 	leaq	(%rdi,%rdi,2), %r10
14008acb0: 66 42 83 bc d5 a8 01 00 00 0d       	cmpw	$0xd, 0x1a8(%rbp,%r10,8)
14008acba: 4d 89 d8                    	movq	%r11, %r8
14008acbd: 0f 82 81 03 00 00           	jb	0x14008b044 <.text+0x8a044>
14008acc3: 4e 8d 04 d5 98 01 00 00     	leaq	0x198(,%r10,8), %r8
14008accb: 49 01 e8                    	addq	%rbp, %r8
14008acce: 4d 8b 58 10                 	movq	0x10(%r8), %r11
14008acd2: 4e 89 9c cd a8 01 00 00     	movq	%r11, 0x1a8(%rbp,%r9,8)
14008acda: 41 0f 10 00                 	movups	(%r8), %xmm0
14008acde: 42 0f 11 84 cd 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r9,8)
14008ace7: 48 85 ff                    	testq	%rdi, %rdi
14008acea: 0f 84 1b 01 00 00           	je	0x14008ae0b <.text+0x89e0b>
14008acf0: 4c 8d 72 fc                 	leaq	-0x4(%rdx), %r14
14008acf4: 4f 8d 1c 76                 	leaq	(%r14,%r14,2), %r11
14008acf8: 66 42 83 bc dd a8 01 00 00 0d       	cmpw	$0xd, 0x1a8(%rbp,%r11,8)
14008ad02: 49 89 f8                    	movq	%rdi, %r8
14008ad05: 0f 82 39 03 00 00           	jb	0x14008b044 <.text+0x8a044>
14008ad0b: 4e 8d 04 dd 98 01 00 00     	leaq	0x198(,%r11,8), %r8
14008ad13: 49 01 e8                    	addq	%rbp, %r8
14008ad16: 4d 8b 48 10                 	movq	0x10(%r8), %r9
14008ad1a: 4e 89 8c d5 a8 01 00 00     	movq	%r9, 0x1a8(%rbp,%r10,8)
14008ad22: 41 0f 10 00                 	movups	(%r8), %xmm0
14008ad26: 42 0f 11 84 d5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r10,8)
14008ad2f: 4d 85 f6                    	testq	%r14, %r14
14008ad32: 0f 84 d3 00 00 00           	je	0x14008ae0b <.text+0x89e0b>
14008ad38: 48 8d 7a fb                 	leaq	-0x5(%rdx), %rdi
14008ad3c: 4c 8d 0c 7f                 	leaq	(%rdi,%rdi,2), %r9
14008ad40: 66 42 83 bc cd a8 01 00 00 0d       	cmpw	$0xd, 0x1a8(%rbp,%r9,8)
14008ad4a: 4d 89 f0                    	movq	%r14, %r8
14008ad4d: 0f 82 f1 02 00 00           	jb	0x14008b044 <.text+0x8a044>
14008ad53: 4e 8d 04 cd 98 01 00 00     	leaq	0x198(,%r9,8), %r8
14008ad5b: 49 01 e8                    	addq	%rbp, %r8
14008ad5e: 4d 8b 50 10                 	movq	0x10(%r8), %r10
14008ad62: 4e 89 94 dd a8 01 00 00     	movq	%r10, 0x1a8(%rbp,%r11,8)
14008ad6a: 41 0f 10 00                 	movups	(%r8), %xmm0
14008ad6e: 42 0f 11 84 dd 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r11,8)
14008ad77: 48 85 ff                    	testq	%rdi, %rdi
14008ad7a: 0f 84 8b 00 00 00           	je	0x14008ae0b <.text+0x89e0b>
14008ad80: 48 83 c2 fa                 	addq	$-0x6, %rdx
14008ad84: 4c 8d 14 52                 	leaq	(%rdx,%rdx,2), %r10
14008ad88: 66 42 83 bc d5 a8 01 00 00 0d       	cmpw	$0xd, 0x1a8(%rbp,%r10,8)
14008ad92: 49 89 f8                    	movq	%rdi, %r8
14008ad95: 0f 82 a9 02 00 00           	jb	0x14008b044 <.text+0x8a044>
14008ad9b: 4e 8d 04 d5 98 01 00 00     	leaq	0x198(,%r10,8), %r8
14008ada3: 49 01 e8                    	addq	%rbp, %r8
14008ada6: 4d 8b 58 10                 	movq	0x10(%r8), %r11
14008adaa: 4e 89 9c cd a8 01 00 00     	movq	%r11, 0x1a8(%rbp,%r9,8)
14008adb2: 41 0f 10 00                 	movups	(%r8), %xmm0
14008adb6: 42 0f 11 84 cd 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r9,8)
14008adbf: 48 85 d2                    	testq	%rdx, %rdx
14008adc2: 0f 84 ea 0e 00 00           	je	0x14008bcb2 <.text+0x8acb2>
14008adc8: 66 83 bc cd 00 01 00 00 0d  	cmpw	$0xd, 0x100(%rbp,%rcx,8)
14008add1: 49 89 d0                    	movq	%rdx, %r8
14008add4: 4c 8b ad 68 02 00 00        	movq	0x268(%rbp), %r13
14008addb: 0f 82 63 02 00 00           	jb	0x14008b044 <.text+0x8a044>
14008ade1: 48 8d 0c cd 98 01 00 00     	leaq	0x198(,%rcx,8), %rcx
14008ade9: 48 01 e9                    	addq	%rbp, %rcx
14008adec: 48 8b 91 68 ff ff ff        	movq	-0x98(%rcx), %rdx
14008adf3: 4a 89 94 d5 a8 01 00 00     	movq	%rdx, 0x1a8(%rbp,%r10,8)
14008adfb: 0f 10 81 58 ff ff ff        	movups	-0xa8(%rcx), %xmm0
14008ae02: 42 0f 11 84 d5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r10,8)
14008ae0b: 45 31 c0                    	xorl	%r8d, %r8d
14008ae0e: e9 31 02 00 00              	jmp	0x14008b044 <.text+0x8a044>
14008ae13: 31 d2                       	xorl	%edx, %edx
14008ae15: 40 84 ff                    	testb	%dil, %dil
14008ae18: 0f 85 dc fd ff ff           	jne	0x14008abfa <.text+0x89bfa>
14008ae1e: 4c 8b ad 68 02 00 00        	movq	0x268(%rbp), %r13
14008ae25: 80 7d 10 00                 	cmpb	$0x0, 0x10(%rbp)
14008ae29: 0f 84 52 02 00 00           	je	0x14008b081 <.text+0x8a081>
14008ae2f: 48 83 fa 07                 	cmpq	$0x7, %rdx
14008ae33: 0f 87 8e 09 00 00           	ja	0x14008b7c7 <.text+0x8a7c7>
14008ae39: 48 8d 85 81 01 00 00        	leaq	0x181(%rbp), %rax
14008ae40: 48 85 d2                    	testq	%rdx, %rdx
14008ae43: 0f 84 f0 01 00 00           	je	0x14008b039 <.text+0x8a039>
14008ae49: 4c 8d 42 ff                 	leaq	-0x1(%rdx), %r8
14008ae4d: 4f 8d 14 40                 	leaq	(%r8,%r8,2), %r10
14008ae51: 66 42 83 bc d5 a8 01 00 00 0f       	cmpw	$0xf, 0x1a8(%rbp,%r10,8)
14008ae5b: 0f 82 8d 06 00 00           	jb	0x14008b4ee <.text+0x8a4ee>
14008ae61: 4e 8d 0c d5 98 01 00 00     	leaq	0x198(,%r10,8), %r9
14008ae69: 49 01 e9                    	addq	%rbp, %r9
14008ae6c: 48 8d 0c 52                 	leaq	(%rdx,%rdx,2), %rcx
14008ae70: 4d 8b 59 10                 	movq	0x10(%r9), %r11
14008ae74: 4c 89 9c cd a8 01 00 00     	movq	%r11, 0x1a8(%rbp,%rcx,8)
14008ae7c: 41 0f 10 01                 	movups	(%r9), %xmm0
14008ae80: 0f 11 84 cd 98 01 00 00     	movups	%xmm0, 0x198(%rbp,%rcx,8)
14008ae88: 4d 85 c0                    	testq	%r8, %r8
14008ae8b: 0f 84 a8 01 00 00           	je	0x14008b039 <.text+0x8a039>
14008ae91: 4c 8d 5a fe                 	leaq	-0x2(%rdx), %r11
14008ae95: 4f 8d 0c 5b                 	leaq	(%r11,%r11,2), %r9
14008ae99: 66 42 83 bc cd a8 01 00 00 0f       	cmpw	$0xf, 0x1a8(%rbp,%r9,8)
14008aea3: 0f 82 48 06 00 00           	jb	0x14008b4f1 <.text+0x8a4f1>
14008aea9: 4e 8d 04 cd 98 01 00 00     	leaq	0x198(,%r9,8), %r8
14008aeb1: 49 01 e8                    	addq	%rbp, %r8
14008aeb4: 49 8b 78 10                 	movq	0x10(%r8), %rdi
14008aeb8: 4a 89 bc d5 a8 01 00 00     	movq	%rdi, 0x1a8(%rbp,%r10,8)
14008aec0: 41 0f 10 00                 	movups	(%r8), %xmm0
14008aec4: 42 0f 11 84 d5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r10,8)
14008aecd: 4d 85 db                    	testq	%r11, %r11
14008aed0: 0f 84 63 01 00 00           	je	0x14008b039 <.text+0x8a039>
14008aed6: 48 8d 7a fd                 	leaq	-0x3(%rdx), %rdi
14008aeda: 4c 8d 14 7f                 	leaq	(%rdi,%rdi,2), %r10
14008aede: 66 42 83 bc d5 a8 01 00 00 0f       	cmpw	$0xf, 0x1a8(%rbp,%r10,8)
14008aee8: 4d 89 d8                    	movq	%r11, %r8
14008aeeb: 0f 82 00 06 00 00           	jb	0x14008b4f1 <.text+0x8a4f1>
14008aef1: 4e 8d 04 d5 98 01 00 00     	leaq	0x198(,%r10,8), %r8
14008aef9: 49 01 e8                    	addq	%rbp, %r8
14008aefc: 4d 8b 58 10                 	movq	0x10(%r8), %r11
14008af00: 4e 89 9c cd a8 01 00 00     	movq	%r11, 0x1a8(%rbp,%r9,8)
14008af08: 41 0f 10 00                 	movups	(%r8), %xmm0
14008af0c: 42 0f 11 84 cd 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r9,8)
14008af15: 48 85 ff                    	testq	%rdi, %rdi
14008af18: 0f 84 1b 01 00 00           	je	0x14008b039 <.text+0x8a039>
14008af1e: 4c 8d 72 fc                 	leaq	-0x4(%rdx), %r14
14008af22: 4f 8d 1c 76                 	leaq	(%r14,%r14,2), %r11
14008af26: 66 42 83 bc dd a8 01 00 00 0f       	cmpw	$0xf, 0x1a8(%rbp,%r11,8)
14008af30: 49 89 f8                    	movq	%rdi, %r8
14008af33: 0f 82 b8 05 00 00           	jb	0x14008b4f1 <.text+0x8a4f1>
14008af39: 4e 8d 04 dd 98 01 00 00     	leaq	0x198(,%r11,8), %r8
14008af41: 49 01 e8                    	addq	%rbp, %r8
14008af44: 4d 8b 48 10                 	movq	0x10(%r8), %r9
14008af48: 4e 89 8c d5 a8 01 00 00     	movq	%r9, 0x1a8(%rbp,%r10,8)
14008af50: 41 0f 10 00                 	movups	(%r8), %xmm0
14008af54: 42 0f 11 84 d5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r10,8)
14008af5d: 4d 85 f6                    	testq	%r14, %r14
14008af60: 0f 84 d3 00 00 00           	je	0x14008b039 <.text+0x8a039>
14008af66: 48 8d 7a fb                 	leaq	-0x5(%rdx), %rdi
14008af6a: 4c 8d 0c 7f                 	leaq	(%rdi,%rdi,2), %r9
14008af6e: 66 42 83 bc cd a8 01 00 00 0f       	cmpw	$0xf, 0x1a8(%rbp,%r9,8)
14008af78: 4d 89 f0                    	movq	%r14, %r8
14008af7b: 0f 82 70 05 00 00           	jb	0x14008b4f1 <.text+0x8a4f1>
14008af81: 4e 8d 04 cd 98 01 00 00     	leaq	0x198(,%r9,8), %r8
14008af89: 49 01 e8                    	addq	%rbp, %r8
14008af8c: 4d 8b 50 10                 	movq	0x10(%r8), %r10
14008af90: 4e 89 94 dd a8 01 00 00     	movq	%r10, 0x1a8(%rbp,%r11,8)
14008af98: 41 0f 10 00                 	movups	(%r8), %xmm0
14008af9c: 42 0f 11 84 dd 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r11,8)
14008afa5: 48 85 ff                    	testq	%rdi, %rdi
14008afa8: 0f 84 8b 00 00 00           	je	0x14008b039 <.text+0x8a039>
14008afae: 48 83 c2 fa                 	addq	$-0x6, %rdx
14008afb2: 4c 8d 14 52                 	leaq	(%rdx,%rdx,2), %r10
14008afb6: 66 42 83 bc d5 a8 01 00 00 0f       	cmpw	$0xf, 0x1a8(%rbp,%r10,8)
14008afc0: 49 89 f8                    	movq	%rdi, %r8
14008afc3: 0f 82 28 05 00 00           	jb	0x14008b4f1 <.text+0x8a4f1>
14008afc9: 4e 8d 04 d5 98 01 00 00     	leaq	0x198(,%r10,8), %r8
14008afd1: 49 01 e8                    	addq	%rbp, %r8
14008afd4: 4d 8b 58 10                 	movq	0x10(%r8), %r11
14008afd8: 4e 89 9c cd a8 01 00 00     	movq	%r11, 0x1a8(%rbp,%r9,8)
14008afe0: 41 0f 10 00                 	movups	(%r8), %xmm0
14008afe4: 42 0f 11 84 cd 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r9,8)
14008afed: 48 85 d2                    	testq	%rdx, %rdx
14008aff0: 0f 84 cb 0c 00 00           	je	0x14008bcc1 <.text+0x8acc1>
14008aff6: 66 83 bc cd 00 01 00 00 0f  	cmpw	$0xf, 0x100(%rbp,%rcx,8)
14008afff: 49 89 d0                    	movq	%rdx, %r8
14008b002: 4c 8b ad 68 02 00 00        	movq	0x268(%rbp), %r13
14008b009: 0f 82 e2 04 00 00           	jb	0x14008b4f1 <.text+0x8a4f1>
14008b00f: 48 8d 0c cd 98 01 00 00     	leaq	0x198(,%rcx,8), %rcx
14008b017: 48 01 e9                    	addq	%rbp, %rcx
14008b01a: 48 8b 91 68 ff ff ff        	movq	-0x98(%rcx), %rdx
14008b021: 4a 89 94 d5 a8 01 00 00     	movq	%rdx, 0x1a8(%rbp,%r10,8)
14008b029: 0f 10 81 58 ff ff ff        	movups	-0xa8(%rcx), %xmm0
14008b030: 42 0f 11 84 d5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r10,8)
14008b039: 45 31 c0                    	xorl	%r8d, %r8d
14008b03c: e9 b0 04 00 00              	jmp	0x14008b4f1 <.text+0x8a4f1>
14008b041: 49 89 d0                    	movq	%rdx, %r8
14008b044: 4b 8d 0c 40                 	leaq	(%r8,%r8,2), %rcx
14008b048: 48 89 84 cd 98 01 00 00     	movq	%rax, 0x198(%rbp,%rcx,8)
14008b050: 48 8b 45 18                 	movq	0x18(%rbp), %rax
14008b054: 48 89 84 cd a0 01 00 00     	movq	%rax, 0x1a0(%rbp,%rcx,8)
14008b05c: 66 c7 84 cd a8 01 00 00 0c 00       	movw	$0xc, 0x1a8(%rbp,%rcx,8)
14008b066: 48 8b 95 58 02 00 00        	movq	0x258(%rbp), %rdx
14008b06d: 48 ff c2                    	incq	%rdx
14008b070: 48 89 95 58 02 00 00        	movq	%rdx, 0x258(%rbp)
14008b077: 80 7d 10 00                 	cmpb	$0x0, 0x10(%rbp)
14008b07b: 0f 85 ae fd ff ff           	jne	0x14008ae2f <.text+0x89e2f>
14008b081: 83 bd 30 01 00 00 02        	cmpl	$0x2, 0x130(%rbp)
14008b088: 0f 84 a3 04 00 00           	je	0x14008b531 <.text+0x8a531>
14008b08e: 41 f6 45 18 01              	testb	$0x1, 0x18(%r13)
14008b093: 0f 84 0c 02 00 00           	je	0x14008b2a5 <.text+0x8a2a5>
14008b099: 84 db                       	testb	%bl, %bl
14008b09b: 74 35                       	je	0x14008b0d2 <.text+0x8a0d2>
14008b09d: 48 8d 85 7b 01 00 00        	leaq	0x17b(%rbp), %rax
14008b0a4: 66 c7 45 50 1c 00           	movw	$0x1c, 0x50(%rbp)
14008b0aa: 48 89 45 40                 	movq	%rax, 0x40(%rbp)
14008b0ae: 4c 89 7d 48                 	movq	%r15, 0x48(%rbp)
14008b0b2: 48 8d 8d 98 01 00 00        	leaq	0x198(%rbp), %rcx
14008b0b9: 48 8d 55 40                 	leaq	0x40(%rbp), %rdx
14008b0bd: e8 fe 97 16 00              	callq	0x1401f48c0 <.text+0x1f38c0>
14008b0c2: 48 85 c0                    	testq	%rax, %rax
14008b0c5: 0f 84 fc 06 00 00           	je	0x14008b7c7 <.text+0x8a7c7>
14008b0cb: 48 8b 95 58 02 00 00        	movq	0x258(%rbp), %rdx
14008b0d2: 48 83 fa 07                 	cmpq	$0x7, %rdx
14008b0d6: 0f 87 eb 06 00 00           	ja	0x14008b7c7 <.text+0x8a7c7>
14008b0dc: 66 b8 1f 00                 	movw	$0x1f, %ax
14008b0e0: 48 85 d2                    	testq	%rdx, %rdx
14008b0e3: 0f 84 b0 03 00 00           	je	0x14008b499 <.text+0x8a499>
14008b0e9: 4c 8d 52 ff                 	leaq	-0x1(%rdx), %r10
14008b0ed: 4f 8d 04 52                 	leaq	(%r10,%r10,2), %r8
14008b0f1: 66 42 83 bc c5 a8 01 00 00 20       	cmpw	$0x20, 0x1a8(%rbp,%r8,8)
14008b0fb: 0f 82 9a 03 00 00           	jb	0x14008b49b <.text+0x8a49b>
14008b101: 4e 8d 0c c5 98 01 00 00     	leaq	0x198(,%r8,8), %r9
14008b109: 49 01 e9                    	addq	%rbp, %r9
14008b10c: 48 8d 0c 52                 	leaq	(%rdx,%rdx,2), %rcx
14008b110: 4d 8b 59 10                 	movq	0x10(%r9), %r11
14008b114: 4c 89 9c cd a8 01 00 00     	movq	%r11, 0x1a8(%rbp,%rcx,8)
14008b11c: 41 0f 10 01                 	movups	(%r9), %xmm0
14008b120: 0f 11 84 cd 98 01 00 00     	movups	%xmm0, 0x198(%rbp,%rcx,8)
14008b128: 4d 85 d2                    	testq	%r10, %r10
14008b12b: 0f 84 68 03 00 00           	je	0x14008b499 <.text+0x8a499>
14008b131: 4c 8d 5a fe                 	leaq	-0x2(%rdx), %r11
14008b135: 4f 8d 0c 5b                 	leaq	(%r11,%r11,2), %r9
14008b139: 66 42 83 bc cd a8 01 00 00 20       	cmpw	$0x20, 0x1a8(%rbp,%r9,8)
14008b143: 0f 82 61 0a 00 00           	jb	0x14008bbaa <.text+0x8abaa>
14008b149: 4e 8d 14 cd 98 01 00 00     	leaq	0x198(,%r9,8), %r10
14008b151: 49 01 ea                    	addq	%rbp, %r10
14008b154: 49 8b 7a 10                 	movq	0x10(%r10), %rdi
14008b158: 4a 89 bc c5 a8 01 00 00     	movq	%rdi, 0x1a8(%rbp,%r8,8)
14008b160: 41 0f 10 02                 	movups	(%r10), %xmm0
14008b164: 42 0f 11 84 c5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r8,8)
14008b16d: 4d 85 db                    	testq	%r11, %r11
14008b170: 0f 84 23 03 00 00           	je	0x14008b499 <.text+0x8a499>
14008b176: 4c 8d 52 fd                 	leaq	-0x3(%rdx), %r10
14008b17a: 4f 8d 04 52                 	leaq	(%r10,%r10,2), %r8
14008b17e: 66 42 83 bc c5 a8 01 00 00 20       	cmpw	$0x20, 0x1a8(%rbp,%r8,8)
14008b188: 0f 82 95 0a 00 00           	jb	0x14008bc23 <.text+0x8ac23>
14008b18e: 4e 8d 1c c5 98 01 00 00     	leaq	0x198(,%r8,8), %r11
14008b196: 49 01 eb                    	addq	%rbp, %r11
14008b199: 49 8b 7b 10                 	movq	0x10(%r11), %rdi
14008b19d: 4a 89 bc cd a8 01 00 00     	movq	%rdi, 0x1a8(%rbp,%r9,8)
14008b1a5: 41 0f 10 03                 	movups	(%r11), %xmm0
14008b1a9: 42 0f 11 84 cd 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r9,8)
14008b1b2: 4d 85 d2                    	testq	%r10, %r10
14008b1b5: 0f 84 de 02 00 00           	je	0x14008b499 <.text+0x8a499>
14008b1bb: 4c 8d 5a fc                 	leaq	-0x4(%rdx), %r11
14008b1bf: 4f 8d 0c 5b                 	leaq	(%r11,%r11,2), %r9
14008b1c3: 66 42 83 bc cd a8 01 00 00 20       	cmpw	$0x20, 0x1a8(%rbp,%r9,8)
14008b1cd: 0f 82 d7 09 00 00           	jb	0x14008bbaa <.text+0x8abaa>
14008b1d3: 4e 8d 14 cd 98 01 00 00     	leaq	0x198(,%r9,8), %r10
14008b1db: 49 01 ea                    	addq	%rbp, %r10
14008b1de: 49 8b 7a 10                 	movq	0x10(%r10), %rdi
14008b1e2: 4a 89 bc c5 a8 01 00 00     	movq	%rdi, 0x1a8(%rbp,%r8,8)
14008b1ea: 41 0f 10 02                 	movups	(%r10), %xmm0
14008b1ee: 42 0f 11 84 c5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r8,8)
14008b1f7: 4d 85 db                    	testq	%r11, %r11
14008b1fa: 0f 84 99 02 00 00           	je	0x14008b499 <.text+0x8a499>
14008b200: 4c 8d 52 fb                 	leaq	-0x5(%rdx), %r10
14008b204: 4f 8d 04 52                 	leaq	(%r10,%r10,2), %r8
14008b208: 66 42 83 bc c5 a8 01 00 00 20       	cmpw	$0x20, 0x1a8(%rbp,%r8,8)
14008b212: 0f 82 29 0a 00 00           	jb	0x14008bc41 <.text+0x8ac41>
14008b218: 4e 8d 1c c5 98 01 00 00     	leaq	0x198(,%r8,8), %r11
14008b220: 49 01 eb                    	addq	%rbp, %r11
14008b223: 49 8b 7b 10                 	movq	0x10(%r11), %rdi
14008b227: 4a 89 bc cd a8 01 00 00     	movq	%rdi, 0x1a8(%rbp,%r9,8)
14008b22f: 41 0f 10 03                 	movups	(%r11), %xmm0
14008b233: 42 0f 11 84 cd 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r9,8)
14008b23c: 4d 85 d2                    	testq	%r10, %r10
14008b23f: 0f 84 49 02 00 00           	je	0x14008b48e <.text+0x8a48e>
14008b245: 48 83 c2 fa                 	addq	$-0x6, %rdx
14008b249: 4c 8d 0c 52                 	leaq	(%rdx,%rdx,2), %r9
14008b24d: 66 42 83 bc cd a8 01 00 00 20       	cmpw	$0x20, 0x1a8(%rbp,%r9,8)
14008b257: 0f 82 34 0a 00 00           	jb	0x14008bc91 <.text+0x8ac91>
14008b25d: 4e 8d 14 cd 98 01 00 00     	leaq	0x198(,%r9,8), %r10
14008b265: 49 01 ea                    	addq	%rbp, %r10
14008b268: 4d 8b 5a 10                 	movq	0x10(%r10), %r11
14008b26c: 4e 89 9c c5 a8 01 00 00     	movq	%r11, 0x1a8(%rbp,%r8,8)
14008b274: 41 0f 10 02                 	movups	(%r10), %xmm0
14008b278: 42 0f 11 84 c5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r8,8)
14008b281: 48 85 d2                    	testq	%rdx, %rdx
14008b284: 0f 84 04 02 00 00           	je	0x14008b48e <.text+0x8a48e>
14008b28a: 66 83 bc cd 00 01 00 00 20  	cmpw	$0x20, 0x100(%rbp,%rcx,8)
14008b293: 0f 83 cb 01 00 00           	jae	0x14008b464 <.text+0x8a464>
14008b299: 4c 8b ad 68 02 00 00        	movq	0x268(%rbp), %r13
14008b2a0: e9 f6 01 00 00              	jmp	0x14008b49b <.text+0x8a49b>
14008b2a5: 48 83 fa 07                 	cmpq	$0x7, %rdx
14008b2a9: 0f 87 18 05 00 00           	ja	0x14008b7c7 <.text+0x8a7c7>
14008b2af: 66 b8 17 00                 	movw	$0x17, %ax
14008b2b3: 48 85 d2                    	testq	%rdx, %rdx
14008b2b6: 0f 84 dd 01 00 00           	je	0x14008b499 <.text+0x8a499>
14008b2bc: 4c 8d 52 ff                 	leaq	-0x1(%rdx), %r10
14008b2c0: 4f 8d 04 52                 	leaq	(%r10,%r10,2), %r8
14008b2c4: 66 42 83 bc c5 a8 01 00 00 18       	cmpw	$0x18, 0x1a8(%rbp,%r8,8)
14008b2ce: 0f 82 c7 01 00 00           	jb	0x14008b49b <.text+0x8a49b>
14008b2d4: 4e 8d 0c c5 98 01 00 00     	leaq	0x198(,%r8,8), %r9
14008b2dc: 49 01 e9                    	addq	%rbp, %r9
14008b2df: 48 8d 0c 52                 	leaq	(%rdx,%rdx,2), %rcx
14008b2e3: 4d 8b 59 10                 	movq	0x10(%r9), %r11
14008b2e7: 4c 89 9c cd a8 01 00 00     	movq	%r11, 0x1a8(%rbp,%rcx,8)
14008b2ef: 41 0f 10 01                 	movups	(%r9), %xmm0
14008b2f3: 0f 11 84 cd 98 01 00 00     	movups	%xmm0, 0x198(%rbp,%rcx,8)
14008b2fb: 4d 85 d2                    	testq	%r10, %r10
14008b2fe: 0f 84 95 01 00 00           	je	0x14008b499 <.text+0x8a499>
14008b304: 4c 8d 5a fe                 	leaq	-0x2(%rdx), %r11
14008b308: 4f 8d 0c 5b                 	leaq	(%r11,%r11,2), %r9
14008b30c: 66 42 83 bc cd a8 01 00 00 18       	cmpw	$0x18, 0x1a8(%rbp,%r9,8)
14008b316: 0f 82 8e 08 00 00           	jb	0x14008bbaa <.text+0x8abaa>
14008b31c: 4e 8d 14 cd 98 01 00 00     	leaq	0x198(,%r9,8), %r10
14008b324: 49 01 ea                    	addq	%rbp, %r10
14008b327: 49 8b 7a 10                 	movq	0x10(%r10), %rdi
14008b32b: 4a 89 bc c5 a8 01 00 00     	movq	%rdi, 0x1a8(%rbp,%r8,8)
14008b333: 41 0f 10 02                 	movups	(%r10), %xmm0
14008b337: 42 0f 11 84 c5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r8,8)
14008b340: 4d 85 db                    	testq	%r11, %r11
14008b343: 0f 84 50 01 00 00           	je	0x14008b499 <.text+0x8a499>
14008b349: 4c 8d 52 fd                 	leaq	-0x3(%rdx), %r10
14008b34d: 4f 8d 04 52                 	leaq	(%r10,%r10,2), %r8
14008b351: 66 42 83 bc c5 a8 01 00 00 18       	cmpw	$0x18, 0x1a8(%rbp,%r8,8)
14008b35b: 0f 82 c2 08 00 00           	jb	0x14008bc23 <.text+0x8ac23>
14008b361: 4e 8d 1c c5 98 01 00 00     	leaq	0x198(,%r8,8), %r11
14008b369: 49 01 eb                    	addq	%rbp, %r11
14008b36c: 49 8b 7b 10                 	movq	0x10(%r11), %rdi
14008b370: 4a 89 bc cd a8 01 00 00     	movq	%rdi, 0x1a8(%rbp,%r9,8)
14008b378: 41 0f 10 03                 	movups	(%r11), %xmm0
14008b37c: 42 0f 11 84 cd 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r9,8)
14008b385: 4d 85 d2                    	testq	%r10, %r10
14008b388: 0f 84 0b 01 00 00           	je	0x14008b499 <.text+0x8a499>
14008b38e: 4c 8d 5a fc                 	leaq	-0x4(%rdx), %r11
14008b392: 4f 8d 0c 5b                 	leaq	(%r11,%r11,2), %r9
14008b396: 66 42 83 bc cd a8 01 00 00 18       	cmpw	$0x18, 0x1a8(%rbp,%r9,8)
14008b3a0: 0f 82 04 08 00 00           	jb	0x14008bbaa <.text+0x8abaa>
14008b3a6: 4e 8d 14 cd 98 01 00 00     	leaq	0x198(,%r9,8), %r10
14008b3ae: 49 01 ea                    	addq	%rbp, %r10
14008b3b1: 49 8b 7a 10                 	movq	0x10(%r10), %rdi
14008b3b5: 4a 89 bc c5 a8 01 00 00     	movq	%rdi, 0x1a8(%rbp,%r8,8)
14008b3bd: 41 0f 10 02                 	movups	(%r10), %xmm0
14008b3c1: 42 0f 11 84 c5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r8,8)
14008b3ca: 4d 85 db                    	testq	%r11, %r11
14008b3cd: 0f 84 c6 00 00 00           	je	0x14008b499 <.text+0x8a499>
14008b3d3: 4c 8d 52 fb                 	leaq	-0x5(%rdx), %r10
14008b3d7: 4f 8d 04 52                 	leaq	(%r10,%r10,2), %r8
14008b3db: 66 42 83 bc c5 a8 01 00 00 18       	cmpw	$0x18, 0x1a8(%rbp,%r8,8)
14008b3e5: 0f 82 56 08 00 00           	jb	0x14008bc41 <.text+0x8ac41>
14008b3eb: 4e 8d 1c c5 98 01 00 00     	leaq	0x198(,%r8,8), %r11
14008b3f3: 49 01 eb                    	addq	%rbp, %r11
14008b3f6: 49 8b 7b 10                 	movq	0x10(%r11), %rdi
14008b3fa: 4a 89 bc cd a8 01 00 00     	movq	%rdi, 0x1a8(%rbp,%r9,8)
14008b402: 41 0f 10 03                 	movups	(%r11), %xmm0
14008b406: 42 0f 11 84 cd 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r9,8)
14008b40f: 4d 85 d2                    	testq	%r10, %r10
14008b412: 74 7a                       	je	0x14008b48e <.text+0x8a48e>
14008b414: 48 83 c2 fa                 	addq	$-0x6, %rdx
14008b418: 4c 8d 0c 52                 	leaq	(%rdx,%rdx,2), %r9
14008b41c: 66 42 83 bc cd a8 01 00 00 18       	cmpw	$0x18, 0x1a8(%rbp,%r9,8)
14008b426: 0f 82 65 08 00 00           	jb	0x14008bc91 <.text+0x8ac91>
14008b42c: 4e 8d 14 cd 98 01 00 00     	leaq	0x198(,%r9,8), %r10
14008b434: 49 01 ea                    	addq	%rbp, %r10
14008b437: 4d 8b 5a 10                 	movq	0x10(%r10), %r11
14008b43b: 4e 89 9c c5 a8 01 00 00     	movq	%r11, 0x1a8(%rbp,%r8,8)
14008b443: 41 0f 10 02                 	movups	(%r10), %xmm0
14008b447: 42 0f 11 84 c5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r8,8)
14008b450: 48 85 d2                    	testq	%rdx, %rdx
14008b453: 74 39                       	je	0x14008b48e <.text+0x8a48e>
14008b455: 66 83 bc cd 00 01 00 00 18  	cmpw	$0x18, 0x100(%rbp,%rcx,8)
14008b45e: 0f 82 35 fe ff ff           	jb	0x14008b299 <.text+0x8a299>
14008b464: 48 8d 0c cd 98 01 00 00     	leaq	0x198(,%rcx,8), %rcx
14008b46c: 48 01 e9                    	addq	%rbp, %rcx
14008b46f: 48 8b 91 68 ff ff ff        	movq	-0x98(%rcx), %rdx
14008b476: 4a 89 94 cd a8 01 00 00     	movq	%rdx, 0x1a8(%rbp,%r9,8)
14008b47e: 0f 10 81 58 ff ff ff        	movups	-0xa8(%rcx), %xmm0
14008b485: 42 0f 11 84 cd 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r9,8)
14008b48e: 31 d2                       	xorl	%edx, %edx
14008b490: 4c 8b ad 68 02 00 00        	movq	0x268(%rbp), %r13
14008b497: eb 02                       	jmp	0x14008b49b <.text+0x8a49b>
14008b499: 31 d2                       	xorl	%edx, %edx
14008b49b: 48 8d 8d 8d 01 00 00        	leaq	0x18d(%rbp), %rcx
14008b4a2: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008b4a6: 48 89 8c d5 98 01 00 00     	movq	%rcx, 0x198(%rbp,%rdx,8)
14008b4ae: 48 8b 8d 18 01 00 00        	movq	0x118(%rbp), %rcx
14008b4b5: 48 89 8c d5 a0 01 00 00     	movq	%rcx, 0x1a0(%rbp,%rdx,8)
14008b4bd: 66 89 84 d5 a8 01 00 00     	movw	%ax, 0x1a8(%rbp,%rdx,8)
14008b4c5: 48 8b 95 58 02 00 00        	movq	0x258(%rbp), %rdx
14008b4cc: 48 ff c2                    	incq	%rdx
14008b4cf: 48 89 95 58 02 00 00        	movq	%rdx, 0x258(%rbp)
14008b4d6: 80 bd 68 01 00 00 00        	cmpb	$0x0, 0x168(%rbp)
14008b4dd: 75 5b                       	jne	0x14008b53a <.text+0x8a53a>
14008b4df: f6 45 e0 01                 	testb	$0x1, -0x20(%rbp)
14008b4e3: 0f 85 ca 02 00 00           	jne	0x14008b7b3 <.text+0x8a7b3>
14008b4e9: e9 96 05 00 00              	jmp	0x14008ba84 <.text+0x8aa84>
14008b4ee: 49 89 d0                    	movq	%rdx, %r8
14008b4f1: 4b 8d 0c 40                 	leaq	(%r8,%r8,2), %rcx
14008b4f5: 48 89 84 cd 98 01 00 00     	movq	%rax, 0x198(%rbp,%rcx,8)
14008b4fd: 48 8b 45 38                 	movq	0x38(%rbp), %rax
14008b501: 48 89 84 cd a0 01 00 00     	movq	%rax, 0x1a0(%rbp,%rcx,8)
14008b509: 66 c7 84 cd a8 01 00 00 0e 00       	movw	$0xe, 0x1a8(%rbp,%rcx,8)
14008b513: 48 8b 95 58 02 00 00        	movq	0x258(%rbp), %rdx
14008b51a: 48 ff c2                    	incq	%rdx
14008b51d: 48 89 95 58 02 00 00        	movq	%rdx, 0x258(%rbp)
14008b524: 83 bd 30 01 00 00 02        	cmpl	$0x2, 0x130(%rbp)
14008b52b: 0f 85 5d fb ff ff           	jne	0x14008b08e <.text+0x8a08e>
14008b531: 80 bd 68 01 00 00 00        	cmpb	$0x0, 0x168(%rbp)
14008b538: 74 a5                       	je	0x14008b4df <.text+0x8a4df>
14008b53a: 83 7d 30 02                 	cmpl	$0x2, 0x30(%rbp)
14008b53e: 0f 94 c1                    	sete	%cl
14008b541: 48 83 fa 07                 	cmpq	$0x7, %rdx
14008b545: 0f 87 7c 02 00 00           	ja	0x14008b7c7 <.text+0x8a7c7>
14008b54b: 48 8d 85 75 01 00 00        	leaq	0x175(%rbp), %rax
14008b552: 4c 8b 85 08 01 00 00        	movq	0x108(%rbp), %r8
14008b559: 45 0f b6 40 18              	movzbl	0x18(%r8), %r8d
14008b55e: 41 f6 d0                    	notb	%r8b
14008b561: 44 08 c1                    	orb	%r8b, %cl
14008b564: 0f b6 c9                    	movzbl	%cl, %ecx
14008b567: 83 e1 01                    	andl	$0x1, %ecx
14008b56a: 8d 0c cd 13 00 00 00        	leal	0x13(,%rcx,8), %ecx
14008b571: 48 85 d2                    	testq	%rdx, %rdx
14008b574: 0f 84 f3 01 00 00           	je	0x14008b76d <.text+0x8a76d>
14008b57a: 4c 8d 4a ff                 	leaq	-0x1(%rdx), %r9
14008b57e: 4f 8d 14 49                 	leaq	(%r9,%r9,2), %r10
14008b582: 66 42 39 8c d5 a8 01 00 00  	cmpw	%cx, 0x1a8(%rbp,%r10,8)
14008b58b: 0f 86 e1 01 00 00           	jbe	0x14008b772 <.text+0x8a772>
14008b591: 4e 8d 1c d5 98 01 00 00     	leaq	0x198(,%r10,8), %r11
14008b599: 49 01 eb                    	addq	%rbp, %r11
14008b59c: 4c 8d 04 52                 	leaq	(%rdx,%rdx,2), %r8
14008b5a0: 49 8b 7b 10                 	movq	0x10(%r11), %rdi
14008b5a4: 4a 89 bc c5 a8 01 00 00     	movq	%rdi, 0x1a8(%rbp,%r8,8)
14008b5ac: 41 0f 10 03                 	movups	(%r11), %xmm0
14008b5b0: 42 0f 11 84 c5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r8,8)
14008b5b9: 4d 85 c9                    	testq	%r9, %r9
14008b5bc: 0f 84 ab 01 00 00           	je	0x14008b76d <.text+0x8a76d>
14008b5c2: 48 8d 5a fe                 	leaq	-0x2(%rdx), %rbx
14008b5c6: 4c 8d 1c 5b                 	leaq	(%rbx,%rbx,2), %r11
14008b5ca: 66 42 39 8c dd a8 01 00 00  	cmpw	%cx, 0x1a8(%rbp,%r11,8)
14008b5d3: 0f 86 9c 01 00 00           	jbe	0x14008b775 <.text+0x8a775>
14008b5d9: 4e 8d 0c dd 98 01 00 00     	leaq	0x198(,%r11,8), %r9
14008b5e1: 49 01 e9                    	addq	%rbp, %r9
14008b5e4: 49 8b 79 10                 	movq	0x10(%r9), %rdi
14008b5e8: 4a 89 bc d5 a8 01 00 00     	movq	%rdi, 0x1a8(%rbp,%r10,8)
14008b5f0: 41 0f 10 01                 	movups	(%r9), %xmm0
14008b5f4: 42 0f 11 84 d5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r10,8)
14008b5fd: 48 85 db                    	testq	%rbx, %rbx
14008b600: 0f 84 67 01 00 00           	je	0x14008b76d <.text+0x8a76d>
14008b606: 48 8d 7a fd                 	leaq	-0x3(%rdx), %rdi
14008b60a: 4c 8d 14 7f                 	leaq	(%rdi,%rdi,2), %r10
14008b60e: 49 89 d9                    	movq	%rbx, %r9
14008b611: 66 42 39 8c d5 a8 01 00 00  	cmpw	%cx, 0x1a8(%rbp,%r10,8)
14008b61a: 0f 86 55 01 00 00           	jbe	0x14008b775 <.text+0x8a775>
14008b620: 4e 8d 0c d5 98 01 00 00     	leaq	0x198(,%r10,8), %r9
14008b628: 49 01 e9                    	addq	%rbp, %r9
14008b62b: 49 8b 59 10                 	movq	0x10(%r9), %rbx
14008b62f: 4a 89 9c dd a8 01 00 00     	movq	%rbx, 0x1a8(%rbp,%r11,8)
14008b637: 41 0f 10 01                 	movups	(%r9), %xmm0
14008b63b: 42 0f 11 84 dd 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r11,8)
14008b644: 48 85 ff                    	testq	%rdi, %rdi
14008b647: 0f 84 20 01 00 00           	je	0x14008b76d <.text+0x8a76d>
14008b64d: 48 8d 5a fc                 	leaq	-0x4(%rdx), %rbx
14008b651: 4c 8d 1c 5b                 	leaq	(%rbx,%rbx,2), %r11
14008b655: 49 89 f9                    	movq	%rdi, %r9
14008b658: 66 42 39 8c dd a8 01 00 00  	cmpw	%cx, 0x1a8(%rbp,%r11,8)
14008b661: 0f 86 0e 01 00 00           	jbe	0x14008b775 <.text+0x8a775>
14008b667: 4e 8d 0c dd 98 01 00 00     	leaq	0x198(,%r11,8), %r9
14008b66f: 49 01 e9                    	addq	%rbp, %r9
14008b672: 49 8b 79 10                 	movq	0x10(%r9), %rdi
14008b676: 4a 89 bc d5 a8 01 00 00     	movq	%rdi, 0x1a8(%rbp,%r10,8)
14008b67e: 41 0f 10 01                 	movups	(%r9), %xmm0
14008b682: 42 0f 11 84 d5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r10,8)
14008b68b: 48 85 db                    	testq	%rbx, %rbx
14008b68e: 0f 84 d9 00 00 00           	je	0x14008b76d <.text+0x8a76d>
14008b694: 48 8d 7a fb                 	leaq	-0x5(%rdx), %rdi
14008b698: 4c 8d 14 7f                 	leaq	(%rdi,%rdi,2), %r10
14008b69c: 49 89 d9                    	movq	%rbx, %r9
14008b69f: 66 42 39 8c d5 a8 01 00 00  	cmpw	%cx, 0x1a8(%rbp,%r10,8)
14008b6a8: 0f 86 c7 00 00 00           	jbe	0x14008b775 <.text+0x8a775>
14008b6ae: 49 89 f6                    	movq	%rsi, %r14
14008b6b1: 4e 8d 0c d5 98 01 00 00     	leaq	0x198(,%r10,8), %r9
14008b6b9: 49 01 e9                    	addq	%rbp, %r9
14008b6bc: 49 8b 59 10                 	movq	0x10(%r9), %rbx
14008b6c0: 4a 89 9c dd a8 01 00 00     	movq	%rbx, 0x1a8(%rbp,%r11,8)
14008b6c8: 41 0f 10 01                 	movups	(%r9), %xmm0
14008b6cc: 42 0f 11 84 dd 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r11,8)
14008b6d5: 48 85 ff                    	testq	%rdi, %rdi
14008b6d8: 0f 84 a1 05 00 00           	je	0x14008bc7f <.text+0x8ac7f>
14008b6de: 48 83 c2 fa                 	addq	$-0x6, %rdx
14008b6e2: 4c 8d 1c 52                 	leaq	(%rdx,%rdx,2), %r11
14008b6e6: 49 89 f9                    	movq	%rdi, %r9
14008b6e9: 66 42 39 8c dd a8 01 00 00  	cmpw	%cx, 0x1a8(%rbp,%r11,8)
14008b6f2: 4c 8b ad 68 02 00 00        	movq	0x268(%rbp), %r13
14008b6f9: 4c 89 f6                    	movq	%r14, %rsi
14008b6fc: 76 77                       	jbe	0x14008b775 <.text+0x8a775>
14008b6fe: 4e 8d 0c dd 98 01 00 00     	leaq	0x198(,%r11,8), %r9
14008b706: 49 01 e9                    	addq	%rbp, %r9
14008b709: 49 8b 79 10                 	movq	0x10(%r9), %rdi
14008b70d: 4a 89 bc d5 a8 01 00 00     	movq	%rdi, 0x1a8(%rbp,%r10,8)
14008b715: 41 0f 10 01                 	movups	(%r9), %xmm0
14008b719: 42 0f 11 84 d5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r10,8)
14008b722: 48 85 d2                    	testq	%rdx, %rdx
14008b725: 0f 84 54 05 00 00           	je	0x14008bc7f <.text+0x8ac7f>
14008b72b: 49 89 d1                    	movq	%rdx, %r9
14008b72e: 66 42 39 8c c5 00 01 00 00  	cmpw	%cx, 0x100(%rbp,%r8,8)
14008b737: 4c 8b ad 68 02 00 00        	movq	0x268(%rbp), %r13
14008b73e: 4c 89 f6                    	movq	%r14, %rsi
14008b741: 76 32                       	jbe	0x14008b775 <.text+0x8a775>
14008b743: 4a 8d 14 c5 98 01 00 00     	leaq	0x198(,%r8,8), %rdx
14008b74b: 48 01 ea                    	addq	%rbp, %rdx
14008b74e: 4c 8b 82 68 ff ff ff        	movq	-0x98(%rdx), %r8
14008b755: 4e 89 84 dd a8 01 00 00     	movq	%r8, 0x1a8(%rbp,%r11,8)
14008b75d: 0f 10 82 58 ff ff ff        	movups	-0xa8(%rdx), %xmm0
14008b764: 42 0f 11 84 dd 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r11,8)
14008b76d: 45 31 c9                    	xorl	%r9d, %r9d
14008b770: eb 03                       	jmp	0x14008b775 <.text+0x8a775>
14008b772: 49 89 d1                    	movq	%rdx, %r9
14008b775: 4b 8d 14 49                 	leaq	(%r9,%r9,2), %rdx
14008b779: 48 89 84 d5 98 01 00 00     	movq	%rax, 0x198(%rbp,%rdx,8)
14008b781: 48 8b 85 20 01 00 00        	movq	0x120(%rbp), %rax
14008b788: 48 89 84 d5 a0 01 00 00     	movq	%rax, 0x1a0(%rbp,%rdx,8)
14008b790: 66 89 8c d5 a8 01 00 00     	movw	%cx, 0x1a8(%rbp,%rdx,8)
14008b798: 48 8b 95 58 02 00 00        	movq	0x258(%rbp), %rdx
14008b79f: 48 ff c2                    	incq	%rdx
14008b7a2: 48 89 95 58 02 00 00        	movq	%rdx, 0x258(%rbp)
14008b7a9: f6 45 e0 01                 	testb	$0x1, -0x20(%rbp)
14008b7ad: 0f 84 d1 02 00 00           	je	0x14008ba84 <.text+0x8aa84>
14008b7b3: 0f b6 45 09                 	movzbl	0x9(%rbp), %eax
14008b7b7: 48 83 f8 29                 	cmpq	$0x29, %rax
14008b7bb: 0f 83 a5 04 00 00           	jae	0x14008bc66 <.text+0x8ac66>
14008b7c1: 48 83 fa 07                 	cmpq	$0x7, %rdx
14008b7c5: 76 7a                       	jbe	0x14008b841 <.text+0x8a841>
14008b7c7: 48 8b 85 48 01 00 00        	movq	0x148(%rbp), %rax
14008b7ce: 44 8b 40 14                 	movl	0x14(%rax), %r8d
14008b7d2: 48 8b 8d 60 01 00 00        	movq	0x160(%rbp), %rcx
14008b7d9: 48 8b 41 18                 	movq	0x18(%rcx), %rax
14008b7dd: 48 8b 49 50                 	movq	0x50(%rcx), %rcx
14008b7e1: 48 8b 95 58 01 00 00        	movq	0x158(%rbp), %rdx
14008b7e8: 48 89 54 24 50              	movq	%rdx, 0x50(%rsp)
14008b7ed: 48 89 4c 24 48              	movq	%rcx, 0x48(%rsp)
14008b7f2: 48 89 44 24 40              	movq	%rax, 0x40(%rsp)
14008b7f7: 48 8b 85 50 01 00 00        	movq	0x150(%rbp), %rax
14008b7fe: 48 89 44 24 38              	movq	%rax, 0x38(%rsp)
14008b803: 48 8b 85 10 01 00 00        	movq	0x110(%rbp), %rax
14008b80a: 48 89 44 24 30              	movq	%rax, 0x30(%rsp)
14008b80f: 0f b7 85 66 02 00 00        	movzwl	0x266(%rbp), %eax
14008b816: 66 89 44 24 28              	movw	%ax, 0x28(%rsp)
14008b81b: 0f b6 85 77 02 00 00        	movzbl	0x277(%rbp), %eax
14008b822: 88 44 24 20                 	movb	%al, 0x20(%rsp)
14008b826: 48 89 f1                    	movq	%rsi, %rcx
14008b829: 48 8b 95 40 01 00 00        	movq	0x140(%rbp), %rdx
14008b830: 4c 8b 8d 38 01 00 00        	movq	0x138(%rbp), %r9
14008b837: e8 f4 b3 02 00              	callq	0x1400b6c30 <.text+0xb5c30>
14008b83c: e9 39 ed ff ff              	jmp	0x14008a57a <.text+0x8957a>
14008b841: 48 8d 4d e1                 	leaq	-0x1f(%rbp), %rcx
14008b845: 48 85 d2                    	testq	%rdx, %rdx
14008b848: 0f 84 ff 01 00 00           	je	0x14008ba4d <.text+0x8aa4d>
14008b84e: 4c 8d 4a ff                 	leaq	-0x1(%rdx), %r9
14008b852: 4f 8d 1c 49                 	leaq	(%r9,%r9,2), %r11
14008b856: 66 42 81 bc dd a8 01 00 00 fd 00    	cmpw	$0xfd, 0x1a8(%rbp,%r11,8)
14008b861: 0f 82 eb 01 00 00           	jb	0x14008ba52 <.text+0x8aa52>
14008b867: 4e 8d 14 dd 98 01 00 00     	leaq	0x198(,%r11,8), %r10
14008b86f: 49 01 ea                    	addq	%rbp, %r10
14008b872: 4c 8d 04 52                 	leaq	(%rdx,%rdx,2), %r8
14008b876: 49 8b 7a 10                 	movq	0x10(%r10), %rdi
14008b87a: 4a 89 bc c5 a8 01 00 00     	movq	%rdi, 0x1a8(%rbp,%r8,8)
14008b882: 41 0f 10 02                 	movups	(%r10), %xmm0
14008b886: 42 0f 11 84 c5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r8,8)
14008b88f: 4d 85 c9                    	testq	%r9, %r9
14008b892: 0f 84 b5 01 00 00           	je	0x14008ba4d <.text+0x8aa4d>
14008b898: 48 8d 7a fe                 	leaq	-0x2(%rdx), %rdi
14008b89c: 4c 8d 14 7f                 	leaq	(%rdi,%rdi,2), %r10
14008b8a0: 66 42 81 bc d5 a8 01 00 00 fd 00    	cmpw	$0xfd, 0x1a8(%rbp,%r10,8)
14008b8ab: 0f 82 a4 01 00 00           	jb	0x14008ba55 <.text+0x8aa55>
14008b8b1: 4e 8d 0c d5 98 01 00 00     	leaq	0x198(,%r10,8), %r9
14008b8b9: 49 01 e9                    	addq	%rbp, %r9
14008b8bc: 49 8b 59 10                 	movq	0x10(%r9), %rbx
14008b8c0: 4a 89 9c dd a8 01 00 00     	movq	%rbx, 0x1a8(%rbp,%r11,8)
14008b8c8: 41 0f 10 01                 	movups	(%r9), %xmm0
14008b8cc: 42 0f 11 84 dd 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r11,8)
14008b8d5: 48 85 ff                    	testq	%rdi, %rdi
14008b8d8: 0f 84 6f 01 00 00           	je	0x14008ba4d <.text+0x8aa4d>
14008b8de: 48 8d 5a fd                 	leaq	-0x3(%rdx), %rbx
14008b8e2: 4c 8d 1c 5b                 	leaq	(%rbx,%rbx,2), %r11
14008b8e6: 66 42 81 bc dd a8 01 00 00 fd 00    	cmpw	$0xfd, 0x1a8(%rbp,%r11,8)
14008b8f1: 49 89 f9                    	movq	%rdi, %r9
14008b8f4: 0f 82 5b 01 00 00           	jb	0x14008ba55 <.text+0x8aa55>
14008b8fa: 4e 8d 0c dd 98 01 00 00     	leaq	0x198(,%r11,8), %r9
14008b902: 49 01 e9                    	addq	%rbp, %r9
14008b905: 49 8b 79 10                 	movq	0x10(%r9), %rdi
14008b909: 4a 89 bc d5 a8 01 00 00     	movq	%rdi, 0x1a8(%rbp,%r10,8)
14008b911: 41 0f 10 01                 	movups	(%r9), %xmm0
14008b915: 42 0f 11 84 d5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r10,8)
14008b91e: 48 85 db                    	testq	%rbx, %rbx
14008b921: 0f 84 26 01 00 00           	je	0x14008ba4d <.text+0x8aa4d>
14008b927: 4c 8d 72 fc                 	leaq	-0x4(%rdx), %r14
14008b92b: 4b 8d 3c 76                 	leaq	(%r14,%r14,2), %rdi
14008b92f: 66 81 bc fd a8 01 00 00 fd 00       	cmpw	$0xfd, 0x1a8(%rbp,%rdi,8)
14008b939: 49 89 d9                    	movq	%rbx, %r9
14008b93c: 0f 82 13 01 00 00           	jb	0x14008ba55 <.text+0x8aa55>
14008b942: 4c 8d 0c fd 98 01 00 00     	leaq	0x198(,%rdi,8), %r9
14008b94a: 49 01 e9                    	addq	%rbp, %r9
14008b94d: 4d 8b 51 10                 	movq	0x10(%r9), %r10
14008b951: 4e 89 94 dd a8 01 00 00     	movq	%r10, 0x1a8(%rbp,%r11,8)
14008b959: 41 0f 10 01                 	movups	(%r9), %xmm0
14008b95d: 42 0f 11 84 dd 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r11,8)
14008b966: 4d 85 f6                    	testq	%r14, %r14
14008b969: 0f 84 de 00 00 00           	je	0x14008ba4d <.text+0x8aa4d>
14008b96f: 48 8d 5a fb                 	leaq	-0x5(%rdx), %rbx
14008b973: 4c 8d 14 5b                 	leaq	(%rbx,%rbx,2), %r10
14008b977: 66 42 81 bc d5 a8 01 00 00 fd 00    	cmpw	$0xfd, 0x1a8(%rbp,%r10,8)
14008b982: 4d 89 f1                    	movq	%r14, %r9
14008b985: 0f 82 ca 00 00 00           	jb	0x14008ba55 <.text+0x8aa55>
14008b98b: 49 89 f6                    	movq	%rsi, %r14
14008b98e: 4e 8d 0c d5 98 01 00 00     	leaq	0x198(,%r10,8), %r9
14008b996: 49 01 e9                    	addq	%rbp, %r9
14008b999: 4d 8b 59 10                 	movq	0x10(%r9), %r11
14008b99d: 4c 89 9c fd a8 01 00 00     	movq	%r11, 0x1a8(%rbp,%rdi,8)
14008b9a5: 41 0f 10 01                 	movups	(%r9), %xmm0
14008b9a9: 0f 11 84 fd 98 01 00 00     	movups	%xmm0, 0x198(%rbp,%rdi,8)
14008b9b1: 48 85 db                    	testq	%rbx, %rbx
14008b9b4: 0f 84 e6 02 00 00           	je	0x14008bca0 <.text+0x8aca0>
14008b9ba: 48 83 c2 fa                 	addq	$-0x6, %rdx
14008b9be: 4c 8d 1c 52                 	leaq	(%rdx,%rdx,2), %r11
14008b9c2: 66 42 81 bc dd a8 01 00 00 fd 00    	cmpw	$0xfd, 0x1a8(%rbp,%r11,8)
14008b9cd: 49 89 d9                    	movq	%rbx, %r9
14008b9d0: 4c 8b ad 68 02 00 00        	movq	0x268(%rbp), %r13
14008b9d7: 4c 89 f6                    	movq	%r14, %rsi
14008b9da: 72 79                       	jb	0x14008ba55 <.text+0x8aa55>
14008b9dc: 4e 8d 0c dd 98 01 00 00     	leaq	0x198(,%r11,8), %r9
14008b9e4: 49 01 e9                    	addq	%rbp, %r9
14008b9e7: 49 8b 79 10                 	movq	0x10(%r9), %rdi
14008b9eb: 4a 89 bc d5 a8 01 00 00     	movq	%rdi, 0x1a8(%rbp,%r10,8)
14008b9f3: 41 0f 10 01                 	movups	(%r9), %xmm0
14008b9f7: 42 0f 11 84 d5 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r10,8)
14008ba00: 48 85 d2                    	testq	%rdx, %rdx
14008ba03: 0f 84 97 02 00 00           	je	0x14008bca0 <.text+0x8aca0>
14008ba09: 66 42 81 bc c5 00 01 00 00 fd 00    	cmpw	$0xfd, 0x100(%rbp,%r8,8)
14008ba14: 49 89 d1                    	movq	%rdx, %r9
14008ba17: 4c 8b ad 68 02 00 00        	movq	0x268(%rbp), %r13
14008ba1e: 4c 89 f6                    	movq	%r14, %rsi
14008ba21: 72 32                       	jb	0x14008ba55 <.text+0x8aa55>
14008ba23: 4a 8d 14 c5 98 01 00 00     	leaq	0x198(,%r8,8), %rdx
14008ba2b: 48 01 ea                    	addq	%rbp, %rdx
14008ba2e: 4c 8b 82 68 ff ff ff        	movq	-0x98(%rdx), %r8
14008ba35: 4e 89 84 dd a8 01 00 00     	movq	%r8, 0x1a8(%rbp,%r11,8)
14008ba3d: 0f 10 82 58 ff ff ff        	movups	-0xa8(%rdx), %xmm0
14008ba44: 42 0f 11 84 dd 98 01 00 00  	movups	%xmm0, 0x198(%rbp,%r11,8)
14008ba4d: 45 31 c9                    	xorl	%r9d, %r9d
14008ba50: eb 03                       	jmp	0x14008ba55 <.text+0x8aa55>
14008ba52: 49 89 d1                    	movq	%rdx, %r9
14008ba55: 4b 8d 14 49                 	leaq	(%r9,%r9,2), %rdx
14008ba59: 48 89 8c d5 98 01 00 00     	movq	%rcx, 0x198(%rbp,%rdx,8)
14008ba61: 48 89 84 d5 a0 01 00 00     	movq	%rax, 0x1a0(%rbp,%rdx,8)
14008ba69: 66 c7 84 d5 a8 01 00 00 fc 00       	movw	$0xfc, 0x1a8(%rbp,%rdx,8)
14008ba73: 48 8b 95 58 02 00 00        	movq	0x258(%rbp), %rdx
14008ba7a: 48 ff c2                    	incq	%rdx
14008ba7d: 48 89 95 58 02 00 00        	movq	%rdx, 0x258(%rbp)
14008ba84: 4c 8b 95 38 01 00 00        	movq	0x138(%rbp), %r10
14008ba8b: 4c 8b 9d 40 01 00 00        	movq	0x140(%rbp), %r11
14008ba92: 4c 8b 8d 48 01 00 00        	movq	0x148(%rbp), %r9
14008ba99: 44 0f b6 85 77 02 00 00     	movzbl	0x277(%rbp), %r8d
14008baa1: 48 83 fa 09                 	cmpq	$0x9, %rdx
14008baa5: 0f 83 a5 01 00 00           	jae	0x14008bc50 <.text+0x8ac50>
14008baab: 83 bd 30 01 00 00 02        	cmpl	$0x2, 0x130(%rbp)
14008bab2: 0f 95 c0                    	setne	%al
14008bab5: 41 0f b6 8c 24 55 02 00 00  	movzbl	0x255(%r12), %ecx
14008babe: 48 8d bd 98 01 00 00        	leaq	0x198(%rbp), %rdi
14008bac5: 48 89 7d 40                 	movq	%rdi, 0x40(%rbp)
14008bac9: 48 89 55 48                 	movq	%rdx, 0x48(%rbp)
14008bacd: 48 8b 55 28                 	movq	0x28(%rbp), %rdx
14008bad1: 48 89 55 50                 	movq	%rdx, 0x50(%rbp)
14008bad5: 48 8b 55 20                 	movq	0x20(%rbp), %rdx
14008bad9: 48 89 55 58                 	movq	%rdx, 0x58(%rbp)
14008badd: 0f b7 95 66 02 00 00        	movzwl	0x266(%rbp), %edx
14008bae4: 66 89 55 60                 	movw	%dx, 0x60(%rbp)
14008bae8: 88 4d 62                    	movb	%cl, 0x62(%rbp)
14008baeb: 48 8b 95 10 01 00 00        	movq	0x110(%rbp), %rdx
14008baf2: 48 8b 0a                    	movq	(%rdx), %rcx
14008baf5: 48 89 4d 63                 	movq	%rcx, 0x63(%rbp)
14008baf9: 0f b6 4a 08                 	movzbl	0x8(%rdx), %ecx
14008bafd: 88 4d 6b                    	movb	%cl, 0x6b(%rbp)
14008bb00: 44 88 45 6c                 	movb	%r8b, 0x6c(%rbp)
14008bb04: 41 80 bc 24 52 02 00 00 00  	cmpb	$0x0, 0x252(%r12)
14008bb0d: 75 15                       	jne	0x14008bb24 <.text+0x8ab24>
14008bb0f: 41 22 45 18                 	andb	0x18(%r13), %al
14008bb13: 75 0f                       	jne	0x14008bb24 <.text+0x8ab24>
14008bb15: 41 80 f8 02                 	cmpb	$0x2, %r8b
14008bb19: 74 43                       	je	0x14008bb5e <.text+0x8ab5e>
14008bb1b: 83 bd 2c 01 00 00 00        	cmpl	$0x0, 0x12c(%rbp)
14008bb22: 74 3a                       	je	0x14008bb5e <.text+0x8ab5e>
14008bb24: 48 8d 45 40                 	leaq	0x40(%rbp), %rax
14008bb28: 48 89 44 24 38              	movq	%rax, 0x38(%rsp)
14008bb2d: 4c 89 54 24 30              	movq	%r10, 0x30(%rsp)
14008bb32: 4c 89 5c 24 28              	movq	%r11, 0x28(%rsp)
14008bb37: 48 8b 85 58 01 00 00        	movq	0x158(%rbp), %rax
14008bb3e: 48 89 44 24 20              	movq	%rax, 0x20(%rsp)
14008bb43: 48 89 f1                    	movq	%rsi, %rcx
14008bb46: 48 8b 95 50 01 00 00        	movq	0x150(%rbp), %rdx
14008bb4d: 4c 8b 85 60 01 00 00        	movq	0x160(%rbp), %r8
14008bb54: e8 17 86 07 00              	callq	0x140104170 <.text+0x103170>
14008bb59: e9 1c ea ff ff              	jmp	0x14008a57a <.text+0x8957a>
14008bb5e: 48 8b 8d 60 01 00 00        	movq	0x160(%rbp), %rcx
14008bb65: 4c 8b 41 18                 	movq	0x18(%rcx), %r8
14008bb69: 4c 89 c8                    	movq	%r9, %rax
14008bb6c: 4c 8b 49 50                 	movq	0x50(%rcx), %r9
14008bb70: 8b 40 14                    	movl	0x14(%rax), %eax
14008bb73: 48 8d 4d 40                 	leaq	0x40(%rbp), %rcx
14008bb77: 48 89 4c 24 40              	movq	%rcx, 0x40(%rsp)
14008bb7c: 4c 89 54 24 38              	movq	%r10, 0x38(%rsp)
14008bb81: 4c 89 5c 24 30              	movq	%r11, 0x30(%rsp)
14008bb86: 48 8b 8d 58 01 00 00        	movq	0x158(%rbp), %rcx
14008bb8d: 48 89 4c 24 28              	movq	%rcx, 0x28(%rsp)
14008bb92: 89 44 24 20                 	movl	%eax, 0x20(%rsp)
14008bb96: 48 89 f1                    	movq	%rsi, %rcx
14008bb99: 48 8b 95 50 01 00 00        	movq	0x150(%rbp), %rdx
14008bba0: e8 bb 5d 07 00              	callq	0x140101960 <.text+0x100960>
14008bba5: e9 d0 e9 ff ff              	jmp	0x14008a57a <.text+0x8957a>
14008bbaa: 4c 89 d2                    	movq	%r10, %rdx
14008bbad: e9 e9 f8 ff ff              	jmp	0x14008b49b <.text+0x8a49b>
14008bbb2: 45 31 ff                    	xorl	%r15d, %r15d
14008bbb5: 31 c0                       	xorl	%eax, %eax
14008bbb7: e9 89 eb ff ff              	jmp	0x14008a745 <.text+0x89745>
14008bbbc: 45 31 ff                    	xorl	%r15d, %r15d
14008bbbf: 31 c0                       	xorl	%eax, %eax
14008bbc1: e9 0d ed ff ff              	jmp	0x14008a8d3 <.text+0x898d3>
14008bbc6: 31 db                       	xorl	%ebx, %ebx
14008bbc8: 31 c0                       	xorl	%eax, %eax
14008bbca: e9 8d ee ff ff              	jmp	0x14008aa5c <.text+0x89a5c>
14008bbcf: 4c 8d 0d fa 19 1e 00        	leaq	0x1e19fa(%rip), %r9     # 0x14026d5d0
14008bbd6: 41 b8 08 00 00 00           	movl	$0x8, %r8d
14008bbdc: 31 c9                       	xorl	%ecx, %ecx
14008bbde: e8 7d 6f 1c 00              	callq	0x140252b60 <.text+0x251b60>
14008bbe3: 0f 0b                       	ud2
14008bbe5: 48 89 f1                    	movq	%rsi, %rcx
14008bbe8: 4c 89 d2                    	movq	%r10, %rdx
14008bbeb: 48 81 c4 f8 02 00 00        	addq	$0x2f8, %rsp            # imm = 0x2F8
14008bbf2: 5b                          	popq	%rbx
14008bbf3: 5f                          	popq	%rdi
14008bbf4: 5e                          	popq	%rsi
14008bbf5: 41 5c                       	popq	%r12
14008bbf7: 41 5d                       	popq	%r13
14008bbf9: 41 5e                       	popq	%r14
14008bbfb: 41 5f                       	popq	%r15
14008bbfd: 5d                          	popq	%rbp
14008bbfe: e9 1d 71 1c 00              	jmp	0x140252d20 <.text+0x251d20>
14008bc03: 4c 8d 0d de 19 1e 00        	leaq	0x1e19de(%rip), %r9     # 0x14026d5e8
14008bc0a: 41 b8 08 00 00 00           	movl	$0x8, %r8d
14008bc10: 31 c9                       	xorl	%ecx, %ecx
14008bc12: e8 49 6f 1c 00              	callq	0x140252b60 <.text+0x251b60>
14008bc17: 0f 0b                       	ud2
14008bc19: 45 31 ff                    	xorl	%r15d, %r15d
14008bc1c: 31 c0                       	xorl	%eax, %eax
14008bc1e: e9 61 ed ff ff              	jmp	0x14008a984 <.text+0x89984>
14008bc23: 4c 89 da                    	movq	%r11, %rdx
14008bc26: e9 70 f8 ff ff              	jmp	0x14008b49b <.text+0x8a49b>
14008bc2b: 4c 8d 0d 86 19 1e 00        	leaq	0x1e1986(%rip), %r9     # 0x14026d5b8
14008bc32: 41 b8 08 00 00 00           	movl	$0x8, %r8d
14008bc38: 31 c9                       	xorl	%ecx, %ecx
14008bc3a: e8 21 6f 1c 00              	callq	0x140252b60 <.text+0x251b60>
14008bc3f: 0f 0b                       	ud2
14008bc41: 4c 89 da                    	movq	%r11, %rdx
14008bc44: 4c 8b ad 68 02 00 00        	movq	0x268(%rbp), %r13
14008bc4b: e9 4b f8 ff ff              	jmp	0x14008b49b <.text+0x8a49b>
14008bc50: 4c 8d 0d 61 18 1e 00        	leaq	0x1e1861(%rip), %r9     # 0x14026d4b8
14008bc57: 41 b8 08 00 00 00           	movl	$0x8, %r8d
14008bc5d: 31 c9                       	xorl	%ecx, %ecx
14008bc5f: e8 fc 6e 1c 00              	callq	0x140252b60 <.text+0x251b60>
14008bc64: 0f 0b                       	ud2
14008bc66: 4c 8d 0d 13 52 1d 00        	leaq	0x1d5213(%rip), %r9     # 0x140260e80
14008bc6d: 41 b8 28 00 00 00           	movl	$0x28, %r8d
14008bc73: 31 c9                       	xorl	%ecx, %ecx
14008bc75: 48 89 c2                    	movq	%rax, %rdx
14008bc78: e8 e3 6e 1c 00              	callq	0x140252b60 <.text+0x251b60>
14008bc7d: 0f 0b                       	ud2
14008bc7f: 45 31 c9                    	xorl	%r9d, %r9d
14008bc82: 4c 8b ad 68 02 00 00        	movq	0x268(%rbp), %r13
14008bc89: 4c 89 f6                    	movq	%r14, %rsi
14008bc8c: e9 e4 fa ff ff              	jmp	0x14008b775 <.text+0x8a775>
14008bc91: 4c 89 d2                    	movq	%r10, %rdx
14008bc94: 4c 8b ad 68 02 00 00        	movq	0x268(%rbp), %r13
14008bc9b: e9 fb f7 ff ff              	jmp	0x14008b49b <.text+0x8a49b>
14008bca0: 45 31 c9                    	xorl	%r9d, %r9d
14008bca3: 4c 8b ad 68 02 00 00        	movq	0x268(%rbp), %r13
14008bcaa: 4c 89 f6                    	movq	%r14, %rsi
14008bcad: e9 a3 fd ff ff              	jmp	0x14008ba55 <.text+0x8aa55>
14008bcb2: 45 31 c0                    	xorl	%r8d, %r8d
14008bcb5: 4c 8b ad 68 02 00 00        	movq	0x268(%rbp), %r13
14008bcbc: e9 83 f3 ff ff              	jmp	0x14008b044 <.text+0x8a044>
14008bcc1: 45 31 c0                    	xorl	%r8d, %r8d
14008bcc4: 4c 8b ad 68 02 00 00        	movq	0x268(%rbp), %r13
14008bccb: e9 21 f8 ff ff              	jmp	0x14008b4f1 <.text+0x8a4f1>

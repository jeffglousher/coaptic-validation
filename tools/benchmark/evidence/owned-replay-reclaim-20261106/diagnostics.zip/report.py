"""Render retained integrated results; never run probes or builds."""
from pathlib import Path
import json, subprocess, sys
out=Path('D:/codex-work/coaptic-validation/tools/benchmark/evidence/owned-replay-reclaim-20261106')
prior=out.parent/'replay-occupancy-index-20261106'
v=(prior/'render.py').read_text(encoding='utf-8')
v=v.replace('Coaptic replay occupancy comparison','Coaptic owned replay reclaim comparison')
v=v.replace('42c8234','32c32d1')
v=v.replace("('replay-occupancy-index-20261106','Combined occupancy / message-ID filter')", "('replay-occupancy-index-20261106','Combined occupancy / message-ID filter'),('owned-replay-reclaim-20261106','Owned reclaim / occupancy fast path')")
v=v.replace('Exact candidate passes 927 library tests','Candidate production code passes 929 library tests')
start=v.index('<p>The preceding deadline-only integration failed six CPU bounds')
end=v.index('<p>Sync and actual async progress',start)
v=v[:start]+'''<p>The preceding occupancy integration failed five CPU bounds. A bounded diagnostic identified two additional key lookups whenever TX headroom reclamation downgrades an older pinned reply to an empty ACK. For n response packets, the measured count was n + 2*(n-31). The compiler already scalarizes the source row copies, so no row-copy saving is claimed here.</p><p>This integration owns the complete reclaim operation: allocated unique-key storage avoids both repeated searches; fixed storage combines one walk while preserving its public duplicate-key behavior. It also restores immediate-free-cursor acquisition in the occupancy index. No fields or allocations are added. The revised allocated model exercises failed TX releases and passes separately; callback order/count is verified by source review. This source has one fresh cohort and no replacement samples.</p>'''+v[end:]
v=v.replace('<h2>64-bit host memory: exact owners</h2>', '<p>The owned reclaim operation removes repeated key searches without adding resident metadata. Memory savings below come from the integrated compact replay and occupancy representation.</p><h2>64-bit host memory: exact owners</h2>')
v=v.replace('<h2>32-bit layout audit:', '<p class="bad">Additional emitted reclaim frame check: fixed Service grows from 784 to 816 bytes (+32), independently failing frame nongrowth. SmallDevice stays 800; allocated Service falls from 800 to 784. These are selected compiler frames, not peak stack. Returning a complete replay row introduces an extra 304-byte copy compared with the preceding compact-layout source.</p><h2>32-bit layout audit:')
(out/'render.py').write_text(v,encoding='utf-8')
subprocess.run([sys.executable,'-B',str(out/'render.py')],check=True)
r=json.loads((out/'measurement.json').read_text())
state='passes the frozen CPU preservation rule; broader qualification and merge remain separate' if r['runtime_accepted'] else 'fails the frozen CPU preservation rule and is rejected'
(out/'README.md').write_text(f'''# Owned replay reclaim integration

Exact candidate `32c32d1997fd416f9cd80feeaa867eb4d8b452bb` versus pinned baseline
`bd63199b652193b4c0a882e5840e72d992cf1362` {state}.
All 64 pairs across 28 workloads are retained; {len(r['failed_point_guards'])} cell
upper bounds exceed 1.02. `comparison.html` contains CPU charts and comparable
tables. Earlier failures remain rejected; no unchanged candidate was resampled.

The bounded diagnostic in sibling `replay-cost-diagnostic-20261106` establishes
two extra key searches per TX reclamation after the first 31 pinned replies.
The owned reclaim hook avoids both searches for allocated unique-key storage,
and combines one search for public fixed storage while preserving duplicate-key
behavior. TX release precedes removal of the first matching key, then replacement.
Deadline ties retain earliest-slot selection, deadlines remain full u64, and the
ordinary rotating acquisition cursor is preserved. Custom storage keeps the
generic fallback. The occupancy index also restores its immediate-free-cursor
fast path. No resident fields, allocations or capacity reductions are added.

The integrated source retains compact inline/TX replay ownership, scalar active
TX writes, a u32 occupancy/message-ID filter, and direct full retained-chunk
initialization. Filter matches still require the complete endpoint/key.
The compact replay type defines equality/hashing by key, deadline and current
replay owner. Discarded inactive bytes no longer affect identity; this observable
pre-release value-semantic change is documented in rustdoc. This is not a claim
of identical historical inactive-byte identity.

Host SmallDevice App saves 56 bytes; fixed Service App saves 832. Allocated Service
saves 24 inline bytes plus 832 requested pool bytes. Selected complete futures
and encoder frames are unchanged. However, the newly inspected fixed-Service
reclaim frame grows from 784 to 816 bytes, independently failing nongrowth.
SmallDevice reclaim stays800; allocated reclaim falls800 to784. Emitted code
adds a304-byte row copy versus the preceding compact-layout source.
Actual Thumbv7EM unit-transport App reductions
are 24/320/16 bytes for SmallDevice/fixed Service/allocated Service. Startup
allocation counts match baseline. These are exact owners, not peak RAM, and
requested heap excludes allocator metadata and rounding. Static target layout
does not establish device execution. Capacities and security remain matched.

Before timing: 929 library, 11 allocation/failure-injection, 27 retained-Q and
13 footprint checks pass. A final test-only correction ensures pinned TX release
failure is exercised, and that focused model passes. General static review of
42c8234 to 32c32d1 found no actionable issue. Callback count/order has source
inspection rather than a dedicated assertion. The initial wrong test-target
invocation is retained; it failed before compilation.

Run `python -B verify.py` here to independently recompute all paired results and
check hashes, capacities, exit records and owner ledgers without executing probes.
Use `python prepare.py CORE_REPO NEW_OUTPUT candidate` to reconstruct the source.
The unchanged fixture lives in sibling `dispatch-scratch-20261104/fixture`.
`observations.zip` retains exact binaries/PDBs, raw outputs and exits;
`diagnostics.zip` retains build/test/review records and selected disassembly;
`layout32.zip` retains the audit fixture, source hashes, layouts and constants.
Local owner/mailbox metadata is excluded from portable archives.

The benchmark measures complete server-App thread CPU cycles with immediate
memory transport, actual sync/async progress and a pending timer. Client work is
outside the clock. It does not measure network latency, maximum throughput,
whole-system peak memory or a new libcoap ranking. No causal comparison should
be inferred between separate experimental cohorts. Broader qualification and
production merge are separate from this frozen runtime verdict.
''',encoding='utf-8')

from pathlib import Path
import json, subprocess, hashlib, shutil
r = Path(__file__).resolve().parent
prior = Path('D:/CoapticCurrent/replay-occupancy-index-20261106')
repo = Path('C:/Users/jeffg/.t3/worktrees/coaptic/t3-a578955c')
sha = '32c32d1997fd416f9cd80feeaa867eb4d8b452bb'
old = '42c823463b1d7eac5cca31df58e1dac7b243d610'
v = json.loads((prior/'source-verification.json').read_text())
v['source'] = sha
fixture = Path(v['fixture_root'])/'coaptic'
for name in v['source_file_hashes']:
    data = subprocess.check_output(['git','-C',str(repo),'show',sha+':'+name]).replace(b'\r\n',b'\n')
    p = fixture/name
    if p.read_bytes() != data: p.write_bytes(data)
    v['source_file_hashes'][name] = hashlib.sha256(data).hexdigest()
patch = subprocess.check_output(['git','-C',str(repo),'diff','--binary',v['baseline'],sha,'--','src','crates','tests','Cargo.toml','Cargo.lock'])
(r/'candidate.patch').write_bytes(patch)
v['patch_sha256'] = hashlib.sha256(patch).hexdigest()
(r/'source-verification.json').write_text(json.dumps(v,indent=2)+'\n')
for name in ['build-preflight.py','build.py','layout.py','inspect.py','measure.py','qualify.py']:
    text = (prior/name).read_text().replace(old,sha)
    if name == 'inspect.py':
        text = text.replace('(?=^\\d+ \\| S_LPROC32)', '(?=^\\s*\\d+ \\| S_LPROC32)')
    (r/name).write_text(text)
(r/'B').mkdir(exist_ok=True)
(r/'layout32').mkdir(exist_ok=True)
for name in ['audit.py','Cargo.toml','Cargo.lock','lib.rs','baseline-build.log','baseline-constants.txt','baseline-layout.txt','baseline-source.json']:
    shutil.copyfile(prior/'layout32'/name,r/'layout32'/name)
shutil.copyfile(prior/'fixture-sha256.json',r/'fixture-sha256.json')
m = json.loads((prior/'METHOD-BEFORE.json').read_text())
m['candidate'] = sha
m['source_hypothesis'] = m['hypothesis'] = 'Owned replay reclaim combines oldest-pinned selection, TX release, key removal and replacement. Allocated unique-key storage removes two repeated exact-key lookups; fixed public storage preserves duplicate-key removal with one walk. Restore immediate-free-cursor acquisition in the u32 occupancy index. Diagnostic call counts establish two extra lookups per reclamation; emitted compiler already scalarizes row copies, so no payload-copy saving is claimed here. Compact replay and full-chunk staging remain integrated.'
m['tradeoffs'] = 'No additional resident owners or allocations. Fixed public duplicate semantics require one key walk. A new optional backend reclaim hook receives an object-safe replacement function; default preserves generic fallback. Existing compact replay equality/hash describes active bytes, not discarded historical bytes. Occupancy remains4B/slot instead of baseline1B and full-width deadlines remain in rows.'
m['preflight_repair'] = 'Prior42c8234 fails5CPU bounds. This new source eliminates verified redundant reclaim lookups; no unchanged source resampling. All original gates remain frozen.'
(r/'METHOD-BEFORE.json').write_text(json.dumps(m,indent=2)+'\n')
print({'source':sha,'verified_files':len(v['source_file_hashes'])},flush=True)

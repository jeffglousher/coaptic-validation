
D:\CoapticCurrent\owned-replay-reclaim-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009fc60:     	pushq	%rbp
14009fc61:     	pushq	%r15
14009fc63:     	pushq	%r14
14009fc65:     	pushq	%r13
14009fc67:     	pushq	%r12
14009fc69:     	pushq	%rsi
14009fc6a:     	pushq	%rdi
14009fc6b:     	pushq	%rbx
14009fc6c:     	subq	$0x308, %rsp            # imm = 0x308
14009fc73:     	leaq	0x80(%rsp), %rbp
14009fc7b:     	movq	0xe8(%rcx), %rax
14009fc82:     	testq	%rax, %rax
14009fc85:     	je	0x14009fd91 <.text+0x9ed91>
14009fc8b:     	leaq	0xc0(%rcx), %rsi
14009fc92:     	movq	0xe0(%rcx), %r9
14009fc99:     	movq	0xc8(%rcx), %r10
14009fca0:     	movq	0xd0(%rcx), %r11
14009fca7:     	xorl	%r8d, %r8d
14009fcaa:     	movl	$0x1, %edi
14009fcaf:     	movq	%rax, %r15
14009fcb2:     	xorl	%r14d, %r14d
14009fcb5:     	imulq	$0x130, %r14, %r12      # imm = 0x130
14009fcbc:     	addq	%r10, %r12
14009fcbf:     	jmp	0x14009fcdf <.text+0x9ecdf>
14009fcc1:     	nopw	%cs:(%rax,%rax)
14009fcd0:     	incq	%r14
14009fcd3:     	addq	$0x130, %r12            # imm = 0x130
14009fcda:     	cmpq	%r14, %r15
14009fcdd:     	je	0x14009fd46 <.text+0x9ed46>
14009fcdf:     	cmpq	%rax, %r14
14009fce2:     	jae	0x14009fcd0 <.text+0x9ecd0>
14009fce4:     	cmpl	$0x0, (%r9,%r14,4)
14009fce9:     	je	0x14009fcd0 <.text+0x9ecd0>
14009fceb:     	cmpq	%r11, %r14
14009fcee:     	jae	0x14009fcd0 <.text+0x9ecd0>
14009fcf0:     	movzwl	(%r12), %r13d
14009fcf5:     	cmpw	$-0x1, %r13w
14009fcfa:     	je	0x14009fcd0 <.text+0x9ecd0>
14009fcfc:     	movq	0x128(%r12), %r15
14009fd04:     	cmpw	$0x2, %r13w
14009fd09:     	setne	%r12b
14009fd0d:     	testq	%r15, %r15
14009fd10:     	sete	%r13b
14009fd14:     	orb	%r12b, %r13b
14009fd17:     	cmpq	%rbx, %r15
14009fd1a:     	setae	%r12b
14009fd1e:     	andb	%r8b, %r12b
14009fd21:     	testb	%r13b, %r13b
14009fd24:     	cmoveq	%rdi, %r8
14009fd28:     	orb	%r13b, %r12b
14009fd2b:     	cmoveq	%r14, %rdx
14009fd2f:     	cmoveq	%r15, %rbx
14009fd33:     	incq	%r14
14009fd36:     	cmpq	%rax, %r14
14009fd39:     	movq	%rax, %r15
14009fd3c:     	cmovaq	%r14, %r15
14009fd40:     	jb	0x14009fcb5 <.text+0x9ecb5>
14009fd46:     	testb	$0x1, %r8b
14009fd4a:     	je	0x14009fd91 <.text+0x9ed91>
14009fd4c:     	cmpq	%rax, %rdx
14009fd4f:     	jae	0x14009fd91 <.text+0x9ed91>
14009fd51:     	movq	0xe0(%rcx), %r8
14009fd58:     	xorl	%eax, %eax
14009fd5a:     	cmpl	$0x0, (%r8,%rdx,4)
14009fd5f:     	je	0x14009fd93 <.text+0x9ed93>
14009fd61:     	cmpq	0xd0(%rcx), %rdx
14009fd68:     	jae	0x14009fd93 <.text+0x9ed93>
14009fd6a:     	movq	0xc8(%rcx), %rax
14009fd71:     	imulq	$0x130, %rdx, %r9       # imm = 0x130
14009fd78:     	cmpw	$0x2, (%rax,%r9)
14009fd7e:     	jne	0x14009fd91 <.text+0x9ed91>
14009fd80:     	addq	%r9, %rax
14009fd83:     	movzbl	0x122(%rax), %r12d
14009fd8b:     	cmpb	$0x2, %r12b
14009fd8f:     	jne	0x14009fda7 <.text+0x9eda7>
14009fd91:     	xorl	%eax, %eax
14009fd93:     	addq	$0x308, %rsp            # imm = 0x308
14009fd9a:     	popq	%rbx
14009fd9b:     	popq	%rdi
14009fd9c:     	popq	%rsi
14009fd9d:     	popq	%r12
14009fd9f:     	popq	%r13
14009fda1:     	popq	%r14
14009fda3:     	popq	%r15
14009fda5:     	popq	%rbp
14009fda6:     	retq
14009fda7:     	movq	0x108(%rax), %rdi
14009fdae:     	movq	0x110(%rax), %r15
14009fdb5:     	movl	0x118(%rax), %r9d
14009fdbc:     	movl	%r9d, 0x27c(%rbp)
14009fdc3:     	movl	0x11c(%rax), %r9d
14009fdca:     	movl	%r9d, 0x280(%rbp)
14009fdd1:     	movzwl	0x120(%rax), %r9d
14009fdd9:     	movw	%r9w, 0x286(%rbp)
14009fde1:     	movzwl	0x124(%rax), %r13d
14009fde9:     	movzwl	0x126(%rax), %r9d
14009fdf1:     	movw	%r9w, 0x284(%rbp)
14009fdf9:     	movzbl	0x123(%rax), %r14d
14009fe01:     	movq	0x8(%rax), %r9
14009fe05:     	cmpq	0x88(%rcx), %r9
14009fe0c:     	jae	0x14009fe62 <.text+0x9ee62>
14009fe0e:     	movq	0x80(%rcx), %r10
14009fe15:     	cmpb	$0x1, (%r10,%r9)
14009fe1a:     	jne	0x14009fe62 <.text+0x9ee62>
14009fe1c:     	cmpq	0xa0(%rcx), %r9
14009fe23:     	jae	0x14009fe33 <.text+0x9ee33>
14009fe25:     	movq	0x98(%rcx), %r11
14009fe2c:     	cmpb	$0x0, (%r11,%r9)
14009fe31:     	jne	0x14009fe62 <.text+0x9ee62>
14009fe33:     	movb	$0x0, (%r10,%r9)
14009fe38:     	decq	0xb0(%rcx)
14009fe3f:     	cmpq	0x70(%rcx), %r9
14009fe43:     	jae	0x14009fe62 <.text+0x9ee62>
14009fe45:     	movq	0x68(%rcx), %r10
14009fe49:     	imulq	$0x58, %r9, %r9
14009fe4d:     	movq	$0x0, 0x30(%r10,%r9)
14009fe56:     	movb	$0x2, 0x52(%r10,%r9)
14009fe5c:     	movb	$0x2, 0x25(%r10,%r9)
14009fe62:     	cmpl	$0x0, (%r8,%rdx,4)
14009fe67:     	je	0x14009fe7d <.text+0x9ee7d>
14009fe69:     	movl	$0x0, (%r8,%rdx,4)
14009fe71:     	decq	0xf8(%rcx)
14009fe78:     	movw	$0xffff, (%rax)         # imm = 0xFFFF
14009fe7d:     	movq	%rcx, 0x268(%rbp)
14009fe84:     	xorps	%xmm0, %xmm0
14009fe87:     	movaps	%xmm0, 0x250(%rbp)
14009fe8e:     	movb	$0x0, 0x132(%rbp)
14009fe95:     	movw	%r13w, 0x130(%rbp)
14009fe9d:     	leaq	0x133(%rbp), %rax
14009fea4:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009fead:     	movq	$0x0, 0x133(%rbp)
14009feb8:     	movq	$0x8, 0x110(%rbp)
14009fec3:     	movq	$0x0, 0x118(%rbp)
14009fece:     	movq	$0x1, 0x120(%rbp)
14009fed9:     	movq	$0x0, 0x128(%rbp)
14009fee4:     	movq	%rax, 0x30(%rsp)
14009fee9:     	movw	%r13w, 0x28(%rsp)
14009feef:     	movq	$0x0, 0x58(%rsp)
14009fef8:     	movq	$0x1, 0x50(%rsp)
14009ff01:     	movq	$0x8, 0x48(%rsp)
14009ff0a:     	movq	$0x8, 0x40(%rsp)
14009ff13:     	movq	$0x0, 0x38(%rsp)
14009ff1c:     	movb	$0x0, 0x20(%rsp)
14009ff21:     	leaq	0x240(%rbp), %rcx
14009ff28:     	leaq	0x250(%rbp), %rdx
14009ff2f:     	movl	$0x10, %r8d
14009ff35:     	movb	$0x2, %r9b
14009ff38:     	callq	0x140005590 <.text+0x4590>
14009ff3d:     	cmpb	$0x1, 0x240(%rbp)
14009ff44:     	je	0x1400a00b0 <.text+0x9f0b0>
14009ff4a:     	movq	%rdi, %rax
14009ff4d:     	movq	0x248(%rbp), %rdi
14009ff54:     	movq	%rax, 0x270(%rbp)
14009ff5b:     	movq	%rax, 0xe8(%rbp)
14009ff62:     	movq	%r15, 0xf0(%rbp)
14009ff69:     	movl	0x27c(%rbp), %eax
14009ff6f:     	movl	%eax, 0xf8(%rbp)
14009ff75:     	movl	0x280(%rbp), %eax
14009ff7b:     	movl	%eax, 0xfc(%rbp)
14009ff81:     	movzwl	0x286(%rbp), %eax
14009ff88:     	movw	%ax, 0x100(%rbp)
14009ff8f:     	movb	%r12b, 0x102(%rbp)
14009ff96:     	movb	%r14b, 0x103(%rbp)
14009ff9d:     	movw	%r13w, 0x104(%rbp)
14009ffa5:     	movzwl	0x284(%rbp), %eax
14009ffac:     	movw	%ax, 0x106(%rbp)
14009ffb3:     	movq	%rbx, 0x108(%rbp)
14009ffba:     	cmpq	$0x11, %rdi
14009ffbe:     	jae	0x1400a00b7 <.text+0x9f0b7>
14009ffc4:     	testq	%rdi, %rdi
14009ffc7:     	je	0x1400a0001 <.text+0x9f001>
14009ffc9:     	movw	%di, -0x1e(%rbp)
14009ffcd:     	leaq	-0x1c(%rbp), %rbx
14009ffd1:     	movl	$0x100, %r8d            # imm = 0x100
14009ffd7:     	subq	%rdi, %r8
14009ffda:     	leaq	(%rdi,%rbp), %rcx
14009ffde:     	addq	$-0x1c, %rcx
14009ffe2:     	xorl	%edx, %edx
14009ffe4:     	callq	0x140251dd2 <.text+0x250dd2>
14009ffe9:     	leaq	0x250(%rbp), %rdx
14009fff0:     	movq	%rbx, %rcx
14009fff3:     	movq	%rdi, %r8
14009fff6:     	callq	0x140251dc0 <.text+0x250dc0>
14009fffb:     	movw	$0x1, %di
14009ffff:     	jmp	0x1400a0003 <.text+0x9f003>
1400a0001:     	xorl	%edi, %edi
1400a0003:     	leaq	-0x1e(%rbp), %rdx
1400a0007:     	leaq	0x112(%rbp), %rcx
1400a000e:     	movl	$0x12e, %r8d            # imm = 0x12E
1400a0014:     	callq	0x140251dc0 <.text+0x250dc0>
1400a0019:     	movw	%di, 0x110(%rbp)
1400a0020:     	cmpw	%r13w, 0x234(%rbp)
1400a0028:     	jne	0x1400a00a1 <.text+0x9f0a1>
1400a002a:     	movl	0x27c(%rbp), %eax
1400a0030:     	cmpl	%eax, 0x228(%rbp)
1400a0036:     	jne	0x1400a00a1 <.text+0x9f0a1>
1400a0038:     	movl	0x280(%rbp), %eax
1400a003e:     	cmpl	%eax, 0x22c(%rbp)
1400a0044:     	jne	0x1400a00a1 <.text+0x9f0a1>
1400a0046:     	movzwl	0x286(%rbp), %eax
1400a004d:     	cmpw	%ax, 0x230(%rbp)
1400a0054:     	jne	0x1400a00a1 <.text+0x9f0a1>
1400a0056:     	cmpb	%r12b, 0x232(%rbp)
1400a005d:     	jne	0x1400a00a1 <.text+0x9f0a1>
1400a005f:     	movq	0x270(%rbp), %rax
1400a0066:     	xorq	0x218(%rbp), %rax
1400a006d:     	xorq	0x220(%rbp), %r15
1400a0074:     	orq	%rax, %r15
1400a0077:     	jne	0x1400a00a1 <.text+0x9f0a1>
1400a0079:     	movq	0x268(%rbp), %rcx
1400a0080:     	addq	$0xd8, %rcx
1400a0087:     	callq	0x140219d10 <.text+0x218d10>
1400a008c:     	testb	$0x1, %al
1400a008e:     	je	0x1400a00b0 <.text+0x9f0b0>
1400a0090:     	leaq	0x110(%rbp), %r8
1400a0097:     	movq	%rsi, %rcx
1400a009a:     	callq	0x14000b6d0 <.text+0xa6d0>
1400a009f:     	jmp	0x1400a00b0 <.text+0x9f0b0>
1400a00a1:     	leaq	0x110(%rbp), %rdx
1400a00a8:     	movq	%rsi, %rcx
1400a00ab:     	callq	0x1400118e0 <.text+0x108e0>
1400a00b0:     	movb	$0x1, %al
1400a00b2:     	jmp	0x14009fd93 <.text+0x9ed93>
1400a00b7:     	leaq	0x1c1402(%rip), %r9     # 0x1402614c0
1400a00be:     	movl	$0x10, %r8d
1400a00c4:     	xorl	%ecx, %ecx
1400a00c6:     	movq	%rdi, %rdx
1400a00c9:     	callq	0x140252850 <.text+0x251850>
1400a00ce:     	ud2


D:\CoapticCurrent\owned-replay-reclaim-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009edd0:     	pushq	%rbp
14009edd1:     	pushq	%r15
14009edd3:     	pushq	%r14
14009edd5:     	pushq	%r13
14009edd7:     	pushq	%r12
14009edd9:     	pushq	%rsi
14009edda:     	pushq	%rdi
14009eddb:     	pushq	%rbx
14009eddc:     	subq	$0x318, %rsp            # imm = 0x318
14009ede3:     	leaq	0x80(%rsp), %rbp
14009edeb:     	movaps	%xmm6, 0x280(%rbp)
14009edf2:     	leaq	0x3a60(%rcx), %rdx
14009edf9:     	leaq	0x2ac8(%rcx), %rsi
14009ee00:     	leaq	0x2bf0(%rcx), %rax
14009ee07:     	xorl	%r10d, %r10d
14009ee0a:     	movl	$0x1, %r11d
14009ee10:     	xorl	%r9d, %r9d
14009ee13:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009ee1a:     	addq	%rax, %rdi
14009ee1d:     	jmp	0x14009ee30 <.text+0x9de30>
14009ee1f:     	nop
14009ee20:     	incq	%r10
14009ee23:     	addq	$0x130, %rdi            # imm = 0x130
14009ee2a:     	cmpq	$0x4, %r10
14009ee2e:     	je	0x14009ee86 <.text+0x9de86>
14009ee30:     	cmpl	$0x0, 0x4c0(%rsi,%r10,4)
14009ee39:     	je	0x14009ee20 <.text+0x9de20>
14009ee3b:     	movzwl	-0x128(%rdi), %r14d
14009ee43:     	cmpw	$-0x1, %r14w
14009ee48:     	je	0x14009ee20 <.text+0x9de20>
14009ee4a:     	movq	(%rdi), %rdi
14009ee4d:     	cmpw	$0x2, %r14w
14009ee52:     	setne	%r14b
14009ee56:     	testq	%rdi, %rdi
14009ee59:     	sete	%r15b
14009ee5d:     	orb	%r14b, %r15b
14009ee60:     	cmpq	%rbx, %rdi
14009ee63:     	setae	%r14b
14009ee67:     	andb	%r9b, %r14b
14009ee6a:     	testb	%r15b, %r15b
14009ee6d:     	cmoveq	%r11, %r9
14009ee71:     	orb	%r15b, %r14b
14009ee74:     	cmoveq	%r10, %r8
14009ee78:     	cmoveq	%rdi, %rbx
14009ee7c:     	cmpq	$0x3, %r10
14009ee80:     	leaq	0x1(%r10), %r10
14009ee84:     	jb	0x14009ee13 <.text+0x9de13>
14009ee86:     	xorl	%eax, %eax
14009ee88:     	cmpq	$0x1, %r9
14009ee8c:     	jne	0x14009eec1 <.text+0x9dec1>
14009ee8e:     	cmpq	$0x4, %r8
14009ee92:     	jae	0x14009eec1 <.text+0x9dec1>
14009ee94:     	cmpl	$0x0, 0x2f88(%rcx,%r8,4)
14009ee9d:     	je	0x14009eebf <.text+0x9debf>
14009ee9f:     	imulq	$0x130, %r8, %r8        # imm = 0x130
14009eea6:     	cmpw	$0x2, (%rsi,%r8)
14009eeac:     	jne	0x14009eebf <.text+0x9debf>
14009eeae:     	addq	%rsi, %r8
14009eeb1:     	movzbl	0x122(%r8), %r13d
14009eeb9:     	cmpb	$0x2, %r13b
14009eebd:     	jne	0x14009eedc <.text+0x9dedc>
14009eebf:     	xorl	%eax, %eax
14009eec1:     	movaps	0x280(%rbp), %xmm6
14009eec8:     	addq	$0x318, %rsp            # imm = 0x318
14009eecf:     	popq	%rbx
14009eed0:     	popq	%rdi
14009eed1:     	popq	%rsi
14009eed2:     	popq	%r12
14009eed4:     	popq	%r13
14009eed6:     	popq	%r14
14009eed8:     	popq	%r15
14009eeda:     	popq	%rbp
14009eedb:     	retq
14009eedc:     	movq	0x8(%r8), %rax
14009eee0:     	movq	0x108(%r8), %rdi
14009eee7:     	movq	0x110(%r8), %r12
14009eeee:     	movl	0x118(%r8), %r9d
14009eef5:     	movl	%r9d, 0x278(%rbp)
14009eefc:     	movl	0x11c(%r8), %r11d
14009ef03:     	movzwl	0x120(%r8), %r10d
14009ef0b:     	movzbl	0x123(%r8), %r9d
14009ef13:     	movb	%r9b, 0x27d(%rbp)
14009ef1a:     	movss	0x124(%r8), %xmm6
14009ef23:     	movzwl	0x124(%r8), %r15d
14009ef2b:     	movzwl	%r15w, %r14d
14009ef2f:     	cmpq	$0x1, %rax
14009ef33:     	ja	0x14009ef84 <.text+0x9df84>
14009ef35:     	cmpb	$0x1, 0x43e8(%rcx,%rax)
14009ef3d:     	jne	0x14009ef84 <.text+0x9df84>
14009ef3f:     	cmpb	$0x0, 0x43ea(%rcx,%rax)
14009ef47:     	jne	0x14009ef84 <.text+0x9df84>
14009ef49:     	movb	$0x0, 0x43e8(%rcx,%rax)
14009ef51:     	decq	0x43e0(%rcx)
14009ef58:     	movq	$0x0, 0x4360(%rcx,%rax,8)
14009ef64:     	leaq	(%rax,%rax,8), %r8
14009ef68:     	leaq	(%r8,%r8,2), %r8
14009ef6c:     	addq	%rax, %r8
14009ef6f:     	movb	$0x2, 0x95a(%rdx,%r8)
14009ef78:     	leaq	(%rax,%rax,2), %rax
14009ef7c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009ef84:     	addl	$0x2, %r14d
14009ef88:     	xorl	%r8d, %r8d
14009ef8b:     	movb	$0x1, %r9b
14009ef8e:     	cmpl	%r14d, 0x2f88(%rcx)
14009ef95:     	jne	0x14009f00d <.text+0x9e00d>
14009ef97:     	cmpw	$-0x1, 0x2ac8(%rcx)
14009ef9f:     	je	0x14009f00d <.text+0x9e00d>
14009efa1:     	cmpw	%r15w, 0x2bec(%rcx)
14009efa9:     	sete	%al
14009efac:     	movl	0x278(%rbp), %edx
14009efb2:     	cmpl	%edx, 0x2be0(%rcx)
14009efb8:     	sete	%dl
14009efbb:     	andb	%al, %dl
14009efbd:     	cmpl	%r11d, 0x2be4(%rcx)
14009efc4:     	sete	%al
14009efc7:     	cmpw	%r10w, 0x2be8(%rcx)
14009efcf:     	sete	%r8b
14009efd3:     	andb	%al, %r8b
14009efd6:     	andb	%dl, %r8b
14009efd9:     	cmpb	%r13b, 0x2bea(%rcx)
14009efe0:     	sete	%al
14009efe3:     	movq	0x2bd8(%rcx), %rdx
14009efea:     	xorq	%r12, %rdx
14009efed:     	movq	0x2bd0(%rcx), %r9
14009eff4:     	xorq	%rdi, %r9
14009eff7:     	orq	%rdx, %r9
14009effa:     	sete	%dl
14009effd:     	andb	%al, %dl
14009efff:     	andb	%r8b, %dl
14009f002:     	movzbl	%dl, %r8d
14009f006:     	movl	%r8d, %r9d
14009f009:     	xorb	$0x1, %r9b
14009f00d:     	xorl	%eax, %eax
14009f00f:     	cmpl	%r14d, 0x2f8c(%rcx)
14009f016:     	movw	%r10w, 0x27e(%rbp)
14009f01e:     	movl	%r11d, 0x274(%rbp)
14009f025:     	jne	0x14009f0cb <.text+0x9e0cb>
14009f02b:     	cmpw	$-0x1, 0x2bf8(%rcx)
14009f033:     	je	0x14009f0cb <.text+0x9e0cb>
14009f039:     	cmpw	%r15w, 0x2d1c(%rcx)
14009f041:     	setne	%al
14009f044:     	movl	0x278(%rbp), %edx
14009f04a:     	cmpl	%edx, 0x2d10(%rcx)
14009f050:     	setne	%dl
14009f053:     	orb	%al, %dl
14009f055:     	cmpl	%r11d, 0x2d14(%rcx)
14009f05c:     	setne	%al
14009f05f:     	cmpw	%r10w, 0x2d18(%rcx)
14009f067:     	setne	%r10b
14009f06b:     	orb	%al, %r10b
14009f06e:     	orb	%dl, %r10b
14009f071:     	cmpb	%r13b, 0x2d1a(%rcx)
14009f078:     	setne	%dl
14009f07b:     	movq	0x2d08(%rcx), %rax
14009f082:     	xorq	%r12, %rax
14009f085:     	movq	0x2d00(%rcx), %r11
14009f08c:     	xorq	%rdi, %r11
14009f08f:     	orq	%rax, %r11
14009f092:     	setne	%al
14009f095:     	orb	%dl, %al
14009f097:     	orb	%r10b, %al
14009f09a:     	orb	%al, %r9b
14009f09d:     	testb	%al, %al
14009f09f:     	movl	$0x1, %edx
14009f0a4:     	cmovneq	%r8, %rdx
14009f0a8:     	testb	$0x1, %r9b
14009f0ac:     	je	0x14009f1d3 <.text+0x9e1d3>
14009f0b2:     	notb	%al
14009f0b4:     	movzbl	%al, %eax
14009f0b7:     	andl	$0x1, %eax
14009f0ba:     	movzwl	0x27e(%rbp), %r10d
14009f0c2:     	movl	0x274(%rbp), %r11d
14009f0c9:     	jmp	0x14009f0ce <.text+0x9e0ce>
14009f0cb:     	movq	%r8, %rdx
14009f0ce:     	cmpl	%r14d, 0x2f90(%rcx)
14009f0d5:     	jne	0x14009f155 <.text+0x9e155>
14009f0d7:     	cmpw	$-0x1, 0x2d28(%rcx)
14009f0df:     	je	0x14009f155 <.text+0x9e155>
14009f0e1:     	cmpw	%r15w, 0x2e4c(%rcx)
14009f0e9:     	jne	0x14009f155 <.text+0x9e155>
14009f0eb:     	movl	0x278(%rbp), %r8d
14009f0f2:     	cmpl	%r8d, 0x2e40(%rcx)
14009f0f9:     	jne	0x14009f155 <.text+0x9e155>
14009f0fb:     	cmpl	%r11d, 0x2e44(%rcx)
14009f102:     	jne	0x14009f155 <.text+0x9e155>
14009f104:     	cmpw	%r10w, 0x2e48(%rcx)
14009f10c:     	jne	0x14009f155 <.text+0x9e155>
14009f10e:     	cmpb	%r13b, 0x2e4a(%rcx)
14009f115:     	jne	0x14009f155 <.text+0x9e155>
14009f117:     	movq	0x2e30(%rcx), %r8
14009f11e:     	xorq	%rdi, %r8
14009f121:     	movq	0x2e38(%rcx), %r9
14009f128:     	xorq	%r12, %r9
14009f12b:     	orq	%r8, %r9
14009f12e:     	jne	0x14009f155 <.text+0x9e155>
14009f130:     	movb	$0x1, %r8b
14009f133:     	testq	%rdx, %rdx
14009f136:     	jne	0x14009f1d8 <.text+0x9e1d8>
14009f13c:     	movl	$0x2, %eax
14009f141:     	movl	$0x1, %edx
14009f146:     	movzwl	0x27e(%rbp), %r10d
14009f14e:     	movl	0x274(%rbp), %r11d
14009f155:     	cmpl	%r14d, 0x2f94(%rcx)
14009f15c:     	jne	0x14009f1c9 <.text+0x9e1c9>
14009f15e:     	cmpw	$-0x1, 0x2e58(%rcx)
14009f166:     	je	0x14009f1c9 <.text+0x9e1c9>
14009f168:     	cmpw	%r15w, 0x2f7c(%rcx)
14009f170:     	jne	0x14009f1c9 <.text+0x9e1c9>
14009f172:     	movl	0x278(%rbp), %r8d
14009f179:     	cmpl	%r8d, 0x2f70(%rcx)
14009f180:     	jne	0x14009f1c9 <.text+0x9e1c9>
14009f182:     	cmpl	%r11d, 0x2f74(%rcx)
14009f189:     	jne	0x14009f1c9 <.text+0x9e1c9>
14009f18b:     	cmpw	%r10w, 0x2f78(%rcx)
14009f193:     	jne	0x14009f1c9 <.text+0x9e1c9>
14009f195:     	cmpb	%r13b, 0x2f7a(%rcx)
14009f19c:     	jne	0x14009f1c9 <.text+0x9e1c9>
14009f19e:     	movq	0x2f60(%rcx), %r8
14009f1a5:     	xorq	%rdi, %r8
14009f1a8:     	movq	0x2f68(%rcx), %r9
14009f1af:     	xorq	%r12, %r9
14009f1b2:     	orq	%r8, %r9
14009f1b5:     	jne	0x14009f1c9 <.text+0x9e1c9>
14009f1b7:     	testq	%rdx, %rdx
14009f1ba:     	movl	$0x3, %r8d
14009f1c0:     	cmoveq	%r8, %rax
14009f1c4:     	movl	%edx, %r8d
14009f1c7:     	jmp	0x14009f1d8 <.text+0x9e1d8>
14009f1c9:     	xorl	%r8d, %r8d
14009f1cc:     	testq	%rdx, %rdx
14009f1cf:     	jne	0x14009f1d8 <.text+0x9e1d8>
14009f1d1:     	jmp	0x14009f201 <.text+0x9e201>
14009f1d3:     	movb	$0x1, %r8b
14009f1d6:     	xorl	%eax, %eax
14009f1d8:     	cmpl	$0x0, 0x2f88(%rcx,%rax,4)
14009f1e0:     	je	0x14009f201 <.text+0x9e201>
14009f1e2:     	movl	$0x0, 0x2f88(%rcx,%rax,4)
14009f1ed:     	decq	0x2fa0(%rcx)
14009f1f4:     	imulq	$0x130, %rax, %rax      # imm = 0x130
14009f1fb:     	movw	$0xffff, (%rsi,%rax)    # imm = 0xFFFF
14009f201:     	movl	%r8d, 0x26c(%rbp)
14009f208:     	movq	%r12, 0x260(%rbp)
14009f20f:     	movq	%rcx, %r12
14009f212:     	xorps	%xmm0, %xmm0
14009f215:     	movaps	%xmm0, 0x250(%rbp)
14009f21c:     	movb	$0x0, 0x132(%rbp)
14009f223:     	movw	%r15w, 0x130(%rbp)
14009f22b:     	leaq	0x133(%rbp), %rax
14009f232:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009f23b:     	movq	$0x0, 0x133(%rbp)
14009f246:     	movq	$0x8, 0x110(%rbp)
14009f251:     	movq	$0x0, 0x118(%rbp)
14009f25c:     	movq	$0x1, 0x120(%rbp)
14009f267:     	movq	$0x0, 0x128(%rbp)
14009f272:     	movq	%rax, 0x30(%rsp)
14009f277:     	movw	%r15w, 0x28(%rsp)
14009f27d:     	movq	$0x0, 0x58(%rsp)
14009f286:     	movq	$0x1, 0x50(%rsp)
14009f28f:     	movq	$0x8, 0x48(%rsp)
14009f298:     	movq	$0x8, 0x40(%rsp)
14009f2a1:     	movq	$0x0, 0x38(%rsp)
14009f2aa:     	movb	$0x0, 0x20(%rsp)
14009f2af:     	leaq	0x240(%rbp), %rcx
14009f2b6:     	leaq	0x250(%rbp), %rdx
14009f2bd:     	movl	$0x10, %r8d
14009f2c3:     	movb	$0x2, %r9b
14009f2c6:     	callq	0x140005590 <.text+0x4590>
14009f2cb:     	cmpb	$0x1, 0x240(%rbp)
14009f2d2:     	je	0x14009f4e2 <.text+0x9e4e2>
14009f2d8:     	movl	%r14d, 0x270(%rbp)
14009f2df:     	movq	%rdi, %rax
14009f2e2:     	movq	0x248(%rbp), %rdi
14009f2e9:     	movq	%rax, %r14
14009f2ec:     	movq	%rax, 0xe8(%rbp)
14009f2f3:     	movq	0x260(%rbp), %rax
14009f2fa:     	movq	%rax, 0xf0(%rbp)
14009f301:     	movl	0x278(%rbp), %eax
14009f307:     	movl	%eax, 0xf8(%rbp)
14009f30d:     	movl	0x274(%rbp), %eax
14009f313:     	movl	%eax, 0xfc(%rbp)
14009f319:     	movzwl	0x27e(%rbp), %eax
14009f320:     	movw	%ax, 0x100(%rbp)
14009f327:     	movb	%r13b, 0x102(%rbp)
14009f32e:     	movzbl	0x27d(%rbp), %eax
14009f335:     	movb	%al, 0x103(%rbp)
14009f33b:     	movss	%xmm6, 0x104(%rbp)
14009f343:     	movq	%rbx, 0x108(%rbp)
14009f34a:     	cmpq	$0x11, %rdi
14009f34e:     	jae	0x14009f54f <.text+0x9e54f>
14009f354:     	testq	%rdi, %rdi
14009f357:     	je	0x14009f391 <.text+0x9e391>
14009f359:     	movw	%di, -0x1e(%rbp)
14009f35d:     	leaq	-0x1c(%rbp), %rbx
14009f361:     	movl	$0x100, %r8d            # imm = 0x100
14009f367:     	subq	%rdi, %r8
14009f36a:     	leaq	(%rdi,%rbp), %rcx
14009f36e:     	addq	$-0x1c, %rcx
14009f372:     	xorl	%edx, %edx
14009f374:     	callq	0x140251dd2 <.text+0x250dd2>
14009f379:     	leaq	0x250(%rbp), %rdx
14009f380:     	movq	%rbx, %rcx
14009f383:     	movq	%rdi, %r8
14009f386:     	callq	0x140251dc0 <.text+0x250dc0>
14009f38b:     	movw	$0x1, %ax
14009f38f:     	jmp	0x14009f393 <.text+0x9e393>
14009f391:     	xorl	%eax, %eax
14009f393:     	movw	%ax, -0x20(%rbp)
14009f397:     	leaq	0x110(%rbp), %rcx
14009f39e:     	leaq	-0x20(%rbp), %rdx
14009f3a2:     	movl	$0x130, %r8d            # imm = 0x130
14009f3a8:     	callq	0x140251dc0 <.text+0x250dc0>
14009f3ad:     	cmpw	$-0x1, 0x110(%rbp)
14009f3b5:     	movl	0x270(%rbp), %r9d
14009f3bc:     	je	0x14009f4e2 <.text+0x9e4e2>
14009f3c2:     	cmpw	%r15w, 0x234(%rbp)
14009f3ca:     	jne	0x14009f4d3 <.text+0x9e4d3>
14009f3d0:     	movl	0x278(%rbp), %ecx
14009f3d6:     	cmpl	%ecx, 0x228(%rbp)
14009f3dc:     	jne	0x14009f4d3 <.text+0x9e4d3>
14009f3e2:     	movl	0x274(%rbp), %ecx
14009f3e8:     	cmpl	%ecx, 0x22c(%rbp)
14009f3ee:     	jne	0x14009f4d3 <.text+0x9e4d3>
14009f3f4:     	movzwl	0x27e(%rbp), %ecx
14009f3fb:     	cmpw	%cx, 0x230(%rbp)
14009f402:     	jne	0x14009f4d3 <.text+0x9e4d3>
14009f408:     	cmpb	%r13b, 0x232(%rbp)
14009f40f:     	jne	0x14009f4d3 <.text+0x9e4d3>
14009f415:     	xorq	0x218(%rbp), %r14
14009f41c:     	movq	0x260(%rbp), %rcx
14009f423:     	xorq	0x220(%rbp), %rcx
14009f42a:     	orq	%r14, %rcx
14009f42d:     	jne	0x14009f4d3 <.text+0x9e4d3>
14009f433:     	cmpb	$0x0, 0x26c(%rbp)
14009f43a:     	jne	0x14009f4e2 <.text+0x9e4e2>
14009f440:     	cmpq	$0x4, 0x2fa0(%r12)
14009f449:     	je	0x14009f4e2 <.text+0x9e4e2>
14009f44f:     	movq	0x2f98(%r12), %rcx
14009f457:     	cmpq	$0x3, %rcx
14009f45b:     	ja	0x14009f568 <.text+0x9e568>
14009f461:     	cmpl	$0x0, 0x2f88(%r12,%rcx,4)
14009f46a:     	je	0x14009f4f6 <.text+0x9e4f6>
14009f470:     	leaq	(,%rcx,4), %r8
14009f478:     	xorl	%edx, %edx
14009f47a:     	cmpl	$0x0, 0x2f88(%r12,%r8)
14009f483:     	je	0x14009f4e9 <.text+0x9e4e9>
14009f485:     	addq	$0x4, %r8
14009f489:     	decq	%rdx
14009f48c:     	cmpq	$0x10, %r8
14009f490:     	jne	0x14009f47a <.text+0x9e47a>
14009f492:     	testq	%rcx, %rcx
14009f495:     	je	0x14009f4e2 <.text+0x9e4e2>
14009f497:     	cmpl	$0x0, 0x2f88(%r12)
14009f4a0:     	je	0x14009f544 <.text+0x9e544>
14009f4a6:     	cmpq	$0x1, %rcx
14009f4aa:     	je	0x14009f4e2 <.text+0x9e4e2>
14009f4ac:     	cmpl	$0x0, 0x2f8c(%r12)
14009f4b5:     	je	0x14009f548 <.text+0x9e548>
14009f4bb:     	cmpq	$0x2, %rcx
14009f4bf:     	je	0x14009f4e2 <.text+0x9e4e2>
14009f4c1:     	movl	$0x2, %ecx
14009f4c6:     	cmpl	$0x0, 0x2f90(%r12)
14009f4cf:     	je	0x14009f4ec <.text+0x9e4ec>
14009f4d1:     	jmp	0x14009f4e2 <.text+0x9e4e2>
14009f4d3:     	leaq	0x110(%rbp), %rdx
14009f4da:     	movq	%rsi, %rcx
14009f4dd:     	callq	0x140216ef0 <.text+0x215ef0>
14009f4e2:     	movb	$0x1, %al
14009f4e4:     	jmp	0x14009eec1 <.text+0x9dec1>
14009f4e9:     	subq	%rdx, %rcx
14009f4ec:     	cmpq	$0x4, %rcx
14009f4f0:     	jae	0x14009f57b <.text+0x9e57b>
14009f4f6:     	movl	$0x1, 0x2f88(%r12,%rcx,4)
14009f502:     	incq	0x2fa0(%r12)
14009f50a:     	leaq	0x1(%rcx), %rdx
14009f50e:     	xorl	%r8d, %r8d
14009f511:     	cmpq	$0x4, %rdx
14009f515:     	cmovneq	%rdx, %r8
14009f519:     	movq	%r8, 0x2f98(%r12)
14009f521:     	movl	%r9d, 0x2f88(%r12,%rcx,4)
14009f529:     	imulq	$0x130, %rcx, %rax      # imm = 0x130
14009f530:     	addq	%rax, %rsi
14009f533:     	leaq	0x110(%rbp), %rcx
14009f53a:     	movq	%rsi, %rdx
14009f53d:     	callq	0x14000b1c0 <.text+0xa1c0>
14009f542:     	jmp	0x14009f4e2 <.text+0x9e4e2>
14009f544:     	xorl	%ecx, %ecx
14009f546:     	jmp	0x14009f4ec <.text+0x9e4ec>
14009f548:     	movl	$0x1, %ecx
14009f54d:     	jmp	0x14009f4ec <.text+0x9e4ec>
14009f54f:     	leaq	0x1c1f6a(%rip), %r9     # 0x1402614c0
14009f556:     	movl	$0x10, %r8d
14009f55c:     	xorl	%ecx, %ecx
14009f55e:     	movq	%rdi, %rdx
14009f561:     	callq	0x140252850 <.text+0x251850>
14009f566:     	ud2
14009f568:     	leaq	0x1ce891(%rip), %r8     # 0x14026de00
14009f56f:     	movl	$0x4, %edx
14009f574:     	callq	0x140252643 <.text+0x251643>
14009f579:     	ud2
14009f57b:     	leaq	0x1ce896(%rip), %r8     # 0x14026de18
14009f582:     	movl	$0x4, %edx
14009f587:     	callq	0x140252643 <.text+0x251643>
14009f58c:     	ud2

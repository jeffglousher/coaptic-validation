
D:\CoapticCurrent\owned-replay-reclaim-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009e610:     	pushq	%rbp
14009e611:     	pushq	%r15
14009e613:     	pushq	%r14
14009e615:     	pushq	%r13
14009e617:     	pushq	%r12
14009e619:     	pushq	%rsi
14009e61a:     	pushq	%rdi
14009e61b:     	pushq	%rbx
14009e61c:     	subq	$0x318, %rsp            # imm = 0x318
14009e623:     	leaq	0x80(%rsp), %rbp
14009e62b:     	movaps	%xmm6, 0x280(%rbp)
14009e632:     	leaq	0x14c0(%rcx), %rdx
14009e639:     	leaq	0x528(%rcx), %rsi
14009e640:     	leaq	0x650(%rcx), %rax
14009e647:     	xorl	%r10d, %r10d
14009e64a:     	movl	$0x1, %r11d
14009e650:     	xorl	%r9d, %r9d
14009e653:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009e65a:     	addq	%rax, %rdi
14009e65d:     	jmp	0x14009e670 <.text+0x9d670>
14009e65f:     	nop
14009e660:     	incq	%r10
14009e663:     	addq	$0x130, %rdi            # imm = 0x130
14009e66a:     	cmpq	$0x4, %r10
14009e66e:     	je	0x14009e6c6 <.text+0x9d6c6>
14009e670:     	cmpl	$0x0, 0x4c0(%rsi,%r10,4)
14009e679:     	je	0x14009e660 <.text+0x9d660>
14009e67b:     	movzwl	-0x128(%rdi), %r14d
14009e683:     	cmpw	$-0x1, %r14w
14009e688:     	je	0x14009e660 <.text+0x9d660>
14009e68a:     	movq	(%rdi), %rdi
14009e68d:     	cmpw	$0x2, %r14w
14009e692:     	setne	%r14b
14009e696:     	testq	%rdi, %rdi
14009e699:     	sete	%r15b
14009e69d:     	orb	%r14b, %r15b
14009e6a0:     	cmpq	%rbx, %rdi
14009e6a3:     	setae	%r14b
14009e6a7:     	andb	%r9b, %r14b
14009e6aa:     	testb	%r15b, %r15b
14009e6ad:     	cmoveq	%r11, %r9
14009e6b1:     	orb	%r15b, %r14b
14009e6b4:     	cmoveq	%r10, %r8
14009e6b8:     	cmoveq	%rdi, %rbx
14009e6bc:     	cmpq	$0x3, %r10
14009e6c0:     	leaq	0x1(%r10), %r10
14009e6c4:     	jb	0x14009e653 <.text+0x9d653>
14009e6c6:     	xorl	%eax, %eax
14009e6c8:     	cmpq	$0x1, %r9
14009e6cc:     	jne	0x14009e701 <.text+0x9d701>
14009e6ce:     	cmpq	$0x4, %r8
14009e6d2:     	jae	0x14009e701 <.text+0x9d701>
14009e6d4:     	cmpl	$0x0, 0x9e8(%rcx,%r8,4)
14009e6dd:     	je	0x14009e6ff <.text+0x9d6ff>
14009e6df:     	imulq	$0x130, %r8, %r8        # imm = 0x130
14009e6e6:     	cmpw	$0x2, (%rsi,%r8)
14009e6ec:     	jne	0x14009e6ff <.text+0x9d6ff>
14009e6ee:     	addq	%rsi, %r8
14009e6f1:     	movzbl	0x122(%r8), %r13d
14009e6f9:     	cmpb	$0x2, %r13b
14009e6fd:     	jne	0x14009e71c <.text+0x9d71c>
14009e6ff:     	xorl	%eax, %eax
14009e701:     	movaps	0x280(%rbp), %xmm6
14009e708:     	addq	$0x318, %rsp            # imm = 0x318
14009e70f:     	popq	%rbx
14009e710:     	popq	%rdi
14009e711:     	popq	%rsi
14009e712:     	popq	%r12
14009e714:     	popq	%r13
14009e716:     	popq	%r14
14009e718:     	popq	%r15
14009e71a:     	popq	%rbp
14009e71b:     	retq
14009e71c:     	movq	0x8(%r8), %rax
14009e720:     	movq	0x108(%r8), %rdi
14009e727:     	movq	0x110(%r8), %r12
14009e72e:     	movl	0x118(%r8), %r9d
14009e735:     	movl	%r9d, 0x278(%rbp)
14009e73c:     	movl	0x11c(%r8), %r11d
14009e743:     	movzwl	0x120(%r8), %r10d
14009e74b:     	movzbl	0x123(%r8), %r9d
14009e753:     	movb	%r9b, 0x27d(%rbp)
14009e75a:     	movss	0x124(%r8), %xmm6
14009e763:     	movzwl	0x124(%r8), %r15d
14009e76b:     	movzwl	%r15w, %r14d
14009e76f:     	cmpq	$0x1, %rax
14009e773:     	ja	0x14009e7c4 <.text+0x9d7c4>
14009e775:     	cmpb	$0x1, 0x1e48(%rcx,%rax)
14009e77d:     	jne	0x14009e7c4 <.text+0x9d7c4>
14009e77f:     	cmpb	$0x0, 0x1e4a(%rcx,%rax)
14009e787:     	jne	0x14009e7c4 <.text+0x9d7c4>
14009e789:     	movb	$0x0, 0x1e48(%rcx,%rax)
14009e791:     	decq	0x1e40(%rcx)
14009e798:     	movq	$0x0, 0x1dc0(%rcx,%rax,8)
14009e7a4:     	leaq	(%rax,%rax,8), %r8
14009e7a8:     	leaq	(%r8,%r8,2), %r8
14009e7ac:     	addq	%rax, %r8
14009e7af:     	movb	$0x2, 0x95a(%rdx,%r8)
14009e7b8:     	leaq	(%rax,%rax,2), %rax
14009e7bc:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009e7c4:     	addl	$0x2, %r14d
14009e7c8:     	xorl	%r8d, %r8d
14009e7cb:     	movb	$0x1, %r9b
14009e7ce:     	cmpl	%r14d, 0x9e8(%rcx)
14009e7d5:     	jne	0x14009e84d <.text+0x9d84d>
14009e7d7:     	cmpw	$-0x1, 0x528(%rcx)
14009e7df:     	je	0x14009e84d <.text+0x9d84d>
14009e7e1:     	cmpw	%r15w, 0x64c(%rcx)
14009e7e9:     	sete	%al
14009e7ec:     	movl	0x278(%rbp), %edx
14009e7f2:     	cmpl	%edx, 0x640(%rcx)
14009e7f8:     	sete	%dl
14009e7fb:     	andb	%al, %dl
14009e7fd:     	cmpl	%r11d, 0x644(%rcx)
14009e804:     	sete	%al
14009e807:     	cmpw	%r10w, 0x648(%rcx)
14009e80f:     	sete	%r8b
14009e813:     	andb	%al, %r8b
14009e816:     	andb	%dl, %r8b
14009e819:     	cmpb	%r13b, 0x64a(%rcx)
14009e820:     	sete	%al
14009e823:     	movq	0x638(%rcx), %rdx
14009e82a:     	xorq	%r12, %rdx
14009e82d:     	movq	0x630(%rcx), %r9
14009e834:     	xorq	%rdi, %r9
14009e837:     	orq	%rdx, %r9
14009e83a:     	sete	%dl
14009e83d:     	andb	%al, %dl
14009e83f:     	andb	%r8b, %dl
14009e842:     	movzbl	%dl, %r8d
14009e846:     	movl	%r8d, %r9d
14009e849:     	xorb	$0x1, %r9b
14009e84d:     	xorl	%eax, %eax
14009e84f:     	cmpl	%r14d, 0x9ec(%rcx)
14009e856:     	movw	%r10w, 0x27e(%rbp)
14009e85e:     	movl	%r11d, 0x274(%rbp)
14009e865:     	jne	0x14009e90b <.text+0x9d90b>
14009e86b:     	cmpw	$-0x1, 0x658(%rcx)
14009e873:     	je	0x14009e90b <.text+0x9d90b>
14009e879:     	cmpw	%r15w, 0x77c(%rcx)
14009e881:     	setne	%al
14009e884:     	movl	0x278(%rbp), %edx
14009e88a:     	cmpl	%edx, 0x770(%rcx)
14009e890:     	setne	%dl
14009e893:     	orb	%al, %dl
14009e895:     	cmpl	%r11d, 0x774(%rcx)
14009e89c:     	setne	%al
14009e89f:     	cmpw	%r10w, 0x778(%rcx)
14009e8a7:     	setne	%r10b
14009e8ab:     	orb	%al, %r10b
14009e8ae:     	orb	%dl, %r10b
14009e8b1:     	cmpb	%r13b, 0x77a(%rcx)
14009e8b8:     	setne	%dl
14009e8bb:     	movq	0x768(%rcx), %rax
14009e8c2:     	xorq	%r12, %rax
14009e8c5:     	movq	0x760(%rcx), %r11
14009e8cc:     	xorq	%rdi, %r11
14009e8cf:     	orq	%rax, %r11
14009e8d2:     	setne	%al
14009e8d5:     	orb	%dl, %al
14009e8d7:     	orb	%r10b, %al
14009e8da:     	orb	%al, %r9b
14009e8dd:     	testb	%al, %al
14009e8df:     	movl	$0x1, %edx
14009e8e4:     	cmovneq	%r8, %rdx
14009e8e8:     	testb	$0x1, %r9b
14009e8ec:     	je	0x14009ea13 <.text+0x9da13>
14009e8f2:     	notb	%al
14009e8f4:     	movzbl	%al, %eax
14009e8f7:     	andl	$0x1, %eax
14009e8fa:     	movzwl	0x27e(%rbp), %r10d
14009e902:     	movl	0x274(%rbp), %r11d
14009e909:     	jmp	0x14009e90e <.text+0x9d90e>
14009e90b:     	movq	%r8, %rdx
14009e90e:     	cmpl	%r14d, 0x9f0(%rcx)
14009e915:     	jne	0x14009e995 <.text+0x9d995>
14009e917:     	cmpw	$-0x1, 0x788(%rcx)
14009e91f:     	je	0x14009e995 <.text+0x9d995>
14009e921:     	cmpw	%r15w, 0x8ac(%rcx)
14009e929:     	jne	0x14009e995 <.text+0x9d995>
14009e92b:     	movl	0x278(%rbp), %r8d
14009e932:     	cmpl	%r8d, 0x8a0(%rcx)
14009e939:     	jne	0x14009e995 <.text+0x9d995>
14009e93b:     	cmpl	%r11d, 0x8a4(%rcx)
14009e942:     	jne	0x14009e995 <.text+0x9d995>
14009e944:     	cmpw	%r10w, 0x8a8(%rcx)
14009e94c:     	jne	0x14009e995 <.text+0x9d995>
14009e94e:     	cmpb	%r13b, 0x8aa(%rcx)
14009e955:     	jne	0x14009e995 <.text+0x9d995>
14009e957:     	movq	0x890(%rcx), %r8
14009e95e:     	xorq	%rdi, %r8
14009e961:     	movq	0x898(%rcx), %r9
14009e968:     	xorq	%r12, %r9
14009e96b:     	orq	%r8, %r9
14009e96e:     	jne	0x14009e995 <.text+0x9d995>
14009e970:     	movb	$0x1, %r8b
14009e973:     	testq	%rdx, %rdx
14009e976:     	jne	0x14009ea18 <.text+0x9da18>
14009e97c:     	movl	$0x2, %eax
14009e981:     	movl	$0x1, %edx
14009e986:     	movzwl	0x27e(%rbp), %r10d
14009e98e:     	movl	0x274(%rbp), %r11d
14009e995:     	cmpl	%r14d, 0x9f4(%rcx)
14009e99c:     	jne	0x14009ea09 <.text+0x9da09>
14009e99e:     	cmpw	$-0x1, 0x8b8(%rcx)
14009e9a6:     	je	0x14009ea09 <.text+0x9da09>
14009e9a8:     	cmpw	%r15w, 0x9dc(%rcx)
14009e9b0:     	jne	0x14009ea09 <.text+0x9da09>
14009e9b2:     	movl	0x278(%rbp), %r8d
14009e9b9:     	cmpl	%r8d, 0x9d0(%rcx)
14009e9c0:     	jne	0x14009ea09 <.text+0x9da09>
14009e9c2:     	cmpl	%r11d, 0x9d4(%rcx)
14009e9c9:     	jne	0x14009ea09 <.text+0x9da09>
14009e9cb:     	cmpw	%r10w, 0x9d8(%rcx)
14009e9d3:     	jne	0x14009ea09 <.text+0x9da09>
14009e9d5:     	cmpb	%r13b, 0x9da(%rcx)
14009e9dc:     	jne	0x14009ea09 <.text+0x9da09>
14009e9de:     	movq	0x9c0(%rcx), %r8
14009e9e5:     	xorq	%rdi, %r8
14009e9e8:     	movq	0x9c8(%rcx), %r9
14009e9ef:     	xorq	%r12, %r9
14009e9f2:     	orq	%r8, %r9
14009e9f5:     	jne	0x14009ea09 <.text+0x9da09>
14009e9f7:     	testq	%rdx, %rdx
14009e9fa:     	movl	$0x3, %r8d
14009ea00:     	cmoveq	%r8, %rax
14009ea04:     	movl	%edx, %r8d
14009ea07:     	jmp	0x14009ea18 <.text+0x9da18>
14009ea09:     	xorl	%r8d, %r8d
14009ea0c:     	testq	%rdx, %rdx
14009ea0f:     	jne	0x14009ea18 <.text+0x9da18>
14009ea11:     	jmp	0x14009ea41 <.text+0x9da41>
14009ea13:     	movb	$0x1, %r8b
14009ea16:     	xorl	%eax, %eax
14009ea18:     	cmpl	$0x0, 0x9e8(%rcx,%rax,4)
14009ea20:     	je	0x14009ea41 <.text+0x9da41>
14009ea22:     	movl	$0x0, 0x9e8(%rcx,%rax,4)
14009ea2d:     	decq	0xa00(%rcx)
14009ea34:     	imulq	$0x130, %rax, %rax      # imm = 0x130
14009ea3b:     	movw	$0xffff, (%rsi,%rax)    # imm = 0xFFFF
14009ea41:     	movl	%r8d, 0x26c(%rbp)
14009ea48:     	movq	%r12, 0x260(%rbp)
14009ea4f:     	movq	%rcx, %r12
14009ea52:     	xorps	%xmm0, %xmm0
14009ea55:     	movaps	%xmm0, 0x250(%rbp)
14009ea5c:     	movb	$0x0, 0x132(%rbp)
14009ea63:     	movw	%r15w, 0x130(%rbp)
14009ea6b:     	leaq	0x133(%rbp), %rax
14009ea72:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009ea7b:     	movq	$0x0, 0x133(%rbp)
14009ea86:     	movq	$0x8, 0x110(%rbp)
14009ea91:     	movq	$0x0, 0x118(%rbp)
14009ea9c:     	movq	$0x1, 0x120(%rbp)
14009eaa7:     	movq	$0x0, 0x128(%rbp)
14009eab2:     	movq	%rax, 0x30(%rsp)
14009eab7:     	movw	%r15w, 0x28(%rsp)
14009eabd:     	movq	$0x0, 0x58(%rsp)
14009eac6:     	movq	$0x1, 0x50(%rsp)
14009eacf:     	movq	$0x8, 0x48(%rsp)
14009ead8:     	movq	$0x8, 0x40(%rsp)
14009eae1:     	movq	$0x0, 0x38(%rsp)
14009eaea:     	movb	$0x0, 0x20(%rsp)
14009eaef:     	leaq	0x240(%rbp), %rcx
14009eaf6:     	leaq	0x250(%rbp), %rdx
14009eafd:     	movl	$0x10, %r8d
14009eb03:     	movb	$0x2, %r9b
14009eb06:     	callq	0x140005590 <.text+0x4590>
14009eb0b:     	cmpb	$0x1, 0x240(%rbp)
14009eb12:     	je	0x14009ed22 <.text+0x9dd22>
14009eb18:     	movl	%r14d, 0x270(%rbp)
14009eb1f:     	movq	%rdi, %rax
14009eb22:     	movq	0x248(%rbp), %rdi
14009eb29:     	movq	%rax, %r14
14009eb2c:     	movq	%rax, 0xe8(%rbp)
14009eb33:     	movq	0x260(%rbp), %rax
14009eb3a:     	movq	%rax, 0xf0(%rbp)
14009eb41:     	movl	0x278(%rbp), %eax
14009eb47:     	movl	%eax, 0xf8(%rbp)
14009eb4d:     	movl	0x274(%rbp), %eax
14009eb53:     	movl	%eax, 0xfc(%rbp)
14009eb59:     	movzwl	0x27e(%rbp), %eax
14009eb60:     	movw	%ax, 0x100(%rbp)
14009eb67:     	movb	%r13b, 0x102(%rbp)
14009eb6e:     	movzbl	0x27d(%rbp), %eax
14009eb75:     	movb	%al, 0x103(%rbp)
14009eb7b:     	movss	%xmm6, 0x104(%rbp)
14009eb83:     	movq	%rbx, 0x108(%rbp)
14009eb8a:     	cmpq	$0x11, %rdi
14009eb8e:     	jae	0x14009ed8f <.text+0x9dd8f>
14009eb94:     	testq	%rdi, %rdi
14009eb97:     	je	0x14009ebd1 <.text+0x9dbd1>
14009eb99:     	movw	%di, -0x1e(%rbp)
14009eb9d:     	leaq	-0x1c(%rbp), %rbx
14009eba1:     	movl	$0x100, %r8d            # imm = 0x100
14009eba7:     	subq	%rdi, %r8
14009ebaa:     	leaq	(%rdi,%rbp), %rcx
14009ebae:     	addq	$-0x1c, %rcx
14009ebb2:     	xorl	%edx, %edx
14009ebb4:     	callq	0x140251dd2 <.text+0x250dd2>
14009ebb9:     	leaq	0x250(%rbp), %rdx
14009ebc0:     	movq	%rbx, %rcx
14009ebc3:     	movq	%rdi, %r8
14009ebc6:     	callq	0x140251dc0 <.text+0x250dc0>
14009ebcb:     	movw	$0x1, %ax
14009ebcf:     	jmp	0x14009ebd3 <.text+0x9dbd3>
14009ebd1:     	xorl	%eax, %eax
14009ebd3:     	movw	%ax, -0x20(%rbp)
14009ebd7:     	leaq	0x110(%rbp), %rcx
14009ebde:     	leaq	-0x20(%rbp), %rdx
14009ebe2:     	movl	$0x130, %r8d            # imm = 0x130
14009ebe8:     	callq	0x140251dc0 <.text+0x250dc0>
14009ebed:     	cmpw	$-0x1, 0x110(%rbp)
14009ebf5:     	movl	0x270(%rbp), %r9d
14009ebfc:     	je	0x14009ed22 <.text+0x9dd22>
14009ec02:     	cmpw	%r15w, 0x234(%rbp)
14009ec0a:     	jne	0x14009ed13 <.text+0x9dd13>
14009ec10:     	movl	0x278(%rbp), %ecx
14009ec16:     	cmpl	%ecx, 0x228(%rbp)
14009ec1c:     	jne	0x14009ed13 <.text+0x9dd13>
14009ec22:     	movl	0x274(%rbp), %ecx
14009ec28:     	cmpl	%ecx, 0x22c(%rbp)
14009ec2e:     	jne	0x14009ed13 <.text+0x9dd13>
14009ec34:     	movzwl	0x27e(%rbp), %ecx
14009ec3b:     	cmpw	%cx, 0x230(%rbp)
14009ec42:     	jne	0x14009ed13 <.text+0x9dd13>
14009ec48:     	cmpb	%r13b, 0x232(%rbp)
14009ec4f:     	jne	0x14009ed13 <.text+0x9dd13>
14009ec55:     	xorq	0x218(%rbp), %r14
14009ec5c:     	movq	0x260(%rbp), %rcx
14009ec63:     	xorq	0x220(%rbp), %rcx
14009ec6a:     	orq	%r14, %rcx
14009ec6d:     	jne	0x14009ed13 <.text+0x9dd13>
14009ec73:     	cmpb	$0x0, 0x26c(%rbp)
14009ec7a:     	jne	0x14009ed22 <.text+0x9dd22>
14009ec80:     	cmpq	$0x4, 0xa00(%r12)
14009ec89:     	je	0x14009ed22 <.text+0x9dd22>
14009ec8f:     	movq	0x9f8(%r12), %rcx
14009ec97:     	cmpq	$0x3, %rcx
14009ec9b:     	ja	0x14009eda8 <.text+0x9dda8>
14009eca1:     	cmpl	$0x0, 0x9e8(%r12,%rcx,4)
14009ecaa:     	je	0x14009ed36 <.text+0x9dd36>
14009ecb0:     	leaq	(,%rcx,4), %r8
14009ecb8:     	xorl	%edx, %edx
14009ecba:     	cmpl	$0x0, 0x9e8(%r12,%r8)
14009ecc3:     	je	0x14009ed29 <.text+0x9dd29>
14009ecc5:     	addq	$0x4, %r8
14009ecc9:     	decq	%rdx
14009eccc:     	cmpq	$0x10, %r8
14009ecd0:     	jne	0x14009ecba <.text+0x9dcba>
14009ecd2:     	testq	%rcx, %rcx
14009ecd5:     	je	0x14009ed22 <.text+0x9dd22>
14009ecd7:     	cmpl	$0x0, 0x9e8(%r12)
14009ece0:     	je	0x14009ed84 <.text+0x9dd84>
14009ece6:     	cmpq	$0x1, %rcx
14009ecea:     	je	0x14009ed22 <.text+0x9dd22>
14009ecec:     	cmpl	$0x0, 0x9ec(%r12)
14009ecf5:     	je	0x14009ed88 <.text+0x9dd88>
14009ecfb:     	cmpq	$0x2, %rcx
14009ecff:     	je	0x14009ed22 <.text+0x9dd22>
14009ed01:     	movl	$0x2, %ecx
14009ed06:     	cmpl	$0x0, 0x9f0(%r12)
14009ed0f:     	je	0x14009ed2c <.text+0x9dd2c>
14009ed11:     	jmp	0x14009ed22 <.text+0x9dd22>
14009ed13:     	leaq	0x110(%rbp), %rdx
14009ed1a:     	movq	%rsi, %rcx
14009ed1d:     	callq	0x140216ef0 <.text+0x215ef0>
14009ed22:     	movb	$0x1, %al
14009ed24:     	jmp	0x14009e701 <.text+0x9d701>
14009ed29:     	subq	%rdx, %rcx
14009ed2c:     	cmpq	$0x4, %rcx
14009ed30:     	jae	0x14009edbb <.text+0x9ddbb>
14009ed36:     	movl	$0x1, 0x9e8(%r12,%rcx,4)
14009ed42:     	incq	0xa00(%r12)
14009ed4a:     	leaq	0x1(%rcx), %rdx
14009ed4e:     	xorl	%r8d, %r8d
14009ed51:     	cmpq	$0x4, %rdx
14009ed55:     	cmovneq	%rdx, %r8
14009ed59:     	movq	%r8, 0x9f8(%r12)
14009ed61:     	movl	%r9d, 0x9e8(%r12,%rcx,4)
14009ed69:     	imulq	$0x130, %rcx, %rax      # imm = 0x130
14009ed70:     	addq	%rax, %rsi
14009ed73:     	leaq	0x110(%rbp), %rcx
14009ed7a:     	movq	%rsi, %rdx
14009ed7d:     	callq	0x14000b1c0 <.text+0xa1c0>
14009ed82:     	jmp	0x14009ed22 <.text+0x9dd22>
14009ed84:     	xorl	%ecx, %ecx
14009ed86:     	jmp	0x14009ed2c <.text+0x9dd2c>
14009ed88:     	movl	$0x1, %ecx
14009ed8d:     	jmp	0x14009ed2c <.text+0x9dd2c>
14009ed8f:     	leaq	0x1c272a(%rip), %r9     # 0x1402614c0
14009ed96:     	movl	$0x10, %r8d
14009ed9c:     	xorl	%ecx, %ecx
14009ed9e:     	movq	%rdi, %rdx
14009eda1:     	callq	0x140252850 <.text+0x251850>
14009eda6:     	ud2
14009eda8:     	leaq	0x1cf051(%rip), %r8     # 0x14026de00
14009edaf:     	movl	$0x4, %edx
14009edb4:     	callq	0x140252643 <.text+0x251643>
14009edb9:     	ud2
14009edbb:     	leaq	0x1cf056(%rip), %r8     # 0x14026de18
14009edc2:     	movl	$0x4, %edx
14009edc7:     	callq	0x140252643 <.text+0x251643>
14009edcc:     	ud2

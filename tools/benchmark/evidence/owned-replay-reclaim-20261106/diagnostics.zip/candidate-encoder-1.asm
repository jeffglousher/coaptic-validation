
D:\CoapticCurrent\owned-replay-reclaim-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068580:     	pushq	%rbp
140068581:     	pushq	%r15
140068583:     	pushq	%r14
140068585:     	pushq	%r13
140068587:     	pushq	%r12
140068589:     	pushq	%rsi
14006858a:     	pushq	%rdi
14006858b:     	pushq	%rbx
14006858c:     	subq	$0x508, %rsp            # imm = 0x508
140068593:     	leaq	0x80(%rsp), %rbp
14006859b:     	movq	0x500(%rbp), %r12
1400685a2:     	movq	0x8(%r12), %rdi
1400685a7:     	movl	$0x3, %r10d
1400685ad:     	cmpq	$0x3, %rdi
1400685b1:     	ja	0x140068691 <.text+0x67691>
1400685b7:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
1400685bf:     	jne	0x140068691 <.text+0x67691>
1400685c5:     	movq	0x26700(%rdx,%rdi,8), %rax
1400685cd:     	cmpq	$0x4001, %rax           # imm = 0x4001
1400685d3:     	jae	0x14006886e <.text+0x6786e>
1400685d9:     	movq	0x10(%r12), %r11
1400685de:     	movq	0x18(%r12), %r15
1400685e3:     	movq	%r15, %rsi
1400685e6:     	movl	$0xb, %r10d
1400685ec:     	addq	%r11, %rsi
1400685ef:     	jb	0x140068691 <.text+0x67691>
1400685f5:     	cmpq	$0x400, %r15            # imm = 0x400
1400685fc:     	ja	0x140068691 <.text+0x67691>
140068602:     	cmpq	%rax, %rsi
140068605:     	ja	0x140068691 <.text+0x67691>
14006860b:     	movq	%r8, %r13
14006860e:     	movq	%r9, 0x470(%rbp)
140068615:     	movq	%rcx, 0x480(%rbp)
14006861c:     	movzbl	0x508(%rbp), %r14d
140068624:     	movq	%rdi, %rax
140068627:     	shlq	$0xe, %rax
14006862b:     	movq	%rdx, %rsi
14006862e:     	leaq	(%rdx,%rax), %rbx
140068632:     	addq	$0x16700, %rbx          # imm = 0x16700
140068639:     	addq	%r11, %rbx
14006863c:     	movl	$0x400, %r8d            # imm = 0x400
140068642:     	cmpq	$0x400, %r15            # imm = 0x400
140068649:     	je	0x140068658 <.text+0x67658>
14006864b:     	movq	%rbp, %rcx
14006864e:     	xorl	%edx, %edx
140068650:     	callq	0x140251dd2 <.text+0x250dd2>
140068655:     	movq	%r15, %r8
140068658:     	movq	%rbp, %rcx
14006865b:     	movq	%rbx, %rdx
14006865e:     	callq	0x140251dc0 <.text+0x250dc0>
140068663:     	testb	%r14b, %r14b
140068666:     	je	0x1400686ac <.text+0x676ac>
140068668:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
14006866f:     	movq	%rsi, %rcx
140068672:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
14006867b:     	jne	0x140068823 <.text+0x67823>
140068681:     	xorl	%edi, %edi
140068683:     	callq	0x14009b240 <.text+0x9a240>
140068688:     	testb	$0x1, %al
14006868a:     	jne	0x1400686be <.text+0x676be>
14006868c:     	jmp	0x14006884c <.text+0x6784c>
140068691:     	movb	$0xa, (%rcx)
140068694:     	movq	%r10, 0x8(%rcx)
140068698:     	addq	$0x508, %rsp            # imm = 0x508
14006869f:     	popq	%rbx
1400686a0:     	popq	%rdi
1400686a1:     	popq	%rsi
1400686a2:     	popq	%r12
1400686a4:     	popq	%r13
1400686a6:     	popq	%r14
1400686a8:     	popq	%r15
1400686aa:     	popq	%rbp
1400686ab:     	retq
1400686ac:     	xorl	%edi, %edi
1400686ae:     	movq	%rsi, %rcx
1400686b1:     	callq	0x14009b240 <.text+0x9a240>
1400686b6:     	testb	$0x1, %al
1400686b8:     	je	0x14006884c <.text+0x6784c>
1400686be:     	movq	%rdx, %rbx
1400686c1:     	movq	0x518(%rbp), %rdx
1400686c8:     	movq	0x510(%rbp), %r8
1400686cf:     	movzwl	0x4f8(%rbp), %ecx
1400686d6:     	movzbl	0x4f0(%rbp), %eax
1400686dd:     	movq	(%r12), %r9
1400686e1:     	movq	%rdi, 0x440(%rbp)
1400686e8:     	movq	0x478(%rbp), %r10
1400686ef:     	movq	%r10, 0x448(%rbp)
1400686f6:     	movq	%r9, 0x450(%rbp)
1400686fd:     	movb	%r14b, 0x458(%rbp)
140068704:     	movups	0x60(%r13), %xmm0
140068709:     	movups	0x6c(%r13), %xmm1
14006870e:     	movups	%xmm1, 0x40c(%rbp)
140068715:     	movaps	%xmm0, 0x400(%rbp)
14006871c:     	leaq	0x8e(%r13), %r9
140068723:     	movq	0x7e(%r13), %r10
140068727:     	movq	0x85(%r13), %r11
14006872e:     	movq	%r11, 0x467(%rbp)
140068735:     	movq	%r10, 0x460(%rbp)
14006873c:     	leaq	0x460(%rbp), %r10
140068743:     	movq	%r10, 0x70(%rsp)
140068748:     	movq	%rdx, 0x68(%rsp)
14006874d:     	movq	%r8, 0x60(%rsp)
140068752:     	movq	%r13, 0x58(%rsp)
140068757:     	leaq	0x440(%rbp), %rdx
14006875e:     	movq	%rdx, 0x50(%rsp)
140068763:     	movq	%r15, 0x48(%rsp)
140068768:     	movq	%rbp, %rdx
14006876b:     	movq	%rdx, 0x40(%rsp)
140068770:     	movq	0x470(%rbp), %rdx
140068777:     	movq	%rdx, 0x38(%rsp)
14006877c:     	movq	%r9, 0x30(%rsp)
140068781:     	movw	%cx, 0x28(%rsp)
140068786:     	movb	%al, 0x20(%rsp)
14006878a:     	leaq	0x420(%rbp), %rcx
140068791:     	leaq	0x400(%rbp), %r8
140068798:     	movq	%rsi, %rdx
14006879b:     	movq	%rbx, %r9
14006879e:     	callq	0x140081520 <.text+0x80520>
1400687a3:     	cmpb	$-0x1, 0x420(%rbp)
1400687aa:     	je	0x14006885b <.text+0x6785b>
1400687b0:     	cmpb	$0x1, 0x37400(%rsi,%rbx)
1400687b8:     	movq	0x480(%rbp), %rax
1400687bf:     	jne	0x140068809 <.text+0x67809>
1400687c1:     	cmpb	$0x0, 0x37420(%rsi,%rbx)
1400687c9:     	jne	0x140068809 <.text+0x67809>
1400687cb:     	movb	$0x0, 0x37400(%rsi,%rbx)
1400687d3:     	decq	0x37448(%rsi)
1400687da:     	leaq	0x37400(%rsi), %rcx
1400687e1:     	movq	$0x0, 0x432d0(%rsi,%rbx,8)
1400687ed:     	leaq	(%rbx,%rbx,8), %rdx
1400687f1:     	leaq	(%rdx,%rdx,2), %rdx
1400687f5:     	addq	%rbx, %rdx
1400687f8:     	movb	$0x2, 0x36a(%rcx,%rdx)
140068800:     	leaq	(%rbx,%rbx,2), %rdx
140068804:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140068809:     	movups	0x420(%rbp), %xmm0
140068810:     	movups	0x430(%rbp), %xmm1
140068817:     	movups	%xmm1, 0x10(%rax)
14006881b:     	movups	%xmm0, (%rax)
14006881e:     	jmp	0x140068698 <.text+0x67698>
140068823:     	addq	%rcx, %rax
140068826:     	addq	$0x15c28, %rax          # imm = 0x15C28
14006882c:     	movq	0x98(%rax), %rax
140068833:     	movq	%rax, 0x478(%rbp)
14006883a:     	movl	$0x1, %edi
14006883f:     	callq	0x14009b240 <.text+0x9a240>
140068844:     	testb	$0x1, %al
140068846:     	jne	0x1400686be <.text+0x676be>
14006884c:     	movq	0x480(%rbp), %rax
140068853:     	movb	$0x9, (%rax)
140068856:     	jmp	0x140068698 <.text+0x67698>
14006885b:     	movq	0x480(%rbp), %rax
140068862:     	movq	%rbx, 0x8(%rax)
140068866:     	movb	$-0x1, (%rax)
140068869:     	jmp	0x140068698 <.text+0x67698>
14006886e:     	leaq	0x20543b(%rip), %r9     # 0x14026dcb0
140068875:     	movl	$0x4000, %r8d           # imm = 0x4000
14006887b:     	xorl	%ecx, %ecx
14006887d:     	movq	%rax, %rdx
140068880:     	callq	0x140252850 <.text+0x251850>
140068885:     	ud2

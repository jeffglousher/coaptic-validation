
D:\CoapticCurrent\owned-replay-reclaim-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009f590:     	pushq	%rbp
14009f591:     	pushq	%r15
14009f593:     	pushq	%r14
14009f595:     	pushq	%r13
14009f597:     	pushq	%r12
14009f599:     	pushq	%rsi
14009f59a:     	pushq	%rdi
14009f59b:     	pushq	%rbx
14009f59c:     	subq	$0x328, %rsp            # imm = 0x328
14009f5a3:     	leaq	0x80(%rsp), %rbp
14009f5ab:     	movaps	%xmm6, 0x290(%rbp)
14009f5b2:     	leaq	0x37400(%rcx), %rdx
14009f5b9:     	leaq	0x26720(%rcx), %rsi
14009f5c0:     	leaq	0x2b320(%rcx), %r14
14009f5c7:     	leaq	0x26848(%rcx), %rax
14009f5ce:     	xorl	%r10d, %r10d
14009f5d1:     	movl	$0x1, %r11d
14009f5d7:     	xorl	%r9d, %r9d
14009f5da:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009f5e1:     	addq	%rax, %rdi
14009f5e4:     	jmp	0x14009f600 <.text+0x9e600>
14009f5e6:     	nopw	%cs:(%rax,%rax)
14009f5f0:     	incq	%r10
14009f5f3:     	addq	$0x130, %rdi            # imm = 0x130
14009f5fa:     	cmpq	$0x40, %r10
14009f5fe:     	je	0x14009f656 <.text+0x9e656>
14009f600:     	cmpl	$0x0, 0x4c00(%rsi,%r10,4)
14009f609:     	je	0x14009f5f0 <.text+0x9e5f0>
14009f60b:     	movzwl	-0x128(%rdi), %r15d
14009f613:     	cmpw	$-0x1, %r15w
14009f618:     	je	0x14009f5f0 <.text+0x9e5f0>
14009f61a:     	movq	(%rdi), %rdi
14009f61d:     	cmpw	$0x2, %r15w
14009f622:     	setne	%r15b
14009f626:     	testq	%rdi, %rdi
14009f629:     	sete	%r12b
14009f62d:     	orb	%r15b, %r12b
14009f630:     	cmpq	%rbx, %rdi
14009f633:     	setae	%r15b
14009f637:     	andb	%r9b, %r15b
14009f63a:     	testb	%r12b, %r12b
14009f63d:     	cmoveq	%r11, %r9
14009f641:     	orb	%r12b, %r15b
14009f644:     	cmoveq	%r10, %r8
14009f648:     	cmoveq	%rdi, %rbx
14009f64c:     	cmpq	$0x3f, %r10
14009f650:     	leaq	0x1(%r10), %r10
14009f654:     	jb	0x14009f5da <.text+0x9e5da>
14009f656:     	xorl	%eax, %eax
14009f658:     	cmpq	$0x1, %r9
14009f65c:     	jne	0x14009f68d <.text+0x9e68d>
14009f65e:     	cmpq	$0x40, %r8
14009f662:     	jae	0x14009f68d <.text+0x9e68d>
14009f664:     	cmpl	$0x0, (%r14,%r8,4)
14009f669:     	je	0x14009f68b <.text+0x9e68b>
14009f66b:     	imulq	$0x130, %r8, %r8        # imm = 0x130
14009f672:     	cmpw	$0x2, (%rsi,%r8)
14009f678:     	jne	0x14009f68b <.text+0x9e68b>
14009f67a:     	addq	%rsi, %r8
14009f67d:     	movzbl	0x122(%r8), %r12d
14009f685:     	cmpb	$0x2, %r12b
14009f689:     	jne	0x14009f6a8 <.text+0x9e6a8>
14009f68b:     	xorl	%eax, %eax
14009f68d:     	movaps	0x290(%rbp), %xmm6
14009f694:     	addq	$0x328, %rsp            # imm = 0x328
14009f69b:     	popq	%rbx
14009f69c:     	popq	%rdi
14009f69d:     	popq	%rsi
14009f69e:     	popq	%r12
14009f6a0:     	popq	%r13
14009f6a2:     	popq	%r14
14009f6a4:     	popq	%r15
14009f6a6:     	popq	%rbp
14009f6a7:     	retq
14009f6a8:     	movq	0x8(%r8), %rax
14009f6ac:     	movq	0x108(%r8), %rdi
14009f6b3:     	movq	0x110(%r8), %r9
14009f6ba:     	movq	%r9, 0x278(%rbp)
14009f6c1:     	movl	0x118(%r8), %r9d
14009f6c8:     	movl	%r9d, 0x284(%rbp)
14009f6cf:     	movl	0x11c(%r8), %r9d
14009f6d6:     	movl	%r9d, 0x288(%rbp)
14009f6dd:     	movzwl	0x120(%r8), %r9d
14009f6e5:     	movw	%r9w, 0x28e(%rbp)
14009f6ed:     	movzbl	0x123(%r8), %r9d
14009f6f5:     	movb	%r9b, 0x28d(%rbp)
14009f6fc:     	movss	0x124(%r8), %xmm6
14009f705:     	movzwl	0x124(%r8), %r13d
14009f70d:     	movzwl	%r13w, %r15d
14009f711:     	cmpq	$0x1f, %rax
14009f715:     	ja	0x14009f75f <.text+0x9e75f>
14009f717:     	cmpb	$0x1, (%rdx,%rax)
14009f71b:     	jne	0x14009f75f <.text+0x9e75f>
14009f71d:     	cmpb	$0x0, 0x37420(%rcx,%rax)
14009f725:     	jne	0x14009f75f <.text+0x9e75f>
14009f727:     	movb	$0x0, 0x37400(%rcx,%rax)
14009f72f:     	decq	0x37448(%rcx)
14009f736:     	movq	$0x0, 0x432d0(%rcx,%rax,8)
14009f742:     	leaq	(%rax,%rax,8), %r8
14009f746:     	leaq	(%r8,%r8,2), %r8
14009f74a:     	addq	%rax, %r8
14009f74d:     	movb	$0x2, 0x36a(%rdx,%r8)
14009f756:     	leaq	(%rax,%rax,2), %rax
14009f75a:     	movb	$0x2, 0x5d(%rdx,%rax,8)
14009f75f:     	addl	$0x2, %r15d
14009f763:     	leaq	0x26844(%rcx), %rax
14009f76a:     	xorl	%r8d, %r8d
14009f76d:     	xorl	%edx, %edx
14009f76f:     	jmp	0x14009f796 <.text+0x9e796>
14009f771:     	nopw	%cs:(%rax,%rax)
14009f780:     	movq	%r9, %r10
14009f783:     	incq	%r8
14009f786:     	addq	$0x130, %rax            # imm = 0x130
14009f78c:     	cmpq	$0x40, %r8
14009f790:     	je	0x14009f816 <.text+0x9e816>
14009f796:     	movq	%r10, %r9
14009f799:     	cmpl	%r15d, (%r14,%r8,4)
14009f79d:     	jne	0x14009f780 <.text+0x9e780>
14009f79f:     	cmpw	$-0x1, -0x124(%rax)
14009f7a7:     	je	0x14009f780 <.text+0x9e780>
14009f7a9:     	cmpw	%r13w, (%rax)
14009f7ad:     	jne	0x14009f780 <.text+0x9e780>
14009f7af:     	movl	0x284(%rbp), %r10d
14009f7b6:     	cmpl	%r10d, -0xc(%rax)
14009f7ba:     	jne	0x14009f780 <.text+0x9e780>
14009f7bc:     	movl	0x288(%rbp), %r10d
14009f7c3:     	cmpl	%r10d, -0x8(%rax)
14009f7c7:     	jne	0x14009f780 <.text+0x9e780>
14009f7c9:     	movzwl	0x28e(%rbp), %r10d
14009f7d1:     	cmpw	%r10w, -0x4(%rax)
14009f7d6:     	jne	0x14009f780 <.text+0x9e780>
14009f7d8:     	cmpb	%r12b, -0x2(%rax)
14009f7dc:     	jne	0x14009f780 <.text+0x9e780>
14009f7de:     	movq	-0x1c(%rax), %r10
14009f7e2:     	xorq	%rdi, %r10
14009f7e5:     	movq	-0x14(%rax), %r11
14009f7e9:     	xorq	0x278(%rbp), %r11
14009f7f0:     	orq	%r10, %r11
14009f7f3:     	jne	0x14009f780 <.text+0x9e780>
14009f7f5:     	movq	%r8, %r10
14009f7f8:     	cmpq	$0x1, %rdx
14009f7fc:     	movl	$0x1, %edx
14009f801:     	jne	0x14009f783 <.text+0x9e783>
14009f803:     	movb	$0x1, %al
14009f805:     	movl	%eax, 0x280(%rbp)
14009f80b:     	movq	%r9, %r10
14009f80e:     	cmpq	$0x3f, %r9
14009f812:     	jbe	0x14009f82b <.text+0x9e82b>
14009f814:     	jmp	0x14009f852 <.text+0x9e852>
14009f816:     	cmpq	$0x40, %r10
14009f81a:     	setb	%al
14009f81d:     	movl	$0x0, 0x280(%rbp)
14009f827:     	testb	%al, %dl
14009f829:     	je	0x14009f852 <.text+0x9e852>
14009f82b:     	cmpl	$0x0, (%r14,%r10,4)
14009f830:     	je	0x14009f852 <.text+0x9e852>
14009f832:     	movl	$0x0, 0x2b320(%rcx,%r10,4)
14009f83e:     	decq	0x2b428(%rcx)
14009f845:     	imulq	$0x130, %r10, %rax      # imm = 0x130
14009f84c:     	movw	$0xffff, (%rsi,%rax)    # imm = 0xFFFF
14009f852:     	movq	%rcx, 0x268(%rbp)
14009f859:     	pxor	%xmm0, %xmm0
14009f85d:     	movdqa	%xmm0, 0x250(%rbp)
14009f865:     	movb	$0x0, 0x132(%rbp)
14009f86c:     	movw	%r13w, 0x130(%rbp)
14009f874:     	leaq	0x133(%rbp), %rax
14009f87b:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009f884:     	movq	$0x0, 0x133(%rbp)
14009f88f:     	movq	$0x8, 0x110(%rbp)
14009f89a:     	movq	$0x0, 0x118(%rbp)
14009f8a5:     	movq	$0x1, 0x120(%rbp)
14009f8b0:     	movq	$0x0, 0x128(%rbp)
14009f8bb:     	movq	%rax, 0x30(%rsp)
14009f8c0:     	movw	%r13w, 0x28(%rsp)
14009f8c6:     	movq	$0x0, 0x58(%rsp)
14009f8cf:     	movq	$0x1, 0x50(%rsp)
14009f8d8:     	movq	$0x8, 0x48(%rsp)
14009f8e1:     	movq	$0x8, 0x40(%rsp)
14009f8ea:     	movq	$0x0, 0x38(%rsp)
14009f8f3:     	movb	$0x0, 0x20(%rsp)
14009f8f8:     	leaq	0x240(%rbp), %rcx
14009f8ff:     	leaq	0x250(%rbp), %rdx
14009f906:     	movl	$0x10, %r8d
14009f90c:     	movb	$0x2, %r9b
14009f90f:     	callq	0x140005590 <.text+0x4590>
14009f914:     	cmpb	$0x1, 0x240(%rbp)
14009f91b:     	je	0x14009fb13 <.text+0x9eb13>
14009f921:     	movq	%rdi, %rax
14009f924:     	movq	0x248(%rbp), %rdi
14009f92b:     	movq	%rax, 0x270(%rbp)
14009f932:     	movq	%rax, 0xe8(%rbp)
14009f939:     	movq	0x278(%rbp), %rax
14009f940:     	movq	%rax, 0xf0(%rbp)
14009f947:     	movl	0x284(%rbp), %eax
14009f94d:     	movl	%eax, 0xf8(%rbp)
14009f953:     	movl	0x288(%rbp), %eax
14009f959:     	movl	%eax, 0xfc(%rbp)
14009f95f:     	movzwl	0x28e(%rbp), %eax
14009f966:     	movw	%ax, 0x100(%rbp)
14009f96d:     	movb	%r12b, 0x102(%rbp)
14009f974:     	movzbl	0x28d(%rbp), %eax
14009f97b:     	movb	%al, 0x103(%rbp)
14009f981:     	movss	%xmm6, 0x104(%rbp)
14009f989:     	movq	%rbx, 0x108(%rbp)
14009f990:     	cmpq	$0x11, %rdi
14009f994:     	jae	0x14009fc2b <.text+0x9ec2b>
14009f99a:     	testq	%rdi, %rdi
14009f99d:     	je	0x14009f9d7 <.text+0x9e9d7>
14009f99f:     	movw	%di, -0x1e(%rbp)
14009f9a3:     	leaq	-0x1c(%rbp), %rbx
14009f9a7:     	movl	$0x100, %r8d            # imm = 0x100
14009f9ad:     	subq	%rdi, %r8
14009f9b0:     	leaq	(%rdi,%rbp), %rcx
14009f9b4:     	addq	$-0x1c, %rcx
14009f9b8:     	xorl	%edx, %edx
14009f9ba:     	callq	0x140251dd2 <.text+0x250dd2>
14009f9bf:     	leaq	0x250(%rbp), %rdx
14009f9c6:     	movq	%rbx, %rcx
14009f9c9:     	movq	%rdi, %r8
14009f9cc:     	callq	0x140251dc0 <.text+0x250dc0>
14009f9d1:     	movw	$0x1, %ax
14009f9d5:     	jmp	0x14009f9d9 <.text+0x9e9d9>
14009f9d7:     	xorl	%eax, %eax
14009f9d9:     	movq	0x270(%rbp), %rdi
14009f9e0:     	movw	%ax, -0x20(%rbp)
14009f9e4:     	leaq	0x110(%rbp), %rcx
14009f9eb:     	leaq	-0x20(%rbp), %rdx
14009f9ef:     	movl	$0x130, %r8d            # imm = 0x130
14009f9f5:     	callq	0x140251dc0 <.text+0x250dc0>
14009f9fa:     	cmpw	$-0x1, 0x110(%rbp)
14009fa02:     	movq	0x268(%rbp), %rax
14009fa09:     	je	0x14009fb13 <.text+0x9eb13>
14009fa0f:     	cmpw	%r13w, 0x234(%rbp)
14009fa17:     	jne	0x14009fb04 <.text+0x9eb04>
14009fa1d:     	movl	0x284(%rbp), %ecx
14009fa23:     	cmpl	%ecx, 0x228(%rbp)
14009fa29:     	jne	0x14009fb04 <.text+0x9eb04>
14009fa2f:     	movl	0x288(%rbp), %ecx
14009fa35:     	cmpl	%ecx, 0x22c(%rbp)
14009fa3b:     	jne	0x14009fb04 <.text+0x9eb04>
14009fa41:     	movzwl	0x28e(%rbp), %ecx
14009fa48:     	cmpw	%cx, 0x230(%rbp)
14009fa4f:     	jne	0x14009fb04 <.text+0x9eb04>
14009fa55:     	cmpb	%r12b, 0x232(%rbp)
14009fa5c:     	jne	0x14009fb04 <.text+0x9eb04>
14009fa62:     	xorq	0x218(%rbp), %rdi
14009fa69:     	movq	0x278(%rbp), %rcx
14009fa70:     	xorq	0x220(%rbp), %rcx
14009fa77:     	orq	%rdi, %rcx
14009fa7a:     	jne	0x14009fb04 <.text+0x9eb04>
14009fa80:     	cmpb	$0x0, 0x280(%rbp)
14009fa87:     	jne	0x14009fb13 <.text+0x9eb13>
14009fa8d:     	cmpq	$0x40, 0x2b428(%rax)
14009fa95:     	je	0x14009fb13 <.text+0x9eb13>
14009fa97:     	movq	0x2b420(%rax), %rcx
14009fa9e:     	cmpq	$0x3f, %rcx
14009faa2:     	ja	0x14009fc44 <.text+0x9ec44>
14009faa8:     	cmpl	$0x0, (%r14,%rcx,4)
14009faad:     	je	0x14009fb27 <.text+0x9eb27>
14009faaf:     	leaq	(,%rcx,4), %r8
14009fab7:     	leaq	(%r14,%rcx,4), %rdx
14009fabb:     	xorl	%r9d, %r9d
14009fabe:     	movq	%r8, %r10
14009fac1:     	cmpl	$0x0, (%r14,%r10)
14009fac6:     	je	0x14009fb1a <.text+0x9eb1a>
14009fac8:     	addq	$0x4, %r10
14009facc:     	decq	%r9
14009facf:     	cmpq	$0x100, %r10            # imm = 0x100
14009fad6:     	jne	0x14009fac1 <.text+0x9eac1>
14009fad8:     	testq	%rcx, %rcx
14009fadb:     	je	0x14009fb13 <.text+0x9eb13>
14009fadd:     	addq	$-0x4, %r8
14009fae1:     	cmpq	$0xc, %r8
14009fae5:     	jae	0x14009fb72 <.text+0x9eb72>
14009faeb:     	xorl	%ecx, %ecx
14009faed:     	movq	%r14, %r10
14009faf0:     	cmpl	$0x0, (%r10)
14009faf4:     	je	0x14009fb1d <.text+0x9eb1d>
14009faf6:     	addq	$0x4, %r10
14009fafa:     	incq	%rcx
14009fafd:     	cmpq	%rdx, %r10
14009fb00:     	jne	0x14009faf0 <.text+0x9eaf0>
14009fb02:     	jmp	0x14009fb13 <.text+0x9eb13>
14009fb04:     	leaq	0x110(%rbp), %rdx
14009fb0b:     	movq	%rsi, %rcx
14009fb0e:     	callq	0x140216be0 <.text+0x215be0>
14009fb13:     	movb	$0x1, %al
14009fb15:     	jmp	0x14009f68d <.text+0x9e68d>
14009fb1a:     	subq	%r9, %rcx
14009fb1d:     	cmpq	$0x40, %rcx
14009fb21:     	jae	0x14009fc18 <.text+0x9ec18>
14009fb27:     	movl	$0x1, 0x2b320(%rax,%rcx,4)
14009fb32:     	incq	0x2b428(%rax)
14009fb39:     	leaq	0x1(%rcx), %rdx
14009fb3d:     	xorl	%r8d, %r8d
14009fb40:     	cmpq	$0x40, %rdx
14009fb44:     	cmovneq	%rdx, %r8
14009fb48:     	movq	%r8, 0x2b420(%rax)
14009fb4f:     	movl	%r15d, 0x2b320(%rax,%rcx,4)
14009fb57:     	imulq	$0x130, %rcx, %rax      # imm = 0x130
14009fb5e:     	addq	%rax, %rsi
14009fb61:     	leaq	0x110(%rbp), %rcx
14009fb68:     	movq	%rsi, %rdx
14009fb6b:     	callq	0x14000b1c0 <.text+0xa1c0>
14009fb70:     	jmp	0x14009fb13 <.text+0x9eb13>
14009fb72:     	shrq	$0x2, %r8
14009fb76:     	incq	%r8
14009fb79:     	movq	%r8, %rcx
14009fb7c:     	andq	$-0x4, %rcx
14009fb80:     	leaq	(%r14,%rcx,4), %r10
14009fb84:     	xorl	%r9d, %r9d
14009fb87:     	pxor	%xmm1, %xmm1
14009fb8b:     	movdqu	(%r14,%r9,4), %xmm0
14009fb91:     	movdqa	%xmm0, %xmm2
14009fb95:     	pcmpeqd	%xmm1, %xmm2
14009fb99:     	movmskps	%xmm2, %r11d
14009fb9d:     	testl	%r11d, %r11d
14009fba0:     	jne	0x14009fbb9 <.text+0x9ebb9>
14009fba2:     	addq	$0x4, %r9
14009fba6:     	cmpq	%r9, %rcx
14009fba9:     	jne	0x14009fb8b <.text+0x9eb8b>
14009fbab:     	cmpq	%rcx, %r8
14009fbae:     	jne	0x14009faf0 <.text+0x9eaf0>
14009fbb4:     	jmp	0x14009fb13 <.text+0x9eb13>
14009fbb9:     	pxor	%xmm1, %xmm1
14009fbbd:     	pcmpeqd	%xmm1, %xmm0
14009fbc1:     	pand	0x1c5227(%rip), %xmm0   # 0x140264df0
14009fbc9:     	movdqa	0x1c311f(%rip), %xmm1   # 0x140262cf0
14009fbd1:     	movdqa	%xmm0, %xmm2
14009fbd5:     	por	%xmm1, %xmm2
14009fbd9:     	pshufd	$0xee, %xmm0, %xmm3     # xmm3 = xmm0[2,3,2,3]
14009fbde:     	por	%xmm3, %xmm1
14009fbe2:     	pcmpgtd	%xmm1, %xmm2
14009fbe6:     	pand	%xmm2, %xmm0
14009fbea:     	pandn	%xmm3, %xmm2
14009fbee:     	por	%xmm0, %xmm2
14009fbf2:     	movd	%xmm2, %ecx
14009fbf6:     	pshufd	$0x55, %xmm2, %xmm0     # xmm0 = xmm2[1,1,1,1]
14009fbfb:     	movd	%xmm0, %edx
14009fbff:     	cmpl	%edx, %ecx
14009fc01:     	cmoval	%ecx, %edx
14009fc04:     	movl	$0x4, %ecx
14009fc09:     	subl	%edx, %ecx
14009fc0b:     	addq	%r9, %rcx
14009fc0e:     	cmpq	$0x40, %rcx
14009fc12:     	jb	0x14009fb27 <.text+0x9eb27>
14009fc18:     	leaq	0x1ce1f9(%rip), %r8     # 0x14026de18
14009fc1f:     	movl	$0x40, %edx
14009fc24:     	callq	0x140252643 <.text+0x251643>
14009fc29:     	ud2
14009fc2b:     	leaq	0x1c188e(%rip), %r9     # 0x1402614c0
14009fc32:     	movl	$0x10, %r8d
14009fc38:     	xorl	%ecx, %ecx
14009fc3a:     	movq	%rdi, %rdx
14009fc3d:     	callq	0x140252850 <.text+0x251850>
14009fc42:     	ud2
14009fc44:     	leaq	0x1ce1b5(%rip), %r8     # 0x14026de00
14009fc4b:     	movl	$0x40, %edx
14009fc50:     	callq	0x140252643 <.text+0x251643>
14009fc55:     	ud2

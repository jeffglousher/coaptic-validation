
D:\CoapticCurrent\owned-replay-reclaim-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068890:     	pushq	%rbp
140068891:     	pushq	%r15
140068893:     	pushq	%r14
140068895:     	pushq	%r13
140068897:     	pushq	%r12
140068899:     	pushq	%rsi
14006889a:     	pushq	%rdi
14006889b:     	pushq	%rbx
14006889c:     	subq	$0x4f8, %rsp            # imm = 0x4F8
1400688a3:     	leaq	0x80(%rsp), %rbp
1400688ab:     	movq	0x4f0(%rbp), %r12
1400688b2:     	movq	0x8(%r12), %rdi
1400688b7:     	movl	$0x3, %r10d
1400688bd:     	cmpq	$0x3, %rdi
1400688c1:     	ja	0x1400689a3 <.text+0x679a3>
1400688c7:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
1400688cf:     	jne	0x1400689a3 <.text+0x679a3>
1400688d5:     	movq	0x26700(%rdx,%rdi,8), %rax
1400688dd:     	cmpq	$0x4001, %rax           # imm = 0x4001
1400688e3:     	jae	0x140068b75 <.text+0x67b75>
1400688e9:     	movq	0x10(%r12), %r11
1400688ee:     	movq	0x18(%r12), %r15
1400688f3:     	movq	%r15, %rsi
1400688f6:     	movl	$0xb, %r10d
1400688fc:     	addq	%r11, %rsi
1400688ff:     	jb	0x1400689a3 <.text+0x679a3>
140068905:     	cmpq	$0x400, %r15            # imm = 0x400
14006890c:     	ja	0x1400689a3 <.text+0x679a3>
140068912:     	cmpq	%rax, %rsi
140068915:     	ja	0x1400689a3 <.text+0x679a3>
14006891b:     	movq	%r8, %r13
14006891e:     	movq	%r9, 0x460(%rbp)
140068925:     	movq	%rcx, 0x470(%rbp)
14006892c:     	movzbl	0x4f8(%rbp), %r14d
140068934:     	movq	%rdi, %rax
140068937:     	shlq	$0xe, %rax
14006893b:     	movq	%rdx, %rsi
14006893e:     	leaq	(%rdx,%rax), %rbx
140068942:     	addq	$0x16700, %rbx          # imm = 0x16700
140068949:     	addq	%r11, %rbx
14006894c:     	movl	$0x400, %r8d            # imm = 0x400
140068952:     	cmpq	$0x400, %r15            # imm = 0x400
140068959:     	je	0x140068969 <.text+0x67969>
14006895b:     	leaq	-0x10(%rbp), %rcx
14006895f:     	xorl	%edx, %edx
140068961:     	callq	0x140251dd2 <.text+0x250dd2>
140068966:     	movq	%r15, %r8
140068969:     	leaq	-0x10(%rbp), %rcx
14006896d:     	movq	%rbx, %rdx
140068970:     	callq	0x140251dc0 <.text+0x250dc0>
140068975:     	testb	%r14b, %r14b
140068978:     	je	0x1400689be <.text+0x679be>
14006897a:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
140068981:     	movq	%rsi, %rcx
140068984:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
14006898d:     	jne	0x140068b2a <.text+0x67b2a>
140068993:     	xorl	%edi, %edi
140068995:     	callq	0x14009b240 <.text+0x9a240>
14006899a:     	testb	$0x1, %al
14006899c:     	jne	0x1400689d0 <.text+0x679d0>
14006899e:     	jmp	0x140068b53 <.text+0x67b53>
1400689a3:     	movb	$0xa, (%rcx)
1400689a6:     	movq	%r10, 0x8(%rcx)
1400689aa:     	addq	$0x4f8, %rsp            # imm = 0x4F8
1400689b1:     	popq	%rbx
1400689b2:     	popq	%rdi
1400689b3:     	popq	%rsi
1400689b4:     	popq	%r12
1400689b6:     	popq	%r13
1400689b8:     	popq	%r14
1400689ba:     	popq	%r15
1400689bc:     	popq	%rbp
1400689bd:     	retq
1400689be:     	xorl	%edi, %edi
1400689c0:     	movq	%rsi, %rcx
1400689c3:     	callq	0x14009b240 <.text+0x9a240>
1400689c8:     	testb	$0x1, %al
1400689ca:     	je	0x140068b53 <.text+0x67b53>
1400689d0:     	movq	%rdx, %rbx
1400689d3:     	movq	0x500(%rbp), %rdx
1400689da:     	movzwl	0x4e8(%rbp), %ecx
1400689e1:     	movzbl	0x4e0(%rbp), %eax
1400689e8:     	movq	(%r12), %r8
1400689ec:     	movq	%rdi, 0x430(%rbp)
1400689f3:     	movq	0x468(%rbp), %r9
1400689fa:     	movq	%r9, 0x438(%rbp)
140068a01:     	movq	%r8, 0x440(%rbp)
140068a08:     	movb	%r14b, 0x448(%rbp)
140068a0f:     	movups	0x60(%r13), %xmm0
140068a14:     	movups	0x6c(%r13), %xmm1
140068a19:     	movups	%xmm1, 0x3fc(%rbp)
140068a20:     	movaps	%xmm0, 0x3f0(%rbp)
140068a27:     	leaq	0x8e(%r13), %r8
140068a2e:     	movq	0x7e(%r13), %r9
140068a32:     	movq	0x85(%r13), %r10
140068a39:     	movq	%r10, 0x457(%rbp)
140068a40:     	movq	%r9, 0x450(%rbp)
140068a47:     	leaq	0x450(%rbp), %r9
140068a4e:     	movq	%r9, 0x68(%rsp)
140068a53:     	movq	%rdx, 0x60(%rsp)
140068a58:     	movq	%r13, 0x58(%rsp)
140068a5d:     	leaq	0x430(%rbp), %rdx
140068a64:     	movq	%rdx, 0x50(%rsp)
140068a69:     	movq	%r15, 0x48(%rsp)
140068a6e:     	leaq	-0x10(%rbp), %rdx
140068a72:     	movq	%rdx, 0x40(%rsp)
140068a77:     	movq	0x460(%rbp), %rdx
140068a7e:     	movq	%rdx, 0x38(%rsp)
140068a83:     	movq	%r8, 0x30(%rsp)
140068a88:     	movw	%cx, 0x28(%rsp)
140068a8d:     	movb	%al, 0x20(%rsp)
140068a91:     	leaq	0x410(%rbp), %rcx
140068a98:     	leaq	0x3f0(%rbp), %r8
140068a9f:     	movq	%rsi, %rdx
140068aa2:     	movq	%rbx, %r9
140068aa5:     	callq	0x140082d10 <.text+0x81d10>
140068aaa:     	cmpb	$-0x1, 0x410(%rbp)
140068ab1:     	je	0x140068b62 <.text+0x67b62>
140068ab7:     	cmpb	$0x1, 0x37400(%rsi,%rbx)
140068abf:     	movq	0x470(%rbp), %rax
140068ac6:     	jne	0x140068b10 <.text+0x67b10>
140068ac8:     	cmpb	$0x0, 0x37420(%rsi,%rbx)
140068ad0:     	jne	0x140068b10 <.text+0x67b10>
140068ad2:     	movb	$0x0, 0x37400(%rsi,%rbx)
140068ada:     	decq	0x37448(%rsi)
140068ae1:     	leaq	0x37400(%rsi), %rcx
140068ae8:     	movq	$0x0, 0x432d0(%rsi,%rbx,8)
140068af4:     	leaq	(%rbx,%rbx,8), %rdx
140068af8:     	leaq	(%rdx,%rdx,2), %rdx
140068afc:     	addq	%rbx, %rdx
140068aff:     	movb	$0x2, 0x36a(%rcx,%rdx)
140068b07:     	leaq	(%rbx,%rbx,2), %rdx
140068b0b:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140068b10:     	movups	0x410(%rbp), %xmm0
140068b17:     	movups	0x420(%rbp), %xmm1
140068b1e:     	movups	%xmm1, 0x10(%rax)
140068b22:     	movups	%xmm0, (%rax)
140068b25:     	jmp	0x1400689aa <.text+0x679aa>
140068b2a:     	addq	%rcx, %rax
140068b2d:     	addq	$0x15c28, %rax          # imm = 0x15C28
140068b33:     	movq	0x98(%rax), %rax
140068b3a:     	movq	%rax, 0x468(%rbp)
140068b41:     	movl	$0x1, %edi
140068b46:     	callq	0x14009b240 <.text+0x9a240>
140068b4b:     	testb	$0x1, %al
140068b4d:     	jne	0x1400689d0 <.text+0x679d0>
140068b53:     	movq	0x470(%rbp), %rax
140068b5a:     	movb	$0x9, (%rax)
140068b5d:     	jmp	0x1400689aa <.text+0x679aa>
140068b62:     	movq	0x470(%rbp), %rax
140068b69:     	movq	%rbx, 0x8(%rax)
140068b6d:     	movb	$-0x1, (%rax)
140068b70:     	jmp	0x1400689aa <.text+0x679aa>
140068b75:     	leaq	0x205134(%rip), %r9     # 0x14026dcb0
140068b7c:     	movl	$0x4000, %r8d           # imm = 0x4000
140068b82:     	xorl	%ecx, %ecx
140068b84:     	movq	%rax, %rdx
140068b87:     	callq	0x140252850 <.text+0x251850>
140068b8c:     	ud2


D:/CoapticCurrent/oscore-packet-staging-20261104/option-reuse/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14025ce00: 55                          	pushq	%rbp
14025ce01: 41 57                       	pushq	%r15
14025ce03: 41 56                       	pushq	%r14
14025ce05: 41 55                       	pushq	%r13
14025ce07: 41 54                       	pushq	%r12
14025ce09: 56                          	pushq	%rsi
14025ce0a: 57                          	pushq	%rdi
14025ce0b: 53                          	pushq	%rbx
14025ce0c: 48 81 ec 98 05 00 00        	subq	$0x598, %rsp            # imm = 0x598
14025ce13: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
14025ce1b: 4d 89 ce                    	movq	%r9, %r14
14025ce1e: 4d 89 c7                    	movq	%r8, %r15
14025ce21: 48 89 d7                    	movq	%rdx, %rdi
14025ce24: 48 89 ce                    	movq	%rcx, %rsi
14025ce27: 48 8d 5d 08                 	leaq	0x8(%rbp), %rbx
14025ce2b: 41 b8 00 05 00 00           	movl	$0x500, %r8d            # imm = 0x500
14025ce31: 48 89 d9                    	movq	%rbx, %rcx
14025ce34: 31 d2                       	xorl	%edx, %edx
14025ce36: e8 e7 3f ff ff              	callq	0x140250e22 <.text+0x24fe22>
14025ce3b: 48 8d 8d 08 05 00 00        	leaq	0x508(%rbp), %rcx
14025ce42: 41 b9 00 05 00 00           	movl	$0x500, %r9d            # imm = 0x500
14025ce48: 48 89 fa                    	movq	%rdi, %rdx
14025ce4b: 49 89 d8                    	movq	%rbx, %r8
14025ce4e: e8 1d 3a eb ff              	callq	0x140110870 <.text+0x10f870>
14025ce53: 66 83 bd 08 05 00 00 01     	cmpw	$0x1, 0x508(%rbp)
14025ce5b: 74 49                       	je	0x14025cea6 <.text+0x25bea6>
14025ce5d: 48 8b 85 88 05 00 00        	movq	0x588(%rbp), %rax
14025ce64: 4c 8b 8d 80 05 00 00        	movq	0x580(%rbp), %r9
14025ce6b: 48 8b 8d 10 05 00 00        	movq	0x510(%rbp), %rcx
14025ce72: 48 89 5c 24 30              	movq	%rbx, 0x30(%rsp)
14025ce77: 48 89 4c 24 28              	movq	%rcx, 0x28(%rsp)
14025ce7c: 48 89 44 24 20              	movq	%rax, 0x20(%rsp)
14025ce81: 48 c7 44 24 38 00 05 00 00  	movq	$0x500, 0x38(%rsp)      # imm = 0x500
14025ce8a: 48 8d 8d 08 05 00 00        	leaq	0x508(%rbp), %rcx
14025ce91: 4c 89 fa                    	movq	%r15, %rdx
14025ce94: 4d 89 f0                    	movq	%r14, %r8
14025ce97: e8 04 00 db ff              	callq	0x14000cea0 <.text+0xbea0>
14025ce9c: 66 83 bd 08 05 00 00 01     	cmpw	$0x1, 0x508(%rbp)
14025cea4: 75 13                       	jne	0x14025ceb9 <.text+0x25beb9>
14025cea6: 8b 85 0a 05 00 00           	movl	0x50a(%rbp), %eax
14025ceac: 89 46 02                    	movl	%eax, 0x2(%rsi)
14025ceaf: 66 c7 06 01 00              	movw	$0x1, (%rsi)
14025ceb4: e9 e2 00 00 00              	jmp	0x14025cf9b <.text+0x25bf9b>
14025ceb9: 48 8b 95 10 05 00 00        	movq	0x510(%rbp), %rdx
14025cec0: 0f b6 47 22                 	movzbl	0x22(%rdi), %eax
14025cec4: 48 8b 0f                    	movq	(%rdi), %rcx
14025cec7: 4c 8b 57 08                 	movq	0x8(%rdi), %r10
14025cecb: 4d 85 d2                    	testq	%r10, %r10
14025cece: 74 26                       	je	0x14025cef6 <.text+0x25bef6>
14025ced0: 4e 8d 04 d5 00 00 00 00     	leaq	(,%r10,8), %r8
14025ced8: 4f 8d 04 40                 	leaq	(%r8,%r8,2), %r8
14025cedc: 45 31 c9                    	xorl	%r9d, %r9d
14025cedf: 90                          	nop
14025cee0: 66 42 83 7c 09 10 06        	cmpw	$0x6, 0x10(%rcx,%r9)
14025cee7: 0f 84 c2 00 00 00           	je	0x14025cfaf <.text+0x25bfaf>
14025ceed: 49 83 c1 18                 	addq	$0x18, %r9
14025cef1: 4d 39 c8                    	cmpq	%r9, %r8
14025cef4: 75 ea                       	jne	0x14025cee0 <.text+0x25bee0>
14025cef6: fe c8                       	decb	%al
14025cef8: 3c 1f                       	cmpb	$0x1f, %al
14025cefa: b8 02 00 00 00              	movl	$0x2, %eax
14025ceff: 41 b8 44 00 00 00           	movl	$0x44, %r8d
14025cf05: 44 0f 42 c0                 	cmovbl	%eax, %r8d
14025cf09: 48 81 fa 01 05 00 00        	cmpq	$0x501, %rdx            # imm = 0x501
14025cf10: 0f 83 b6 00 00 00           	jae	0x14025cfcc <.text+0x25bfcc>
14025cf16: 4c 8b 9d c0 05 00 00        	movq	0x5c0(%rbp), %r11
14025cf1d: 4c 8b b5 b8 05 00 00        	movq	0x5b8(%rbp), %r14
14025cf24: 4c 8b bd b0 05 00 00        	movq	0x5b0(%rbp), %r15
14025cf2b: 4c 8b a5 a8 05 00 00        	movq	0x5a8(%rbp), %r12
14025cf32: 4c 8b ad a0 05 00 00        	movq	0x5a0(%rbp), %r13
14025cf39: 0f b6 47 2c                 	movzbl	0x2c(%rdi), %eax
14025cf3d: 44 0f b7 4f 20              	movzwl	0x20(%rdi), %r9d
14025cf42: 48 83 c7 23                 	addq	$0x23, %rdi
14025cf46: 4c 89 5c 24 78              	movq	%r11, 0x78(%rsp)
14025cf4b: 4c 89 74 24 70              	movq	%r14, 0x70(%rsp)
14025cf50: 48 89 54 24 68              	movq	%rdx, 0x68(%rsp)
14025cf55: 48 89 5c 24 60              	movq	%rbx, 0x60(%rsp)
14025cf5a: 4c 89 7c 24 58              	movq	%r15, 0x58(%rsp)
14025cf5f: 4c 89 64 24 50              	movq	%r12, 0x50(%rsp)
14025cf64: 4c 89 6c 24 48              	movq	%r13, 0x48(%rsp)
14025cf69: 48 8b 95 98 05 00 00        	movq	0x598(%rbp), %rdx
14025cf70: 48 89 54 24 40              	movq	%rdx, 0x40(%rsp)
14025cf75: 48 8b 95 90 05 00 00        	movq	0x590(%rbp), %rdx
14025cf7c: 48 89 54 24 38              	movq	%rdx, 0x38(%rsp)
14025cf81: 4c 89 54 24 30              	movq	%r10, 0x30(%rsp)
14025cf86: 48 89 4c 24 28              	movq	%rcx, 0x28(%rsp)
14025cf8b: 48 89 7c 24 20              	movq	%rdi, 0x20(%rsp)
14025cf90: 89 c2                       	movl	%eax, %edx
14025cf92: 48 89 f1                    	movq	%rsi, %rcx
14025cf95: e8 66 25 eb ff              	callq	0x14010f500 <.text+0x10e500>
14025cf9a: 90                          	nop
14025cf9b: 48 81 c4 98 05 00 00        	addq	$0x598, %rsp            # imm = 0x598
14025cfa2: 5b                          	popq	%rbx
14025cfa3: 5f                          	popq	%rdi
14025cfa4: 5e                          	popq	%rsi
14025cfa5: 41 5c                       	popq	%r12
14025cfa7: 41 5d                       	popq	%r13
14025cfa9: 41 5e                       	popq	%r14
14025cfab: 41 5f                       	popq	%r15
14025cfad: 5d                          	popq	%rbp
14025cfae: c3                          	retq
14025cfaf: fe c8                       	decb	%al
14025cfb1: 3c 1f                       	cmpb	$0x1f, %al
14025cfb3: 41 0f 93 c0                 	setae	%r8b
14025cfb7: 41 c0 e0 06                 	shlb	$0x6, %r8b
14025cfbb: 41 80 c8 05                 	orb	$0x5, %r8b
14025cfbf: 48 81 fa 01 05 00 00        	cmpq	$0x501, %rdx            # imm = 0x501
14025cfc6: 0f 82 4a ff ff ff           	jb	0x14025cf16 <.text+0x25bf16>
14025cfcc: 4c 8d 0d 5d d6 00 00        	leaq	0xd65d(%rip), %r9       # 0x14026a630
14025cfd3: 41 b8 00 05 00 00           	movl	$0x500, %r8d            # imm = 0x500
14025cfd9: 31 c9                       	xorl	%ecx, %ecx
14025cfdb: e8 80 48 ff ff              	callq	0x140251860 <.text+0x250860>
14025cfe0: 0f 0b                       	ud2

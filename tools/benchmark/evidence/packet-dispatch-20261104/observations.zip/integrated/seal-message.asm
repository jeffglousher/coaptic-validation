
D:/CoapticCurrent/oscore-packet-staging-20261104/option-reuse/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14010fa70: 55                          	pushq	%rbp
14010fa71: 41 57                       	pushq	%r15
14010fa73: 41 56                       	pushq	%r14
14010fa75: 41 55                       	pushq	%r13
14010fa77: 41 54                       	pushq	%r12
14010fa79: 56                          	pushq	%rsi
14010fa7a: 57                          	pushq	%rdi
14010fa7b: 53                          	pushq	%rbx
14010fa7c: 48 81 ec b8 00 00 00        	subq	$0xb8, %rsp
14010fa83: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
14010fa8b: 4c 89 4d 18                 	movq	%r9, 0x18(%rbp)
14010fa8f: 4c 89 45 10                 	movq	%r8, 0x10(%rbp)
14010fa93: 49 89 d6                    	movq	%rdx, %r14
14010fa96: 48 89 4d 30                 	movq	%rcx, 0x30(%rbp)
14010fa9a: 48 8b b5 e0 00 00 00        	movq	0xe0(%rbp), %rsi
14010faa1: 4c 8b ad d8 00 00 00        	movq	0xd8(%rbp), %r13
14010faa8: 4c 8b a5 d0 00 00 00        	movq	0xd0(%rbp), %r12
14010faaf: 4c 8b 9d c8 00 00 00        	movq	0xc8(%rbp), %r11
14010fab6: 4c 8b 95 c0 00 00 00        	movq	0xc0(%rbp), %r10
14010fabd: 48 8b 8d b8 00 00 00        	movq	0xb8(%rbp), %rcx
14010fac4: 48 8b 85 b0 00 00 00        	movq	0xb0(%rbp), %rax
14010facb: 0f b6 52 2c                 	movzbl	0x2c(%rdx), %edx
14010facf: 45 0f b6 46 22              	movzbl	0x22(%r14), %r8d
14010fad4: 49 8b 1e                    	movq	(%r14), %rbx
14010fad7: 4d 8b 7e 08                 	movq	0x8(%r14), %r15
14010fadb: 4d 85 ff                    	testq	%r15, %r15
14010fade: 74 21                       	je	0x14010fb01 <.text+0x10eb01>
14010fae0: 4e 8d 0c fd 00 00 00 00     	leaq	(,%r15,8), %r9
14010fae8: 4f 8d 0c 49                 	leaq	(%r9,%r9,2), %r9
14010faec: 31 ff                       	xorl	%edi, %edi
14010faee: 66 90                       	nop
14010faf0: 66 83 7c 3b 10 06           	cmpw	$0x6, 0x10(%rbx,%rdi)
14010faf6: 74 22                       	je	0x14010fb1a <.text+0x10eb1a>
14010faf8: 48 83 c7 18                 	addq	$0x18, %rdi
14010fafc: 49 39 f9                    	cmpq	%rdi, %r9
14010faff: 75 ef                       	jne	0x14010faf0 <.text+0x10eaf0>
14010fb01: 41 fe c8                    	decb	%r8b
14010fb04: 41 80 f8 1f                 	cmpb	$0x1f, %r8b
14010fb08: 41 b9 02 00 00 00           	movl	$0x2, %r9d
14010fb0e: 41 b8 44 00 00 00           	movl	$0x44, %r8d
14010fb14: 45 0f 42 c1                 	cmovbl	%r9d, %r8d
14010fb18: eb 13                       	jmp	0x14010fb2d <.text+0x10eb2d>
14010fb1a: 41 fe c8                    	decb	%r8b
14010fb1d: 41 80 f8 1f                 	cmpb	$0x1f, %r8b
14010fb21: 41 0f 93 c0                 	setae	%r8b
14010fb25: 41 c0 e0 06                 	shlb	$0x6, %r8b
14010fb29: 41 80 c8 05                 	orb	$0x5, %r8b
14010fb2d: 4c 8b 8d a8 00 00 00        	movq	0xa8(%rbp), %r9
14010fb34: 4c 89 4d 08                 	movq	%r9, 0x8(%rbp)
14010fb38: 4c 8b 8d a0 00 00 00        	movq	0xa0(%rbp), %r9
14010fb3f: 4c 89 4d 00                 	movq	%r9, (%rbp)
14010fb43: 45 0f b7 4e 20              	movzwl	0x20(%r14), %r9d
14010fb48: 49 8d 7e 23                 	leaq	0x23(%r14), %rdi
14010fb4c: 48 89 74 24 78              	movq	%rsi, 0x78(%rsp)
14010fb51: 4c 89 6c 24 70              	movq	%r13, 0x70(%rsp)
14010fb56: 4c 89 64 24 58              	movq	%r12, 0x58(%rsp)
14010fb5b: 4c 89 5c 24 50              	movq	%r11, 0x50(%rsp)
14010fb60: 4c 89 54 24 48              	movq	%r10, 0x48(%rsp)
14010fb65: 48 89 4c 24 40              	movq	%rcx, 0x40(%rsp)
14010fb6a: 48 89 44 24 38              	movq	%rax, 0x38(%rsp)
14010fb6f: 4c 89 7c 24 30              	movq	%r15, 0x30(%rsp)
14010fb74: 48 89 5c 24 28              	movq	%rbx, 0x28(%rsp)
14010fb79: 48 89 7c 24 20              	movq	%rdi, 0x20(%rsp)
14010fb7e: 48 c7 44 24 68 00 00 00 00  	movq	$0x0, 0x68(%rsp)
14010fb87: 48 c7 44 24 60 01 00 00 00  	movq	$0x1, 0x60(%rsp)
14010fb90: 48 8d 4d 20                 	leaq	0x20(%rbp), %rcx
14010fb94: e8 67 f9 ff ff              	callq	0x14010f500 <.text+0x10e500>
14010fb99: 66 83 7d 20 01              	cmpw	$0x1, 0x20(%rbp)
14010fb9e: 0f 84 ba 00 00 00           	je	0x14010fc5e <.text+0x10ec5e>
14010fba4: 48 8b 5d 28                 	movq	0x28(%rbp), %rbx
14010fba8: 48 39 de                    	cmpq	%rbx, %rsi
14010fbab: 48 8b 7d 10                 	movq	0x10(%rbp), %rdi
14010fbaf: 0f 86 ba 00 00 00           	jbe	0x14010fc6f <.text+0x10ec6f>
14010fbb5: 4e 8d 24 2b                 	leaq	(%rbx,%r13), %r12
14010fbb9: 49 ff c4                    	incq	%r12
14010fbbc: 48 89 d8                    	movq	%rbx, %rax
14010fbbf: 48 f7 d0                    	notq	%rax
14010fbc2: 48 01 c6                    	addq	%rax, %rsi
14010fbc5: 41 c6 44 1d 00 ff           	movb	$-0x1, (%r13,%rbx)
14010fbcb: 48 81 fe 00 05 00 00        	cmpq	$0x500, %rsi            # imm = 0x500
14010fbd2: 41 bd 00 05 00 00           	movl	$0x500, %r13d           # imm = 0x500
14010fbd8: 4c 0f 42 ee                 	cmovbq	%rsi, %r13
14010fbdc: 48 8d 4d 20                 	leaq	0x20(%rbp), %rcx
14010fbe0: 4c 89 f2                    	movq	%r14, %rdx
14010fbe3: 4d 89 e0                    	movq	%r12, %r8
14010fbe6: 4d 89 e9                    	movq	%r13, %r9
14010fbe9: e8 82 0c 00 00              	callq	0x140110870 <.text+0x10f870>
14010fbee: 66 83 7d 20 01              	cmpw	$0x1, 0x20(%rbp)
14010fbf3: 0f 84 81 00 00 00           	je	0x14010fc7a <.text+0x10ec7a>
14010fbf9: 48 8b 45 28                 	movq	0x28(%rbp), %rax
14010fbfd: 4c 89 6c 24 38              	movq	%r13, 0x38(%rsp)
14010fc02: 4c 89 64 24 30              	movq	%r12, 0x30(%rsp)
14010fc07: 48 89 44 24 28              	movq	%rax, 0x28(%rsp)
14010fc0c: 48 8b 45 08                 	movq	0x8(%rbp), %rax
14010fc10: 48 89 44 24 20              	movq	%rax, 0x20(%rsp)
14010fc15: 48 8d 4d 20                 	leaq	0x20(%rbp), %rcx
14010fc19: 48 89 fa                    	movq	%rdi, %rdx
14010fc1c: 48 8b 75 18                 	movq	0x18(%rbp), %rsi
14010fc20: 49 89 f0                    	movq	%rsi, %r8
14010fc23: 4c 8b 4d 00                 	movq	(%rbp), %r9
14010fc27: e8 74 d2 ef ff              	callq	0x14000cea0 <.text+0xbea0>
14010fc2c: 66 83 7d 20 01              	cmpw	$0x1, 0x20(%rbp)
14010fc31: 74 50                       	je	0x14010fc83 <.text+0x10ec83>
14010fc33: 48 8b 45 28                 	movq	0x28(%rbp), %rax
14010fc37: 48 01 d8                    	addq	%rbx, %rax
14010fc3a: 48 ff c0                    	incq	%rax
14010fc3d: 48 8b 4d 30                 	movq	0x30(%rbp), %rcx
14010fc41: 48 89 41 08                 	movq	%rax, 0x8(%rcx)
14010fc45: 66 c7 01 00 00              	movw	$0x0, (%rcx)
14010fc4a: 48 81 c4 b8 00 00 00        	addq	$0xb8, %rsp
14010fc51: 5b                          	popq	%rbx
14010fc52: 5f                          	popq	%rdi
14010fc53: 5e                          	popq	%rsi
14010fc54: 41 5c                       	popq	%r12
14010fc56: 41 5d                       	popq	%r13
14010fc58: 41 5e                       	popq	%r14
14010fc5a: 41 5f                       	popq	%r15
14010fc5c: 5d                          	popq	%rbp
14010fc5d: c3                          	retq
14010fc5e: 8b 45 22                    	movl	0x22(%rbp), %eax
14010fc61: 48 8b 75 18                 	movq	0x18(%rbp), %rsi
14010fc65: 48 8b 4d 30                 	movq	0x30(%rbp), %rcx
14010fc69: 48 8b 7d 10                 	movq	0x10(%rbp), %rdi
14010fc6d: eb 1b                       	jmp	0x14010fc8a <.text+0x10ec8a>
14010fc6f: b8 11 00 00 00              	movl	$0x11, %eax
14010fc74: 48 8b 75 18                 	movq	0x18(%rbp), %rsi
14010fc78: eb 0c                       	jmp	0x14010fc86 <.text+0x10ec86>
14010fc7a: 8b 45 22                    	movl	0x22(%rbp), %eax
14010fc7d: 48 8b 75 18                 	movq	0x18(%rbp), %rsi
14010fc81: eb 03                       	jmp	0x14010fc86 <.text+0x10ec86>
14010fc83: 8b 45 22                    	movl	0x22(%rbp), %eax
14010fc86: 48 8b 4d 30                 	movq	0x30(%rbp), %rcx
14010fc8a: 89 41 02                    	movl	%eax, 0x2(%rcx)
14010fc8d: 66 c7 01 01 00              	movw	$0x1, (%rcx)
14010fc92: 4c 89 f2                    	movq	%r14, %rdx
14010fc95: 49 89 f8                    	movq	%rdi, %r8
14010fc98: 49 89 f1                    	movq	%rsi, %r9
14010fc9b: 48 81 c4 b8 00 00 00        	addq	$0xb8, %rsp
14010fca2: 5b                          	popq	%rbx
14010fca3: 5f                          	popq	%rdi
14010fca4: 5e                          	popq	%rsi
14010fca5: 41 5c                       	popq	%r12
14010fca7: 41 5d                       	popq	%r13
14010fca9: 41 5e                       	popq	%r14
14010fcab: 41 5f                       	popq	%r15
14010fcad: 5d                          	popq	%rbp
14010fcae: e9 4d d1 14 00              	jmp	0x14025ce00 <.text+0x25be00>

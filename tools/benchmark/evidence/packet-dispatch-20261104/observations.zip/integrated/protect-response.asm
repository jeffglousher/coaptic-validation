
D:/CoapticCurrent/oscore-packet-staging-20261104/option-reuse/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140110ac0: 55                          	pushq	%rbp
140110ac1: 41 57                       	pushq	%r15
140110ac3: 41 56                       	pushq	%r14
140110ac5: 41 55                       	pushq	%r13
140110ac7: 41 54                       	pushq	%r12
140110ac9: 56                          	pushq	%rsi
140110aca: 57                          	pushq	%rdi
140110acb: 53                          	pushq	%rbx
140110acc: 48 81 ec d8 00 00 00        	subq	$0xd8, %rsp
140110ad3: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
140110adb: 48 89 ce                    	movq	%rcx, %rsi
140110ade: 41 0f b6 40 22              	movzbl	0x22(%r8), %eax
140110ae3: c1 e8 05                    	shrl	$0x5, %eax
140110ae6: 83 f8 05                    	cmpl	$0x5, %eax
140110ae9: 0f 87 10 01 00 00           	ja	0x140110bff <.text+0x10fbff>
140110aef: b9 34 00 00 00              	movl	$0x34, %ecx
140110af4: 0f a3 c1                    	btl	%eax, %ecx
140110af7: 0f 83 02 01 00 00           	jae	0x140110bff <.text+0x10fbff>
140110afd: 4d 89 ce                    	movq	%r9, %r14
140110b00: 45 0f b6 79 07              	movzbl	0x7(%r9), %r15d
140110b05: 49 83 ff 08                 	cmpq	$0x8, %r15
140110b09: 0f 83 0a 01 00 00           	jae	0x140110c19 <.text+0x10fc19>
140110b0f: 48 89 d7                    	movq	%rdx, %rdi
140110b12: 45 8b 66 08                 	movl	0x8(%r14), %r12d
140110b16: 45 0f b7 6e 0c              	movzwl	0xc(%r14), %r13d
140110b1b: 66 44 89 6d 4c              	movw	%r13w, 0x4c(%rbp)
140110b20: 49 c1 e5 20                 	shlq	$0x20, %r13
140110b24: 44 89 65 48                 	movl	%r12d, 0x48(%rbp)
140110b28: 4c 89 ea                    	movq	%r13, %rdx
140110b2b: 48 c1 ea 28                 	shrq	$0x28, %rdx
140110b2f: 80 fa 06                    	cmpb	$0x6, %dl
140110b32: 0f 83 fa 00 00 00           	jae	0x140110c32 <.text+0x10fc32>
140110b38: 4c 89 c3                    	movq	%r8, %rbx
140110b3b: 48 89 54 24 20              	movq	%rdx, 0x20(%rsp)
140110b40: 48 8d 4d f0                 	leaq	-0x10(%rbp), %rcx
140110b44: 4c 8d 4d 48                 	leaq	0x48(%rbp), %r9
140110b48: 4c 89 f2                    	movq	%r14, %rdx
140110b4b: 4d 89 f8                    	movq	%r15, %r8
140110b4e: e8 4d 58 ef ff              	callq	0x1400063a0 <.text+0x53a0>
140110b53: 80 7d f0 00                 	cmpb	$0x0, -0x10(%rbp)
140110b57: 74 10                       	je	0x140110b69 <.text+0x10fb69>
140110b59: 8b 45 f2                    	movl	-0xe(%rbp), %eax
140110b5c: 89 46 02                    	movl	%eax, 0x2(%rsi)
140110b5f: 66 c7 06 01 00              	movw	$0x1, (%rsi)
140110b64: e9 9c 00 00 00              	jmp	0x140110c05 <.text+0x10fc05>
140110b69: 4d 09 ec                    	orq	%r13, %r12
140110b6c: 48 8b 45 18                 	movq	0x18(%rbp), %rax
140110b70: 48 89 45 40                 	movq	%rax, 0x40(%rbp)
140110b74: 0f 10 45 f8                 	movups	-0x8(%rbp), %xmm0
140110b78: 0f 10 4d 08                 	movups	0x8(%rbp), %xmm1
140110b7c: 0f 29 4d 30                 	movaps	%xmm1, 0x30(%rbp)
140110b80: 0f 29 45 20                 	movaps	%xmm0, 0x20(%rbp)
140110b84: 48 8d 97 5d 01 00 00        	leaq	0x15d(%rdi), %rdx
140110b8b: 4c 89 64 24 20              	movq	%r12, 0x20(%rsp)
140110b90: 48 8d 4d 48                 	leaq	0x48(%rbp), %rcx
140110b94: 4d 89 f0                    	movq	%r14, %r8
140110b97: 4d 89 f9                    	movq	%r15, %r9
140110b9a: e8 21 ca ef ff              	callq	0x14000d5c0 <.text+0xc5c0>
140110b9f: 48 8b 55 40                 	movq	0x40(%rbp), %rdx
140110ba3: 48 83 fa 21                 	cmpq	$0x21, %rdx
140110ba7: 0f 83 9b 00 00 00           	jae	0x140110c48 <.text+0x10fc48>
140110bad: 48 8b 85 c8 00 00 00        	movq	0xc8(%rbp), %rax
140110bb4: 48 8b 8d c0 00 00 00        	movq	0xc0(%rbp), %rcx
140110bbb: 48 81 c7 20 01 00 00        	addq	$0x120, %rdi            # imm = 0x120
140110bc2: 48 89 44 24 60              	movq	%rax, 0x60(%rsp)
140110bc7: 48 89 4c 24 58              	movq	%rcx, 0x58(%rsp)
140110bcc: 0f 57 c0                    	xorps	%xmm0, %xmm0
140110bcf: 0f 11 44 24 30              	movups	%xmm0, 0x30(%rsp)
140110bd4: 48 89 54 24 28              	movq	%rdx, 0x28(%rsp)
140110bd9: 48 8d 45 20                 	leaq	0x20(%rbp), %rax
140110bdd: 48 89 44 24 20              	movq	%rax, 0x20(%rsp)
140110be2: 48 c7 44 24 48 00 00 00 00  	movq	$0x0, 0x48(%rsp)
140110beb: 4c 8d 4d 48                 	leaq	0x48(%rbp), %r9
140110bef: 48 89 f1                    	movq	%rsi, %rcx
140110bf2: 48 89 da                    	movq	%rbx, %rdx
140110bf5: 49 89 f8                    	movq	%rdi, %r8
140110bf8: e8 73 ee ff ff              	callq	0x14010fa70 <.text+0x10ea70>
140110bfd: eb 06                       	jmp	0x140110c05 <.text+0x10fc05>
140110bff: c7 06 01 00 12 00           	movl	$0x120001, (%rsi)       # imm = 0x120001
140110c05: 48 81 c4 d8 00 00 00        	addq	$0xd8, %rsp
140110c0c: 5b                          	popq	%rbx
140110c0d: 5f                          	popq	%rdi
140110c0e: 5e                          	popq	%rsi
140110c0f: 41 5c                       	popq	%r12
140110c11: 41 5d                       	popq	%r13
140110c13: 41 5e                       	popq	%r14
140110c15: 41 5f                       	popq	%r15
140110c17: 5d                          	popq	%rbp
140110c18: c3                          	retq
140110c19: 4c 8d 0d d0 f3 14 00        	leaq	0x14f3d0(%rip), %r9     # 0x14025fff0
140110c20: 41 b8 07 00 00 00           	movl	$0x7, %r8d
140110c26: 31 c9                       	xorl	%ecx, %ecx
140110c28: 4c 89 fa                    	movq	%r15, %rdx
140110c2b: e8 30 0c 14 00              	callq	0x140251860 <.text+0x250860>
140110c30: 0f 0b                       	ud2
140110c32: 4c 8d 0d ff f1 14 00        	leaq	0x14f1ff(%rip), %r9     # 0x14025fe38
140110c39: 41 b8 05 00 00 00           	movl	$0x5, %r8d
140110c3f: 31 c9                       	xorl	%ecx, %ecx
140110c41: e8 1a 0c 14 00              	callq	0x140251860 <.text+0x250860>
140110c46: 0f 0b                       	ud2
140110c48: 4c 8d 0d 49 f1 14 00        	leaq	0x14f149(%rip), %r9     # 0x14025fd98
140110c4f: 41 b8 20 00 00 00           	movl	$0x20, %r8d
140110c55: 31 c9                       	xorl	%ecx, %ecx
140110c57: e8 04 0c 14 00              	callq	0x140251860 <.text+0x250860>
140110c5c: 0f 0b                       	ud2

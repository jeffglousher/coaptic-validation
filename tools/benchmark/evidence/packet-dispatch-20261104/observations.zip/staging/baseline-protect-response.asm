
D:/CoapticCurrent/dispatch-memory-20261104/response-scratch/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140111230: 55                          	pushq	%rbp
140111231: 41 57                       	pushq	%r15
140111233: 41 56                       	pushq	%r14
140111235: 41 55                       	pushq	%r13
140111237: 41 54                       	pushq	%r12
140111239: 56                          	pushq	%rsi
14011123a: 57                          	pushq	%rdi
14011123b: 53                          	pushq	%rbx
14011123c: 48 81 ec 08 06 00 00        	subq	$0x608, %rsp            # imm = 0x608
140111243: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
14011124b: 45 0f b6 60 22              	movzbl	0x22(%r8), %r12d
140111250: 44 89 e0                    	movl	%r12d, %eax
140111253: c1 e8 05                    	shrl	$0x5, %eax
140111256: 83 f8 05                    	cmpl	$0x5, %eax
140111259: 0f 87 72 01 00 00           	ja	0x1401113d1 <.text+0x1103d1>
14011125f: 48 89 d3                    	movq	%rdx, %rbx
140111262: ba 34 00 00 00              	movl	$0x34, %edx
140111267: 0f a3 c2                    	btl	%eax, %edx
14011126a: 0f 83 61 01 00 00           	jae	0x1401113d1 <.text+0x1103d1>
140111270: 4d 89 ce                    	movq	%r9, %r14
140111273: 45 0f b6 79 07              	movzbl	0x7(%r9), %r15d
140111278: 49 83 ff 08                 	cmpq	$0x8, %r15
14011127c: 0f 83 5f 02 00 00           	jae	0x1401114e1 <.text+0x1104e1>
140111282: 45 8b 6e 08                 	movl	0x8(%r14), %r13d
140111286: 41 0f b7 76 0c              	movzwl	0xc(%r14), %esi
14011128b: 66 89 75 04                 	movw	%si, 0x4(%rbp)
14011128f: 48 c1 e6 20                 	shlq	$0x20, %rsi
140111293: 44 89 6d 00                 	movl	%r13d, (%rbp)
140111297: 48 89 f2                    	movq	%rsi, %rdx
14011129a: 48 c1 ea 28                 	shrq	$0x28, %rdx
14011129e: 80 fa 06                    	cmpb	$0x6, %dl
1401112a1: 0f 83 53 02 00 00           	jae	0x1401114fa <.text+0x1104fa>
1401112a7: 4c 89 c7                    	movq	%r8, %rdi
1401112aa: 48 89 8d 80 05 00 00        	movq	%rcx, 0x580(%rbp)
1401112b1: 48 89 54 24 20              	movq	%rdx, 0x20(%rsp)
1401112b6: 48 8d 8d 00 05 00 00        	leaq	0x500(%rbp), %rcx
1401112bd: 49 89 e9                    	movq	%rbp, %r9
1401112c0: 4c 89 f2                    	movq	%r14, %rdx
1401112c3: 4d 89 f8                    	movq	%r15, %r8
1401112c6: e8 d5 50 ef ff              	callq	0x1400063a0 <.text+0x53a0>
1401112cb: 80 bd 00 05 00 00 00        	cmpb	$0x0, 0x500(%rbp)
1401112d2: 74 0b                       	je	0x1401112df <.text+0x1102df>
1401112d4: 8b 85 02 05 00 00           	movl	0x502(%rbp), %eax
1401112da: e9 de 00 00 00              	jmp	0x1401113bd <.text+0x1103bd>
1401112df: 49 09 f5                    	orq	%rsi, %r13
1401112e2: 48 8b 85 28 05 00 00        	movq	0x528(%rbp), %rax
1401112e9: 48 89 85 50 05 00 00        	movq	%rax, 0x550(%rbp)
1401112f0: 0f 10 85 08 05 00 00        	movups	0x508(%rbp), %xmm0
1401112f7: 0f 10 8d 18 05 00 00        	movups	0x518(%rbp), %xmm1
1401112fe: 0f 29 8d 40 05 00 00        	movaps	%xmm1, 0x540(%rbp)
140111305: 0f 29 85 30 05 00 00        	movaps	%xmm0, 0x530(%rbp)
14011130c: 48 8d 93 5d 01 00 00        	leaq	0x15d(%rbx), %rdx
140111313: 4c 89 6c 24 20              	movq	%r13, 0x20(%rsp)
140111318: 48 8d 8d 63 05 00 00        	leaq	0x563(%rbp), %rcx
14011131f: 4d 89 f0                    	movq	%r14, %r8
140111322: 4d 89 f9                    	movq	%r15, %r9
140111325: e8 96 c2 ef ff              	callq	0x14000d5c0 <.text+0xc5c0>
14011132a: 49 89 ee                    	movq	%rbp, %r14
14011132d: 41 b8 00 05 00 00           	movl	$0x500, %r8d            # imm = 0x500
140111333: 4c 89 f1                    	movq	%r14, %rcx
140111336: 31 d2                       	xorl	%edx, %edx
140111338: e8 e5 0d 14 00              	callq	0x140252122 <.text+0x251122>
14011133d: 48 8d 8d 70 05 00 00        	leaq	0x570(%rbp), %rcx
140111344: 48 89 fa                    	movq	%rdi, %rdx
140111347: 4d 89 f0                    	movq	%r14, %r8
14011134a: e8 91 fc ff ff              	callq	0x140110fe0 <.text+0x10ffe0>
14011134f: 66 83 bd 70 05 00 00 01     	cmpw	$0x1, 0x570(%rbp)
140111357: 74 5e                       	je	0x1401113b7 <.text+0x1103b7>
140111359: 48 8b 95 50 05 00 00        	movq	0x550(%rbp), %rdx
140111360: 48 83 fa 21                 	cmpq	$0x21, %rdx
140111364: 0f 83 a6 01 00 00           	jae	0x140111510 <.text+0x110510>
14011136a: 48 8b 85 78 05 00 00        	movq	0x578(%rbp), %rax
140111371: 48 81 c3 20 01 00 00        	addq	$0x120, %rbx            # imm = 0x120
140111378: 4c 89 74 24 30              	movq	%r14, 0x30(%rsp)
14011137d: 48 89 44 24 28              	movq	%rax, 0x28(%rsp)
140111382: 48 89 54 24 20              	movq	%rdx, 0x20(%rsp)
140111387: 48 c7 44 24 38 00 05 00 00  	movq	$0x500, 0x38(%rsp)      # imm = 0x500
140111390: 48 8d 8d 70 05 00 00        	leaq	0x570(%rbp), %rcx
140111397: 4c 8d 85 63 05 00 00        	leaq	0x563(%rbp), %r8
14011139e: 4c 8d 8d 30 05 00 00        	leaq	0x530(%rbp), %r9
1401113a5: 48 89 da                    	movq	%rbx, %rdx
1401113a8: e8 f3 ba ef ff              	callq	0x14000cea0 <.text+0xbea0>
1401113ad: 66 83 bd 70 05 00 00 01     	cmpw	$0x1, 0x570(%rbp)
1401113b5: 75 25                       	jne	0x1401113dc <.text+0x1103dc>
1401113b7: 8b 85 72 05 00 00           	movl	0x572(%rbp), %eax
1401113bd: 48 8b 8d 80 05 00 00        	movq	0x580(%rbp), %rcx
1401113c4: 89 41 02                    	movl	%eax, 0x2(%rcx)
1401113c7: 66 c7 01 01 00              	movw	$0x1, (%rcx)
1401113cc: e9 c6 00 00 00              	jmp	0x140111497 <.text+0x110497>
1401113d1: c7 01 01 00 12 00           	movl	$0x120001, (%rcx)       # imm = 0x120001
1401113d7: e9 bb 00 00 00              	jmp	0x140111497 <.text+0x110497>
1401113dc: 48 8b 95 78 05 00 00        	movq	0x578(%rbp), %rdx
1401113e3: 48 8b 0f                    	movq	(%rdi), %rcx
1401113e6: 4c 8b 57 08                 	movq	0x8(%rdi), %r10
1401113ea: 4d 85 d2                    	testq	%r10, %r10
1401113ed: 74 27                       	je	0x140111416 <.text+0x110416>
1401113ef: 4a 8d 04 d5 00 00 00 00     	leaq	(,%r10,8), %rax
1401113f7: 48 8d 04 40                 	leaq	(%rax,%rax,2), %rax
1401113fb: 45 31 c0                    	xorl	%r8d, %r8d
1401113fe: 66 90                       	nop
140111400: 66 42 83 7c 01 10 06        	cmpw	$0x6, 0x10(%rcx,%r8)
140111407: 0f 84 9e 00 00 00           	je	0x1401114ab <.text+0x1104ab>
14011140d: 49 83 c0 18                 	addq	$0x18, %r8
140111411: 4c 39 c0                    	cmpq	%r8, %rax
140111414: 75 ea                       	jne	0x140111400 <.text+0x110400>
140111416: 41 fe cc                    	decb	%r12b
140111419: 41 80 fc 1f                 	cmpb	$0x1f, %r12b
14011141d: b8 02 00 00 00              	movl	$0x2, %eax
140111422: 41 b8 44 00 00 00           	movl	$0x44, %r8d
140111428: 44 0f 42 c0                 	cmovbl	%eax, %r8d
14011142c: 48 81 fa 01 05 00 00        	cmpq	$0x501, %rdx            # imm = 0x501
140111433: 0f 83 92 00 00 00           	jae	0x1401114cb <.text+0x1104cb>
140111439: 4c 8b 9d f8 05 00 00        	movq	0x5f8(%rbp), %r11
140111440: 48 8b b5 f0 05 00 00        	movq	0x5f0(%rbp), %rsi
140111447: 0f b6 47 2c                 	movzbl	0x2c(%rdi), %eax
14011144b: 44 0f b7 4f 20              	movzwl	0x20(%rdi), %r9d
140111450: 48 83 c7 23                 	addq	$0x23, %rdi
140111454: 4c 89 5c 24 78              	movq	%r11, 0x78(%rsp)
140111459: 48 89 74 24 70              	movq	%rsi, 0x70(%rsp)
14011145e: 48 89 54 24 68              	movq	%rdx, 0x68(%rsp)
140111463: 4c 89 74 24 60              	movq	%r14, 0x60(%rsp)
140111468: 0f 57 c0                    	xorps	%xmm0, %xmm0
14011146b: 0f 11 44 24 38              	movups	%xmm0, 0x38(%rsp)
140111470: 4c 89 54 24 30              	movq	%r10, 0x30(%rsp)
140111475: 48 89 4c 24 28              	movq	%rcx, 0x28(%rsp)
14011147a: 48 89 7c 24 20              	movq	%rdi, 0x20(%rsp)
14011147f: 48 c7 44 24 50 00 00 00 00  	movq	$0x0, 0x50(%rsp)
140111488: 48 8b 8d 80 05 00 00        	movq	0x580(%rbp), %rcx
14011148f: 89 c2                       	movl	%eax, %edx
140111491: e8 5a ea ff ff              	callq	0x14010fef0 <.text+0x10eef0>
140111496: 90                          	nop
140111497: 48 81 c4 08 06 00 00        	addq	$0x608, %rsp            # imm = 0x608
14011149e: 5b                          	popq	%rbx
14011149f: 5f                          	popq	%rdi
1401114a0: 5e                          	popq	%rsi
1401114a1: 41 5c                       	popq	%r12
1401114a3: 41 5d                       	popq	%r13
1401114a5: 41 5e                       	popq	%r14
1401114a7: 41 5f                       	popq	%r15
1401114a9: 5d                          	popq	%rbp
1401114aa: c3                          	retq
1401114ab: 41 fe cc                    	decb	%r12b
1401114ae: 41 80 fc 1f                 	cmpb	$0x1f, %r12b
1401114b2: 41 0f 93 c0                 	setae	%r8b
1401114b6: 41 c0 e0 06                 	shlb	$0x6, %r8b
1401114ba: 41 80 c8 05                 	orb	$0x5, %r8b
1401114be: 48 81 fa 01 05 00 00        	cmpq	$0x501, %rdx            # imm = 0x501
1401114c5: 0f 82 6e ff ff ff           	jb	0x140111439 <.text+0x110439>
1401114cb: 4c 8d 0d 06 a2 15 00        	leaq	0x15a206(%rip), %r9     # 0x14026b6d8
1401114d2: 41 b8 00 05 00 00           	movl	$0x500, %r8d            # imm = 0x500
1401114d8: 31 c9                       	xorl	%ecx, %ecx
1401114da: e8 81 16 14 00              	callq	0x140252b60 <.text+0x251b60>
1401114df: 0f 0b                       	ud2
1401114e1: 4c 8d 0d d0 fa 14 00        	leaq	0x14fad0(%rip), %r9     # 0x140260fb8
1401114e8: 41 b8 07 00 00 00           	movl	$0x7, %r8d
1401114ee: 31 c9                       	xorl	%ecx, %ecx
1401114f0: 4c 89 fa                    	movq	%r15, %rdx
1401114f3: e8 68 16 14 00              	callq	0x140252b60 <.text+0x251b60>
1401114f8: 0f 0b                       	ud2
1401114fa: 4c 8d 0d 17 f9 14 00        	leaq	0x14f917(%rip), %r9     # 0x140260e18
140111501: 41 b8 05 00 00 00           	movl	$0x5, %r8d
140111507: 31 c9                       	xorl	%ecx, %ecx
140111509: e8 52 16 14 00              	callq	0x140252b60 <.text+0x251b60>
14011150e: 0f 0b                       	ud2
140111510: 4c 8d 0d 69 f8 14 00        	leaq	0x14f869(%rip), %r9     # 0x140260d80
140111517: 41 b8 20 00 00 00           	movl	$0x20, %r8d
14011151d: 31 c9                       	xorl	%ecx, %ecx
14011151f: e8 3c 16 14 00              	callq	0x140252b60 <.text+0x251b60>
140111524: 0f 0b                       	ud2

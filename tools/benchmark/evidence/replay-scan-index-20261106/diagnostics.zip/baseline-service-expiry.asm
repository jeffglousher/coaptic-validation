
D:\CoapticCurrent\oscore-packet-staging-20261104\option-reuse\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400a1b10:     	pushq	%rbp
1400a1b11:     	pushq	%r15
1400a1b13:     	pushq	%r14
1400a1b15:     	pushq	%r13
1400a1b17:     	pushq	%r12
1400a1b19:     	pushq	%rsi
1400a1b1a:     	pushq	%rdi
1400a1b1b:     	pushq	%rbx
1400a1b1c:     	movq	%rsp, %rbp
1400a1b1f:     	cmpb	$0x2, 0x22(%rdx)
1400a1b23:     	je	0x1400a1b34 <.text+0xa0b34>
1400a1b25:     	movq	(%rdx), %rax
1400a1b28:     	decq	%rax
1400a1b2b:     	cmpq	%r8, %rax
1400a1b2e:     	jae	0x1400a1b34 <.text+0xa0b34>
1400a1b30:     	movb	$0x2, 0x22(%rdx)
1400a1b34:     	cmpq	$0x0, 0x5048(%rcx)
1400a1b3c:     	je	0x1400a1ca5 <.text+0xa0ca5>
1400a1b42:     	leaq	0x5000(%rcx), %rax
1400a1b49:     	leaq	0x37740(%rcx), %rdx
1400a1b50:     	xorl	%r9d, %r9d
1400a1b53:     	jmp	0x1400a1b6d <.text+0xa0b6d>
1400a1b55:     	nopw	%cs:(%rax,%rax)
1400a1b60:     	incq	%r9
1400a1b63:     	cmpq	$0x40, %r9
1400a1b67:     	je	0x1400a1ca5 <.text+0xa0ca5>
1400a1b6d:     	cmpb	$0x1, (%rax,%r9)
1400a1b72:     	jne	0x1400a1b60 <.text+0xa0b60>
1400a1b74:     	leaq	(%r9,%r9,4), %r14
1400a1b78:     	shlq	$0x6, %r14
1400a1b7c:     	movq	(%rcx,%r14), %r15
1400a1b80:     	cmpq	$0x2, %r15
1400a1b84:     	je	0x1400a1b60 <.text+0xa0b60>
1400a1b86:     	addq	%rcx, %r14
1400a1b89:     	movq	0x30(%r14), %r10
1400a1b8d:     	decq	%r10
1400a1b90:     	cmpq	%r8, %r10
1400a1b93:     	jae	0x1400a1b60 <.text+0xa0b60>
1400a1b95:     	movq	0x10(%r14), %r10
1400a1b99:     	movq	0x18(%r14), %r11
1400a1b9d:     	movq	0x20(%r14), %xmm0
1400a1ba3:     	movzwl	0x28(%r14), %esi
1400a1ba8:     	movzbl	0x2a(%r14), %ebx
1400a1bad:     	movzwl	0x2c(%r14), %edi
1400a1bb2:     	cmpl	$0x1, %r15d
1400a1bb6:     	jne	0x1400a1c0e <.text+0xa0c0e>
1400a1bb8:     	movq	0x8(%r14), %r14
1400a1bbc:     	cmpq	$0x1f, %r14
1400a1bc0:     	ja	0x1400a1c0e <.text+0xa0c0e>
1400a1bc2:     	cmpb	$0x1, (%rdx,%r14)
1400a1bc7:     	jne	0x1400a1c0e <.text+0xa0c0e>
1400a1bc9:     	cmpb	$0x0, 0x37760(%rcx,%r14)
1400a1bd2:     	jne	0x1400a1c0e <.text+0xa0c0e>
1400a1bd4:     	movb	$0x0, 0x37740(%rcx,%r14)
1400a1bdd:     	decq	0x37788(%rcx)
1400a1be4:     	movq	$0x0, 0x43610(%rcx,%r14,8)
1400a1bf0:     	leaq	(%r14,%r14,8), %r15
1400a1bf4:     	leaq	(%r15,%r15,2), %r15
1400a1bf8:     	addq	%r14, %r15
1400a1bfb:     	movb	$0x2, 0x36a(%rdx,%r15)
1400a1c04:     	leaq	(%r14,%r14,2), %r14
1400a1c08:     	movb	$0x2, 0x5d(%rdx,%r14,8)
1400a1c0e:     	movq	$-0x5000, %r14          # imm = 0xB000
1400a1c15:     	movq	%rax, %r15
1400a1c18:     	jmp	0x1400a1c30 <.text+0xa0c30>
1400a1c1a:     	nopw	(%rax,%rax)
1400a1c20:     	incq	%r15
1400a1c23:     	addq	$0x140, %r14            # imm = 0x140
1400a1c2a:     	je	0x1400a1b60 <.text+0xa0b60>
1400a1c30:     	cmpb	$0x1, (%r15)
1400a1c34:     	jne	0x1400a1c20 <.text+0xa0c20>
1400a1c36:     	cmpl	$0x2, (%rax,%r14)
1400a1c3b:     	je	0x1400a1c20 <.text+0xa0c20>
1400a1c3d:     	cmpw	%di, 0x2c(%rax,%r14)
1400a1c43:     	jne	0x1400a1c20 <.text+0xa0c20>
1400a1c45:     	movq	0x20(%rax,%r14), %xmm1
1400a1c4c:     	pcmpeqd	%xmm0, %xmm1
1400a1c50:     	pshufd	$0x50, %xmm1, %xmm1     # xmm1 = xmm1[0,0,1,1]
1400a1c55:     	movmskpd	%xmm1, %r12d
1400a1c5a:     	testb	$0x1, %r12b
1400a1c5e:     	je	0x1400a1c20 <.text+0xa0c20>
1400a1c60:     	shrb	%r12b
1400a1c63:     	je	0x1400a1c20 <.text+0xa0c20>
1400a1c65:     	cmpw	%si, 0x28(%rax,%r14)
1400a1c6b:     	jne	0x1400a1c20 <.text+0xa0c20>
1400a1c6d:     	cmpb	%bl, 0x2a(%rax,%r14)
1400a1c72:     	jne	0x1400a1c20 <.text+0xa0c20>
1400a1c74:     	movq	0x10(%rax,%r14), %r12
1400a1c79:     	xorq	%r10, %r12
1400a1c7c:     	movq	0x18(%rax,%r14), %r13
1400a1c81:     	xorq	%r11, %r13
1400a1c84:     	orq	%r12, %r13
1400a1c87:     	jne	0x1400a1c20 <.text+0xa0c20>
1400a1c89:     	movb	$0x0, (%r15)
1400a1c8d:     	decq	0x5048(%rcx)
1400a1c94:     	movq	$0x2, 0x5000(%rcx,%r14)
1400a1ca0:     	jmp	0x1400a1b60 <.text+0xa0b60>
1400a1ca5:     	popq	%rbx
1400a1ca6:     	popq	%rdi
1400a1ca7:     	popq	%rsi
1400a1ca8:     	popq	%r12
1400a1caa:     	popq	%r13
1400a1cac:     	popq	%r14
1400a1cae:     	popq	%r15
1400a1cb0:     	popq	%rbp
1400a1cb1:     	retq

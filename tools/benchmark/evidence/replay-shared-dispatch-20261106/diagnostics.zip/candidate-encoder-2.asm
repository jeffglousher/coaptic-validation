
D:\CoapticCurrent\replay-shared-dispatch-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400676e0:     	pushq	%rbp
1400676e1:     	pushq	%r15
1400676e3:     	pushq	%r14
1400676e5:     	pushq	%r13
1400676e7:     	pushq	%r12
1400676e9:     	pushq	%rsi
1400676ea:     	pushq	%rdi
1400676eb:     	pushq	%rbx
1400676ec:     	subq	$0x4f8, %rsp            # imm = 0x4F8
1400676f3:     	leaq	0x80(%rsp), %rbp
1400676fb:     	movq	0x4f0(%rbp), %r12
140067702:     	movq	0x8(%r12), %rdi
140067707:     	movl	$0x3, %r10d
14006770d:     	cmpq	$0x3, %rdi
140067711:     	ja	0x1400677f3 <.text+0x667f3>
140067717:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
14006771f:     	jne	0x1400677f3 <.text+0x667f3>
140067725:     	movq	0x26700(%rdx,%rdi,8), %rax
14006772d:     	cmpq	$0x4001, %rax           # imm = 0x4001
140067733:     	jae	0x1400679c5 <.text+0x669c5>
140067739:     	movq	0x10(%r12), %r11
14006773e:     	movq	0x18(%r12), %r15
140067743:     	movq	%r15, %rsi
140067746:     	movl	$0xb, %r10d
14006774c:     	addq	%r11, %rsi
14006774f:     	jb	0x1400677f3 <.text+0x667f3>
140067755:     	cmpq	$0x400, %r15            # imm = 0x400
14006775c:     	ja	0x1400677f3 <.text+0x667f3>
140067762:     	cmpq	%rax, %rsi
140067765:     	ja	0x1400677f3 <.text+0x667f3>
14006776b:     	movq	%r8, %r13
14006776e:     	movq	%r9, 0x460(%rbp)
140067775:     	movq	%rcx, 0x470(%rbp)
14006777c:     	movzbl	0x4f8(%rbp), %r14d
140067784:     	movq	%rdi, %rax
140067787:     	shlq	$0xe, %rax
14006778b:     	movq	%rdx, %rsi
14006778e:     	leaq	(%rdx,%rax), %rbx
140067792:     	addq	$0x16700, %rbx          # imm = 0x16700
140067799:     	addq	%r11, %rbx
14006779c:     	movl	$0x400, %r8d            # imm = 0x400
1400677a2:     	cmpq	$0x400, %r15            # imm = 0x400
1400677a9:     	je	0x1400677b9 <.text+0x667b9>
1400677ab:     	leaq	-0x10(%rbp), %rcx
1400677af:     	xorl	%edx, %edx
1400677b1:     	callq	0x140252002 <.text+0x251002>
1400677b6:     	movq	%r15, %r8
1400677b9:     	leaq	-0x10(%rbp), %rcx
1400677bd:     	movq	%rbx, %rdx
1400677c0:     	callq	0x140251ff0 <.text+0x250ff0>
1400677c5:     	testb	%r14b, %r14b
1400677c8:     	je	0x14006780e <.text+0x6680e>
1400677ca:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
1400677d1:     	movq	%rsi, %rcx
1400677d4:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
1400677dd:     	jne	0x14006797a <.text+0x6697a>
1400677e3:     	xorl	%edi, %edi
1400677e5:     	callq	0x14009a100 <.text+0x99100>
1400677ea:     	testb	$0x1, %al
1400677ec:     	jne	0x140067820 <.text+0x66820>
1400677ee:     	jmp	0x1400679a3 <.text+0x669a3>
1400677f3:     	movb	$0xa, (%rcx)
1400677f6:     	movq	%r10, 0x8(%rcx)
1400677fa:     	addq	$0x4f8, %rsp            # imm = 0x4F8
140067801:     	popq	%rbx
140067802:     	popq	%rdi
140067803:     	popq	%rsi
140067804:     	popq	%r12
140067806:     	popq	%r13
140067808:     	popq	%r14
14006780a:     	popq	%r15
14006780c:     	popq	%rbp
14006780d:     	retq
14006780e:     	xorl	%edi, %edi
140067810:     	movq	%rsi, %rcx
140067813:     	callq	0x14009a100 <.text+0x99100>
140067818:     	testb	$0x1, %al
14006781a:     	je	0x1400679a3 <.text+0x669a3>
140067820:     	movq	%rdx, %rbx
140067823:     	movq	0x500(%rbp), %rdx
14006782a:     	movzwl	0x4e8(%rbp), %ecx
140067831:     	movzbl	0x4e0(%rbp), %eax
140067838:     	movq	(%r12), %r8
14006783c:     	movq	%rdi, 0x430(%rbp)
140067843:     	movq	0x468(%rbp), %r9
14006784a:     	movq	%r9, 0x438(%rbp)
140067851:     	movq	%r8, 0x440(%rbp)
140067858:     	movb	%r14b, 0x448(%rbp)
14006785f:     	movups	0x60(%r13), %xmm0
140067864:     	movups	0x6c(%r13), %xmm1
140067869:     	movups	%xmm1, 0x3fc(%rbp)
140067870:     	movaps	%xmm0, 0x3f0(%rbp)
140067877:     	leaq	0x8e(%r13), %r8
14006787e:     	movq	0x7e(%r13), %r9
140067882:     	movq	0x85(%r13), %r10
140067889:     	movq	%r10, 0x457(%rbp)
140067890:     	movq	%r9, 0x450(%rbp)
140067897:     	leaq	0x450(%rbp), %r9
14006789e:     	movq	%r9, 0x68(%rsp)
1400678a3:     	movq	%rdx, 0x60(%rsp)
1400678a8:     	movq	%r13, 0x58(%rsp)
1400678ad:     	leaq	0x430(%rbp), %rdx
1400678b4:     	movq	%rdx, 0x50(%rsp)
1400678b9:     	movq	%r15, 0x48(%rsp)
1400678be:     	leaq	-0x10(%rbp), %rdx
1400678c2:     	movq	%rdx, 0x40(%rsp)
1400678c7:     	movq	0x460(%rbp), %rdx
1400678ce:     	movq	%rdx, 0x38(%rsp)
1400678d3:     	movq	%r8, 0x30(%rsp)
1400678d8:     	movw	%cx, 0x28(%rsp)
1400678dd:     	movb	%al, 0x20(%rsp)
1400678e1:     	leaq	0x410(%rbp), %rcx
1400678e8:     	leaq	0x3f0(%rbp), %r8
1400678ef:     	movq	%rsi, %rdx
1400678f2:     	movq	%rbx, %r9
1400678f5:     	callq	0x140081b20 <.text+0x80b20>
1400678fa:     	cmpb	$-0x1, 0x410(%rbp)
140067901:     	je	0x1400679b2 <.text+0x669b2>
140067907:     	cmpb	$0x1, 0x326f0(%rsi,%rbx)
14006790f:     	movq	0x470(%rbp), %rax
140067916:     	jne	0x140067960 <.text+0x66960>
140067918:     	cmpb	$0x0, 0x32710(%rsi,%rbx)
140067920:     	jne	0x140067960 <.text+0x66960>
140067922:     	movb	$0x0, 0x326f0(%rsi,%rbx)
14006792a:     	decq	0x32738(%rsi)
140067931:     	leaq	0x326f0(%rsi), %rcx
140067938:     	movq	$0x0, 0x3e5c0(%rsi,%rbx,8)
140067944:     	leaq	(%rbx,%rbx,8), %rdx
140067948:     	leaq	(%rdx,%rdx,2), %rdx
14006794c:     	addq	%rbx, %rdx
14006794f:     	movb	$0x2, 0x36a(%rcx,%rdx)
140067957:     	leaq	(%rbx,%rbx,2), %rdx
14006795b:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140067960:     	movups	0x410(%rbp), %xmm0
140067967:     	movups	0x420(%rbp), %xmm1
14006796e:     	movups	%xmm1, 0x10(%rax)
140067972:     	movups	%xmm0, (%rax)
140067975:     	jmp	0x1400677fa <.text+0x667fa>
14006797a:     	addq	%rcx, %rax
14006797d:     	addq	$0x15c28, %rax          # imm = 0x15C28
140067983:     	movq	0x98(%rax), %rax
14006798a:     	movq	%rax, 0x468(%rbp)
140067991:     	movl	$0x1, %edi
140067996:     	callq	0x14009a100 <.text+0x99100>
14006799b:     	testb	$0x1, %al
14006799d:     	jne	0x140067820 <.text+0x66820>
1400679a3:     	movq	0x470(%rbp), %rax
1400679aa:     	movb	$0x9, (%rax)
1400679ad:     	jmp	0x1400677fa <.text+0x667fa>
1400679b2:     	movq	0x470(%rbp), %rax
1400679b9:     	movq	%rbx, 0x8(%rax)
1400679bd:     	movb	$-0x1, (%rax)
1400679c0:     	jmp	0x1400677fa <.text+0x667fa>
1400679c5:     	leaq	0x206284(%rip), %r9     # 0x14026dc50
1400679cc:     	movl	$0x4000, %r8d           # imm = 0x4000
1400679d2:     	xorl	%ecx, %ecx
1400679d4:     	movq	%rax, %rdx
1400679d7:     	callq	0x140252a80 <.text+0x251a80>
1400679dc:     	ud2

from pathlib import Path
import subprocess,os,json
r=Path(__file__).resolve().parent
repo=Path('C:/Users/jeffg/.t3/worktrees/coaptic/t3-a578955c')
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR='D:/coaptic-batch-interop-target')
env.pop('RUSTFLAGS',None);env.pop('RUSTC_BOOTSTRAP',None)
results=json.loads((r/'initial-focused-checks.json').read_text())
results[1]['source']='d35f8ff585a7795ab25d71926bd5253fdeaa77c1';results[1]['reuse']='Only comments and a Clippy allowance changed; check-reuse.json'
for index,args in [(0,['fmt','--all','--','--check']),(2,['clippy','--locked','--offline','--all-targets','--all-features','--','-D','warnings'])]:
 name=results[index]['name'];cmd=[str(Path.home()/'.cargo/bin/agent-resources.exe'),'run','--id','coaptic-core-reusable','--directory',str(repo),'--','cargo',*args]
 with (r/(name+'.log')).open('wb') as log:p=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 results[index]={'name':name,'command':cmd,'exit_code':p.returncode,'source':'4bf07388b8454d75acb3c010f5e38443ca3b2417'}
 (r/'focused-checks.json').write_text(json.dumps(results,indent=2)+'\n');print(results[index],flush=True)
 if p.returncode:raise SystemExit(p.returncode)

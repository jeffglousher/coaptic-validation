
D:\CoapticCurrent\replay-shared-dispatch-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009e3f0:     	pushq	%rbp
14009e3f1:     	pushq	%r15
14009e3f3:     	pushq	%r14
14009e3f5:     	pushq	%r13
14009e3f7:     	pushq	%r12
14009e3f9:     	pushq	%rsi
14009e3fa:     	pushq	%rdi
14009e3fb:     	pushq	%rbx
14009e3fc:     	subq	$0x218, %rsp            # imm = 0x218
14009e403:     	leaq	0x80(%rsp), %rbp
14009e40b:     	movaps	%xmm6, 0x180(%rbp)
14009e412:     	leaq	0x3f7f0(%rcx), %rsi
14009e419:     	leaq	0x3f818(%rcx), %r8
14009e420:     	movl	$0x40, %r11d
14009e426:     	xorl	%eax, %eax
14009e428:     	movl	$0x1, %r9d
14009e42e:     	xorl	%r10d, %r10d
14009e431:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009e438:     	addq	%r8, %rdi
14009e43b:     	nopl	(%rax,%rax)
14009e440:     	cmpb	$0x2, -0xe(%rdi)
14009e444:     	jne	0x14009e460 <.text+0x9d460>
14009e446:     	incq	%r10
14009e449:     	addq	$0x130, %rdi            # imm = 0x130
14009e450:     	cmpq	%r10, %r11
14009e453:     	jne	0x14009e440 <.text+0x9d440>
14009e455:     	jmp	0x14009e4a5 <.text+0x9d4a5>
14009e457:     	nopw	(%rax,%rax)
14009e460:     	movq	-0x8(%rdi), %r11
14009e464:     	cmpb	$0x3, (%rdi)
14009e467:     	setne	%bl
14009e46a:     	testq	%r11, %r11
14009e46d:     	sete	%dil
14009e471:     	orb	%bl, %dil
14009e474:     	cmpq	%r14, %r11
14009e477:     	setae	%bl
14009e47a:     	andb	%al, %bl
14009e47c:     	testb	%dil, %dil
14009e47f:     	cmoveq	%r9, %rax
14009e483:     	orb	%dil, %bl
14009e486:     	cmoveq	%r10, %rdx
14009e48a:     	cmoveq	%r11, %r14
14009e48e:     	incq	%r10
14009e491:     	cmpq	$0x41, %r10
14009e495:     	movl	$0x40, %r11d
14009e49b:     	cmovaeq	%r10, %r11
14009e49f:     	cmpq	$0x3f, %r10
14009e4a3:     	jbe	0x14009e431 <.text+0x9d431>
14009e4a5:     	testb	$0x1, %al
14009e4a7:     	je	0x14009e61f <.text+0x9d61f>
14009e4ad:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009e4b4:     	movzbl	0x1a(%rsi,%rax), %r15d
14009e4ba:     	cmpb	$0x2, %r15b
14009e4be:     	je	0x14009e61f <.text+0x9d61f>
14009e4c4:     	addq	%rsi, %rax
14009e4c7:     	cmpb	$0x3, 0x28(%rax)
14009e4cb:     	jne	0x14009e61f <.text+0x9d61f>
14009e4d1:     	movq	0x30(%rax), %r8
14009e4d5:     	movq	(%rax), %rdx
14009e4d8:     	movq	%rdx, 0x168(%rbp)
14009e4df:     	movq	0x8(%rax), %rdx
14009e4e3:     	movq	%rdx, 0x170(%rbp)
14009e4ea:     	movl	0x10(%rax), %edi
14009e4ed:     	movl	0x14(%rax), %edx
14009e4f0:     	movl	%edx, 0x178(%rbp)
14009e4f6:     	movzwl	0x18(%rax), %edx
14009e4fa:     	movw	%dx, 0x17c(%rbp)
14009e501:     	movzbl	0x1b(%rax), %edx
14009e505:     	movb	%dl, 0x17f(%rbp)
14009e50b:     	movss	0x1c(%rax), %xmm6
14009e510:     	movzwl	0x1c(%rax), %eax
14009e514:     	movzwl	%ax, %edx
14009e517:     	cmpq	$0x1f, %r8
14009e51b:     	ja	0x14009e570 <.text+0x9d570>
14009e51d:     	leaq	0x326f0(%rcx), %r9
14009e524:     	cmpb	$0x1, (%r9,%r8)
14009e529:     	jne	0x14009e570 <.text+0x9d570>
14009e52b:     	cmpb	$0x0, 0x32710(%rcx,%r8)
14009e534:     	jne	0x14009e570 <.text+0x9d570>
14009e536:     	movb	$0x0, 0x326f0(%rcx,%r8)
14009e53f:     	decq	0x32738(%rcx)
14009e546:     	movq	$0x0, 0x3e5c0(%rcx,%r8,8)
14009e552:     	leaq	(%r8,%r8,8), %r10
14009e556:     	leaq	(%r10,%r10,2), %r10
14009e55a:     	addq	%r8, %r10
14009e55d:     	movb	$0x2, 0x36a(%r9,%r10)
14009e566:     	leaq	(%r8,%r8,2), %r8
14009e56a:     	movb	$0x2, 0x5d(%r9,%r8,8)
14009e570:     	leaq	0x443f0(%rcx), %r12
14009e577:     	addl	$0x2, %edx
14009e57a:     	leaq	0x3f80c(%rcx), %r9
14009e581:     	xorl	%r10d, %r10d
14009e584:     	xorl	%r8d, %r8d
14009e587:     	jmp	0x14009e5a7 <.text+0x9d5a7>
14009e589:     	nopl	(%rax)
14009e590:     	movq	%r13, %r11
14009e593:     	incq	%r10
14009e596:     	addq	$0x130, %r9             # imm = 0x130
14009e59d:     	cmpq	$0x40, %r10
14009e5a1:     	je	0x14009e63c <.text+0x9d63c>
14009e5a7:     	movq	%r11, %r13
14009e5aa:     	cmpl	%edx, (%r12,%r10,4)
14009e5ae:     	jne	0x14009e590 <.text+0x9d590>
14009e5b0:     	movzbl	-0x2(%r9), %r11d
14009e5b5:     	cmpb	$0x2, %r11b
14009e5b9:     	je	0x14009e590 <.text+0x9d590>
14009e5bb:     	cmpb	%r15b, %r11b
14009e5be:     	jne	0x14009e590 <.text+0x9d590>
14009e5c0:     	cmpw	%ax, (%r9)
14009e5c4:     	jne	0x14009e590 <.text+0x9d590>
14009e5c6:     	cmpl	%edi, -0xc(%r9)
14009e5ca:     	jne	0x14009e590 <.text+0x9d590>
14009e5cc:     	movl	0x178(%rbp), %r11d
14009e5d3:     	cmpl	%r11d, -0x8(%r9)
14009e5d7:     	jne	0x14009e590 <.text+0x9d590>
14009e5d9:     	movzwl	0x17c(%rbp), %r11d
14009e5e1:     	cmpw	%r11w, -0x4(%r9)
14009e5e6:     	jne	0x14009e590 <.text+0x9d590>
14009e5e8:     	movq	-0x1c(%r9), %r11
14009e5ec:     	xorq	0x168(%rbp), %r11
14009e5f3:     	movq	-0x14(%r9), %rbx
14009e5f7:     	xorq	0x170(%rbp), %rbx
14009e5fe:     	orq	%r11, %rbx
14009e601:     	jne	0x14009e590 <.text+0x9d590>
14009e603:     	movq	%r10, %r11
14009e606:     	cmpq	$0x1, %r8
14009e60a:     	movl	$0x1, %r8d
14009e610:     	jne	0x14009e593 <.text+0x9d593>
14009e612:     	movb	$0x1, %bl
14009e614:     	movq	%r13, %r11
14009e617:     	cmpq	$0x3f, %r13
14009e61b:     	jbe	0x14009e64a <.text+0x9d64a>
14009e61d:     	jmp	0x14009e670 <.text+0x9d670>
14009e61f:     	xorl	%eax, %eax
14009e621:     	movaps	0x180(%rbp), %xmm6
14009e628:     	addq	$0x218, %rsp            # imm = 0x218
14009e62f:     	popq	%rbx
14009e630:     	popq	%rdi
14009e631:     	popq	%rsi
14009e632:     	popq	%r12
14009e634:     	popq	%r13
14009e636:     	popq	%r14
14009e638:     	popq	%r15
14009e63a:     	popq	%rbp
14009e63b:     	retq
14009e63c:     	cmpq	$0x40, %r11
14009e640:     	setb	%dl
14009e643:     	xorl	%ebx, %ebx
14009e645:     	testb	%dl, %r8b
14009e648:     	je	0x14009e670 <.text+0x9d670>
14009e64a:     	cmpl	$0x0, (%r12,%r11,4)
14009e64f:     	je	0x14009e670 <.text+0x9d670>
14009e651:     	movl	$0x0, 0x443f0(%rcx,%r11,4)
14009e65d:     	decq	0x444f8(%rcx)
14009e664:     	imulq	$0x130, %r11, %rdx      # imm = 0x130
14009e66b:     	movb	$0x2, 0x1a(%rsi,%rdx)
14009e670:     	pxor	%xmm0, %xmm0
14009e674:     	movdqa	%xmm0, 0x150(%rbp)
14009e67c:     	movb	$0x0, 0x132(%rbp)
14009e683:     	movw	%ax, 0x130(%rbp)
14009e68a:     	leaq	0x133(%rbp), %rdx
14009e691:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009e69a:     	movq	$0x0, 0x133(%rbp)
14009e6a5:     	movq	$0x8, 0x110(%rbp)
14009e6b0:     	movq	$0x0, 0x118(%rbp)
14009e6bb:     	movq	$0x1, 0x120(%rbp)
14009e6c6:     	movq	$0x0, 0x128(%rbp)
14009e6d1:     	movq	%rdx, 0x30(%rsp)
14009e6d6:     	movw	%ax, 0x28(%rsp)
14009e6db:     	movq	$0x0, 0x58(%rsp)
14009e6e4:     	movq	$0x1, 0x50(%rsp)
14009e6ed:     	movq	$0x8, 0x48(%rsp)
14009e6f6:     	movq	$0x8, 0x40(%rsp)
14009e6ff:     	movq	$0x0, 0x38(%rsp)
14009e708:     	movb	$0x0, 0x20(%rsp)
14009e70d:     	leaq	0x140(%rbp), %rax
14009e714:     	leaq	0x150(%rbp), %rdx
14009e71b:     	movl	$0x10, %r8d
14009e721:     	movq	%rcx, %r13
14009e724:     	movq	%rax, %rcx
14009e727:     	movb	$0x2, %r9b
14009e72a:     	callq	0x140005590 <.text+0x4590>
14009e72f:     	movq	%r13, %rax
14009e732:     	movq	0x148(%rbp), %r13
14009e739:     	cmpq	$0x11, %r13
14009e73d:     	setae	%cl
14009e740:     	orb	%bl, %cl
14009e742:     	orb	0x140(%rbp), %cl
14009e748:     	testb	$0x1, %cl
14009e74b:     	jne	0x14009e757 <.text+0x9d757>
14009e74d:     	cmpq	$0x40, 0x444f8(%rax)
14009e755:     	jne	0x14009e75e <.text+0x9d75e>
14009e757:     	movb	$0x1, %al
14009e759:     	jmp	0x14009e621 <.text+0x9d621>
14009e75e:     	movq	0x444f0(%rax), %rbx
14009e765:     	cmpq	$0x3f, %rbx
14009e769:     	ja	0x14009ea09 <.text+0x9da09>
14009e76f:     	cmpl	$0x0, (%r12,%rbx,4)
14009e774:     	je	0x14009e7e0 <.text+0x9d7e0>
14009e776:     	leaq	(,%rbx,4), %rdx
14009e77e:     	leaq	(%r12,%rbx,4), %rcx
14009e782:     	xorl	%r8d, %r8d
14009e785:     	movq	%rdx, %r9
14009e788:     	nopl	(%rax,%rax)
14009e790:     	cmpl	$0x0, (%r12,%r9)
14009e795:     	je	0x14009e7d3 <.text+0x9d7d3>
14009e797:     	addq	$0x4, %r9
14009e79b:     	decq	%r8
14009e79e:     	cmpq	$0x100, %r9             # imm = 0x100
14009e7a5:     	jne	0x14009e790 <.text+0x9d790>
14009e7a7:     	testq	%rbx, %rbx
14009e7aa:     	je	0x14009e757 <.text+0x9d757>
14009e7ac:     	addq	$-0x4, %rdx
14009e7b0:     	cmpq	$0xc, %rdx
14009e7b4:     	jae	0x14009e94d <.text+0x9d94d>
14009e7ba:     	xorl	%ebx, %ebx
14009e7bc:     	movq	%r12, %r9
14009e7bf:     	cmpl	$0x0, (%r9)
14009e7c3:     	je	0x14009e7d6 <.text+0x9d7d6>
14009e7c5:     	addq	$0x4, %r9
14009e7c9:     	incq	%rbx
14009e7cc:     	cmpq	%rcx, %r9
14009e7cf:     	jne	0x14009e7bf <.text+0x9d7bf>
14009e7d1:     	jmp	0x14009e757 <.text+0x9d757>
14009e7d3:     	subq	%r8, %rbx
14009e7d6:     	cmpq	$0x40, %rbx
14009e7da:     	jae	0x14009e9f3 <.text+0x9d9f3>
14009e7e0:     	movl	$0x1, 0x443f0(%rax,%rbx,4)
14009e7eb:     	incq	0x444f8(%rax)
14009e7f2:     	leaq	0x1(%rbx), %rcx
14009e7f6:     	xorl	%edx, %edx
14009e7f8:     	cmpq	$0x40, %rcx
14009e7fc:     	cmovneq	%rcx, %rdx
14009e800:     	movq	%rdx, 0x444f0(%rax)
14009e807:     	movq	0x170(%rbp), %rax
14009e80e:     	movq	%rax, -0x18(%rbp)
14009e812:     	movq	0x168(%rbp), %rax
14009e819:     	movq	%rax, -0x20(%rbp)
14009e81d:     	movl	%edi, -0x10(%rbp)
14009e820:     	movl	0x178(%rbp), %eax
14009e826:     	movl	%eax, -0xc(%rbp)
14009e829:     	movzwl	0x17c(%rbp), %eax
14009e830:     	movw	%ax, -0x8(%rbp)
14009e834:     	movb	%r15b, -0x6(%rbp)
14009e838:     	movzbl	0x17f(%rbp), %eax
14009e83f:     	movb	%al, -0x5(%rbp)
14009e842:     	movss	%xmm6, -0x4(%rbp)
14009e847:     	movq	%r14, (%rbp)
14009e84b:     	testq	%r13, %r13
14009e84e:     	je	0x14009e8b2 <.text+0x9d8b2>
14009e850:     	movb	$0x1, 0x8(%rbp)
14009e854:     	movb	%r13b, 0x9(%rbp)
14009e858:     	leaq	0xa(%rbp), %r14
14009e85c:     	movl	$0x80, %r8d
14009e862:     	subq	%r13, %r8
14009e865:     	leaq	0xa(,%r13), %rcx
14009e86d:     	addq	%rbp, %rcx
14009e870:     	xorl	%edx, %edx
14009e872:     	callq	0x140252002 <.text+0x251002>
14009e877:     	leaq	0x150(%rbp), %rdx
14009e87e:     	movq	%r14, %rcx
14009e881:     	movq	%r13, %r8
14009e884:     	callq	0x140251ff0 <.text+0x250ff0>
14009e889:     	movzwl	-0x4(%rbp), %eax
14009e88d:     	addl	$0x2, %eax
14009e890:     	movl	%eax, (%r12,%rbx,4)
14009e894:     	imulq	$0x130, %rbx, %rax      # imm = 0x130
14009e89b:     	addq	%rax, %rsi
14009e89e:     	movzbl	0x8(%rbp), %eax
14009e8a2:     	leaq	0x1d29a7(%rip), %rcx    # 0x140271250
14009e8a9:     	movslq	(%rcx,%rax,4), %rax
14009e8ad:     	addq	%rcx, %rax
14009e8b0:     	jmpq	*%rax
14009e8b2:     	movb	$0x0, 0x8(%rbp)
14009e8b6:     	movzwl	-0x4(%rbp), %eax
14009e8ba:     	addl	$0x2, %eax
14009e8bd:     	movl	%eax, (%r12,%rbx,4)
14009e8c1:     	imulq	$0x130, %rbx, %rax      # imm = 0x130
14009e8c8:     	addq	%rax, %rsi
14009e8cb:     	movzbl	0x8(%rbp), %eax
14009e8cf:     	leaq	0x1d297a(%rip), %rcx    # 0x140271250
14009e8d6:     	movslq	(%rcx,%rax,4), %rax
14009e8da:     	addq	%rcx, %rax
14009e8dd:     	jmpq	*%rax
14009e8df:     	movdqa	-0x20(%rbp), %xmm0
14009e8e4:     	movdqa	-0x10(%rbp), %xmm1
14009e8e9:     	movdqu	%xmm1, 0x10(%rsi)
14009e8ee:     	movdqu	%xmm0, (%rsi)
14009e8f2:     	movb	$0x0, 0x28(%rsi)
14009e8f6:     	movq	(%rbp), %rax
14009e8fa:     	movq	%rax, 0x20(%rsi)
14009e8fe:     	jmp	0x14009e757 <.text+0x9d757>
14009e903:     	leaq	-0x20(%rbp), %rdx
14009e907:     	movl	$0x130, %r8d            # imm = 0x130
14009e90d:     	movq	%rsi, %rcx
14009e910:     	callq	0x140251ff0 <.text+0x250ff0>
14009e915:     	jmp	0x14009e757 <.text+0x9d757>
14009e91a:     	movq	(%rbp), %r8
14009e91e:     	movq	0x10(%rbp), %r9
14009e922:     	leaq	-0x20(%rbp), %rdx
14009e926:     	movq	%rsi, %rcx
14009e929:     	callq	0x14000b2d0 <.text+0xa2d0>
14009e92e:     	jmp	0x14009e757 <.text+0x9d757>
14009e933:     	leaq	0xa(%rbp), %r8
14009e937:     	movzbl	0x9(%rbp), %r9d
14009e93c:     	leaq	-0x20(%rbp), %rdx
14009e940:     	movq	%rsi, %rcx
14009e943:     	callq	0x14000b1c0 <.text+0xa1c0>
14009e948:     	jmp	0x14009e757 <.text+0x9d757>
14009e94d:     	shrq	$0x2, %rdx
14009e951:     	incq	%rdx
14009e954:     	movq	%rdx, %rbx
14009e957:     	andq	$-0x4, %rbx
14009e95b:     	leaq	(%r12,%rbx,4), %r9
14009e95f:     	xorl	%r8d, %r8d
14009e962:     	pxor	%xmm1, %xmm1
14009e966:     	movdqu	(%r12,%r8,4), %xmm0
14009e96c:     	movdqa	%xmm0, %xmm2
14009e970:     	pcmpeqd	%xmm1, %xmm2
14009e974:     	movmskps	%xmm2, %r10d
14009e978:     	testl	%r10d, %r10d
14009e97b:     	jne	0x14009e994 <.text+0x9d994>
14009e97d:     	addq	$0x4, %r8
14009e981:     	cmpq	%r8, %rbx
14009e984:     	jne	0x14009e966 <.text+0x9d966>
14009e986:     	cmpq	%rbx, %rdx
14009e989:     	jne	0x14009e7bf <.text+0x9d7bf>
14009e98f:     	jmp	0x14009e757 <.text+0x9d757>
14009e994:     	pxor	%xmm1, %xmm1
14009e998:     	pcmpeqd	%xmm1, %xmm0
14009e99c:     	pand	0x1c63ec(%rip), %xmm0   # 0x140264d90
14009e9a4:     	movdqa	0x1c42e4(%rip), %xmm1   # 0x140262c90
14009e9ac:     	movdqa	%xmm0, %xmm2
14009e9b0:     	por	%xmm1, %xmm2
14009e9b4:     	pshufd	$0xee, %xmm0, %xmm3     # xmm3 = xmm0[2,3,2,3]
14009e9b9:     	por	%xmm3, %xmm1
14009e9bd:     	pcmpgtd	%xmm1, %xmm2
14009e9c1:     	pand	%xmm2, %xmm0
14009e9c5:     	pandn	%xmm3, %xmm2
14009e9c9:     	por	%xmm0, %xmm2
14009e9cd:     	movd	%xmm2, %ecx
14009e9d1:     	pshufd	$0x55, %xmm2, %xmm0     # xmm0 = xmm2[1,1,1,1]
14009e9d6:     	movd	%xmm0, %edx
14009e9da:     	cmpl	%edx, %ecx
14009e9dc:     	cmoval	%ecx, %edx
14009e9df:     	movl	$0x4, %ebx
14009e9e4:     	subl	%edx, %ebx
14009e9e6:     	addq	%r8, %rbx
14009e9e9:     	cmpq	$0x40, %rbx
14009e9ed:     	jb	0x14009e7e0 <.text+0x9d7e0>
14009e9f3:     	leaq	0x1cf3be(%rip), %r8     # 0x14026ddb8
14009e9fa:     	movl	$0x40, %edx
14009e9ff:     	movq	%rbx, %rcx
14009ea02:     	callq	0x140252873 <.text+0x251873>
14009ea07:     	ud2
14009ea09:     	leaq	0x1cf390(%rip), %r8     # 0x14026dda0
14009ea10:     	movl	$0x40, %edx
14009ea15:     	movq	%rbx, %rcx
14009ea18:     	callq	0x140252873 <.text+0x251873>
14009ea1d:     	ud2

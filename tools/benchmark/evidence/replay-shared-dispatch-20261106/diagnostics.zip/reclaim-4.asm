
D:\CoapticCurrent\replay-shared-dispatch-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009ea20:     	pushq	%rbp
14009ea21:     	pushq	%r15
14009ea23:     	pushq	%r14
14009ea25:     	pushq	%r13
14009ea27:     	pushq	%r12
14009ea29:     	pushq	%rsi
14009ea2a:     	pushq	%rdi
14009ea2b:     	pushq	%rbx
14009ea2c:     	subq	$0x218, %rsp            # imm = 0x218
14009ea33:     	leaq	0x80(%rsp), %rbp
14009ea3b:     	movaps	%xmm6, 0x180(%rbp)
14009ea42:     	movq	0xe8(%rcx), %r8
14009ea49:     	testq	%r8, %r8
14009ea4c:     	je	0x14009ed39 <.text+0x9dd39>
14009ea52:     	leaq	0xc0(%rcx), %r13
14009ea59:     	leaq	0xd8(%rcx), %rdi
14009ea60:     	movq	0xc8(%rcx), %rbx
14009ea67:     	movq	0xd0(%rcx), %r10
14009ea6e:     	leaq	0x28(%rbx), %rax
14009ea72:     	xorl	%r11d, %r11d
14009ea75:     	xorl	%r15d, %r15d
14009ea78:     	imulq	$0x130, %r15, %r12      # imm = 0x130
14009ea7f:     	addq	%rax, %r12
14009ea82:     	jmp	0x14009ea9f <.text+0x9da9f>
14009ea84:     	nopw	%cs:(%rax,%rax)
14009ea90:     	incq	%r15
14009ea93:     	addq	$0x130, %r12            # imm = 0x130
14009ea9a:     	cmpq	%r8, %r15
14009ea9d:     	jae	0x14009eb0a <.text+0x9db0a>
14009ea9f:     	cmpq	%r10, %r15
14009eaa2:     	jae	0x14009ea90 <.text+0x9da90>
14009eaa4:     	cmpb	$0x2, -0xe(%r12)
14009eaaa:     	je	0x14009ea90 <.text+0x9da90>
14009eaac:     	movq	%r13, %rdi
14009eaaf:     	movq	-0x8(%r12), %r13
14009eab4:     	cmpb	$0x3, (%r12)
14009eab9:     	setne	%r12b
14009eabd:     	testq	%r13, %r13
14009eac0:     	sete	%sil
14009eac4:     	orb	%r12b, %sil
14009eac7:     	cmpq	%r14, %r13
14009eaca:     	setae	%r12b
14009eace:     	andb	%r11b, %r12b
14009ead1:     	testb	%sil, %sil
14009ead4:     	movq	%r14, %rdx
14009ead7:     	movq	%rax, %r14
14009eada:     	movl	$0x1, %eax
14009eadf:     	cmoveq	%rax, %r11
14009eae3:     	movq	%r14, %rax
14009eae6:     	movq	%rdx, %r14
14009eae9:     	orb	%sil, %r12b
14009eaec:     	cmoveq	%r15, %r9
14009eaf0:     	cmoveq	%r13, %r14
14009eaf4:     	movq	%rdi, %r13
14009eaf7:     	leaq	0xd8(%rcx), %rdi
14009eafe:     	incq	%r15
14009eb01:     	cmpq	%r8, %r15
14009eb04:     	jb	0x14009ea78 <.text+0x9da78>
14009eb0a:     	xorl	%eax, %eax
14009eb0c:     	cmpq	$0x1, %r11
14009eb10:     	jne	0x14009ed3b <.text+0x9dd3b>
14009eb16:     	cmpq	%r10, %r9
14009eb19:     	jae	0x14009ed3b <.text+0x9dd3b>
14009eb1f:     	imulq	$0x130, %r9, %rax       # imm = 0x130
14009eb26:     	movzbl	0x1a(%rbx,%rax), %r15d
14009eb2c:     	cmpb	$0x2, %r15b
14009eb30:     	je	0x14009ed39 <.text+0x9dd39>
14009eb36:     	addq	%rax, %rbx
14009eb39:     	cmpb	$0x3, 0x28(%rbx)
14009eb3d:     	jne	0x14009ed39 <.text+0x9dd39>
14009eb43:     	movq	0x30(%rbx), %r10
14009eb47:     	movups	(%rbx), %xmm0
14009eb4a:     	movups	0xa(%rbx), %xmm1
14009eb4e:     	movups	%xmm1, 0x11a(%rbp)
14009eb55:     	movaps	%xmm0, 0x110(%rbp)
14009eb5c:     	movzbl	0x1b(%rbx), %r12d
14009eb61:     	movss	0x1c(%rbx), %xmm6
14009eb66:     	movzwl	0x1c(%rbx), %eax
14009eb6a:     	cmpq	0x88(%rcx), %r10
14009eb71:     	jae	0x14009ebc7 <.text+0x9dbc7>
14009eb73:     	movq	0x80(%rcx), %r11
14009eb7a:     	cmpb	$0x1, (%r11,%r10)
14009eb7f:     	jne	0x14009ebc7 <.text+0x9dbc7>
14009eb81:     	cmpq	0xa0(%rcx), %r10
14009eb88:     	jae	0x14009eb98 <.text+0x9db98>
14009eb8a:     	movq	0x98(%rcx), %rsi
14009eb91:     	cmpb	$0x0, (%rsi,%r10)
14009eb96:     	jne	0x14009ebc7 <.text+0x9dbc7>
14009eb98:     	movb	$0x0, (%r11,%r10)
14009eb9d:     	decq	0xb0(%rcx)
14009eba4:     	cmpq	0x70(%rcx), %r10
14009eba8:     	jae	0x14009ebc7 <.text+0x9dbc7>
14009ebaa:     	movq	0x68(%rcx), %r11
14009ebae:     	imulq	$0x58, %r10, %r10
14009ebb2:     	movq	$0x0, 0x30(%r11,%r10)
14009ebbb:     	movb	$0x2, 0x52(%r11,%r10)
14009ebc1:     	movb	$0x2, 0x25(%r11,%r10)
14009ebc7:     	cmpq	%r8, %r9
14009ebca:     	jae	0x14009ebed <.text+0x9dbed>
14009ebcc:     	movq	0xe0(%rcx), %r8
14009ebd3:     	cmpl	$0x0, (%r8,%r9,4)
14009ebd8:     	je	0x14009ebed <.text+0x9dbed>
14009ebda:     	movl	$0x0, (%r8,%r9,4)
14009ebe2:     	decq	0xf8(%rcx)
14009ebe9:     	movb	$0x2, 0x1a(%rbx)
14009ebed:     	xorps	%xmm0, %xmm0
14009ebf0:     	movaps	%xmm0, 0x170(%rbp)
14009ebf7:     	movb	$0x0, 0x152(%rbp)
14009ebfe:     	movw	%ax, 0x150(%rbp)
14009ec05:     	leaq	0x153(%rbp), %rcx
14009ec0c:     	movw	$0x200, 0x15b(%rbp)     # imm = 0x200
14009ec15:     	movq	$0x0, 0x153(%rbp)
14009ec20:     	movq	$0x8, 0x130(%rbp)
14009ec2b:     	movq	$0x0, 0x138(%rbp)
14009ec36:     	movq	$0x1, 0x140(%rbp)
14009ec41:     	movq	$0x0, 0x148(%rbp)
14009ec4c:     	movq	%rcx, 0x30(%rsp)
14009ec51:     	movw	%ax, 0x28(%rsp)
14009ec56:     	movq	$0x0, 0x58(%rsp)
14009ec5f:     	movq	$0x1, 0x50(%rsp)
14009ec68:     	movq	$0x8, 0x48(%rsp)
14009ec71:     	movq	$0x8, 0x40(%rsp)
14009ec7a:     	movq	$0x0, 0x38(%rsp)
14009ec83:     	movb	$0x0, 0x20(%rsp)
14009ec88:     	leaq	0x160(%rbp), %rcx
14009ec8f:     	leaq	0x170(%rbp), %rdx
14009ec96:     	movl	$0x10, %r8d
14009ec9c:     	movb	$0x2, %r9b
14009ec9f:     	callq	0x140005590 <.text+0x4590>
14009eca4:     	movq	0x168(%rbp), %rbx
14009ecab:     	cmpq	$0x11, %rbx
14009ecaf:     	setae	%al
14009ecb2:     	orb	0x160(%rbp), %al
14009ecb8:     	jne	0x14009ed66 <.text+0x9dd66>
14009ecbe:     	movq	%rdi, %rcx
14009ecc1:     	callq	0x140219dd0 <.text+0x218dd0>
14009ecc6:     	cmpq	$0x1, %rax
14009ecca:     	jne	0x14009ed66 <.text+0x9dd66>
14009ecd0:     	movups	0x11a(%rbp), %xmm0
14009ecd7:     	movups	%xmm0, -0x16(%rbp)
14009ecdb:     	movaps	0x110(%rbp), %xmm0
14009ece2:     	movaps	%xmm0, -0x20(%rbp)
14009ece6:     	movb	%r15b, -0x6(%rbp)
14009ecea:     	movb	%r12b, -0x5(%rbp)
14009ecee:     	movss	%xmm6, -0x4(%rbp)
14009ecf3:     	movq	%r14, (%rbp)
14009ecf7:     	testq	%rbx, %rbx
14009ecfa:     	je	0x14009ed56 <.text+0x9dd56>
14009ecfc:     	movb	$0x1, 0x8(%rbp)
14009ed00:     	movb	%bl, 0x9(%rbp)
14009ed03:     	leaq	0xa(%rbp), %rdi
14009ed07:     	movl	$0x80, %r8d
14009ed0d:     	subq	%rbx, %r8
14009ed10:     	leaq	(%rbx,%rbp), %rcx
14009ed14:     	addq	$0xa, %rcx
14009ed18:     	movq	%rdx, %r14
14009ed1b:     	xorl	%edx, %edx
14009ed1d:     	callq	0x140252002 <.text+0x251002>
14009ed22:     	leaq	0x170(%rbp), %rdx
14009ed29:     	movq	%rdi, %rcx
14009ed2c:     	movq	%rbx, %r8
14009ed2f:     	callq	0x140251ff0 <.text+0x250ff0>
14009ed34:     	movq	%r14, %rdx
14009ed37:     	jmp	0x14009ed5a <.text+0x9dd5a>
14009ed39:     	xorl	%eax, %eax
14009ed3b:     	movaps	0x180(%rbp), %xmm6
14009ed42:     	addq	$0x218, %rsp            # imm = 0x218
14009ed49:     	popq	%rbx
14009ed4a:     	popq	%rdi
14009ed4b:     	popq	%rsi
14009ed4c:     	popq	%r12
14009ed4e:     	popq	%r13
14009ed50:     	popq	%r14
14009ed52:     	popq	%r15
14009ed54:     	popq	%rbp
14009ed55:     	retq
14009ed56:     	movb	$0x0, 0x8(%rbp)
14009ed5a:     	leaq	-0x20(%rbp), %r8
14009ed5e:     	movq	%r13, %rcx
14009ed61:     	callq	0x14000b620 <.text+0xa620>
14009ed66:     	movb	$0x1, %al
14009ed68:     	jmp	0x14009ed3b <.text+0x9dd3b>


D:\CoapticCurrent\replay-shared-dispatch-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009dc60:     	pushq	%rbp
14009dc61:     	pushq	%r15
14009dc63:     	pushq	%r14
14009dc65:     	pushq	%r13
14009dc67:     	pushq	%r12
14009dc69:     	pushq	%rsi
14009dc6a:     	pushq	%rdi
14009dc6b:     	pushq	%rbx
14009dc6c:     	subq	$0x218, %rsp            # imm = 0x218
14009dc73:     	leaq	0x80(%rsp), %rbp
14009dc7b:     	movaps	%xmm6, 0x180(%rbp)
14009dc82:     	leaq	0x3f10(%rcx), %rsi
14009dc89:     	leaq	0x3f38(%rcx), %r8
14009dc90:     	movl	$0x4, %r11d
14009dc96:     	xorl	%eax, %eax
14009dc98:     	movl	$0x1, %r9d
14009dc9e:     	xorl	%r10d, %r10d
14009dca1:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009dca8:     	addq	%r8, %rdi
14009dcab:     	nopl	(%rax,%rax)
14009dcb0:     	cmpb	$0x2, -0xe(%rdi)
14009dcb4:     	jne	0x14009dcd0 <.text+0x9ccd0>
14009dcb6:     	incq	%r10
14009dcb9:     	addq	$0x130, %rdi            # imm = 0x130
14009dcc0:     	cmpq	%r10, %r11
14009dcc3:     	jne	0x14009dcb0 <.text+0x9ccb0>
14009dcc5:     	jmp	0x14009dd15 <.text+0x9cd15>
14009dcc7:     	nopw	(%rax,%rax)
14009dcd0:     	movq	-0x8(%rdi), %r11
14009dcd4:     	cmpb	$0x3, (%rdi)
14009dcd7:     	setne	%bl
14009dcda:     	testq	%r11, %r11
14009dcdd:     	sete	%dil
14009dce1:     	orb	%bl, %dil
14009dce4:     	cmpq	%r14, %r11
14009dce7:     	setae	%bl
14009dcea:     	andb	%al, %bl
14009dcec:     	testb	%dil, %dil
14009dcef:     	cmoveq	%r9, %rax
14009dcf3:     	orb	%dil, %bl
14009dcf6:     	cmoveq	%r10, %rdx
14009dcfa:     	cmoveq	%r11, %r14
14009dcfe:     	incq	%r10
14009dd01:     	cmpq	$0x5, %r10
14009dd05:     	movl	$0x4, %r11d
14009dd0b:     	cmovaeq	%r10, %r11
14009dd0f:     	cmpq	$0x3, %r10
14009dd13:     	jbe	0x14009dca1 <.text+0x9cca1>
14009dd15:     	testb	$0x1, %al
14009dd17:     	je	0x14009de11 <.text+0x9ce11>
14009dd1d:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009dd24:     	movzbl	0x1a(%rsi,%rax), %r15d
14009dd2a:     	cmpb	$0x2, %r15b
14009dd2e:     	je	0x14009de11 <.text+0x9ce11>
14009dd34:     	addq	%rsi, %rax
14009dd37:     	cmpb	$0x3, 0x28(%rax)
14009dd3b:     	jne	0x14009de11 <.text+0x9ce11>
14009dd41:     	movq	0x30(%rax), %r8
14009dd45:     	movq	(%rax), %rdx
14009dd48:     	movq	%rdx, 0x168(%rbp)
14009dd4f:     	movq	0x8(%rax), %rdx
14009dd53:     	movq	%rdx, 0x170(%rbp)
14009dd5a:     	movl	0x10(%rax), %ebx
14009dd5d:     	movl	0x14(%rax), %r12d
14009dd61:     	movzwl	0x18(%rax), %edi
14009dd65:     	movzbl	0x1b(%rax), %edx
14009dd69:     	movb	%dl, 0x17f(%rbp)
14009dd6f:     	movss	0x1c(%rax), %xmm6
14009dd74:     	movzwl	0x1c(%rax), %eax
14009dd78:     	movzwl	%ax, %edx
14009dd7b:     	cmpq	$0x1, %r8
14009dd7f:     	ja	0x14009dddb <.text+0x9cddb>
14009dd81:     	cmpb	$0x1, 0x3f08(%rcx,%r8)
14009dd8a:     	jne	0x14009dddb <.text+0x9cddb>
14009dd8c:     	cmpb	$0x0, 0x3f0a(%rcx,%r8)
14009dd95:     	jne	0x14009dddb <.text+0x9cddb>
14009dd97:     	movb	$0x0, 0x3f08(%rcx,%r8)
14009dda0:     	decq	0x3f00(%rcx)
14009dda7:     	leaq	0x3580(%rcx), %r9
14009ddae:     	movq	$0x0, 0x3e80(%rcx,%r8,8)
14009ddba:     	leaq	(%r8,%r8,8), %r10
14009ddbe:     	leaq	(%r10,%r10,2), %r10
14009ddc2:     	addq	%r8, %r10
14009ddc5:     	movb	$0x2, 0x95a(%r9,%r10)
14009ddce:     	leaq	(%r8,%r8,2), %r8
14009ddd2:     	movb	$0x2, 0x91d(%r9,%r8,8)
14009dddb:     	addl	$0x2, %edx
14009ddde:     	movb	$0x1, %r9b
14009dde1:     	cmpl	%edx, 0x43d0(%rcx)
14009dde7:     	jne	0x14009ddf7 <.text+0x9cdf7>
14009dde9:     	movzbl	0x3f2a(%rcx), %r8d
14009ddf1:     	cmpb	$0x2, %r8b
14009ddf5:     	jne	0x14009de2e <.text+0x9ce2e>
14009ddf7:     	xorl	%r8d, %r8d
14009ddfa:     	cmpl	%edx, 0x43d4(%rcx)
14009de00:     	movl	%ebx, 0x178(%rbp)
14009de06:     	jne	0x14009debd <.text+0x9cebd>
14009de0c:     	jmp	0x14009deab <.text+0x9ceab>
14009de11:     	xorl	%eax, %eax
14009de13:     	movaps	0x180(%rbp), %xmm6
14009de1a:     	addq	$0x218, %rsp            # imm = 0x218
14009de21:     	popq	%rbx
14009de22:     	popq	%rdi
14009de23:     	popq	%rsi
14009de24:     	popq	%r12
14009de26:     	popq	%r13
14009de28:     	popq	%r14
14009de2a:     	popq	%r15
14009de2c:     	popq	%rbp
14009de2d:     	retq
14009de2e:     	cmpw	%ax, 0x3f2c(%rcx)
14009de35:     	sete	%r9b
14009de39:     	cmpl	%ebx, 0x3f20(%rcx)
14009de3f:     	sete	%r10b
14009de43:     	andb	%r9b, %r10b
14009de46:     	cmpl	%r12d, 0x3f24(%rcx)
14009de4d:     	sete	%r9b
14009de51:     	cmpw	%di, 0x3f28(%rcx)
14009de58:     	sete	%r11b
14009de5c:     	andb	%r9b, %r11b
14009de5f:     	andb	%r10b, %r11b
14009de62:     	cmpb	%r15b, %r8b
14009de65:     	sete	%r8b
14009de69:     	movq	0x3f18(%rcx), %r9
14009de70:     	xorq	0x170(%rbp), %r9
14009de77:     	movq	0x3f10(%rcx), %r10
14009de7e:     	xorq	0x168(%rbp), %r10
14009de85:     	orq	%r9, %r10
14009de88:     	sete	%r9b
14009de8c:     	andb	%r8b, %r9b
14009de8f:     	andb	%r11b, %r9b
14009de92:     	movzbl	%r9b, %r8d
14009de96:     	movl	%r8d, %r9d
14009de99:     	xorb	$0x1, %r9b
14009de9d:     	cmpl	%edx, 0x43d4(%rcx)
14009dea3:     	movl	%ebx, 0x178(%rbp)
14009dea9:     	jne	0x14009debd <.text+0x9cebd>
14009deab:     	movzbl	0x405a(%rcx), %r10d
14009deb3:     	cmpb	$0x2, %r10b
14009deb7:     	jne	0x14009df6e <.text+0x9cf6e>
14009debd:     	xorl	%r9d, %r9d
14009dec0:     	cmpl	%edx, 0x43d8(%rcx)
14009dec6:     	jne	0x14009e014 <.text+0x9d014>
14009decc:     	movzbl	0x418a(%rcx), %r10d
14009ded4:     	cmpb	$0x2, %r10b
14009ded8:     	je	0x14009e014 <.text+0x9d014>
14009dede:     	cmpb	%r15b, %r10b
14009dee1:     	jne	0x14009e014 <.text+0x9d014>
14009dee7:     	cmpw	%ax, 0x418c(%rcx)
14009deee:     	jne	0x14009e014 <.text+0x9d014>
14009def4:     	cmpl	%ebx, 0x4180(%rcx)
14009defa:     	jne	0x14009e014 <.text+0x9d014>
14009df00:     	cmpl	%r12d, 0x4184(%rcx)
14009df07:     	jne	0x14009e014 <.text+0x9d014>
14009df0d:     	cmpw	%di, 0x4188(%rcx)
14009df14:     	jne	0x14009e014 <.text+0x9d014>
14009df1a:     	movq	0x4170(%rcx), %r10
14009df21:     	xorq	0x168(%rbp), %r10
14009df28:     	movq	0x4178(%rcx), %r11
14009df2f:     	xorq	0x170(%rbp), %r11
14009df36:     	orq	%r10, %r11
14009df39:     	jne	0x14009e014 <.text+0x9d014>
14009df3f:     	movl	%r12d, %r13d
14009df42:     	movl	%edi, %r12d
14009df45:     	movb	$0x1, %dil
14009df48:     	testq	%r8, %r8
14009df4b:     	jne	0x14009e0a0 <.text+0x9d0a0>
14009df51:     	movl	$0x1, %r8d
14009df57:     	movl	$0x2, %r9d
14009df5d:     	movl	%r12d, %edi
14009df60:     	movl	%r13d, %r12d
14009df63:     	movl	0x178(%rbp), %ebx
14009df69:     	jmp	0x14009e014 <.text+0x9d014>
14009df6e:     	cmpw	%ax, 0x405c(%rcx)
14009df75:     	setne	%r11b
14009df79:     	cmpl	%ebx, 0x4050(%rcx)
14009df7f:     	setne	%bl
14009df82:     	orb	%r11b, %bl
14009df85:     	movl	%r12d, %r13d
14009df88:     	cmpl	%r12d, 0x4054(%rcx)
14009df8f:     	setne	%r11b
14009df93:     	movl	%edi, %r12d
14009df96:     	cmpw	%di, 0x4058(%rcx)
14009df9d:     	setne	%dil
14009dfa1:     	orb	%r11b, %dil
14009dfa4:     	orb	%bl, %dil
14009dfa7:     	cmpb	%r15b, %r10b
14009dfaa:     	setne	%r11b
14009dfae:     	movq	0x4048(%rcx), %r10
14009dfb5:     	xorq	0x170(%rbp), %r10
14009dfbc:     	movq	0x4040(%rcx), %rbx
14009dfc3:     	xorq	0x168(%rbp), %rbx
14009dfca:     	orq	%r10, %rbx
14009dfcd:     	setne	%r10b
14009dfd1:     	orb	%r11b, %r10b
14009dfd4:     	orb	%dil, %r10b
14009dfd7:     	orb	%r10b, %r9b
14009dfda:     	testb	%r10b, %r10b
14009dfdd:     	movl	$0x1, %r11d
14009dfe3:     	cmoveq	%r11, %r8
14009dfe7:     	testb	$0x1, %r9b
14009dfeb:     	je	0x14009e09a <.text+0x9d09a>
14009dff1:     	notb	%r10b
14009dff4:     	movzbl	%r10b, %r9d
14009dff8:     	andl	$0x1, %r9d
14009dffc:     	movl	%r12d, %edi
14009dfff:     	movl	%r13d, %r12d
14009e002:     	movl	0x178(%rbp), %ebx
14009e008:     	cmpl	%edx, 0x43d8(%rcx)
14009e00e:     	je	0x14009decc <.text+0x9cecc>
14009e014:     	cmpl	%edx, 0x43dc(%rcx)
14009e01a:     	jne	0x14009e028 <.text+0x9d028>
14009e01c:     	movzbl	0x42ba(%rcx), %edx
14009e023:     	cmpb	$0x2, %dl
14009e026:     	jne	0x14009e03a <.text+0x9d03a>
14009e028:     	movl	%r12d, %r13d
14009e02b:     	movl	%edi, %r12d
14009e02e:     	xorl	%edi, %edi
14009e030:     	testq	%r8, %r8
14009e033:     	jne	0x14009e0a0 <.text+0x9d0a0>
14009e035:     	jmp	0x14009e0ca <.text+0x9d0ca>
14009e03a:     	cmpb	%r15b, %dl
14009e03d:     	jne	0x14009e028 <.text+0x9d028>
14009e03f:     	cmpw	%ax, 0x42bc(%rcx)
14009e046:     	jne	0x14009e028 <.text+0x9d028>
14009e048:     	cmpl	%ebx, 0x42b0(%rcx)
14009e04e:     	jne	0x14009e028 <.text+0x9d028>
14009e050:     	cmpl	%r12d, 0x42b4(%rcx)
14009e057:     	jne	0x14009e028 <.text+0x9d028>
14009e059:     	cmpw	%di, 0x42b8(%rcx)
14009e060:     	jne	0x14009e028 <.text+0x9d028>
14009e062:     	movq	0x42a0(%rcx), %rdx
14009e069:     	xorq	0x168(%rbp), %rdx
14009e070:     	movq	0x42a8(%rcx), %r10
14009e077:     	xorq	0x170(%rbp), %r10
14009e07e:     	orq	%rdx, %r10
14009e081:     	jne	0x14009e028 <.text+0x9d028>
14009e083:     	movl	%r12d, %r13d
14009e086:     	movl	%edi, %r12d
14009e089:     	testq	%r8, %r8
14009e08c:     	movl	$0x3, %edx
14009e091:     	cmoveq	%rdx, %r9
14009e095:     	movl	%r8d, %edi
14009e098:     	jmp	0x14009e0a0 <.text+0x9d0a0>
14009e09a:     	movb	$0x1, %dil
14009e09d:     	xorl	%r9d, %r9d
14009e0a0:     	cmpl	$0x0, 0x43d0(%rcx,%r9,4)
14009e0a9:     	je	0x14009e0ca <.text+0x9d0ca>
14009e0ab:     	movl	$0x0, 0x43d0(%rcx,%r9,4)
14009e0b7:     	decq	0x43e8(%rcx)
14009e0be:     	imulq	$0x130, %r9, %rdx       # imm = 0x130
14009e0c5:     	movb	$0x2, 0x1a(%rsi,%rdx)
14009e0ca:     	xorps	%xmm0, %xmm0
14009e0cd:     	movaps	%xmm0, 0x150(%rbp)
14009e0d4:     	movb	$0x0, 0x132(%rbp)
14009e0db:     	movw	%ax, 0x130(%rbp)
14009e0e2:     	leaq	0x133(%rbp), %rdx
14009e0e9:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009e0f2:     	movq	$0x0, 0x133(%rbp)
14009e0fd:     	movq	$0x8, 0x110(%rbp)
14009e108:     	movq	$0x0, 0x118(%rbp)
14009e113:     	movq	$0x1, 0x120(%rbp)
14009e11e:     	movq	$0x0, 0x128(%rbp)
14009e129:     	movq	%rdx, 0x30(%rsp)
14009e12e:     	movw	%ax, 0x28(%rsp)
14009e133:     	movq	$0x0, 0x58(%rsp)
14009e13c:     	movq	$0x1, 0x50(%rsp)
14009e145:     	movq	$0x8, 0x48(%rsp)
14009e14e:     	movq	$0x8, 0x40(%rsp)
14009e157:     	movq	$0x0, 0x38(%rsp)
14009e160:     	movb	$0x0, 0x20(%rsp)
14009e165:     	leaq	0x140(%rbp), %rax
14009e16c:     	leaq	0x150(%rbp), %rdx
14009e173:     	movl	$0x10, %r8d
14009e179:     	movq	%rcx, %rbx
14009e17c:     	movq	%rax, %rcx
14009e17f:     	movb	$0x2, %r9b
14009e182:     	callq	0x140005590 <.text+0x4590>
14009e187:     	cmpb	$0x0, 0x140(%rbp)
14009e18e:     	jne	0x14009e1af <.text+0x9d1af>
14009e190:     	testb	%dil, %dil
14009e193:     	jne	0x14009e1af <.text+0x9d1af>
14009e195:     	movq	%rbx, %rax
14009e198:     	movq	0x148(%rbp), %rbx
14009e19f:     	cmpq	$0x10, %rbx
14009e1a3:     	ja	0x14009e1af <.text+0x9d1af>
14009e1a5:     	cmpq	$0x4, 0x43e8(%rax)
14009e1ad:     	jne	0x14009e1b6 <.text+0x9d1b6>
14009e1af:     	movb	$0x1, %al
14009e1b1:     	jmp	0x14009de13 <.text+0x9ce13>
14009e1b6:     	movq	0x43e0(%rax), %rdi
14009e1bd:     	cmpq	$0x3, %rdi
14009e1c1:     	ja	0x14009e3bd <.text+0x9d3bd>
14009e1c7:     	cmpl	$0x0, 0x43d0(%rax,%rdi,4)
14009e1cf:     	je	0x14009e242 <.text+0x9d242>
14009e1d1:     	leaq	(,%rdi,4), %rdx
14009e1d9:     	xorl	%ecx, %ecx
14009e1db:     	nopl	(%rax,%rax)
14009e1e0:     	cmpl	$0x0, 0x43d0(%rax,%rdx)
14009e1e8:     	je	0x14009e235 <.text+0x9d235>
14009e1ea:     	addq	$0x4, %rdx
14009e1ee:     	decq	%rcx
14009e1f1:     	cmpq	$0x10, %rdx
14009e1f5:     	jne	0x14009e1e0 <.text+0x9d1e0>
14009e1f7:     	testq	%rdi, %rdi
14009e1fa:     	je	0x14009e1af <.text+0x9d1af>
14009e1fc:     	cmpl	$0x0, 0x43d0(%rax)
14009e203:     	je	0x14009e3ac <.text+0x9d3ac>
14009e209:     	cmpq	$0x1, %rdi
14009e20d:     	je	0x14009e1af <.text+0x9d1af>
14009e20f:     	cmpl	$0x0, 0x43d4(%rax)
14009e216:     	je	0x14009e3b3 <.text+0x9d3b3>
14009e21c:     	cmpq	$0x2, %rdi
14009e220:     	je	0x14009e1af <.text+0x9d1af>
14009e222:     	movl	$0x2, %edi
14009e227:     	cmpl	$0x0, 0x43d8(%rax)
14009e22e:     	je	0x14009e238 <.text+0x9d238>
14009e230:     	jmp	0x14009e1af <.text+0x9d1af>
14009e235:     	subq	%rcx, %rdi
14009e238:     	cmpq	$0x4, %rdi
14009e23c:     	jae	0x14009e3d3 <.text+0x9d3d3>
14009e242:     	movl	$0x1, 0x43d0(%rax,%rdi,4)
14009e24d:     	incq	0x43e8(%rax)
14009e254:     	leaq	0x1(%rdi), %rcx
14009e258:     	xorl	%edx, %edx
14009e25a:     	cmpq	$0x4, %rcx
14009e25e:     	cmovneq	%rcx, %rdx
14009e262:     	movq	%rdx, 0x43e0(%rax)
14009e269:     	movq	0x170(%rbp), %rcx
14009e270:     	movq	%rcx, -0x18(%rbp)
14009e274:     	movq	0x168(%rbp), %rcx
14009e27b:     	movq	%rcx, -0x20(%rbp)
14009e27f:     	movl	0x178(%rbp), %ecx
14009e285:     	movl	%ecx, -0x10(%rbp)
14009e288:     	movl	%r13d, -0xc(%rbp)
14009e28c:     	movw	%r12w, -0x8(%rbp)
14009e291:     	movb	%r15b, -0x6(%rbp)
14009e295:     	movzbl	0x17f(%rbp), %ecx
14009e29c:     	movb	%cl, -0x5(%rbp)
14009e29f:     	movss	%xmm6, -0x4(%rbp)
14009e2a4:     	movq	%r14, (%rbp)
14009e2a8:     	testq	%rbx, %rbx
14009e2ab:     	je	0x14009e312 <.text+0x9d312>
14009e2ad:     	movb	$0x1, 0x8(%rbp)
14009e2b1:     	movb	%bl, 0x9(%rbp)
14009e2b4:     	leaq	0xa(%rbp), %r14
14009e2b8:     	movl	$0x80, %r8d
14009e2be:     	subq	%rbx, %r8
14009e2c1:     	leaq	(%rbx,%rbp), %rcx
14009e2c5:     	addq	$0xa, %rcx
14009e2c9:     	movq	%rax, %r15
14009e2cc:     	xorl	%edx, %edx
14009e2ce:     	callq	0x140252002 <.text+0x251002>
14009e2d3:     	leaq	0x150(%rbp), %rdx
14009e2da:     	movq	%r14, %rcx
14009e2dd:     	movq	%rbx, %r8
14009e2e0:     	callq	0x140251ff0 <.text+0x250ff0>
14009e2e5:     	movzwl	-0x4(%rbp), %eax
14009e2e9:     	addl	$0x2, %eax
14009e2ec:     	movl	%eax, 0x43d0(%r15,%rdi,4)
14009e2f4:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009e2fb:     	addq	%rax, %rsi
14009e2fe:     	movzbl	0x8(%rbp), %eax
14009e302:     	leaq	0x1d2f37(%rip), %rcx    # 0x140271240
14009e309:     	movslq	(%rcx,%rax,4), %rax
14009e30d:     	addq	%rcx, %rax
14009e310:     	jmpq	*%rax
14009e312:     	movb	$0x0, 0x8(%rbp)
14009e316:     	movzwl	-0x4(%rbp), %ecx
14009e31a:     	addl	$0x2, %ecx
14009e31d:     	movl	%ecx, 0x43d0(%rax,%rdi,4)
14009e324:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009e32b:     	addq	%rax, %rsi
14009e32e:     	movzbl	0x8(%rbp), %eax
14009e332:     	leaq	0x1d2f07(%rip), %rcx    # 0x140271240
14009e339:     	movslq	(%rcx,%rax,4), %rax
14009e33d:     	addq	%rcx, %rax
14009e340:     	jmpq	*%rax
14009e342:     	movaps	-0x20(%rbp), %xmm0
14009e346:     	movaps	-0x10(%rbp), %xmm1
14009e34a:     	movups	%xmm1, 0x10(%rsi)
14009e34e:     	movups	%xmm0, (%rsi)
14009e351:     	movb	$0x0, 0x28(%rsi)
14009e355:     	movq	(%rbp), %rax
14009e359:     	movq	%rax, 0x20(%rsi)
14009e35d:     	jmp	0x14009e1af <.text+0x9d1af>
14009e362:     	leaq	-0x20(%rbp), %rdx
14009e366:     	movl	$0x130, %r8d            # imm = 0x130
14009e36c:     	movq	%rsi, %rcx
14009e36f:     	callq	0x140251ff0 <.text+0x250ff0>
14009e374:     	jmp	0x14009e1af <.text+0x9d1af>
14009e379:     	movq	(%rbp), %r8
14009e37d:     	movq	0x10(%rbp), %r9
14009e381:     	leaq	-0x20(%rbp), %rdx
14009e385:     	movq	%rsi, %rcx
14009e388:     	callq	0x14000b2d0 <.text+0xa2d0>
14009e38d:     	jmp	0x14009e1af <.text+0x9d1af>
14009e392:     	leaq	0xa(%rbp), %r8
14009e396:     	movzbl	0x9(%rbp), %r9d
14009e39b:     	leaq	-0x20(%rbp), %rdx
14009e39f:     	movq	%rsi, %rcx
14009e3a2:     	callq	0x14000b1c0 <.text+0xa1c0>
14009e3a7:     	jmp	0x14009e1af <.text+0x9d1af>
14009e3ac:     	xorl	%edi, %edi
14009e3ae:     	jmp	0x14009e238 <.text+0x9d238>
14009e3b3:     	movl	$0x1, %edi
14009e3b8:     	jmp	0x14009e238 <.text+0x9d238>
14009e3bd:     	leaq	0x1cf9dc(%rip), %r8     # 0x14026dda0
14009e3c4:     	movl	$0x4, %edx
14009e3c9:     	movq	%rdi, %rcx
14009e3cc:     	callq	0x140252873 <.text+0x251873>
14009e3d1:     	ud2
14009e3d3:     	leaq	0x1cf9de(%rip), %r8     # 0x14026ddb8
14009e3da:     	movl	$0x4, %edx
14009e3df:     	movq	%rdi, %rcx
14009e3e2:     	callq	0x140252873 <.text+0x251873>
14009e3e7:     	ud2


D:\CoapticCurrent\replay-shared-dispatch-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009d4d0:     	pushq	%rbp
14009d4d1:     	pushq	%r15
14009d4d3:     	pushq	%r14
14009d4d5:     	pushq	%r13
14009d4d7:     	pushq	%r12
14009d4d9:     	pushq	%rsi
14009d4da:     	pushq	%rdi
14009d4db:     	pushq	%rbx
14009d4dc:     	subq	$0x218, %rsp            # imm = 0x218
14009d4e3:     	leaq	0x80(%rsp), %rbp
14009d4eb:     	movaps	%xmm6, 0x180(%rbp)
14009d4f2:     	leaq	0x1970(%rcx), %rsi
14009d4f9:     	leaq	0x1998(%rcx), %r8
14009d500:     	movl	$0x4, %r11d
14009d506:     	xorl	%eax, %eax
14009d508:     	movl	$0x1, %r9d
14009d50e:     	xorl	%r10d, %r10d
14009d511:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009d518:     	addq	%r8, %rdi
14009d51b:     	nopl	(%rax,%rax)
14009d520:     	cmpb	$0x2, -0xe(%rdi)
14009d524:     	jne	0x14009d540 <.text+0x9c540>
14009d526:     	incq	%r10
14009d529:     	addq	$0x130, %rdi            # imm = 0x130
14009d530:     	cmpq	%r10, %r11
14009d533:     	jne	0x14009d520 <.text+0x9c520>
14009d535:     	jmp	0x14009d585 <.text+0x9c585>
14009d537:     	nopw	(%rax,%rax)
14009d540:     	movq	-0x8(%rdi), %r11
14009d544:     	cmpb	$0x3, (%rdi)
14009d547:     	setne	%bl
14009d54a:     	testq	%r11, %r11
14009d54d:     	sete	%dil
14009d551:     	orb	%bl, %dil
14009d554:     	cmpq	%r14, %r11
14009d557:     	setae	%bl
14009d55a:     	andb	%al, %bl
14009d55c:     	testb	%dil, %dil
14009d55f:     	cmoveq	%r9, %rax
14009d563:     	orb	%dil, %bl
14009d566:     	cmoveq	%r10, %rdx
14009d56a:     	cmoveq	%r11, %r14
14009d56e:     	incq	%r10
14009d571:     	cmpq	$0x5, %r10
14009d575:     	movl	$0x4, %r11d
14009d57b:     	cmovaeq	%r10, %r11
14009d57f:     	cmpq	$0x3, %r10
14009d583:     	jbe	0x14009d511 <.text+0x9c511>
14009d585:     	testb	$0x1, %al
14009d587:     	je	0x14009d681 <.text+0x9c681>
14009d58d:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009d594:     	movzbl	0x1a(%rsi,%rax), %r15d
14009d59a:     	cmpb	$0x2, %r15b
14009d59e:     	je	0x14009d681 <.text+0x9c681>
14009d5a4:     	addq	%rsi, %rax
14009d5a7:     	cmpb	$0x3, 0x28(%rax)
14009d5ab:     	jne	0x14009d681 <.text+0x9c681>
14009d5b1:     	movq	0x30(%rax), %r8
14009d5b5:     	movq	(%rax), %rdx
14009d5b8:     	movq	%rdx, 0x168(%rbp)
14009d5bf:     	movq	0x8(%rax), %rdx
14009d5c3:     	movq	%rdx, 0x170(%rbp)
14009d5ca:     	movl	0x10(%rax), %ebx
14009d5cd:     	movl	0x14(%rax), %r12d
14009d5d1:     	movzwl	0x18(%rax), %edi
14009d5d5:     	movzbl	0x1b(%rax), %edx
14009d5d9:     	movb	%dl, 0x17f(%rbp)
14009d5df:     	movss	0x1c(%rax), %xmm6
14009d5e4:     	movzwl	0x1c(%rax), %eax
14009d5e8:     	movzwl	%ax, %edx
14009d5eb:     	cmpq	$0x1, %r8
14009d5ef:     	ja	0x14009d64b <.text+0x9c64b>
14009d5f1:     	cmpb	$0x1, 0x1968(%rcx,%r8)
14009d5fa:     	jne	0x14009d64b <.text+0x9c64b>
14009d5fc:     	cmpb	$0x0, 0x196a(%rcx,%r8)
14009d605:     	jne	0x14009d64b <.text+0x9c64b>
14009d607:     	movb	$0x0, 0x1968(%rcx,%r8)
14009d610:     	decq	0x1960(%rcx)
14009d617:     	leaq	0xfe0(%rcx), %r9
14009d61e:     	movq	$0x0, 0x18e0(%rcx,%r8,8)
14009d62a:     	leaq	(%r8,%r8,8), %r10
14009d62e:     	leaq	(%r10,%r10,2), %r10
14009d632:     	addq	%r8, %r10
14009d635:     	movb	$0x2, 0x95a(%r9,%r10)
14009d63e:     	leaq	(%r8,%r8,2), %r8
14009d642:     	movb	$0x2, 0x91d(%r9,%r8,8)
14009d64b:     	addl	$0x2, %edx
14009d64e:     	movb	$0x1, %r9b
14009d651:     	cmpl	%edx, 0x1e30(%rcx)
14009d657:     	jne	0x14009d667 <.text+0x9c667>
14009d659:     	movzbl	0x198a(%rcx), %r8d
14009d661:     	cmpb	$0x2, %r8b
14009d665:     	jne	0x14009d69e <.text+0x9c69e>
14009d667:     	xorl	%r8d, %r8d
14009d66a:     	cmpl	%edx, 0x1e34(%rcx)
14009d670:     	movl	%ebx, 0x178(%rbp)
14009d676:     	jne	0x14009d72d <.text+0x9c72d>
14009d67c:     	jmp	0x14009d71b <.text+0x9c71b>
14009d681:     	xorl	%eax, %eax
14009d683:     	movaps	0x180(%rbp), %xmm6
14009d68a:     	addq	$0x218, %rsp            # imm = 0x218
14009d691:     	popq	%rbx
14009d692:     	popq	%rdi
14009d693:     	popq	%rsi
14009d694:     	popq	%r12
14009d696:     	popq	%r13
14009d698:     	popq	%r14
14009d69a:     	popq	%r15
14009d69c:     	popq	%rbp
14009d69d:     	retq
14009d69e:     	cmpw	%ax, 0x198c(%rcx)
14009d6a5:     	sete	%r9b
14009d6a9:     	cmpl	%ebx, 0x1980(%rcx)
14009d6af:     	sete	%r10b
14009d6b3:     	andb	%r9b, %r10b
14009d6b6:     	cmpl	%r12d, 0x1984(%rcx)
14009d6bd:     	sete	%r9b
14009d6c1:     	cmpw	%di, 0x1988(%rcx)
14009d6c8:     	sete	%r11b
14009d6cc:     	andb	%r9b, %r11b
14009d6cf:     	andb	%r10b, %r11b
14009d6d2:     	cmpb	%r15b, %r8b
14009d6d5:     	sete	%r8b
14009d6d9:     	movq	0x1978(%rcx), %r9
14009d6e0:     	xorq	0x170(%rbp), %r9
14009d6e7:     	movq	0x1970(%rcx), %r10
14009d6ee:     	xorq	0x168(%rbp), %r10
14009d6f5:     	orq	%r9, %r10
14009d6f8:     	sete	%r9b
14009d6fc:     	andb	%r8b, %r9b
14009d6ff:     	andb	%r11b, %r9b
14009d702:     	movzbl	%r9b, %r8d
14009d706:     	movl	%r8d, %r9d
14009d709:     	xorb	$0x1, %r9b
14009d70d:     	cmpl	%edx, 0x1e34(%rcx)
14009d713:     	movl	%ebx, 0x178(%rbp)
14009d719:     	jne	0x14009d72d <.text+0x9c72d>
14009d71b:     	movzbl	0x1aba(%rcx), %r10d
14009d723:     	cmpb	$0x2, %r10b
14009d727:     	jne	0x14009d7de <.text+0x9c7de>
14009d72d:     	xorl	%r9d, %r9d
14009d730:     	cmpl	%edx, 0x1e38(%rcx)
14009d736:     	jne	0x14009d884 <.text+0x9c884>
14009d73c:     	movzbl	0x1bea(%rcx), %r10d
14009d744:     	cmpb	$0x2, %r10b
14009d748:     	je	0x14009d884 <.text+0x9c884>
14009d74e:     	cmpb	%r15b, %r10b
14009d751:     	jne	0x14009d884 <.text+0x9c884>
14009d757:     	cmpw	%ax, 0x1bec(%rcx)
14009d75e:     	jne	0x14009d884 <.text+0x9c884>
14009d764:     	cmpl	%ebx, 0x1be0(%rcx)
14009d76a:     	jne	0x14009d884 <.text+0x9c884>
14009d770:     	cmpl	%r12d, 0x1be4(%rcx)
14009d777:     	jne	0x14009d884 <.text+0x9c884>
14009d77d:     	cmpw	%di, 0x1be8(%rcx)
14009d784:     	jne	0x14009d884 <.text+0x9c884>
14009d78a:     	movq	0x1bd0(%rcx), %r10
14009d791:     	xorq	0x168(%rbp), %r10
14009d798:     	movq	0x1bd8(%rcx), %r11
14009d79f:     	xorq	0x170(%rbp), %r11
14009d7a6:     	orq	%r10, %r11
14009d7a9:     	jne	0x14009d884 <.text+0x9c884>
14009d7af:     	movl	%r12d, %r13d
14009d7b2:     	movl	%edi, %r12d
14009d7b5:     	movb	$0x1, %dil
14009d7b8:     	testq	%r8, %r8
14009d7bb:     	jne	0x14009d910 <.text+0x9c910>
14009d7c1:     	movl	$0x1, %r8d
14009d7c7:     	movl	$0x2, %r9d
14009d7cd:     	movl	%r12d, %edi
14009d7d0:     	movl	%r13d, %r12d
14009d7d3:     	movl	0x178(%rbp), %ebx
14009d7d9:     	jmp	0x14009d884 <.text+0x9c884>
14009d7de:     	cmpw	%ax, 0x1abc(%rcx)
14009d7e5:     	setne	%r11b
14009d7e9:     	cmpl	%ebx, 0x1ab0(%rcx)
14009d7ef:     	setne	%bl
14009d7f2:     	orb	%r11b, %bl
14009d7f5:     	movl	%r12d, %r13d
14009d7f8:     	cmpl	%r12d, 0x1ab4(%rcx)
14009d7ff:     	setne	%r11b
14009d803:     	movl	%edi, %r12d
14009d806:     	cmpw	%di, 0x1ab8(%rcx)
14009d80d:     	setne	%dil
14009d811:     	orb	%r11b, %dil
14009d814:     	orb	%bl, %dil
14009d817:     	cmpb	%r15b, %r10b
14009d81a:     	setne	%r11b
14009d81e:     	movq	0x1aa8(%rcx), %r10
14009d825:     	xorq	0x170(%rbp), %r10
14009d82c:     	movq	0x1aa0(%rcx), %rbx
14009d833:     	xorq	0x168(%rbp), %rbx
14009d83a:     	orq	%r10, %rbx
14009d83d:     	setne	%r10b
14009d841:     	orb	%r11b, %r10b
14009d844:     	orb	%dil, %r10b
14009d847:     	orb	%r10b, %r9b
14009d84a:     	testb	%r10b, %r10b
14009d84d:     	movl	$0x1, %r11d
14009d853:     	cmoveq	%r11, %r8
14009d857:     	testb	$0x1, %r9b
14009d85b:     	je	0x14009d90a <.text+0x9c90a>
14009d861:     	notb	%r10b
14009d864:     	movzbl	%r10b, %r9d
14009d868:     	andl	$0x1, %r9d
14009d86c:     	movl	%r12d, %edi
14009d86f:     	movl	%r13d, %r12d
14009d872:     	movl	0x178(%rbp), %ebx
14009d878:     	cmpl	%edx, 0x1e38(%rcx)
14009d87e:     	je	0x14009d73c <.text+0x9c73c>
14009d884:     	cmpl	%edx, 0x1e3c(%rcx)
14009d88a:     	jne	0x14009d898 <.text+0x9c898>
14009d88c:     	movzbl	0x1d1a(%rcx), %edx
14009d893:     	cmpb	$0x2, %dl
14009d896:     	jne	0x14009d8aa <.text+0x9c8aa>
14009d898:     	movl	%r12d, %r13d
14009d89b:     	movl	%edi, %r12d
14009d89e:     	xorl	%edi, %edi
14009d8a0:     	testq	%r8, %r8
14009d8a3:     	jne	0x14009d910 <.text+0x9c910>
14009d8a5:     	jmp	0x14009d93a <.text+0x9c93a>
14009d8aa:     	cmpb	%r15b, %dl
14009d8ad:     	jne	0x14009d898 <.text+0x9c898>
14009d8af:     	cmpw	%ax, 0x1d1c(%rcx)
14009d8b6:     	jne	0x14009d898 <.text+0x9c898>
14009d8b8:     	cmpl	%ebx, 0x1d10(%rcx)
14009d8be:     	jne	0x14009d898 <.text+0x9c898>
14009d8c0:     	cmpl	%r12d, 0x1d14(%rcx)
14009d8c7:     	jne	0x14009d898 <.text+0x9c898>
14009d8c9:     	cmpw	%di, 0x1d18(%rcx)
14009d8d0:     	jne	0x14009d898 <.text+0x9c898>
14009d8d2:     	movq	0x1d00(%rcx), %rdx
14009d8d9:     	xorq	0x168(%rbp), %rdx
14009d8e0:     	movq	0x1d08(%rcx), %r10
14009d8e7:     	xorq	0x170(%rbp), %r10
14009d8ee:     	orq	%rdx, %r10
14009d8f1:     	jne	0x14009d898 <.text+0x9c898>
14009d8f3:     	movl	%r12d, %r13d
14009d8f6:     	movl	%edi, %r12d
14009d8f9:     	testq	%r8, %r8
14009d8fc:     	movl	$0x3, %edx
14009d901:     	cmoveq	%rdx, %r9
14009d905:     	movl	%r8d, %edi
14009d908:     	jmp	0x14009d910 <.text+0x9c910>
14009d90a:     	movb	$0x1, %dil
14009d90d:     	xorl	%r9d, %r9d
14009d910:     	cmpl	$0x0, 0x1e30(%rcx,%r9,4)
14009d919:     	je	0x14009d93a <.text+0x9c93a>
14009d91b:     	movl	$0x0, 0x1e30(%rcx,%r9,4)
14009d927:     	decq	0x1e48(%rcx)
14009d92e:     	imulq	$0x130, %r9, %rdx       # imm = 0x130
14009d935:     	movb	$0x2, 0x1a(%rsi,%rdx)
14009d93a:     	xorps	%xmm0, %xmm0
14009d93d:     	movaps	%xmm0, 0x150(%rbp)
14009d944:     	movb	$0x0, 0x132(%rbp)
14009d94b:     	movw	%ax, 0x130(%rbp)
14009d952:     	leaq	0x133(%rbp), %rdx
14009d959:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009d962:     	movq	$0x0, 0x133(%rbp)
14009d96d:     	movq	$0x8, 0x110(%rbp)
14009d978:     	movq	$0x0, 0x118(%rbp)
14009d983:     	movq	$0x1, 0x120(%rbp)
14009d98e:     	movq	$0x0, 0x128(%rbp)
14009d999:     	movq	%rdx, 0x30(%rsp)
14009d99e:     	movw	%ax, 0x28(%rsp)
14009d9a3:     	movq	$0x0, 0x58(%rsp)
14009d9ac:     	movq	$0x1, 0x50(%rsp)
14009d9b5:     	movq	$0x8, 0x48(%rsp)
14009d9be:     	movq	$0x8, 0x40(%rsp)
14009d9c7:     	movq	$0x0, 0x38(%rsp)
14009d9d0:     	movb	$0x0, 0x20(%rsp)
14009d9d5:     	leaq	0x140(%rbp), %rax
14009d9dc:     	leaq	0x150(%rbp), %rdx
14009d9e3:     	movl	$0x10, %r8d
14009d9e9:     	movq	%rcx, %rbx
14009d9ec:     	movq	%rax, %rcx
14009d9ef:     	movb	$0x2, %r9b
14009d9f2:     	callq	0x140005590 <.text+0x4590>
14009d9f7:     	cmpb	$0x0, 0x140(%rbp)
14009d9fe:     	jne	0x14009da1f <.text+0x9ca1f>
14009da00:     	testb	%dil, %dil
14009da03:     	jne	0x14009da1f <.text+0x9ca1f>
14009da05:     	movq	%rbx, %rax
14009da08:     	movq	0x148(%rbp), %rbx
14009da0f:     	cmpq	$0x10, %rbx
14009da13:     	ja	0x14009da1f <.text+0x9ca1f>
14009da15:     	cmpq	$0x4, 0x1e48(%rax)
14009da1d:     	jne	0x14009da26 <.text+0x9ca26>
14009da1f:     	movb	$0x1, %al
14009da21:     	jmp	0x14009d683 <.text+0x9c683>
14009da26:     	movq	0x1e40(%rax), %rdi
14009da2d:     	cmpq	$0x3, %rdi
14009da31:     	ja	0x14009dc2d <.text+0x9cc2d>
14009da37:     	cmpl	$0x0, 0x1e30(%rax,%rdi,4)
14009da3f:     	je	0x14009dab2 <.text+0x9cab2>
14009da41:     	leaq	(,%rdi,4), %rdx
14009da49:     	xorl	%ecx, %ecx
14009da4b:     	nopl	(%rax,%rax)
14009da50:     	cmpl	$0x0, 0x1e30(%rax,%rdx)
14009da58:     	je	0x14009daa5 <.text+0x9caa5>
14009da5a:     	addq	$0x4, %rdx
14009da5e:     	decq	%rcx
14009da61:     	cmpq	$0x10, %rdx
14009da65:     	jne	0x14009da50 <.text+0x9ca50>
14009da67:     	testq	%rdi, %rdi
14009da6a:     	je	0x14009da1f <.text+0x9ca1f>
14009da6c:     	cmpl	$0x0, 0x1e30(%rax)
14009da73:     	je	0x14009dc1c <.text+0x9cc1c>
14009da79:     	cmpq	$0x1, %rdi
14009da7d:     	je	0x14009da1f <.text+0x9ca1f>
14009da7f:     	cmpl	$0x0, 0x1e34(%rax)
14009da86:     	je	0x14009dc23 <.text+0x9cc23>
14009da8c:     	cmpq	$0x2, %rdi
14009da90:     	je	0x14009da1f <.text+0x9ca1f>
14009da92:     	movl	$0x2, %edi
14009da97:     	cmpl	$0x0, 0x1e38(%rax)
14009da9e:     	je	0x14009daa8 <.text+0x9caa8>
14009daa0:     	jmp	0x14009da1f <.text+0x9ca1f>
14009daa5:     	subq	%rcx, %rdi
14009daa8:     	cmpq	$0x4, %rdi
14009daac:     	jae	0x14009dc43 <.text+0x9cc43>
14009dab2:     	movl	$0x1, 0x1e30(%rax,%rdi,4)
14009dabd:     	incq	0x1e48(%rax)
14009dac4:     	leaq	0x1(%rdi), %rcx
14009dac8:     	xorl	%edx, %edx
14009daca:     	cmpq	$0x4, %rcx
14009dace:     	cmovneq	%rcx, %rdx
14009dad2:     	movq	%rdx, 0x1e40(%rax)
14009dad9:     	movq	0x170(%rbp), %rcx
14009dae0:     	movq	%rcx, -0x18(%rbp)
14009dae4:     	movq	0x168(%rbp), %rcx
14009daeb:     	movq	%rcx, -0x20(%rbp)
14009daef:     	movl	0x178(%rbp), %ecx
14009daf5:     	movl	%ecx, -0x10(%rbp)
14009daf8:     	movl	%r13d, -0xc(%rbp)
14009dafc:     	movw	%r12w, -0x8(%rbp)
14009db01:     	movb	%r15b, -0x6(%rbp)
14009db05:     	movzbl	0x17f(%rbp), %ecx
14009db0c:     	movb	%cl, -0x5(%rbp)
14009db0f:     	movss	%xmm6, -0x4(%rbp)
14009db14:     	movq	%r14, (%rbp)
14009db18:     	testq	%rbx, %rbx
14009db1b:     	je	0x14009db82 <.text+0x9cb82>
14009db1d:     	movb	$0x1, 0x8(%rbp)
14009db21:     	movb	%bl, 0x9(%rbp)
14009db24:     	leaq	0xa(%rbp), %r14
14009db28:     	movl	$0x80, %r8d
14009db2e:     	subq	%rbx, %r8
14009db31:     	leaq	(%rbx,%rbp), %rcx
14009db35:     	addq	$0xa, %rcx
14009db39:     	movq	%rax, %r15
14009db3c:     	xorl	%edx, %edx
14009db3e:     	callq	0x140252002 <.text+0x251002>
14009db43:     	leaq	0x150(%rbp), %rdx
14009db4a:     	movq	%r14, %rcx
14009db4d:     	movq	%rbx, %r8
14009db50:     	callq	0x140251ff0 <.text+0x250ff0>
14009db55:     	movzwl	-0x4(%rbp), %eax
14009db59:     	addl	$0x2, %eax
14009db5c:     	movl	%eax, 0x1e30(%r15,%rdi,4)
14009db64:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009db6b:     	addq	%rax, %rsi
14009db6e:     	movzbl	0x8(%rbp), %eax
14009db72:     	leaq	0x1d36b7(%rip), %rcx    # 0x140271230
14009db79:     	movslq	(%rcx,%rax,4), %rax
14009db7d:     	addq	%rcx, %rax
14009db80:     	jmpq	*%rax
14009db82:     	movb	$0x0, 0x8(%rbp)
14009db86:     	movzwl	-0x4(%rbp), %ecx
14009db8a:     	addl	$0x2, %ecx
14009db8d:     	movl	%ecx, 0x1e30(%rax,%rdi,4)
14009db94:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009db9b:     	addq	%rax, %rsi
14009db9e:     	movzbl	0x8(%rbp), %eax
14009dba2:     	leaq	0x1d3687(%rip), %rcx    # 0x140271230
14009dba9:     	movslq	(%rcx,%rax,4), %rax
14009dbad:     	addq	%rcx, %rax
14009dbb0:     	jmpq	*%rax
14009dbb2:     	movaps	-0x20(%rbp), %xmm0
14009dbb6:     	movaps	-0x10(%rbp), %xmm1
14009dbba:     	movups	%xmm1, 0x10(%rsi)
14009dbbe:     	movups	%xmm0, (%rsi)
14009dbc1:     	movb	$0x0, 0x28(%rsi)
14009dbc5:     	movq	(%rbp), %rax
14009dbc9:     	movq	%rax, 0x20(%rsi)
14009dbcd:     	jmp	0x14009da1f <.text+0x9ca1f>
14009dbd2:     	leaq	-0x20(%rbp), %rdx
14009dbd6:     	movl	$0x130, %r8d            # imm = 0x130
14009dbdc:     	movq	%rsi, %rcx
14009dbdf:     	callq	0x140251ff0 <.text+0x250ff0>
14009dbe4:     	jmp	0x14009da1f <.text+0x9ca1f>
14009dbe9:     	movq	(%rbp), %r8
14009dbed:     	movq	0x10(%rbp), %r9
14009dbf1:     	leaq	-0x20(%rbp), %rdx
14009dbf5:     	movq	%rsi, %rcx
14009dbf8:     	callq	0x14000b2d0 <.text+0xa2d0>
14009dbfd:     	jmp	0x14009da1f <.text+0x9ca1f>
14009dc02:     	leaq	0xa(%rbp), %r8
14009dc06:     	movzbl	0x9(%rbp), %r9d
14009dc0b:     	leaq	-0x20(%rbp), %rdx
14009dc0f:     	movq	%rsi, %rcx
14009dc12:     	callq	0x14000b1c0 <.text+0xa1c0>
14009dc17:     	jmp	0x14009da1f <.text+0x9ca1f>
14009dc1c:     	xorl	%edi, %edi
14009dc1e:     	jmp	0x14009daa8 <.text+0x9caa8>
14009dc23:     	movl	$0x1, %edi
14009dc28:     	jmp	0x14009daa8 <.text+0x9caa8>
14009dc2d:     	leaq	0x1d016c(%rip), %r8     # 0x14026dda0
14009dc34:     	movl	$0x4, %edx
14009dc39:     	movq	%rdi, %rcx
14009dc3c:     	callq	0x140252873 <.text+0x251873>
14009dc41:     	ud2
14009dc43:     	leaq	0x1d016e(%rip), %r8     # 0x14026ddb8
14009dc4a:     	movl	$0x4, %edx
14009dc4f:     	movq	%rdi, %rcx
14009dc52:     	callq	0x140252873 <.text+0x251873>
14009dc57:     	ud2

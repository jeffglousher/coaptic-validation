
D:\CoapticCurrent\replay-shared-dispatch-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400673d0:     	pushq	%rbp
1400673d1:     	pushq	%r15
1400673d3:     	pushq	%r14
1400673d5:     	pushq	%r13
1400673d7:     	pushq	%r12
1400673d9:     	pushq	%rsi
1400673da:     	pushq	%rdi
1400673db:     	pushq	%rbx
1400673dc:     	subq	$0x508, %rsp            # imm = 0x508
1400673e3:     	leaq	0x80(%rsp), %rbp
1400673eb:     	movq	0x500(%rbp), %r12
1400673f2:     	movq	0x8(%r12), %rdi
1400673f7:     	movl	$0x3, %r10d
1400673fd:     	cmpq	$0x3, %rdi
140067401:     	ja	0x1400674e1 <.text+0x664e1>
140067407:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
14006740f:     	jne	0x1400674e1 <.text+0x664e1>
140067415:     	movq	0x26700(%rdx,%rdi,8), %rax
14006741d:     	cmpq	$0x4001, %rax           # imm = 0x4001
140067423:     	jae	0x1400676be <.text+0x666be>
140067429:     	movq	0x10(%r12), %r11
14006742e:     	movq	0x18(%r12), %r15
140067433:     	movq	%r15, %rsi
140067436:     	movl	$0xb, %r10d
14006743c:     	addq	%r11, %rsi
14006743f:     	jb	0x1400674e1 <.text+0x664e1>
140067445:     	cmpq	$0x400, %r15            # imm = 0x400
14006744c:     	ja	0x1400674e1 <.text+0x664e1>
140067452:     	cmpq	%rax, %rsi
140067455:     	ja	0x1400674e1 <.text+0x664e1>
14006745b:     	movq	%r8, %r13
14006745e:     	movq	%r9, 0x470(%rbp)
140067465:     	movq	%rcx, 0x480(%rbp)
14006746c:     	movzbl	0x508(%rbp), %r14d
140067474:     	movq	%rdi, %rax
140067477:     	shlq	$0xe, %rax
14006747b:     	movq	%rdx, %rsi
14006747e:     	leaq	(%rdx,%rax), %rbx
140067482:     	addq	$0x16700, %rbx          # imm = 0x16700
140067489:     	addq	%r11, %rbx
14006748c:     	movl	$0x400, %r8d            # imm = 0x400
140067492:     	cmpq	$0x400, %r15            # imm = 0x400
140067499:     	je	0x1400674a8 <.text+0x664a8>
14006749b:     	movq	%rbp, %rcx
14006749e:     	xorl	%edx, %edx
1400674a0:     	callq	0x140252002 <.text+0x251002>
1400674a5:     	movq	%r15, %r8
1400674a8:     	movq	%rbp, %rcx
1400674ab:     	movq	%rbx, %rdx
1400674ae:     	callq	0x140251ff0 <.text+0x250ff0>
1400674b3:     	testb	%r14b, %r14b
1400674b6:     	je	0x1400674fc <.text+0x664fc>
1400674b8:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
1400674bf:     	movq	%rsi, %rcx
1400674c2:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
1400674cb:     	jne	0x140067673 <.text+0x66673>
1400674d1:     	xorl	%edi, %edi
1400674d3:     	callq	0x14009a100 <.text+0x99100>
1400674d8:     	testb	$0x1, %al
1400674da:     	jne	0x14006750e <.text+0x6650e>
1400674dc:     	jmp	0x14006769c <.text+0x6669c>
1400674e1:     	movb	$0xa, (%rcx)
1400674e4:     	movq	%r10, 0x8(%rcx)
1400674e8:     	addq	$0x508, %rsp            # imm = 0x508
1400674ef:     	popq	%rbx
1400674f0:     	popq	%rdi
1400674f1:     	popq	%rsi
1400674f2:     	popq	%r12
1400674f4:     	popq	%r13
1400674f6:     	popq	%r14
1400674f8:     	popq	%r15
1400674fa:     	popq	%rbp
1400674fb:     	retq
1400674fc:     	xorl	%edi, %edi
1400674fe:     	movq	%rsi, %rcx
140067501:     	callq	0x14009a100 <.text+0x99100>
140067506:     	testb	$0x1, %al
140067508:     	je	0x14006769c <.text+0x6669c>
14006750e:     	movq	%rdx, %rbx
140067511:     	movq	0x518(%rbp), %rdx
140067518:     	movq	0x510(%rbp), %r8
14006751f:     	movzwl	0x4f8(%rbp), %ecx
140067526:     	movzbl	0x4f0(%rbp), %eax
14006752d:     	movq	(%r12), %r9
140067531:     	movq	%rdi, 0x440(%rbp)
140067538:     	movq	0x478(%rbp), %r10
14006753f:     	movq	%r10, 0x448(%rbp)
140067546:     	movq	%r9, 0x450(%rbp)
14006754d:     	movb	%r14b, 0x458(%rbp)
140067554:     	movups	0x60(%r13), %xmm0
140067559:     	movups	0x6c(%r13), %xmm1
14006755e:     	movups	%xmm1, 0x40c(%rbp)
140067565:     	movaps	%xmm0, 0x400(%rbp)
14006756c:     	leaq	0x8e(%r13), %r9
140067573:     	movq	0x7e(%r13), %r10
140067577:     	movq	0x85(%r13), %r11
14006757e:     	movq	%r11, 0x467(%rbp)
140067585:     	movq	%r10, 0x460(%rbp)
14006758c:     	leaq	0x460(%rbp), %r10
140067593:     	movq	%r10, 0x70(%rsp)
140067598:     	movq	%rdx, 0x68(%rsp)
14006759d:     	movq	%r8, 0x60(%rsp)
1400675a2:     	movq	%r13, 0x58(%rsp)
1400675a7:     	leaq	0x440(%rbp), %rdx
1400675ae:     	movq	%rdx, 0x50(%rsp)
1400675b3:     	movq	%r15, 0x48(%rsp)
1400675b8:     	movq	%rbp, %rdx
1400675bb:     	movq	%rdx, 0x40(%rsp)
1400675c0:     	movq	0x470(%rbp), %rdx
1400675c7:     	movq	%rdx, 0x38(%rsp)
1400675cc:     	movq	%r9, 0x30(%rsp)
1400675d1:     	movw	%cx, 0x28(%rsp)
1400675d6:     	movb	%al, 0x20(%rsp)
1400675da:     	leaq	0x420(%rbp), %rcx
1400675e1:     	leaq	0x400(%rbp), %r8
1400675e8:     	movq	%rsi, %rdx
1400675eb:     	movq	%rbx, %r9
1400675ee:     	callq	0x140080330 <.text+0x7f330>
1400675f3:     	cmpb	$-0x1, 0x420(%rbp)
1400675fa:     	je	0x1400676ab <.text+0x666ab>
140067600:     	cmpb	$0x1, 0x326f0(%rsi,%rbx)
140067608:     	movq	0x480(%rbp), %rax
14006760f:     	jne	0x140067659 <.text+0x66659>
140067611:     	cmpb	$0x0, 0x32710(%rsi,%rbx)
140067619:     	jne	0x140067659 <.text+0x66659>
14006761b:     	movb	$0x0, 0x326f0(%rsi,%rbx)
140067623:     	decq	0x32738(%rsi)
14006762a:     	leaq	0x326f0(%rsi), %rcx
140067631:     	movq	$0x0, 0x3e5c0(%rsi,%rbx,8)
14006763d:     	leaq	(%rbx,%rbx,8), %rdx
140067641:     	leaq	(%rdx,%rdx,2), %rdx
140067645:     	addq	%rbx, %rdx
140067648:     	movb	$0x2, 0x36a(%rcx,%rdx)
140067650:     	leaq	(%rbx,%rbx,2), %rdx
140067654:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140067659:     	movups	0x420(%rbp), %xmm0
140067660:     	movups	0x430(%rbp), %xmm1
140067667:     	movups	%xmm1, 0x10(%rax)
14006766b:     	movups	%xmm0, (%rax)
14006766e:     	jmp	0x1400674e8 <.text+0x664e8>
140067673:     	addq	%rcx, %rax
140067676:     	addq	$0x15c28, %rax          # imm = 0x15C28
14006767c:     	movq	0x98(%rax), %rax
140067683:     	movq	%rax, 0x478(%rbp)
14006768a:     	movl	$0x1, %edi
14006768f:     	callq	0x14009a100 <.text+0x99100>
140067694:     	testb	$0x1, %al
140067696:     	jne	0x14006750e <.text+0x6650e>
14006769c:     	movq	0x480(%rbp), %rax
1400676a3:     	movb	$0x9, (%rax)
1400676a6:     	jmp	0x1400674e8 <.text+0x664e8>
1400676ab:     	movq	0x480(%rbp), %rax
1400676b2:     	movq	%rbx, 0x8(%rax)
1400676b6:     	movb	$-0x1, (%rax)
1400676b9:     	jmp	0x1400674e8 <.text+0x664e8>
1400676be:     	leaq	0x20658b(%rip), %r9     # 0x14026dc50
1400676c5:     	movl	$0x4000, %r8d           # imm = 0x4000
1400676cb:     	xorl	%ecx, %ecx
1400676cd:     	movq	%rax, %rdx
1400676d0:     	callq	0x140252a80 <.text+0x251a80>
1400676d5:     	ud2

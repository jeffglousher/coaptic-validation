"""Render the completed integration from retained records only."""
from pathlib import Path
import json,re,subprocess,sys
r=Path(__file__).resolve().parent
out=Path('D:/codex-work/coaptic-validation/tools/benchmark/evidence/replay-shared-dispatch-20261106')
prior=out.parent/'replay-row-presence-20261106'
s=(prior/'render.py').read_text(encoding='utf-8')
prefix=s[:s.index('document =')]
prefix=prefix.replace("('replay-row-presence-20261106','Replay row presence')","('replay-row-presence-20261106','Replay row presence'),('replay-shared-dispatch-20261106','Replay + shared dispatch integration')")
style=re.search(r'<style>(.*?)</style>',s,re.S)[1]
body='''document = f\'''<!doctype html><html><head><meta charset="utf-8"><title>Replay and shared dispatch integration</title><style>'''+style+'''</style></head><body>
<p><strong>{'Runtime preservation passed; qualification and merge are separate' if passed else 'Rejected: runtime preservation not established'}</strong></p>
<p>Exact native source <code>4bf0738</code> versus pinned <code>bd63199</code>. Complete server-App thread CPU cycles,64 paired processes per workload,28 matched workloads. Lower is better.</p>
{''.join(svg)}<p class="muted">Dots: geometric mean change. Lines: one-sided95% upper bound. Dashed line: +2% preservation limit. All28 cell bounds and ordinary/all sync/async aggregates must pass. No trimming or replacement.</p>
{cpu}
<h2>Complete memory owners</h2>{mem}
<p>Host SmallDevice saves744 bytes; fixed Service saves1,504; allocated Service saves696 inline plus832 requested pool bytes. Both Service progress futures shrink1,416 bytes; SmallDevice's future is unchanged. Nested fields are already included in their owners. These are object/compiler sizes and requested heap, not peak RAM or reserved task stacks.</p>
<h2>What changed</h2><p>Blockwise dispatch borrows the existing collected-body backing. Datagram-only dispatch keeps its temporary owner. Flat reply metadata borrows the retained packet. Replay uses compact exclusive ownership, a short128-byte writer, reduced key-search work and direct row-presence checks. Full retained chunks initialize directly from the body. The final integration is measured together; gains from earlier cohorts are not added.</p>
<h2>32-bit static layout</h2>{mem32}<p>Installed Thumbv7EM target, actual App types with unit transport; no device execution or new platform claim. Capacities are unchanged.</p>
<details><summary>All28 workload comparisons</summary>{cells}</details>
<details><summary>Largest fixed-Service pool owners</summary>{bars}<p>The pool is already inside the App total. Independent body and packet capacities dominate; preallocation alone does not make temporary copies share storage.</p></details>
<details><summary>Retained prior failures</summary>{history}<p>Separate cohorts against the same pinned source. No causal subtraction or unchanged resampling. Previous failed integrations remain failed, including row-presence8fc41ea and scratch90e3ef9.</p></details>
<details><summary>Checks and tradeoffs</summary><p>935 library,11 allocation,27 retained-Q,13 footprint and4 scratch-admission checks pass. Tests ran at d35f8ff; the only follow-up is an explanatory comment and scoped Clippy allowance on the intentional inline union. Final4bf0738 passes formatting and strict all-features lint. General integrated review found no actionable issue.</p><p>Selected encoder frames remain1,280/1,296 bytes. Reclaim frames are544 versus baseline784–800. Short replay writes128 payload bytes plus metadata; full256-byte capacity remains. Its helper reserves8 bytes and all eight inspected caller reservations match or shrink. This is not peak-stack evidence.</p><p>The shared owner adds metadata included in App totals. Large custom scratch switches initialized variants when collecting bodies; startup and those custom switch costs are outside this steady-state cohort. Body-slot release timing and4,096-byte collection capacity are preserved. Custom implementations select ResidentRxScratch separately from temporary scratch so temporary Rc markers do not restrict App Send/Sync. Compact replay equality/hash excludes discarded inactive bytes.</p><p>Sync and actual async wait/progress use immediate-ready memory transport and a pending timer. Client preparation, authentication and verification are outside the server clock. No socket latency, maximum throughput, executor scheduling, peak device memory or new libcoap ranking is claimed.</p></details>
</body></html>\'''
(ROOT/'comparison.html').write_text(document,encoding='utf-8')
print(ROOT/'comparison.html')
'''
(out/'render.py').write_text(prefix+body,encoding='utf-8')
subprocess.run([sys.executable,'-B',str(out/'render.py')],check=True)
x=json.loads((out/'measurement.json').read_text())
verdict='passes the frozen runtime preservation rule; broader checks and merge are separate' if x['runtime_accepted'] else 'is rejected under the frozen runtime preservation rule'
readme=f'''# Replay and shared dispatch integration

Exact native candidate4bf07388b8454d75acb3c010f5e38443ca3b2417 versus pinned
baselinebd63199b652193b4c0a882e5840e72d992cf1362 {verdict}.
All64 pairs across28 workloads are retained; {len(x['failed_point_guards'])} cell bounds fail.
Complete App CPU change: sync{(x['groups']['all-sync']['ratio']-1)*100:+.3f}%,
async{(x['groups']['all-async']['ratio']-1)*100:+.3f}%.
`comparison.html` contains the chart and comparable owner/workload tables.

Blockwise dispatch shares the existing collected-response backing. Datagram-only
dispatch retains temporary scratch. Flat reply metadata borrows retained bytes.
The replay integration uses compact exclusive owners, short128-byte copies,
borrowed reclaim encoding, occupancy/MID metadata, reduced key searches and
row-presence borrowing. Full retained chunks initialize directly from body data.
This is the first combined measurement of these source changes. Previous failed
cohorts remain failed; their gains are not summed or treated as causal effects.

Host SmallDevice App14936 to14192 (-744); fixed Service315656 to314152 (-1504).
Allocated Service App35672 to34976 (-696), requested pool282512 to281680 (-832).
Client App16944 to16248 (-696), requested pool37060 to36956 (-104).
Retained fixed App112728 to111848 (-880), allocated42704 to42008 (-696).
Service complete progress futures16912 to15496 (-1416); SmallDevice15952 unchanged.
These owners must not be added to nested fields again. Requested heap excludes
allocator metadata/rounding; compiler futures are not peak stack or task reserves.

Thumbv7EM unit-transport App layouts: Small11304 to10592, fixed Service307504
to306504, allocated App28184 to27488. Replay tables4/64 remain1240/19720.
No target execution claim. Host and target use matched configured capacities.

SmallDevice uses Constrained,4routes,1Call,0deferred,4security requests,1association,
2RX/2TX datagrams1152bytes,4dedup,2Observe,no bodies. Ordinary Service uses32routes,
4Calls,8deferred,4security requests,1association,32RX/32TX datagrams1472bytes,
64dedup,32Observe,4RX/4TX bodies16384bytes. Raw qualifiers retain all configurations.

935 library,11 allocation/failure-injection,27 retained-Q,13 footprint and4
scratch-admission checks pass atd35f8ff. Final4bf0738 only adds explanation and a
scoped Clippy allowance on the intentional inline union; successful tests are
reused, exact patch/check-reuse record retained. Formatting and all-target/all-
feature strict lint pass at4bf0738. General integration review found no actionable
issue in ownership, release timing, custom Send/Sync, admission or cancellation.

Encoder frames remain1280/1296; reclaim frames544 versus baseline784–800.
Short replay copies128 payload bytes plus metadata with full256-byte capacity.
Its helper reserves8 bytes; all eight inspected caller reservations match or
shrink. Compiler reservation evidence does not establish peak stack.

Tradeoffs: the shared owner adds enum/capacity metadata already included above.
Large custom scratch switches initialized variants on body collection; startup
and custom switch costs are outside the steady-state server clock. Body-slot
release timing and4096-byte collection limit stay unchanged. Custom profiles
select ResidentRxScratch separately from temporary scratch, preserving App
Send/Sync when temporary scratch has an Rc marker. Compact equality/hash describes
active replay, excluding discarded inactive bytes. Packet staging, protected
plaintext writeback and128-byte Response payload copying remain.

Run `python -B verify.py` to verify hashes, exits, capacities, memory and independently
recompute CPU results without executing probes. `prepare.py CORE_REPO NEW_OUTPUT
candidate` reconstructs exact native sources using the pinned baseline and patch.
The unchanged fixture is sibling dispatch-scratch-20261104/fixture.
observations.zip retains exact binaries/PDBs and raw samples; diagnostics.zip has
build/check/review/lowering records; layout32.zip contains static target evidence.
Local owner/mailbox metadata is excluded. Broader qualification, if run after a
passing runtime result, is recorded separately in qualification.json/its logs.

The clock covers complete server App work with actual sync and async wait/progress,
immediate-ready memory transport and pending timer. Client preparation/authentication/
verification are outside. No network throughput/latency, executor policy, peak
memory, device qualification or new libcoap ranking follows from this cohort.
'''
(out/'README.md').write_text(readme,encoding='utf-8')

from pathlib import Path
import subprocess,json,hashlib,shutil
r=Path(__file__).resolve().parent
p=Path('D:/CoapticCurrent/replay-row-presence-20261106')
repo=Path('C:/Users/jeffg/.t3/worktrees/coaptic/t3-a578955c')
sha='d35f8ff585a7795ab25d71926bd5253fdeaa77c1';old='8fc41ead4790e25051ae90c395b012b4c8518f72'
v=json.loads((p/'source-verification.json').read_text());v['source']=sha
core=Path(v['fixture_root'])/'coaptic'
for name in v['source_file_hashes']:
 data=subprocess.check_output(['git','-C',str(repo),'show',sha+':'+name]).replace(b'\r\n',b'\n')
 if (core/name).read_bytes()!=data:(core/name).write_bytes(data)
 v['source_file_hashes'][name]=hashlib.sha256(data).hexdigest()
patch=subprocess.check_output(['git','-C',str(repo),'diff','--binary',v['baseline'],sha,'--','src','crates','tests','Cargo.toml','Cargo.lock'])
(r/'candidate.patch').write_bytes(patch);v['patch_sha256']=hashlib.sha256(patch).hexdigest()
(r/'source-verification.json').write_text(json.dumps(v,indent=2)+'\n')
for name in ['build-preflight.py','build.py','layout.py','inspect.py','inspect-inline.py','inspect-reclaim.py','check-preflight.py','baseline-reclaim-symbols.txt','measure.py','qualify.py','focused-checks.py','fixture-sha256.json']:
 (r/name).write_text((p/name).read_text().replace(old,sha))
(r/'B').mkdir(exist_ok=True);(r/'layout32').mkdir(exist_ok=True)
for name in ['audit.py','Cargo.toml','Cargo.lock','lib.rs','baseline-build.log','baseline-constants.txt','baseline-layout.txt','baseline-source.json']:
 (r/'layout32'/name).write_bytes((p/'layout32'/name).read_bytes())
m=json.loads((p/'METHOD-BEFORE.json').read_text());m['candidate']=sha
m['hypothesis']=m['source_hypothesis']='Combine replay row/index/reclaim/short-copy improvements with existing phase sharing between blockwise dispatch scratch and collected-response backing, including corrected resident/temporary scratch auto-traits. Datagram-only dispatch retains on-demand scratch. Flat response metadata borrowing remains integrated. Measure the combined App, never sum gains from separate failed cohorts.'
m['tradeoffs']='Additional internal storage state for custom scratch larger than body backing, startup admission validates separate resident and temporary bounds before entropy. Custom implementors select ResidentRxScratch; temporary scratch must not affect resident App Send/Sync. Same response collection limit and body-slot release timing. Full256 replay capacity unchanged.'
m['preflight_repair']='Preceding8fc41ea fails one retained async upper bound; original90e3ef9 scratch cohort fails four ordinary CPU bounds and has auto-trait defect correctedbf19562. Both stay rejected. This is their first combined integration, with complete checks/layout/review before one64-pair cohort under unchanged rules.'
(r/'METHOD-BEFORE.json').write_text(json.dumps(m,indent=2)+'\n');print({'source':sha,'verified_files':len(v['source_file_hashes'])})


D:\CoapticCurrent\deadline-cache-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068800:     	pushq	%rbp
140068801:     	pushq	%r15
140068803:     	pushq	%r14
140068805:     	pushq	%r13
140068807:     	pushq	%r12
140068809:     	pushq	%rsi
14006880a:     	pushq	%rdi
14006880b:     	pushq	%rbx
14006880c:     	subq	$0x508, %rsp            # imm = 0x508
140068813:     	leaq	0x80(%rsp), %rbp
14006881b:     	movq	0x500(%rbp), %r12
140068822:     	movq	0x8(%r12), %rdi
140068827:     	movl	$0x3, %r10d
14006882d:     	cmpq	$0x3, %rdi
140068831:     	ja	0x140068911 <.text+0x67911>
140068837:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
14006883f:     	jne	0x140068911 <.text+0x67911>
140068845:     	movq	0x26700(%rdx,%rdi,8), %rax
14006884d:     	cmpq	$0x4001, %rax           # imm = 0x4001
140068853:     	jae	0x140068aee <.text+0x67aee>
140068859:     	movq	0x10(%r12), %r11
14006885e:     	movq	0x18(%r12), %r15
140068863:     	movq	%r15, %rsi
140068866:     	movl	$0xb, %r10d
14006886c:     	addq	%r11, %rsi
14006886f:     	jb	0x140068911 <.text+0x67911>
140068875:     	cmpq	$0x400, %r15            # imm = 0x400
14006887c:     	ja	0x140068911 <.text+0x67911>
140068882:     	cmpq	%rax, %rsi
140068885:     	ja	0x140068911 <.text+0x67911>
14006888b:     	movq	%r8, %r13
14006888e:     	movq	%r9, 0x470(%rbp)
140068895:     	movq	%rcx, 0x480(%rbp)
14006889c:     	movzbl	0x508(%rbp), %r14d
1400688a4:     	movq	%rdi, %rax
1400688a7:     	shlq	$0xe, %rax
1400688ab:     	movq	%rdx, %rsi
1400688ae:     	leaq	(%rdx,%rax), %rbx
1400688b2:     	addq	$0x16700, %rbx          # imm = 0x16700
1400688b9:     	addq	%r11, %rbx
1400688bc:     	movl	$0x400, %r8d            # imm = 0x400
1400688c2:     	cmpq	$0x400, %r15            # imm = 0x400
1400688c9:     	je	0x1400688d8 <.text+0x678d8>
1400688cb:     	movq	%rbp, %rcx
1400688ce:     	xorl	%edx, %edx
1400688d0:     	callq	0x140250882 <.text+0x24f882>
1400688d5:     	movq	%r15, %r8
1400688d8:     	movq	%rbp, %rcx
1400688db:     	movq	%rbx, %rdx
1400688de:     	callq	0x140250870 <.text+0x24f870>
1400688e3:     	testb	%r14b, %r14b
1400688e6:     	je	0x14006892c <.text+0x6792c>
1400688e8:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
1400688ef:     	movq	%rsi, %rcx
1400688f2:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
1400688fb:     	jne	0x140068aa3 <.text+0x67aa3>
140068901:     	xorl	%edi, %edi
140068903:     	callq	0x14009b3a0 <.text+0x9a3a0>
140068908:     	testb	$0x1, %al
14006890a:     	jne	0x14006893e <.text+0x6793e>
14006890c:     	jmp	0x140068acc <.text+0x67acc>
140068911:     	movb	$0xa, (%rcx)
140068914:     	movq	%r10, 0x8(%rcx)
140068918:     	addq	$0x508, %rsp            # imm = 0x508
14006891f:     	popq	%rbx
140068920:     	popq	%rdi
140068921:     	popq	%rsi
140068922:     	popq	%r12
140068924:     	popq	%r13
140068926:     	popq	%r14
140068928:     	popq	%r15
14006892a:     	popq	%rbp
14006892b:     	retq
14006892c:     	xorl	%edi, %edi
14006892e:     	movq	%rsi, %rcx
140068931:     	callq	0x14009b3a0 <.text+0x9a3a0>
140068936:     	testb	$0x1, %al
140068938:     	je	0x140068acc <.text+0x67acc>
14006893e:     	movq	%rdx, %rbx
140068941:     	movq	0x518(%rbp), %rdx
140068948:     	movq	0x510(%rbp), %r8
14006894f:     	movzwl	0x4f8(%rbp), %ecx
140068956:     	movzbl	0x4f0(%rbp), %eax
14006895d:     	movq	(%r12), %r9
140068961:     	movq	%rdi, 0x440(%rbp)
140068968:     	movq	0x478(%rbp), %r10
14006896f:     	movq	%r10, 0x448(%rbp)
140068976:     	movq	%r9, 0x450(%rbp)
14006897d:     	movb	%r14b, 0x458(%rbp)
140068984:     	movups	0x60(%r13), %xmm0
140068989:     	movups	0x6c(%r13), %xmm1
14006898e:     	movups	%xmm1, 0x40c(%rbp)
140068995:     	movaps	%xmm0, 0x400(%rbp)
14006899c:     	leaq	0x8e(%r13), %r9
1400689a3:     	movq	0x7e(%r13), %r10
1400689a7:     	movq	0x85(%r13), %r11
1400689ae:     	movq	%r11, 0x467(%rbp)
1400689b5:     	movq	%r10, 0x460(%rbp)
1400689bc:     	leaq	0x460(%rbp), %r10
1400689c3:     	movq	%r10, 0x70(%rsp)
1400689c8:     	movq	%rdx, 0x68(%rsp)
1400689cd:     	movq	%r8, 0x60(%rsp)
1400689d2:     	movq	%r13, 0x58(%rsp)
1400689d7:     	leaq	0x440(%rbp), %rdx
1400689de:     	movq	%rdx, 0x50(%rsp)
1400689e3:     	movq	%r15, 0x48(%rsp)
1400689e8:     	movq	%rbp, %rdx
1400689eb:     	movq	%rdx, 0x40(%rsp)
1400689f0:     	movq	0x470(%rbp), %rdx
1400689f7:     	movq	%rdx, 0x38(%rsp)
1400689fc:     	movq	%r9, 0x30(%rsp)
140068a01:     	movw	%cx, 0x28(%rsp)
140068a06:     	movb	%al, 0x20(%rsp)
140068a0a:     	leaq	0x420(%rbp), %rcx
140068a11:     	leaq	0x400(%rbp), %r8
140068a18:     	movq	%rsi, %rdx
140068a1b:     	movq	%rbx, %r9
140068a1e:     	callq	0x140081890 <.text+0x80890>
140068a23:     	cmpb	$-0x1, 0x420(%rbp)
140068a2a:     	je	0x140068adb <.text+0x67adb>
140068a30:     	cmpb	$0x1, 0x37540(%rsi,%rbx)
140068a38:     	movq	0x480(%rbp), %rax
140068a3f:     	jne	0x140068a89 <.text+0x67a89>
140068a41:     	cmpb	$0x0, 0x37560(%rsi,%rbx)
140068a49:     	jne	0x140068a89 <.text+0x67a89>
140068a4b:     	movb	$0x0, 0x37540(%rsi,%rbx)
140068a53:     	decq	0x37588(%rsi)
140068a5a:     	leaq	0x37540(%rsi), %rcx
140068a61:     	movq	$0x0, 0x43410(%rsi,%rbx,8)
140068a6d:     	leaq	(%rbx,%rbx,8), %rdx
140068a71:     	leaq	(%rdx,%rdx,2), %rdx
140068a75:     	addq	%rbx, %rdx
140068a78:     	movb	$0x2, 0x36a(%rcx,%rdx)
140068a80:     	leaq	(%rbx,%rbx,2), %rdx
140068a84:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140068a89:     	movups	0x420(%rbp), %xmm0
140068a90:     	movups	0x430(%rbp), %xmm1
140068a97:     	movups	%xmm1, 0x10(%rax)
140068a9b:     	movups	%xmm0, (%rax)
140068a9e:     	jmp	0x140068918 <.text+0x67918>
140068aa3:     	addq	%rcx, %rax
140068aa6:     	addq	$0x15c28, %rax          # imm = 0x15C28
140068aac:     	movq	0x98(%rax), %rax
140068ab3:     	movq	%rax, 0x478(%rbp)
140068aba:     	movl	$0x1, %edi
140068abf:     	callq	0x14009b3a0 <.text+0x9a3a0>
140068ac4:     	testb	$0x1, %al
140068ac6:     	jne	0x14006893e <.text+0x6793e>
140068acc:     	movq	0x480(%rbp), %rax
140068ad3:     	movb	$0x9, (%rax)
140068ad6:     	jmp	0x140068918 <.text+0x67918>
140068adb:     	movq	0x480(%rbp), %rax
140068ae2:     	movq	%rbx, 0x8(%rax)
140068ae6:     	movb	$-0x1, (%rax)
140068ae9:     	jmp	0x140068918 <.text+0x67918>
140068aee:     	leaq	0x20311b(%rip), %r9     # 0x14026bc10
140068af5:     	movl	$0x4000, %r8d           # imm = 0x4000
140068afb:     	xorl	%ecx, %ecx
140068afd:     	movq	%rax, %rdx
140068b00:     	callq	0x140251300 <.text+0x250300>
140068b05:     	ud2


D:\CoapticCurrent\deadline-cache-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068b10:     	pushq	%rbp
140068b11:     	pushq	%r15
140068b13:     	pushq	%r14
140068b15:     	pushq	%r13
140068b17:     	pushq	%r12
140068b19:     	pushq	%rsi
140068b1a:     	pushq	%rdi
140068b1b:     	pushq	%rbx
140068b1c:     	subq	$0x4f8, %rsp            # imm = 0x4F8
140068b23:     	leaq	0x80(%rsp), %rbp
140068b2b:     	movq	0x4f0(%rbp), %r12
140068b32:     	movq	0x8(%r12), %rdi
140068b37:     	movl	$0x3, %r10d
140068b3d:     	cmpq	$0x3, %rdi
140068b41:     	ja	0x140068c23 <.text+0x67c23>
140068b47:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
140068b4f:     	jne	0x140068c23 <.text+0x67c23>
140068b55:     	movq	0x26700(%rdx,%rdi,8), %rax
140068b5d:     	cmpq	$0x4001, %rax           # imm = 0x4001
140068b63:     	jae	0x140068df5 <.text+0x67df5>
140068b69:     	movq	0x10(%r12), %r11
140068b6e:     	movq	0x18(%r12), %r15
140068b73:     	movq	%r15, %rsi
140068b76:     	movl	$0xb, %r10d
140068b7c:     	addq	%r11, %rsi
140068b7f:     	jb	0x140068c23 <.text+0x67c23>
140068b85:     	cmpq	$0x400, %r15            # imm = 0x400
140068b8c:     	ja	0x140068c23 <.text+0x67c23>
140068b92:     	cmpq	%rax, %rsi
140068b95:     	ja	0x140068c23 <.text+0x67c23>
140068b9b:     	movq	%r8, %r13
140068b9e:     	movq	%r9, 0x460(%rbp)
140068ba5:     	movq	%rcx, 0x470(%rbp)
140068bac:     	movzbl	0x4f8(%rbp), %r14d
140068bb4:     	movq	%rdi, %rax
140068bb7:     	shlq	$0xe, %rax
140068bbb:     	movq	%rdx, %rsi
140068bbe:     	leaq	(%rdx,%rax), %rbx
140068bc2:     	addq	$0x16700, %rbx          # imm = 0x16700
140068bc9:     	addq	%r11, %rbx
140068bcc:     	movl	$0x400, %r8d            # imm = 0x400
140068bd2:     	cmpq	$0x400, %r15            # imm = 0x400
140068bd9:     	je	0x140068be9 <.text+0x67be9>
140068bdb:     	leaq	-0x10(%rbp), %rcx
140068bdf:     	xorl	%edx, %edx
140068be1:     	callq	0x140250882 <.text+0x24f882>
140068be6:     	movq	%r15, %r8
140068be9:     	leaq	-0x10(%rbp), %rcx
140068bed:     	movq	%rbx, %rdx
140068bf0:     	callq	0x140250870 <.text+0x24f870>
140068bf5:     	testb	%r14b, %r14b
140068bf8:     	je	0x140068c3e <.text+0x67c3e>
140068bfa:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
140068c01:     	movq	%rsi, %rcx
140068c04:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
140068c0d:     	jne	0x140068daa <.text+0x67daa>
140068c13:     	xorl	%edi, %edi
140068c15:     	callq	0x14009b3a0 <.text+0x9a3a0>
140068c1a:     	testb	$0x1, %al
140068c1c:     	jne	0x140068c50 <.text+0x67c50>
140068c1e:     	jmp	0x140068dd3 <.text+0x67dd3>
140068c23:     	movb	$0xa, (%rcx)
140068c26:     	movq	%r10, 0x8(%rcx)
140068c2a:     	addq	$0x4f8, %rsp            # imm = 0x4F8
140068c31:     	popq	%rbx
140068c32:     	popq	%rdi
140068c33:     	popq	%rsi
140068c34:     	popq	%r12
140068c36:     	popq	%r13
140068c38:     	popq	%r14
140068c3a:     	popq	%r15
140068c3c:     	popq	%rbp
140068c3d:     	retq
140068c3e:     	xorl	%edi, %edi
140068c40:     	movq	%rsi, %rcx
140068c43:     	callq	0x14009b3a0 <.text+0x9a3a0>
140068c48:     	testb	$0x1, %al
140068c4a:     	je	0x140068dd3 <.text+0x67dd3>
140068c50:     	movq	%rdx, %rbx
140068c53:     	movq	0x500(%rbp), %rdx
140068c5a:     	movzwl	0x4e8(%rbp), %ecx
140068c61:     	movzbl	0x4e0(%rbp), %eax
140068c68:     	movq	(%r12), %r8
140068c6c:     	movq	%rdi, 0x430(%rbp)
140068c73:     	movq	0x468(%rbp), %r9
140068c7a:     	movq	%r9, 0x438(%rbp)
140068c81:     	movq	%r8, 0x440(%rbp)
140068c88:     	movb	%r14b, 0x448(%rbp)
140068c8f:     	movups	0x60(%r13), %xmm0
140068c94:     	movups	0x6c(%r13), %xmm1
140068c99:     	movups	%xmm1, 0x3fc(%rbp)
140068ca0:     	movaps	%xmm0, 0x3f0(%rbp)
140068ca7:     	leaq	0x8e(%r13), %r8
140068cae:     	movq	0x7e(%r13), %r9
140068cb2:     	movq	0x85(%r13), %r10
140068cb9:     	movq	%r10, 0x457(%rbp)
140068cc0:     	movq	%r9, 0x450(%rbp)
140068cc7:     	leaq	0x450(%rbp), %r9
140068cce:     	movq	%r9, 0x68(%rsp)
140068cd3:     	movq	%rdx, 0x60(%rsp)
140068cd8:     	movq	%r13, 0x58(%rsp)
140068cdd:     	leaq	0x430(%rbp), %rdx
140068ce4:     	movq	%rdx, 0x50(%rsp)
140068ce9:     	movq	%r15, 0x48(%rsp)
140068cee:     	leaq	-0x10(%rbp), %rdx
140068cf2:     	movq	%rdx, 0x40(%rsp)
140068cf7:     	movq	0x460(%rbp), %rdx
140068cfe:     	movq	%rdx, 0x38(%rsp)
140068d03:     	movq	%r8, 0x30(%rsp)
140068d08:     	movw	%cx, 0x28(%rsp)
140068d0d:     	movb	%al, 0x20(%rsp)
140068d11:     	leaq	0x410(%rbp), %rcx
140068d18:     	leaq	0x3f0(%rbp), %r8
140068d1f:     	movq	%rsi, %rdx
140068d22:     	movq	%rbx, %r9
140068d25:     	callq	0x140083080 <.text+0x82080>
140068d2a:     	cmpb	$-0x1, 0x410(%rbp)
140068d31:     	je	0x140068de2 <.text+0x67de2>
140068d37:     	cmpb	$0x1, 0x37540(%rsi,%rbx)
140068d3f:     	movq	0x470(%rbp), %rax
140068d46:     	jne	0x140068d90 <.text+0x67d90>
140068d48:     	cmpb	$0x0, 0x37560(%rsi,%rbx)
140068d50:     	jne	0x140068d90 <.text+0x67d90>
140068d52:     	movb	$0x0, 0x37540(%rsi,%rbx)
140068d5a:     	decq	0x37588(%rsi)
140068d61:     	leaq	0x37540(%rsi), %rcx
140068d68:     	movq	$0x0, 0x43410(%rsi,%rbx,8)
140068d74:     	leaq	(%rbx,%rbx,8), %rdx
140068d78:     	leaq	(%rdx,%rdx,2), %rdx
140068d7c:     	addq	%rbx, %rdx
140068d7f:     	movb	$0x2, 0x36a(%rcx,%rdx)
140068d87:     	leaq	(%rbx,%rbx,2), %rdx
140068d8b:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140068d90:     	movups	0x410(%rbp), %xmm0
140068d97:     	movups	0x420(%rbp), %xmm1
140068d9e:     	movups	%xmm1, 0x10(%rax)
140068da2:     	movups	%xmm0, (%rax)
140068da5:     	jmp	0x140068c2a <.text+0x67c2a>
140068daa:     	addq	%rcx, %rax
140068dad:     	addq	$0x15c28, %rax          # imm = 0x15C28
140068db3:     	movq	0x98(%rax), %rax
140068dba:     	movq	%rax, 0x468(%rbp)
140068dc1:     	movl	$0x1, %edi
140068dc6:     	callq	0x14009b3a0 <.text+0x9a3a0>
140068dcb:     	testb	$0x1, %al
140068dcd:     	jne	0x140068c50 <.text+0x67c50>
140068dd3:     	movq	0x470(%rbp), %rax
140068dda:     	movb	$0x9, (%rax)
140068ddd:     	jmp	0x140068c2a <.text+0x67c2a>
140068de2:     	movq	0x470(%rbp), %rax
140068de9:     	movq	%rbx, 0x8(%rax)
140068ded:     	movb	$-0x1, (%rax)
140068df0:     	jmp	0x140068c2a <.text+0x67c2a>
140068df5:     	leaq	0x202e14(%rip), %r9     # 0x14026bc10
140068dfc:     	movl	$0x4000, %r8d           # imm = 0x4000
140068e02:     	xorl	%ecx, %ecx
140068e04:     	movq	%rax, %rdx
140068e07:     	callq	0x140251300 <.text+0x250300>
140068e0c:     	ud2

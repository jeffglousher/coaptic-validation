"""Adapt the existing evidence report to the completed deadline-only cohort."""
from pathlib import Path
import json, subprocess, sys
out = Path('D:/codex-work/coaptic-validation/tools/benchmark/evidence/deadline-cache-20261106')
prior = out.parent / 'replay-chunk-staging-20261106'
v = (prior / 'render.py').read_text(encoding='utf-8')
v = v.replace('Coaptic replay and chunk staging comparison', 'Coaptic deadline cache comparison')
v = v.replace('9fa0e45', '55388e3')
v = v.replace("('replay-chunk-staging-20261106','Replay index / direct chunk initialization')", "('replay-chunk-staging-20261106','Replay index / direct chunk initialization'),('deadline-cache-20261106','Replay deadline cache / chunk initialization')")
v = v.replace('each inspected encoder adds 32 instruction bytes', 'the inspected encoder instruction sizes are retained in diagnostics')
v = v.replace('the scan index consumes 12 of those bytes. Net reduction: 4 bytes per configured replay row', 'the full-width deadline cache consumes 8 of those bytes. Net reduction: 8 bytes per configured replay row')
v = v.replace('scan-vector header', 'deadline-vector header')
v = v.replace('32-bit layout audit: regression', '32-bit layout audit: unchanged owners')
v = v.replace('<p class="bad">The cached MID/deadline row costs more than smaller 32-bit replay pins save. This independently disqualifies the integration.</p>', '<p>The 8-byte deadline cache exactly offsets the smaller replay owner on this target. App and replay-table sizes are preserved; no 32-bit memory reduction is claimed.</p>')
start = v.index('<details><summary>Checks, rejected forms and limits</summary>')
end = v.index('<p>Sync and actual async progress', start)
v = v[:start] + '<details><summary>Checks, review and limits</summary><p>Exact candidate passes 926 library tests, 11 allocation/failure-injection tests, 27 retained-Q regressions, 13 footprint checks and formatting. General read-only review found no actionable issue in cache coherence, duplicate keys, TX release order, acquired-empty slots or full-width/reversed clocks.</p><p>The previous integration failed one CPU bound and increased 32-bit memory; its raw cohort and two earlier frame-growing staging forms remain preserved separately. This candidate removes cached MID metadata and restores exact borrowed key lookup. It uses one new cohort, with no old samples reused.</p>' + v[end:]
(out / 'render.py').write_text(v, encoding='utf-8')
subprocess.run([sys.executable, '-B', str(out / 'render.py')], check=True)
r = json.loads((out / 'measurement.json').read_text())
state = 'passes the frozen CPU preservation rule' if r['runtime_accepted'] else 'fails the frozen CPU preservation rule and is rejected'
text = f'''# Deadline-only replay cache and chunk staging

Exact candidate `55388e3caf1345afd50706661030eadf00e0c15f` versus pinned baseline
`bd63199b652193b4c0a882e5840e72d992cf1362` {state}.
All 64 paired runs across 28 workloads are retained; {len(r['failed_point_guards'])}
cell upper bounds exceed 1.02. See `comparison.html` for comparable tables and
the chart. No failed source was resampled or reclassified.

The integration retains compact inline/TX replay ownership, active-owner writes
and direct initialization of full retained chunks. Only full-u64 deadlines are
cached; exact borrowed key lookup replaces the previous cached MID filter.
No capacity or clock range is reduced. The selected host SmallDevice App saves
32 bytes; Service fixed App or allocated pool saves 512 bytes. Selected complete
futures and encoder frames are unchanged. Actual Thumbv7EM App/table sizes are
unchanged, with unit transport; this is a layout audit, not device execution.

Allocated replay tables make one additional bounded startup allocation.
Requested heap excludes allocator bookkeeping/rounding. No peak-RAM, network
throughput, latency, hardware or new libcoap ranking claim follows from these
in-memory complete-server-App thread-cycle measurements.

Run `python -B verify.py` here to recompute all paired results and verify retained
bytes without executing native probes. Use `python prepare.py CORE_REPO NEW_OUTPUT
candidate` for source reconstruction; the unchanged fixture lives in sibling
`dispatch-scratch-20261104/fixture`. Exact candidate binaries/PDBs, method,
raw observations and process-exit records are in `observations.zip`.
`diagnostics.zip` retains build/test logs, review and selected disassembly.
`layout32.zip` retains source hashes, actual type layouts, LLVM constants and
the no_std audit fixture; its baseline capture is reused from the pinned audit.

Before timing: 926 library, 11 allocation/failure-injection, 27 retained-Q and
13 footprint tests passed, as did formatting. General read-only review found
no actionable correctness issue. The host and target memory records count
owners separately and do not add nested storage twice.

The earlier failures are in sibling `replay-chunk-staging-20261106` and
`replay-scan-index-20261106`; original decisions, capture failures and untimed
frame regressions remain intact. This changed-source cohort adds no replacement
samples and uses the same 64 pairs, baseline, capacities and CPU gates.
'''
(out / 'README.md').write_text(text, encoding='utf-8')


D:/CoapticCurrent/replay-active-copy-20261105/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140091700: 55                          	pushq	%rbp
140091701: 41 57                       	pushq	%r15
140091703: 41 56                       	pushq	%r14
140091705: 41 54                       	pushq	%r12
140091707: 56                          	pushq	%rsi
140091708: 57                          	pushq	%rdi
140091709: 53                          	pushq	%rbx
14009170a: 48 81 ec 60 02 00 00        	subq	$0x260, %rsp            # imm = 0x260
140091711: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
140091719: b0 01                       	movb	$0x1, %al
14009171b: 80 bd 40 02 00 00 00        	cmpb	$0x0, 0x240(%rbp)
140091722: 0f 85 60 01 00 00           	jne	0x140091888 <.text+0x90888>
140091728: 48 8b b5 58 02 00 00        	movq	0x258(%rbp), %rsi
14009172f: 0f b6 9d 50 02 00 00        	movzbl	0x250(%rbp), %ebx
140091736: 48 8b 85 48 02 00 00        	movq	0x248(%rbp), %rax
14009173d: 49 89 c2                    	movq	%rax, %r10
140091740: 49 81 c2 d8 c4 03 00        	addq	$0x3c4d8, %r10          # imm = 0x3C4D8
140091747: 49 c7 c3 ff ff ff ff        	movq	$-0x1, %r11
14009174e: 4d 0f 43 da                 	cmovaeq	%r10, %r11
140091752: 41 0f 10 00                 	movups	(%r8), %xmm0
140091756: 41 0f 10 48 0c              	movups	0xc(%r8), %xmm1
14009175b: 0f 11 8d c4 01 00 00        	movups	%xmm1, 0x1c4(%rbp)
140091762: 0f 11 85 b8 01 00 00        	movups	%xmm0, 0x1b8(%rbp)
140091769: 66 44 89 8d d4 01 00 00     	movw	%r9w, 0x1d4(%rbp)
140091771: 4c 89 9d d8 01 00 00        	movq	%r11, 0x1d8(%rbp)
140091778: 80 bc 11 40 1e 00 00 01     	cmpb	$0x1, 0x1e40(%rcx,%rdx)
140091780: 75 0a                       	jne	0x14009178c <.text+0x9078c>
140091782: 80 bc 11 42 1e 00 00 00     	cmpb	$0x0, 0x1e42(%rcx,%rdx)
14009178a: 74 1e                       	je	0x1400917aa <.text+0x907aa>
14009178c: 48 89 74 24 28              	movq	%rsi, 0x28(%rsp)
140091791: 88 5c 24 20                 	movb	%bl, 0x20(%rsp)
140091795: 4c 89 c2                    	movq	%r8, %rdx
140091798: 45 89 c8                    	movl	%r9d, %r8d
14009179b: 49 89 c1                    	movq	%rax, %r9
14009179e: e8 bd 61 00 00              	callq	0x140097960 <.text+0x96960>
1400917a3: b0 01                       	movb	$0x1, %al
1400917a5: e9 de 00 00 00              	jmp	0x140091888 <.text+0x90888>
1400917aa: c6 84 11 42 1e 00 00 01     	movb	$0x1, 0x1e42(%rcx,%rdx)
1400917b2: 48 8b bc d1 b8 1d 00 00     	movq	0x1db8(%rcx,%rdx,8), %rdi
1400917ba: 48 81 ff 81 04 00 00        	cmpq	$0x481, %rdi            # imm = 0x481
1400917c1: 0f 83 d3 00 00 00           	jae	0x14009189a <.text+0x9089a>
1400917c7: 48 81 ff 01 01 00 00        	cmpq	$0x101, %rdi            # imm = 0x101
1400917ce: 72 12                       	jb	0x1400917e2 <.text+0x907e2>
1400917d0: 66 c7 85 b0 00 00 00 02 00  	movw	$0x2, 0xb0(%rbp)
1400917d9: 48 89 95 b8 00 00 00        	movq	%rdx, 0xb8(%rbp)
1400917e0: eb 7c                       	jmp	0x14009185e <.text+0x9085e>
1400917e2: 48 85 ff                    	testq	%rdi, %rdi
1400917e5: 74 45                       	je	0x14009182c <.text+0x9082c>
1400917e7: 49 89 cf                    	movq	%rcx, %r15
1400917ea: 48 8d 81 b8 14 00 00        	leaq	0x14b8(%rcx), %rax
1400917f1: 49 89 d4                    	movq	%rdx, %r12
1400917f4: 4c 8d 34 d2                 	leaq	(%rdx,%rdx,8), %r14
1400917f8: 49 c1 e6 07                 	shlq	$0x7, %r14
1400917fc: 49 01 c6                    	addq	%rax, %r14
1400917ff: 41 b8 00 01 00 00           	movl	$0x100, %r8d            # imm = 0x100
140091805: 49 29 f8                    	subq	%rdi, %r8
140091808: 48 8d 0c 2f                 	leaq	(%rdi,%rbp), %rcx
14009180c: 48 83 c1 b0                 	addq	$-0x50, %rcx
140091810: 31 d2                       	xorl	%edx, %edx
140091812: e8 0b ee 1b 00              	callq	0x140250622 <.text+0x24f622>
140091817: 48 8d 4d b0                 	leaq	-0x50(%rbp), %rcx
14009181b: 4c 89 f2                    	movq	%r14, %rdx
14009181e: 49 89 f8                    	movq	%rdi, %r8
140091821: e8 ea ed 1b 00              	callq	0x140250610 <.text+0x24f610>
140091826: 66 b8 01 00                 	movw	$0x1, %ax
14009182a: eb 08                       	jmp	0x140091834 <.text+0x90834>
14009182c: 49 89 d4                    	movq	%rdx, %r12
14009182f: 49 89 cf                    	movq	%rcx, %r15
140091832: 31 c0                       	xorl	%eax, %eax
140091834: 66 89 85 b0 00 00 00        	movw	%ax, 0xb0(%rbp)
14009183b: 66 89 bd b2 00 00 00        	movw	%di, 0xb2(%rbp)
140091842: 48 8d 8d b4 00 00 00        	leaq	0xb4(%rbp), %rcx
140091849: 48 8d 55 b0                 	leaq	-0x50(%rbp), %rdx
14009184d: 41 b8 00 01 00 00           	movl	$0x100, %r8d            # imm = 0x100
140091853: e8 b8 ed 1b 00              	callq	0x140250610 <.text+0x24f610>
140091858: 4c 89 f9                    	movq	%r15, %rcx
14009185b: 4c 89 e2                    	movq	%r12, %rdx
14009185e: 48 81 ff 01 01 00 00        	cmpq	$0x101, %rdi            # imm = 0x101
140091865: 40 0f 92 c7                 	setb	%dil
140091869: c6 84 11 42 1e 00 00 00     	movb	$0x0, 0x1e42(%rcx,%rdx)
140091871: 48 8d 95 b0 00 00 00        	leaq	0xb0(%rbp), %rdx
140091878: 41 89 d8                    	movl	%ebx, %r8d
14009187b: 49 89 f1                    	movq	%rsi, %r9
14009187e: e8 1d 78 ff ff              	callq	0x1400890a0 <.text+0x880a0>
140091883: 34 01                       	xorb	$0x1, %al
140091885: 40 08 f8                    	orb	%dil, %al
140091888: 48 81 c4 60 02 00 00        	addq	$0x260, %rsp            # imm = 0x260
14009188f: 5b                          	popq	%rbx
140091890: 5f                          	popq	%rdi
140091891: 5e                          	popq	%rsi
140091892: 41 5c                       	popq	%r12
140091894: 41 5e                       	popq	%r14
140091896: 41 5f                       	popq	%r15
140091898: 5d                          	popq	%rbp
140091899: c3                          	retq
14009189a: 4c 8d 0d 37 a1 1d 00        	leaq	0x1da137(%rip), %r9     # 0x14026b9d8
1400918a1: 41 b8 80 04 00 00           	movl	$0x480, %r8d            # imm = 0x480
1400918a7: 31 c9                       	xorl	%ecx, %ecx
1400918a9: 48 89 fa                    	movq	%rdi, %rdx
1400918ac: e8 af f7 1b 00              	callq	0x140251060 <.text+0x250060>
1400918b1: 0f 0b                       	ud2

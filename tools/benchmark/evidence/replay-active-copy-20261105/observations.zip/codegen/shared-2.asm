
D:/CoapticCurrent/replay-storage-20261105/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140091720: 55                          	pushq	%rbp
140091721: 41 57                       	pushq	%r15
140091723: 41 56                       	pushq	%r14
140091725: 41 54                       	pushq	%r12
140091727: 56                          	pushq	%rsi
140091728: 57                          	pushq	%rdi
140091729: 53                          	pushq	%rbx
14009172a: 48 81 ec 60 02 00 00        	subq	$0x260, %rsp            # imm = 0x260
140091731: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
140091739: b0 01                       	movb	$0x1, %al
14009173b: 80 bd 40 02 00 00 00        	cmpb	$0x0, 0x240(%rbp)
140091742: 0f 85 60 01 00 00           	jne	0x1400918a8 <.text+0x908a8>
140091748: 48 8b b5 58 02 00 00        	movq	0x258(%rbp), %rsi
14009174f: 0f b6 9d 50 02 00 00        	movzbl	0x250(%rbp), %ebx
140091756: 48 8b 85 48 02 00 00        	movq	0x248(%rbp), %rax
14009175d: 49 89 c2                    	movq	%rax, %r10
140091760: 49 81 c2 d8 c4 03 00        	addq	$0x3c4d8, %r10          # imm = 0x3C4D8
140091767: 49 c7 c3 ff ff ff ff        	movq	$-0x1, %r11
14009176e: 4d 0f 43 da                 	cmovaeq	%r10, %r11
140091772: 41 0f 10 00                 	movups	(%r8), %xmm0
140091776: 41 0f 10 48 0c              	movups	0xc(%r8), %xmm1
14009177b: 0f 11 8d c4 01 00 00        	movups	%xmm1, 0x1c4(%rbp)
140091782: 0f 11 85 b8 01 00 00        	movups	%xmm0, 0x1b8(%rbp)
140091789: 66 44 89 8d d4 01 00 00     	movw	%r9w, 0x1d4(%rbp)
140091791: 4c 89 9d d8 01 00 00        	movq	%r11, 0x1d8(%rbp)
140091798: 80 bc 11 40 1e 00 00 01     	cmpb	$0x1, 0x1e40(%rcx,%rdx)
1400917a0: 75 0a                       	jne	0x1400917ac <.text+0x907ac>
1400917a2: 80 bc 11 42 1e 00 00 00     	cmpb	$0x0, 0x1e42(%rcx,%rdx)
1400917aa: 74 1e                       	je	0x1400917ca <.text+0x907ca>
1400917ac: 48 89 74 24 28              	movq	%rsi, 0x28(%rsp)
1400917b1: 88 5c 24 20                 	movb	%bl, 0x20(%rsp)
1400917b5: 4c 89 c2                    	movq	%r8, %rdx
1400917b8: 45 89 c8                    	movl	%r9d, %r8d
1400917bb: 49 89 c1                    	movq	%rax, %r9
1400917be: e8 bd 61 00 00              	callq	0x140097980 <.text+0x96980>
1400917c3: b0 01                       	movb	$0x1, %al
1400917c5: e9 de 00 00 00              	jmp	0x1400918a8 <.text+0x908a8>
1400917ca: c6 84 11 42 1e 00 00 01     	movb	$0x1, 0x1e42(%rcx,%rdx)
1400917d2: 48 8b bc d1 b8 1d 00 00     	movq	0x1db8(%rcx,%rdx,8), %rdi
1400917da: 48 81 ff 81 04 00 00        	cmpq	$0x481, %rdi            # imm = 0x481
1400917e1: 0f 83 d3 00 00 00           	jae	0x1400918ba <.text+0x908ba>
1400917e7: 48 81 ff 01 01 00 00        	cmpq	$0x101, %rdi            # imm = 0x101
1400917ee: 72 12                       	jb	0x140091802 <.text+0x90802>
1400917f0: 66 c7 85 b0 00 00 00 02 00  	movw	$0x2, 0xb0(%rbp)
1400917f9: 48 89 95 b8 00 00 00        	movq	%rdx, 0xb8(%rbp)
140091800: eb 7c                       	jmp	0x14009187e <.text+0x9087e>
140091802: 48 85 ff                    	testq	%rdi, %rdi
140091805: 74 45                       	je	0x14009184c <.text+0x9084c>
140091807: 49 89 cf                    	movq	%rcx, %r15
14009180a: 48 8d 81 b8 14 00 00        	leaq	0x14b8(%rcx), %rax
140091811: 49 89 d4                    	movq	%rdx, %r12
140091814: 4c 8d 34 d2                 	leaq	(%rdx,%rdx,8), %r14
140091818: 49 c1 e6 07                 	shlq	$0x7, %r14
14009181c: 49 01 c6                    	addq	%rax, %r14
14009181f: 41 b8 00 01 00 00           	movl	$0x100, %r8d            # imm = 0x100
140091825: 49 29 f8                    	subq	%rdi, %r8
140091828: 48 8d 0c 2f                 	leaq	(%rdi,%rbp), %rcx
14009182c: 48 83 c1 b0                 	addq	$-0x50, %rcx
140091830: 31 d2                       	xorl	%edx, %edx
140091832: e8 bb ef 1b 00              	callq	0x1402507f2 <.text+0x24f7f2>
140091837: 48 8d 4d b0                 	leaq	-0x50(%rbp), %rcx
14009183b: 4c 89 f2                    	movq	%r14, %rdx
14009183e: 49 89 f8                    	movq	%rdi, %r8
140091841: e8 9a ef 1b 00              	callq	0x1402507e0 <.text+0x24f7e0>
140091846: 66 b8 01 00                 	movw	$0x1, %ax
14009184a: eb 08                       	jmp	0x140091854 <.text+0x90854>
14009184c: 49 89 d4                    	movq	%rdx, %r12
14009184f: 49 89 cf                    	movq	%rcx, %r15
140091852: 31 c0                       	xorl	%eax, %eax
140091854: 66 89 85 b0 00 00 00        	movw	%ax, 0xb0(%rbp)
14009185b: 66 89 bd b2 00 00 00        	movw	%di, 0xb2(%rbp)
140091862: 48 8d 8d b4 00 00 00        	leaq	0xb4(%rbp), %rcx
140091869: 48 8d 55 b0                 	leaq	-0x50(%rbp), %rdx
14009186d: 41 b8 00 01 00 00           	movl	$0x100, %r8d            # imm = 0x100
140091873: e8 68 ef 1b 00              	callq	0x1402507e0 <.text+0x24f7e0>
140091878: 4c 89 f9                    	movq	%r15, %rcx
14009187b: 4c 89 e2                    	movq	%r12, %rdx
14009187e: 48 81 ff 01 01 00 00        	cmpq	$0x101, %rdi            # imm = 0x101
140091885: 40 0f 92 c7                 	setb	%dil
140091889: c6 84 11 42 1e 00 00 00     	movb	$0x0, 0x1e42(%rcx,%rdx)
140091891: 48 8d 95 b0 00 00 00        	leaq	0xb0(%rbp), %rdx
140091898: 41 89 d8                    	movl	%ebx, %r8d
14009189b: 49 89 f1                    	movq	%rsi, %r9
14009189e: e8 8d 79 ff ff              	callq	0x140089230 <.text+0x88230>
1400918a3: 34 01                       	xorb	$0x1, %al
1400918a5: 40 08 f8                    	orb	%dil, %al
1400918a8: 48 81 c4 60 02 00 00        	addq	$0x260, %rsp            # imm = 0x260
1400918af: 5b                          	popq	%rbx
1400918b0: 5f                          	popq	%rdi
1400918b1: 5e                          	popq	%rsi
1400918b2: 41 5c                       	popq	%r12
1400918b4: 41 5e                       	popq	%r14
1400918b6: 41 5f                       	popq	%r15
1400918b8: 5d                          	popq	%rbp
1400918b9: c3                          	retq
1400918ba: 4c 8d 0d 6f a0 1d 00        	leaq	0x1da06f(%rip), %r9     # 0x14026b930
1400918c1: 41 b8 80 04 00 00           	movl	$0x480, %r8d            # imm = 0x480
1400918c7: 31 c9                       	xorl	%ecx, %ecx
1400918c9: 48 89 fa                    	movq	%rdi, %rdx
1400918cc: e8 5f f9 1b 00              	callq	0x140251230 <.text+0x250230>
1400918d1: 0f 0b                       	ud2

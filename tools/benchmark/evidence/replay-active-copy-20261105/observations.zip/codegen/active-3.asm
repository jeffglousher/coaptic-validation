
D:/CoapticCurrent/replay-active-copy-20261105/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140091c40: 55                          	pushq	%rbp
140091c41: 41 57                       	pushq	%r15
140091c43: 41 56                       	pushq	%r14
140091c45: 41 55                       	pushq	%r13
140091c47: 41 54                       	pushq	%r12
140091c49: 56                          	pushq	%rsi
140091c4a: 57                          	pushq	%rdi
140091c4b: 53                          	pushq	%rbx
140091c4c: 48 81 ec 68 02 00 00        	subq	$0x268, %rsp            # imm = 0x268
140091c53: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
140091c5b: b0 01                       	movb	$0x1, %al
140091c5d: 80 bd 50 02 00 00 00        	cmpb	$0x0, 0x250(%rbp)
140091c64: 0f 85 db 00 00 00           	jne	0x140091d45 <.text+0x90d45>
140091c6a: 48 8b b5 68 02 00 00        	movq	0x268(%rbp), %rsi
140091c71: 0f b6 9d 60 02 00 00        	movzbl	0x260(%rbp), %ebx
140091c78: 48 8b 85 58 02 00 00        	movq	0x258(%rbp), %rax
140091c7f: 49 89 c2                    	movq	%rax, %r10
140091c82: 49 81 c2 d8 c4 03 00        	addq	$0x3c4d8, %r10          # imm = 0x3C4D8
140091c89: 49 c7 c3 ff ff ff ff        	movq	$-0x1, %r11
140091c90: 4d 0f 43 da                 	cmovaeq	%r10, %r11
140091c94: 41 0f 10 00                 	movups	(%r8), %xmm0
140091c98: 41 0f 10 48 0c              	movups	0xc(%r8), %xmm1
140091c9d: 0f 11 8d cc 01 00 00        	movups	%xmm1, 0x1cc(%rbp)
140091ca4: 0f 11 85 c0 01 00 00        	movups	%xmm0, 0x1c0(%rbp)
140091cab: 66 44 89 8d dc 01 00 00     	movw	%r9w, 0x1dc(%rbp)
140091cb3: 4c 89 9d e0 01 00 00        	movq	%r11, 0x1e0(%rbp)
140091cba: 48 3b 91 88 00 00 00        	cmpq	0x88(%rcx), %rdx
140091cc1: 73 69                       	jae	0x140091d2c <.text+0x90d2c>
140091cc3: 4c 8b 91 80 00 00 00        	movq	0x80(%rcx), %r10
140091cca: 41 80 3c 12 01              	cmpb	$0x1, (%r10,%rdx)
140091ccf: 75 5b                       	jne	0x140091d2c <.text+0x90d2c>
140091cd1: 48 3b 91 a0 00 00 00        	cmpq	0xa0(%rcx), %rdx
140091cd8: 73 52                       	jae	0x140091d2c <.text+0x90d2c>
140091cda: 4c 8b b9 98 00 00 00        	movq	0x98(%rcx), %r15
140091ce1: 41 80 3c 17 00              	cmpb	$0x0, (%r15,%rdx)
140091ce6: 75 44                       	jne	0x140091d2c <.text+0x90d2c>
140091ce8: 41 c6 04 17 01              	movb	$0x1, (%r15,%rdx)
140091ced: 48 3b 51 70                 	cmpq	0x70(%rcx), %rdx
140091cf1: 73 39                       	jae	0x140091d2c <.text+0x90d2c>
140091cf3: 48 8b 41 68                 	movq	0x68(%rcx), %rax
140091cf7: 4c 6b ca 58                 	imulq	$0x58, %rdx, %r9
140091cfb: 4e 8b 44 08 10              	movq	0x10(%rax,%r9), %r8
140091d00: 4a 8b 7c 08 30              	movq	0x30(%rax,%r9), %rdi
140091d05: 4c 39 c7                    	cmpq	%r8, %rdi
140091d08: 0f 87 e2 00 00 00           	ja	0x140091df0 <.text+0x90df0>
140091d0e: 48 81 ff 01 01 00 00        	cmpq	$0x101, %rdi            # imm = 0x101
140091d15: 72 42                       	jb	0x140091d59 <.text+0x90d59>
140091d17: 66 c7 85 b8 00 00 00 02 00  	movw	$0x2, 0xb8(%rbp)
140091d20: 48 89 95 c0 00 00 00        	movq	%rdx, 0xc0(%rbp)
140091d27: e9 98 00 00 00              	jmp	0x140091dc4 <.text+0x90dc4>
140091d2c: 48 89 74 24 28              	movq	%rsi, 0x28(%rsp)
140091d31: 88 5c 24 20                 	movb	%bl, 0x20(%rsp)
140091d35: 4c 89 c2                    	movq	%r8, %rdx
140091d38: 45 89 c8                    	movl	%r9d, %r8d
140091d3b: 49 89 c1                    	movq	%rax, %r9
140091d3e: e8 cd 63 00 00              	callq	0x140098110 <.text+0x97110>
140091d43: b0 01                       	movb	$0x1, %al
140091d45: 48 81 c4 68 02 00 00        	addq	$0x268, %rsp            # imm = 0x268
140091d4c: 5b                          	popq	%rbx
140091d4d: 5f                          	popq	%rdi
140091d4e: 5e                          	popq	%rsi
140091d4f: 41 5c                       	popq	%r12
140091d51: 41 5d                       	popq	%r13
140091d53: 41 5e                       	popq	%r14
140091d55: 41 5f                       	popq	%r15
140091d57: 5d                          	popq	%rbp
140091d58: c3                          	retq
140091d59: 49 89 d4                    	movq	%rdx, %r12
140091d5c: 49 89 cd                    	movq	%rcx, %r13
140091d5f: 48 85 ff                    	testq	%rdi, %rdi
140091d62: 74 34                       	je	0x140091d98 <.text+0x90d98>
140091d64: 4c 01 c8                    	addq	%r9, %rax
140091d67: 4c 8b 70 08                 	movq	0x8(%rax), %r14
140091d6b: 41 b8 00 01 00 00           	movl	$0x100, %r8d            # imm = 0x100
140091d71: 49 29 f8                    	subq	%rdi, %r8
140091d74: 48 8d 0c 2f                 	leaq	(%rdi,%rbp), %rcx
140091d78: 48 83 c1 b8                 	addq	$-0x48, %rcx
140091d7c: 31 d2                       	xorl	%edx, %edx
140091d7e: e8 9f e8 1b 00              	callq	0x140250622 <.text+0x24f622>
140091d83: 48 8d 4d b8                 	leaq	-0x48(%rbp), %rcx
140091d87: 4c 89 f2                    	movq	%r14, %rdx
140091d8a: 49 89 f8                    	movq	%rdi, %r8
140091d8d: e8 7e e8 1b 00              	callq	0x140250610 <.text+0x24f610>
140091d92: 66 b8 01 00                 	movw	$0x1, %ax
140091d96: eb 02                       	jmp	0x140091d9a <.text+0x90d9a>
140091d98: 31 c0                       	xorl	%eax, %eax
140091d9a: 66 89 85 b8 00 00 00        	movw	%ax, 0xb8(%rbp)
140091da1: 66 89 bd ba 00 00 00        	movw	%di, 0xba(%rbp)
140091da8: 48 8d 8d bc 00 00 00        	leaq	0xbc(%rbp), %rcx
140091daf: 48 8d 55 b8                 	leaq	-0x48(%rbp), %rdx
140091db3: 41 b8 00 01 00 00           	movl	$0x100, %r8d            # imm = 0x100
140091db9: e8 52 e8 1b 00              	callq	0x140250610 <.text+0x24f610>
140091dbe: 4c 89 e9                    	movq	%r13, %rcx
140091dc1: 4c 89 e2                    	movq	%r12, %rdx
140091dc4: 48 81 ff 01 01 00 00        	cmpq	$0x101, %rdi            # imm = 0x101
140091dcb: 40 0f 92 c7                 	setb	%dil
140091dcf: 41 c6 04 17 00              	movb	$0x0, (%r15,%rdx)
140091dd4: 48 8d 95 b8 00 00 00        	leaq	0xb8(%rbp), %rdx
140091ddb: 41 89 d8                    	movl	%ebx, %r8d
140091dde: 49 89 f1                    	movq	%rsi, %r9
140091de1: e8 1a 87 ff ff              	callq	0x14008a500 <.text+0x89500>
140091de6: 34 01                       	xorb	$0x1, %al
140091de8: 40 08 f8                    	orb	%dil, %al
140091deb: e9 55 ff ff ff              	jmp	0x140091d45 <.text+0x90d45>
140091df0: 4c 8d 0d 29 d3 1c 00        	leaq	0x1cd329(%rip), %r9     # 0x14025f120
140091df7: 31 c9                       	xorl	%ecx, %ecx
140091df9: 48 89 fa                    	movq	%rdi, %rdx
140091dfc: e8 5f f2 1b 00              	callq	0x140251060 <.text+0x250060>
140091e01: 0f 0b                       	ud2

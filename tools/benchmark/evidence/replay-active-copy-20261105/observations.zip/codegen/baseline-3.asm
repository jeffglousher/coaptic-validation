
D:/CoapticCurrent/oscore-packet-staging-20261104/option-reuse/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140091a40: 55                          	pushq	%rbp
140091a41: 41 57                       	pushq	%r15
140091a43: 41 56                       	pushq	%r14
140091a45: 41 54                       	pushq	%r12
140091a47: 56                          	pushq	%rsi
140091a48: 57                          	pushq	%rdi
140091a49: 53                          	pushq	%rbx
140091a4a: 48 81 ec 70 01 00 00        	subq	$0x170, %rsp            # imm = 0x170
140091a51: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
140091a59: b0 01                       	movb	$0x1, %al
140091a5b: 80 bd 50 01 00 00 00        	cmpb	$0x0, 0x150(%rbp)
140091a62: 0f 85 26 01 00 00           	jne	0x140091b8e <.text+0x90b8e>
140091a68: 48 8b b5 68 01 00 00        	movq	0x168(%rbp), %rsi
140091a6f: 0f b6 9d 60 01 00 00        	movzbl	0x160(%rbp), %ebx
140091a76: 48 8b 85 58 01 00 00        	movq	0x158(%rbp), %rax
140091a7d: 49 89 c2                    	movq	%rax, %r10
140091a80: 49 81 c2 d8 c4 03 00        	addq	$0x3c4d8, %r10          # imm = 0x3C4D8
140091a87: 49 c7 c3 ff ff ff ff        	movq	$-0x1, %r11
140091a8e: 4d 0f 43 da                 	cmovaeq	%r10, %r11
140091a92: 0f 57 c0                    	xorps	%xmm0, %xmm0
140091a95: 0f 11 85 d8 00 00 00        	movups	%xmm0, 0xd8(%rbp)
140091a9c: 0f 11 85 c8 00 00 00        	movups	%xmm0, 0xc8(%rbp)
140091aa3: 0f 11 85 b8 00 00 00        	movups	%xmm0, 0xb8(%rbp)
140091aaa: 0f 11 85 a8 00 00 00        	movups	%xmm0, 0xa8(%rbp)
140091ab1: 0f 11 85 98 00 00 00        	movups	%xmm0, 0x98(%rbp)
140091ab8: 0f 11 85 88 00 00 00        	movups	%xmm0, 0x88(%rbp)
140091abf: 0f 11 45 78                 	movups	%xmm0, 0x78(%rbp)
140091ac3: 0f 11 45 68                 	movups	%xmm0, 0x68(%rbp)
140091ac7: 0f 11 45 58                 	movups	%xmm0, 0x58(%rbp)
140091acb: 0f 11 45 48                 	movups	%xmm0, 0x48(%rbp)
140091acf: 0f 11 45 38                 	movups	%xmm0, 0x38(%rbp)
140091ad3: 0f 11 45 28                 	movups	%xmm0, 0x28(%rbp)
140091ad7: 0f 11 45 18                 	movups	%xmm0, 0x18(%rbp)
140091adb: 0f 11 45 08                 	movups	%xmm0, 0x8(%rbp)
140091adf: 0f 11 45 f8                 	movups	%xmm0, -0x8(%rbp)
140091ae3: 0f 11 45 e8                 	movups	%xmm0, -0x18(%rbp)
140091ae7: 41 0f 10 00                 	movups	(%r8), %xmm0
140091aeb: 41 0f 10 48 0c              	movups	0xc(%r8), %xmm1
140091af0: 0f 11 45 c0                 	movups	%xmm0, -0x40(%rbp)
140091af4: 0f 11 4d cc                 	movups	%xmm1, -0x34(%rbp)
140091af8: 66 44 89 4d dc              	movw	%r9w, -0x24(%rbp)
140091afd: 4c 89 5d e0                 	movq	%r11, -0x20(%rbp)
140091b01: 48 3b 91 88 00 00 00        	cmpq	0x88(%rcx), %rdx
140091b08: 73 6b                       	jae	0x140091b75 <.text+0x90b75>
140091b0a: 4c 8b 91 80 00 00 00        	movq	0x80(%rcx), %r10
140091b11: 41 80 3c 12 01              	cmpb	$0x1, (%r10,%rdx)
140091b16: 75 5d                       	jne	0x140091b75 <.text+0x90b75>
140091b18: 48 3b 91 a0 00 00 00        	cmpq	0xa0(%rcx), %rdx
140091b1f: 73 54                       	jae	0x140091b75 <.text+0x90b75>
140091b21: 4c 8b b1 98 00 00 00        	movq	0x98(%rcx), %r14
140091b28: 41 80 3c 16 00              	cmpb	$0x0, (%r14,%rdx)
140091b2d: 75 46                       	jne	0x140091b75 <.text+0x90b75>
140091b2f: 41 c6 04 16 01              	movb	$0x1, (%r14,%rdx)
140091b34: 48 3b 51 70                 	cmpq	0x70(%rcx), %rdx
140091b38: 73 3b                       	jae	0x140091b75 <.text+0x90b75>
140091b3a: 4c 8b 49 68                 	movq	0x68(%rcx), %r9
140091b3e: 4c 6b d2 58                 	imulq	$0x58, %rdx, %r10
140091b42: 4f 8b 44 11 10              	movq	0x10(%r9,%r10), %r8
140091b47: 4b 8b 7c 11 30              	movq	0x30(%r9,%r10), %rdi
140091b4c: 4c 39 c7                    	cmpq	%r8, %rdi
140091b4f: 0f 87 a5 00 00 00           	ja	0x140091bfa <.text+0x90bfa>
140091b55: 48 81 ff 01 01 00 00        	cmpq	$0x101, %rdi            # imm = 0x101
140091b5c: 72 42                       	jb	0x140091ba0 <.text+0x90ba0>
140091b5e: 48 c7 45 b0 01 00 00 00     	movq	$0x1, -0x50(%rbp)
140091b66: 48 89 55 b8                 	movq	%rdx, -0x48(%rbp)
140091b6a: 66 c7 85 e8 00 00 00 00 00  	movw	$0x0, 0xe8(%rbp)
140091b73: eb 5f                       	jmp	0x140091bd4 <.text+0x90bd4>
140091b75: 48 89 74 24 28              	movq	%rsi, 0x28(%rsp)
140091b7a: 88 5c 24 20                 	movb	%bl, 0x20(%rsp)
140091b7e: 4c 89 c2                    	movq	%r8, %rdx
140091b81: 45 89 c8                    	movl	%r9d, %r8d
140091b84: 49 89 c1                    	movq	%rax, %r9
140091b87: e8 34 64 00 00              	callq	0x140097fc0 <.text+0x96fc0>
140091b8c: b0 01                       	movb	$0x1, %al
140091b8e: 48 81 c4 70 01 00 00        	addq	$0x170, %rsp            # imm = 0x170
140091b95: 5b                          	popq	%rbx
140091b96: 5f                          	popq	%rdi
140091b97: 5e                          	popq	%rsi
140091b98: 41 5c                       	popq	%r12
140091b9a: 41 5e                       	popq	%r14
140091b9c: 41 5f                       	popq	%r15
140091b9e: 5d                          	popq	%rbp
140091b9f: c3                          	retq
140091ba0: 48 8d 45 e8                 	leaq	-0x18(%rbp), %rax
140091ba4: 4d 01 d1                    	addq	%r10, %r9
140091ba7: 4d 8b 41 08                 	movq	0x8(%r9), %r8
140091bab: 49 89 cf                    	movq	%rcx, %r15
140091bae: 48 89 c1                    	movq	%rax, %rcx
140091bb1: 49 89 d4                    	movq	%rdx, %r12
140091bb4: 4c 89 c2                    	movq	%r8, %rdx
140091bb7: 49 89 f8                    	movq	%rdi, %r8
140091bba: e8 51 f2 1b 00              	callq	0x140250e10 <.text+0x24fe10>
140091bbf: 4c 89 e2                    	movq	%r12, %rdx
140091bc2: 4c 89 f9                    	movq	%r15, %rcx
140091bc5: 66 89 bd e8 00 00 00        	movw	%di, 0xe8(%rbp)
140091bcc: 48 c7 45 b0 00 00 00 00     	movq	$0x0, -0x50(%rbp)
140091bd4: 48 81 ff 01 01 00 00        	cmpq	$0x101, %rdi            # imm = 0x101
140091bdb: 40 0f 92 c7                 	setb	%dil
140091bdf: 41 c6 04 16 00              	movb	$0x0, (%r14,%rdx)
140091be4: 48 8d 55 b0                 	leaq	-0x50(%rbp), %rdx
140091be8: 41 89 d8                    	movl	%ebx, %r8d
140091beb: 49 89 f1                    	movq	%rsi, %r9
140091bee: e8 9d 87 ff ff              	callq	0x14008a390 <.text+0x89390>
140091bf3: 34 01                       	xorb	$0x1, %al
140091bf5: 40 08 f8                    	orb	%dil, %al
140091bf8: eb 94                       	jmp	0x140091b8e <.text+0x90b8e>
140091bfa: 4c 8d 0d 27 e5 1c 00        	leaq	0x1ce527(%rip), %r9     # 0x140260128
140091c01: 31 c9                       	xorl	%ecx, %ecx
140091c03: 48 89 fa                    	movq	%rdi, %rdx
140091c06: e8 55 fc 1b 00              	callq	0x140251860 <.text+0x250860>
140091c0b: 0f 0b                       	ud2

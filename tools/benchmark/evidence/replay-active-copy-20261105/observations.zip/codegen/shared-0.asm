
D:/CoapticCurrent/replay-storage-20261105/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140089230: 55                          	pushq	%rbp
140089231: 41 57                       	pushq	%r15
140089233: 41 56                       	pushq	%r14
140089235: 41 55                       	pushq	%r13
140089237: 41 54                       	pushq	%r12
140089239: 56                          	pushq	%rsi
14008923a: 57                          	pushq	%rdi
14008923b: 53                          	pushq	%rbx
14008923c: 48 81 ec 98 00 00 00        	subq	$0x98, %rsp
140089243: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
14008924b: 0f 29 75 00                 	movaps	%xmm6, (%rbp)
14008924f: 4c 89 ce                    	movq	%r9, %rsi
140089252: 48 8b 82 08 01 00 00        	movq	0x108(%rdx), %rax
140089259: 48 89 45 e8                 	movq	%rax, -0x18(%rbp)
14008925d: 48 8b 82 10 01 00 00        	movq	0x110(%rdx), %rax
140089264: 48 89 45 e0                 	movq	%rax, -0x20(%rbp)
140089268: 8b 82 18 01 00 00           	movl	0x118(%rdx), %eax
14008926e: 89 45 f0                    	movl	%eax, -0x10(%rbp)
140089271: 8b 82 1c 01 00 00           	movl	0x11c(%rdx), %eax
140089277: 89 45 f4                    	movl	%eax, -0xc(%rbp)
14008927a: 0f b7 82 20 01 00 00        	movzwl	0x120(%rdx), %eax
140089281: 66 89 45 fc                 	movw	%ax, -0x4(%rbp)
140089285: 0f b6 82 22 01 00 00        	movzbl	0x122(%rdx), %eax
14008928c: 88 45 ff                    	movb	%al, -0x1(%rbp)
14008928f: 0f b6 82 23 01 00 00        	movzbl	0x123(%rdx), %eax
140089296: 88 45 f9                    	movb	%al, -0x7(%rbp)
140089299: f3 0f 10 b2 24 01 00 00     	movss	0x124(%rdx), %xmm6
1400892a1: 0f b7 82 24 01 00 00        	movzwl	0x124(%rdx), %eax
1400892a8: 66 89 45 fa                 	movw	%ax, -0x6(%rbp)
1400892ac: 48 8b 82 28 01 00 00        	movq	0x128(%rdx), %rax
1400892b3: 48 89 45 c0                 	movq	%rax, -0x40(%rbp)
1400892b7: 0f b7 02                    	movzwl	(%rdx), %eax
1400892ba: 85 c0                       	testl	%eax, %eax
1400892bc: 0f 84 f7 01 00 00           	je	0x1400894b9 <.text+0x884b9>
1400892c2: 48 89 cb                    	movq	%rcx, %rbx
1400892c5: 83 f8 01                    	cmpl	$0x1, %eax
1400892c8: 75 10                       	jne	0x1400892da <.text+0x882da>
1400892ca: 0f b7 42 02                 	movzwl	0x2(%rdx), %eax
1400892ce: 48 3d 01 01 00 00           	cmpq	$0x101, %rax            # imm = 0x101
1400892d4: 0f 83 e9 04 00 00           	jae	0x1400897c3 <.text+0x887c3>
1400892da: 44 88 45 fe                 	movb	%r8b, -0x2(%rbp)
1400892de: 48 8d 83 b8 14 00 00        	leaq	0x14b8(%rbx), %rax
1400892e5: 48 89 45 d0                 	movq	%rax, -0x30(%rbp)
1400892e9: 48 8d 83 28 05 00 00        	leaq	0x528(%rbx), %rax
1400892f0: 48 89 45 c8                 	movq	%rax, -0x38(%rbp)
1400892f4: 4c 8d bb f8 09 00 00        	leaq	0x9f8(%rbx), %r15
1400892fb: 48 8d 83 50 06 00 00        	leaq	0x650(%rbx), %rax
140089302: 45 31 db                    	xorl	%r11d, %r11d
140089305: b9 01 00 00 00              	movl	$0x1, %ecx
14008930a: 31 ff                       	xorl	%edi, %edi
14008930c: 4d 69 d3 30 01 00 00        	imulq	$0x130, %r11, %r10      # imm = 0x130
140089313: 49 01 c2                    	addq	%rax, %r10
140089316: 4d 89 d9                    	movq	%r11, %r9
140089319: eb 19                       	jmp	0x140089334 <.text+0x88334>
14008931b: 0f 1f 44 00 00              	nopl	(%rax,%rax)
140089320: 49 ff c1                    	incq	%r9
140089323: 49 81 c2 30 01 00 00        	addq	$0x130, %r10            # imm = 0x130
14008932a: 49 83 f9 04                 	cmpq	$0x4, %r9
14008932e: 0f 84 97 00 00 00           	je	0x1400893cb <.text+0x883cb>
140089334: 43 80 3c 0f 00              	cmpb	$0x0, (%r15,%r9)
140089339: 74 e5                       	je	0x140089320 <.text+0x88320>
14008933b: 45 0f b7 9a d8 fe ff ff     	movzwl	-0x128(%r10), %r11d
140089343: 66 41 83 fb ff              	cmpw	$-0x1, %r11w
140089348: 74 d6                       	je	0x140089320 <.text+0x88320>
14008934a: 44 0f b7 75 fa              	movzwl	-0x6(%rbp), %r14d
14008934f: 66 45 39 72 fc              	cmpw	%r14w, -0x4(%r10)
140089354: 75 44                       	jne	0x14008939a <.text+0x8839a>
140089356: 44 8b 75 f0                 	movl	-0x10(%rbp), %r14d
14008935a: 45 39 72 f0                 	cmpl	%r14d, -0x10(%r10)
14008935e: 75 3a                       	jne	0x14008939a <.text+0x8839a>
140089360: 44 8b 75 f4                 	movl	-0xc(%rbp), %r14d
140089364: 45 39 72 f4                 	cmpl	%r14d, -0xc(%r10)
140089368: 75 30                       	jne	0x14008939a <.text+0x8839a>
14008936a: 44 0f b7 75 fc              	movzwl	-0x4(%rbp), %r14d
14008936f: 66 45 39 72 f8              	cmpw	%r14w, -0x8(%r10)
140089374: 75 24                       	jne	0x14008939a <.text+0x8839a>
140089376: 44 0f b6 75 ff              	movzbl	-0x1(%rbp), %r14d
14008937b: 45 38 72 fa                 	cmpb	%r14b, -0x6(%r10)
14008937f: 75 19                       	jne	0x14008939a <.text+0x8839a>
140089381: 4d 8b 72 e0                 	movq	-0x20(%r10), %r14
140089385: 4c 33 75 e8                 	xorq	-0x18(%rbp), %r14
140089389: 4d 8b 62 e8                 	movq	-0x18(%r10), %r12
14008938d: 4c 33 65 e0                 	xorq	-0x20(%rbp), %r12
140089391: 4d 09 f4                    	orq	%r14, %r12
140089394: 0f 84 80 03 00 00           	je	0x14008971a <.text+0x8871a>
14008939a: 4d 8b 12                    	movq	(%r10), %r10
14008939d: 4d 39 c2                    	cmpq	%r8, %r10
1400893a0: 41 0f 93 c3                 	setae	%r11b
1400893a4: 41 20 fb                    	andb	%dil, %r11b
1400893a7: 4d 85 d2                    	testq	%r10, %r10
1400893aa: 48 0f 45 f9                 	cmovneq	%rcx, %rdi
1400893ae: 41 0f 94 c6                 	sete	%r14b
1400893b2: 45 08 de                    	orb	%r11b, %r14b
1400893b5: 4d 0f 44 e9                 	cmoveq	%r9, %r13
1400893b9: 4d 8d 59 01                 	leaq	0x1(%r9), %r11
1400893bd: 4d 0f 44 c2                 	cmoveq	%r10, %r8
1400893c1: 49 83 f9 03                 	cmpq	$0x3, %r9
1400893c5: 0f 82 41 ff ff ff           	jb	0x14008930c <.text+0x8830c>
1400893cb: 4c 8b b3 f0 09 00 00        	movq	0x9f0(%rbx), %r14
1400893d2: 49 83 fe 04                 	cmpq	$0x4, %r14
1400893d6: 0f 85 45 01 00 00           	jne	0x140089521 <.text+0x88521>
1400893dc: 48 83 ff 01                 	cmpq	$0x1, %rdi
1400893e0: 44 0f b6 45 fe              	movzbl	-0x2(%rbp), %r8d
1400893e5: 0f 85 ce 00 00 00           	jne	0x1400894b9 <.text+0x884b9>
1400893eb: 43 80 3c 2f 01              	cmpb	$0x1, (%r15,%r13)
1400893f0: 48 8d 8b 28 05 00 00        	leaq	0x528(%rbx), %rcx
1400893f7: 0f 85 df 03 00 00           	jne	0x1400897dc <.text+0x887dc>
1400893fd: 4d 69 c5 30 01 00 00        	imulq	$0x130, %r13, %r8       # imm = 0x130
140089404: 46 0f b7 0c 01              	movzwl	(%rcx,%r8), %r9d
140089409: 66 41 83 f9 ff              	cmpw	$-0x1, %r9w
14008940e: 0f 84 c8 03 00 00           	je	0x1400897dc <.text+0x887dc>
140089414: 48 89 d7                    	movq	%rdx, %rdi
140089417: 49 01 c8                    	addq	%rcx, %r8
14008941a: 49 8b 40 08                 	movq	0x8(%r8), %rax
14008941e: 41 0f 10 80 18 01 00 00     	movups	0x118(%r8), %xmm0
140089426: 0f 29 45 b0                 	movaps	%xmm0, -0x50(%rbp)
14008942a: 41 0f 10 80 08 01 00 00     	movups	0x108(%r8), %xmm0
140089432: 0f 29 45 a0                 	movaps	%xmm0, -0x60(%rbp)
140089436: 66 41 83 f9 02              	cmpw	$0x2, %r9w
14008943b: 75 5d                       	jne	0x14008949a <.text+0x8849a>
14008943d: 48 83 f8 01                 	cmpq	$0x1, %rax
140089441: 77 57                       	ja	0x14008949a <.text+0x8849a>
140089443: 80 bc 03 40 1e 00 00 01     	cmpb	$0x1, 0x1e40(%rbx,%rax)
14008944b: 75 4d                       	jne	0x14008949a <.text+0x8849a>
14008944d: 80 bc 03 42 1e 00 00 00     	cmpb	$0x0, 0x1e42(%rbx,%rax)
140089455: 75 43                       	jne	0x14008949a <.text+0x8849a>
140089457: c6 84 03 40 1e 00 00 00     	movb	$0x0, 0x1e40(%rbx,%rax)
14008945f: 48 ff 8b 38 1e 00 00        	decq	0x1e38(%rbx)
140089466: 48 c7 84 c3 b8 1d 00 00 00 00 00 00 	movq	$0x0, 0x1db8(%rbx,%rax,8)
140089472: 48 8d 14 c0                 	leaq	(%rax,%rax,8), %rdx
140089476: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008947a: 48 01 c2                    	addq	%rax, %rdx
14008947d: 4c 8d 83 b8 14 00 00        	leaq	0x14b8(%rbx), %r8
140089484: 41 c6 84 10 5a 09 00 00 02  	movb	$0x2, 0x95a(%r8,%rdx)
14008948d: 48 8d 04 40                 	leaq	(%rax,%rax,2), %rax
140089491: 41 c6 84 c0 1d 09 00 00 02  	movb	$0x2, 0x91d(%r8,%rax,8)
14008949a: 48 8d 55 a0                 	leaq	-0x60(%rbp), %rdx
14008949e: e8 1d c8 18 00              	callq	0x140215cc0 <.text+0x214cc0>
1400894a3: 4c 8b b3 f0 09 00 00        	movq	0x9f0(%rbx), %r14
1400894aa: 49 83 fe 04                 	cmpq	$0x4, %r14
1400894ae: 0f 85 31 01 00 00           	jne	0x1400895e5 <.text+0x885e5>
1400894b4: 44 0f b6 45 fe              	movzbl	-0x2(%rbp), %r8d
1400894b9: 41 fe c8                    	decb	%r8b
1400894bc: 41 80 f8 07                 	cmpb	$0x7, %r8b
1400894c0: 0f 92 c0                    	setb	%al
1400894c3: b2 4d                       	movb	$0x4d, %dl
1400894c5: 44 89 c1                    	movl	%r8d, %ecx
1400894c8: d2 ea                       	shrb	%cl, %dl
1400894ca: 84 d0                       	testb	%dl, %al
1400894cc: 0f 85 f9 00 00 00           	jne	0x1400895cb <.text+0x885cb>
1400894d2: 0f b6 46 22                 	movzbl	0x22(%rsi), %eax
1400894d6: 3c 02                       	cmpb	$0x2, %al
1400894d8: 0f 85 97 00 00 00           	jne	0x140089575 <.text+0x88575>
1400894de: 48 8b 45 c0                 	movq	-0x40(%rbp), %rax
1400894e2: 48 89 06                    	movq	%rax, (%rsi)
1400894e5: 48 8b 45 e8                 	movq	-0x18(%rbp), %rax
1400894e9: 48 89 46 08                 	movq	%rax, 0x8(%rsi)
1400894ed: 48 8b 45 e0                 	movq	-0x20(%rbp), %rax
1400894f1: 48 89 46 10                 	movq	%rax, 0x10(%rsi)
1400894f5: 8b 45 f0                    	movl	-0x10(%rbp), %eax
1400894f8: 89 46 18                    	movl	%eax, 0x18(%rsi)
1400894fb: 8b 45 f4                    	movl	-0xc(%rbp), %eax
1400894fe: 89 46 1c                    	movl	%eax, 0x1c(%rsi)
140089501: 0f b7 45 fc                 	movzwl	-0x4(%rbp), %eax
140089505: 66 89 46 20                 	movw	%ax, 0x20(%rsi)
140089509: 0f b6 45 ff                 	movzbl	-0x1(%rbp), %eax
14008950d: 88 46 22                    	movb	%al, 0x22(%rsi)
140089510: 0f b6 45 f9                 	movzbl	-0x7(%rbp), %eax
140089514: 88 46 23                    	movb	%al, 0x23(%rsi)
140089517: f3 0f 11 76 24              	movss	%xmm6, 0x24(%rsi)
14008951c: e9 aa 00 00 00              	jmp	0x1400895cb <.text+0x885cb>
140089521: 4c 8b a3 e8 09 00 00        	movq	0x9e8(%rbx), %r12
140089528: 49 83 fc 03                 	cmpq	$0x3, %r12
14008952c: 0f 87 c4 02 00 00           	ja	0x1400897f6 <.text+0x887f6>
140089532: 43 80 3c 27 00              	cmpb	$0x0, (%r15,%r12)
140089537: 0f 84 29 01 00 00           	je	0x140089666 <.text+0x88666>
14008953d: 48 89 55 d8                 	movq	%rdx, -0x28(%rbp)
140089541: 4b 8d 0c 27                 	leaq	(%r15,%r12), %rcx
140089545: ba 04 00 00 00              	movl	$0x4, %edx
14008954a: 4c 29 e2                    	subq	%r12, %rdx
14008954d: e8 7e 69 f8 ff              	callq	0x14000fed0 <.text+0xeed0>
140089552: 48 83 f8 01                 	cmpq	$0x1, %rax
140089556: 0f 85 c2 00 00 00           	jne	0x14008961e <.text+0x8861e>
14008955c: 49 01 d4                    	addq	%rdx, %r12
14008955f: b8 01 00 00 00              	movl	$0x1, %eax
140089564: 48 8b 55 d8                 	movq	-0x28(%rbp), %rdx
140089568: a8 01                       	testb	$0x1, %al
14008956a: 0f 84 6c fe ff ff           	je	0x1400893dc <.text+0x883dc>
140089570: e9 c3 00 00 00              	jmp	0x140089638 <.text+0x88638>
140089575: 0f b7 4d fa                 	movzwl	-0x6(%rbp), %ecx
140089579: 66 39 4e 24                 	cmpw	%cx, 0x24(%rsi)
14008957d: 0f 85 5b ff ff ff           	jne	0x1400894de <.text+0x884de>
140089583: 8b 4d f0                    	movl	-0x10(%rbp), %ecx
140089586: 39 4e 18                    	cmpl	%ecx, 0x18(%rsi)
140089589: 0f 85 4f ff ff ff           	jne	0x1400894de <.text+0x884de>
14008958f: 8b 4d f4                    	movl	-0xc(%rbp), %ecx
140089592: 39 4e 1c                    	cmpl	%ecx, 0x1c(%rsi)
140089595: 0f 85 43 ff ff ff           	jne	0x1400894de <.text+0x884de>
14008959b: 0f b7 4d fc                 	movzwl	-0x4(%rbp), %ecx
14008959f: 66 39 4e 20                 	cmpw	%cx, 0x20(%rsi)
1400895a3: 0f 85 35 ff ff ff           	jne	0x1400894de <.text+0x884de>
1400895a9: 3a 45 ff                    	cmpb	-0x1(%rbp), %al
1400895ac: 0f 85 2c ff ff ff           	jne	0x1400894de <.text+0x884de>
1400895b2: 48 8b 46 08                 	movq	0x8(%rsi), %rax
1400895b6: 48 33 45 e8                 	xorq	-0x18(%rbp), %rax
1400895ba: 48 8b 4e 10                 	movq	0x10(%rsi), %rcx
1400895be: 48 33 4d e0                 	xorq	-0x20(%rbp), %rcx
1400895c2: 48 09 c1                    	orq	%rax, %rcx
1400895c5: 0f 85 13 ff ff ff           	jne	0x1400894de <.text+0x884de>
1400895cb: 31 c0                       	xorl	%eax, %eax
1400895cd: 0f 28 75 00                 	movaps	(%rbp), %xmm6
1400895d1: 48 81 c4 98 00 00 00        	addq	$0x98, %rsp
1400895d8: 5b                          	popq	%rbx
1400895d9: 5f                          	popq	%rdi
1400895da: 5e                          	popq	%rsi
1400895db: 41 5c                       	popq	%r12
1400895dd: 41 5d                       	popq	%r13
1400895df: 41 5e                       	popq	%r14
1400895e1: 41 5f                       	popq	%r15
1400895e3: 5d                          	popq	%rbp
1400895e4: c3                          	retq
1400895e5: 4c 8b a3 e8 09 00 00        	movq	0x9e8(%rbx), %r12
1400895ec: 49 83 fc 03                 	cmpq	$0x3, %r12
1400895f0: 0f 87 00 02 00 00           	ja	0x1400897f6 <.text+0x887f6>
1400895f6: 43 80 3c 27 00              	cmpb	$0x0, (%r15,%r12)
1400895fb: 74 66                       	je	0x140089663 <.text+0x88663>
1400895fd: 4b 8d 0c 27                 	leaq	(%r15,%r12), %rcx
140089601: ba 04 00 00 00              	movl	$0x4, %edx
140089606: 4c 29 e2                    	subq	%r12, %rdx
140089609: e8 c2 68 f8 ff              	callq	0x14000fed0 <.text+0xeed0>
14008960e: 48 83 f8 01                 	cmpq	$0x1, %rax
140089612: 75 2f                       	jne	0x140089643 <.text+0x88643>
140089614: 49 01 d4                    	addq	%rdx, %r12
140089617: b8 01 00 00 00              	movl	$0x1, %eax
14008961c: eb 33                       	jmp	0x140089651 <.text+0x88651>
14008961e: 4c 89 f9                    	movq	%r15, %rcx
140089621: 4c 89 e2                    	movq	%r12, %rdx
140089624: e8 a7 68 f8 ff              	callq	0x14000fed0 <.text+0xeed0>
140089629: 49 89 d4                    	movq	%rdx, %r12
14008962c: 48 8b 55 d8                 	movq	-0x28(%rbp), %rdx
140089630: a8 01                       	testb	$0x1, %al
140089632: 0f 84 a4 fd ff ff           	je	0x1400893dc <.text+0x883dc>
140089638: 49 83 fc 04                 	cmpq	$0x4, %r12
14008963c: 72 28                       	jb	0x140089666 <.text+0x88666>
14008963e: e9 c9 01 00 00              	jmp	0x14008980c <.text+0x8880c>
140089643: 4c 89 f9                    	movq	%r15, %rcx
140089646: 4c 89 e2                    	movq	%r12, %rdx
140089649: e8 82 68 f8 ff              	callq	0x14000fed0 <.text+0xeed0>
14008964e: 49 89 d4                    	movq	%rdx, %r12
140089651: a8 01                       	testb	$0x1, %al
140089653: 0f 84 5b fe ff ff           	je	0x1400894b4 <.text+0x884b4>
140089659: 49 83 fc 04                 	cmpq	$0x4, %r12
14008965d: 0f 83 a9 01 00 00           	jae	0x14008980c <.text+0x8880c>
140089663: 48 89 fa                    	movq	%rdi, %rdx
140089666: 48 8d 8b 28 05 00 00        	leaq	0x528(%rbx), %rcx
14008966d: 49 8d 44 24 01              	leaq	0x1(%r12), %rax
140089672: 45 31 c0                    	xorl	%r8d, %r8d
140089675: 48 83 f8 04                 	cmpq	$0x4, %rax
140089679: 4c 0f 45 c0                 	cmovneq	%rax, %r8
14008967d: 42 c6 84 23 f8 09 00 00 01  	movb	$0x1, 0x9f8(%rbx,%r12)
140089686: 4c 89 83 e8 09 00 00        	movq	%r8, 0x9e8(%rbx)
14008968d: 49 ff c6                    	incq	%r14
140089690: 4c 89 b3 f0 09 00 00        	movq	%r14, 0x9f0(%rbx)
140089697: 49 69 c4 30 01 00 00        	imulq	$0x130, %r12, %rax      # imm = 0x130
14008969e: 48 01 c1                    	addq	%rax, %rcx
1400896a1: 41 b8 30 01 00 00           	movl	$0x130, %r8d            # imm = 0x130
1400896a7: e8 34 71 1c 00              	callq	0x1402507e0 <.text+0x24f7e0>
1400896ac: 0f b6 4e 22                 	movzbl	0x22(%rsi), %ecx
1400896b0: b0 01                       	movb	$0x1, %al
1400896b2: 80 f9 02                    	cmpb	$0x2, %cl
1400896b5: 0f 84 12 ff ff ff           	je	0x1400895cd <.text+0x885cd>
1400896bb: 0f b7 55 fa                 	movzwl	-0x6(%rbp), %edx
1400896bf: 66 39 56 24                 	cmpw	%dx, 0x24(%rsi)
1400896c3: 0f 85 04 ff ff ff           	jne	0x1400895cd <.text+0x885cd>
1400896c9: 8b 55 f0                    	movl	-0x10(%rbp), %edx
1400896cc: 39 56 18                    	cmpl	%edx, 0x18(%rsi)
1400896cf: 0f 85 f8 fe ff ff           	jne	0x1400895cd <.text+0x885cd>
1400896d5: 8b 55 f4                    	movl	-0xc(%rbp), %edx
1400896d8: 39 56 1c                    	cmpl	%edx, 0x1c(%rsi)
1400896db: 0f 85 ec fe ff ff           	jne	0x1400895cd <.text+0x885cd>
1400896e1: 0f b7 55 fc                 	movzwl	-0x4(%rbp), %edx
1400896e5: 66 39 56 20                 	cmpw	%dx, 0x20(%rsi)
1400896e9: 0f 85 de fe ff ff           	jne	0x1400895cd <.text+0x885cd>
1400896ef: 3a 4d ff                    	cmpb	-0x1(%rbp), %cl
1400896f2: 0f 85 d5 fe ff ff           	jne	0x1400895cd <.text+0x885cd>
1400896f8: 48 8b 55 e8                 	movq	-0x18(%rbp), %rdx
1400896fc: 48 33 56 08                 	xorq	0x8(%rsi), %rdx
140089700: 48 8b 4d e0                 	movq	-0x20(%rbp), %rcx
140089704: 48 33 4e 10                 	xorq	0x10(%rsi), %rcx
140089708: 48 09 d1                    	orq	%rdx, %rcx
14008970b: 0f 85 bc fe ff ff           	jne	0x1400895cd <.text+0x885cd>
140089711: c6 46 22 02                 	movb	$0x2, 0x22(%rsi)
140089715: e9 b3 fe ff ff              	jmp	0x1400895cd <.text+0x885cd>
14008971a: 49 89 d7                    	movq	%rdx, %r15
14008971d: 49 8b 82 e0 fe ff ff        	movq	-0x120(%r10), %rax
140089724: 41 0f 10 42 f0              	movups	-0x10(%r10), %xmm0
140089729: 0f 29 45 b0                 	movaps	%xmm0, -0x50(%rbp)
14008972d: 41 0f 10 42 e0              	movups	-0x20(%r10), %xmm0
140089732: 0f 29 45 a0                 	movaps	%xmm0, -0x60(%rbp)
140089736: 66 41 83 fb 02              	cmpw	$0x2, %r11w
14008973b: 75 58                       	jne	0x140089795 <.text+0x88795>
14008973d: 48 83 f8 01                 	cmpq	$0x1, %rax
140089741: 77 52                       	ja	0x140089795 <.text+0x88795>
140089743: 80 bc 03 40 1e 00 00 01     	cmpb	$0x1, 0x1e40(%rbx,%rax)
14008974b: 75 48                       	jne	0x140089795 <.text+0x88795>
14008974d: 80 bc 03 42 1e 00 00 00     	cmpb	$0x0, 0x1e42(%rbx,%rax)
140089755: 75 3e                       	jne	0x140089795 <.text+0x88795>
140089757: c6 84 03 40 1e 00 00 00     	movb	$0x0, 0x1e40(%rbx,%rax)
14008975f: 48 ff 8b 38 1e 00 00        	decq	0x1e38(%rbx)
140089766: 48 c7 84 c3 b8 1d 00 00 00 00 00 00 	movq	$0x0, 0x1db8(%rbx,%rax,8)
140089772: 48 8d 0c c0                 	leaq	(%rax,%rax,8), %rcx
140089776: 48 8d 0c 49                 	leaq	(%rcx,%rcx,2), %rcx
14008977a: 48 01 c1                    	addq	%rax, %rcx
14008977d: 48 8b 55 d0                 	movq	-0x30(%rbp), %rdx
140089781: c6 84 0a 5a 09 00 00 02     	movb	$0x2, 0x95a(%rdx,%rcx)
140089789: 48 8d 04 40                 	leaq	(%rax,%rax,2), %rax
14008978d: c6 84 c2 1d 09 00 00 02     	movb	$0x2, 0x91d(%rdx,%rax,8)
140089795: 48 8d 55 a0                 	leaq	-0x60(%rbp), %rdx
140089799: 48 8b 7d c8                 	movq	-0x38(%rbp), %rdi
14008979d: 48 89 f9                    	movq	%rdi, %rcx
1400897a0: e8 1b c5 18 00              	callq	0x140215cc0 <.text+0x214cc0>
1400897a5: 48 89 f9                    	movq	%rdi, %rcx
1400897a8: 4c 89 fa                    	movq	%r15, %rdx
1400897ab: e8 50 c2 18 00              	callq	0x140215a00 <.text+0x214a00>
1400897b0: 48 85 c0                    	testq	%rax, %rax
1400897b3: 44 0f b6 45 fe              	movzbl	-0x2(%rbp), %r8d
1400897b8: 0f 85 ee fe ff ff           	jne	0x1400896ac <.text+0x886ac>
1400897be: e9 f6 fc ff ff              	jmp	0x1400894b9 <.text+0x884b9>
1400897c3: 4c 8d 0d 9e 5b 1d 00        	leaq	0x1d5b9e(%rip), %r9     # 0x14025f368
1400897ca: 41 b8 00 01 00 00           	movl	$0x100, %r8d            # imm = 0x100
1400897d0: 31 c9                       	xorl	%ecx, %ecx
1400897d2: 48 89 c2                    	movq	%rax, %rdx
1400897d5: e8 56 7a 1c 00              	callq	0x140251230 <.text+0x250230>
1400897da: 0f 0b                       	ud2
1400897dc: 48 8d 0d dd 00 1e 00        	leaq	0x1e00dd(%rip), %rcx    # 0x1402698c0
1400897e3: 4c 8d 05 ee 00 1e 00        	leaq	0x1e00ee(%rip), %r8     # 0x1402698d8
1400897ea: ba 15 00 00 00              	movl	$0x15, %edx
1400897ef: e8 4c 77 1c 00              	callq	0x140250f40 <.text+0x24ff40>
1400897f4: 0f 0b                       	ud2
1400897f6: 4c 8d 05 93 61 1d 00        	leaq	0x1d6193(%rip), %r8     # 0x14025f990
1400897fd: ba 04 00 00 00              	movl	$0x4, %edx
140089802: 4c 89 e1                    	movq	%r12, %rcx
140089805: e8 19 78 1c 00              	callq	0x140251023 <.text+0x250023>
14008980a: 0f 0b                       	ud2
14008980c: 4c 8d 05 95 61 1d 00        	leaq	0x1d6195(%rip), %r8     # 0x14025f9a8
140089813: ba 04 00 00 00              	movl	$0x4, %edx
140089818: 4c 89 e1                    	movq	%r12, %rcx
14008981b: e8 03 78 1c 00              	callq	0x140251023 <.text+0x250023>
140089820: 0f 0b                       	ud2

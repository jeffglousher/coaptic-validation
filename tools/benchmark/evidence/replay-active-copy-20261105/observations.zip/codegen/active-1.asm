
D:/CoapticCurrent/replay-active-copy-20261105/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14008a500: 55                          	pushq	%rbp
14008a501: 41 57                       	pushq	%r15
14008a503: 41 56                       	pushq	%r14
14008a505: 41 55                       	pushq	%r13
14008a507: 41 54                       	pushq	%r12
14008a509: 56                          	pushq	%rsi
14008a50a: 57                          	pushq	%rdi
14008a50b: 53                          	pushq	%rbx
14008a50c: 48 83 ec 78                 	subq	$0x78, %rsp
14008a510: 48 8d 6c 24 70              	leaq	0x70(%rsp), %rbp
14008a515: 0f 29 75 f0                 	movaps	%xmm6, -0x10(%rbp)
14008a519: 4c 89 ce                    	movq	%r9, %rsi
14008a51c: 45 89 c6                    	movl	%r8d, %r14d
14008a51f: 48 89 d7                    	movq	%rdx, %rdi
14008a522: 48 89 cb                    	movq	%rcx, %rbx
14008a525: 48 8b 82 10 01 00 00        	movq	0x110(%rdx), %rax
14008a52c: 48 89 45 d0                 	movq	%rax, -0x30(%rbp)
14008a530: 48 8b 82 08 01 00 00        	movq	0x108(%rdx), %rax
14008a537: 48 89 45 d8                 	movq	%rax, -0x28(%rbp)
14008a53b: 8b 82 18 01 00 00           	movl	0x118(%rdx), %eax
14008a541: 89 45 e0                    	movl	%eax, -0x20(%rbp)
14008a544: 8b 82 1c 01 00 00           	movl	0x11c(%rdx), %eax
14008a54a: 89 45 e4                    	movl	%eax, -0x1c(%rbp)
14008a54d: 0f b7 82 20 01 00 00        	movzwl	0x120(%rdx), %eax
14008a554: 66 89 45 ec                 	movw	%ax, -0x14(%rbp)
14008a558: 0f b6 82 22 01 00 00        	movzbl	0x122(%rdx), %eax
14008a55f: 88 45 ef                    	movb	%al, -0x11(%rbp)
14008a562: 0f b6 82 23 01 00 00        	movzbl	0x123(%rdx), %eax
14008a569: 88 45 e9                    	movb	%al, -0x17(%rbp)
14008a56c: f3 0f 10 b2 24 01 00 00     	movss	0x124(%rdx), %xmm6
14008a574: 0f b7 82 24 01 00 00        	movzwl	0x124(%rdx), %eax
14008a57b: 66 89 45 ea                 	movw	%ax, -0x16(%rbp)
14008a57f: 4c 8b ba 28 01 00 00        	movq	0x128(%rdx), %r15
14008a586: 44 0f b7 2a                 	movzwl	(%rdx), %r13d
14008a58a: 66 41 83 fd 01              	cmpw	$0x1, %r13w
14008a58f: 75 23                       	jne	0x14008a5b4 <.text+0x895b4>
14008a591: 0f b7 57 02                 	movzwl	0x2(%rdi), %edx
14008a595: 48 81 fa 01 01 00 00        	cmpq	$0x101, %rdx            # imm = 0x101
14008a59c: 72 20                       	jb	0x14008a5be <.text+0x895be>
14008a59e: 4c 8d 0d 13 4e 1d 00        	leaq	0x1d4e13(%rip), %r9     # 0x14025f3b8
14008a5a5: 41 b8 00 01 00 00           	movl	$0x100, %r8d            # imm = 0x100
14008a5ab: 31 c9                       	xorl	%ecx, %ecx
14008a5ad: e8 ae 6a 1c 00              	callq	0x140251060 <.text+0x250060>
14008a5b2: 0f 0b                       	ud2
14008a5b4: 66 45 85 ed                 	testw	%r13w, %r13w
14008a5b8: 0f 84 5f 02 00 00           	je	0x14008a81d <.text+0x8981d>
14008a5be: 4c 89 7d c0                 	movq	%r15, -0x40(%rbp)
14008a5c2: 48 8b 83 e8 00 00 00        	movq	0xe8(%rbx), %rax
14008a5c9: 48 85 c0                    	testq	%rax, %rax
14008a5cc: 0f 84 ea 00 00 00           	je	0x14008a6bc <.text+0x896bc>
14008a5d2: b9 28 01 00 00              	movl	$0x128, %ecx            # imm = 0x128
14008a5d7: 48 03 8b c8 00 00 00        	addq	0xc8(%rbx), %rcx
14008a5de: 48 8b 93 d0 00 00 00        	movq	0xd0(%rbx), %rdx
14008a5e5: 49 c7 c3 ff ff ff ff        	movq	$-0x1, %r11
14008a5ec: 45 31 e4                    	xorl	%r12d, %r12d
14008a5ef: 45 31 ff                    	xorl	%r15d, %r15d
14008a5f2: 4d 69 cc 30 01 00 00        	imulq	$0x130, %r12, %r9       # imm = 0x130
14008a5f9: 49 01 c9                    	addq	%rcx, %r9
14008a5fc: eb 15                       	jmp	0x14008a613 <.text+0x89613>
14008a5fe: 66 90                       	nop
14008a600: 49 ff c4                    	incq	%r12
14008a603: 49 81 c1 30 01 00 00        	addq	$0x130, %r9             # imm = 0x130
14008a60a: 49 39 c4                    	cmpq	%rax, %r12
14008a60d: 0f 83 ac 00 00 00           	jae	0x14008a6bf <.text+0x896bf>
14008a613: 49 39 d4                    	cmpq	%rdx, %r12
14008a616: 73 e8                       	jae	0x14008a600 <.text+0x89600>
14008a618: 45 0f b7 91 d8 fe ff ff     	movzwl	-0x128(%r9), %r10d
14008a620: 66 41 83 fa ff              	cmpw	$-0x1, %r10w
14008a625: 74 d9                       	je	0x14008a600 <.text+0x89600>
14008a627: 44 0f b7 45 ea              	movzwl	-0x16(%rbp), %r8d
14008a62c: 66 45 39 41 fc              	cmpw	%r8w, -0x4(%r9)
14008a631: 75 4c                       	jne	0x14008a67f <.text+0x8967f>
14008a633: 44 8b 45 e0                 	movl	-0x20(%rbp), %r8d
14008a637: 45 39 41 f0                 	cmpl	%r8d, -0x10(%r9)
14008a63b: 75 42                       	jne	0x14008a67f <.text+0x8967f>
14008a63d: 44 8b 45 e4                 	movl	-0x1c(%rbp), %r8d
14008a641: 45 39 41 f4                 	cmpl	%r8d, -0xc(%r9)
14008a645: 75 38                       	jne	0x14008a67f <.text+0x8967f>
14008a647: 44 0f b7 45 ec              	movzwl	-0x14(%rbp), %r8d
14008a64c: 66 45 39 41 f8              	cmpw	%r8w, -0x8(%r9)
14008a651: 75 2c                       	jne	0x14008a67f <.text+0x8967f>
14008a653: 44 0f b6 45 ef              	movzbl	-0x11(%rbp), %r8d
14008a658: 45 38 41 fa                 	cmpb	%r8b, -0x6(%r9)
14008a65c: 75 21                       	jne	0x14008a67f <.text+0x8967f>
14008a65e: 4c 89 5d b8                 	movq	%r11, -0x48(%rbp)
14008a662: 4d 8b 59 e0                 	movq	-0x20(%r9), %r11
14008a666: 4c 33 5d d8                 	xorq	-0x28(%rbp), %r11
14008a66a: 4d 8b 41 e8                 	movq	-0x18(%r9), %r8
14008a66e: 4c 33 45 d0                 	xorq	-0x30(%rbp), %r8
14008a672: 4d 09 d8                    	orq	%r11, %r8
14008a675: 4c 8b 5d b8                 	movq	-0x48(%rbp), %r11
14008a679: 0f 84 0b 03 00 00           	je	0x14008a98a <.text+0x8998a>
14008a67f: 4d 8b 09                    	movq	(%r9), %r9
14008a682: 4d 85 c9                    	testq	%r9, %r9
14008a685: 74 27                       	je	0x14008a6ae <.text+0x896ae>
14008a687: 4d 85 ff                    	testq	%r15, %r15
14008a68a: 41 0f 94 c0                 	sete	%r8b
14008a68e: 4d 39 d9                    	cmpq	%r11, %r9
14008a691: 41 0f 92 c2                 	setb	%r10b
14008a695: 45 08 c2                    	orb	%r8b, %r10b
14008a698: 4c 8b 45 c8                 	movq	-0x38(%rbp), %r8
14008a69c: 4d 0f 45 c4                 	cmovneq	%r12, %r8
14008a6a0: 4c 89 45 c8                 	movq	%r8, -0x38(%rbp)
14008a6a4: 4d 0f 45 d9                 	cmovneq	%r9, %r11
14008a6a8: 41 bf 01 00 00 00           	movl	$0x1, %r15d
14008a6ae: 49 ff c4                    	incq	%r12
14008a6b1: 49 39 c4                    	cmpq	%rax, %r12
14008a6b4: 0f 82 38 ff ff ff           	jb	0x14008a5f2 <.text+0x895f2>
14008a6ba: eb 03                       	jmp	0x14008a6bf <.text+0x896bf>
14008a6bc: 45 31 ff                    	xorl	%r15d, %r15d
14008a6bf: 4c 8d a3 d8 00 00 00        	leaq	0xd8(%rbx), %r12
14008a6c6: 4c 89 e1                    	movq	%r12, %rcx
14008a6c9: e8 92 0a f8 ff              	callq	0x14000b160 <.text+0xa160>
14008a6ce: a8 01                       	testb	$0x1, %al
14008a6d0: 74 53                       	je	0x14008a725 <.text+0x89725>
14008a6d2: 4c 8b 7d c0                 	movq	-0x40(%rbp), %r15
14008a6d6: 4d 85 ff                    	testq	%r15, %r15
14008a6d9: 74 16                       	je	0x14008a6f1 <.text+0x896f1>
14008a6db: 48 8b 83 18 01 00 00        	movq	0x118(%rbx), %rax
14008a6e2: 48 ff c8                    	decq	%rax
14008a6e5: 4c 39 f8                    	cmpq	%r15, %rax
14008a6e8: 72 07                       	jb	0x14008a6f1 <.text+0x896f1>
14008a6ea: 4c 89 bb 18 01 00 00        	movq	%r15, 0x118(%rbx)
14008a6f1: 48 8b 83 d0 00 00 00        	movq	0xd0(%rbx), %rax
14008a6f8: 48 39 c2                    	cmpq	%rax, %rdx
14008a6fb: 0f 83 bc 02 00 00           	jae	0x14008a9bd <.text+0x899bd>
14008a701: 48 69 ca 30 01 00 00        	imulq	$0x130, %rdx, %rcx      # imm = 0x130
14008a708: 48 03 8b c8 00 00 00        	addq	0xc8(%rbx), %rcx
14008a70f: 66 41 83 fd 01              	cmpw	$0x1, %r13w
14008a714: 0f 85 67 01 00 00           	jne	0x14008a881 <.text+0x89881>
14008a71a: 41 b8 30 01 00 00           	movl	$0x130, %r8d            # imm = 0x130
14008a720: e9 91 01 00 00              	jmp	0x14008a8b6 <.text+0x898b6>
14008a725: 49 83 ff 01                 	cmpq	$0x1, %r15
14008a729: 4c 8b 7d c0                 	movq	-0x40(%rbp), %r15
14008a72d: 0f 85 ea 00 00 00           	jne	0x14008a81d <.text+0x8981d>
14008a733: 48 8b 83 d0 00 00 00        	movq	0xd0(%rbx), %rax
14008a73a: 4c 8b 4d c8                 	movq	-0x38(%rbp), %r9
14008a73e: 49 39 c1                    	cmpq	%rax, %r9
14008a741: 73 75                       	jae	0x14008a7b8 <.text+0x897b8>
14008a743: 48 8b 8b c8 00 00 00        	movq	0xc8(%rbx), %rcx
14008a74a: 49 69 d1 30 01 00 00        	imulq	$0x130, %r9, %rdx       # imm = 0x130
14008a751: 66 83 3c 11 02              	cmpw	$0x2, (%rcx,%rdx)
14008a756: 75 60                       	jne	0x14008a7b8 <.text+0x897b8>
14008a758: 48 01 d1                    	addq	%rdx, %rcx
14008a75b: 48 8b 49 08                 	movq	0x8(%rcx), %rcx
14008a75f: 48 3b 8b 88 00 00 00        	cmpq	0x88(%rbx), %rcx
14008a766: 73 50                       	jae	0x14008a7b8 <.text+0x897b8>
14008a768: 48 8b 93 80 00 00 00        	movq	0x80(%rbx), %rdx
14008a76f: 80 3c 0a 01                 	cmpb	$0x1, (%rdx,%rcx)
14008a773: 75 43                       	jne	0x14008a7b8 <.text+0x897b8>
14008a775: 48 3b 8b a0 00 00 00        	cmpq	0xa0(%rbx), %rcx
14008a77c: 73 0e                       	jae	0x14008a78c <.text+0x8978c>
14008a77e: 4c 8b 83 98 00 00 00        	movq	0x98(%rbx), %r8
14008a785: 41 80 3c 08 00              	cmpb	$0x0, (%r8,%rcx)
14008a78a: 75 2c                       	jne	0x14008a7b8 <.text+0x897b8>
14008a78c: c6 04 0a 00                 	movb	$0x0, (%rdx,%rcx)
14008a790: 48 ff 8b b0 00 00 00        	decq	0xb0(%rbx)
14008a797: 48 3b 4b 70                 	cmpq	0x70(%rbx), %rcx
14008a79b: 73 1b                       	jae	0x14008a7b8 <.text+0x897b8>
14008a79d: 48 8b 53 68                 	movq	0x68(%rbx), %rdx
14008a7a1: 48 6b c9 58                 	imulq	$0x58, %rcx, %rcx
14008a7a5: 48 c7 44 0a 30 00 00 00 00  	movq	$0x0, 0x30(%rdx,%rcx)
14008a7ae: c6 44 0a 52 02              	movb	$0x2, 0x52(%rdx,%rcx)
14008a7b3: c6 44 0a 25 02              	movb	$0x2, 0x25(%rdx,%rcx)
14008a7b8: 4c 3b 8b e8 00 00 00        	cmpq	0xe8(%rbx), %r9
14008a7bf: 73 4a                       	jae	0x14008a80b <.text+0x8980b>
14008a7c1: 48 8b 8b e0 00 00 00        	movq	0xe0(%rbx), %rcx
14008a7c8: 42 80 3c 09 01              	cmpb	$0x1, (%rcx,%r9)
14008a7cd: 75 3c                       	jne	0x14008a80b <.text+0x8980b>
14008a7cf: 4c 3b 8b 00 01 00 00        	cmpq	0x100(%rbx), %r9
14008a7d6: 73 0e                       	jae	0x14008a7e6 <.text+0x897e6>
14008a7d8: 48 8b 93 f8 00 00 00        	movq	0xf8(%rbx), %rdx
14008a7df: 42 80 3c 0a 00              	cmpb	$0x0, (%rdx,%r9)
14008a7e4: 75 25                       	jne	0x14008a80b <.text+0x8980b>
14008a7e6: 42 c6 04 09 00              	movb	$0x0, (%rcx,%r9)
14008a7eb: 48 ff 8b 10 01 00 00        	decq	0x110(%rbx)
14008a7f2: 49 39 c1                    	cmpq	%rax, %r9
14008a7f5: 73 14                       	jae	0x14008a80b <.text+0x8980b>
14008a7f7: 48 8b 83 c8 00 00 00        	movq	0xc8(%rbx), %rax
14008a7fe: 49 69 c9 30 01 00 00        	imulq	$0x130, %r9, %rcx       # imm = 0x130
14008a805: 66 c7 04 08 ff ff           	movw	$0xffff, (%rax,%rcx)    # imm = 0xFFFF
14008a80b: 4c 89 e1                    	movq	%r12, %rcx
14008a80e: e8 4d 09 f8 ff              	callq	0x14000b160 <.text+0xa160>
14008a813: 48 83 f8 01                 	cmpq	$0x1, %rax
14008a817: 0f 84 b9 fe ff ff           	je	0x14008a6d6 <.text+0x896d6>
14008a81d: 41 fe ce                    	decb	%r14b
14008a820: 41 80 fe 07                 	cmpb	$0x7, %r14b
14008a824: 0f 92 c0                    	setb	%al
14008a827: b2 4d                       	movb	$0x4d, %dl
14008a829: 44 89 f1                    	movl	%r14d, %ecx
14008a82c: d2 ea                       	shrb	%cl, %dl
14008a82e: 84 d0                       	testb	%dl, %al
14008a830: 0f 85 3d 01 00 00           	jne	0x14008a973 <.text+0x89973>
14008a836: 0f b6 46 22                 	movzbl	0x22(%rsi), %eax
14008a83a: 3c 02                       	cmpb	$0x2, %al
14008a83c: 0f 85 db 00 00 00           	jne	0x14008a91d <.text+0x8991d>
14008a842: 4c 89 3e                    	movq	%r15, (%rsi)
14008a845: 48 8b 45 d8                 	movq	-0x28(%rbp), %rax
14008a849: 48 89 46 08                 	movq	%rax, 0x8(%rsi)
14008a84d: 48 8b 45 d0                 	movq	-0x30(%rbp), %rax
14008a851: 48 89 46 10                 	movq	%rax, 0x10(%rsi)
14008a855: 8b 45 e0                    	movl	-0x20(%rbp), %eax
14008a858: 89 46 18                    	movl	%eax, 0x18(%rsi)
14008a85b: 8b 45 e4                    	movl	-0x1c(%rbp), %eax
14008a85e: 89 46 1c                    	movl	%eax, 0x1c(%rsi)
14008a861: 0f b7 45 ec                 	movzwl	-0x14(%rbp), %eax
14008a865: 66 89 46 20                 	movw	%ax, 0x20(%rsi)
14008a869: 0f b6 45 ef                 	movzbl	-0x11(%rbp), %eax
14008a86d: 88 46 22                    	movb	%al, 0x22(%rsi)
14008a870: 0f b6 45 e9                 	movzbl	-0x17(%rbp), %eax
14008a874: 88 46 23                    	movb	%al, 0x23(%rsi)
14008a877: f3 0f 11 76 24              	movss	%xmm6, 0x24(%rsi)
14008a87c: e9 f2 00 00 00              	jmp	0x14008a973 <.text+0x89973>
14008a881: 48 8d 87 08 01 00 00        	leaq	0x108(%rdi), %rax
14008a888: 66 c7 01 00 00              	movw	$0x0, (%rcx)
14008a88d: 0f 10 00                    	movups	(%rax), %xmm0
14008a890: 0f 10 48 10                 	movups	0x10(%rax), %xmm1
14008a894: 0f 11 81 08 01 00 00        	movups	%xmm0, 0x108(%rcx)
14008a89b: 0f 11 89 18 01 00 00        	movups	%xmm1, 0x118(%rcx)
14008a8a2: 4c 89 b9 28 01 00 00        	movq	%r15, 0x128(%rcx)
14008a8a9: 66 41 83 fd 02              	cmpw	$0x2, %r13w
14008a8ae: 75 0e                       	jne	0x14008a8be <.text+0x898be>
14008a8b0: 41 b8 08 01 00 00           	movl	$0x108, %r8d            # imm = 0x108
14008a8b6: 48 89 fa                    	movq	%rdi, %rdx
14008a8b9: e8 52 5d 1c 00              	callq	0x140250610 <.text+0x24f610>
14008a8be: 0f b6 4e 22                 	movzbl	0x22(%rsi), %ecx
14008a8c2: b0 01                       	movb	$0x1, %al
14008a8c4: 80 f9 02                    	cmpb	$0x2, %cl
14008a8c7: 0f 84 a8 00 00 00           	je	0x14008a975 <.text+0x89975>
14008a8cd: 0f b7 55 ea                 	movzwl	-0x16(%rbp), %edx
14008a8d1: 66 39 56 24                 	cmpw	%dx, 0x24(%rsi)
14008a8d5: 0f 85 9a 00 00 00           	jne	0x14008a975 <.text+0x89975>
14008a8db: 8b 55 e0                    	movl	-0x20(%rbp), %edx
14008a8de: 39 56 18                    	cmpl	%edx, 0x18(%rsi)
14008a8e1: 0f 85 8e 00 00 00           	jne	0x14008a975 <.text+0x89975>
14008a8e7: 8b 55 e4                    	movl	-0x1c(%rbp), %edx
14008a8ea: 39 56 1c                    	cmpl	%edx, 0x1c(%rsi)
14008a8ed: 0f 85 82 00 00 00           	jne	0x14008a975 <.text+0x89975>
14008a8f3: 0f b7 55 ec                 	movzwl	-0x14(%rbp), %edx
14008a8f7: 66 39 56 20                 	cmpw	%dx, 0x20(%rsi)
14008a8fb: 75 78                       	jne	0x14008a975 <.text+0x89975>
14008a8fd: 3a 4d ef                    	cmpb	-0x11(%rbp), %cl
14008a900: 75 73                       	jne	0x14008a975 <.text+0x89975>
14008a902: 48 8b 55 d8                 	movq	-0x28(%rbp), %rdx
14008a906: 48 33 56 08                 	xorq	0x8(%rsi), %rdx
14008a90a: 48 8b 4d d0                 	movq	-0x30(%rbp), %rcx
14008a90e: 48 33 4e 10                 	xorq	0x10(%rsi), %rcx
14008a912: 48 09 d1                    	orq	%rdx, %rcx
14008a915: 75 5e                       	jne	0x14008a975 <.text+0x89975>
14008a917: c6 46 22 02                 	movb	$0x2, 0x22(%rsi)
14008a91b: eb 58                       	jmp	0x14008a975 <.text+0x89975>
14008a91d: 0f b7 4d ea                 	movzwl	-0x16(%rbp), %ecx
14008a921: 66 39 4e 24                 	cmpw	%cx, 0x24(%rsi)
14008a925: 0f 85 17 ff ff ff           	jne	0x14008a842 <.text+0x89842>
14008a92b: 8b 4d e0                    	movl	-0x20(%rbp), %ecx
14008a92e: 39 4e 18                    	cmpl	%ecx, 0x18(%rsi)
14008a931: 0f 85 0b ff ff ff           	jne	0x14008a842 <.text+0x89842>
14008a937: 8b 4d e4                    	movl	-0x1c(%rbp), %ecx
14008a93a: 39 4e 1c                    	cmpl	%ecx, 0x1c(%rsi)
14008a93d: 0f 85 ff fe ff ff           	jne	0x14008a842 <.text+0x89842>
14008a943: 0f b7 4d ec                 	movzwl	-0x14(%rbp), %ecx
14008a947: 66 39 4e 20                 	cmpw	%cx, 0x20(%rsi)
14008a94b: 0f 85 f1 fe ff ff           	jne	0x14008a842 <.text+0x89842>
14008a951: 3a 45 ef                    	cmpb	-0x11(%rbp), %al
14008a954: 0f 85 e8 fe ff ff           	jne	0x14008a842 <.text+0x89842>
14008a95a: 48 8b 46 08                 	movq	0x8(%rsi), %rax
14008a95e: 48 33 45 d8                 	xorq	-0x28(%rbp), %rax
14008a962: 48 8b 4e 10                 	movq	0x10(%rsi), %rcx
14008a966: 48 33 4d d0                 	xorq	-0x30(%rbp), %rcx
14008a96a: 48 09 c1                    	orq	%rax, %rcx
14008a96d: 0f 85 cf fe ff ff           	jne	0x14008a842 <.text+0x89842>
14008a973: 31 c0                       	xorl	%eax, %eax
14008a975: 0f 28 75 f0                 	movaps	-0x10(%rbp), %xmm6
14008a979: 48 83 c4 78                 	addq	$0x78, %rsp
14008a97d: 5b                          	popq	%rbx
14008a97e: 5f                          	popq	%rdi
14008a97f: 5e                          	popq	%rsi
14008a980: 41 5c                       	popq	%r12
14008a982: 41 5d                       	popq	%r13
14008a984: 41 5e                       	popq	%r14
14008a986: 41 5f                       	popq	%r15
14008a988: 5d                          	popq	%rbp
14008a989: c3                          	retq
14008a98a: 66 41 83 fa 02              	cmpw	$0x2, %r10w
14008a98f: 75 10                       	jne	0x14008a9a1 <.text+0x899a1>
14008a991: 49 8b 91 e0 fe ff ff        	movq	-0x120(%r9), %rdx
14008a998: 48 8d 4b 60                 	leaq	0x60(%rbx), %rcx
14008a99c: e8 3f 67 f8 ff              	callq	0x1400110e0 <.text+0x100e0>
14008a9a1: 48 8d 8b c0 00 00 00        	leaq	0xc0(%rbx), %rcx
14008a9a8: 4c 89 e2                    	movq	%r12, %rdx
14008a9ab: e8 00 70 f8 ff              	callq	0x1400119b0 <.text+0x109b0>
14008a9b0: 3c ff                       	cmpb	$-0x1, %al
14008a9b2: 0f 85 06 ff ff ff           	jne	0x14008a8be <.text+0x898be>
14008a9b8: e9 02 fd ff ff              	jmp	0x14008a6bf <.text+0x896bf>
14008a9bd: 4c 8d 05 1c 37 1e 00        	leaq	0x1e371c(%rip), %r8     # 0x14026e0e0
14008a9c4: 48 89 d1                    	movq	%rdx, %rcx
14008a9c7: 48 89 c2                    	movq	%rax, %rdx
14008a9ca: e8 84 64 1c 00              	callq	0x140250e53 <.text+0x24fe53>
14008a9cf: 0f 0b                       	ud2

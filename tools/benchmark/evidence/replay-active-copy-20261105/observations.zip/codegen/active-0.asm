
D:/CoapticCurrent/replay-active-copy-20261105/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400890a0: 55                          	pushq	%rbp
1400890a1: 41 57                       	pushq	%r15
1400890a3: 41 56                       	pushq	%r14
1400890a5: 41 55                       	pushq	%r13
1400890a7: 41 54                       	pushq	%r12
1400890a9: 56                          	pushq	%rsi
1400890aa: 57                          	pushq	%rdi
1400890ab: 53                          	pushq	%rbx
1400890ac: 48 81 ec a8 00 00 00        	subq	$0xa8, %rsp
1400890b3: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
1400890bb: 0f 29 75 10                 	movaps	%xmm6, 0x10(%rbp)
1400890bf: 4c 89 ce                    	movq	%r9, %rsi
1400890c2: 44 88 45 06                 	movb	%r8b, 0x6(%rbp)
1400890c6: 48 89 cb                    	movq	%rcx, %rbx
1400890c9: 4c 8b a2 10 01 00 00        	movq	0x110(%rdx), %r12
1400890d0: 48 8b 82 08 01 00 00        	movq	0x108(%rdx), %rax
1400890d7: 48 89 45 f0                 	movq	%rax, -0x10(%rbp)
1400890db: 8b 82 18 01 00 00           	movl	0x118(%rdx), %eax
1400890e1: 89 45 fc                    	movl	%eax, -0x4(%rbp)
1400890e4: 8b 82 1c 01 00 00           	movl	0x11c(%rdx), %eax
1400890ea: 89 45 00                    	movl	%eax, (%rbp)
1400890ed: 0f b7 82 20 01 00 00        	movzwl	0x120(%rdx), %eax
1400890f4: 66 89 45 0a                 	movw	%ax, 0xa(%rbp)
1400890f8: 0f b6 82 22 01 00 00        	movzbl	0x122(%rdx), %eax
1400890ff: 88 45 0f                    	movb	%al, 0xf(%rbp)
140089102: 0f b6 82 23 01 00 00        	movzbl	0x123(%rdx), %eax
140089109: 88 45 07                    	movb	%al, 0x7(%rbp)
14008910c: f3 0f 10 b2 24 01 00 00     	movss	0x124(%rdx), %xmm6
140089114: 0f b7 82 24 01 00 00        	movzwl	0x124(%rdx), %eax
14008911b: 66 89 45 08                 	movw	%ax, 0x8(%rbp)
14008911f: 48 8b 82 28 01 00 00        	movq	0x128(%rdx), %rax
140089126: 48 89 45 d8                 	movq	%rax, -0x28(%rbp)
14008912a: 0f b7 02                    	movzwl	(%rdx), %eax
14008912d: 66 83 f8 01                 	cmpw	$0x1, %ax
140089131: 66 89 45 0c                 	movw	%ax, 0xc(%rbp)
140089135: 75 25                       	jne	0x14008915c <.text+0x8815c>
140089137: 0f b7 42 02                 	movzwl	0x2(%rdx), %eax
14008913b: 48 3d 01 01 00 00           	cmpq	$0x101, %rax            # imm = 0x101
140089141: 72 22                       	jb	0x140089165 <.text+0x88165>
140089143: 4c 8d 0d 6e 62 1d 00        	leaq	0x1d626e(%rip), %r9     # 0x14025f3b8
14008914a: 41 b8 00 01 00 00           	movl	$0x100, %r8d            # imm = 0x100
140089150: 31 c9                       	xorl	%ecx, %ecx
140089152: 48 89 c2                    	movq	%rax, %rdx
140089155: e8 06 7f 1c 00              	callq	0x140251060 <.text+0x250060>
14008915a: 0f 0b                       	ud2
14008915c: 66 85 c0                    	testw	%ax, %ax
14008915f: 0f 84 e2 01 00 00           	je	0x140089347 <.text+0x88347>
140089165: 48 8d 82 08 01 00 00        	leaq	0x108(%rdx), %rax
14008916c: 48 89 45 c0                 	movq	%rax, -0x40(%rbp)
140089170: 48 8d 83 b8 14 00 00        	leaq	0x14b8(%rbx), %rax
140089177: 48 89 45 d0                 	movq	%rax, -0x30(%rbp)
14008917b: 48 8d 83 28 05 00 00        	leaq	0x528(%rbx), %rax
140089182: 48 89 45 c8                 	movq	%rax, -0x38(%rbp)
140089186: 48 8d 83 50 06 00 00        	leaq	0x650(%rbx), %rax
14008918d: 41 bb 04 00 00 00           	movl	$0x4, %r11d
140089193: 45 31 c9                    	xorl	%r9d, %r9d
140089196: b9 01 00 00 00              	movl	$0x1, %ecx
14008919b: 31 ff                       	xorl	%edi, %edi
14008919d: 4d 69 d1 30 01 00 00        	imulq	$0x130, %r9, %r10       # imm = 0x130
1400891a4: 49 01 c2                    	addq	%rax, %r10
1400891a7: 66 0f 1f 84 00 00 00 00 00  	nopw	(%rax,%rax)
1400891b0: 45 0f b7 b2 d8 fe ff ff     	movzwl	-0x128(%r10), %r14d
1400891b8: 66 41 83 fe ff              	cmpw	$-0x1, %r14w
1400891bd: 75 21                       	jne	0x1400891e0 <.text+0x881e0>
1400891bf: 49 ff c1                    	incq	%r9
1400891c2: 49 81 c2 30 01 00 00        	addq	$0x130, %r10            # imm = 0x130
1400891c9: 4d 39 cb                    	cmpq	%r9, %r11
1400891cc: 75 e2                       	jne	0x1400891b0 <.text+0x881b0>
1400891ce: e9 9b 00 00 00              	jmp	0x14008926e <.text+0x8826e>
1400891d3: 66 66 66 66 2e 0f 1f 84 00 00 00 00 00      	nopw	%cs:(%rax,%rax)
1400891e0: 44 0f b7 5d 08              	movzwl	0x8(%rbp), %r11d
1400891e5: 66 45 39 5a fc              	cmpw	%r11w, -0x4(%r10)
1400891ea: 75 43                       	jne	0x14008922f <.text+0x8822f>
1400891ec: 44 8b 5d fc                 	movl	-0x4(%rbp), %r11d
1400891f0: 45 39 5a f0                 	cmpl	%r11d, -0x10(%r10)
1400891f4: 75 39                       	jne	0x14008922f <.text+0x8822f>
1400891f6: 44 8b 5d 00                 	movl	(%rbp), %r11d
1400891fa: 45 39 5a f4                 	cmpl	%r11d, -0xc(%r10)
1400891fe: 75 2f                       	jne	0x14008922f <.text+0x8822f>
140089200: 44 0f b7 5d 0a              	movzwl	0xa(%rbp), %r11d
140089205: 66 45 39 5a f8              	cmpw	%r11w, -0x8(%r10)
14008920a: 75 23                       	jne	0x14008922f <.text+0x8822f>
14008920c: 44 0f b6 5d 0f              	movzbl	0xf(%rbp), %r11d
140089211: 45 38 5a fa                 	cmpb	%r11b, -0x6(%r10)
140089215: 75 18                       	jne	0x14008922f <.text+0x8822f>
140089217: 4d 8b 5a e0                 	movq	-0x20(%r10), %r11
14008921b: 4c 33 5d f0                 	xorq	-0x10(%rbp), %r11
14008921f: 4d 8b 7a e8                 	movq	-0x18(%r10), %r15
140089223: 4d 31 e7                    	xorq	%r12, %r15
140089226: 4d 09 df                    	orq	%r11, %r15
140089229: 0f 84 d6 03 00 00           	je	0x140089605 <.text+0x88605>
14008922f: 4d 8b 12                    	movq	(%r10), %r10
140089232: 4d 39 c2                    	cmpq	%r8, %r10
140089235: 41 0f 93 c3                 	setae	%r11b
140089239: 41 20 fb                    	andb	%dil, %r11b
14008923c: 4d 85 d2                    	testq	%r10, %r10
14008923f: 48 0f 45 f9                 	cmovneq	%rcx, %rdi
140089243: 41 0f 94 c6                 	sete	%r14b
140089247: 45 08 de                    	orb	%r11b, %r14b
14008924a: 4d 0f 44 e9                 	cmoveq	%r9, %r13
14008924e: 4d 8d 49 01                 	leaq	0x1(%r9), %r9
140089252: 4d 0f 44 c2                 	cmoveq	%r10, %r8
140089256: 49 83 f9 05                 	cmpq	$0x5, %r9
14008925a: 41 bb 04 00 00 00           	movl	$0x4, %r11d
140089260: 4d 0f 43 d9                 	cmovaeq	%r9, %r11
140089264: 49 83 f9 03                 	cmpq	$0x3, %r9
140089268: 0f 86 2f ff ff ff           	jbe	0x14008919d <.text+0x8819d>
14008926e: 4c 8b b3 f0 09 00 00        	movq	0x9f0(%rbx), %r14
140089275: 49 83 fe 04                 	cmpq	$0x4, %r14
140089279: 0f 85 2b 01 00 00           	jne	0x1400893aa <.text+0x883aa>
14008927f: 48 83 ff 01                 	cmpq	$0x1, %rdi
140089283: 0f 85 be 00 00 00           	jne	0x140089347 <.text+0x88347>
140089289: 4d 69 c5 30 01 00 00        	imulq	$0x130, %r13, %r8       # imm = 0x130
140089290: 48 8d 8b 28 05 00 00        	leaq	0x528(%rbx), %rcx
140089297: 46 0f b7 0c 01              	movzwl	(%rcx,%r8), %r9d
14008929c: 66 41 83 f9 ff              	cmpw	$-0x1, %r9w
1400892a1: 0f 84 02 04 00 00           	je	0x1400896a9 <.text+0x886a9>
1400892a7: 48 89 d7                    	movq	%rdx, %rdi
1400892aa: 49 01 c8                    	addq	%rcx, %r8
1400892ad: 49 8b 40 08                 	movq	0x8(%r8), %rax
1400892b1: 41 0f 10 80 18 01 00 00     	movups	0x118(%r8), %xmm0
1400892b9: 0f 29 45 b0                 	movaps	%xmm0, -0x50(%rbp)
1400892bd: 41 0f 10 80 08 01 00 00     	movups	0x108(%r8), %xmm0
1400892c5: 0f 29 45 a0                 	movaps	%xmm0, -0x60(%rbp)
1400892c9: 66 41 83 f9 02              	cmpw	$0x2, %r9w
1400892ce: 75 5d                       	jne	0x14008932d <.text+0x8832d>
1400892d0: 48 83 f8 01                 	cmpq	$0x1, %rax
1400892d4: 77 57                       	ja	0x14008932d <.text+0x8832d>
1400892d6: 80 bc 03 40 1e 00 00 01     	cmpb	$0x1, 0x1e40(%rbx,%rax)
1400892de: 75 4d                       	jne	0x14008932d <.text+0x8832d>
1400892e0: 80 bc 03 42 1e 00 00 00     	cmpb	$0x0, 0x1e42(%rbx,%rax)
1400892e8: 75 43                       	jne	0x14008932d <.text+0x8832d>
1400892ea: c6 84 03 40 1e 00 00 00     	movb	$0x0, 0x1e40(%rbx,%rax)
1400892f2: 48 ff 8b 38 1e 00 00        	decq	0x1e38(%rbx)
1400892f9: 48 c7 84 c3 b8 1d 00 00 00 00 00 00 	movq	$0x0, 0x1db8(%rbx,%rax,8)
140089305: 48 8d 14 c0                 	leaq	(%rax,%rax,8), %rdx
140089309: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008930d: 48 01 c2                    	addq	%rax, %rdx
140089310: 4c 8d 83 b8 14 00 00        	leaq	0x14b8(%rbx), %r8
140089317: 41 c6 84 10 5a 09 00 00 02  	movb	$0x2, 0x95a(%r8,%rdx)
140089320: 48 8d 04 40                 	leaq	(%rax,%rax,2), %rax
140089324: 41 c6 84 c0 1d 09 00 00 02  	movb	$0x2, 0x91d(%r8,%rax,8)
14008932d: 48 8d 55 a0                 	leaq	-0x60(%rbp), %rdx
140089331: e8 ba c8 18 00              	callq	0x140215bf0 <.text+0x214bf0>
140089336: 4c 8b b3 f0 09 00 00        	movq	0x9f0(%rbx), %r14
14008933d: 49 83 fe 04                 	cmpq	$0x4, %r14
140089341: 0f 85 1d 01 00 00           	jne	0x140089464 <.text+0x88464>
140089347: 0f b6 4d 06                 	movzbl	0x6(%rbp), %ecx
14008934b: fe c9                       	decb	%cl
14008934d: 80 f9 07                    	cmpb	$0x7, %cl
140089350: 0f 92 c0                    	setb	%al
140089353: b2 4d                       	movb	$0x4d, %dl
140089355: d2 ea                       	shrb	%cl, %dl
140089357: 84 d0                       	testb	%dl, %al
140089359: 0f 85 fe 00 00 00           	jne	0x14008945d <.text+0x8845d>
14008935f: 0f b6 46 22                 	movzbl	0x22(%rsi), %eax
140089363: 3c 02                       	cmpb	$0x2, %al
140089365: 0f 85 9d 00 00 00           	jne	0x140089408 <.text+0x88408>
14008936b: 48 8b 45 d8                 	movq	-0x28(%rbp), %rax
14008936f: 48 89 06                    	movq	%rax, (%rsi)
140089372: 48 8b 45 f0                 	movq	-0x10(%rbp), %rax
140089376: 48 89 46 08                 	movq	%rax, 0x8(%rsi)
14008937a: 4c 89 66 10                 	movq	%r12, 0x10(%rsi)
14008937e: 8b 45 fc                    	movl	-0x4(%rbp), %eax
140089381: 89 46 18                    	movl	%eax, 0x18(%rsi)
140089384: 8b 45 00                    	movl	(%rbp), %eax
140089387: 89 46 1c                    	movl	%eax, 0x1c(%rsi)
14008938a: 0f b7 45 0a                 	movzwl	0xa(%rbp), %eax
14008938e: 66 89 46 20                 	movw	%ax, 0x20(%rsi)
140089392: 0f b6 45 0f                 	movzbl	0xf(%rbp), %eax
140089396: 88 46 22                    	movb	%al, 0x22(%rsi)
140089399: 0f b6 45 07                 	movzbl	0x7(%rbp), %eax
14008939d: 88 46 23                    	movb	%al, 0x23(%rsi)
1400893a0: f3 0f 11 76 24              	movss	%xmm6, 0x24(%rsi)
1400893a5: e9 b3 00 00 00              	jmp	0x14008945d <.text+0x8845d>
1400893aa: 48 89 75 e0                 	movq	%rsi, -0x20(%rbp)
1400893ae: 4c 8b bb e8 09 00 00        	movq	0x9e8(%rbx), %r15
1400893b5: 49 83 ff 03                 	cmpq	$0x3, %r15
1400893b9: 0f 87 04 03 00 00           	ja	0x1400896c3 <.text+0x886c3>
1400893bf: 4c 89 e6                    	movq	%r12, %rsi
1400893c2: 4c 8d a3 f8 09 00 00        	leaq	0x9f8(%rbx), %r12
1400893c9: 43 80 3c 3c 00              	cmpb	$0x0, (%r12,%r15)
1400893ce: 74 2c                       	je	0x1400893fc <.text+0x883fc>
1400893d0: 48 89 55 e8                 	movq	%rdx, -0x18(%rbp)
1400893d4: 4b 8d 0c 3c                 	leaq	(%r12,%r15), %rcx
1400893d8: ba 04 00 00 00              	movl	$0x4, %edx
1400893dd: 4c 29 fa                    	subq	%r15, %rdx
1400893e0: e8 eb 6a f8 ff              	callq	0x14000fed0 <.text+0xeed0>
1400893e5: 48 83 f8 01                 	cmpq	$0x1, %rax
1400893e9: 0f 85 c2 00 00 00           	jne	0x1400894b1 <.text+0x884b1>
1400893ef: 49 01 d7                    	addq	%rdx, %r15
1400893f2: b8 01 00 00 00              	movl	$0x1, %eax
1400893f7: e9 c3 00 00 00              	jmp	0x1400894bf <.text+0x884bf>
1400893fc: 49 89 f4                    	movq	%rsi, %r12
1400893ff: 48 8b 75 e0                 	movq	-0x20(%rbp), %rsi
140089403: e9 de 00 00 00              	jmp	0x1400894e6 <.text+0x884e6>
140089408: 0f b7 4d 08                 	movzwl	0x8(%rbp), %ecx
14008940c: 66 39 4e 24                 	cmpw	%cx, 0x24(%rsi)
140089410: 0f 85 55 ff ff ff           	jne	0x14008936b <.text+0x8836b>
140089416: 8b 4d fc                    	movl	-0x4(%rbp), %ecx
140089419: 39 4e 18                    	cmpl	%ecx, 0x18(%rsi)
14008941c: 0f 85 49 ff ff ff           	jne	0x14008936b <.text+0x8836b>
140089422: 8b 4d 00                    	movl	(%rbp), %ecx
140089425: 39 4e 1c                    	cmpl	%ecx, 0x1c(%rsi)
140089428: 0f 85 3d ff ff ff           	jne	0x14008936b <.text+0x8836b>
14008942e: 0f b7 4d 0a                 	movzwl	0xa(%rbp), %ecx
140089432: 66 39 4e 20                 	cmpw	%cx, 0x20(%rsi)
140089436: 0f 85 2f ff ff ff           	jne	0x14008936b <.text+0x8836b>
14008943c: 3a 45 0f                    	cmpb	0xf(%rbp), %al
14008943f: 0f 85 26 ff ff ff           	jne	0x14008936b <.text+0x8836b>
140089445: 48 8b 46 08                 	movq	0x8(%rsi), %rax
140089449: 48 33 45 f0                 	xorq	-0x10(%rbp), %rax
14008944d: 48 8b 4e 10                 	movq	0x10(%rsi), %rcx
140089451: 4c 31 e1                    	xorq	%r12, %rcx
140089454: 48 09 c1                    	orq	%rax, %rcx
140089457: 0f 85 0e ff ff ff           	jne	0x14008936b <.text+0x8836b>
14008945d: 31 c0                       	xorl	%eax, %eax
14008945f: e9 54 01 00 00              	jmp	0x1400895b8 <.text+0x885b8>
140089464: 4c 8b bb e8 09 00 00        	movq	0x9e8(%rbx), %r15
14008946b: 49 83 ff 03                 	cmpq	$0x3, %r15
14008946f: 0f 87 4e 02 00 00           	ja	0x1400896c3 <.text+0x886c3>
140089475: 49 89 f5                    	movq	%rsi, %r13
140089478: 4c 89 e6                    	movq	%r12, %rsi
14008947b: 4c 8d a3 f8 09 00 00        	leaq	0x9f8(%rbx), %r12
140089482: 43 80 3c 3c 00              	cmpb	$0x0, (%r12,%r15)
140089487: 74 54                       	je	0x1400894dd <.text+0x884dd>
140089489: 4b 8d 0c 3c                 	leaq	(%r12,%r15), %rcx
14008948d: ba 04 00 00 00              	movl	$0x4, %edx
140089492: 4c 29 fa                    	subq	%r15, %rdx
140089495: e8 36 6a f8 ff              	callq	0x14000fed0 <.text+0xeed0>
14008949a: 48 83 f8 01                 	cmpq	$0x1, %rax
14008949e: 0f 85 2c 01 00 00           	jne	0x1400895d0 <.text+0x885d0>
1400894a4: 49 01 d7                    	addq	%rdx, %r15
1400894a7: b8 01 00 00 00              	movl	$0x1, %eax
1400894ac: e9 2d 01 00 00              	jmp	0x1400895de <.text+0x885de>
1400894b1: 4c 89 e1                    	movq	%r12, %rcx
1400894b4: 4c 89 fa                    	movq	%r15, %rdx
1400894b7: e8 14 6a f8 ff              	callq	0x14000fed0 <.text+0xeed0>
1400894bc: 49 89 d7                    	movq	%rdx, %r15
1400894bf: 48 8b 55 e8                 	movq	-0x18(%rbp), %rdx
1400894c3: 49 89 f4                    	movq	%rsi, %r12
1400894c6: a8 01                       	testb	$0x1, %al
1400894c8: 48 8b 75 e0                 	movq	-0x20(%rbp), %rsi
1400894cc: 0f 84 ad fd ff ff           	je	0x14008927f <.text+0x8827f>
1400894d2: 49 83 ff 04                 	cmpq	$0x4, %r15
1400894d6: 72 0e                       	jb	0x1400894e6 <.text+0x884e6>
1400894d8: e9 fc 01 00 00              	jmp	0x1400896d9 <.text+0x886d9>
1400894dd: 48 89 fa                    	movq	%rdi, %rdx
1400894e0: 49 89 f4                    	movq	%rsi, %r12
1400894e3: 4c 89 ee                    	movq	%r13, %rsi
1400894e6: 48 8d 8b 28 05 00 00        	leaq	0x528(%rbx), %rcx
1400894ed: 44 0f b7 55 0c              	movzwl	0xc(%rbp), %r10d
1400894f2: 49 8d 47 01                 	leaq	0x1(%r15), %rax
1400894f6: 45 31 c0                    	xorl	%r8d, %r8d
1400894f9: 48 83 f8 04                 	cmpq	$0x4, %rax
1400894fd: 4c 0f 45 c0                 	cmovneq	%rax, %r8
140089501: 42 c6 84 3b f8 09 00 00 01  	movb	$0x1, 0x9f8(%rbx,%r15)
14008950a: 4c 89 83 e8 09 00 00        	movq	%r8, 0x9e8(%rbx)
140089511: 49 ff c6                    	incq	%r14
140089514: 4c 89 b3 f0 09 00 00        	movq	%r14, 0x9f0(%rbx)
14008951b: 49 69 c7 30 01 00 00        	imulq	$0x130, %r15, %rax      # imm = 0x130
140089522: 48 01 c1                    	addq	%rax, %rcx
140089525: 66 41 83 fa 01              	cmpw	$0x1, %r10w
14008952a: 75 08                       	jne	0x140089534 <.text+0x88534>
14008952c: 41 b8 30 01 00 00           	movl	$0x130, %r8d            # imm = 0x130
140089532: eb 36                       	jmp	0x14008956a <.text+0x8856a>
140089534: 66 c7 01 00 00              	movw	$0x0, (%rcx)
140089539: 48 8b 45 c0                 	movq	-0x40(%rbp), %rax
14008953d: 0f 10 00                    	movups	(%rax), %xmm0
140089540: 0f 10 48 10                 	movups	0x10(%rax), %xmm1
140089544: 0f 11 81 08 01 00 00        	movups	%xmm0, 0x108(%rcx)
14008954b: 0f 11 89 18 01 00 00        	movups	%xmm1, 0x118(%rcx)
140089552: 48 8b 45 d8                 	movq	-0x28(%rbp), %rax
140089556: 48 89 81 28 01 00 00        	movq	%rax, 0x128(%rcx)
14008955d: 66 41 83 fa 02              	cmpw	$0x2, %r10w
140089562: 75 0b                       	jne	0x14008956f <.text+0x8856f>
140089564: 41 b8 08 01 00 00           	movl	$0x108, %r8d            # imm = 0x108
14008956a: e8 a1 70 1c 00              	callq	0x140250610 <.text+0x24f610>
14008956f: 0f b6 4e 22                 	movzbl	0x22(%rsi), %ecx
140089573: b0 01                       	movb	$0x1, %al
140089575: 80 f9 02                    	cmpb	$0x2, %cl
140089578: 74 3e                       	je	0x1400895b8 <.text+0x885b8>
14008957a: 0f b7 55 08                 	movzwl	0x8(%rbp), %edx
14008957e: 66 39 56 24                 	cmpw	%dx, 0x24(%rsi)
140089582: 75 34                       	jne	0x1400895b8 <.text+0x885b8>
140089584: 8b 55 fc                    	movl	-0x4(%rbp), %edx
140089587: 39 56 18                    	cmpl	%edx, 0x18(%rsi)
14008958a: 75 2c                       	jne	0x1400895b8 <.text+0x885b8>
14008958c: 8b 55 00                    	movl	(%rbp), %edx
14008958f: 39 56 1c                    	cmpl	%edx, 0x1c(%rsi)
140089592: 75 24                       	jne	0x1400895b8 <.text+0x885b8>
140089594: 0f b7 55 0a                 	movzwl	0xa(%rbp), %edx
140089598: 66 39 56 20                 	cmpw	%dx, 0x20(%rsi)
14008959c: 75 1a                       	jne	0x1400895b8 <.text+0x885b8>
14008959e: 3a 4d 0f                    	cmpb	0xf(%rbp), %cl
1400895a1: 75 15                       	jne	0x1400895b8 <.text+0x885b8>
1400895a3: 48 8b 4d f0                 	movq	-0x10(%rbp), %rcx
1400895a7: 48 33 4e 08                 	xorq	0x8(%rsi), %rcx
1400895ab: 4c 33 66 10                 	xorq	0x10(%rsi), %r12
1400895af: 49 09 cc                    	orq	%rcx, %r12
1400895b2: 75 04                       	jne	0x1400895b8 <.text+0x885b8>
1400895b4: c6 46 22 02                 	movb	$0x2, 0x22(%rsi)
1400895b8: 0f 28 75 10                 	movaps	0x10(%rbp), %xmm6
1400895bc: 48 81 c4 a8 00 00 00        	addq	$0xa8, %rsp
1400895c3: 5b                          	popq	%rbx
1400895c4: 5f                          	popq	%rdi
1400895c5: 5e                          	popq	%rsi
1400895c6: 41 5c                       	popq	%r12
1400895c8: 41 5d                       	popq	%r13
1400895ca: 41 5e                       	popq	%r14
1400895cc: 41 5f                       	popq	%r15
1400895ce: 5d                          	popq	%rbp
1400895cf: c3                          	retq
1400895d0: 4c 89 e1                    	movq	%r12, %rcx
1400895d3: 4c 89 fa                    	movq	%r15, %rdx
1400895d6: e8 f5 68 f8 ff              	callq	0x14000fed0 <.text+0xeed0>
1400895db: 49 89 d7                    	movq	%rdx, %r15
1400895de: 49 89 f4                    	movq	%rsi, %r12
1400895e1: a8 01                       	testb	$0x1, %al
1400895e3: 4c 89 ee                    	movq	%r13, %rsi
1400895e6: 48 8d 8b 28 05 00 00        	leaq	0x528(%rbx), %rcx
1400895ed: 0f 84 54 fd ff ff           	je	0x140089347 <.text+0x88347>
1400895f3: 49 83 ff 04                 	cmpq	$0x4, %r15
1400895f7: 0f 83 dc 00 00 00           	jae	0x1400896d9 <.text+0x886d9>
1400895fd: 48 89 fa                    	movq	%rdi, %rdx
140089600: e9 e8 fe ff ff              	jmp	0x1400894ed <.text+0x884ed>
140089605: 49 89 d7                    	movq	%rdx, %r15
140089608: 49 8b 82 e0 fe ff ff        	movq	-0x120(%r10), %rax
14008960f: 41 0f 10 42 f0              	movups	-0x10(%r10), %xmm0
140089614: 0f 29 45 b0                 	movaps	%xmm0, -0x50(%rbp)
140089618: 41 0f 10 42 e0              	movups	-0x20(%r10), %xmm0
14008961d: 0f 29 45 a0                 	movaps	%xmm0, -0x60(%rbp)
140089621: 66 41 83 fe 02              	cmpw	$0x2, %r14w
140089626: 75 58                       	jne	0x140089680 <.text+0x88680>
140089628: 48 83 f8 01                 	cmpq	$0x1, %rax
14008962c: 77 52                       	ja	0x140089680 <.text+0x88680>
14008962e: 80 bc 03 40 1e 00 00 01     	cmpb	$0x1, 0x1e40(%rbx,%rax)
140089636: 75 48                       	jne	0x140089680 <.text+0x88680>
140089638: 80 bc 03 42 1e 00 00 00     	cmpb	$0x0, 0x1e42(%rbx,%rax)
140089640: 75 3e                       	jne	0x140089680 <.text+0x88680>
140089642: c6 84 03 40 1e 00 00 00     	movb	$0x0, 0x1e40(%rbx,%rax)
14008964a: 48 ff 8b 38 1e 00 00        	decq	0x1e38(%rbx)
140089651: 48 c7 84 c3 b8 1d 00 00 00 00 00 00 	movq	$0x0, 0x1db8(%rbx,%rax,8)
14008965d: 48 8d 0c c0                 	leaq	(%rax,%rax,8), %rcx
140089661: 48 8d 0c 49                 	leaq	(%rcx,%rcx,2), %rcx
140089665: 48 01 c1                    	addq	%rax, %rcx
140089668: 48 8b 55 d0                 	movq	-0x30(%rbp), %rdx
14008966c: c6 84 0a 5a 09 00 00 02     	movb	$0x2, 0x95a(%rdx,%rcx)
140089674: 48 8d 04 40                 	leaq	(%rax,%rax,2), %rax
140089678: c6 84 c2 1d 09 00 00 02     	movb	$0x2, 0x91d(%rdx,%rax,8)
140089680: 48 8d 55 a0                 	leaq	-0x60(%rbp), %rdx
140089684: 48 8b 7d c8                 	movq	-0x38(%rbp), %rdi
140089688: 48 89 f9                    	movq	%rdi, %rcx
14008968b: e8 60 c5 18 00              	callq	0x140215bf0 <.text+0x214bf0>
140089690: 48 89 f9                    	movq	%rdi, %rcx
140089693: 4c 89 fa                    	movq	%r15, %rdx
140089696: e8 05 c2 18 00              	callq	0x1402158a0 <.text+0x2148a0>
14008969b: 48 85 c0                    	testq	%rax, %rax
14008969e: 0f 85 cb fe ff ff           	jne	0x14008956f <.text+0x8856f>
1400896a4: e9 9e fc ff ff              	jmp	0x140089347 <.text+0x88347>
1400896a9: 48 8d 0d a0 02 1e 00        	leaq	0x1e02a0(%rip), %rcx    # 0x140269950
1400896b0: 4c 8d 05 b1 02 1e 00        	leaq	0x1e02b1(%rip), %r8     # 0x140269968
1400896b7: ba 15 00 00 00              	movl	$0x15, %edx
1400896bc: e8 af 76 1c 00              	callq	0x140250d70 <.text+0x24fd70>
1400896c1: 0f 0b                       	ud2
1400896c3: 4c 8d 05 26 63 1d 00        	leaq	0x1d6326(%rip), %r8     # 0x14025f9f0
1400896ca: ba 04 00 00 00              	movl	$0x4, %edx
1400896cf: 4c 89 f9                    	movq	%r15, %rcx
1400896d2: e8 7c 77 1c 00              	callq	0x140250e53 <.text+0x24fe53>
1400896d7: 0f 0b                       	ud2
1400896d9: 4c 8d 05 28 63 1d 00        	leaq	0x1d6328(%rip), %r8     # 0x14025fa08
1400896e0: ba 04 00 00 00              	movl	$0x4, %edx
1400896e5: 4c 89 f9                    	movq	%r15, %rcx
1400896e8: e8 66 77 1c 00              	callq	0x140250e53 <.text+0x24fe53>
1400896ed: 0f 0b                       	ud2

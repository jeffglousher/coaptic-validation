
D:/CoapticCurrent/replay-active-copy-20261105/scalar-pin/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400917b0: 55                          	pushq	%rbp
1400917b1: 41 57                       	pushq	%r15
1400917b3: 41 56                       	pushq	%r14
1400917b5: 41 55                       	pushq	%r13
1400917b7: 41 54                       	pushq	%r12
1400917b9: 56                          	pushq	%rsi
1400917ba: 57                          	pushq	%rdi
1400917bb: 53                          	pushq	%rbx
1400917bc: 48 81 ec 68 01 00 00        	subq	$0x168, %rsp            # imm = 0x168
1400917c3: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
1400917cb: b0 01                       	movb	$0x1, %al
1400917cd: 80 bd 50 01 00 00 00        	cmpb	$0x0, 0x150(%rbp)
1400917d4: 0f 85 47 01 00 00           	jne	0x140091921 <.text+0x90921>
1400917da: 44 89 ce                    	movl	%r9d, %esi
1400917dd: 4d 89 c2                    	movq	%r8, %r10
1400917e0: 4c 8b 8d 68 01 00 00        	movq	0x168(%rbp), %r9
1400917e7: 44 0f b6 85 60 01 00 00     	movzbl	0x160(%rbp), %r8d
1400917ef: 4c 8b 9d 58 01 00 00        	movq	0x158(%rbp), %r11
1400917f6: 4c 89 d8                    	movq	%r11, %rax
1400917f9: 48 05 d8 c4 03 00           	addq	$0x3c4d8, %rax          # imm = 0x3C4D8
1400917ff: 48 c7 c7 ff ff ff ff        	movq	$-0x1, %rdi
140091806: 48 0f 43 f8                 	cmovaeq	%rax, %rdi
14009180a: 41 0f 10 02                 	movups	(%r10), %xmm0
14009180e: 41 0f 10 4a 0c              	movups	0xc(%r10), %xmm1
140091813: 0f 11 8d cc 00 00 00        	movups	%xmm1, 0xcc(%rbp)
14009181a: 0f 11 85 c0 00 00 00        	movups	%xmm0, 0xc0(%rbp)
140091821: 66 89 b5 dc 00 00 00        	movw	%si, 0xdc(%rbp)
140091828: 48 89 bd e0 00 00 00        	movq	%rdi, 0xe0(%rbp)
14009182f: 80 bc 11 40 1e 00 00 01     	cmpb	$0x1, 0x1e40(%rcx,%rdx)
140091837: 75 0a                       	jne	0x140091843 <.text+0x90843>
140091839: 80 bc 11 42 1e 00 00 00     	cmpb	$0x0, 0x1e42(%rcx,%rdx)
140091841: 74 1f                       	je	0x140091862 <.text+0x90862>
140091843: 4c 89 4c 24 28              	movq	%r9, 0x28(%rsp)
140091848: 44 88 44 24 20              	movb	%r8b, 0x20(%rsp)
14009184d: 4c 89 d2                    	movq	%r10, %rdx
140091850: 41 89 f0                    	movl	%esi, %r8d
140091853: 4d 89 d9                    	movq	%r11, %r9
140091856: e8 55 61 00 00              	callq	0x1400979b0 <.text+0x969b0>
14009185b: b0 01                       	movb	$0x1, %al
14009185d: e9 bf 00 00 00              	jmp	0x140091921 <.text+0x90921>
140091862: c6 84 11 42 1e 00 00 01     	movb	$0x1, 0x1e42(%rcx,%rdx)
14009186a: 48 8b b4 d1 b8 1d 00 00     	movq	0x1db8(%rcx,%rdx,8), %rsi
140091872: 48 81 fe 81 04 00 00        	cmpq	$0x481, %rsi            # imm = 0x481
140091879: 0f 83 b6 00 00 00           	jae	0x140091935 <.text+0x90935>
14009187f: 48 81 fe 01 01 00 00        	cmpq	$0x101, %rsi            # imm = 0x101
140091886: 72 0c                       	jb	0x140091894 <.text+0x90894>
140091888: 66 c7 45 b8 02 00           	movw	$0x2, -0x48(%rbp)
14009188e: 48 89 55 c0                 	movq	%rdx, -0x40(%rbp)
140091892: eb 6e                       	jmp	0x140091902 <.text+0x90902>
140091894: 48 85 f6                    	testq	%rsi, %rsi
140091897: 74 63                       	je	0x1400918fc <.text+0x908fc>
140091899: 48 8d 81 b8 14 00 00        	leaq	0x14b8(%rcx), %rax
1400918a0: 48 8d 3c d2                 	leaq	(%rdx,%rdx,8), %rdi
1400918a4: 48 c1 e7 07                 	shlq	$0x7, %rdi
1400918a8: 48 01 c7                    	addq	%rax, %rdi
1400918ab: 66 89 75 ba                 	movw	%si, -0x46(%rbp)
1400918af: 48 8d 5d bc                 	leaq	-0x44(%rbp), %rbx
1400918b3: b8 00 01 00 00              	movl	$0x100, %eax            # imm = 0x100
1400918b8: 48 29 f0                    	subq	%rsi, %rax
1400918bb: 4c 8d 14 2e                 	leaq	(%rsi,%rbp), %r10
1400918bf: 49 83 c2 bc                 	addq	$-0x44, %r10
1400918c3: 49 89 ce                    	movq	%rcx, %r14
1400918c6: 4c 89 d1                    	movq	%r10, %rcx
1400918c9: 49 89 d7                    	movq	%rdx, %r15
1400918cc: 31 d2                       	xorl	%edx, %edx
1400918ce: 45 89 c4                    	movl	%r8d, %r12d
1400918d1: 49 89 c0                    	movq	%rax, %r8
1400918d4: 4d 89 cd                    	movq	%r9, %r13
1400918d7: e8 66 ea 1b 00              	callq	0x140250342 <.text+0x24f342>
1400918dc: 48 89 d9                    	movq	%rbx, %rcx
1400918df: 48 89 fa                    	movq	%rdi, %rdx
1400918e2: 49 89 f0                    	movq	%rsi, %r8
1400918e5: e8 46 ea 1b 00              	callq	0x140250330 <.text+0x24f330>
1400918ea: 4c 89 fa                    	movq	%r15, %rdx
1400918ed: 45 89 e0                    	movl	%r12d, %r8d
1400918f0: 4d 89 e9                    	movq	%r13, %r9
1400918f3: 4c 89 f1                    	movq	%r14, %rcx
1400918f6: 66 b8 01 00                 	movw	$0x1, %ax
1400918fa: eb 02                       	jmp	0x1400918fe <.text+0x908fe>
1400918fc: 31 c0                       	xorl	%eax, %eax
1400918fe: 66 89 45 b8                 	movw	%ax, -0x48(%rbp)
140091902: 48 81 fe 01 01 00 00        	cmpq	$0x101, %rsi            # imm = 0x101
140091909: 0f 92 c3                    	setb	%bl
14009190c: c6 84 11 42 1e 00 00 00     	movb	$0x0, 0x1e42(%rcx,%rdx)
140091914: 48 8d 55 b8                 	leaq	-0x48(%rbp), %rdx
140091918: e8 f3 76 ff ff              	callq	0x140089010 <.text+0x88010>
14009191d: 34 01                       	xorb	$0x1, %al
14009191f: 08 d8                       	orb	%bl, %al
140091921: 48 81 c4 68 01 00 00        	addq	$0x168, %rsp            # imm = 0x168
140091928: 5b                          	popq	%rbx
140091929: 5f                          	popq	%rdi
14009192a: 5e                          	popq	%rsi
14009192b: 41 5c                       	popq	%r12
14009192d: 41 5d                       	popq	%r13
14009192f: 41 5e                       	popq	%r14
140091931: 41 5f                       	popq	%r15
140091933: 5d                          	popq	%rbp
140091934: c3                          	retq
140091935: 4c 8d 0d 9c a0 1d 00        	leaq	0x1da09c(%rip), %r9     # 0x14026b9d8
14009193c: 41 b8 80 04 00 00           	movl	$0x480, %r8d            # imm = 0x480
140091942: 31 c9                       	xorl	%ecx, %ecx
140091944: 48 89 f2                    	movq	%rsi, %rdx
140091947: e8 34 f4 1b 00              	callq	0x140250d80 <.text+0x24fd80>
14009194c: 0f 0b                       	ud2


D:/CoapticCurrent/oscore-packet-staging-20261104/option-reuse/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14008a390: 55                          	pushq	%rbp
14008a391: 41 57                       	pushq	%r15
14008a393: 41 56                       	pushq	%r14
14008a395: 41 55                       	pushq	%r13
14008a397: 41 54                       	pushq	%r12
14008a399: 56                          	pushq	%rsi
14008a39a: 57                          	pushq	%rdi
14008a39b: 53                          	pushq	%rbx
14008a39c: 48 83 ec 78                 	subq	$0x78, %rsp
14008a3a0: 48 8d 6c 24 70              	leaq	0x70(%rsp), %rbp
14008a3a5: 0f 29 75 f0                 	movaps	%xmm6, -0x10(%rbp)
14008a3a9: 48 89 d7                    	movq	%rdx, %rdi
14008a3ac: 0f b7 92 38 01 00 00        	movzwl	0x138(%rdx), %edx
14008a3b3: 48 81 fa 01 01 00 00        	cmpq	$0x101, %rdx            # imm = 0x101
14008a3ba: 0f 83 14 04 00 00           	jae	0x14008a7d4 <.text+0x897d4>
14008a3c0: 4c 89 ce                    	movq	%r9, %rsi
14008a3c3: 45 89 c6                    	movl	%r8d, %r14d
14008a3c6: 48 89 cb                    	movq	%rcx, %rbx
14008a3c9: 48 8b 47 10                 	movq	0x10(%rdi), %rax
14008a3cd: 48 89 45 c0                 	movq	%rax, -0x40(%rbp)
14008a3d1: 4c 8b 67 18                 	movq	0x18(%rdi), %r12
14008a3d5: 8b 47 20                    	movl	0x20(%rdi), %eax
14008a3d8: 89 45 e0                    	movl	%eax, -0x20(%rbp)
14008a3db: 8b 47 24                    	movl	0x24(%rdi), %eax
14008a3de: 89 45 e4                    	movl	%eax, -0x1c(%rbp)
14008a3e1: 0f b7 47 28                 	movzwl	0x28(%rdi), %eax
14008a3e5: 66 89 45 ea                 	movw	%ax, -0x16(%rbp)
14008a3e9: 0f b6 47 2a                 	movzbl	0x2a(%rdi), %eax
14008a3ed: 88 45 ef                    	movb	%al, -0x11(%rbp)
14008a3f0: 0f b6 47 2b                 	movzbl	0x2b(%rdi), %eax
14008a3f4: 88 45 e9                    	movb	%al, -0x17(%rbp)
14008a3f7: f3 0f 10 77 2c              	movss	0x2c(%rdi), %xmm6
14008a3fc: 0f b7 47 2c                 	movzwl	0x2c(%rdi), %eax
14008a400: 66 89 45 ec                 	movw	%ax, -0x14(%rbp)
14008a404: 4c 8b 6f 30                 	movq	0x30(%rdi), %r13
14008a408: 48 85 d2                    	testq	%rdx, %rdx
14008a40b: 75 6d                       	jne	0x14008a47a <.text+0x8947a>
14008a40d: 80 3f 00                    	cmpb	$0x0, (%rdi)
14008a410: 75 68                       	jne	0x14008a47a <.text+0x8947a>
14008a412: 41 fe ce                    	decb	%r14b
14008a415: 41 80 fe 07                 	cmpb	$0x7, %r14b
14008a419: 0f 92 c0                    	setb	%al
14008a41c: b2 4d                       	movb	$0x4d, %dl
14008a41e: 44 89 f1                    	movl	%r14d, %ecx
14008a421: d2 ea                       	shrb	%cl, %dl
14008a423: 84 d0                       	testb	%dl, %al
14008a425: 0f 85 63 03 00 00           	jne	0x14008a78e <.text+0x8978e>
14008a42b: 0f b6 46 22                 	movzbl	0x22(%rsi), %eax
14008a42f: 3c 02                       	cmpb	$0x2, %al
14008a431: 48 8b 55 c0                 	movq	-0x40(%rbp), %rdx
14008a435: 44 0f b6 45 ef              	movzbl	-0x11(%rbp), %r8d
14008a43a: 44 0f b7 4d ea              	movzwl	-0x16(%rbp), %r9d
14008a43f: 44 8b 55 e4                 	movl	-0x1c(%rbp), %r10d
14008a443: 44 8b 5d e0                 	movl	-0x20(%rbp), %r11d
14008a447: 0f 85 f4 02 00 00           	jne	0x14008a741 <.text+0x89741>
14008a44d: 4c 89 2e                    	movq	%r13, (%rsi)
14008a450: 48 89 56 08                 	movq	%rdx, 0x8(%rsi)
14008a454: 4c 89 66 10                 	movq	%r12, 0x10(%rsi)
14008a458: 44 89 5e 18                 	movl	%r11d, 0x18(%rsi)
14008a45c: 44 89 56 1c                 	movl	%r10d, 0x1c(%rsi)
14008a460: 66 44 89 4e 20              	movw	%r9w, 0x20(%rsi)
14008a465: 44 88 46 22                 	movb	%r8b, 0x22(%rsi)
14008a469: 0f b6 45 e9                 	movzbl	-0x17(%rbp), %eax
14008a46d: 88 46 23                    	movb	%al, 0x23(%rsi)
14008a470: f3 0f 11 76 24              	movss	%xmm6, 0x24(%rsi)
14008a475: e9 14 03 00 00              	jmp	0x14008a78e <.text+0x8978e>
14008a47a: 4c 89 65 c8                 	movq	%r12, -0x38(%rbp)
14008a47e: 48 8b 83 e8 00 00 00        	movq	0xe8(%rbx), %rax
14008a485: 48 85 c0                    	testq	%rax, %rax
14008a488: 0f 84 0b 01 00 00           	je	0x14008a599 <.text+0x89599>
14008a48e: 48 8b 8b e0 00 00 00        	movq	0xe0(%rbx), %rcx
14008a495: 48 8b 93 c8 00 00 00        	movq	0xc8(%rbx), %rdx
14008a49c: 4c 8b 83 d0 00 00 00        	movq	0xd0(%rbx), %r8
14008a4a3: 48 83 c2 30                 	addq	$0x30, %rdx
14008a4a7: 49 c7 c7 ff ff ff ff        	movq	$-0x1, %r15
14008a4ae: 45 31 e4                    	xorl	%r12d, %r12d
14008a4b1: 48 c7 45 d8 00 00 00 00     	movq	$0x0, -0x28(%rbp)
14008a4b9: 4f 8d 14 a4                 	leaq	(%r12,%r12,4), %r10
14008a4bd: 49 c1 e2 06                 	shlq	$0x6, %r10
14008a4c1: 49 01 d2                    	addq	%rdx, %r10
14008a4c4: eb 1d                       	jmp	0x14008a4e3 <.text+0x894e3>
14008a4c6: 66 2e 0f 1f 84 00 00 00 00 00       	nopw	%cs:(%rax,%rax)
14008a4d0: 49 ff c4                    	incq	%r12
14008a4d3: 49 81 c2 40 01 00 00        	addq	$0x140, %r10            # imm = 0x140
14008a4da: 49 39 c4                    	cmpq	%rax, %r12
14008a4dd: 0f 83 be 00 00 00           	jae	0x14008a5a1 <.text+0x895a1>
14008a4e3: 49 39 c4                    	cmpq	%rax, %r12
14008a4e6: 73 e8                       	jae	0x14008a4d0 <.text+0x894d0>
14008a4e8: 42 80 3c 21 01              	cmpb	$0x1, (%rcx,%r12)
14008a4ed: 75 e1                       	jne	0x14008a4d0 <.text+0x894d0>
14008a4ef: 4d 39 c4                    	cmpq	%r8, %r12
14008a4f2: 73 dc                       	jae	0x14008a4d0 <.text+0x894d0>
14008a4f4: 4d 8b 5a d0                 	movq	-0x30(%r10), %r11
14008a4f8: 49 83 fb 02                 	cmpq	$0x2, %r11
14008a4fc: 74 d2                       	je	0x14008a4d0 <.text+0x894d0>
14008a4fe: 44 0f b7 4d ec              	movzwl	-0x14(%rbp), %r9d
14008a503: 66 45 39 4a fc              	cmpw	%r9w, -0x4(%r10)
14008a508: 75 4c                       	jne	0x14008a556 <.text+0x89556>
14008a50a: 44 8b 4d e0                 	movl	-0x20(%rbp), %r9d
14008a50e: 45 39 4a f0                 	cmpl	%r9d, -0x10(%r10)
14008a512: 75 42                       	jne	0x14008a556 <.text+0x89556>
14008a514: 44 8b 4d e4                 	movl	-0x1c(%rbp), %r9d
14008a518: 45 39 4a f4                 	cmpl	%r9d, -0xc(%r10)
14008a51c: 75 38                       	jne	0x14008a556 <.text+0x89556>
14008a51e: 44 0f b7 4d ea              	movzwl	-0x16(%rbp), %r9d
14008a523: 66 45 39 4a f8              	cmpw	%r9w, -0x8(%r10)
14008a528: 75 2c                       	jne	0x14008a556 <.text+0x89556>
14008a52a: 44 0f b6 4d ef              	movzbl	-0x11(%rbp), %r9d
14008a52f: 45 38 4a fa                 	cmpb	%r9b, -0x6(%r10)
14008a533: 75 21                       	jne	0x14008a556 <.text+0x89556>
14008a535: 4c 89 7d b8                 	movq	%r15, -0x48(%rbp)
14008a539: 4d 8b 7a e0                 	movq	-0x20(%r10), %r15
14008a53d: 4c 33 7d c0                 	xorq	-0x40(%rbp), %r15
14008a541: 4d 8b 4a e8                 	movq	-0x18(%r10), %r9
14008a545: 4c 33 4d c8                 	xorq	-0x38(%rbp), %r9
14008a549: 4d 09 f9                    	orq	%r15, %r9
14008a54c: 4c 8b 7d b8                 	movq	-0x48(%rbp), %r15
14008a550: 0f 84 4f 02 00 00           	je	0x14008a7a5 <.text+0x897a5>
14008a556: 4d 8b 12                    	movq	(%r10), %r10
14008a559: 4d 85 d2                    	testq	%r10, %r10
14008a55c: 74 2d                       	je	0x14008a58b <.text+0x8958b>
14008a55e: 48 83 7d d8 00              	cmpq	$0x0, -0x28(%rbp)
14008a563: 41 0f 94 c1                 	sete	%r9b
14008a567: 4d 39 fa                    	cmpq	%r15, %r10
14008a56a: 41 0f 92 c3                 	setb	%r11b
14008a56e: 45 08 cb                    	orb	%r9b, %r11b
14008a571: 4c 8b 4d d0                 	movq	-0x30(%rbp), %r9
14008a575: 4d 0f 45 cc                 	cmovneq	%r12, %r9
14008a579: 4c 89 4d d0                 	movq	%r9, -0x30(%rbp)
14008a57d: 4d 0f 45 fa                 	cmovneq	%r10, %r15
14008a581: 41 b9 01 00 00 00           	movl	$0x1, %r9d
14008a587: 4c 89 4d d8                 	movq	%r9, -0x28(%rbp)
14008a58b: 49 ff c4                    	incq	%r12
14008a58e: 49 39 c4                    	cmpq	%rax, %r12
14008a591: 0f 82 22 ff ff ff           	jb	0x14008a4b9 <.text+0x894b9>
14008a597: eb 08                       	jmp	0x14008a5a1 <.text+0x895a1>
14008a599: 48 c7 45 d8 00 00 00 00     	movq	$0x0, -0x28(%rbp)
14008a5a1: 4c 8d bb d8 00 00 00        	leaq	0xd8(%rbx), %r15
14008a5a8: 4c 89 f9                    	movq	%r15, %rcx
14008a5ab: e8 b0 0b f8 ff              	callq	0x14000b160 <.text+0xa160>
14008a5b0: a8 01                       	testb	$0x1, %al
14008a5b2: 0f 84 b6 00 00 00           	je	0x14008a66e <.text+0x8966e>
14008a5b8: 4d 85 ed                    	testq	%r13, %r13
14008a5bb: 74 16                       	je	0x14008a5d3 <.text+0x895d3>
14008a5bd: 48 8b 83 18 01 00 00        	movq	0x118(%rbx), %rax
14008a5c4: 48 ff c8                    	decq	%rax
14008a5c7: 4c 39 e8                    	cmpq	%r13, %rax
14008a5ca: 72 07                       	jb	0x14008a5d3 <.text+0x895d3>
14008a5cc: 4c 89 ab 18 01 00 00        	movq	%r13, 0x118(%rbx)
14008a5d3: 48 8b 83 d0 00 00 00        	movq	0xd0(%rbx), %rax
14008a5da: 48 39 c2                    	cmpq	%rax, %rdx
14008a5dd: 0f 83 07 02 00 00           	jae	0x14008a7ea <.text+0x897ea>
14008a5e3: 48 8d 0c 92                 	leaq	(%rdx,%rdx,4), %rcx
14008a5e7: 48 c1 e1 06                 	shlq	$0x6, %rcx
14008a5eb: 48 03 8b c8 00 00 00        	addq	0xc8(%rbx), %rcx
14008a5f2: 41 b8 40 01 00 00           	movl	$0x140, %r8d            # imm = 0x140
14008a5f8: 48 89 fa                    	movq	%rdi, %rdx
14008a5fb: e8 10 68 1c 00              	callq	0x140250e10 <.text+0x24fe10>
14008a600: 0f b6 4e 22                 	movzbl	0x22(%rsi), %ecx
14008a604: b0 01                       	movb	$0x1, %al
14008a606: 80 f9 02                    	cmpb	$0x2, %cl
14008a609: 0f 84 81 01 00 00           	je	0x14008a790 <.text+0x89790>
14008a60f: 0f b7 55 ec                 	movzwl	-0x14(%rbp), %edx
14008a613: 66 39 56 24                 	cmpw	%dx, 0x24(%rsi)
14008a617: 0f 85 73 01 00 00           	jne	0x14008a790 <.text+0x89790>
14008a61d: 8b 55 e0                    	movl	-0x20(%rbp), %edx
14008a620: 39 56 18                    	cmpl	%edx, 0x18(%rsi)
14008a623: 0f 85 67 01 00 00           	jne	0x14008a790 <.text+0x89790>
14008a629: 8b 55 e4                    	movl	-0x1c(%rbp), %edx
14008a62c: 39 56 1c                    	cmpl	%edx, 0x1c(%rsi)
14008a62f: 0f 85 5b 01 00 00           	jne	0x14008a790 <.text+0x89790>
14008a635: 0f b7 55 ea                 	movzwl	-0x16(%rbp), %edx
14008a639: 66 39 56 20                 	cmpw	%dx, 0x20(%rsi)
14008a63d: 0f 85 4d 01 00 00           	jne	0x14008a790 <.text+0x89790>
14008a643: 3a 4d ef                    	cmpb	-0x11(%rbp), %cl
14008a646: 0f 85 44 01 00 00           	jne	0x14008a790 <.text+0x89790>
14008a64c: 48 8b 55 c0                 	movq	-0x40(%rbp), %rdx
14008a650: 48 33 56 08                 	xorq	0x8(%rsi), %rdx
14008a654: 48 8b 4d c8                 	movq	-0x38(%rbp), %rcx
14008a658: 48 33 4e 10                 	xorq	0x10(%rsi), %rcx
14008a65c: 48 09 d1                    	orq	%rdx, %rcx
14008a65f: 0f 85 2b 01 00 00           	jne	0x14008a790 <.text+0x89790>
14008a665: c6 46 22 02                 	movb	$0x2, 0x22(%rsi)
14008a669: e9 22 01 00 00              	jmp	0x14008a790 <.text+0x89790>
14008a66e: 48 83 7d d8 01              	cmpq	$0x1, -0x28(%rbp)
14008a673: 4c 8b 65 c8                 	movq	-0x38(%rbp), %r12
14008a677: 0f 85 95 fd ff ff           	jne	0x14008a412 <.text+0x89412>
14008a67d: 48 8b 83 e8 00 00 00        	movq	0xe8(%rbx), %rax
14008a684: 4c 8b 45 d0                 	movq	-0x30(%rbp), %r8
14008a688: 49 39 c0                    	cmpq	%rax, %r8
14008a68b: 73 47                       	jae	0x14008a6d4 <.text+0x896d4>
14008a68d: 48 8b 8b e0 00 00 00        	movq	0xe0(%rbx), %rcx
14008a694: 42 80 3c 01 01              	cmpb	$0x1, (%rcx,%r8)
14008a699: 75 39                       	jne	0x14008a6d4 <.text+0x896d4>
14008a69b: 4c 3b 83 d0 00 00 00        	cmpq	0xd0(%rbx), %r8
14008a6a2: 73 30                       	jae	0x14008a6d4 <.text+0x896d4>
14008a6a4: 48 8b 8b c8 00 00 00        	movq	0xc8(%rbx), %rcx
14008a6ab: 4b 8d 14 80                 	leaq	(%r8,%r8,4), %rdx
14008a6af: 48 c1 e2 06                 	shlq	$0x6, %rdx
14008a6b3: 83 3c 11 01                 	cmpl	$0x1, (%rcx,%rdx)
14008a6b7: 75 1b                       	jne	0x14008a6d4 <.text+0x896d4>
14008a6b9: 48 01 d1                    	addq	%rdx, %rcx
14008a6bc: 48 8b 51 08                 	movq	0x8(%rcx), %rdx
14008a6c0: 48 8d 4b 60                 	leaq	0x60(%rbx), %rcx
14008a6c4: e8 17 6a f8 ff              	callq	0x1400110e0 <.text+0x100e0>
14008a6c9: 4c 8b 45 d0                 	movq	-0x30(%rbp), %r8
14008a6cd: 48 8b 83 e8 00 00 00        	movq	0xe8(%rbx), %rax
14008a6d4: 49 39 c0                    	cmpq	%rax, %r8
14008a6d7: 73 51                       	jae	0x14008a72a <.text+0x8972a>
14008a6d9: 48 8b 83 e0 00 00 00        	movq	0xe0(%rbx), %rax
14008a6e0: 42 80 3c 00 01              	cmpb	$0x1, (%rax,%r8)
14008a6e5: 75 43                       	jne	0x14008a72a <.text+0x8972a>
14008a6e7: 4c 3b 83 00 01 00 00        	cmpq	0x100(%rbx), %r8
14008a6ee: 73 0e                       	jae	0x14008a6fe <.text+0x896fe>
14008a6f0: 48 8b 8b f8 00 00 00        	movq	0xf8(%rbx), %rcx
14008a6f7: 42 80 3c 01 00              	cmpb	$0x0, (%rcx,%r8)
14008a6fc: 75 2c                       	jne	0x14008a72a <.text+0x8972a>
14008a6fe: 42 c6 04 00 00              	movb	$0x0, (%rax,%r8)
14008a703: 48 ff 8b 10 01 00 00        	decq	0x110(%rbx)
14008a70a: 4c 3b 83 d0 00 00 00        	cmpq	0xd0(%rbx), %r8
14008a711: 73 17                       	jae	0x14008a72a <.text+0x8972a>
14008a713: 48 8b 83 c8 00 00 00        	movq	0xc8(%rbx), %rax
14008a71a: 4b 8d 0c 80                 	leaq	(%r8,%r8,4), %rcx
14008a71e: 48 c1 e1 06                 	shlq	$0x6, %rcx
14008a722: 48 c7 04 08 02 00 00 00     	movq	$0x2, (%rax,%rcx)
14008a72a: 4c 89 f9                    	movq	%r15, %rcx
14008a72d: e8 2e 0a f8 ff              	callq	0x14000b160 <.text+0xa160>
14008a732: 48 83 f8 01                 	cmpq	$0x1, %rax
14008a736: 0f 85 d6 fc ff ff           	jne	0x14008a412 <.text+0x89412>
14008a73c: e9 77 fe ff ff              	jmp	0x14008a5b8 <.text+0x895b8>
14008a741: 0f b7 4d ec                 	movzwl	-0x14(%rbp), %ecx
14008a745: 66 39 4e 24                 	cmpw	%cx, 0x24(%rsi)
14008a749: 0f 85 fe fc ff ff           	jne	0x14008a44d <.text+0x8944d>
14008a74f: 44 39 5e 18                 	cmpl	%r11d, 0x18(%rsi)
14008a753: 0f 85 f4 fc ff ff           	jne	0x14008a44d <.text+0x8944d>
14008a759: 44 39 56 1c                 	cmpl	%r10d, 0x1c(%rsi)
14008a75d: 0f 85 ea fc ff ff           	jne	0x14008a44d <.text+0x8944d>
14008a763: 66 44 39 4e 20              	cmpw	%r9w, 0x20(%rsi)
14008a768: 0f 85 df fc ff ff           	jne	0x14008a44d <.text+0x8944d>
14008a76e: 44 38 c0                    	cmpb	%r8b, %al
14008a771: 0f 85 d6 fc ff ff           	jne	0x14008a44d <.text+0x8944d>
14008a777: 48 8b 46 08                 	movq	0x8(%rsi), %rax
14008a77b: 48 31 d0                    	xorq	%rdx, %rax
14008a77e: 48 8b 4e 10                 	movq	0x10(%rsi), %rcx
14008a782: 4c 31 e1                    	xorq	%r12, %rcx
14008a785: 48 09 c1                    	orq	%rax, %rcx
14008a788: 0f 85 bf fc ff ff           	jne	0x14008a44d <.text+0x8944d>
14008a78e: 31 c0                       	xorl	%eax, %eax
14008a790: 0f 28 75 f0                 	movaps	-0x10(%rbp), %xmm6
14008a794: 48 83 c4 78                 	addq	$0x78, %rsp
14008a798: 5b                          	popq	%rbx
14008a799: 5f                          	popq	%rdi
14008a79a: 5e                          	popq	%rsi
14008a79b: 41 5c                       	popq	%r12
14008a79d: 41 5d                       	popq	%r13
14008a79f: 41 5e                       	popq	%r14
14008a7a1: 41 5f                       	popq	%r15
14008a7a3: 5d                          	popq	%rbp
14008a7a4: c3                          	retq
14008a7a5: 41 83 fb 01                 	cmpl	$0x1, %r11d
14008a7a9: 75 0d                       	jne	0x14008a7b8 <.text+0x897b8>
14008a7ab: 49 8b 52 d8                 	movq	-0x28(%r10), %rdx
14008a7af: 48 8d 4b 60                 	leaq	0x60(%rbx), %rcx
14008a7b3: e8 28 69 f8 ff              	callq	0x1400110e0 <.text+0x100e0>
14008a7b8: 48 8d 8b c0 00 00 00        	leaq	0xc0(%rbx), %rcx
14008a7bf: 4c 89 e2                    	movq	%r12, %rdx
14008a7c2: e8 49 71 f8 ff              	callq	0x140011910 <.text+0x10910>
14008a7c7: 3c ff                       	cmpb	$-0x1, %al
14008a7c9: 0f 85 31 fe ff ff           	jne	0x14008a600 <.text+0x89600>
14008a7cf: e9 cd fd ff ff              	jmp	0x14008a5a1 <.text+0x895a1>
14008a7d4: 4c 8d 0d ed 5b 1d 00        	leaq	0x1d5bed(%rip), %r9     # 0x1402603c8
14008a7db: 41 b8 00 01 00 00           	movl	$0x100, %r8d            # imm = 0x100
14008a7e1: 31 c9                       	xorl	%ecx, %ecx
14008a7e3: e8 78 70 1c 00              	callq	0x140251860 <.text+0x250860>
14008a7e8: 0f 0b                       	ud2
14008a7ea: 4c 8d 05 47 49 1e 00        	leaq	0x1e4947(%rip), %r8     # 0x14026f138
14008a7f1: 48 89 d1                    	movq	%rdx, %rcx
14008a7f4: 48 89 c2                    	movq	%rax, %rdx
14008a7f7: e8 57 6e 1c 00              	callq	0x140251653 <.text+0x250653>
14008a7fc: 0f 0b                       	ud2


D:/CoapticCurrent/oscore-packet-staging-20261104/option-reuse/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400914e0: 55                          	pushq	%rbp
1400914e1: 41 57                       	pushq	%r15
1400914e3: 41 56                       	pushq	%r14
1400914e5: 56                          	pushq	%rsi
1400914e6: 57                          	pushq	%rdi
1400914e7: 53                          	pushq	%rbx
1400914e8: 48 81 ec 78 01 00 00        	subq	$0x178, %rsp            # imm = 0x178
1400914ef: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
1400914f7: b0 01                       	movb	$0x1, %al
1400914f9: 80 bd 50 01 00 00 00        	cmpb	$0x0, 0x150(%rbp)
140091500: 0f 85 71 01 00 00           	jne	0x140091677 <.text+0x90677>
140091506: 48 8b b5 68 01 00 00        	movq	0x168(%rbp), %rsi
14009150d: 0f b6 9d 60 01 00 00        	movzbl	0x160(%rbp), %ebx
140091514: 48 8b 85 58 01 00 00        	movq	0x158(%rbp), %rax
14009151b: 49 89 c2                    	movq	%rax, %r10
14009151e: 49 81 c2 d8 c4 03 00        	addq	$0x3c4d8, %r10          # imm = 0x3C4D8
140091525: 49 c7 c3 ff ff ff ff        	movq	$-0x1, %r11
14009152c: 4d 0f 43 da                 	cmovaeq	%r10, %r11
140091530: 0f 57 c0                    	xorps	%xmm0, %xmm0
140091533: 0f 11 85 e0 00 00 00        	movups	%xmm0, 0xe0(%rbp)
14009153a: 0f 11 85 d0 00 00 00        	movups	%xmm0, 0xd0(%rbp)
140091541: 0f 11 85 c0 00 00 00        	movups	%xmm0, 0xc0(%rbp)
140091548: 0f 11 85 b0 00 00 00        	movups	%xmm0, 0xb0(%rbp)
14009154f: 0f 11 85 a0 00 00 00        	movups	%xmm0, 0xa0(%rbp)
140091556: 0f 11 85 90 00 00 00        	movups	%xmm0, 0x90(%rbp)
14009155d: 0f 11 85 80 00 00 00        	movups	%xmm0, 0x80(%rbp)
140091564: 0f 11 45 70                 	movups	%xmm0, 0x70(%rbp)
140091568: 0f 11 45 60                 	movups	%xmm0, 0x60(%rbp)
14009156c: 0f 11 45 50                 	movups	%xmm0, 0x50(%rbp)
140091570: 0f 11 45 40                 	movups	%xmm0, 0x40(%rbp)
140091574: 0f 11 45 30                 	movups	%xmm0, 0x30(%rbp)
140091578: 0f 11 45 20                 	movups	%xmm0, 0x20(%rbp)
14009157c: 0f 11 45 10                 	movups	%xmm0, 0x10(%rbp)
140091580: 0f 11 45 00                 	movups	%xmm0, (%rbp)
140091584: 0f 11 45 f0                 	movups	%xmm0, -0x10(%rbp)
140091588: 41 0f 10 00                 	movups	(%r8), %xmm0
14009158c: 41 0f 10 48 0c              	movups	0xc(%r8), %xmm1
140091591: 0f 11 45 c8                 	movups	%xmm0, -0x38(%rbp)
140091595: 0f 11 4d d4                 	movups	%xmm1, -0x2c(%rbp)
140091599: 66 44 89 4d e4              	movw	%r9w, -0x1c(%rbp)
14009159e: 4c 89 5d e8                 	movq	%r11, -0x18(%rbp)
1400915a2: 80 bc 11 80 1e 00 00 01     	cmpb	$0x1, 0x1e80(%rcx,%rdx)
1400915aa: 75 0a                       	jne	0x1400915b6 <.text+0x905b6>
1400915ac: 80 bc 11 82 1e 00 00 00     	cmpb	$0x0, 0x1e82(%rcx,%rdx)
1400915b4: 74 1e                       	je	0x1400915d4 <.text+0x905d4>
1400915b6: 48 89 74 24 28              	movq	%rsi, 0x28(%rsp)
1400915bb: 88 5c 24 20                 	movb	%bl, 0x20(%rsp)
1400915bf: 4c 89 c2                    	movq	%r8, %rdx
1400915c2: 45 89 c8                    	movl	%r9d, %r8d
1400915c5: 49 89 c1                    	movq	%rax, %r9
1400915c8: e8 b3 61 00 00              	callq	0x140097780 <.text+0x96780>
1400915cd: b0 01                       	movb	$0x1, %al
1400915cf: e9 a3 00 00 00              	jmp	0x140091677 <.text+0x90677>
1400915d4: c6 84 11 82 1e 00 00 01     	movb	$0x1, 0x1e82(%rcx,%rdx)
1400915dc: 48 8b bc d1 f8 1d 00 00     	movq	0x1df8(%rcx,%rdx,8), %rdi
1400915e4: 48 81 ff 81 04 00 00        	cmpq	$0x481, %rdi            # imm = 0x481
1400915eb: 0f 83 96 00 00 00           	jae	0x140091687 <.text+0x90687>
1400915f1: 48 81 ff 01 01 00 00        	cmpq	$0x101, %rdi            # imm = 0x101
1400915f8: 72 17                       	jb	0x140091611 <.text+0x90611>
1400915fa: 48 c7 45 b8 01 00 00 00     	movq	$0x1, -0x48(%rbp)
140091602: 48 89 55 c0                 	movq	%rdx, -0x40(%rbp)
140091606: 66 c7 85 f0 00 00 00 00 00  	movw	$0x0, 0xf0(%rbp)
14009160f: eb 3f                       	jmp	0x140091650 <.text+0x90650>
140091611: 48 8d 45 f0                 	leaq	-0x10(%rbp), %rax
140091615: 4c 8d 89 f8 14 00 00        	leaq	0x14f8(%rcx), %r9
14009161c: 4c 8d 04 d2                 	leaq	(%rdx,%rdx,8), %r8
140091620: 49 c1 e0 07                 	shlq	$0x7, %r8
140091624: 4d 01 c8                    	addq	%r9, %r8
140091627: 49 89 ce                    	movq	%rcx, %r14
14009162a: 48 89 c1                    	movq	%rax, %rcx
14009162d: 49 89 d7                    	movq	%rdx, %r15
140091630: 4c 89 c2                    	movq	%r8, %rdx
140091633: 49 89 f8                    	movq	%rdi, %r8
140091636: e8 d5 f7 1b 00              	callq	0x140250e10 <.text+0x24fe10>
14009163b: 4c 89 fa                    	movq	%r15, %rdx
14009163e: 4c 89 f1                    	movq	%r14, %rcx
140091641: 66 89 bd f0 00 00 00        	movw	%di, 0xf0(%rbp)
140091648: 48 c7 45 b8 00 00 00 00     	movq	$0x0, -0x48(%rbp)
140091650: 48 81 ff 01 01 00 00        	cmpq	$0x101, %rdi            # imm = 0x101
140091657: 40 0f 92 c7                 	setb	%dil
14009165b: c6 84 11 82 1e 00 00 00     	movb	$0x0, 0x1e82(%rcx,%rdx)
140091663: 48 8d 55 b8                 	leaq	-0x48(%rbp), %rdx
140091667: 41 89 d8                    	movl	%ebx, %r8d
14009166a: 49 89 f1                    	movq	%rsi, %r9
14009166d: e8 de 79 ff ff              	callq	0x140089050 <.text+0x88050>
140091672: 34 01                       	xorb	$0x1, %al
140091674: 40 08 f8                    	orb	%dil, %al
140091677: 48 81 c4 78 01 00 00        	addq	$0x178, %rsp            # imm = 0x178
14009167e: 5b                          	popq	%rbx
14009167f: 5f                          	popq	%rdi
140091680: 5e                          	popq	%rsi
140091681: 41 5e                       	popq	%r14
140091683: 41 5f                       	popq	%r15
140091685: 5d                          	popq	%rbp
140091686: c3                          	retq
140091687: 4c 8d 0d a2 b3 1d 00        	leaq	0x1db3a2(%rip), %r9     # 0x14026ca30
14009168e: 41 b8 80 04 00 00           	movl	$0x480, %r8d            # imm = 0x480
140091694: 31 c9                       	xorl	%ecx, %ecx
140091696: 48 89 fa                    	movq	%rdi, %rdx
140091699: e8 c2 01 1c 00              	callq	0x140251860 <.text+0x250860>
14009169e: 0f 0b                       	ud2

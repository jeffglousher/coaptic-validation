"""Retain selected emitted retention routines; no profiling or runtime claim."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

exe, pdb, prefix = sys.argv[1:]
root = Path(__file__).resolve().parent
assert not (root / (prefix + '-symbols.json')).exists()
headers = subprocess.check_output(['llvm-objdump', '-h', exe]).decode()
base = int(re.search(r'\s+\d+\s+\.text\s+[0-9a-f]+\s+([0-9a-f]+)', headers)[1], 16)
symbols = subprocess.check_output(['llvm-pdbutil', 'dump', '-symbols', pdb]).decode()
records = []
for match in re.finditer(r'^.*S_[LG]PROC32[^\n]*\n(?:.*\n){0,5}', symbols, re.M):
    record = match[0]
    if 'DedupEntry::write_tx`' not in record:
        if not any(name + '<' in record for name in ['remember_tx_reply', 'note_dedup_store']):
            continue
        if not (('Constrained' in record and 'NoBodies' in record) or 'AllocMemory' in record):
            continue
    address, size = map(int, re.search(r'addr = 0001:(\d+), code size = (\d+)', record).groups())
    name = re.search(r'`([^`]+)`', record)[1]
    frame = int(re.search(r'size = (\d+), padding size', record)[1])
    start = base + address
    output = subprocess.check_output(['llvm-objdump', '-d', '--start-address=' + hex(start),
                                     '--stop-address=' + hex(start + size), exe])
    filename = prefix + '-' + str(len(records)) + '.asm'
    (root / filename).write_bytes(output)
    records.append(dict(name=name, address=hex(start), code_bytes=size,
                        frame_record_bytes=frame, disassembly=filename))
thunks = [m[0] for m in re.finditer(r'^.*S_THUNK32[^\n]*\n(?:.*\n){0,3}', symbols, re.M)
          if any(name in m[0] for name in ['memcpy', 'memmove'])]
assert len(records) in (4, 5)
result = dict(exe_sha256=hashlib.sha256(Path(exe).read_bytes()).hexdigest(),
              pdb_sha256=hashlib.sha256(Path(pdb).read_bytes()).hexdigest(),
              text_vma=hex(base), records=records, thunks=thunks,
              scope='Emitted code and selected frame records, not complete stack or CPU shares')
(root / (prefix + '-symbols.json')).write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))

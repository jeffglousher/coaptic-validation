
D:/CoapticCurrent/replay-active-copy-20261105/direct-fill/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140091690: 55                          	pushq	%rbp
140091691: 41 57                       	pushq	%r15
140091693: 41 56                       	pushq	%r14
140091695: 41 55                       	pushq	%r13
140091697: 41 54                       	pushq	%r12
140091699: 56                          	pushq	%rsi
14009169a: 57                          	pushq	%rdi
14009169b: 53                          	pushq	%rbx
14009169c: 48 81 ec 68 01 00 00        	subq	$0x168, %rsp            # imm = 0x168
1400916a3: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
1400916ab: b0 01                       	movb	$0x1, %al
1400916ad: 80 bd 50 01 00 00 00        	cmpb	$0x0, 0x150(%rbp)
1400916b4: 0f 85 47 01 00 00           	jne	0x140091801 <.text+0x90801>
1400916ba: 44 89 ce                    	movl	%r9d, %esi
1400916bd: 4d 89 c2                    	movq	%r8, %r10
1400916c0: 4c 8b 8d 68 01 00 00        	movq	0x168(%rbp), %r9
1400916c7: 44 0f b6 85 60 01 00 00     	movzbl	0x160(%rbp), %r8d
1400916cf: 4c 8b 9d 58 01 00 00        	movq	0x158(%rbp), %r11
1400916d6: 4c 89 d8                    	movq	%r11, %rax
1400916d9: 48 05 d8 c4 03 00           	addq	$0x3c4d8, %rax          # imm = 0x3C4D8
1400916df: 48 c7 c7 ff ff ff ff        	movq	$-0x1, %rdi
1400916e6: 48 0f 43 f8                 	cmovaeq	%rax, %rdi
1400916ea: 41 0f 10 02                 	movups	(%r10), %xmm0
1400916ee: 41 0f 10 4a 0c              	movups	0xc(%r10), %xmm1
1400916f3: 0f 11 8d cc 00 00 00        	movups	%xmm1, 0xcc(%rbp)
1400916fa: 0f 11 85 c0 00 00 00        	movups	%xmm0, 0xc0(%rbp)
140091701: 66 89 b5 dc 00 00 00        	movw	%si, 0xdc(%rbp)
140091708: 48 89 bd e0 00 00 00        	movq	%rdi, 0xe0(%rbp)
14009170f: 80 bc 11 40 1e 00 00 01     	cmpb	$0x1, 0x1e40(%rcx,%rdx)
140091717: 75 0a                       	jne	0x140091723 <.text+0x90723>
140091719: 80 bc 11 42 1e 00 00 00     	cmpb	$0x0, 0x1e42(%rcx,%rdx)
140091721: 74 1f                       	je	0x140091742 <.text+0x90742>
140091723: 4c 89 4c 24 28              	movq	%r9, 0x28(%rsp)
140091728: 44 88 44 24 20              	movb	%r8b, 0x20(%rsp)
14009172d: 4c 89 d2                    	movq	%r10, %rdx
140091730: 41 89 f0                    	movl	%esi, %r8d
140091733: 4d 89 d9                    	movq	%r11, %r9
140091736: e8 55 61 00 00              	callq	0x140097890 <.text+0x96890>
14009173b: b0 01                       	movb	$0x1, %al
14009173d: e9 bf 00 00 00              	jmp	0x140091801 <.text+0x90801>
140091742: c6 84 11 42 1e 00 00 01     	movb	$0x1, 0x1e42(%rcx,%rdx)
14009174a: 48 8b b4 d1 b8 1d 00 00     	movq	0x1db8(%rcx,%rdx,8), %rsi
140091752: 48 81 fe 81 04 00 00        	cmpq	$0x481, %rsi            # imm = 0x481
140091759: 0f 83 b6 00 00 00           	jae	0x140091815 <.text+0x90815>
14009175f: 48 81 fe 01 01 00 00        	cmpq	$0x101, %rsi            # imm = 0x101
140091766: 72 0c                       	jb	0x140091774 <.text+0x90774>
140091768: 66 c7 45 b8 02 00           	movw	$0x2, -0x48(%rbp)
14009176e: 48 89 55 c0                 	movq	%rdx, -0x40(%rbp)
140091772: eb 6e                       	jmp	0x1400917e2 <.text+0x907e2>
140091774: 48 85 f6                    	testq	%rsi, %rsi
140091777: 74 63                       	je	0x1400917dc <.text+0x907dc>
140091779: 48 8d 81 b8 14 00 00        	leaq	0x14b8(%rcx), %rax
140091780: 48 8d 3c d2                 	leaq	(%rdx,%rdx,8), %rdi
140091784: 48 c1 e7 07                 	shlq	$0x7, %rdi
140091788: 48 01 c7                    	addq	%rax, %rdi
14009178b: 66 89 75 ba                 	movw	%si, -0x46(%rbp)
14009178f: 48 8d 5d bc                 	leaq	-0x44(%rbp), %rbx
140091793: b8 00 01 00 00              	movl	$0x100, %eax            # imm = 0x100
140091798: 48 29 f0                    	subq	%rsi, %rax
14009179b: 4c 8d 14 2e                 	leaq	(%rsi,%rbp), %r10
14009179f: 49 83 c2 bc                 	addq	$-0x44, %r10
1400917a3: 49 89 ce                    	movq	%rcx, %r14
1400917a6: 4c 89 d1                    	movq	%r10, %rcx
1400917a9: 49 89 d7                    	movq	%rdx, %r15
1400917ac: 31 d2                       	xorl	%edx, %edx
1400917ae: 45 89 c4                    	movl	%r8d, %r12d
1400917b1: 49 89 c0                    	movq	%rax, %r8
1400917b4: 4d 89 cd                    	movq	%r9, %r13
1400917b7: e8 b6 ea 1b 00              	callq	0x140250272 <.text+0x24f272>
1400917bc: 48 89 d9                    	movq	%rbx, %rcx
1400917bf: 48 89 fa                    	movq	%rdi, %rdx
1400917c2: 49 89 f0                    	movq	%rsi, %r8
1400917c5: e8 96 ea 1b 00              	callq	0x140250260 <.text+0x24f260>
1400917ca: 4c 89 fa                    	movq	%r15, %rdx
1400917cd: 45 89 e0                    	movl	%r12d, %r8d
1400917d0: 4d 89 e9                    	movq	%r13, %r9
1400917d3: 4c 89 f1                    	movq	%r14, %rcx
1400917d6: 66 b8 01 00                 	movw	$0x1, %ax
1400917da: eb 02                       	jmp	0x1400917de <.text+0x907de>
1400917dc: 31 c0                       	xorl	%eax, %eax
1400917de: 66 89 45 b8                 	movw	%ax, -0x48(%rbp)
1400917e2: 48 81 fe 01 01 00 00        	cmpq	$0x101, %rsi            # imm = 0x101
1400917e9: 0f 92 c3                    	setb	%bl
1400917ec: c6 84 11 42 1e 00 00 00     	movb	$0x0, 0x1e42(%rcx,%rdx)
1400917f4: 48 8d 55 b8                 	leaq	-0x48(%rbp), %rdx
1400917f8: e8 33 78 ff ff              	callq	0x140089030 <.text+0x88030>
1400917fd: 34 01                       	xorb	$0x1, %al
1400917ff: 08 d8                       	orb	%bl, %al
140091801: 48 81 c4 68 01 00 00        	addq	$0x168, %rsp            # imm = 0x168
140091808: 5b                          	popq	%rbx
140091809: 5f                          	popq	%rdi
14009180a: 5e                          	popq	%rsi
14009180b: 41 5c                       	popq	%r12
14009180d: 41 5d                       	popq	%r13
14009180f: 41 5e                       	popq	%r14
140091811: 41 5f                       	popq	%r15
140091813: 5d                          	popq	%rbp
140091814: c3                          	retq
140091815: 4c 8d 0d bc a1 1d 00        	leaq	0x1da1bc(%rip), %r9     # 0x14026b9d8
14009181c: 41 b8 80 04 00 00           	movl	$0x480, %r8d            # imm = 0x480
140091822: 31 c9                       	xorl	%ecx, %ecx
140091824: 48 89 f2                    	movq	%rsi, %rdx
140091827: e8 84 f4 1b 00              	callq	0x140250cb0 <.text+0x24fcb0>
14009182c: 0f 0b                       	ud2


D:/CoapticCurrent/replay-storage-20261105/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14008a580: 55                          	pushq	%rbp
14008a581: 41 57                       	pushq	%r15
14008a583: 41 56                       	pushq	%r14
14008a585: 41 55                       	pushq	%r13
14008a587: 41 54                       	pushq	%r12
14008a589: 56                          	pushq	%rsi
14008a58a: 57                          	pushq	%rdi
14008a58b: 53                          	pushq	%rbx
14008a58c: 48 83 ec 78                 	subq	$0x78, %rsp
14008a590: 48 8d 6c 24 70              	leaq	0x70(%rsp), %rbp
14008a595: 0f 29 75 f0                 	movaps	%xmm6, -0x10(%rbp)
14008a599: 4c 89 ce                    	movq	%r9, %rsi
14008a59c: 45 89 c6                    	movl	%r8d, %r14d
14008a59f: 48 8b 82 08 01 00 00        	movq	0x108(%rdx), %rax
14008a5a6: 48 89 45 d0                 	movq	%rax, -0x30(%rbp)
14008a5aa: 48 8b 82 10 01 00 00        	movq	0x110(%rdx), %rax
14008a5b1: 48 89 45 c8                 	movq	%rax, -0x38(%rbp)
14008a5b5: 8b 82 18 01 00 00           	movl	0x118(%rdx), %eax
14008a5bb: 89 45 e0                    	movl	%eax, -0x20(%rbp)
14008a5be: 8b 82 1c 01 00 00           	movl	0x11c(%rdx), %eax
14008a5c4: 89 45 e4                    	movl	%eax, -0x1c(%rbp)
14008a5c7: 0f b7 82 20 01 00 00        	movzwl	0x120(%rdx), %eax
14008a5ce: 66 89 45 ec                 	movw	%ax, -0x14(%rbp)
14008a5d2: 0f b6 82 22 01 00 00        	movzbl	0x122(%rdx), %eax
14008a5d9: 88 45 ef                    	movb	%al, -0x11(%rbp)
14008a5dc: 44 0f b6 a2 23 01 00 00     	movzbl	0x123(%rdx), %r12d
14008a5e4: f3 0f 10 b2 24 01 00 00     	movss	0x124(%rdx), %xmm6
14008a5ec: 0f b7 82 24 01 00 00        	movzwl	0x124(%rdx), %eax
14008a5f3: 66 89 45 ea                 	movw	%ax, -0x16(%rbp)
14008a5f7: 4c 8b aa 28 01 00 00        	movq	0x128(%rdx), %r13
14008a5fe: 0f b7 02                    	movzwl	(%rdx), %eax
14008a601: 85 c0                       	testl	%eax, %eax
14008a603: 0f 84 e5 02 00 00           	je	0x14008a8ee <.text+0x898ee>
14008a609: 48 89 d7                    	movq	%rdx, %rdi
14008a60c: 48 89 cb                    	movq	%rcx, %rbx
14008a60f: 83 f8 01                    	cmpl	$0x1, %eax
14008a612: 75 11                       	jne	0x14008a625 <.text+0x89625>
14008a614: 0f b7 57 02                 	movzwl	0x2(%rdi), %edx
14008a618: 48 81 fa 01 01 00 00        	cmpq	$0x101, %rdx            # imm = 0x101
14008a61f: 0f 83 a7 03 00 00           	jae	0x14008a9cc <.text+0x899cc>
14008a625: 44 88 65 e9                 	movb	%r12b, -0x17(%rbp)
14008a629: 48 8b 83 e8 00 00 00        	movq	0xe8(%rbx), %rax
14008a630: 48 85 c0                    	testq	%rax, %rax
14008a633: 0f 84 15 01 00 00           	je	0x14008a74e <.text+0x8974e>
14008a639: 48 8b 8b d0 00 00 00        	movq	0xd0(%rbx), %rcx
14008a640: ba 28 01 00 00              	movl	$0x128, %edx            # imm = 0x128
14008a645: 48 03 93 c8 00 00 00        	addq	0xc8(%rbx), %rdx
14008a64c: 4c 8b 83 e0 00 00 00        	movq	0xe0(%rbx), %r8
14008a653: 49 c7 c7 ff ff ff ff        	movq	$-0x1, %r15
14008a65a: 45 31 e4                    	xorl	%r12d, %r12d
14008a65d: 48 c7 45 d8 00 00 00 00     	movq	$0x0, -0x28(%rbp)
14008a665: 4d 69 d4 30 01 00 00        	imulq	$0x130, %r12, %r10      # imm = 0x130
14008a66c: 49 01 d2                    	addq	%rdx, %r10
14008a66f: eb 22                       	jmp	0x14008a693 <.text+0x89693>
14008a671: 66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00	nopw	%cs:(%rax,%rax)
14008a680: 49 ff c4                    	incq	%r12
14008a683: 49 81 c2 30 01 00 00        	addq	$0x130, %r10            # imm = 0x130
14008a68a: 49 39 c4                    	cmpq	%rax, %r12
14008a68d: 0f 83 c3 00 00 00           	jae	0x14008a756 <.text+0x89756>
14008a693: 49 39 c4                    	cmpq	%rax, %r12
14008a696: 73 e8                       	jae	0x14008a680 <.text+0x89680>
14008a698: 43 80 3c 20 01              	cmpb	$0x1, (%r8,%r12)
14008a69d: 75 e1                       	jne	0x14008a680 <.text+0x89680>
14008a69f: 49 39 cc                    	cmpq	%rcx, %r12
14008a6a2: 73 dc                       	jae	0x14008a680 <.text+0x89680>
14008a6a4: 45 0f b7 9a d8 fe ff ff     	movzwl	-0x128(%r10), %r11d
14008a6ac: 66 41 83 fb ff              	cmpw	$-0x1, %r11w
14008a6b1: 74 cd                       	je	0x14008a680 <.text+0x89680>
14008a6b3: 44 0f b7 4d ea              	movzwl	-0x16(%rbp), %r9d
14008a6b8: 66 45 39 4a fc              	cmpw	%r9w, -0x4(%r10)
14008a6bd: 75 4c                       	jne	0x14008a70b <.text+0x8970b>
14008a6bf: 44 8b 4d e0                 	movl	-0x20(%rbp), %r9d
14008a6c3: 45 39 4a f0                 	cmpl	%r9d, -0x10(%r10)
14008a6c7: 75 42                       	jne	0x14008a70b <.text+0x8970b>
14008a6c9: 44 8b 4d e4                 	movl	-0x1c(%rbp), %r9d
14008a6cd: 45 39 4a f4                 	cmpl	%r9d, -0xc(%r10)
14008a6d1: 75 38                       	jne	0x14008a70b <.text+0x8970b>
14008a6d3: 44 0f b7 4d ec              	movzwl	-0x14(%rbp), %r9d
14008a6d8: 66 45 39 4a f8              	cmpw	%r9w, -0x8(%r10)
14008a6dd: 75 2c                       	jne	0x14008a70b <.text+0x8970b>
14008a6df: 44 0f b6 4d ef              	movzbl	-0x11(%rbp), %r9d
14008a6e4: 45 38 4a fa                 	cmpb	%r9b, -0x6(%r10)
14008a6e8: 75 21                       	jne	0x14008a70b <.text+0x8970b>
14008a6ea: 4c 89 7d b8                 	movq	%r15, -0x48(%rbp)
14008a6ee: 4d 8b 7a e0                 	movq	-0x20(%r10), %r15
14008a6f2: 4c 33 7d d0                 	xorq	-0x30(%rbp), %r15
14008a6f6: 4d 8b 4a e8                 	movq	-0x18(%r10), %r9
14008a6fa: 4c 33 4d c8                 	xorq	-0x38(%rbp), %r9
14008a6fe: 4d 09 f9                    	orq	%r15, %r9
14008a701: 4c 8b 7d b8                 	movq	-0x48(%rbp), %r15
14008a705: 0f 84 8e 02 00 00           	je	0x14008a999 <.text+0x89999>
14008a70b: 4d 8b 12                    	movq	(%r10), %r10
14008a70e: 4d 85 d2                    	testq	%r10, %r10
14008a711: 74 2d                       	je	0x14008a740 <.text+0x89740>
14008a713: 48 83 7d d8 00              	cmpq	$0x0, -0x28(%rbp)
14008a718: 41 0f 94 c1                 	sete	%r9b
14008a71c: 4d 39 fa                    	cmpq	%r15, %r10
14008a71f: 41 0f 92 c3                 	setb	%r11b
14008a723: 45 08 cb                    	orb	%r9b, %r11b
14008a726: 4c 8b 4d c0                 	movq	-0x40(%rbp), %r9
14008a72a: 4d 0f 45 cc                 	cmovneq	%r12, %r9
14008a72e: 4c 89 4d c0                 	movq	%r9, -0x40(%rbp)
14008a732: 4d 0f 45 fa                 	cmovneq	%r10, %r15
14008a736: 41 b9 01 00 00 00           	movl	$0x1, %r9d
14008a73c: 4c 89 4d d8                 	movq	%r9, -0x28(%rbp)
14008a740: 49 ff c4                    	incq	%r12
14008a743: 49 39 c4                    	cmpq	%rax, %r12
14008a746: 0f 82 19 ff ff ff           	jb	0x14008a665 <.text+0x89665>
14008a74c: eb 08                       	jmp	0x14008a756 <.text+0x89756>
14008a74e: 48 c7 45 d8 00 00 00 00     	movq	$0x0, -0x28(%rbp)
14008a756: 4c 8d bb d8 00 00 00        	leaq	0xd8(%rbx), %r15
14008a75d: 4c 89 f9                    	movq	%r15, %rcx
14008a760: e8 fb 09 f8 ff              	callq	0x14000b160 <.text+0xa160>
14008a765: a8 01                       	testb	$0x1, %al
14008a767: 0f 84 b5 00 00 00           	je	0x14008a822 <.text+0x89822>
14008a76d: 4d 85 ed                    	testq	%r13, %r13
14008a770: 74 16                       	je	0x14008a788 <.text+0x89788>
14008a772: 48 8b 83 18 01 00 00        	movq	0x118(%rbx), %rax
14008a779: 48 ff c8                    	decq	%rax
14008a77c: 4c 39 e8                    	cmpq	%r13, %rax
14008a77f: 72 07                       	jb	0x14008a788 <.text+0x89788>
14008a781: 4c 89 ab 18 01 00 00        	movq	%r13, 0x118(%rbx)
14008a788: 48 8b 83 d0 00 00 00        	movq	0xd0(%rbx), %rax
14008a78f: 48 39 c2                    	cmpq	%rax, %rdx
14008a792: 0f 83 4a 02 00 00           	jae	0x14008a9e2 <.text+0x899e2>
14008a798: 48 69 ca 30 01 00 00        	imulq	$0x130, %rdx, %rcx      # imm = 0x130
14008a79f: 48 03 8b c8 00 00 00        	addq	0xc8(%rbx), %rcx
14008a7a6: 41 b8 30 01 00 00           	movl	$0x130, %r8d            # imm = 0x130
14008a7ac: 48 89 fa                    	movq	%rdi, %rdx
14008a7af: e8 2c 60 1c 00              	callq	0x1402507e0 <.text+0x24f7e0>
14008a7b4: 0f b6 4e 22                 	movzbl	0x22(%rsi), %ecx
14008a7b8: b0 01                       	movb	$0x1, %al
14008a7ba: 80 f9 02                    	cmpb	$0x2, %cl
14008a7bd: 0f 84 c1 01 00 00           	je	0x14008a984 <.text+0x89984>
14008a7c3: 0f b7 55 ea                 	movzwl	-0x16(%rbp), %edx
14008a7c7: 66 39 56 24                 	cmpw	%dx, 0x24(%rsi)
14008a7cb: 0f 85 b3 01 00 00           	jne	0x14008a984 <.text+0x89984>
14008a7d1: 8b 55 e0                    	movl	-0x20(%rbp), %edx
14008a7d4: 39 56 18                    	cmpl	%edx, 0x18(%rsi)
14008a7d7: 0f 85 a7 01 00 00           	jne	0x14008a984 <.text+0x89984>
14008a7dd: 8b 55 e4                    	movl	-0x1c(%rbp), %edx
14008a7e0: 39 56 1c                    	cmpl	%edx, 0x1c(%rsi)
14008a7e3: 0f 85 9b 01 00 00           	jne	0x14008a984 <.text+0x89984>
14008a7e9: 0f b7 55 ec                 	movzwl	-0x14(%rbp), %edx
14008a7ed: 66 39 56 20                 	cmpw	%dx, 0x20(%rsi)
14008a7f1: 0f 85 8d 01 00 00           	jne	0x14008a984 <.text+0x89984>
14008a7f7: 3a 4d ef                    	cmpb	-0x11(%rbp), %cl
14008a7fa: 0f 85 84 01 00 00           	jne	0x14008a984 <.text+0x89984>
14008a800: 48 8b 55 d0                 	movq	-0x30(%rbp), %rdx
14008a804: 48 33 56 08                 	xorq	0x8(%rsi), %rdx
14008a808: 48 8b 4d c8                 	movq	-0x38(%rbp), %rcx
14008a80c: 48 33 4e 10                 	xorq	0x10(%rsi), %rcx
14008a810: 48 09 d1                    	orq	%rdx, %rcx
14008a813: 0f 85 6b 01 00 00           	jne	0x14008a984 <.text+0x89984>
14008a819: c6 46 22 02                 	movb	$0x2, 0x22(%rsi)
14008a81d: e9 62 01 00 00              	jmp	0x14008a984 <.text+0x89984>
14008a822: 48 83 7d d8 01              	cmpq	$0x1, -0x28(%rbp)
14008a827: 44 0f b6 65 e9              	movzbl	-0x17(%rbp), %r12d
14008a82c: 0f 85 bc 00 00 00           	jne	0x14008a8ee <.text+0x898ee>
14008a832: 48 8b 83 e8 00 00 00        	movq	0xe8(%rbx), %rax
14008a839: 4c 8b 45 c0                 	movq	-0x40(%rbp), %r8
14008a83d: 49 39 c0                    	cmpq	%rax, %r8
14008a840: 73 47                       	jae	0x14008a889 <.text+0x89889>
14008a842: 48 8b 8b e0 00 00 00        	movq	0xe0(%rbx), %rcx
14008a849: 42 80 3c 01 01              	cmpb	$0x1, (%rcx,%r8)
14008a84e: 75 39                       	jne	0x14008a889 <.text+0x89889>
14008a850: 4c 3b 83 d0 00 00 00        	cmpq	0xd0(%rbx), %r8
14008a857: 73 30                       	jae	0x14008a889 <.text+0x89889>
14008a859: 48 8b 8b c8 00 00 00        	movq	0xc8(%rbx), %rcx
14008a860: 49 69 d0 30 01 00 00        	imulq	$0x130, %r8, %rdx       # imm = 0x130
14008a867: 66 83 3c 11 02              	cmpw	$0x2, (%rcx,%rdx)
14008a86c: 75 1b                       	jne	0x14008a889 <.text+0x89889>
14008a86e: 48 01 d1                    	addq	%rdx, %rcx
14008a871: 48 8b 51 08                 	movq	0x8(%rcx), %rdx
14008a875: 48 8d 4b 60                 	leaq	0x60(%rbx), %rcx
14008a879: e8 62 68 f8 ff              	callq	0x1400110e0 <.text+0x100e0>
14008a87e: 4c 8b 45 c0                 	movq	-0x40(%rbp), %r8
14008a882: 48 8b 83 e8 00 00 00        	movq	0xe8(%rbx), %rax
14008a889: 49 39 c0                    	cmpq	%rax, %r8
14008a88c: 73 4e                       	jae	0x14008a8dc <.text+0x898dc>
14008a88e: 48 8b 83 e0 00 00 00        	movq	0xe0(%rbx), %rax
14008a895: 42 80 3c 00 01              	cmpb	$0x1, (%rax,%r8)
14008a89a: 75 40                       	jne	0x14008a8dc <.text+0x898dc>
14008a89c: 4c 3b 83 00 01 00 00        	cmpq	0x100(%rbx), %r8
14008a8a3: 73 0e                       	jae	0x14008a8b3 <.text+0x898b3>
14008a8a5: 48 8b 8b f8 00 00 00        	movq	0xf8(%rbx), %rcx
14008a8ac: 42 80 3c 01 00              	cmpb	$0x0, (%rcx,%r8)
14008a8b1: 75 29                       	jne	0x14008a8dc <.text+0x898dc>
14008a8b3: 42 c6 04 00 00              	movb	$0x0, (%rax,%r8)
14008a8b8: 48 ff 8b 10 01 00 00        	decq	0x110(%rbx)
14008a8bf: 4c 3b 83 d0 00 00 00        	cmpq	0xd0(%rbx), %r8
14008a8c6: 73 14                       	jae	0x14008a8dc <.text+0x898dc>
14008a8c8: 48 8b 83 c8 00 00 00        	movq	0xc8(%rbx), %rax
14008a8cf: 49 69 c8 30 01 00 00        	imulq	$0x130, %r8, %rcx       # imm = 0x130
14008a8d6: 66 c7 04 08 ff ff           	movw	$0xffff, (%rax,%rcx)    # imm = 0xFFFF
14008a8dc: 4c 89 f9                    	movq	%r15, %rcx
14008a8df: e8 7c 08 f8 ff              	callq	0x14000b160 <.text+0xa160>
14008a8e4: 48 83 f8 01                 	cmpq	$0x1, %rax
14008a8e8: 0f 84 7f fe ff ff           	je	0x14008a76d <.text+0x8976d>
14008a8ee: 41 fe ce                    	decb	%r14b
14008a8f1: 41 80 fe 07                 	cmpb	$0x7, %r14b
14008a8f5: 0f 92 c0                    	setb	%al
14008a8f8: b2 4d                       	movb	$0x4d, %dl
14008a8fa: 44 89 f1                    	movl	%r14d, %ecx
14008a8fd: d2 ea                       	shrb	%cl, %dl
14008a8ff: 84 d0                       	testb	%dl, %al
14008a901: 75 7f                       	jne	0x14008a982 <.text+0x89982>
14008a903: 0f b6 46 22                 	movzbl	0x22(%rsi), %eax
14008a907: 3c 02                       	cmpb	$0x2, %al
14008a909: 75 39                       	jne	0x14008a944 <.text+0x89944>
14008a90b: 4c 89 2e                    	movq	%r13, (%rsi)
14008a90e: 48 8b 45 d0                 	movq	-0x30(%rbp), %rax
14008a912: 48 89 46 08                 	movq	%rax, 0x8(%rsi)
14008a916: 48 8b 45 c8                 	movq	-0x38(%rbp), %rax
14008a91a: 48 89 46 10                 	movq	%rax, 0x10(%rsi)
14008a91e: 8b 45 e0                    	movl	-0x20(%rbp), %eax
14008a921: 89 46 18                    	movl	%eax, 0x18(%rsi)
14008a924: 8b 45 e4                    	movl	-0x1c(%rbp), %eax
14008a927: 89 46 1c                    	movl	%eax, 0x1c(%rsi)
14008a92a: 0f b7 45 ec                 	movzwl	-0x14(%rbp), %eax
14008a92e: 66 89 46 20                 	movw	%ax, 0x20(%rsi)
14008a932: 0f b6 45 ef                 	movzbl	-0x11(%rbp), %eax
14008a936: 88 46 22                    	movb	%al, 0x22(%rsi)
14008a939: 44 88 66 23                 	movb	%r12b, 0x23(%rsi)
14008a93d: f3 0f 11 76 24              	movss	%xmm6, 0x24(%rsi)
14008a942: eb 3e                       	jmp	0x14008a982 <.text+0x89982>
14008a944: 0f b7 4d ea                 	movzwl	-0x16(%rbp), %ecx
14008a948: 66 39 4e 24                 	cmpw	%cx, 0x24(%rsi)
14008a94c: 75 bd                       	jne	0x14008a90b <.text+0x8990b>
14008a94e: 8b 4d e0                    	movl	-0x20(%rbp), %ecx
14008a951: 39 4e 18                    	cmpl	%ecx, 0x18(%rsi)
14008a954: 75 b5                       	jne	0x14008a90b <.text+0x8990b>
14008a956: 8b 4d e4                    	movl	-0x1c(%rbp), %ecx
14008a959: 39 4e 1c                    	cmpl	%ecx, 0x1c(%rsi)
14008a95c: 75 ad                       	jne	0x14008a90b <.text+0x8990b>
14008a95e: 0f b7 4d ec                 	movzwl	-0x14(%rbp), %ecx
14008a962: 66 39 4e 20                 	cmpw	%cx, 0x20(%rsi)
14008a966: 75 a3                       	jne	0x14008a90b <.text+0x8990b>
14008a968: 3a 45 ef                    	cmpb	-0x11(%rbp), %al
14008a96b: 75 9e                       	jne	0x14008a90b <.text+0x8990b>
14008a96d: 48 8b 46 08                 	movq	0x8(%rsi), %rax
14008a971: 48 33 45 d0                 	xorq	-0x30(%rbp), %rax
14008a975: 48 8b 4e 10                 	movq	0x10(%rsi), %rcx
14008a979: 48 33 4d c8                 	xorq	-0x38(%rbp), %rcx
14008a97d: 48 09 c1                    	orq	%rax, %rcx
14008a980: 75 89                       	jne	0x14008a90b <.text+0x8990b>
14008a982: 31 c0                       	xorl	%eax, %eax
14008a984: 0f 28 75 f0                 	movaps	-0x10(%rbp), %xmm6
14008a988: 48 83 c4 78                 	addq	$0x78, %rsp
14008a98c: 5b                          	popq	%rbx
14008a98d: 5f                          	popq	%rdi
14008a98e: 5e                          	popq	%rsi
14008a98f: 41 5c                       	popq	%r12
14008a991: 41 5d                       	popq	%r13
14008a993: 41 5e                       	popq	%r14
14008a995: 41 5f                       	popq	%r15
14008a997: 5d                          	popq	%rbp
14008a998: c3                          	retq
14008a999: 66 41 83 fb 02              	cmpw	$0x2, %r11w
14008a99e: 75 10                       	jne	0x14008a9b0 <.text+0x899b0>
14008a9a0: 49 8b 92 e0 fe ff ff        	movq	-0x120(%r10), %rdx
14008a9a7: 48 8d 4b 60                 	leaq	0x60(%rbx), %rcx
14008a9ab: e8 30 67 f8 ff              	callq	0x1400110e0 <.text+0x100e0>
14008a9b0: 48 8d 8b c0 00 00 00        	leaq	0xc0(%rbx), %rcx
14008a9b7: 4c 89 e2                    	movq	%r12, %rdx
14008a9ba: e8 71 6f f8 ff              	callq	0x140011930 <.text+0x10930>
14008a9bf: 3c ff                       	cmpb	$-0x1, %al
14008a9c1: 0f 85 ed fd ff ff           	jne	0x14008a7b4 <.text+0x897b4>
14008a9c7: e9 8a fd ff ff              	jmp	0x14008a756 <.text+0x89756>
14008a9cc: 4c 8d 0d 95 49 1d 00        	leaq	0x1d4995(%rip), %r9     # 0x14025f368
14008a9d3: 41 b8 00 01 00 00           	movl	$0x100, %r8d            # imm = 0x100
14008a9d9: 31 c9                       	xorl	%ecx, %ecx
14008a9db: e8 50 68 1c 00              	callq	0x140251230 <.text+0x250230>
14008a9e0: 0f 0b                       	ud2
14008a9e2: 4c 8d 05 47 36 1e 00        	leaq	0x1e3647(%rip), %r8     # 0x14026e030
14008a9e9: 48 89 d1                    	movq	%rdx, %rcx
14008a9ec: 48 89 c2                    	movq	%rax, %rdx
14008a9ef: e8 2f 66 1c 00              	callq	0x140251023 <.text+0x250023>
14008a9f4: 0f 0b                       	ud2

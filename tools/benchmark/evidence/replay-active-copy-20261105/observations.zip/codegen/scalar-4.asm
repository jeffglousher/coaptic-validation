
D:/CoapticCurrent/replay-active-copy-20261105/scalar-pin/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140091cb0: 55                          	pushq	%rbp
140091cb1: 41 57                       	pushq	%r15
140091cb3: 41 56                       	pushq	%r14
140091cb5: 41 55                       	pushq	%r13
140091cb7: 41 54                       	pushq	%r12
140091cb9: 56                          	pushq	%rsi
140091cba: 57                          	pushq	%rdi
140091cbb: 53                          	pushq	%rbx
140091cbc: 48 81 ec 68 01 00 00        	subq	$0x168, %rsp            # imm = 0x168
140091cc3: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
140091ccb: b0 01                       	movb	$0x1, %al
140091ccd: 80 bd 50 01 00 00 00        	cmpb	$0x0, 0x150(%rbp)
140091cd4: 0f 85 da 00 00 00           	jne	0x140091db4 <.text+0x90db4>
140091cda: 44 89 ce                    	movl	%r9d, %esi
140091cdd: 4d 89 c2                    	movq	%r8, %r10
140091ce0: 4c 8b 8d 68 01 00 00        	movq	0x168(%rbp), %r9
140091ce7: 44 0f b6 85 60 01 00 00     	movzbl	0x160(%rbp), %r8d
140091cef: 4c 8b 9d 58 01 00 00        	movq	0x158(%rbp), %r11
140091cf6: 4c 89 d8                    	movq	%r11, %rax
140091cf9: 48 05 d8 c4 03 00           	addq	$0x3c4d8, %rax          # imm = 0x3C4D8
140091cff: 48 c7 c7 ff ff ff ff        	movq	$-0x1, %rdi
140091d06: 48 0f 43 f8                 	cmovaeq	%rax, %rdi
140091d0a: 41 0f 10 02                 	movups	(%r10), %xmm0
140091d0e: 41 0f 10 4a 0c              	movups	0xc(%r10), %xmm1
140091d13: 0f 11 8d cc 00 00 00        	movups	%xmm1, 0xcc(%rbp)
140091d1a: 0f 11 85 c0 00 00 00        	movups	%xmm0, 0xc0(%rbp)
140091d21: 66 89 b5 dc 00 00 00        	movw	%si, 0xdc(%rbp)
140091d28: 48 89 bd e0 00 00 00        	movq	%rdi, 0xe0(%rbp)
140091d2f: 48 3b 91 88 00 00 00        	cmpq	0x88(%rcx), %rdx
140091d36: 73 62                       	jae	0x140091d9a <.text+0x90d9a>
140091d38: 48 8b 81 80 00 00 00        	movq	0x80(%rcx), %rax
140091d3f: 80 3c 10 01                 	cmpb	$0x1, (%rax,%rdx)
140091d43: 75 55                       	jne	0x140091d9a <.text+0x90d9a>
140091d45: 48 3b 91 a0 00 00 00        	cmpq	0xa0(%rcx), %rdx
140091d4c: 73 4c                       	jae	0x140091d9a <.text+0x90d9a>
140091d4e: 4c 8b b1 98 00 00 00        	movq	0x98(%rcx), %r14
140091d55: 41 80 3c 16 00              	cmpb	$0x0, (%r14,%rdx)
140091d5a: 75 3e                       	jne	0x140091d9a <.text+0x90d9a>
140091d5c: 41 c6 04 16 01              	movb	$0x1, (%r14,%rdx)
140091d61: 48 3b 51 70                 	cmpq	0x70(%rcx), %rdx
140091d65: 73 33                       	jae	0x140091d9a <.text+0x90d9a>
140091d67: 4c 8b 51 68                 	movq	0x68(%rcx), %r10
140091d6b: 4c 6b da 58                 	imulq	$0x58, %rdx, %r11
140091d6f: 4b 8b 44 1a 10              	movq	0x10(%r10,%r11), %rax
140091d74: 4b 8b 74 1a 30              	movq	0x30(%r10,%r11), %rsi
140091d79: 48 39 c6                    	cmpq	%rax, %rsi
140091d7c: 0f 87 c7 00 00 00           	ja	0x140091e49 <.text+0x90e49>
140091d82: 48 81 fe 01 01 00 00        	cmpq	$0x101, %rsi            # imm = 0x101
140091d89: 72 3d                       	jb	0x140091dc8 <.text+0x90dc8>
140091d8b: 66 c7 45 b8 02 00           	movw	$0x2, -0x48(%rbp)
140091d91: 48 89 55 c0                 	movq	%rdx, -0x40(%rbp)
140091d95: e9 8e 00 00 00              	jmp	0x140091e28 <.text+0x90e28>
140091d9a: 4c 89 4c 24 28              	movq	%r9, 0x28(%rsp)
140091d9f: 44 88 44 24 20              	movb	%r8b, 0x20(%rsp)
140091da4: 4c 89 d2                    	movq	%r10, %rdx
140091da7: 41 89 f0                    	movl	%esi, %r8d
140091daa: 4d 89 d9                    	movq	%r11, %r9
140091dad: e8 ee 62 00 00              	callq	0x1400980a0 <.text+0x970a0>
140091db2: b0 01                       	movb	$0x1, %al
140091db4: 48 81 c4 68 01 00 00        	addq	$0x168, %rsp            # imm = 0x168
140091dbb: 5b                          	popq	%rbx
140091dbc: 5f                          	popq	%rdi
140091dbd: 5e                          	popq	%rsi
140091dbe: 41 5c                       	popq	%r12
140091dc0: 41 5d                       	popq	%r13
140091dc2: 41 5e                       	popq	%r14
140091dc4: 41 5f                       	popq	%r15
140091dc6: 5d                          	popq	%rbp
140091dc7: c3                          	retq
140091dc8: 48 85 f6                    	testq	%rsi, %rsi
140091dcb: 74 55                       	je	0x140091e22 <.text+0x90e22>
140091dcd: 4d 01 da                    	addq	%r11, %r10
140091dd0: 49 8b 7a 08                 	movq	0x8(%r10), %rdi
140091dd4: 66 89 75 ba                 	movw	%si, -0x46(%rbp)
140091dd8: b8 00 01 00 00              	movl	$0x100, %eax            # imm = 0x100
140091ddd: 48 29 f0                    	subq	%rsi, %rax
140091de0: 4c 8d 14 2e                 	leaq	(%rsi,%rbp), %r10
140091de4: 49 83 c2 bc                 	addq	$-0x44, %r10
140091de8: 49 89 cf                    	movq	%rcx, %r15
140091deb: 4c 89 d1                    	movq	%r10, %rcx
140091dee: 49 89 d4                    	movq	%rdx, %r12
140091df1: 31 d2                       	xorl	%edx, %edx
140091df3: 45 89 c5                    	movl	%r8d, %r13d
140091df6: 49 89 c0                    	movq	%rax, %r8
140091df9: 4c 89 cb                    	movq	%r9, %rbx
140091dfc: e8 41 e5 1b 00              	callq	0x140250342 <.text+0x24f342>
140091e01: 48 8d 4d bc                 	leaq	-0x44(%rbp), %rcx
140091e05: 48 89 fa                    	movq	%rdi, %rdx
140091e08: 49 89 f0                    	movq	%rsi, %r8
140091e0b: e8 20 e5 1b 00              	callq	0x140250330 <.text+0x24f330>
140091e10: 4c 89 e2                    	movq	%r12, %rdx
140091e13: 45 89 e8                    	movl	%r13d, %r8d
140091e16: 49 89 d9                    	movq	%rbx, %r9
140091e19: 4c 89 f9                    	movq	%r15, %rcx
140091e1c: 66 b8 01 00                 	movw	$0x1, %ax
140091e20: eb 02                       	jmp	0x140091e24 <.text+0x90e24>
140091e22: 31 c0                       	xorl	%eax, %eax
140091e24: 66 89 45 b8                 	movw	%ax, -0x48(%rbp)
140091e28: 48 81 fe 01 01 00 00        	cmpq	$0x101, %rsi            # imm = 0x101
140091e2f: 0f 92 c3                    	setb	%bl
140091e32: 41 c6 04 16 00              	movb	$0x0, (%r14,%rdx)
140091e37: 48 8d 55 b8                 	leaq	-0x48(%rbp), %rdx
140091e3b: e8 90 87 ff ff              	callq	0x14008a5d0 <.text+0x895d0>
140091e40: 34 01                       	xorb	$0x1, %al
140091e42: 08 d8                       	orb	%bl, %al
140091e44: e9 6b ff ff ff              	jmp	0x140091db4 <.text+0x90db4>
140091e49: 4c 8d 0d d0 d2 1c 00        	leaq	0x1cd2d0(%rip), %r9     # 0x14025f120
140091e50: 31 c9                       	xorl	%ecx, %ecx
140091e52: 48 89 f2                    	movq	%rsi, %rdx
140091e55: 49 89 c0                    	movq	%rax, %r8
140091e58: e8 23 ef 1b 00              	callq	0x140250d80 <.text+0x24fd80>
140091e5d: 0f 0b                       	ud2

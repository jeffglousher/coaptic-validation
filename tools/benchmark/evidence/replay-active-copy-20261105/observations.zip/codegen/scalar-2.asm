
D:/CoapticCurrent/replay-active-copy-20261105/scalar-pin/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14008a5d0: 55                          	pushq	%rbp
14008a5d1: 41 57                       	pushq	%r15
14008a5d3: 41 56                       	pushq	%r14
14008a5d5: 41 55                       	pushq	%r13
14008a5d7: 41 54                       	pushq	%r12
14008a5d9: 56                          	pushq	%rsi
14008a5da: 57                          	pushq	%rdi
14008a5db: 53                          	pushq	%rbx
14008a5dc: 48 83 ec 78                 	subq	$0x78, %rsp
14008a5e0: 48 8d 6c 24 70              	leaq	0x70(%rsp), %rbp
14008a5e5: 0f 29 75 f0                 	movaps	%xmm6, -0x10(%rbp)
14008a5e9: 4c 89 ce                    	movq	%r9, %rsi
14008a5ec: 45 89 c7                    	movl	%r8d, %r15d
14008a5ef: 48 8b 82 08 01 00 00        	movq	0x108(%rdx), %rax
14008a5f6: 48 89 45 d8                 	movq	%rax, -0x28(%rbp)
14008a5fa: 48 8b 82 10 01 00 00        	movq	0x110(%rdx), %rax
14008a601: 48 89 45 d0                 	movq	%rax, -0x30(%rbp)
14008a605: 8b 82 18 01 00 00           	movl	0x118(%rdx), %eax
14008a60b: 89 45 e0                    	movl	%eax, -0x20(%rbp)
14008a60e: 8b 82 1c 01 00 00           	movl	0x11c(%rdx), %eax
14008a614: 89 45 e4                    	movl	%eax, -0x1c(%rbp)
14008a617: 0f b7 82 20 01 00 00        	movzwl	0x120(%rdx), %eax
14008a61e: 66 89 45 ec                 	movw	%ax, -0x14(%rbp)
14008a622: 0f b6 82 22 01 00 00        	movzbl	0x122(%rdx), %eax
14008a629: 88 45 ef                    	movb	%al, -0x11(%rbp)
14008a62c: 0f b6 82 23 01 00 00        	movzbl	0x123(%rdx), %eax
14008a633: 88 45 e9                    	movb	%al, -0x17(%rbp)
14008a636: f3 0f 10 b2 24 01 00 00     	movss	0x124(%rdx), %xmm6
14008a63e: 0f b7 82 24 01 00 00        	movzwl	0x124(%rdx), %eax
14008a645: 66 89 45 ea                 	movw	%ax, -0x16(%rbp)
14008a649: 4c 8b a2 28 01 00 00        	movq	0x128(%rdx), %r12
14008a650: 0f b7 3a                    	movzwl	(%rdx), %edi
14008a653: 85 ff                       	testl	%edi, %edi
14008a655: 0f 84 97 02 00 00           	je	0x14008a8f2 <.text+0x898f2>
14008a65b: 48 89 d3                    	movq	%rdx, %rbx
14008a65e: 49 89 ce                    	movq	%rcx, %r14
14008a661: 83 ff 01                    	cmpl	$0x1, %edi
14008a664: 75 11                       	jne	0x14008a677 <.text+0x89677>
14008a666: 0f b7 53 02                 	movzwl	0x2(%rbx), %edx
14008a66a: 48 81 fa 01 01 00 00        	cmpq	$0x101, %rdx            # imm = 0x101
14008a671: 0f 83 e1 03 00 00           	jae	0x14008aa58 <.text+0x89a58>
14008a677: 4c 89 65 c0                 	movq	%r12, -0x40(%rbp)
14008a67b: 49 8b 86 e8 00 00 00        	movq	0xe8(%r14), %rax
14008a682: 48 85 c0                    	testq	%rax, %rax
14008a685: 0f 84 f1 00 00 00           	je	0x14008a77c <.text+0x8977c>
14008a68b: b9 28 01 00 00              	movl	$0x128, %ecx            # imm = 0x128
14008a690: 49 03 8e c8 00 00 00        	addq	0xc8(%r14), %rcx
14008a697: 49 8b 96 d0 00 00 00        	movq	0xd0(%r14), %rdx
14008a69e: 49 c7 c3 ff ff ff ff        	movq	$-0x1, %r11
14008a6a5: 45 31 ed                    	xorl	%r13d, %r13d
14008a6a8: 45 31 e4                    	xorl	%r12d, %r12d
14008a6ab: 4d 69 cd 30 01 00 00        	imulq	$0x130, %r13, %r9       # imm = 0x130
14008a6b2: 49 01 c9                    	addq	%rcx, %r9
14008a6b5: eb 1c                       	jmp	0x14008a6d3 <.text+0x896d3>
14008a6b7: 66 0f 1f 84 00 00 00 00 00  	nopw	(%rax,%rax)
14008a6c0: 49 ff c5                    	incq	%r13
14008a6c3: 49 81 c1 30 01 00 00        	addq	$0x130, %r9             # imm = 0x130
14008a6ca: 49 39 c5                    	cmpq	%rax, %r13
14008a6cd: 0f 83 ac 00 00 00           	jae	0x14008a77f <.text+0x8977f>
14008a6d3: 49 39 d5                    	cmpq	%rdx, %r13
14008a6d6: 73 e8                       	jae	0x14008a6c0 <.text+0x896c0>
14008a6d8: 45 0f b7 91 d8 fe ff ff     	movzwl	-0x128(%r9), %r10d
14008a6e0: 66 41 83 fa ff              	cmpw	$-0x1, %r10w
14008a6e5: 74 d9                       	je	0x14008a6c0 <.text+0x896c0>
14008a6e7: 44 0f b7 45 ea              	movzwl	-0x16(%rbp), %r8d
14008a6ec: 66 45 39 41 fc              	cmpw	%r8w, -0x4(%r9)
14008a6f1: 75 4c                       	jne	0x14008a73f <.text+0x8973f>
14008a6f3: 44 8b 45 e0                 	movl	-0x20(%rbp), %r8d
14008a6f7: 45 39 41 f0                 	cmpl	%r8d, -0x10(%r9)
14008a6fb: 75 42                       	jne	0x14008a73f <.text+0x8973f>
14008a6fd: 44 8b 45 e4                 	movl	-0x1c(%rbp), %r8d
14008a701: 45 39 41 f4                 	cmpl	%r8d, -0xc(%r9)
14008a705: 75 38                       	jne	0x14008a73f <.text+0x8973f>
14008a707: 44 0f b7 45 ec              	movzwl	-0x14(%rbp), %r8d
14008a70c: 66 45 39 41 f8              	cmpw	%r8w, -0x8(%r9)
14008a711: 75 2c                       	jne	0x14008a73f <.text+0x8973f>
14008a713: 44 0f b6 45 ef              	movzbl	-0x11(%rbp), %r8d
14008a718: 45 38 41 fa                 	cmpb	%r8b, -0x6(%r9)
14008a71c: 75 21                       	jne	0x14008a73f <.text+0x8973f>
14008a71e: 4c 89 5d b8                 	movq	%r11, -0x48(%rbp)
14008a722: 4d 8b 59 e0                 	movq	-0x20(%r9), %r11
14008a726: 4c 33 5d d8                 	xorq	-0x28(%rbp), %r11
14008a72a: 4d 8b 41 e8                 	movq	-0x18(%r9), %r8
14008a72e: 4c 33 45 d0                 	xorq	-0x30(%rbp), %r8
14008a732: 4d 09 d8                    	orq	%r11, %r8
14008a735: 4c 8b 5d b8                 	movq	-0x48(%rbp), %r11
14008a739: 0f 84 e6 02 00 00           	je	0x14008aa25 <.text+0x89a25>
14008a73f: 4d 8b 09                    	movq	(%r9), %r9
14008a742: 4d 85 c9                    	testq	%r9, %r9
14008a745: 74 27                       	je	0x14008a76e <.text+0x8976e>
14008a747: 4d 85 e4                    	testq	%r12, %r12
14008a74a: 41 0f 94 c0                 	sete	%r8b
14008a74e: 4d 39 d9                    	cmpq	%r11, %r9
14008a751: 41 0f 92 c2                 	setb	%r10b
14008a755: 45 08 c2                    	orb	%r8b, %r10b
14008a758: 4c 8b 45 c8                 	movq	-0x38(%rbp), %r8
14008a75c: 4d 0f 45 c5                 	cmovneq	%r13, %r8
14008a760: 4c 89 45 c8                 	movq	%r8, -0x38(%rbp)
14008a764: 4d 0f 45 d9                 	cmovneq	%r9, %r11
14008a768: 41 bc 01 00 00 00           	movl	$0x1, %r12d
14008a76e: 49 ff c5                    	incq	%r13
14008a771: 49 39 c5                    	cmpq	%rax, %r13
14008a774: 0f 82 31 ff ff ff           	jb	0x14008a6ab <.text+0x896ab>
14008a77a: eb 03                       	jmp	0x14008a77f <.text+0x8977f>
14008a77c: 45 31 e4                    	xorl	%r12d, %r12d
14008a77f: 4d 8d ae d8 00 00 00        	leaq	0xd8(%r14), %r13
14008a786: 4c 89 e9                    	movq	%r13, %rcx
14008a789: e8 02 0a f8 ff              	callq	0x14000b190 <.text+0xa190>
14008a78e: a8 01                       	testb	$0x1, %al
14008a790: 74 68                       	je	0x14008a7fa <.text+0x897fa>
14008a792: 4c 8b 65 c0                 	movq	-0x40(%rbp), %r12
14008a796: 4d 85 e4                    	testq	%r12, %r12
14008a799: 74 16                       	je	0x14008a7b1 <.text+0x897b1>
14008a79b: 49 8b 86 18 01 00 00        	movq	0x118(%r14), %rax
14008a7a2: 48 ff c8                    	decq	%rax
14008a7a5: 4c 39 e0                    	cmpq	%r12, %rax
14008a7a8: 72 07                       	jb	0x14008a7b1 <.text+0x897b1>
14008a7aa: 4d 89 a6 18 01 00 00        	movq	%r12, 0x118(%r14)
14008a7b1: 49 8b 86 d0 00 00 00        	movq	0xd0(%r14), %rax
14008a7b8: 48 39 c2                    	cmpq	%rax, %rdx
14008a7bb: 0f 83 ad 02 00 00           	jae	0x14008aa6e <.text+0x89a6e>
14008a7c1: 48 8d 83 08 01 00 00        	leaq	0x108(%rbx), %rax
14008a7c8: 48 69 ca 30 01 00 00        	imulq	$0x130, %rdx, %rcx      # imm = 0x130
14008a7cf: 49 03 8e c8 00 00 00        	addq	0xc8(%r14), %rcx
14008a7d6: 85 ff                       	testl	%edi, %edi
14008a7d8: 0f 84 b3 01 00 00           	je	0x14008a991 <.text+0x89991>
14008a7de: 83 ff 01                    	cmpl	$0x1, %edi
14008a7e1: 0f 85 cd 01 00 00           	jne	0x14008a9b4 <.text+0x899b4>
14008a7e7: 41 b8 30 01 00 00           	movl	$0x130, %r8d            # imm = 0x130
14008a7ed: 48 89 da                    	movq	%rbx, %rdx
14008a7f0: e8 3b 5b 1c 00              	callq	0x140250330 <.text+0x24f330>
14008a7f5: e9 c9 01 00 00              	jmp	0x14008a9c3 <.text+0x899c3>
14008a7fa: 49 83 fc 01                 	cmpq	$0x1, %r12
14008a7fe: 4c 8b 65 c0                 	movq	-0x40(%rbp), %r12
14008a802: 0f 85 ea 00 00 00           	jne	0x14008a8f2 <.text+0x898f2>
14008a808: 49 8b 86 d0 00 00 00        	movq	0xd0(%r14), %rax
14008a80f: 4c 8b 4d c8                 	movq	-0x38(%rbp), %r9
14008a813: 49 39 c1                    	cmpq	%rax, %r9
14008a816: 73 75                       	jae	0x14008a88d <.text+0x8988d>
14008a818: 49 8b 8e c8 00 00 00        	movq	0xc8(%r14), %rcx
14008a81f: 49 69 d1 30 01 00 00        	imulq	$0x130, %r9, %rdx       # imm = 0x130
14008a826: 66 83 3c 11 02              	cmpw	$0x2, (%rcx,%rdx)
14008a82b: 75 60                       	jne	0x14008a88d <.text+0x8988d>
14008a82d: 48 01 d1                    	addq	%rdx, %rcx
14008a830: 48 8b 49 08                 	movq	0x8(%rcx), %rcx
14008a834: 49 3b 8e 88 00 00 00        	cmpq	0x88(%r14), %rcx
14008a83b: 73 50                       	jae	0x14008a88d <.text+0x8988d>
14008a83d: 49 8b 96 80 00 00 00        	movq	0x80(%r14), %rdx
14008a844: 80 3c 0a 01                 	cmpb	$0x1, (%rdx,%rcx)
14008a848: 75 43                       	jne	0x14008a88d <.text+0x8988d>
14008a84a: 49 3b 8e a0 00 00 00        	cmpq	0xa0(%r14), %rcx
14008a851: 73 0e                       	jae	0x14008a861 <.text+0x89861>
14008a853: 4d 8b 86 98 00 00 00        	movq	0x98(%r14), %r8
14008a85a: 41 80 3c 08 00              	cmpb	$0x0, (%r8,%rcx)
14008a85f: 75 2c                       	jne	0x14008a88d <.text+0x8988d>
14008a861: c6 04 0a 00                 	movb	$0x0, (%rdx,%rcx)
14008a865: 49 ff 8e b0 00 00 00        	decq	0xb0(%r14)
14008a86c: 49 3b 4e 70                 	cmpq	0x70(%r14), %rcx
14008a870: 73 1b                       	jae	0x14008a88d <.text+0x8988d>
14008a872: 49 8b 56 68                 	movq	0x68(%r14), %rdx
14008a876: 48 6b c9 58                 	imulq	$0x58, %rcx, %rcx
14008a87a: 48 c7 44 0a 30 00 00 00 00  	movq	$0x0, 0x30(%rdx,%rcx)
14008a883: c6 44 0a 52 02              	movb	$0x2, 0x52(%rdx,%rcx)
14008a888: c6 44 0a 25 02              	movb	$0x2, 0x25(%rdx,%rcx)
14008a88d: 4d 3b 8e e8 00 00 00        	cmpq	0xe8(%r14), %r9
14008a894: 73 4a                       	jae	0x14008a8e0 <.text+0x898e0>
14008a896: 49 8b 8e e0 00 00 00        	movq	0xe0(%r14), %rcx
14008a89d: 42 80 3c 09 01              	cmpb	$0x1, (%rcx,%r9)
14008a8a2: 75 3c                       	jne	0x14008a8e0 <.text+0x898e0>
14008a8a4: 4d 3b 8e 00 01 00 00        	cmpq	0x100(%r14), %r9
14008a8ab: 73 0e                       	jae	0x14008a8bb <.text+0x898bb>
14008a8ad: 49 8b 96 f8 00 00 00        	movq	0xf8(%r14), %rdx
14008a8b4: 42 80 3c 0a 00              	cmpb	$0x0, (%rdx,%r9)
14008a8b9: 75 25                       	jne	0x14008a8e0 <.text+0x898e0>
14008a8bb: 42 c6 04 09 00              	movb	$0x0, (%rcx,%r9)
14008a8c0: 49 ff 8e 10 01 00 00        	decq	0x110(%r14)
14008a8c7: 49 39 c1                    	cmpq	%rax, %r9
14008a8ca: 73 14                       	jae	0x14008a8e0 <.text+0x898e0>
14008a8cc: 49 8b 86 c8 00 00 00        	movq	0xc8(%r14), %rax
14008a8d3: 49 69 c9 30 01 00 00        	imulq	$0x130, %r9, %rcx       # imm = 0x130
14008a8da: 66 c7 04 08 ff ff           	movw	$0xffff, (%rax,%rcx)    # imm = 0xFFFF
14008a8e0: 4c 89 e9                    	movq	%r13, %rcx
14008a8e3: e8 a8 08 f8 ff              	callq	0x14000b190 <.text+0xa190>
14008a8e8: 48 83 f8 01                 	cmpq	$0x1, %rax
14008a8ec: 0f 84 a4 fe ff ff           	je	0x14008a796 <.text+0x89796>
14008a8f2: 41 fe cf                    	decb	%r15b
14008a8f5: 41 80 ff 07                 	cmpb	$0x7, %r15b
14008a8f9: 0f 92 c0                    	setb	%al
14008a8fc: b2 4d                       	movb	$0x4d, %dl
14008a8fe: 44 89 f9                    	movl	%r15d, %ecx
14008a901: d2 ea                       	shrb	%cl, %dl
14008a903: 84 d0                       	testb	%dl, %al
14008a905: 0f 85 82 00 00 00           	jne	0x14008a98d <.text+0x8998d>
14008a90b: 0f b6 46 22                 	movzbl	0x22(%rsi), %eax
14008a90f: 3c 02                       	cmpb	$0x2, %al
14008a911: 75 3c                       	jne	0x14008a94f <.text+0x8994f>
14008a913: 4c 89 26                    	movq	%r12, (%rsi)
14008a916: 48 8b 45 d8                 	movq	-0x28(%rbp), %rax
14008a91a: 48 89 46 08                 	movq	%rax, 0x8(%rsi)
14008a91e: 48 8b 45 d0                 	movq	-0x30(%rbp), %rax
14008a922: 48 89 46 10                 	movq	%rax, 0x10(%rsi)
14008a926: 8b 45 e0                    	movl	-0x20(%rbp), %eax
14008a929: 89 46 18                    	movl	%eax, 0x18(%rsi)
14008a92c: 8b 45 e4                    	movl	-0x1c(%rbp), %eax
14008a92f: 89 46 1c                    	movl	%eax, 0x1c(%rsi)
14008a932: 0f b7 45 ec                 	movzwl	-0x14(%rbp), %eax
14008a936: 66 89 46 20                 	movw	%ax, 0x20(%rsi)
14008a93a: 0f b6 45 ef                 	movzbl	-0x11(%rbp), %eax
14008a93e: 88 46 22                    	movb	%al, 0x22(%rsi)
14008a941: 0f b6 45 e9                 	movzbl	-0x17(%rbp), %eax
14008a945: 88 46 23                    	movb	%al, 0x23(%rsi)
14008a948: f3 0f 11 76 24              	movss	%xmm6, 0x24(%rsi)
14008a94d: eb 3e                       	jmp	0x14008a98d <.text+0x8998d>
14008a94f: 0f b7 4d ea                 	movzwl	-0x16(%rbp), %ecx
14008a953: 66 39 4e 24                 	cmpw	%cx, 0x24(%rsi)
14008a957: 75 ba                       	jne	0x14008a913 <.text+0x89913>
14008a959: 8b 4d e0                    	movl	-0x20(%rbp), %ecx
14008a95c: 39 4e 18                    	cmpl	%ecx, 0x18(%rsi)
14008a95f: 75 b2                       	jne	0x14008a913 <.text+0x89913>
14008a961: 8b 4d e4                    	movl	-0x1c(%rbp), %ecx
14008a964: 39 4e 1c                    	cmpl	%ecx, 0x1c(%rsi)
14008a967: 75 aa                       	jne	0x14008a913 <.text+0x89913>
14008a969: 0f b7 4d ec                 	movzwl	-0x14(%rbp), %ecx
14008a96d: 66 39 4e 20                 	cmpw	%cx, 0x20(%rsi)
14008a971: 75 a0                       	jne	0x14008a913 <.text+0x89913>
14008a973: 3a 45 ef                    	cmpb	-0x11(%rbp), %al
14008a976: 75 9b                       	jne	0x14008a913 <.text+0x89913>
14008a978: 48 8b 46 08                 	movq	0x8(%rsi), %rax
14008a97c: 48 33 45 d8                 	xorq	-0x28(%rbp), %rax
14008a980: 48 8b 4e 10                 	movq	0x10(%rsi), %rcx
14008a984: 48 33 4d d0                 	xorq	-0x30(%rbp), %rcx
14008a988: 48 09 c1                    	orq	%rax, %rcx
14008a98b: 75 86                       	jne	0x14008a913 <.text+0x89913>
14008a98d: 31 c0                       	xorl	%eax, %eax
14008a98f: eb 7f                       	jmp	0x14008aa10 <.text+0x89a10>
14008a991: 66 c7 01 00 00              	movw	$0x0, (%rcx)
14008a996: 0f 10 00                    	movups	(%rax), %xmm0
14008a999: 0f 10 48 10                 	movups	0x10(%rax), %xmm1
14008a99d: 0f 11 81 08 01 00 00        	movups	%xmm0, 0x108(%rcx)
14008a9a4: 0f 11 89 18 01 00 00        	movups	%xmm1, 0x118(%rcx)
14008a9ab: 4c 89 a1 28 01 00 00        	movq	%r12, 0x128(%rcx)
14008a9b2: eb 0f                       	jmp	0x14008a9c3 <.text+0x899c3>
14008a9b4: 4c 8b 4b 08                 	movq	0x8(%rbx), %r9
14008a9b8: 48 89 c2                    	movq	%rax, %rdx
14008a9bb: 4d 89 e0                    	movq	%r12, %r8
14008a9be: e8 ed 03 f8 ff              	callq	0x14000adb0 <.text+0x9db0>
14008a9c3: 0f b6 4e 22                 	movzbl	0x22(%rsi), %ecx
14008a9c7: b0 01                       	movb	$0x1, %al
14008a9c9: 80 f9 02                    	cmpb	$0x2, %cl
14008a9cc: 74 42                       	je	0x14008aa10 <.text+0x89a10>
14008a9ce: 0f b7 55 ea                 	movzwl	-0x16(%rbp), %edx
14008a9d2: 66 39 56 24                 	cmpw	%dx, 0x24(%rsi)
14008a9d6: 75 38                       	jne	0x14008aa10 <.text+0x89a10>
14008a9d8: 8b 55 e0                    	movl	-0x20(%rbp), %edx
14008a9db: 39 56 18                    	cmpl	%edx, 0x18(%rsi)
14008a9de: 75 30                       	jne	0x14008aa10 <.text+0x89a10>
14008a9e0: 8b 55 e4                    	movl	-0x1c(%rbp), %edx
14008a9e3: 39 56 1c                    	cmpl	%edx, 0x1c(%rsi)
14008a9e6: 75 28                       	jne	0x14008aa10 <.text+0x89a10>
14008a9e8: 0f b7 55 ec                 	movzwl	-0x14(%rbp), %edx
14008a9ec: 66 39 56 20                 	cmpw	%dx, 0x20(%rsi)
14008a9f0: 75 1e                       	jne	0x14008aa10 <.text+0x89a10>
14008a9f2: 3a 4d ef                    	cmpb	-0x11(%rbp), %cl
14008a9f5: 75 19                       	jne	0x14008aa10 <.text+0x89a10>
14008a9f7: 48 8b 55 d8                 	movq	-0x28(%rbp), %rdx
14008a9fb: 48 33 56 08                 	xorq	0x8(%rsi), %rdx
14008a9ff: 48 8b 4d d0                 	movq	-0x30(%rbp), %rcx
14008aa03: 48 33 4e 10                 	xorq	0x10(%rsi), %rcx
14008aa07: 48 09 d1                    	orq	%rdx, %rcx
14008aa0a: 75 04                       	jne	0x14008aa10 <.text+0x89a10>
14008aa0c: c6 46 22 02                 	movb	$0x2, 0x22(%rsi)
14008aa10: 0f 28 75 f0                 	movaps	-0x10(%rbp), %xmm6
14008aa14: 48 83 c4 78                 	addq	$0x78, %rsp
14008aa18: 5b                          	popq	%rbx
14008aa19: 5f                          	popq	%rdi
14008aa1a: 5e                          	popq	%rsi
14008aa1b: 41 5c                       	popq	%r12
14008aa1d: 41 5d                       	popq	%r13
14008aa1f: 41 5e                       	popq	%r14
14008aa21: 41 5f                       	popq	%r15
14008aa23: 5d                          	popq	%rbp
14008aa24: c3                          	retq
14008aa25: 66 41 83 fa 02              	cmpw	$0x2, %r10w
14008aa2a: 75 10                       	jne	0x14008aa3c <.text+0x89a3c>
14008aa2c: 49 8b 91 e0 fe ff ff        	movq	-0x120(%r9), %rdx
14008aa33: 49 8d 4e 60                 	leaq	0x60(%r14), %rcx
14008aa37: e8 d4 66 f8 ff              	callq	0x140011110 <.text+0x10110>
14008aa3c: 49 8d 8e c0 00 00 00        	leaq	0xc0(%r14), %rcx
14008aa43: 4c 89 ea                    	movq	%r13, %rdx
14008aa46: e8 45 6f f8 ff              	callq	0x140011990 <.text+0x10990>
14008aa4b: 3c ff                       	cmpb	$-0x1, %al
14008aa4d: 0f 85 70 ff ff ff           	jne	0x14008a9c3 <.text+0x899c3>
14008aa53: e9 27 fd ff ff              	jmp	0x14008a77f <.text+0x8977f>
14008aa58: 4c 8d 0d 59 49 1d 00        	leaq	0x1d4959(%rip), %r9     # 0x14025f3b8
14008aa5f: 41 b8 00 01 00 00           	movl	$0x100, %r8d            # imm = 0x100
14008aa65: 31 c9                       	xorl	%ecx, %ecx
14008aa67: e8 14 63 1c 00              	callq	0x140250d80 <.text+0x24fd80>
14008aa6c: 0f 0b                       	ud2
14008aa6e: 4c 8d 05 6b 36 1e 00        	leaq	0x1e366b(%rip), %r8     # 0x14026e0e0
14008aa75: 48 89 d1                    	movq	%rdx, %rcx
14008aa78: 48 89 c2                    	movq	%rax, %rdx
14008aa7b: e8 f3 60 1c 00              	callq	0x140250b73 <.text+0x24fb73>
14008aa80: 0f 0b                       	ud2

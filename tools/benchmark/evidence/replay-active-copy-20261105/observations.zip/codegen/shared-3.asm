
D:/CoapticCurrent/replay-storage-20261105/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140091c60: 55                          	pushq	%rbp
140091c61: 41 57                       	pushq	%r15
140091c63: 41 56                       	pushq	%r14
140091c65: 41 55                       	pushq	%r13
140091c67: 41 54                       	pushq	%r12
140091c69: 56                          	pushq	%rsi
140091c6a: 57                          	pushq	%rdi
140091c6b: 53                          	pushq	%rbx
140091c6c: 48 81 ec 68 02 00 00        	subq	$0x268, %rsp            # imm = 0x268
140091c73: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
140091c7b: b0 01                       	movb	$0x1, %al
140091c7d: 80 bd 50 02 00 00 00        	cmpb	$0x0, 0x250(%rbp)
140091c84: 0f 85 db 00 00 00           	jne	0x140091d65 <.text+0x90d65>
140091c8a: 48 8b b5 68 02 00 00        	movq	0x268(%rbp), %rsi
140091c91: 0f b6 9d 60 02 00 00        	movzbl	0x260(%rbp), %ebx
140091c98: 48 8b 85 58 02 00 00        	movq	0x258(%rbp), %rax
140091c9f: 49 89 c2                    	movq	%rax, %r10
140091ca2: 49 81 c2 d8 c4 03 00        	addq	$0x3c4d8, %r10          # imm = 0x3C4D8
140091ca9: 49 c7 c3 ff ff ff ff        	movq	$-0x1, %r11
140091cb0: 4d 0f 43 da                 	cmovaeq	%r10, %r11
140091cb4: 41 0f 10 00                 	movups	(%r8), %xmm0
140091cb8: 41 0f 10 48 0c              	movups	0xc(%r8), %xmm1
140091cbd: 0f 11 8d cc 01 00 00        	movups	%xmm1, 0x1cc(%rbp)
140091cc4: 0f 11 85 c0 01 00 00        	movups	%xmm0, 0x1c0(%rbp)
140091ccb: 66 44 89 8d dc 01 00 00     	movw	%r9w, 0x1dc(%rbp)
140091cd3: 4c 89 9d e0 01 00 00        	movq	%r11, 0x1e0(%rbp)
140091cda: 48 3b 91 88 00 00 00        	cmpq	0x88(%rcx), %rdx
140091ce1: 73 69                       	jae	0x140091d4c <.text+0x90d4c>
140091ce3: 4c 8b 91 80 00 00 00        	movq	0x80(%rcx), %r10
140091cea: 41 80 3c 12 01              	cmpb	$0x1, (%r10,%rdx)
140091cef: 75 5b                       	jne	0x140091d4c <.text+0x90d4c>
140091cf1: 48 3b 91 a0 00 00 00        	cmpq	0xa0(%rcx), %rdx
140091cf8: 73 52                       	jae	0x140091d4c <.text+0x90d4c>
140091cfa: 4c 8b b9 98 00 00 00        	movq	0x98(%rcx), %r15
140091d01: 41 80 3c 17 00              	cmpb	$0x0, (%r15,%rdx)
140091d06: 75 44                       	jne	0x140091d4c <.text+0x90d4c>
140091d08: 41 c6 04 17 01              	movb	$0x1, (%r15,%rdx)
140091d0d: 48 3b 51 70                 	cmpq	0x70(%rcx), %rdx
140091d11: 73 39                       	jae	0x140091d4c <.text+0x90d4c>
140091d13: 48 8b 41 68                 	movq	0x68(%rcx), %rax
140091d17: 4c 6b ca 58                 	imulq	$0x58, %rdx, %r9
140091d1b: 4e 8b 44 08 10              	movq	0x10(%rax,%r9), %r8
140091d20: 4a 8b 7c 08 30              	movq	0x30(%rax,%r9), %rdi
140091d25: 4c 39 c7                    	cmpq	%r8, %rdi
140091d28: 0f 87 e2 00 00 00           	ja	0x140091e10 <.text+0x90e10>
140091d2e: 48 81 ff 01 01 00 00        	cmpq	$0x101, %rdi            # imm = 0x101
140091d35: 72 42                       	jb	0x140091d79 <.text+0x90d79>
140091d37: 66 c7 85 b8 00 00 00 02 00  	movw	$0x2, 0xb8(%rbp)
140091d40: 48 89 95 c0 00 00 00        	movq	%rdx, 0xc0(%rbp)
140091d47: e9 98 00 00 00              	jmp	0x140091de4 <.text+0x90de4>
140091d4c: 48 89 74 24 28              	movq	%rsi, 0x28(%rsp)
140091d51: 88 5c 24 20                 	movb	%bl, 0x20(%rsp)
140091d55: 4c 89 c2                    	movq	%r8, %rdx
140091d58: 45 89 c8                    	movl	%r9d, %r8d
140091d5b: 49 89 c1                    	movq	%rax, %r9
140091d5e: e8 cd 63 00 00              	callq	0x140098130 <.text+0x97130>
140091d63: b0 01                       	movb	$0x1, %al
140091d65: 48 81 c4 68 02 00 00        	addq	$0x268, %rsp            # imm = 0x268
140091d6c: 5b                          	popq	%rbx
140091d6d: 5f                          	popq	%rdi
140091d6e: 5e                          	popq	%rsi
140091d6f: 41 5c                       	popq	%r12
140091d71: 41 5d                       	popq	%r13
140091d73: 41 5e                       	popq	%r14
140091d75: 41 5f                       	popq	%r15
140091d77: 5d                          	popq	%rbp
140091d78: c3                          	retq
140091d79: 49 89 d4                    	movq	%rdx, %r12
140091d7c: 49 89 cd                    	movq	%rcx, %r13
140091d7f: 48 85 ff                    	testq	%rdi, %rdi
140091d82: 74 34                       	je	0x140091db8 <.text+0x90db8>
140091d84: 4c 01 c8                    	addq	%r9, %rax
140091d87: 4c 8b 70 08                 	movq	0x8(%rax), %r14
140091d8b: 41 b8 00 01 00 00           	movl	$0x100, %r8d            # imm = 0x100
140091d91: 49 29 f8                    	subq	%rdi, %r8
140091d94: 48 8d 0c 2f                 	leaq	(%rdi,%rbp), %rcx
140091d98: 48 83 c1 b8                 	addq	$-0x48, %rcx
140091d9c: 31 d2                       	xorl	%edx, %edx
140091d9e: e8 4f ea 1b 00              	callq	0x1402507f2 <.text+0x24f7f2>
140091da3: 48 8d 4d b8                 	leaq	-0x48(%rbp), %rcx
140091da7: 4c 89 f2                    	movq	%r14, %rdx
140091daa: 49 89 f8                    	movq	%rdi, %r8
140091dad: e8 2e ea 1b 00              	callq	0x1402507e0 <.text+0x24f7e0>
140091db2: 66 b8 01 00                 	movw	$0x1, %ax
140091db6: eb 02                       	jmp	0x140091dba <.text+0x90dba>
140091db8: 31 c0                       	xorl	%eax, %eax
140091dba: 66 89 85 b8 00 00 00        	movw	%ax, 0xb8(%rbp)
140091dc1: 66 89 bd ba 00 00 00        	movw	%di, 0xba(%rbp)
140091dc8: 48 8d 8d bc 00 00 00        	leaq	0xbc(%rbp), %rcx
140091dcf: 48 8d 55 b8                 	leaq	-0x48(%rbp), %rdx
140091dd3: 41 b8 00 01 00 00           	movl	$0x100, %r8d            # imm = 0x100
140091dd9: e8 02 ea 1b 00              	callq	0x1402507e0 <.text+0x24f7e0>
140091dde: 4c 89 e9                    	movq	%r13, %rcx
140091de1: 4c 89 e2                    	movq	%r12, %rdx
140091de4: 48 81 ff 01 01 00 00        	cmpq	$0x101, %rdi            # imm = 0x101
140091deb: 40 0f 92 c7                 	setb	%dil
140091def: 41 c6 04 17 00              	movb	$0x0, (%r15,%rdx)
140091df4: 48 8d 95 b8 00 00 00        	leaq	0xb8(%rbp), %rdx
140091dfb: 41 89 d8                    	movl	%ebx, %r8d
140091dfe: 49 89 f1                    	movq	%rsi, %r9
140091e01: e8 7a 87 ff ff              	callq	0x14008a580 <.text+0x89580>
140091e06: 34 01                       	xorb	$0x1, %al
140091e08: 40 08 f8                    	orb	%dil, %al
140091e0b: e9 55 ff ff ff              	jmp	0x140091d65 <.text+0x90d65>
140091e10: 4c 8d 0d c9 d2 1c 00        	leaq	0x1cd2c9(%rip), %r9     # 0x14025f0e0
140091e17: 31 c9                       	xorl	%ecx, %ecx
140091e19: 48 89 fa                    	movq	%rdi, %rdx
140091e1c: e8 0f f4 1b 00              	callq	0x140251230 <.text+0x250230>
140091e21: 0f 0b                       	ud2


D:/CoapticCurrent/replay-active-copy-20261105/direct-fill/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140091b90: 55                          	pushq	%rbp
140091b91: 41 57                       	pushq	%r15
140091b93: 41 56                       	pushq	%r14
140091b95: 41 55                       	pushq	%r13
140091b97: 41 54                       	pushq	%r12
140091b99: 56                          	pushq	%rsi
140091b9a: 57                          	pushq	%rdi
140091b9b: 53                          	pushq	%rbx
140091b9c: 48 81 ec 68 01 00 00        	subq	$0x168, %rsp            # imm = 0x168
140091ba3: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
140091bab: b0 01                       	movb	$0x1, %al
140091bad: 80 bd 50 01 00 00 00        	cmpb	$0x0, 0x150(%rbp)
140091bb4: 0f 85 da 00 00 00           	jne	0x140091c94 <.text+0x90c94>
140091bba: 44 89 ce                    	movl	%r9d, %esi
140091bbd: 4d 89 c2                    	movq	%r8, %r10
140091bc0: 4c 8b 8d 68 01 00 00        	movq	0x168(%rbp), %r9
140091bc7: 44 0f b6 85 60 01 00 00     	movzbl	0x160(%rbp), %r8d
140091bcf: 4c 8b 9d 58 01 00 00        	movq	0x158(%rbp), %r11
140091bd6: 4c 89 d8                    	movq	%r11, %rax
140091bd9: 48 05 d8 c4 03 00           	addq	$0x3c4d8, %rax          # imm = 0x3C4D8
140091bdf: 48 c7 c7 ff ff ff ff        	movq	$-0x1, %rdi
140091be6: 48 0f 43 f8                 	cmovaeq	%rax, %rdi
140091bea: 41 0f 10 02                 	movups	(%r10), %xmm0
140091bee: 41 0f 10 4a 0c              	movups	0xc(%r10), %xmm1
140091bf3: 0f 11 8d cc 00 00 00        	movups	%xmm1, 0xcc(%rbp)
140091bfa: 0f 11 85 c0 00 00 00        	movups	%xmm0, 0xc0(%rbp)
140091c01: 66 89 b5 dc 00 00 00        	movw	%si, 0xdc(%rbp)
140091c08: 48 89 bd e0 00 00 00        	movq	%rdi, 0xe0(%rbp)
140091c0f: 48 3b 91 88 00 00 00        	cmpq	0x88(%rcx), %rdx
140091c16: 73 62                       	jae	0x140091c7a <.text+0x90c7a>
140091c18: 48 8b 81 80 00 00 00        	movq	0x80(%rcx), %rax
140091c1f: 80 3c 10 01                 	cmpb	$0x1, (%rax,%rdx)
140091c23: 75 55                       	jne	0x140091c7a <.text+0x90c7a>
140091c25: 48 3b 91 a0 00 00 00        	cmpq	0xa0(%rcx), %rdx
140091c2c: 73 4c                       	jae	0x140091c7a <.text+0x90c7a>
140091c2e: 4c 8b b1 98 00 00 00        	movq	0x98(%rcx), %r14
140091c35: 41 80 3c 16 00              	cmpb	$0x0, (%r14,%rdx)
140091c3a: 75 3e                       	jne	0x140091c7a <.text+0x90c7a>
140091c3c: 41 c6 04 16 01              	movb	$0x1, (%r14,%rdx)
140091c41: 48 3b 51 70                 	cmpq	0x70(%rcx), %rdx
140091c45: 73 33                       	jae	0x140091c7a <.text+0x90c7a>
140091c47: 4c 8b 51 68                 	movq	0x68(%rcx), %r10
140091c4b: 4c 6b da 58                 	imulq	$0x58, %rdx, %r11
140091c4f: 4b 8b 44 1a 10              	movq	0x10(%r10,%r11), %rax
140091c54: 4b 8b 74 1a 30              	movq	0x30(%r10,%r11), %rsi
140091c59: 48 39 c6                    	cmpq	%rax, %rsi
140091c5c: 0f 87 c7 00 00 00           	ja	0x140091d29 <.text+0x90d29>
140091c62: 48 81 fe 01 01 00 00        	cmpq	$0x101, %rsi            # imm = 0x101
140091c69: 72 3d                       	jb	0x140091ca8 <.text+0x90ca8>
140091c6b: 66 c7 45 b8 02 00           	movw	$0x2, -0x48(%rbp)
140091c71: 48 89 55 c0                 	movq	%rdx, -0x40(%rbp)
140091c75: e9 8e 00 00 00              	jmp	0x140091d08 <.text+0x90d08>
140091c7a: 4c 89 4c 24 28              	movq	%r9, 0x28(%rsp)
140091c7f: 44 88 44 24 20              	movb	%r8b, 0x20(%rsp)
140091c84: 4c 89 d2                    	movq	%r10, %rdx
140091c87: 41 89 f0                    	movl	%esi, %r8d
140091c8a: 4d 89 d9                    	movq	%r11, %r9
140091c8d: e8 ee 62 00 00              	callq	0x140097f80 <.text+0x96f80>
140091c92: b0 01                       	movb	$0x1, %al
140091c94: 48 81 c4 68 01 00 00        	addq	$0x168, %rsp            # imm = 0x168
140091c9b: 5b                          	popq	%rbx
140091c9c: 5f                          	popq	%rdi
140091c9d: 5e                          	popq	%rsi
140091c9e: 41 5c                       	popq	%r12
140091ca0: 41 5d                       	popq	%r13
140091ca2: 41 5e                       	popq	%r14
140091ca4: 41 5f                       	popq	%r15
140091ca6: 5d                          	popq	%rbp
140091ca7: c3                          	retq
140091ca8: 48 85 f6                    	testq	%rsi, %rsi
140091cab: 74 55                       	je	0x140091d02 <.text+0x90d02>
140091cad: 4d 01 da                    	addq	%r11, %r10
140091cb0: 49 8b 7a 08                 	movq	0x8(%r10), %rdi
140091cb4: 66 89 75 ba                 	movw	%si, -0x46(%rbp)
140091cb8: b8 00 01 00 00              	movl	$0x100, %eax            # imm = 0x100
140091cbd: 48 29 f0                    	subq	%rsi, %rax
140091cc0: 4c 8d 14 2e                 	leaq	(%rsi,%rbp), %r10
140091cc4: 49 83 c2 bc                 	addq	$-0x44, %r10
140091cc8: 49 89 cf                    	movq	%rcx, %r15
140091ccb: 4c 89 d1                    	movq	%r10, %rcx
140091cce: 49 89 d4                    	movq	%rdx, %r12
140091cd1: 31 d2                       	xorl	%edx, %edx
140091cd3: 45 89 c5                    	movl	%r8d, %r13d
140091cd6: 49 89 c0                    	movq	%rax, %r8
140091cd9: 4c 89 cb                    	movq	%r9, %rbx
140091cdc: e8 91 e5 1b 00              	callq	0x140250272 <.text+0x24f272>
140091ce1: 48 8d 4d bc                 	leaq	-0x44(%rbp), %rcx
140091ce5: 48 89 fa                    	movq	%rdi, %rdx
140091ce8: 49 89 f0                    	movq	%rsi, %r8
140091ceb: e8 70 e5 1b 00              	callq	0x140250260 <.text+0x24f260>
140091cf0: 4c 89 e2                    	movq	%r12, %rdx
140091cf3: 45 89 e8                    	movl	%r13d, %r8d
140091cf6: 49 89 d9                    	movq	%rbx, %r9
140091cf9: 4c 89 f9                    	movq	%r15, %rcx
140091cfc: 66 b8 01 00                 	movw	$0x1, %ax
140091d00: eb 02                       	jmp	0x140091d04 <.text+0x90d04>
140091d02: 31 c0                       	xorl	%eax, %eax
140091d04: 66 89 45 b8                 	movw	%ax, -0x48(%rbp)
140091d08: 48 81 fe 01 01 00 00        	cmpq	$0x101, %rsi            # imm = 0x101
140091d0f: 0f 92 c3                    	setb	%bl
140091d12: 41 c6 04 16 00              	movb	$0x0, (%r14,%rdx)
140091d17: 48 8d 55 b8                 	leaq	-0x48(%rbp), %rdx
140091d1b: e8 70 87 ff ff              	callq	0x14008a490 <.text+0x89490>
140091d20: 34 01                       	xorb	$0x1, %al
140091d22: 08 d8                       	orb	%bl, %al
140091d24: e9 6b ff ff ff              	jmp	0x140091c94 <.text+0x90c94>
140091d29: 4c 8d 0d f0 d3 1c 00        	leaq	0x1cd3f0(%rip), %r9     # 0x14025f120
140091d30: 31 c9                       	xorl	%ecx, %ecx
140091d32: 48 89 f2                    	movq	%rsi, %rdx
140091d35: 49 89 c0                    	movq	%rax, %r8
140091d38: e8 73 ef 1b 00              	callq	0x140250cb0 <.text+0x24fcb0>
140091d3d: 0f 0b                       	ud2

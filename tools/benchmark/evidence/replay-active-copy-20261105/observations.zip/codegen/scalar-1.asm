
D:/CoapticCurrent/replay-active-copy-20261105/scalar-pin/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140089010: 55                          	pushq	%rbp
140089011: 41 57                       	pushq	%r15
140089013: 41 56                       	pushq	%r14
140089015: 41 55                       	pushq	%r13
140089017: 41 54                       	pushq	%r12
140089019: 56                          	pushq	%rsi
14008901a: 57                          	pushq	%rdi
14008901b: 53                          	pushq	%rbx
14008901c: 48 81 ec a8 00 00 00        	subq	$0xa8, %rsp
140089023: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
14008902b: 0f 29 75 10                 	movaps	%xmm6, 0x10(%rbp)
14008902f: 4d 89 cf                    	movq	%r9, %r15
140089032: 49 89 ce                    	movq	%rcx, %r14
140089035: 4c 8b a2 08 01 00 00        	movq	0x108(%rdx), %r12
14008903c: 4c 8b aa 10 01 00 00        	movq	0x110(%rdx), %r13
140089043: 8b 82 18 01 00 00           	movl	0x118(%rdx), %eax
140089049: 89 45 00                    	movl	%eax, (%rbp)
14008904c: 8b 82 1c 01 00 00           	movl	0x11c(%rdx), %eax
140089052: 89 45 04                    	movl	%eax, 0x4(%rbp)
140089055: 0f b7 82 20 01 00 00        	movzwl	0x120(%rdx), %eax
14008905c: 66 89 45 0c                 	movw	%ax, 0xc(%rbp)
140089060: 0f b6 82 22 01 00 00        	movzbl	0x122(%rdx), %eax
140089067: 88 45 0f                    	movb	%al, 0xf(%rbp)
14008906a: 0f b6 82 23 01 00 00        	movzbl	0x123(%rdx), %eax
140089071: 88 45 09                    	movb	%al, 0x9(%rbp)
140089074: f3 0f 10 b2 24 01 00 00     	movss	0x124(%rdx), %xmm6
14008907c: 0f b7 82 24 01 00 00        	movzwl	0x124(%rdx), %eax
140089083: 66 89 45 0a                 	movw	%ax, 0xa(%rbp)
140089087: 48 8b 82 28 01 00 00        	movq	0x128(%rdx), %rax
14008908e: 48 89 45 e0                 	movq	%rax, -0x20(%rbp)
140089092: 0f b7 0a                    	movzwl	(%rdx), %ecx
140089095: 85 c9                       	testl	%ecx, %ecx
140089097: 0f 84 1c 02 00 00           	je	0x1400892b9 <.text+0x882b9>
14008909d: 83 f9 01                    	cmpl	$0x1, %ecx
1400890a0: 75 10                       	jne	0x1400890b2 <.text+0x880b2>
1400890a2: 0f b7 42 02                 	movzwl	0x2(%rdx), %eax
1400890a6: 48 3d 01 01 00 00           	cmpq	$0x101, %rax            # imm = 0x101
1400890ac: 0f 83 f3 05 00 00           	jae	0x1400896a5 <.text+0x886a5>
1400890b2: 89 4d fc                    	movl	%ecx, -0x4(%rbp)
1400890b5: 44 88 45 0e                 	movb	%r8b, 0xe(%rbp)
1400890b9: 4c 89 7d e8                 	movq	%r15, -0x18(%rbp)
1400890bd: 48 8d 82 08 01 00 00        	leaq	0x108(%rdx), %rax
1400890c4: 48 89 45 c8                 	movq	%rax, -0x38(%rbp)
1400890c8: 49 8d 86 b8 14 00 00        	leaq	0x14b8(%r14), %rax
1400890cf: 48 89 45 c0                 	movq	%rax, -0x40(%rbp)
1400890d3: 49 8d 86 28 05 00 00        	leaq	0x528(%r14), %rax
1400890da: 48 89 45 d0                 	movq	%rax, -0x30(%rbp)
1400890de: 49 8d 86 50 06 00 00        	leaq	0x650(%r14), %rax
1400890e5: 41 bb 04 00 00 00           	movl	$0x4, %r11d
1400890eb: 45 31 c9                    	xorl	%r9d, %r9d
1400890ee: b9 01 00 00 00              	movl	$0x1, %ecx
1400890f3: 31 ff                       	xorl	%edi, %edi
1400890f5: 4d 69 d1 30 01 00 00        	imulq	$0x130, %r9, %r10       # imm = 0x130
1400890fc: 49 01 c2                    	addq	%rax, %r10
1400890ff: 90                          	nop
140089100: 45 0f b7 ba d8 fe ff ff     	movzwl	-0x128(%r10), %r15d
140089108: 66 41 83 ff ff              	cmpw	$-0x1, %r15w
14008910d: 75 21                       	jne	0x140089130 <.text+0x88130>
14008910f: 49 ff c1                    	incq	%r9
140089112: 49 81 c2 30 01 00 00        	addq	$0x130, %r10            # imm = 0x130
140089119: 4d 39 cb                    	cmpq	%r9, %r11
14008911c: 75 e2                       	jne	0x140089100 <.text+0x88100>
14008911e: e9 a0 00 00 00              	jmp	0x1400891c3 <.text+0x881c3>
140089123: 66 66 66 66 2e 0f 1f 84 00 00 00 00 00      	nopw	%cs:(%rax,%rax)
140089130: 44 0f b7 5d 0a              	movzwl	0xa(%rbp), %r11d
140089135: 66 45 39 5a fc              	cmpw	%r11w, -0x4(%r10)
14008913a: 75 48                       	jne	0x140089184 <.text+0x88184>
14008913c: 44 8b 5d 00                 	movl	(%rbp), %r11d
140089140: 45 39 5a f0                 	cmpl	%r11d, -0x10(%r10)
140089144: 75 3e                       	jne	0x140089184 <.text+0x88184>
140089146: 44 8b 5d 04                 	movl	0x4(%rbp), %r11d
14008914a: 45 39 5a f4                 	cmpl	%r11d, -0xc(%r10)
14008914e: 75 34                       	jne	0x140089184 <.text+0x88184>
140089150: 44 0f b7 5d 0c              	movzwl	0xc(%rbp), %r11d
140089155: 66 45 39 5a f8              	cmpw	%r11w, -0x8(%r10)
14008915a: 75 28                       	jne	0x140089184 <.text+0x88184>
14008915c: 44 0f b6 5d 0f              	movzbl	0xf(%rbp), %r11d
140089161: 45 38 5a fa                 	cmpb	%r11b, -0x6(%r10)
140089165: 75 1d                       	jne	0x140089184 <.text+0x88184>
140089167: 4d 8b 5a e0                 	movq	-0x20(%r10), %r11
14008916b: 4d 31 e3                    	xorq	%r12, %r11
14008916e: 4c 89 e6                    	movq	%r12, %rsi
140089171: 4d 8b 62 e8                 	movq	-0x18(%r10), %r12
140089175: 4d 31 ec                    	xorq	%r13, %r12
140089178: 4d 09 dc                    	orq	%r11, %r12
14008917b: 49 89 f4                    	movq	%rsi, %r12
14008917e: 0f 84 6e 04 00 00           	je	0x1400895f2 <.text+0x885f2>
140089184: 4d 8b 12                    	movq	(%r10), %r10
140089187: 4d 39 c2                    	cmpq	%r8, %r10
14008918a: 41 0f 93 c3                 	setae	%r11b
14008918e: 41 20 fb                    	andb	%dil, %r11b
140089191: 4d 85 d2                    	testq	%r10, %r10
140089194: 48 0f 45 f9                 	cmovneq	%rcx, %rdi
140089198: 41 0f 94 c7                 	sete	%r15b
14008919c: 45 08 df                    	orb	%r11b, %r15b
14008919f: 49 0f 44 d9                 	cmoveq	%r9, %rbx
1400891a3: 4d 8d 49 01                 	leaq	0x1(%r9), %r9
1400891a7: 4d 0f 44 c2                 	cmoveq	%r10, %r8
1400891ab: 49 83 f9 05                 	cmpq	$0x5, %r9
1400891af: 41 bb 04 00 00 00           	movl	$0x4, %r11d
1400891b5: 4d 0f 43 d9                 	cmovaeq	%r9, %r11
1400891b9: 49 83 f9 03                 	cmpq	$0x3, %r9
1400891bd: 0f 86 32 ff ff ff           	jbe	0x1400890f5 <.text+0x880f5>
1400891c3: 4c 89 6d f0                 	movq	%r13, -0x10(%rbp)
1400891c7: 4d 8b be f0 09 00 00        	movq	0x9f0(%r14), %r15
1400891ce: 49 83 ff 04                 	cmpq	$0x4, %r15
1400891d2: 0f 85 48 01 00 00           	jne	0x140089320 <.text+0x88320>
1400891d8: 48 83 ff 01                 	cmpq	$0x1, %rdi
1400891dc: 4c 8b 6d f0                 	movq	-0x10(%rbp), %r13
1400891e0: 4c 8b 7d e8                 	movq	-0x18(%rbp), %r15
1400891e4: 44 0f b6 45 0e              	movzbl	0xe(%rbp), %r8d
1400891e9: 0f 85 ca 00 00 00           	jne	0x1400892b9 <.text+0x882b9>
1400891ef: 4c 69 c3 30 01 00 00        	imulq	$0x130, %rbx, %r8       # imm = 0x130
1400891f6: 49 8d 8e 28 05 00 00        	leaq	0x528(%r14), %rcx
1400891fd: 46 0f b7 0c 01              	movzwl	(%rcx,%r8), %r9d
140089202: 66 41 83 f9 ff              	cmpw	$-0x1, %r9w
140089207: 0f 84 b1 04 00 00           	je	0x1400896be <.text+0x886be>
14008920d: 48 89 d7                    	movq	%rdx, %rdi
140089210: 49 01 c8                    	addq	%rcx, %r8
140089213: 49 8b 40 08                 	movq	0x8(%r8), %rax
140089217: 41 0f 10 80 18 01 00 00     	movups	0x118(%r8), %xmm0
14008921f: 0f 29 45 b0                 	movaps	%xmm0, -0x50(%rbp)
140089223: 41 0f 10 80 08 01 00 00     	movups	0x108(%r8), %xmm0
14008922b: 0f 29 45 a0                 	movaps	%xmm0, -0x60(%rbp)
14008922f: 66 41 83 f9 02              	cmpw	$0x2, %r9w
140089234: 75 60                       	jne	0x140089296 <.text+0x88296>
140089236: 48 83 f8 01                 	cmpq	$0x1, %rax
14008923a: 77 5a                       	ja	0x140089296 <.text+0x88296>
14008923c: 41 80 bc 06 40 1e 00 00 01  	cmpb	$0x1, 0x1e40(%r14,%rax)
140089245: 75 4f                       	jne	0x140089296 <.text+0x88296>
140089247: 41 80 bc 06 42 1e 00 00 00  	cmpb	$0x0, 0x1e42(%r14,%rax)
140089250: 75 44                       	jne	0x140089296 <.text+0x88296>
140089252: 41 c6 84 06 40 1e 00 00 00  	movb	$0x0, 0x1e40(%r14,%rax)
14008925b: 49 ff 8e 38 1e 00 00        	decq	0x1e38(%r14)
140089262: 49 c7 84 c6 b8 1d 00 00 00 00 00 00 	movq	$0x0, 0x1db8(%r14,%rax,8)
14008926e: 48 8d 14 c0                 	leaq	(%rax,%rax,8), %rdx
140089272: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
140089276: 48 01 c2                    	addq	%rax, %rdx
140089279: 4d 8d 86 b8 14 00 00        	leaq	0x14b8(%r14), %r8
140089280: 41 c6 84 10 5a 09 00 00 02  	movb	$0x2, 0x95a(%r8,%rdx)
140089289: 48 8d 04 40                 	leaq	(%rax,%rax,2), %rax
14008928d: 41 c6 84 c0 1d 09 00 00 02  	movb	$0x2, 0x91d(%r8,%rax,8)
140089296: 48 8d 55 a0                 	leaq	-0x60(%rbp), %rdx
14008929a: e8 71 c6 18 00              	callq	0x140215910 <.text+0x214910>
14008929f: 49 8b 9e f0 09 00 00        	movq	0x9f0(%r14), %rbx
1400892a6: 48 83 fb 04                 	cmpq	$0x4, %rbx
1400892aa: 0f 85 48 01 00 00           	jne	0x1400893f8 <.text+0x883f8>
1400892b0: 4c 8b 6d f0                 	movq	-0x10(%rbp), %r13
1400892b4: 44 0f b6 45 0e              	movzbl	0xe(%rbp), %r8d
1400892b9: 41 fe c8                    	decb	%r8b
1400892bc: 41 80 f8 07                 	cmpb	$0x7, %r8b
1400892c0: 0f 92 c0                    	setb	%al
1400892c3: b2 4d                       	movb	$0x4d, %dl
1400892c5: 44 89 c1                    	movl	%r8d, %ecx
1400892c8: d2 ea                       	shrb	%cl, %dl
1400892ca: 84 d0                       	testb	%dl, %al
1400892cc: 0f 85 07 01 00 00           	jne	0x1400893d9 <.text+0x883d9>
1400892d2: 41 0f b6 47 22              	movzbl	0x22(%r15), %eax
1400892d7: 3c 02                       	cmpb	$0x2, %al
1400892d9: 0f 85 a2 00 00 00           	jne	0x140089381 <.text+0x88381>
1400892df: 48 8b 45 e0                 	movq	-0x20(%rbp), %rax
1400892e3: 49 89 07                    	movq	%rax, (%r15)
1400892e6: 4d 89 67 08                 	movq	%r12, 0x8(%r15)
1400892ea: 4d 89 6f 10                 	movq	%r13, 0x10(%r15)
1400892ee: 8b 45 00                    	movl	(%rbp), %eax
1400892f1: 41 89 47 18                 	movl	%eax, 0x18(%r15)
1400892f5: 8b 45 04                    	movl	0x4(%rbp), %eax
1400892f8: 41 89 47 1c                 	movl	%eax, 0x1c(%r15)
1400892fc: 0f b7 45 0c                 	movzwl	0xc(%rbp), %eax
140089300: 66 41 89 47 20              	movw	%ax, 0x20(%r15)
140089305: 0f b6 45 0f                 	movzbl	0xf(%rbp), %eax
140089309: 41 88 47 22                 	movb	%al, 0x22(%r15)
14008930d: 0f b6 45 09                 	movzbl	0x9(%rbp), %eax
140089311: 41 88 47 23                 	movb	%al, 0x23(%r15)
140089315: f3 41 0f 11 77 24           	movss	%xmm6, 0x24(%r15)
14008931b: e9 b9 00 00 00              	jmp	0x1400893d9 <.text+0x883d9>
140089320: 4d 8b ae e8 09 00 00        	movq	0x9e8(%r14), %r13
140089327: 49 83 fd 03                 	cmpq	$0x3, %r13
14008932b: 0f 87 a7 03 00 00           	ja	0x1400896d8 <.text+0x886d8>
140089331: 4c 89 e6                    	movq	%r12, %rsi
140089334: 4d 8d a6 f8 09 00 00        	leaq	0x9f8(%r14), %r12
14008933b: 43 80 3c 2c 00              	cmpb	$0x0, (%r12,%r13)
140089340: 0f 84 ad 00 00 00           	je	0x1400893f3 <.text+0x883f3>
140089346: 48 89 55 d8                 	movq	%rdx, -0x28(%rbp)
14008934a: 4b 8d 0c 2c                 	leaq	(%r12,%r13), %rcx
14008934e: ba 04 00 00 00              	movl	$0x4, %edx
140089353: 4c 29 ea                    	subq	%r13, %rdx
140089356: e8 a5 6b f8 ff              	callq	0x14000ff00 <.text+0xef00>
14008935b: 48 83 f8 01                 	cmpq	$0x1, %rax
14008935f: 0f 85 e1 00 00 00           	jne	0x140089446 <.text+0x88446>
140089365: 49 01 d5                    	addq	%rdx, %r13
140089368: b8 01 00 00 00              	movl	$0x1, %eax
14008936d: 48 8b 55 d8                 	movq	-0x28(%rbp), %rdx
140089371: 49 89 f4                    	movq	%rsi, %r12
140089374: a8 01                       	testb	$0x1, %al
140089376: 0f 84 5c fe ff ff           	je	0x1400891d8 <.text+0x881d8>
14008937c: e9 e2 00 00 00              	jmp	0x140089463 <.text+0x88463>
140089381: 0f b7 4d 0a                 	movzwl	0xa(%rbp), %ecx
140089385: 66 41 39 4f 24              	cmpw	%cx, 0x24(%r15)
14008938a: 0f 85 4f ff ff ff           	jne	0x1400892df <.text+0x882df>
140089390: 8b 4d 00                    	movl	(%rbp), %ecx
140089393: 41 39 4f 18                 	cmpl	%ecx, 0x18(%r15)
140089397: 0f 85 42 ff ff ff           	jne	0x1400892df <.text+0x882df>
14008939d: 8b 4d 04                    	movl	0x4(%rbp), %ecx
1400893a0: 41 39 4f 1c                 	cmpl	%ecx, 0x1c(%r15)
1400893a4: 0f 85 35 ff ff ff           	jne	0x1400892df <.text+0x882df>
1400893aa: 0f b7 4d 0c                 	movzwl	0xc(%rbp), %ecx
1400893ae: 66 41 39 4f 20              	cmpw	%cx, 0x20(%r15)
1400893b3: 0f 85 26 ff ff ff           	jne	0x1400892df <.text+0x882df>
1400893b9: 3a 45 0f                    	cmpb	0xf(%rbp), %al
1400893bc: 0f 85 1d ff ff ff           	jne	0x1400892df <.text+0x882df>
1400893c2: 49 8b 47 08                 	movq	0x8(%r15), %rax
1400893c6: 4c 31 e0                    	xorq	%r12, %rax
1400893c9: 49 8b 4f 10                 	movq	0x10(%r15), %rcx
1400893cd: 4c 31 e9                    	xorq	%r13, %rcx
1400893d0: 48 09 c1                    	orq	%rax, %rcx
1400893d3: 0f 85 06 ff ff ff           	jne	0x1400892df <.text+0x882df>
1400893d9: 31 c0                       	xorl	%eax, %eax
1400893db: 0f 28 75 10                 	movaps	0x10(%rbp), %xmm6
1400893df: 48 81 c4 a8 00 00 00        	addq	$0xa8, %rsp
1400893e6: 5b                          	popq	%rbx
1400893e7: 5f                          	popq	%rdi
1400893e8: 5e                          	popq	%rsi
1400893e9: 41 5c                       	popq	%r12
1400893eb: 41 5d                       	popq	%r13
1400893ed: 41 5e                       	popq	%r14
1400893ef: 41 5f                       	popq	%r15
1400893f1: 5d                          	popq	%rbp
1400893f2: c3                          	retq
1400893f3: 49 89 f4                    	movq	%rsi, %r12
1400893f6: eb 75                       	jmp	0x14008946d <.text+0x8846d>
1400893f8: 4d 8b ae e8 09 00 00        	movq	0x9e8(%r14), %r13
1400893ff: 49 83 fd 03                 	cmpq	$0x3, %r13
140089403: 0f 87 cf 02 00 00           	ja	0x1400896d8 <.text+0x886d8>
140089409: 4c 89 e6                    	movq	%r12, %rsi
14008940c: 4d 8d a6 f8 09 00 00        	leaq	0x9f8(%r14), %r12
140089413: 43 80 3c 2c 00              	cmpb	$0x0, (%r12,%r13)
140089418: 0f 84 ca 00 00 00           	je	0x1400894e8 <.text+0x884e8>
14008941e: 4b 8d 0c 2c                 	leaq	(%r12,%r13), %rcx
140089422: ba 04 00 00 00              	movl	$0x4, %edx
140089427: 4c 29 ea                    	subq	%r13, %rdx
14008942a: e8 d1 6a f8 ff              	callq	0x14000ff00 <.text+0xef00>
14008942f: 48 83 f8 01                 	cmpq	$0x1, %rax
140089433: 0f 85 b7 00 00 00           	jne	0x1400894f0 <.text+0x884f0>
140089439: 49 01 d5                    	addq	%rdx, %r13
14008943c: b8 01 00 00 00              	movl	$0x1, %eax
140089441: e9 b8 00 00 00              	jmp	0x1400894fe <.text+0x884fe>
140089446: 4c 89 e1                    	movq	%r12, %rcx
140089449: 4c 89 ea                    	movq	%r13, %rdx
14008944c: e8 af 6a f8 ff              	callq	0x14000ff00 <.text+0xef00>
140089451: 49 89 d5                    	movq	%rdx, %r13
140089454: 48 8b 55 d8                 	movq	-0x28(%rbp), %rdx
140089458: 49 89 f4                    	movq	%rsi, %r12
14008945b: a8 01                       	testb	$0x1, %al
14008945d: 0f 84 75 fd ff ff           	je	0x1400891d8 <.text+0x881d8>
140089463: 49 83 fd 04                 	cmpq	$0x4, %r13
140089467: 0f 83 81 02 00 00           	jae	0x1400896ee <.text+0x886ee>
14008946d: 49 8d 8e 28 05 00 00        	leaq	0x528(%r14), %rcx
140089474: 44 8b 4d fc                 	movl	-0x4(%rbp), %r9d
140089478: 49 8d 45 01                 	leaq	0x1(%r13), %rax
14008947c: 45 31 c0                    	xorl	%r8d, %r8d
14008947f: 48 83 f8 04                 	cmpq	$0x4, %rax
140089483: 4c 0f 45 c0                 	cmovneq	%rax, %r8
140089487: 43 c6 84 2e f8 09 00 00 01  	movb	$0x1, 0x9f8(%r14,%r13)
140089490: 4d 89 86 e8 09 00 00        	movq	%r8, 0x9e8(%r14)
140089497: 49 ff c7                    	incq	%r15
14008949a: 4d 89 be f0 09 00 00        	movq	%r15, 0x9f0(%r14)
1400894a1: 4c 8b 7d e8                 	movq	-0x18(%rbp), %r15
1400894a5: 49 69 c5 30 01 00 00        	imulq	$0x130, %r13, %rax      # imm = 0x130
1400894ac: 48 01 c1                    	addq	%rax, %rcx
1400894af: 45 85 c9                    	testl	%r9d, %r9d
1400894b2: 0f 84 a1 00 00 00           	je	0x140089559 <.text+0x88559>
1400894b8: 41 83 f9 01                 	cmpl	$0x1, %r9d
1400894bc: 4c 8b 6d f0                 	movq	-0x10(%rbp), %r13
1400894c0: 75 10                       	jne	0x1400894d2 <.text+0x884d2>
1400894c2: 41 b8 30 01 00 00           	movl	$0x130, %r8d            # imm = 0x130
1400894c8: e8 63 6e 1c 00              	callq	0x140250330 <.text+0x24f330>
1400894cd: e9 b4 00 00 00              	jmp	0x140089586 <.text+0x88586>
1400894d2: 4c 8b 4a 08                 	movq	0x8(%rdx), %r9
1400894d6: 48 8b 55 c8                 	movq	-0x38(%rbp), %rdx
1400894da: 4c 8b 45 e0                 	movq	-0x20(%rbp), %r8
1400894de: e8 cd 18 f8 ff              	callq	0x14000adb0 <.text+0x9db0>
1400894e3: e9 9e 00 00 00              	jmp	0x140089586 <.text+0x88586>
1400894e8: 48 89 fa                    	movq	%rdi, %rdx
1400894eb: 49 89 f4                    	movq	%rsi, %r12
1400894ee: eb 26                       	jmp	0x140089516 <.text+0x88516>
1400894f0: 4c 89 e1                    	movq	%r12, %rcx
1400894f3: 4c 89 ea                    	movq	%r13, %rdx
1400894f6: e8 05 6a f8 ff              	callq	0x14000ff00 <.text+0xef00>
1400894fb: 49 89 d5                    	movq	%rdx, %r13
1400894fe: 49 89 f4                    	movq	%rsi, %r12
140089501: a8 01                       	testb	$0x1, %al
140089503: 0f 84 a7 fd ff ff           	je	0x1400892b0 <.text+0x882b0>
140089509: 49 83 fd 04                 	cmpq	$0x4, %r13
14008950d: 0f 83 db 01 00 00           	jae	0x1400896ee <.text+0x886ee>
140089513: 48 89 fa                    	movq	%rdi, %rdx
140089516: 49 8d 45 01                 	leaq	0x1(%r13), %rax
14008951a: 31 c9                       	xorl	%ecx, %ecx
14008951c: 48 83 f8 04                 	cmpq	$0x4, %rax
140089520: 48 0f 45 c8                 	cmovneq	%rax, %rcx
140089524: 43 c6 84 2e f8 09 00 00 01  	movb	$0x1, 0x9f8(%r14,%r13)
14008952d: 49 89 8e e8 09 00 00        	movq	%rcx, 0x9e8(%r14)
140089534: 48 ff c3                    	incq	%rbx
140089537: 49 89 9e f0 09 00 00        	movq	%rbx, 0x9f0(%r14)
14008953e: 48 8b 4d d0                 	movq	-0x30(%rbp), %rcx
140089542: 44 8b 4d fc                 	movl	-0x4(%rbp), %r9d
140089546: 49 69 c5 30 01 00 00        	imulq	$0x130, %r13, %rax      # imm = 0x130
14008954d: 48 01 c1                    	addq	%rax, %rcx
140089550: 45 85 c9                    	testl	%r9d, %r9d
140089553: 0f 85 5f ff ff ff           	jne	0x1400894b8 <.text+0x884b8>
140089559: 66 c7 01 00 00              	movw	$0x0, (%rcx)
14008955e: 48 8b 45 c8                 	movq	-0x38(%rbp), %rax
140089562: 0f 10 00                    	movups	(%rax), %xmm0
140089565: 0f 10 48 10                 	movups	0x10(%rax), %xmm1
140089569: 0f 11 81 08 01 00 00        	movups	%xmm0, 0x108(%rcx)
140089570: 0f 11 89 18 01 00 00        	movups	%xmm1, 0x118(%rcx)
140089577: 48 8b 45 e0                 	movq	-0x20(%rbp), %rax
14008957b: 48 89 81 28 01 00 00        	movq	%rax, 0x128(%rcx)
140089582: 4c 8b 6d f0                 	movq	-0x10(%rbp), %r13
140089586: 41 0f b6 4f 22              	movzbl	0x22(%r15), %ecx
14008958b: b0 01                       	movb	$0x1, %al
14008958d: 80 f9 02                    	cmpb	$0x2, %cl
140089590: 0f 84 45 fe ff ff           	je	0x1400893db <.text+0x883db>
140089596: 0f b7 55 0a                 	movzwl	0xa(%rbp), %edx
14008959a: 66 41 39 57 24              	cmpw	%dx, 0x24(%r15)
14008959f: 0f 85 36 fe ff ff           	jne	0x1400893db <.text+0x883db>
1400895a5: 8b 55 00                    	movl	(%rbp), %edx
1400895a8: 41 39 57 18                 	cmpl	%edx, 0x18(%r15)
1400895ac: 0f 85 29 fe ff ff           	jne	0x1400893db <.text+0x883db>
1400895b2: 8b 55 04                    	movl	0x4(%rbp), %edx
1400895b5: 41 39 57 1c                 	cmpl	%edx, 0x1c(%r15)
1400895b9: 0f 85 1c fe ff ff           	jne	0x1400893db <.text+0x883db>
1400895bf: 0f b7 55 0c                 	movzwl	0xc(%rbp), %edx
1400895c3: 66 41 39 57 20              	cmpw	%dx, 0x20(%r15)
1400895c8: 0f 85 0d fe ff ff           	jne	0x1400893db <.text+0x883db>
1400895ce: 3a 4d 0f                    	cmpb	0xf(%rbp), %cl
1400895d1: 0f 85 04 fe ff ff           	jne	0x1400893db <.text+0x883db>
1400895d7: 4d 33 67 08                 	xorq	0x8(%r15), %r12
1400895db: 4d 33 6f 10                 	xorq	0x10(%r15), %r13
1400895df: 4d 09 e5                    	orq	%r12, %r13
1400895e2: 0f 85 f3 fd ff ff           	jne	0x1400893db <.text+0x883db>
1400895e8: 41 c6 47 22 02              	movb	$0x2, 0x22(%r15)
1400895ed: e9 e9 fd ff ff              	jmp	0x1400893db <.text+0x883db>
1400895f2: 49 89 d4                    	movq	%rdx, %r12
1400895f5: 49 8b 82 e0 fe ff ff        	movq	-0x120(%r10), %rax
1400895fc: 41 0f 10 42 f0              	movups	-0x10(%r10), %xmm0
140089601: 0f 29 45 b0                 	movaps	%xmm0, -0x50(%rbp)
140089605: 41 0f 10 42 e0              	movups	-0x20(%r10), %xmm0
14008960a: 0f 29 45 a0                 	movaps	%xmm0, -0x60(%rbp)
14008960e: 66 41 83 ff 02              	cmpw	$0x2, %r15w
140089613: 75 5b                       	jne	0x140089670 <.text+0x88670>
140089615: 48 83 f8 01                 	cmpq	$0x1, %rax
140089619: 77 55                       	ja	0x140089670 <.text+0x88670>
14008961b: 41 80 bc 06 40 1e 00 00 01  	cmpb	$0x1, 0x1e40(%r14,%rax)
140089624: 75 4a                       	jne	0x140089670 <.text+0x88670>
140089626: 41 80 bc 06 42 1e 00 00 00  	cmpb	$0x0, 0x1e42(%r14,%rax)
14008962f: 75 3f                       	jne	0x140089670 <.text+0x88670>
140089631: 41 c6 84 06 40 1e 00 00 00  	movb	$0x0, 0x1e40(%r14,%rax)
14008963a: 49 ff 8e 38 1e 00 00        	decq	0x1e38(%r14)
140089641: 49 c7 84 c6 b8 1d 00 00 00 00 00 00 	movq	$0x0, 0x1db8(%r14,%rax,8)
14008964d: 48 8d 0c c0                 	leaq	(%rax,%rax,8), %rcx
140089651: 48 8d 0c 49                 	leaq	(%rcx,%rcx,2), %rcx
140089655: 48 01 c1                    	addq	%rax, %rcx
140089658: 48 8b 55 c0                 	movq	-0x40(%rbp), %rdx
14008965c: c6 84 0a 5a 09 00 00 02     	movb	$0x2, 0x95a(%rdx,%rcx)
140089664: 48 8d 04 40                 	leaq	(%rax,%rax,2), %rax
140089668: c6 84 c2 1d 09 00 00 02     	movb	$0x2, 0x91d(%rdx,%rax,8)
140089670: 48 8d 55 a0                 	leaq	-0x60(%rbp), %rdx
140089674: 48 8b 7d d0                 	movq	-0x30(%rbp), %rdi
140089678: 48 89 f9                    	movq	%rdi, %rcx
14008967b: e8 90 c2 18 00              	callq	0x140215910 <.text+0x214910>
140089680: 48 89 f9                    	movq	%rdi, %rcx
140089683: 4c 89 e2                    	movq	%r12, %rdx
140089686: e8 85 bf 18 00              	callq	0x140215610 <.text+0x214610>
14008968b: 48 85 c0                    	testq	%rax, %rax
14008968e: 49 89 f4                    	movq	%rsi, %r12
140089691: 4c 8b 7d e8                 	movq	-0x18(%rbp), %r15
140089695: 44 0f b6 45 0e              	movzbl	0xe(%rbp), %r8d
14008969a: 0f 85 e6 fe ff ff           	jne	0x140089586 <.text+0x88586>
1400896a0: e9 14 fc ff ff              	jmp	0x1400892b9 <.text+0x882b9>
1400896a5: 4c 8d 0d 0c 5d 1d 00        	leaq	0x1d5d0c(%rip), %r9     # 0x14025f3b8
1400896ac: 41 b8 00 01 00 00           	movl	$0x100, %r8d            # imm = 0x100
1400896b2: 31 c9                       	xorl	%ecx, %ecx
1400896b4: 48 89 c2                    	movq	%rax, %rdx
1400896b7: e8 c4 76 1c 00              	callq	0x140250d80 <.text+0x24fd80>
1400896bc: 0f 0b                       	ud2
1400896be: 48 8d 0d 8b 02 1e 00        	leaq	0x1e028b(%rip), %rcx    # 0x140269950
1400896c5: 4c 8d 05 9c 02 1e 00        	leaq	0x1e029c(%rip), %r8     # 0x140269968
1400896cc: ba 15 00 00 00              	movl	$0x15, %edx
1400896d1: e8 ba 73 1c 00              	callq	0x140250a90 <.text+0x24fa90>
1400896d6: 0f 0b                       	ud2
1400896d8: 4c 8d 05 11 63 1d 00        	leaq	0x1d6311(%rip), %r8     # 0x14025f9f0
1400896df: ba 04 00 00 00              	movl	$0x4, %edx
1400896e4: 4c 89 e9                    	movq	%r13, %rcx
1400896e7: e8 87 74 1c 00              	callq	0x140250b73 <.text+0x24fb73>
1400896ec: 0f 0b                       	ud2
1400896ee: 4c 8d 05 13 63 1d 00        	leaq	0x1d6313(%rip), %r8     # 0x14025fa08
1400896f5: ba 04 00 00 00              	movl	$0x4, %edx
1400896fa: 4c 89 e9                    	movq	%r13, %rcx
1400896fd: e8 71 74 1c 00              	callq	0x140250b73 <.text+0x24fb73>
140089702: 0f 0b                       	ud2

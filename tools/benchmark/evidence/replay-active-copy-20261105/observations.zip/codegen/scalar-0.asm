
D:/CoapticCurrent/replay-active-copy-20261105/scalar-pin/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14000adb0: 55                          	pushq	%rbp
14000adb1: 48 89 e5                    	movq	%rsp, %rbp
14000adb4: 66 c7 01 02 00              	movw	$0x2, (%rcx)
14000adb9: 4c 89 49 08                 	movq	%r9, 0x8(%rcx)
14000adbd: 0f 10 02                    	movups	(%rdx), %xmm0
14000adc0: 0f 10 4a 10                 	movups	0x10(%rdx), %xmm1
14000adc4: 0f 11 81 08 01 00 00        	movups	%xmm0, 0x108(%rcx)
14000adcb: 0f 11 89 18 01 00 00        	movups	%xmm1, 0x118(%rcx)
14000add2: 4c 89 81 28 01 00 00        	movq	%r8, 0x128(%rcx)
14000add9: 5d                          	popq	%rbp
14000adda: c3                          	retq

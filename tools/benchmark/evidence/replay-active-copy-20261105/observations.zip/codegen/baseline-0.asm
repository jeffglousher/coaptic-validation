
D:/CoapticCurrent/oscore-packet-staging-20261104/option-reuse/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140089050: 55                          	pushq	%rbp
140089051: 41 57                       	pushq	%r15
140089053: 41 56                       	pushq	%r14
140089055: 41 55                       	pushq	%r13
140089057: 41 54                       	pushq	%r12
140089059: 56                          	pushq	%rsi
14008905a: 57                          	pushq	%rdi
14008905b: 53                          	pushq	%rbx
14008905c: 48 81 ec a8 00 00 00        	subq	$0xa8, %rsp
140089063: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
14008906b: 0f 29 75 10                 	movaps	%xmm6, 0x10(%rbp)
14008906f: 0f b7 82 38 01 00 00        	movzwl	0x138(%rdx), %eax
140089076: 48 3d 01 01 00 00           	cmpq	$0x101, %rax            # imm = 0x101
14008907c: 0f 83 96 05 00 00           	jae	0x140089618 <.text+0x88618>
140089082: 4c 89 ce                    	movq	%r9, %rsi
140089085: 4c 8b 7a 10                 	movq	0x10(%rdx), %r15
140089089: 4c 8b 62 18                 	movq	0x18(%rdx), %r12
14008908d: 44 8b 5a 20                 	movl	0x20(%rdx), %r11d
140089091: 44 8b 52 24                 	movl	0x24(%rdx), %r10d
140089095: 44 0f b7 4a 28              	movzwl	0x28(%rdx), %r9d
14008909a: 0f b6 7a 2a                 	movzbl	0x2a(%rdx), %edi
14008909e: 44 0f b6 6a 2b              	movzbl	0x2b(%rdx), %r13d
1400890a3: f3 0f 10 72 2c              	movss	0x2c(%rdx), %xmm6
1400890a8: 0f b7 5a 2c                 	movzwl	0x2c(%rdx), %ebx
1400890ac: 66 89 5d 0a                 	movw	%bx, 0xa(%rbp)
1400890b0: 48 8b 5a 30                 	movq	0x30(%rdx), %rbx
1400890b4: 66 85 c0                    	testw	%ax, %ax
1400890b7: 75 09                       	jne	0x1400890c2 <.text+0x880c2>
1400890b9: 80 3a 00                    	cmpb	$0x0, (%rdx)
1400890bc: 0f 84 28 02 00 00           	je	0x1400892ea <.text+0x882ea>
1400890c2: 48 89 5d d8                 	movq	%rbx, -0x28(%rbp)
1400890c6: 44 88 6d 0e                 	movb	%r13b, 0xe(%rbp)
1400890ca: 44 89 5d 00                 	movl	%r11d, (%rbp)
1400890ce: 44 89 55 04                 	movl	%r10d, 0x4(%rbp)
1400890d2: 66 44 89 4d 0c              	movw	%r9w, 0xc(%rbp)
1400890d7: 40 88 7d 0f                 	movb	%dil, 0xf(%rbp)
1400890db: 4c 89 7d e8                 	movq	%r15, -0x18(%rbp)
1400890df: 48 8d 81 f8 14 00 00        	leaq	0x14f8(%rcx), %rax
1400890e6: 48 89 45 c8                 	movq	%rax, -0x38(%rbp)
1400890ea: 48 8d 81 10 05 00 00        	leaq	0x510(%rcx), %rax
1400890f1: 48 89 45 e0                 	movq	%rax, -0x20(%rbp)
1400890f5: 48 8d 41 30                 	leaq	0x30(%rcx), %rax
1400890f9: 45 31 ff                    	xorl	%r15d, %r15d
1400890fc: 41 b9 01 00 00 00           	movl	$0x1, %r9d
140089102: 31 ff                       	xorl	%edi, %edi
140089104: 4b 8d 1c bf                 	leaq	(%r15,%r15,4), %rbx
140089108: 48 c1 e3 06                 	shlq	$0x6, %rbx
14008910c: 48 01 c3                    	addq	%rax, %rbx
14008910f: 4d 89 fb                    	movq	%r15, %r11
140089112: eb 20                       	jmp	0x140089134 <.text+0x88134>
140089114: 66 66 66 2e 0f 1f 84 00 00 00 00 00 	nopw	%cs:(%rax,%rax)
140089120: 49 ff c3                    	incq	%r11
140089123: 48 81 c3 40 01 00 00        	addq	$0x140, %rbx            # imm = 0x140
14008912a: 49 83 fb 04                 	cmpq	$0x4, %r11
14008912e: 0f 84 9e 00 00 00           	je	0x1400891d2 <.text+0x881d2>
140089134: 42 80 bc 19 10 05 00 00 00  	cmpb	$0x0, 0x510(%rcx,%r11)
14008913d: 74 e1                       	je	0x140089120 <.text+0x88120>
14008913f: 4c 8b 6b d0                 	movq	-0x30(%rbx), %r13
140089143: 49 83 fd 02                 	cmpq	$0x2, %r13
140089147: 74 d7                       	je	0x140089120 <.text+0x88120>
140089149: 4c 89 65 f0                 	movq	%r12, -0x10(%rbp)
14008914d: 44 0f b7 7d 0a              	movzwl	0xa(%rbp), %r15d
140089152: 66 44 39 7b fc              	cmpw	%r15w, -0x4(%rbx)
140089157: 75 44                       	jne	0x14008919d <.text+0x8819d>
140089159: 44 8b 7d 00                 	movl	(%rbp), %r15d
14008915d: 44 39 7b f0                 	cmpl	%r15d, -0x10(%rbx)
140089161: 75 3a                       	jne	0x14008919d <.text+0x8819d>
140089163: 44 8b 7d 04                 	movl	0x4(%rbp), %r15d
140089167: 44 39 7b f4                 	cmpl	%r15d, -0xc(%rbx)
14008916b: 75 30                       	jne	0x14008919d <.text+0x8819d>
14008916d: 44 0f b7 7d 0c              	movzwl	0xc(%rbp), %r15d
140089172: 66 44 39 7b f8              	cmpw	%r15w, -0x8(%rbx)
140089177: 75 24                       	jne	0x14008919d <.text+0x8819d>
140089179: 44 0f b6 7d 0f              	movzbl	0xf(%rbp), %r15d
14008917e: 44 38 7b fa                 	cmpb	%r15b, -0x6(%rbx)
140089182: 75 19                       	jne	0x14008919d <.text+0x8819d>
140089184: 4c 8b 7b e0                 	movq	-0x20(%rbx), %r15
140089188: 4c 33 7d e8                 	xorq	-0x18(%rbp), %r15
14008918c: 4c 8b 63 e8                 	movq	-0x18(%rbx), %r12
140089190: 4c 33 65 f0                 	xorq	-0x10(%rbp), %r12
140089194: 4d 09 fc                    	orq	%r15, %r12
140089197: 0f 84 b2 03 00 00           	je	0x14008954f <.text+0x8854f>
14008919d: 48 8b 1b                    	movq	(%rbx), %rbx
1400891a0: 4c 39 d3                    	cmpq	%r10, %rbx
1400891a3: 41 0f 93 c7                 	setae	%r15b
1400891a7: 41 20 ff                    	andb	%dil, %r15b
1400891aa: 48 85 db                    	testq	%rbx, %rbx
1400891ad: 49 0f 45 f9                 	cmovneq	%r9, %rdi
1400891b1: 41 0f 94 c4                 	sete	%r12b
1400891b5: 45 08 fc                    	orb	%r15b, %r12b
1400891b8: 4d 0f 44 f3                 	cmoveq	%r11, %r14
1400891bc: 4d 8d 7b 01                 	leaq	0x1(%r11), %r15
1400891c0: 4c 0f 44 d3                 	cmoveq	%rbx, %r10
1400891c4: 49 83 fb 03                 	cmpq	$0x3, %r11
1400891c8: 4c 8b 65 f0                 	movq	-0x10(%rbp), %r12
1400891cc: 0f 82 32 ff ff ff           	jb	0x140089104 <.text+0x88104>
1400891d2: 4c 8b a9 08 05 00 00        	movq	0x508(%rcx), %r13
1400891d9: 49 83 fd 04                 	cmpq	$0x4, %r13
1400891dd: 4c 8b 7d e8                 	movq	-0x18(%rbp), %r15
1400891e1: 0f 85 52 01 00 00           	jne	0x140089339 <.text+0x88339>
1400891e7: 48 83 ff 01                 	cmpq	$0x1, %rdi
1400891eb: 0f b6 7d 0f                 	movzbl	0xf(%rbp), %edi
1400891ef: 44 0f b7 4d 0c              	movzwl	0xc(%rbp), %r9d
1400891f4: 44 8b 55 04                 	movl	0x4(%rbp), %r10d
1400891f8: 44 8b 5d 00                 	movl	(%rbp), %r11d
1400891fc: 44 0f b6 6d 0e              	movzbl	0xe(%rbp), %r13d
140089201: 48 8b 5d d8                 	movq	-0x28(%rbp), %rbx
140089205: 0f 85 df 00 00 00           	jne	0x1400892ea <.text+0x882ea>
14008920b: 48 8b 45 e0                 	movq	-0x20(%rbp), %rax
14008920f: 42 80 3c 30 01              	cmpb	$0x1, (%rax,%r14)
140089214: 0f 85 17 04 00 00           	jne	0x140089631 <.text+0x88631>
14008921a: 4f 8d 14 b6                 	leaq	(%r14,%r14,4), %r10
14008921e: 49 c1 e2 06                 	shlq	$0x6, %r10
140089222: 4e 8b 0c 11                 	movq	(%rcx,%r10), %r9
140089226: 49 83 f9 02                 	cmpq	$0x2, %r9
14008922a: 0f 84 01 04 00 00           	je	0x140089631 <.text+0x88631>
140089230: 44 89 c7                    	movl	%r8d, %edi
140089233: 48 89 55 f8                 	movq	%rdx, -0x8(%rbp)
140089237: 49 01 ca                    	addq	%rcx, %r10
14008923a: 49 8b 42 08                 	movq	0x8(%r10), %rax
14008923e: 41 0f 10 42 20              	movups	0x20(%r10), %xmm0
140089243: 0f 29 45 b0                 	movaps	%xmm0, -0x50(%rbp)
140089247: 41 0f 10 42 10              	movups	0x10(%r10), %xmm0
14008924c: 0f 29 45 a0                 	movaps	%xmm0, -0x60(%rbp)
140089250: 41 83 f9 01                 	cmpl	$0x1, %r9d
140089254: 75 5a                       	jne	0x1400892b0 <.text+0x882b0>
140089256: 48 83 f8 01                 	cmpq	$0x1, %rax
14008925a: 77 54                       	ja	0x1400892b0 <.text+0x882b0>
14008925c: 80 bc 01 80 1e 00 00 01     	cmpb	$0x1, 0x1e80(%rcx,%rax)
140089264: 75 4a                       	jne	0x1400892b0 <.text+0x882b0>
140089266: 80 bc 01 82 1e 00 00 00     	cmpb	$0x0, 0x1e82(%rcx,%rax)
14008926e: 75 40                       	jne	0x1400892b0 <.text+0x882b0>
140089270: c6 84 01 80 1e 00 00 00     	movb	$0x0, 0x1e80(%rcx,%rax)
140089278: 48 ff 89 78 1e 00 00        	decq	0x1e78(%rcx)
14008927f: 48 c7 84 c1 f8 1d 00 00 00 00 00 00 	movq	$0x0, 0x1df8(%rcx,%rax,8)
14008928b: 48 8d 14 c0                 	leaq	(%rax,%rax,8), %rdx
14008928f: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
140089293: 48 01 c2                    	addq	%rax, %rdx
140089296: 4c 8b 45 c8                 	movq	-0x38(%rbp), %r8
14008929a: 41 c6 84 10 5a 09 00 00 02  	movb	$0x2, 0x95a(%r8,%rdx)
1400892a3: 48 8d 04 40                 	leaq	(%rax,%rax,2), %rax
1400892a7: 41 c6 84 c0 1d 09 00 00 02  	movb	$0x2, 0x91d(%r8,%rax,8)
1400892b0: 48 8d 55 a0                 	leaq	-0x60(%rbp), %rdx
1400892b4: 49 89 ce                    	movq	%rcx, %r14
1400892b7: e8 04 d0 18 00              	callq	0x1402162c0 <.text+0x2152c0>
1400892bc: 4d 8b ae 08 05 00 00        	movq	0x508(%r14), %r13
1400892c3: 49 83 fd 04                 	cmpq	$0x4, %r13
1400892c7: 41 89 f8                    	movl	%edi, %r8d
1400892ca: 0f 85 2c 01 00 00           	jne	0x1400893fc <.text+0x883fc>
1400892d0: 0f b6 7d 0f                 	movzbl	0xf(%rbp), %edi
1400892d4: 44 0f b7 4d 0c              	movzwl	0xc(%rbp), %r9d
1400892d9: 44 8b 55 04                 	movl	0x4(%rbp), %r10d
1400892dd: 44 8b 5d 00                 	movl	(%rbp), %r11d
1400892e1: 44 0f b6 6d 0e              	movzbl	0xe(%rbp), %r13d
1400892e6: 48 8b 5d d8                 	movq	-0x28(%rbp), %rbx
1400892ea: 41 fe c8                    	decb	%r8b
1400892ed: 41 80 f8 07                 	cmpb	$0x7, %r8b
1400892f1: 0f 92 c0                    	setb	%al
1400892f4: b2 4d                       	movb	$0x4d, %dl
1400892f6: 44 89 c1                    	movl	%r8d, %ecx
1400892f9: d2 ea                       	shrb	%cl, %dl
1400892fb: 84 d0                       	testb	%dl, %al
1400892fd: 0f 85 df 00 00 00           	jne	0x1400893e2 <.text+0x883e2>
140089303: 0f b6 46 22                 	movzbl	0x22(%rsi), %eax
140089307: 3c 02                       	cmpb	$0x2, %al
140089309: 0f 85 86 00 00 00           	jne	0x140089395 <.text+0x88395>
14008930f: 48 89 1e                    	movq	%rbx, (%rsi)
140089312: 4c 89 7e 08                 	movq	%r15, 0x8(%rsi)
140089316: 4c 89 66 10                 	movq	%r12, 0x10(%rsi)
14008931a: 44 89 5e 18                 	movl	%r11d, 0x18(%rsi)
14008931e: 44 89 56 1c                 	movl	%r10d, 0x1c(%rsi)
140089322: 66 44 89 4e 20              	movw	%r9w, 0x20(%rsi)
140089327: 40 88 7e 22                 	movb	%dil, 0x22(%rsi)
14008932b: 44 88 6e 23                 	movb	%r13b, 0x23(%rsi)
14008932f: f3 0f 11 76 24              	movss	%xmm6, 0x24(%rsi)
140089334: e9 a9 00 00 00              	jmp	0x1400893e2 <.text+0x883e2>
140089339: 48 8b 99 00 05 00 00        	movq	0x500(%rcx), %rbx
140089340: 48 83 fb 03                 	cmpq	$0x3, %rbx
140089344: 0f 87 01 03 00 00           	ja	0x14008964b <.text+0x8864b>
14008934a: 48 8d 81 10 05 00 00        	leaq	0x510(%rcx), %rax
140089351: 80 3c 18 00                 	cmpb	$0x0, (%rax,%rbx)
140089355: 0f 84 46 01 00 00           	je	0x1400894a1 <.text+0x884a1>
14008935b: 4c 89 65 f0                 	movq	%r12, -0x10(%rbp)
14008935f: 44 88 45 f8                 	movb	%r8b, -0x8(%rbp)
140089363: 48 89 4d d0                 	movq	%rcx, -0x30(%rbp)
140089367: 49 89 d4                    	movq	%rdx, %r12
14008936a: 48 8d 0c 18                 	leaq	(%rax,%rbx), %rcx
14008936e: ba 04 00 00 00              	movl	$0x4, %edx
140089373: 48 29 da                    	subq	%rbx, %rdx
140089376: 49 89 c7                    	movq	%rax, %r15
140089379: e8 52 6b f8 ff              	callq	0x14000fed0 <.text+0xeed0>
14008937e: 48 83 f8 01                 	cmpq	$0x1, %rax
140089382: 0f 85 b3 00 00 00           	jne	0x14008943b <.text+0x8843b>
140089388: 48 01 d3                    	addq	%rdx, %rbx
14008938b: b8 01 00 00 00              	movl	$0x1, %eax
140089390: e9 b4 00 00 00              	jmp	0x140089449 <.text+0x88449>
140089395: 0f b7 4d 0a                 	movzwl	0xa(%rbp), %ecx
140089399: 66 39 4e 24                 	cmpw	%cx, 0x24(%rsi)
14008939d: 0f 85 6c ff ff ff           	jne	0x14008930f <.text+0x8830f>
1400893a3: 44 39 5e 18                 	cmpl	%r11d, 0x18(%rsi)
1400893a7: 0f 85 62 ff ff ff           	jne	0x14008930f <.text+0x8830f>
1400893ad: 44 39 56 1c                 	cmpl	%r10d, 0x1c(%rsi)
1400893b1: 0f 85 58 ff ff ff           	jne	0x14008930f <.text+0x8830f>
1400893b7: 66 44 39 4e 20              	cmpw	%r9w, 0x20(%rsi)
1400893bc: 0f 85 4d ff ff ff           	jne	0x14008930f <.text+0x8830f>
1400893c2: 40 38 f8                    	cmpb	%dil, %al
1400893c5: 0f 85 44 ff ff ff           	jne	0x14008930f <.text+0x8830f>
1400893cb: 48 8b 46 08                 	movq	0x8(%rsi), %rax
1400893cf: 4c 31 f8                    	xorq	%r15, %rax
1400893d2: 48 8b 4e 10                 	movq	0x10(%rsi), %rcx
1400893d6: 4c 31 e1                    	xorq	%r12, %rcx
1400893d9: 48 09 c1                    	orq	%rax, %rcx
1400893dc: 0f 85 2d ff ff ff           	jne	0x14008930f <.text+0x8830f>
1400893e2: 31 c0                       	xorl	%eax, %eax
1400893e4: 0f 28 75 10                 	movaps	0x10(%rbp), %xmm6
1400893e8: 48 81 c4 a8 00 00 00        	addq	$0xa8, %rsp
1400893ef: 5b                          	popq	%rbx
1400893f0: 5f                          	popq	%rdi
1400893f1: 5e                          	popq	%rsi
1400893f2: 41 5c                       	popq	%r12
1400893f4: 41 5d                       	popq	%r13
1400893f6: 41 5e                       	popq	%r14
1400893f8: 41 5f                       	popq	%r15
1400893fa: 5d                          	popq	%rbp
1400893fb: c3                          	retq
1400893fc: 4c 89 f1                    	movq	%r14, %rcx
1400893ff: 49 8b 9e 00 05 00 00        	movq	0x500(%r14), %rbx
140089406: 48 83 fb 03                 	cmpq	$0x3, %rbx
14008940a: 0f 87 3b 02 00 00           	ja	0x14008964b <.text+0x8864b>
140089410: 48 8b 45 e0                 	movq	-0x20(%rbp), %rax
140089414: 80 3c 18 00                 	cmpb	$0x0, (%rax,%rbx)
140089418: 74 56                       	je	0x140089470 <.text+0x88470>
14008941a: 48 8d 0c 18                 	leaq	(%rax,%rbx), %rcx
14008941e: ba 04 00 00 00              	movl	$0x4, %edx
140089423: 48 29 da                    	subq	%rbx, %rdx
140089426: e8 a5 6a f8 ff              	callq	0x14000fed0 <.text+0xeed0>
14008942b: 48 83 f8 01                 	cmpq	$0x1, %rax
14008942f: 75 45                       	jne	0x140089476 <.text+0x88476>
140089431: 48 01 d3                    	addq	%rdx, %rbx
140089434: b8 01 00 00 00              	movl	$0x1, %eax
140089439: eb 4a                       	jmp	0x140089485 <.text+0x88485>
14008943b: 4c 89 f9                    	movq	%r15, %rcx
14008943e: 48 89 da                    	movq	%rbx, %rdx
140089441: e8 8a 6a f8 ff              	callq	0x14000fed0 <.text+0xeed0>
140089446: 48 89 d3                    	movq	%rdx, %rbx
140089449: 4c 89 e2                    	movq	%r12, %rdx
14008944c: 48 8b 4d d0                 	movq	-0x30(%rbp), %rcx
140089450: 44 0f b6 45 f8              	movzbl	-0x8(%rbp), %r8d
140089455: a8 01                       	testb	$0x1, %al
140089457: 4c 8b 65 f0                 	movq	-0x10(%rbp), %r12
14008945b: 4c 8b 7d e8                 	movq	-0x18(%rbp), %r15
14008945f: 0f 84 82 fd ff ff           	je	0x1400891e7 <.text+0x881e7>
140089465: 48 83 fb 04                 	cmpq	$0x4, %rbx
140089469: 72 36                       	jb	0x1400894a1 <.text+0x884a1>
14008946b: e9 f1 01 00 00              	jmp	0x140089661 <.text+0x88661>
140089470: 48 8b 55 f8                 	movq	-0x8(%rbp), %rdx
140089474: eb 2b                       	jmp	0x1400894a1 <.text+0x884a1>
140089476: 48 8b 4d e0                 	movq	-0x20(%rbp), %rcx
14008947a: 48 89 da                    	movq	%rbx, %rdx
14008947d: e8 4e 6a f8 ff              	callq	0x14000fed0 <.text+0xeed0>
140089482: 48 89 d3                    	movq	%rdx, %rbx
140089485: 4c 89 f1                    	movq	%r14, %rcx
140089488: 41 89 f8                    	movl	%edi, %r8d
14008948b: a8 01                       	testb	$0x1, %al
14008948d: 0f 84 3d fe ff ff           	je	0x1400892d0 <.text+0x882d0>
140089493: 48 83 fb 04                 	cmpq	$0x4, %rbx
140089497: 48 8b 55 f8                 	movq	-0x8(%rbp), %rdx
14008949b: 0f 83 c0 01 00 00           	jae	0x140089661 <.text+0x88661>
1400894a1: 0f b6 7d 0f                 	movzbl	0xf(%rbp), %edi
1400894a5: 48 8d 43 01                 	leaq	0x1(%rbx), %rax
1400894a9: 45 31 c0                    	xorl	%r8d, %r8d
1400894ac: 48 83 f8 04                 	cmpq	$0x4, %rax
1400894b0: 4c 0f 45 c0                 	cmovneq	%rax, %r8
1400894b4: c6 84 19 10 05 00 00 01     	movb	$0x1, 0x510(%rcx,%rbx)
1400894bc: 4c 89 81 00 05 00 00        	movq	%r8, 0x500(%rcx)
1400894c3: 49 ff c5                    	incq	%r13
1400894c6: 4c 89 a9 08 05 00 00        	movq	%r13, 0x508(%rcx)
1400894cd: 48 8d 04 9b                 	leaq	(%rbx,%rbx,4), %rax
1400894d1: 48 c1 e0 06                 	shlq	$0x6, %rax
1400894d5: 48 01 c1                    	addq	%rax, %rcx
1400894d8: 41 b8 40 01 00 00           	movl	$0x140, %r8d            # imm = 0x140
1400894de: e8 2d 79 1c 00              	callq	0x140250e10 <.text+0x24fe10>
1400894e3: 44 0f b7 4d 0c              	movzwl	0xc(%rbp), %r9d
1400894e8: 44 8b 55 04                 	movl	0x4(%rbp), %r10d
1400894ec: 44 8b 5d 00                 	movl	(%rbp), %r11d
1400894f0: 0f b6 4e 22                 	movzbl	0x22(%rsi), %ecx
1400894f4: b0 01                       	movb	$0x1, %al
1400894f6: 80 f9 02                    	cmpb	$0x2, %cl
1400894f9: 0f 84 e5 fe ff ff           	je	0x1400893e4 <.text+0x883e4>
1400894ff: 0f b7 55 0a                 	movzwl	0xa(%rbp), %edx
140089503: 66 39 56 24                 	cmpw	%dx, 0x24(%rsi)
140089507: 0f 85 d7 fe ff ff           	jne	0x1400893e4 <.text+0x883e4>
14008950d: 44 39 5e 18                 	cmpl	%r11d, 0x18(%rsi)
140089511: 0f 85 cd fe ff ff           	jne	0x1400893e4 <.text+0x883e4>
140089517: 44 39 56 1c                 	cmpl	%r10d, 0x1c(%rsi)
14008951b: 0f 85 c3 fe ff ff           	jne	0x1400893e4 <.text+0x883e4>
140089521: 66 44 39 4e 20              	cmpw	%r9w, 0x20(%rsi)
140089526: 0f 85 b8 fe ff ff           	jne	0x1400893e4 <.text+0x883e4>
14008952c: 40 38 f9                    	cmpb	%dil, %cl
14008952f: 0f 85 af fe ff ff           	jne	0x1400893e4 <.text+0x883e4>
140089535: 4c 33 7e 08                 	xorq	0x8(%rsi), %r15
140089539: 4c 33 66 10                 	xorq	0x10(%rsi), %r12
14008953d: 4d 09 fc                    	orq	%r15, %r12
140089540: 0f 85 9e fe ff ff           	jne	0x1400893e4 <.text+0x883e4>
140089546: c6 46 22 02                 	movb	$0x2, 0x22(%rsi)
14008954a: e9 95 fe ff ff              	jmp	0x1400893e4 <.text+0x883e4>
14008954f: 44 89 c7                    	movl	%r8d, %edi
140089552: 48 89 55 f8                 	movq	%rdx, -0x8(%rbp)
140089556: 48 8b 43 d8                 	movq	-0x28(%rbx), %rax
14008955a: 0f 10 43 f0                 	movups	-0x10(%rbx), %xmm0
14008955e: 0f 29 45 b0                 	movaps	%xmm0, -0x50(%rbp)
140089562: 0f 10 43 e0                 	movups	-0x20(%rbx), %xmm0
140089566: 0f 29 45 a0                 	movaps	%xmm0, -0x60(%rbp)
14008956a: 41 83 fd 01                 	cmpl	$0x1, %r13d
14008956e: 75 5d                       	jne	0x1400895cd <.text+0x885cd>
140089570: 48 83 f8 01                 	cmpq	$0x1, %rax
140089574: 77 57                       	ja	0x1400895cd <.text+0x885cd>
140089576: 80 bc 01 80 1e 00 00 01     	cmpb	$0x1, 0x1e80(%rcx,%rax)
14008957e: 75 4d                       	jne	0x1400895cd <.text+0x885cd>
140089580: 80 bc 01 82 1e 00 00 00     	cmpb	$0x0, 0x1e82(%rcx,%rax)
140089588: 75 43                       	jne	0x1400895cd <.text+0x885cd>
14008958a: c6 84 01 80 1e 00 00 00     	movb	$0x0, 0x1e80(%rcx,%rax)
140089592: 48 ff 89 78 1e 00 00        	decq	0x1e78(%rcx)
140089599: 48 c7 84 c1 f8 1d 00 00 00 00 00 00 	movq	$0x0, 0x1df8(%rcx,%rax,8)
1400895a5: 48 8d 14 c0                 	leaq	(%rax,%rax,8), %rdx
1400895a9: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
1400895ad: 48 01 c2                    	addq	%rax, %rdx
1400895b0: 4c 8d 81 f8 14 00 00        	leaq	0x14f8(%rcx), %r8
1400895b7: 41 c6 84 10 5a 09 00 00 02  	movb	$0x2, 0x95a(%r8,%rdx)
1400895c0: 48 8d 04 40                 	leaq	(%rax,%rax,2), %rax
1400895c4: 41 c6 84 c0 1d 09 00 00 02  	movb	$0x2, 0x91d(%r8,%rax,8)
1400895cd: 48 8d 55 a0                 	leaq	-0x60(%rbp), %rdx
1400895d1: 48 89 cb                    	movq	%rcx, %rbx
1400895d4: e8 e7 cc 18 00              	callq	0x1402162c0 <.text+0x2152c0>
1400895d9: 48 89 d9                    	movq	%rbx, %rcx
1400895dc: 48 8b 55 f8                 	movq	-0x8(%rbp), %rdx
1400895e0: e8 4b ca 18 00              	callq	0x140216030 <.text+0x215030>
1400895e5: 48 85 c0                    	testq	%rax, %rax
1400895e8: 41 89 f8                    	movl	%edi, %r8d
1400895eb: 4c 8b 65 f0                 	movq	-0x10(%rbp), %r12
1400895ef: 4c 8b 7d e8                 	movq	-0x18(%rbp), %r15
1400895f3: 0f b6 7d 0f                 	movzbl	0xf(%rbp), %edi
1400895f7: 44 0f b7 4d 0c              	movzwl	0xc(%rbp), %r9d
1400895fc: 44 8b 55 04                 	movl	0x4(%rbp), %r10d
140089600: 44 8b 5d 00                 	movl	(%rbp), %r11d
140089604: 44 0f b6 6d 0e              	movzbl	0xe(%rbp), %r13d
140089609: 48 8b 5d d8                 	movq	-0x28(%rbp), %rbx
14008960d: 0f 85 dd fe ff ff           	jne	0x1400894f0 <.text+0x884f0>
140089613: e9 d2 fc ff ff              	jmp	0x1400892ea <.text+0x882ea>
140089618: 4c 8d 0d a9 6d 1d 00        	leaq	0x1d6da9(%rip), %r9     # 0x1402603c8
14008961f: 41 b8 00 01 00 00           	movl	$0x100, %r8d            # imm = 0x100
140089625: 31 c9                       	xorl	%ecx, %ecx
140089627: 48 89 c2                    	movq	%rax, %rdx
14008962a: e8 31 82 1c 00              	callq	0x140251860 <.text+0x250860>
14008962f: 0f 0b                       	ud2
140089631: 48 8d 0d 40 13 1e 00        	leaq	0x1e1340(%rip), %rcx    # 0x14026a978
140089638: 4c 8d 05 51 13 1e 00        	leaq	0x1e1351(%rip), %r8     # 0x14026a990
14008963f: ba 15 00 00 00              	movl	$0x15, %edx
140089644: e8 27 7f 1c 00              	callq	0x140251570 <.text+0x250570>
140089649: 0f 0b                       	ud2
14008964b: 4c 8d 05 ae 73 1d 00        	leaq	0x1d73ae(%rip), %r8     # 0x140260a00
140089652: ba 04 00 00 00              	movl	$0x4, %edx
140089657: 48 89 d9                    	movq	%rbx, %rcx
14008965a: e8 f4 7f 1c 00              	callq	0x140251653 <.text+0x250653>
14008965f: 0f 0b                       	ud2
140089661: 4c 8d 05 b0 73 1d 00        	leaq	0x1d73b0(%rip), %r8     # 0x140260a18
140089668: ba 04 00 00 00              	movl	$0x4, %edx
14008966d: 48 89 d9                    	movq	%rbx, %rcx
140089670: e8 de 7f 1c 00              	callq	0x140251653 <.text+0x250653>
140089675: 0f 0b                       	ud2


D:/CoapticCurrent/replay-active-copy-20261105/direct-fill/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140089030: 55                          	pushq	%rbp
140089031: 41 57                       	pushq	%r15
140089033: 41 56                       	pushq	%r14
140089035: 41 55                       	pushq	%r13
140089037: 41 54                       	pushq	%r12
140089039: 56                          	pushq	%rsi
14008903a: 57                          	pushq	%rdi
14008903b: 53                          	pushq	%rbx
14008903c: 48 81 ec a8 00 00 00        	subq	$0xa8, %rsp
140089043: 48 8d ac 24 80 00 00 00     	leaq	0x80(%rsp), %rbp
14008904b: 0f 29 75 10                 	movaps	%xmm6, 0x10(%rbp)
14008904f: 4c 89 ce                    	movq	%r9, %rsi
140089052: 44 88 45 06                 	movb	%r8b, 0x6(%rbp)
140089056: 48 89 cb                    	movq	%rcx, %rbx
140089059: 4c 8b a2 10 01 00 00        	movq	0x110(%rdx), %r12
140089060: 48 8b 82 08 01 00 00        	movq	0x108(%rdx), %rax
140089067: 48 89 45 f0                 	movq	%rax, -0x10(%rbp)
14008906b: 8b 82 18 01 00 00           	movl	0x118(%rdx), %eax
140089071: 89 45 fc                    	movl	%eax, -0x4(%rbp)
140089074: 8b 82 1c 01 00 00           	movl	0x11c(%rdx), %eax
14008907a: 89 45 00                    	movl	%eax, (%rbp)
14008907d: 0f b7 82 20 01 00 00        	movzwl	0x120(%rdx), %eax
140089084: 66 89 45 0a                 	movw	%ax, 0xa(%rbp)
140089088: 0f b6 82 22 01 00 00        	movzbl	0x122(%rdx), %eax
14008908f: 88 45 0f                    	movb	%al, 0xf(%rbp)
140089092: 0f b6 82 23 01 00 00        	movzbl	0x123(%rdx), %eax
140089099: 88 45 07                    	movb	%al, 0x7(%rbp)
14008909c: f3 0f 10 b2 24 01 00 00     	movss	0x124(%rdx), %xmm6
1400890a4: 0f b7 82 24 01 00 00        	movzwl	0x124(%rdx), %eax
1400890ab: 66 89 45 08                 	movw	%ax, 0x8(%rbp)
1400890af: 48 8b 82 28 01 00 00        	movq	0x128(%rdx), %rax
1400890b6: 48 89 45 d8                 	movq	%rax, -0x28(%rbp)
1400890ba: 0f b7 02                    	movzwl	(%rdx), %eax
1400890bd: 66 83 f8 01                 	cmpw	$0x1, %ax
1400890c1: 66 89 45 0c                 	movw	%ax, 0xc(%rbp)
1400890c5: 75 25                       	jne	0x1400890ec <.text+0x880ec>
1400890c7: 0f b7 42 02                 	movzwl	0x2(%rdx), %eax
1400890cb: 48 3d 01 01 00 00           	cmpq	$0x101, %rax            # imm = 0x101
1400890d1: 72 22                       	jb	0x1400890f5 <.text+0x880f5>
1400890d3: 4c 8d 0d de 62 1d 00        	leaq	0x1d62de(%rip), %r9     # 0x14025f3b8
1400890da: 41 b8 00 01 00 00           	movl	$0x100, %r8d            # imm = 0x100
1400890e0: 31 c9                       	xorl	%ecx, %ecx
1400890e2: 48 89 c2                    	movq	%rax, %rdx
1400890e5: e8 c6 7b 1c 00              	callq	0x140250cb0 <.text+0x24fcb0>
1400890ea: 0f 0b                       	ud2
1400890ec: 66 85 c0                    	testw	%ax, %ax
1400890ef: 0f 84 e2 01 00 00           	je	0x1400892d7 <.text+0x882d7>
1400890f5: 48 8d 82 08 01 00 00        	leaq	0x108(%rdx), %rax
1400890fc: 48 89 45 c0                 	movq	%rax, -0x40(%rbp)
140089100: 48 8d 83 b8 14 00 00        	leaq	0x14b8(%rbx), %rax
140089107: 48 89 45 d0                 	movq	%rax, -0x30(%rbp)
14008910b: 48 8d 83 28 05 00 00        	leaq	0x528(%rbx), %rax
140089112: 48 89 45 c8                 	movq	%rax, -0x38(%rbp)
140089116: 48 8d 83 50 06 00 00        	leaq	0x650(%rbx), %rax
14008911d: 41 bb 04 00 00 00           	movl	$0x4, %r11d
140089123: 45 31 c9                    	xorl	%r9d, %r9d
140089126: b9 01 00 00 00              	movl	$0x1, %ecx
14008912b: 31 ff                       	xorl	%edi, %edi
14008912d: 4d 69 d1 30 01 00 00        	imulq	$0x130, %r9, %r10       # imm = 0x130
140089134: 49 01 c2                    	addq	%rax, %r10
140089137: 66 0f 1f 84 00 00 00 00 00  	nopw	(%rax,%rax)
140089140: 45 0f b7 b2 d8 fe ff ff     	movzwl	-0x128(%r10), %r14d
140089148: 66 41 83 fe ff              	cmpw	$-0x1, %r14w
14008914d: 75 21                       	jne	0x140089170 <.text+0x88170>
14008914f: 49 ff c1                    	incq	%r9
140089152: 49 81 c2 30 01 00 00        	addq	$0x130, %r10            # imm = 0x130
140089159: 4d 39 cb                    	cmpq	%r9, %r11
14008915c: 75 e2                       	jne	0x140089140 <.text+0x88140>
14008915e: e9 9b 00 00 00              	jmp	0x1400891fe <.text+0x881fe>
140089163: 66 66 66 66 2e 0f 1f 84 00 00 00 00 00      	nopw	%cs:(%rax,%rax)
140089170: 44 0f b7 5d 08              	movzwl	0x8(%rbp), %r11d
140089175: 66 45 39 5a fc              	cmpw	%r11w, -0x4(%r10)
14008917a: 75 43                       	jne	0x1400891bf <.text+0x881bf>
14008917c: 44 8b 5d fc                 	movl	-0x4(%rbp), %r11d
140089180: 45 39 5a f0                 	cmpl	%r11d, -0x10(%r10)
140089184: 75 39                       	jne	0x1400891bf <.text+0x881bf>
140089186: 44 8b 5d 00                 	movl	(%rbp), %r11d
14008918a: 45 39 5a f4                 	cmpl	%r11d, -0xc(%r10)
14008918e: 75 2f                       	jne	0x1400891bf <.text+0x881bf>
140089190: 44 0f b7 5d 0a              	movzwl	0xa(%rbp), %r11d
140089195: 66 45 39 5a f8              	cmpw	%r11w, -0x8(%r10)
14008919a: 75 23                       	jne	0x1400891bf <.text+0x881bf>
14008919c: 44 0f b6 5d 0f              	movzbl	0xf(%rbp), %r11d
1400891a1: 45 38 5a fa                 	cmpb	%r11b, -0x6(%r10)
1400891a5: 75 18                       	jne	0x1400891bf <.text+0x881bf>
1400891a7: 4d 8b 5a e0                 	movq	-0x20(%r10), %r11
1400891ab: 4c 33 5d f0                 	xorq	-0x10(%rbp), %r11
1400891af: 4d 8b 7a e8                 	movq	-0x18(%r10), %r15
1400891b3: 4d 31 e7                    	xorq	%r12, %r15
1400891b6: 4d 09 df                    	orq	%r11, %r15
1400891b9: 0f 84 d6 03 00 00           	je	0x140089595 <.text+0x88595>
1400891bf: 4d 8b 12                    	movq	(%r10), %r10
1400891c2: 4d 39 c2                    	cmpq	%r8, %r10
1400891c5: 41 0f 93 c3                 	setae	%r11b
1400891c9: 41 20 fb                    	andb	%dil, %r11b
1400891cc: 4d 85 d2                    	testq	%r10, %r10
1400891cf: 48 0f 45 f9                 	cmovneq	%rcx, %rdi
1400891d3: 41 0f 94 c6                 	sete	%r14b
1400891d7: 45 08 de                    	orb	%r11b, %r14b
1400891da: 4d 0f 44 e9                 	cmoveq	%r9, %r13
1400891de: 4d 8d 49 01                 	leaq	0x1(%r9), %r9
1400891e2: 4d 0f 44 c2                 	cmoveq	%r10, %r8
1400891e6: 49 83 f9 05                 	cmpq	$0x5, %r9
1400891ea: 41 bb 04 00 00 00           	movl	$0x4, %r11d
1400891f0: 4d 0f 43 d9                 	cmovaeq	%r9, %r11
1400891f4: 49 83 f9 03                 	cmpq	$0x3, %r9
1400891f8: 0f 86 2f ff ff ff           	jbe	0x14008912d <.text+0x8812d>
1400891fe: 4c 8b b3 f0 09 00 00        	movq	0x9f0(%rbx), %r14
140089205: 49 83 fe 04                 	cmpq	$0x4, %r14
140089209: 0f 85 2b 01 00 00           	jne	0x14008933a <.text+0x8833a>
14008920f: 48 83 ff 01                 	cmpq	$0x1, %rdi
140089213: 0f 85 be 00 00 00           	jne	0x1400892d7 <.text+0x882d7>
140089219: 4d 69 c5 30 01 00 00        	imulq	$0x130, %r13, %r8       # imm = 0x130
140089220: 48 8d 8b 28 05 00 00        	leaq	0x528(%rbx), %rcx
140089227: 46 0f b7 0c 01              	movzwl	(%rcx,%r8), %r9d
14008922c: 66 41 83 f9 ff              	cmpw	$-0x1, %r9w
140089231: 0f 84 02 04 00 00           	je	0x140089639 <.text+0x88639>
140089237: 48 89 d7                    	movq	%rdx, %rdi
14008923a: 49 01 c8                    	addq	%rcx, %r8
14008923d: 49 8b 40 08                 	movq	0x8(%r8), %rax
140089241: 41 0f 10 80 18 01 00 00     	movups	0x118(%r8), %xmm0
140089249: 0f 29 45 b0                 	movaps	%xmm0, -0x50(%rbp)
14008924d: 41 0f 10 80 08 01 00 00     	movups	0x108(%r8), %xmm0
140089255: 0f 29 45 a0                 	movaps	%xmm0, -0x60(%rbp)
140089259: 66 41 83 f9 02              	cmpw	$0x2, %r9w
14008925e: 75 5d                       	jne	0x1400892bd <.text+0x882bd>
140089260: 48 83 f8 01                 	cmpq	$0x1, %rax
140089264: 77 57                       	ja	0x1400892bd <.text+0x882bd>
140089266: 80 bc 03 40 1e 00 00 01     	cmpb	$0x1, 0x1e40(%rbx,%rax)
14008926e: 75 4d                       	jne	0x1400892bd <.text+0x882bd>
140089270: 80 bc 03 42 1e 00 00 00     	cmpb	$0x0, 0x1e42(%rbx,%rax)
140089278: 75 43                       	jne	0x1400892bd <.text+0x882bd>
14008927a: c6 84 03 40 1e 00 00 00     	movb	$0x0, 0x1e40(%rbx,%rax)
140089282: 48 ff 8b 38 1e 00 00        	decq	0x1e38(%rbx)
140089289: 48 c7 84 c3 b8 1d 00 00 00 00 00 00 	movq	$0x0, 0x1db8(%rbx,%rax,8)
140089295: 48 8d 14 c0                 	leaq	(%rax,%rax,8), %rdx
140089299: 48 8d 14 52                 	leaq	(%rdx,%rdx,2), %rdx
14008929d: 48 01 c2                    	addq	%rax, %rdx
1400892a0: 4c 8d 83 b8 14 00 00        	leaq	0x14b8(%rbx), %r8
1400892a7: 41 c6 84 10 5a 09 00 00 02  	movb	$0x2, 0x95a(%r8,%rdx)
1400892b0: 48 8d 04 40                 	leaq	(%rax,%rax,2), %rax
1400892b4: 41 c6 84 c0 1d 09 00 00 02  	movb	$0x2, 0x91d(%r8,%rax,8)
1400892bd: 48 8d 55 a0                 	leaq	-0x60(%rbp), %rdx
1400892c1: e8 7a c5 18 00              	callq	0x140215840 <.text+0x214840>
1400892c6: 4c 8b b3 f0 09 00 00        	movq	0x9f0(%rbx), %r14
1400892cd: 49 83 fe 04                 	cmpq	$0x4, %r14
1400892d1: 0f 85 1d 01 00 00           	jne	0x1400893f4 <.text+0x883f4>
1400892d7: 0f b6 4d 06                 	movzbl	0x6(%rbp), %ecx
1400892db: fe c9                       	decb	%cl
1400892dd: 80 f9 07                    	cmpb	$0x7, %cl
1400892e0: 0f 92 c0                    	setb	%al
1400892e3: b2 4d                       	movb	$0x4d, %dl
1400892e5: d2 ea                       	shrb	%cl, %dl
1400892e7: 84 d0                       	testb	%dl, %al
1400892e9: 0f 85 fe 00 00 00           	jne	0x1400893ed <.text+0x883ed>
1400892ef: 0f b6 46 22                 	movzbl	0x22(%rsi), %eax
1400892f3: 3c 02                       	cmpb	$0x2, %al
1400892f5: 0f 85 9d 00 00 00           	jne	0x140089398 <.text+0x88398>
1400892fb: 48 8b 45 d8                 	movq	-0x28(%rbp), %rax
1400892ff: 48 89 06                    	movq	%rax, (%rsi)
140089302: 48 8b 45 f0                 	movq	-0x10(%rbp), %rax
140089306: 48 89 46 08                 	movq	%rax, 0x8(%rsi)
14008930a: 4c 89 66 10                 	movq	%r12, 0x10(%rsi)
14008930e: 8b 45 fc                    	movl	-0x4(%rbp), %eax
140089311: 89 46 18                    	movl	%eax, 0x18(%rsi)
140089314: 8b 45 00                    	movl	(%rbp), %eax
140089317: 89 46 1c                    	movl	%eax, 0x1c(%rsi)
14008931a: 0f b7 45 0a                 	movzwl	0xa(%rbp), %eax
14008931e: 66 89 46 20                 	movw	%ax, 0x20(%rsi)
140089322: 0f b6 45 0f                 	movzbl	0xf(%rbp), %eax
140089326: 88 46 22                    	movb	%al, 0x22(%rsi)
140089329: 0f b6 45 07                 	movzbl	0x7(%rbp), %eax
14008932d: 88 46 23                    	movb	%al, 0x23(%rsi)
140089330: f3 0f 11 76 24              	movss	%xmm6, 0x24(%rsi)
140089335: e9 b3 00 00 00              	jmp	0x1400893ed <.text+0x883ed>
14008933a: 48 89 75 e0                 	movq	%rsi, -0x20(%rbp)
14008933e: 4c 8b bb e8 09 00 00        	movq	0x9e8(%rbx), %r15
140089345: 49 83 ff 03                 	cmpq	$0x3, %r15
140089349: 0f 87 04 03 00 00           	ja	0x140089653 <.text+0x88653>
14008934f: 4c 89 e6                    	movq	%r12, %rsi
140089352: 4c 8d a3 f8 09 00 00        	leaq	0x9f8(%rbx), %r12
140089359: 43 80 3c 3c 00              	cmpb	$0x0, (%r12,%r15)
14008935e: 74 2c                       	je	0x14008938c <.text+0x8838c>
140089360: 48 89 55 e8                 	movq	%rdx, -0x18(%rbp)
140089364: 4b 8d 0c 3c                 	leaq	(%r12,%r15), %rcx
140089368: ba 04 00 00 00              	movl	$0x4, %edx
14008936d: 4c 29 fa                    	subq	%r15, %rdx
140089370: e8 5b 6b f8 ff              	callq	0x14000fed0 <.text+0xeed0>
140089375: 48 83 f8 01                 	cmpq	$0x1, %rax
140089379: 0f 85 c2 00 00 00           	jne	0x140089441 <.text+0x88441>
14008937f: 49 01 d7                    	addq	%rdx, %r15
140089382: b8 01 00 00 00              	movl	$0x1, %eax
140089387: e9 c3 00 00 00              	jmp	0x14008944f <.text+0x8844f>
14008938c: 49 89 f4                    	movq	%rsi, %r12
14008938f: 48 8b 75 e0                 	movq	-0x20(%rbp), %rsi
140089393: e9 de 00 00 00              	jmp	0x140089476 <.text+0x88476>
140089398: 0f b7 4d 08                 	movzwl	0x8(%rbp), %ecx
14008939c: 66 39 4e 24                 	cmpw	%cx, 0x24(%rsi)
1400893a0: 0f 85 55 ff ff ff           	jne	0x1400892fb <.text+0x882fb>
1400893a6: 8b 4d fc                    	movl	-0x4(%rbp), %ecx
1400893a9: 39 4e 18                    	cmpl	%ecx, 0x18(%rsi)
1400893ac: 0f 85 49 ff ff ff           	jne	0x1400892fb <.text+0x882fb>
1400893b2: 8b 4d 00                    	movl	(%rbp), %ecx
1400893b5: 39 4e 1c                    	cmpl	%ecx, 0x1c(%rsi)
1400893b8: 0f 85 3d ff ff ff           	jne	0x1400892fb <.text+0x882fb>
1400893be: 0f b7 4d 0a                 	movzwl	0xa(%rbp), %ecx
1400893c2: 66 39 4e 20                 	cmpw	%cx, 0x20(%rsi)
1400893c6: 0f 85 2f ff ff ff           	jne	0x1400892fb <.text+0x882fb>
1400893cc: 3a 45 0f                    	cmpb	0xf(%rbp), %al
1400893cf: 0f 85 26 ff ff ff           	jne	0x1400892fb <.text+0x882fb>
1400893d5: 48 8b 46 08                 	movq	0x8(%rsi), %rax
1400893d9: 48 33 45 f0                 	xorq	-0x10(%rbp), %rax
1400893dd: 48 8b 4e 10                 	movq	0x10(%rsi), %rcx
1400893e1: 4c 31 e1                    	xorq	%r12, %rcx
1400893e4: 48 09 c1                    	orq	%rax, %rcx
1400893e7: 0f 85 0e ff ff ff           	jne	0x1400892fb <.text+0x882fb>
1400893ed: 31 c0                       	xorl	%eax, %eax
1400893ef: e9 54 01 00 00              	jmp	0x140089548 <.text+0x88548>
1400893f4: 4c 8b bb e8 09 00 00        	movq	0x9e8(%rbx), %r15
1400893fb: 49 83 ff 03                 	cmpq	$0x3, %r15
1400893ff: 0f 87 4e 02 00 00           	ja	0x140089653 <.text+0x88653>
140089405: 49 89 f5                    	movq	%rsi, %r13
140089408: 4c 89 e6                    	movq	%r12, %rsi
14008940b: 4c 8d a3 f8 09 00 00        	leaq	0x9f8(%rbx), %r12
140089412: 43 80 3c 3c 00              	cmpb	$0x0, (%r12,%r15)
140089417: 74 54                       	je	0x14008946d <.text+0x8846d>
140089419: 4b 8d 0c 3c                 	leaq	(%r12,%r15), %rcx
14008941d: ba 04 00 00 00              	movl	$0x4, %edx
140089422: 4c 29 fa                    	subq	%r15, %rdx
140089425: e8 a6 6a f8 ff              	callq	0x14000fed0 <.text+0xeed0>
14008942a: 48 83 f8 01                 	cmpq	$0x1, %rax
14008942e: 0f 85 2c 01 00 00           	jne	0x140089560 <.text+0x88560>
140089434: 49 01 d7                    	addq	%rdx, %r15
140089437: b8 01 00 00 00              	movl	$0x1, %eax
14008943c: e9 2d 01 00 00              	jmp	0x14008956e <.text+0x8856e>
140089441: 4c 89 e1                    	movq	%r12, %rcx
140089444: 4c 89 fa                    	movq	%r15, %rdx
140089447: e8 84 6a f8 ff              	callq	0x14000fed0 <.text+0xeed0>
14008944c: 49 89 d7                    	movq	%rdx, %r15
14008944f: 48 8b 55 e8                 	movq	-0x18(%rbp), %rdx
140089453: 49 89 f4                    	movq	%rsi, %r12
140089456: a8 01                       	testb	$0x1, %al
140089458: 48 8b 75 e0                 	movq	-0x20(%rbp), %rsi
14008945c: 0f 84 ad fd ff ff           	je	0x14008920f <.text+0x8820f>
140089462: 49 83 ff 04                 	cmpq	$0x4, %r15
140089466: 72 0e                       	jb	0x140089476 <.text+0x88476>
140089468: e9 fc 01 00 00              	jmp	0x140089669 <.text+0x88669>
14008946d: 48 89 fa                    	movq	%rdi, %rdx
140089470: 49 89 f4                    	movq	%rsi, %r12
140089473: 4c 89 ee                    	movq	%r13, %rsi
140089476: 48 8d 8b 28 05 00 00        	leaq	0x528(%rbx), %rcx
14008947d: 44 0f b7 55 0c              	movzwl	0xc(%rbp), %r10d
140089482: 49 8d 47 01                 	leaq	0x1(%r15), %rax
140089486: 45 31 c0                    	xorl	%r8d, %r8d
140089489: 48 83 f8 04                 	cmpq	$0x4, %rax
14008948d: 4c 0f 45 c0                 	cmovneq	%rax, %r8
140089491: 42 c6 84 3b f8 09 00 00 01  	movb	$0x1, 0x9f8(%rbx,%r15)
14008949a: 4c 89 83 e8 09 00 00        	movq	%r8, 0x9e8(%rbx)
1400894a1: 49 ff c6                    	incq	%r14
1400894a4: 4c 89 b3 f0 09 00 00        	movq	%r14, 0x9f0(%rbx)
1400894ab: 49 69 c7 30 01 00 00        	imulq	$0x130, %r15, %rax      # imm = 0x130
1400894b2: 48 01 c1                    	addq	%rax, %rcx
1400894b5: 66 41 83 fa 01              	cmpw	$0x1, %r10w
1400894ba: 75 08                       	jne	0x1400894c4 <.text+0x884c4>
1400894bc: 41 b8 30 01 00 00           	movl	$0x130, %r8d            # imm = 0x130
1400894c2: eb 36                       	jmp	0x1400894fa <.text+0x884fa>
1400894c4: 66 c7 01 00 00              	movw	$0x0, (%rcx)
1400894c9: 48 8b 45 c0                 	movq	-0x40(%rbp), %rax
1400894cd: 0f 10 00                    	movups	(%rax), %xmm0
1400894d0: 0f 10 48 10                 	movups	0x10(%rax), %xmm1
1400894d4: 0f 11 81 08 01 00 00        	movups	%xmm0, 0x108(%rcx)
1400894db: 0f 11 89 18 01 00 00        	movups	%xmm1, 0x118(%rcx)
1400894e2: 48 8b 45 d8                 	movq	-0x28(%rbp), %rax
1400894e6: 48 89 81 28 01 00 00        	movq	%rax, 0x128(%rcx)
1400894ed: 66 41 83 fa 02              	cmpw	$0x2, %r10w
1400894f2: 75 0b                       	jne	0x1400894ff <.text+0x884ff>
1400894f4: 41 b8 08 01 00 00           	movl	$0x108, %r8d            # imm = 0x108
1400894fa: e8 61 6d 1c 00              	callq	0x140250260 <.text+0x24f260>
1400894ff: 0f b6 4e 22                 	movzbl	0x22(%rsi), %ecx
140089503: b0 01                       	movb	$0x1, %al
140089505: 80 f9 02                    	cmpb	$0x2, %cl
140089508: 74 3e                       	je	0x140089548 <.text+0x88548>
14008950a: 0f b7 55 08                 	movzwl	0x8(%rbp), %edx
14008950e: 66 39 56 24                 	cmpw	%dx, 0x24(%rsi)
140089512: 75 34                       	jne	0x140089548 <.text+0x88548>
140089514: 8b 55 fc                    	movl	-0x4(%rbp), %edx
140089517: 39 56 18                    	cmpl	%edx, 0x18(%rsi)
14008951a: 75 2c                       	jne	0x140089548 <.text+0x88548>
14008951c: 8b 55 00                    	movl	(%rbp), %edx
14008951f: 39 56 1c                    	cmpl	%edx, 0x1c(%rsi)
140089522: 75 24                       	jne	0x140089548 <.text+0x88548>
140089524: 0f b7 55 0a                 	movzwl	0xa(%rbp), %edx
140089528: 66 39 56 20                 	cmpw	%dx, 0x20(%rsi)
14008952c: 75 1a                       	jne	0x140089548 <.text+0x88548>
14008952e: 3a 4d 0f                    	cmpb	0xf(%rbp), %cl
140089531: 75 15                       	jne	0x140089548 <.text+0x88548>
140089533: 48 8b 4d f0                 	movq	-0x10(%rbp), %rcx
140089537: 48 33 4e 08                 	xorq	0x8(%rsi), %rcx
14008953b: 4c 33 66 10                 	xorq	0x10(%rsi), %r12
14008953f: 49 09 cc                    	orq	%rcx, %r12
140089542: 75 04                       	jne	0x140089548 <.text+0x88548>
140089544: c6 46 22 02                 	movb	$0x2, 0x22(%rsi)
140089548: 0f 28 75 10                 	movaps	0x10(%rbp), %xmm6
14008954c: 48 81 c4 a8 00 00 00        	addq	$0xa8, %rsp
140089553: 5b                          	popq	%rbx
140089554: 5f                          	popq	%rdi
140089555: 5e                          	popq	%rsi
140089556: 41 5c                       	popq	%r12
140089558: 41 5d                       	popq	%r13
14008955a: 41 5e                       	popq	%r14
14008955c: 41 5f                       	popq	%r15
14008955e: 5d                          	popq	%rbp
14008955f: c3                          	retq
140089560: 4c 89 e1                    	movq	%r12, %rcx
140089563: 4c 89 fa                    	movq	%r15, %rdx
140089566: e8 65 69 f8 ff              	callq	0x14000fed0 <.text+0xeed0>
14008956b: 49 89 d7                    	movq	%rdx, %r15
14008956e: 49 89 f4                    	movq	%rsi, %r12
140089571: a8 01                       	testb	$0x1, %al
140089573: 4c 89 ee                    	movq	%r13, %rsi
140089576: 48 8d 8b 28 05 00 00        	leaq	0x528(%rbx), %rcx
14008957d: 0f 84 54 fd ff ff           	je	0x1400892d7 <.text+0x882d7>
140089583: 49 83 ff 04                 	cmpq	$0x4, %r15
140089587: 0f 83 dc 00 00 00           	jae	0x140089669 <.text+0x88669>
14008958d: 48 89 fa                    	movq	%rdi, %rdx
140089590: e9 e8 fe ff ff              	jmp	0x14008947d <.text+0x8847d>
140089595: 49 89 d7                    	movq	%rdx, %r15
140089598: 49 8b 82 e0 fe ff ff        	movq	-0x120(%r10), %rax
14008959f: 41 0f 10 42 f0              	movups	-0x10(%r10), %xmm0
1400895a4: 0f 29 45 b0                 	movaps	%xmm0, -0x50(%rbp)
1400895a8: 41 0f 10 42 e0              	movups	-0x20(%r10), %xmm0
1400895ad: 0f 29 45 a0                 	movaps	%xmm0, -0x60(%rbp)
1400895b1: 66 41 83 fe 02              	cmpw	$0x2, %r14w
1400895b6: 75 58                       	jne	0x140089610 <.text+0x88610>
1400895b8: 48 83 f8 01                 	cmpq	$0x1, %rax
1400895bc: 77 52                       	ja	0x140089610 <.text+0x88610>
1400895be: 80 bc 03 40 1e 00 00 01     	cmpb	$0x1, 0x1e40(%rbx,%rax)
1400895c6: 75 48                       	jne	0x140089610 <.text+0x88610>
1400895c8: 80 bc 03 42 1e 00 00 00     	cmpb	$0x0, 0x1e42(%rbx,%rax)
1400895d0: 75 3e                       	jne	0x140089610 <.text+0x88610>
1400895d2: c6 84 03 40 1e 00 00 00     	movb	$0x0, 0x1e40(%rbx,%rax)
1400895da: 48 ff 8b 38 1e 00 00        	decq	0x1e38(%rbx)
1400895e1: 48 c7 84 c3 b8 1d 00 00 00 00 00 00 	movq	$0x0, 0x1db8(%rbx,%rax,8)
1400895ed: 48 8d 0c c0                 	leaq	(%rax,%rax,8), %rcx
1400895f1: 48 8d 0c 49                 	leaq	(%rcx,%rcx,2), %rcx
1400895f5: 48 01 c1                    	addq	%rax, %rcx
1400895f8: 48 8b 55 d0                 	movq	-0x30(%rbp), %rdx
1400895fc: c6 84 0a 5a 09 00 00 02     	movb	$0x2, 0x95a(%rdx,%rcx)
140089604: 48 8d 04 40                 	leaq	(%rax,%rax,2), %rax
140089608: c6 84 c2 1d 09 00 00 02     	movb	$0x2, 0x91d(%rdx,%rax,8)
140089610: 48 8d 55 a0                 	leaq	-0x60(%rbp), %rdx
140089614: 48 8b 7d c8                 	movq	-0x38(%rbp), %rdi
140089618: 48 89 f9                    	movq	%rdi, %rcx
14008961b: e8 20 c2 18 00              	callq	0x140215840 <.text+0x214840>
140089620: 48 89 f9                    	movq	%rdi, %rcx
140089623: 4c 89 fa                    	movq	%r15, %rdx
140089626: e8 c5 be 18 00              	callq	0x1402154f0 <.text+0x2144f0>
14008962b: 48 85 c0                    	testq	%rax, %rax
14008962e: 0f 85 cb fe ff ff           	jne	0x1400894ff <.text+0x884ff>
140089634: e9 9e fc ff ff              	jmp	0x1400892d7 <.text+0x882d7>
140089639: 48 8d 0d 10 03 1e 00        	leaq	0x1e0310(%rip), %rcx    # 0x140269950
140089640: 4c 8d 05 21 03 1e 00        	leaq	0x1e0321(%rip), %r8     # 0x140269968
140089647: ba 15 00 00 00              	movl	$0x15, %edx
14008964c: e8 6f 73 1c 00              	callq	0x1402509c0 <.text+0x24f9c0>
140089651: 0f 0b                       	ud2
140089653: 4c 8d 05 96 63 1d 00        	leaq	0x1d6396(%rip), %r8     # 0x14025f9f0
14008965a: ba 04 00 00 00              	movl	$0x4, %edx
14008965f: 4c 89 f9                    	movq	%r15, %rcx
140089662: e8 3c 74 1c 00              	callq	0x140250aa3 <.text+0x24faa3>
140089667: 0f 0b                       	ud2
140089669: 4c 8d 05 98 63 1d 00        	leaq	0x1d6398(%rip), %r8     # 0x14025fa08
140089670: ba 04 00 00 00              	movl	$0x4, %edx
140089675: 4c 89 f9                    	movq	%r15, %rcx
140089678: e8 26 74 1c 00              	callq	0x140250aa3 <.text+0x24faa3>
14008967d: 0f 0b                       	ud2


D:/CoapticCurrent/replay-active-copy-20261105/direct-fill/B/dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14008a490: 55                          	pushq	%rbp
14008a491: 41 57                       	pushq	%r15
14008a493: 41 56                       	pushq	%r14
14008a495: 41 55                       	pushq	%r13
14008a497: 41 54                       	pushq	%r12
14008a499: 56                          	pushq	%rsi
14008a49a: 57                          	pushq	%rdi
14008a49b: 53                          	pushq	%rbx
14008a49c: 48 83 ec 78                 	subq	$0x78, %rsp
14008a4a0: 48 8d 6c 24 70              	leaq	0x70(%rsp), %rbp
14008a4a5: 0f 29 75 f0                 	movaps	%xmm6, -0x10(%rbp)
14008a4a9: 4c 89 ce                    	movq	%r9, %rsi
14008a4ac: 45 89 c6                    	movl	%r8d, %r14d
14008a4af: 48 89 d7                    	movq	%rdx, %rdi
14008a4b2: 48 89 cb                    	movq	%rcx, %rbx
14008a4b5: 48 8b 82 10 01 00 00        	movq	0x110(%rdx), %rax
14008a4bc: 48 89 45 d0                 	movq	%rax, -0x30(%rbp)
14008a4c0: 48 8b 82 08 01 00 00        	movq	0x108(%rdx), %rax
14008a4c7: 48 89 45 d8                 	movq	%rax, -0x28(%rbp)
14008a4cb: 8b 82 18 01 00 00           	movl	0x118(%rdx), %eax
14008a4d1: 89 45 e0                    	movl	%eax, -0x20(%rbp)
14008a4d4: 8b 82 1c 01 00 00           	movl	0x11c(%rdx), %eax
14008a4da: 89 45 e4                    	movl	%eax, -0x1c(%rbp)
14008a4dd: 0f b7 82 20 01 00 00        	movzwl	0x120(%rdx), %eax
14008a4e4: 66 89 45 ec                 	movw	%ax, -0x14(%rbp)
14008a4e8: 0f b6 82 22 01 00 00        	movzbl	0x122(%rdx), %eax
14008a4ef: 88 45 ef                    	movb	%al, -0x11(%rbp)
14008a4f2: 0f b6 82 23 01 00 00        	movzbl	0x123(%rdx), %eax
14008a4f9: 88 45 e9                    	movb	%al, -0x17(%rbp)
14008a4fc: f3 0f 10 b2 24 01 00 00     	movss	0x124(%rdx), %xmm6
14008a504: 0f b7 82 24 01 00 00        	movzwl	0x124(%rdx), %eax
14008a50b: 66 89 45 ea                 	movw	%ax, -0x16(%rbp)
14008a50f: 4c 8b ba 28 01 00 00        	movq	0x128(%rdx), %r15
14008a516: 44 0f b7 2a                 	movzwl	(%rdx), %r13d
14008a51a: 66 41 83 fd 01              	cmpw	$0x1, %r13w
14008a51f: 75 23                       	jne	0x14008a544 <.text+0x89544>
14008a521: 0f b7 57 02                 	movzwl	0x2(%rdi), %edx
14008a525: 48 81 fa 01 01 00 00        	cmpq	$0x101, %rdx            # imm = 0x101
14008a52c: 72 20                       	jb	0x14008a54e <.text+0x8954e>
14008a52e: 4c 8d 0d 83 4e 1d 00        	leaq	0x1d4e83(%rip), %r9     # 0x14025f3b8
14008a535: 41 b8 00 01 00 00           	movl	$0x100, %r8d            # imm = 0x100
14008a53b: 31 c9                       	xorl	%ecx, %ecx
14008a53d: e8 6e 67 1c 00              	callq	0x140250cb0 <.text+0x24fcb0>
14008a542: 0f 0b                       	ud2
14008a544: 66 45 85 ed                 	testw	%r13w, %r13w
14008a548: 0f 84 5f 02 00 00           	je	0x14008a7ad <.text+0x897ad>
14008a54e: 4c 89 7d c0                 	movq	%r15, -0x40(%rbp)
14008a552: 48 8b 83 e8 00 00 00        	movq	0xe8(%rbx), %rax
14008a559: 48 85 c0                    	testq	%rax, %rax
14008a55c: 0f 84 ea 00 00 00           	je	0x14008a64c <.text+0x8964c>
14008a562: b9 28 01 00 00              	movl	$0x128, %ecx            # imm = 0x128
14008a567: 48 03 8b c8 00 00 00        	addq	0xc8(%rbx), %rcx
14008a56e: 48 8b 93 d0 00 00 00        	movq	0xd0(%rbx), %rdx
14008a575: 49 c7 c3 ff ff ff ff        	movq	$-0x1, %r11
14008a57c: 45 31 e4                    	xorl	%r12d, %r12d
14008a57f: 45 31 ff                    	xorl	%r15d, %r15d
14008a582: 4d 69 cc 30 01 00 00        	imulq	$0x130, %r12, %r9       # imm = 0x130
14008a589: 49 01 c9                    	addq	%rcx, %r9
14008a58c: eb 15                       	jmp	0x14008a5a3 <.text+0x895a3>
14008a58e: 66 90                       	nop
14008a590: 49 ff c4                    	incq	%r12
14008a593: 49 81 c1 30 01 00 00        	addq	$0x130, %r9             # imm = 0x130
14008a59a: 49 39 c4                    	cmpq	%rax, %r12
14008a59d: 0f 83 ac 00 00 00           	jae	0x14008a64f <.text+0x8964f>
14008a5a3: 49 39 d4                    	cmpq	%rdx, %r12
14008a5a6: 73 e8                       	jae	0x14008a590 <.text+0x89590>
14008a5a8: 45 0f b7 91 d8 fe ff ff     	movzwl	-0x128(%r9), %r10d
14008a5b0: 66 41 83 fa ff              	cmpw	$-0x1, %r10w
14008a5b5: 74 d9                       	je	0x14008a590 <.text+0x89590>
14008a5b7: 44 0f b7 45 ea              	movzwl	-0x16(%rbp), %r8d
14008a5bc: 66 45 39 41 fc              	cmpw	%r8w, -0x4(%r9)
14008a5c1: 75 4c                       	jne	0x14008a60f <.text+0x8960f>
14008a5c3: 44 8b 45 e0                 	movl	-0x20(%rbp), %r8d
14008a5c7: 45 39 41 f0                 	cmpl	%r8d, -0x10(%r9)
14008a5cb: 75 42                       	jne	0x14008a60f <.text+0x8960f>
14008a5cd: 44 8b 45 e4                 	movl	-0x1c(%rbp), %r8d
14008a5d1: 45 39 41 f4                 	cmpl	%r8d, -0xc(%r9)
14008a5d5: 75 38                       	jne	0x14008a60f <.text+0x8960f>
14008a5d7: 44 0f b7 45 ec              	movzwl	-0x14(%rbp), %r8d
14008a5dc: 66 45 39 41 f8              	cmpw	%r8w, -0x8(%r9)
14008a5e1: 75 2c                       	jne	0x14008a60f <.text+0x8960f>
14008a5e3: 44 0f b6 45 ef              	movzbl	-0x11(%rbp), %r8d
14008a5e8: 45 38 41 fa                 	cmpb	%r8b, -0x6(%r9)
14008a5ec: 75 21                       	jne	0x14008a60f <.text+0x8960f>
14008a5ee: 4c 89 5d b8                 	movq	%r11, -0x48(%rbp)
14008a5f2: 4d 8b 59 e0                 	movq	-0x20(%r9), %r11
14008a5f6: 4c 33 5d d8                 	xorq	-0x28(%rbp), %r11
14008a5fa: 4d 8b 41 e8                 	movq	-0x18(%r9), %r8
14008a5fe: 4c 33 45 d0                 	xorq	-0x30(%rbp), %r8
14008a602: 4d 09 d8                    	orq	%r11, %r8
14008a605: 4c 8b 5d b8                 	movq	-0x48(%rbp), %r11
14008a609: 0f 84 0b 03 00 00           	je	0x14008a91a <.text+0x8991a>
14008a60f: 4d 8b 09                    	movq	(%r9), %r9
14008a612: 4d 85 c9                    	testq	%r9, %r9
14008a615: 74 27                       	je	0x14008a63e <.text+0x8963e>
14008a617: 4d 85 ff                    	testq	%r15, %r15
14008a61a: 41 0f 94 c0                 	sete	%r8b
14008a61e: 4d 39 d9                    	cmpq	%r11, %r9
14008a621: 41 0f 92 c2                 	setb	%r10b
14008a625: 45 08 c2                    	orb	%r8b, %r10b
14008a628: 4c 8b 45 c8                 	movq	-0x38(%rbp), %r8
14008a62c: 4d 0f 45 c4                 	cmovneq	%r12, %r8
14008a630: 4c 89 45 c8                 	movq	%r8, -0x38(%rbp)
14008a634: 4d 0f 45 d9                 	cmovneq	%r9, %r11
14008a638: 41 bf 01 00 00 00           	movl	$0x1, %r15d
14008a63e: 49 ff c4                    	incq	%r12
14008a641: 49 39 c4                    	cmpq	%rax, %r12
14008a644: 0f 82 38 ff ff ff           	jb	0x14008a582 <.text+0x89582>
14008a64a: eb 03                       	jmp	0x14008a64f <.text+0x8964f>
14008a64c: 45 31 ff                    	xorl	%r15d, %r15d
14008a64f: 4c 8d a3 d8 00 00 00        	leaq	0xd8(%rbx), %r12
14008a656: 4c 89 e1                    	movq	%r12, %rcx
14008a659: e8 02 0b f8 ff              	callq	0x14000b160 <.text+0xa160>
14008a65e: a8 01                       	testb	$0x1, %al
14008a660: 74 53                       	je	0x14008a6b5 <.text+0x896b5>
14008a662: 4c 8b 7d c0                 	movq	-0x40(%rbp), %r15
14008a666: 4d 85 ff                    	testq	%r15, %r15
14008a669: 74 16                       	je	0x14008a681 <.text+0x89681>
14008a66b: 48 8b 83 18 01 00 00        	movq	0x118(%rbx), %rax
14008a672: 48 ff c8                    	decq	%rax
14008a675: 4c 39 f8                    	cmpq	%r15, %rax
14008a678: 72 07                       	jb	0x14008a681 <.text+0x89681>
14008a67a: 4c 89 bb 18 01 00 00        	movq	%r15, 0x118(%rbx)
14008a681: 48 8b 83 d0 00 00 00        	movq	0xd0(%rbx), %rax
14008a688: 48 39 c2                    	cmpq	%rax, %rdx
14008a68b: 0f 83 bc 02 00 00           	jae	0x14008a94d <.text+0x8994d>
14008a691: 48 69 ca 30 01 00 00        	imulq	$0x130, %rdx, %rcx      # imm = 0x130
14008a698: 48 03 8b c8 00 00 00        	addq	0xc8(%rbx), %rcx
14008a69f: 66 41 83 fd 01              	cmpw	$0x1, %r13w
14008a6a4: 0f 85 67 01 00 00           	jne	0x14008a811 <.text+0x89811>
14008a6aa: 41 b8 30 01 00 00           	movl	$0x130, %r8d            # imm = 0x130
14008a6b0: e9 91 01 00 00              	jmp	0x14008a846 <.text+0x89846>
14008a6b5: 49 83 ff 01                 	cmpq	$0x1, %r15
14008a6b9: 4c 8b 7d c0                 	movq	-0x40(%rbp), %r15
14008a6bd: 0f 85 ea 00 00 00           	jne	0x14008a7ad <.text+0x897ad>
14008a6c3: 48 8b 83 d0 00 00 00        	movq	0xd0(%rbx), %rax
14008a6ca: 4c 8b 4d c8                 	movq	-0x38(%rbp), %r9
14008a6ce: 49 39 c1                    	cmpq	%rax, %r9
14008a6d1: 73 75                       	jae	0x14008a748 <.text+0x89748>
14008a6d3: 48 8b 8b c8 00 00 00        	movq	0xc8(%rbx), %rcx
14008a6da: 49 69 d1 30 01 00 00        	imulq	$0x130, %r9, %rdx       # imm = 0x130
14008a6e1: 66 83 3c 11 02              	cmpw	$0x2, (%rcx,%rdx)
14008a6e6: 75 60                       	jne	0x14008a748 <.text+0x89748>
14008a6e8: 48 01 d1                    	addq	%rdx, %rcx
14008a6eb: 48 8b 49 08                 	movq	0x8(%rcx), %rcx
14008a6ef: 48 3b 8b 88 00 00 00        	cmpq	0x88(%rbx), %rcx
14008a6f6: 73 50                       	jae	0x14008a748 <.text+0x89748>
14008a6f8: 48 8b 93 80 00 00 00        	movq	0x80(%rbx), %rdx
14008a6ff: 80 3c 0a 01                 	cmpb	$0x1, (%rdx,%rcx)
14008a703: 75 43                       	jne	0x14008a748 <.text+0x89748>
14008a705: 48 3b 8b a0 00 00 00        	cmpq	0xa0(%rbx), %rcx
14008a70c: 73 0e                       	jae	0x14008a71c <.text+0x8971c>
14008a70e: 4c 8b 83 98 00 00 00        	movq	0x98(%rbx), %r8
14008a715: 41 80 3c 08 00              	cmpb	$0x0, (%r8,%rcx)
14008a71a: 75 2c                       	jne	0x14008a748 <.text+0x89748>
14008a71c: c6 04 0a 00                 	movb	$0x0, (%rdx,%rcx)
14008a720: 48 ff 8b b0 00 00 00        	decq	0xb0(%rbx)
14008a727: 48 3b 4b 70                 	cmpq	0x70(%rbx), %rcx
14008a72b: 73 1b                       	jae	0x14008a748 <.text+0x89748>
14008a72d: 48 8b 53 68                 	movq	0x68(%rbx), %rdx
14008a731: 48 6b c9 58                 	imulq	$0x58, %rcx, %rcx
14008a735: 48 c7 44 0a 30 00 00 00 00  	movq	$0x0, 0x30(%rdx,%rcx)
14008a73e: c6 44 0a 52 02              	movb	$0x2, 0x52(%rdx,%rcx)
14008a743: c6 44 0a 25 02              	movb	$0x2, 0x25(%rdx,%rcx)
14008a748: 4c 3b 8b e8 00 00 00        	cmpq	0xe8(%rbx), %r9
14008a74f: 73 4a                       	jae	0x14008a79b <.text+0x8979b>
14008a751: 48 8b 8b e0 00 00 00        	movq	0xe0(%rbx), %rcx
14008a758: 42 80 3c 09 01              	cmpb	$0x1, (%rcx,%r9)
14008a75d: 75 3c                       	jne	0x14008a79b <.text+0x8979b>
14008a75f: 4c 3b 8b 00 01 00 00        	cmpq	0x100(%rbx), %r9
14008a766: 73 0e                       	jae	0x14008a776 <.text+0x89776>
14008a768: 48 8b 93 f8 00 00 00        	movq	0xf8(%rbx), %rdx
14008a76f: 42 80 3c 0a 00              	cmpb	$0x0, (%rdx,%r9)
14008a774: 75 25                       	jne	0x14008a79b <.text+0x8979b>
14008a776: 42 c6 04 09 00              	movb	$0x0, (%rcx,%r9)
14008a77b: 48 ff 8b 10 01 00 00        	decq	0x110(%rbx)
14008a782: 49 39 c1                    	cmpq	%rax, %r9
14008a785: 73 14                       	jae	0x14008a79b <.text+0x8979b>
14008a787: 48 8b 83 c8 00 00 00        	movq	0xc8(%rbx), %rax
14008a78e: 49 69 c9 30 01 00 00        	imulq	$0x130, %r9, %rcx       # imm = 0x130
14008a795: 66 c7 04 08 ff ff           	movw	$0xffff, (%rax,%rcx)    # imm = 0xFFFF
14008a79b: 4c 89 e1                    	movq	%r12, %rcx
14008a79e: e8 bd 09 f8 ff              	callq	0x14000b160 <.text+0xa160>
14008a7a3: 48 83 f8 01                 	cmpq	$0x1, %rax
14008a7a7: 0f 84 b9 fe ff ff           	je	0x14008a666 <.text+0x89666>
14008a7ad: 41 fe ce                    	decb	%r14b
14008a7b0: 41 80 fe 07                 	cmpb	$0x7, %r14b
14008a7b4: 0f 92 c0                    	setb	%al
14008a7b7: b2 4d                       	movb	$0x4d, %dl
14008a7b9: 44 89 f1                    	movl	%r14d, %ecx
14008a7bc: d2 ea                       	shrb	%cl, %dl
14008a7be: 84 d0                       	testb	%dl, %al
14008a7c0: 0f 85 3d 01 00 00           	jne	0x14008a903 <.text+0x89903>
14008a7c6: 0f b6 46 22                 	movzbl	0x22(%rsi), %eax
14008a7ca: 3c 02                       	cmpb	$0x2, %al
14008a7cc: 0f 85 db 00 00 00           	jne	0x14008a8ad <.text+0x898ad>
14008a7d2: 4c 89 3e                    	movq	%r15, (%rsi)
14008a7d5: 48 8b 45 d8                 	movq	-0x28(%rbp), %rax
14008a7d9: 48 89 46 08                 	movq	%rax, 0x8(%rsi)
14008a7dd: 48 8b 45 d0                 	movq	-0x30(%rbp), %rax
14008a7e1: 48 89 46 10                 	movq	%rax, 0x10(%rsi)
14008a7e5: 8b 45 e0                    	movl	-0x20(%rbp), %eax
14008a7e8: 89 46 18                    	movl	%eax, 0x18(%rsi)
14008a7eb: 8b 45 e4                    	movl	-0x1c(%rbp), %eax
14008a7ee: 89 46 1c                    	movl	%eax, 0x1c(%rsi)
14008a7f1: 0f b7 45 ec                 	movzwl	-0x14(%rbp), %eax
14008a7f5: 66 89 46 20                 	movw	%ax, 0x20(%rsi)
14008a7f9: 0f b6 45 ef                 	movzbl	-0x11(%rbp), %eax
14008a7fd: 88 46 22                    	movb	%al, 0x22(%rsi)
14008a800: 0f b6 45 e9                 	movzbl	-0x17(%rbp), %eax
14008a804: 88 46 23                    	movb	%al, 0x23(%rsi)
14008a807: f3 0f 11 76 24              	movss	%xmm6, 0x24(%rsi)
14008a80c: e9 f2 00 00 00              	jmp	0x14008a903 <.text+0x89903>
14008a811: 48 8d 87 08 01 00 00        	leaq	0x108(%rdi), %rax
14008a818: 66 c7 01 00 00              	movw	$0x0, (%rcx)
14008a81d: 0f 10 00                    	movups	(%rax), %xmm0
14008a820: 0f 10 48 10                 	movups	0x10(%rax), %xmm1
14008a824: 0f 11 81 08 01 00 00        	movups	%xmm0, 0x108(%rcx)
14008a82b: 0f 11 89 18 01 00 00        	movups	%xmm1, 0x118(%rcx)
14008a832: 4c 89 b9 28 01 00 00        	movq	%r15, 0x128(%rcx)
14008a839: 66 41 83 fd 02              	cmpw	$0x2, %r13w
14008a83e: 75 0e                       	jne	0x14008a84e <.text+0x8984e>
14008a840: 41 b8 08 01 00 00           	movl	$0x108, %r8d            # imm = 0x108
14008a846: 48 89 fa                    	movq	%rdi, %rdx
14008a849: e8 12 5a 1c 00              	callq	0x140250260 <.text+0x24f260>
14008a84e: 0f b6 4e 22                 	movzbl	0x22(%rsi), %ecx
14008a852: b0 01                       	movb	$0x1, %al
14008a854: 80 f9 02                    	cmpb	$0x2, %cl
14008a857: 0f 84 a8 00 00 00           	je	0x14008a905 <.text+0x89905>
14008a85d: 0f b7 55 ea                 	movzwl	-0x16(%rbp), %edx
14008a861: 66 39 56 24                 	cmpw	%dx, 0x24(%rsi)
14008a865: 0f 85 9a 00 00 00           	jne	0x14008a905 <.text+0x89905>
14008a86b: 8b 55 e0                    	movl	-0x20(%rbp), %edx
14008a86e: 39 56 18                    	cmpl	%edx, 0x18(%rsi)
14008a871: 0f 85 8e 00 00 00           	jne	0x14008a905 <.text+0x89905>
14008a877: 8b 55 e4                    	movl	-0x1c(%rbp), %edx
14008a87a: 39 56 1c                    	cmpl	%edx, 0x1c(%rsi)
14008a87d: 0f 85 82 00 00 00           	jne	0x14008a905 <.text+0x89905>
14008a883: 0f b7 55 ec                 	movzwl	-0x14(%rbp), %edx
14008a887: 66 39 56 20                 	cmpw	%dx, 0x20(%rsi)
14008a88b: 75 78                       	jne	0x14008a905 <.text+0x89905>
14008a88d: 3a 4d ef                    	cmpb	-0x11(%rbp), %cl
14008a890: 75 73                       	jne	0x14008a905 <.text+0x89905>
14008a892: 48 8b 55 d8                 	movq	-0x28(%rbp), %rdx
14008a896: 48 33 56 08                 	xorq	0x8(%rsi), %rdx
14008a89a: 48 8b 4d d0                 	movq	-0x30(%rbp), %rcx
14008a89e: 48 33 4e 10                 	xorq	0x10(%rsi), %rcx
14008a8a2: 48 09 d1                    	orq	%rdx, %rcx
14008a8a5: 75 5e                       	jne	0x14008a905 <.text+0x89905>
14008a8a7: c6 46 22 02                 	movb	$0x2, 0x22(%rsi)
14008a8ab: eb 58                       	jmp	0x14008a905 <.text+0x89905>
14008a8ad: 0f b7 4d ea                 	movzwl	-0x16(%rbp), %ecx
14008a8b1: 66 39 4e 24                 	cmpw	%cx, 0x24(%rsi)
14008a8b5: 0f 85 17 ff ff ff           	jne	0x14008a7d2 <.text+0x897d2>
14008a8bb: 8b 4d e0                    	movl	-0x20(%rbp), %ecx
14008a8be: 39 4e 18                    	cmpl	%ecx, 0x18(%rsi)
14008a8c1: 0f 85 0b ff ff ff           	jne	0x14008a7d2 <.text+0x897d2>
14008a8c7: 8b 4d e4                    	movl	-0x1c(%rbp), %ecx
14008a8ca: 39 4e 1c                    	cmpl	%ecx, 0x1c(%rsi)
14008a8cd: 0f 85 ff fe ff ff           	jne	0x14008a7d2 <.text+0x897d2>
14008a8d3: 0f b7 4d ec                 	movzwl	-0x14(%rbp), %ecx
14008a8d7: 66 39 4e 20                 	cmpw	%cx, 0x20(%rsi)
14008a8db: 0f 85 f1 fe ff ff           	jne	0x14008a7d2 <.text+0x897d2>
14008a8e1: 3a 45 ef                    	cmpb	-0x11(%rbp), %al
14008a8e4: 0f 85 e8 fe ff ff           	jne	0x14008a7d2 <.text+0x897d2>
14008a8ea: 48 8b 46 08                 	movq	0x8(%rsi), %rax
14008a8ee: 48 33 45 d8                 	xorq	-0x28(%rbp), %rax
14008a8f2: 48 8b 4e 10                 	movq	0x10(%rsi), %rcx
14008a8f6: 48 33 4d d0                 	xorq	-0x30(%rbp), %rcx
14008a8fa: 48 09 c1                    	orq	%rax, %rcx
14008a8fd: 0f 85 cf fe ff ff           	jne	0x14008a7d2 <.text+0x897d2>
14008a903: 31 c0                       	xorl	%eax, %eax
14008a905: 0f 28 75 f0                 	movaps	-0x10(%rbp), %xmm6
14008a909: 48 83 c4 78                 	addq	$0x78, %rsp
14008a90d: 5b                          	popq	%rbx
14008a90e: 5f                          	popq	%rdi
14008a90f: 5e                          	popq	%rsi
14008a910: 41 5c                       	popq	%r12
14008a912: 41 5d                       	popq	%r13
14008a914: 41 5e                       	popq	%r14
14008a916: 41 5f                       	popq	%r15
14008a918: 5d                          	popq	%rbp
14008a919: c3                          	retq
14008a91a: 66 41 83 fa 02              	cmpw	$0x2, %r10w
14008a91f: 75 10                       	jne	0x14008a931 <.text+0x89931>
14008a921: 49 8b 91 e0 fe ff ff        	movq	-0x120(%r9), %rdx
14008a928: 48 8d 4b 60                 	leaq	0x60(%rbx), %rcx
14008a92c: e8 af 67 f8 ff              	callq	0x1400110e0 <.text+0x100e0>
14008a931: 48 8d 8b c0 00 00 00        	leaq	0xc0(%rbx), %rcx
14008a938: 4c 89 e2                    	movq	%r12, %rdx
14008a93b: e8 70 70 f8 ff              	callq	0x1400119b0 <.text+0x109b0>
14008a940: 3c ff                       	cmpb	$-0x1, %al
14008a942: 0f 85 06 ff ff ff           	jne	0x14008a84e <.text+0x8984e>
14008a948: e9 02 fd ff ff              	jmp	0x14008a64f <.text+0x8964f>
14008a94d: 4c 8d 05 8c 37 1e 00        	leaq	0x1e378c(%rip), %r8     # 0x14026e0e0
14008a954: 48 89 d1                    	movq	%rdx, %rcx
14008a957: 48 89 c2                    	movq	%rax, %rdx
14008a95a: e8 44 61 1c 00              	callq	0x140250aa3 <.text+0x24faa3>
14008a95f: 0f 0b                       	ud2

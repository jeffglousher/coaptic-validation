"""Retention/expiry diagnostic only; not a comparison or acceptance measurement."""
from pathlib import Path
import ast
import json
import os
import psutil
import subprocess

root = Path(__file__).resolve().parent
assert not (root / 'result3.json').exists()
process = psutil.Process()
affinity = process.cpu_affinity()
rows = []
process.cpu_affinity([0])
try:
    for profile in ['small-device', 'service-fixed', 'service-allocated']:
        for mode in ['sync', 'async']:
            label = 'phase3-' + profile + '-unprotected-' + mode
            env = dict(os.environ, COAPTIC_EXPIRY_PROBE='steady')
            env.pop('COAPTIC_DISPATCH_ASYNC', None)
            if mode == 'async':
                env['COAPTIC_DISPATCH_ASYNC'] = '1'
            cmd = [str(root / 'diagnostic3.exe'), '8192', 'unprotected', '--' + profile]
            if profile != 'small-device':
                cmd += ['1024']
            result = subprocess.run(cmd, env=env, capture_output=True, timeout=30)
            (root / (label + '.json')).write_bytes(result.stdout)
            (root / (label + '.stderr')).write_bytes(result.stderr)
            assert result.returncode == 0, result.stderr
            value = json.loads(result.stdout)
            assert value['operations'] == 8192 and value['security'] == 'unprotected'
            if profile != 'small-device':
                assert value['verified'] == 8320 and value['server_poll_counts'] == [1] * 8192
            else:
                assert value['black_box'] and value['payload_bytes'] == 32
            line = next(line for line in result.stderr.decode().splitlines() if line.startswith('PHASE_NS '))
            phases = ast.literal_eval(line[len('PHASE_NS '):])
            assert len(phases) == 17 and phases[0][0] == 8320
            rows.append(dict(profile=profile, mode=mode, phases=phases,
                             ns_per_drive=[ns / phases[0][0] for count, ns in phases]))
    (root / 'result3.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
    print(json.dumps([dict(profile=x['profile'], mode=x['mode'],
                           drive=x['ns_per_drive'][0], floor=x['ns_per_drive'][8],
                           expiry=x['ns_per_drive'][15], retention=x['ns_per_drive'][16],
                           expiry_calls=x['phases'][15][0], retention_calls=x['phases'][16][0])
                      for x in rows], indent=2))
finally:
    process.cpu_affinity(affinity)

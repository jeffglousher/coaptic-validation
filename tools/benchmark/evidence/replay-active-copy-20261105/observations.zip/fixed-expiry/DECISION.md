# Fixed expiry integration, prospective decision

Candidate1c6cee94 combines shared replay ownership, owned-table lookup simplification, direct inline fill, scalar TX stores and a fixed-table deadline lower bound refreshed during the existing App expiry walk. Baselinebd63199 is unchanged. This differs from retired2321164-parent fixed cache: no separate refresh scan; replay owner savings absorb the8-byte bound. Preserve that earlier failed comparison.

Diagnostic3 in ../async-cost-20261105 shows fixed Service expiry above timer floor, while small/allocated expiry is near floor. Inclusive instrumented nanoseconds are diagnostic, not CPU shares or a runtime benefit claim.

One28-cell complete-App runtime cohort; identical gates and capacity/security settings to scalar-pin. Must pass both ordinary/all sync+async upper95<1 and every cell point<=1.02, plus matched retained-memory reduction. No unchanged failed retry. No sockets/executor-latency/peak-memory claim. Tests926 pass; new duplicate-key App test added separately at2244b31 has no production effect.

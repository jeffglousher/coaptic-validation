
D:\CoapticCurrent\phase-sharing-static-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009e2e0:     	pushq	%rbp
14009e2e1:     	pushq	%r15
14009e2e3:     	pushq	%r14
14009e2e5:     	pushq	%r13
14009e2e7:     	pushq	%r12
14009e2e9:     	pushq	%rsi
14009e2ea:     	pushq	%rdi
14009e2eb:     	pushq	%rbx
14009e2ec:     	subq	$0x318, %rsp            # imm = 0x318
14009e2f3:     	leaq	0x80(%rsp), %rbp
14009e2fb:     	movaps	%xmm7, 0x280(%rbp)
14009e302:     	movdqa	%xmm6, 0x270(%rbp)
14009e30a:     	movq	0xe8(%rcx), %r8
14009e311:     	testq	%r8, %r8
14009e314:     	je	0x14009e6f4 <.text+0x9d6f4>
14009e31a:     	movq	0x88(%rcx), %r11
14009e321:     	movq	0xe0(%rcx), %rdx
14009e328:     	movq	0xc8(%rcx), %rax
14009e32f:     	movq	0xd0(%rcx), %r9
14009e336:     	leaq	0x30(%rax), %rsi
14009e33a:     	xorl	%ebx, %ebx
14009e33c:     	xorl	%edi, %edi
14009e33e:     	leaq	(%rdi,%rdi,4), %r12
14009e342:     	shlq	$0x6, %r12
14009e346:     	addq	%rsi, %r12
14009e349:     	jmp	0x14009e363 <.text+0x9d363>
14009e34b:     	nopl	(%rax,%rax)
14009e350:     	incq	%rdi
14009e353:     	addq	$0x140, %r12            # imm = 0x140
14009e35a:     	cmpq	%r8, %rdi
14009e35d:     	jae	0x14009e42c <.text+0x9d42c>
14009e363:     	cmpq	%r9, %rdi
14009e366:     	setb	%r15b
14009e36a:     	andb	(%rdx,%rdi), %r15b
14009e36e:     	cmpb	$0x1, %r15b
14009e372:     	jne	0x14009e350 <.text+0x9d350>
14009e374:     	movq	-0x30(%r12), %r15
14009e379:     	cmpq	$0x2, %r15
14009e37d:     	je	0x14009e350 <.text+0x9d350>
14009e37f:     	movq	(%r12), %r13
14009e383:     	cmpl	$0x1, %r15d
14009e387:     	setne	%r15b
14009e38b:     	testq	%r13, %r13
14009e38e:     	sete	%r10b
14009e392:     	orb	%r15b, %r10b
14009e395:     	cmpb	$0x1, %r10b
14009e399:     	je	0x14009e350 <.text+0x9d350>
14009e39b:     	movq	0x260(%rbp), %r15
14009e3a2:     	cmpq	%r15, %r13
14009e3a5:     	setae	%r10b
14009e3a9:     	testb	%r10b, %bl
14009e3ac:     	jne	0x14009e415 <.text+0x9d415>
14009e3ae:     	movq	-0x28(%r12), %r10
14009e3b3:     	movq	%r10, 0x250(%rbp)
14009e3ba:     	movq	-0x20(%r12), %r10
14009e3bf:     	movq	%r10, 0x248(%rbp)
14009e3c6:     	movd	-0x4(%r12), %xmm6
14009e3cd:     	movzbl	-0x5(%r12), %r10d
14009e3d3:     	movb	%r10b, 0x26e(%rbp)
14009e3da:     	movzbl	-0x6(%r12), %r10d
14009e3e0:     	movb	%r10b, 0x26f(%rbp)
14009e3e7:     	movzwl	-0x8(%r12), %r10d
14009e3ed:     	movw	%r10w, 0x26c(%rbp)
14009e3f5:     	movl	-0xc(%r12), %r10d
14009e3fa:     	movl	%r10d, 0x268(%rbp)
14009e401:     	movl	-0x10(%r12), %r14d
14009e406:     	movq	-0x18(%r12), %r10
14009e40b:     	movq	%r10, 0x258(%rbp)
14009e412:     	movq	%r13, %r15
14009e415:     	movq	%r15, 0x260(%rbp)
14009e41c:     	incq	%rdi
14009e41f:     	movb	$0x1, %bl
14009e421:     	cmpq	%r8, %rdi
14009e424:     	jb	0x14009e33e <.text+0x9d33e>
14009e42a:     	jmp	0x14009e435 <.text+0x9d435>
14009e42c:     	testb	$0x1, %bl
14009e42f:     	je	0x14009e6f4 <.text+0x9d6f4>
14009e435:     	movq	0x250(%rbp), %r10
14009e43c:     	cmpq	%r11, %r10
14009e43f:     	jae	0x14009e495 <.text+0x9d495>
14009e441:     	movq	0x80(%rcx), %r11
14009e448:     	cmpb	$0x1, (%r11,%r10)
14009e44d:     	jne	0x14009e495 <.text+0x9d495>
14009e44f:     	cmpq	0xa0(%rcx), %r10
14009e456:     	jae	0x14009e466 <.text+0x9d466>
14009e458:     	movq	0x98(%rcx), %rsi
14009e45f:     	cmpb	$0x0, (%rsi,%r10)
14009e464:     	jne	0x14009e495 <.text+0x9d495>
14009e466:     	movb	$0x0, (%r11,%r10)
14009e46b:     	decq	0xb0(%rcx)
14009e472:     	cmpq	0x70(%rcx), %r10
14009e476:     	jae	0x14009e495 <.text+0x9d495>
14009e478:     	movq	0x68(%rcx), %r11
14009e47c:     	imulq	$0x58, %r10, %r10
14009e480:     	movq	$0x0, 0x30(%r11,%r10)
14009e489:     	movb	$0x2, 0x52(%r11,%r10)
14009e48f:     	movb	$0x2, 0x25(%r11,%r10)
14009e495:     	leaq	0xc0(%rcx), %rsi
14009e49c:     	movd	%xmm6, %r10d
14009e4a1:     	addq	$0x2c, %rax
14009e4a5:     	xorl	%r11d, %r11d
14009e4a8:     	movq	0x248(%rbp), %r15
14009e4af:     	movzbl	0x26e(%rbp), %r12d
14009e4b7:     	jmp	0x14009e4d2 <.text+0x9d4d2>
14009e4b9:     	nopl	(%rax)
14009e4c0:     	incq	%r11
14009e4c3:     	addq	$0x140, %rax            # imm = 0x140
14009e4c9:     	cmpq	%r11, %r8
14009e4cc:     	je	0x14009e55e <.text+0x9d55e>
14009e4d2:     	cmpq	%r9, %r11
14009e4d5:     	setb	%bl
14009e4d8:     	andb	(%rdx,%r11), %bl
14009e4dc:     	cmpb	$0x1, %bl
14009e4df:     	jne	0x14009e4c0 <.text+0x9d4c0>
14009e4e1:     	cmpl	$0x2, -0x2c(%rax)
14009e4e5:     	je	0x14009e4c0 <.text+0x9d4c0>
14009e4e7:     	cmpw	%r10w, (%rax)
14009e4eb:     	jne	0x14009e4c0 <.text+0x9d4c0>
14009e4ed:     	cmpl	%r14d, -0xc(%rax)
14009e4f1:     	jne	0x14009e4c0 <.text+0x9d4c0>
14009e4f3:     	movl	0x268(%rbp), %edi
14009e4f9:     	cmpl	%edi, -0x8(%rax)
14009e4fc:     	jne	0x14009e4c0 <.text+0x9d4c0>
14009e4fe:     	movzwl	0x26c(%rbp), %edi
14009e505:     	cmpw	%di, -0x4(%rax)
14009e509:     	jne	0x14009e4c0 <.text+0x9d4c0>
14009e50b:     	movzbl	0x26f(%rbp), %ebx
14009e512:     	cmpb	%bl, -0x2(%rax)
14009e515:     	jne	0x14009e4c0 <.text+0x9d4c0>
14009e517:     	movq	-0x1c(%rax), %rdi
14009e51b:     	xorq	%r15, %rdi
14009e51e:     	movq	-0x14(%rax), %rbx
14009e522:     	xorq	0x258(%rbp), %rbx
14009e529:     	orq	%rdi, %rbx
14009e52c:     	jne	0x14009e4c0 <.text+0x9d4c0>
14009e52e:     	cmpq	%r8, %r11
14009e531:     	jae	0x14009e55e <.text+0x9d55e>
14009e533:     	cmpq	0x100(%rcx), %r11
14009e53a:     	jae	0x14009e54a <.text+0x9d54a>
14009e53c:     	movq	0xf8(%rcx), %r8
14009e543:     	cmpb	$0x0, (%r8,%r11)
14009e548:     	jne	0x14009e55e <.text+0x9d55e>
14009e54a:     	movb	$0x0, (%rdx,%r11)
14009e54f:     	decq	0x110(%rcx)
14009e556:     	movq	$0x2, -0x2c(%rax)
14009e55e:     	xorps	%xmm7, %xmm7
14009e561:     	movaps	%xmm7, 0x230(%rbp)
14009e568:     	movb	$0x0, 0x212(%rbp)
14009e56f:     	movw	%r10w, 0x210(%rbp)
14009e577:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
14009e580:     	movq	$0x0, 0x213(%rbp)
14009e58b:     	movq	$0x8, 0x1f0(%rbp)
14009e596:     	movq	$0x0, 0x1f8(%rbp)
14009e5a1:     	movq	$0x1, 0x200(%rbp)
14009e5ac:     	movq	$0x0, 0x208(%rbp)
14009e5b7:     	leaq	0x220(%rbp), %rcx
14009e5be:     	leaq	0x1f0(%rbp), %rdx
14009e5c5:     	leaq	0x230(%rbp), %r8
14009e5cc:     	movl	$0x10, %r9d
14009e5d2:     	callq	0x140110570 <.text+0x10f570>
14009e5d7:     	cmpb	$0x0, 0x220(%rbp)
14009e5de:     	jne	0x14009e6f0 <.text+0x9d6f0>
14009e5e4:     	movq	0x228(%rbp), %rdi
14009e5eb:     	movaps	%xmm7, 0xe0(%rbp)
14009e5f2:     	movaps	%xmm7, 0xf0(%rbp)
14009e5f9:     	movaps	%xmm7, 0x100(%rbp)
14009e600:     	movaps	%xmm7, 0x110(%rbp)
14009e607:     	movaps	%xmm7, 0x120(%rbp)
14009e60e:     	movaps	%xmm7, 0x130(%rbp)
14009e615:     	movaps	%xmm7, 0x140(%rbp)
14009e61c:     	movaps	%xmm7, 0x150(%rbp)
14009e623:     	movaps	%xmm7, 0x160(%rbp)
14009e62a:     	movaps	%xmm7, 0x170(%rbp)
14009e631:     	movaps	%xmm7, 0x180(%rbp)
14009e638:     	movaps	%xmm7, 0x190(%rbp)
14009e63f:     	movaps	%xmm7, 0x1a0(%rbp)
14009e646:     	movaps	%xmm7, 0x1b0(%rbp)
14009e64d:     	movaps	%xmm7, 0x1c0(%rbp)
14009e654:     	movaps	%xmm7, 0x1d0(%rbp)
14009e65b:     	cmpq	$0x11, %rdi
14009e65f:     	jae	0x14009e718 <.text+0x9d718>
14009e665:     	leaq	0xe0(%rbp), %rbx
14009e66c:     	leaq	0x230(%rbp), %rdx
14009e673:     	movq	%rbx, %rcx
14009e676:     	movq	%rdi, %r8
14009e679:     	callq	0x14024edd0 <.text+0x24ddd0>
14009e67e:     	movw	%di, 0x1e0(%rbp)
14009e685:     	movq	$0x0, -0x60(%rbp)
14009e68d:     	movq	0x258(%rbp), %rax
14009e694:     	movq	%rax, -0x48(%rbp)
14009e698:     	movq	%r15, -0x50(%rbp)
14009e69c:     	movl	%r14d, -0x40(%rbp)
14009e6a0:     	movl	0x268(%rbp), %eax
14009e6a6:     	movl	%eax, -0x3c(%rbp)
14009e6a9:     	movzwl	0x26c(%rbp), %eax
14009e6b0:     	movw	%ax, -0x38(%rbp)
14009e6b4:     	movzbl	0x26f(%rbp), %eax
14009e6bb:     	movb	%al, -0x36(%rbp)
14009e6be:     	movb	%r12b, -0x35(%rbp)
14009e6c2:     	movd	%xmm6, -0x34(%rbp)
14009e6c7:     	movq	0x260(%rbp), %rax
14009e6ce:     	movq	%rax, -0x30(%rbp)
14009e6d2:     	leaq	-0x28(%rbp), %rcx
14009e6d6:     	movl	$0x108, %r8d            # imm = 0x108
14009e6dc:     	movq	%rbx, %rdx
14009e6df:     	callq	0x14024edd0 <.text+0x24ddd0>
14009e6e4:     	leaq	-0x60(%rbp), %rdx
14009e6e8:     	movq	%rsi, %rcx
14009e6eb:     	callq	0x1400116e0 <.text+0x106e0>
14009e6f0:     	movb	$0x1, %al
14009e6f2:     	jmp	0x14009e6f6 <.text+0x9d6f6>
14009e6f4:     	xorl	%eax, %eax
14009e6f6:     	movaps	0x270(%rbp), %xmm6
14009e6fd:     	movaps	0x280(%rbp), %xmm7
14009e704:     	addq	$0x318, %rsp            # imm = 0x318
14009e70b:     	popq	%rbx
14009e70c:     	popq	%rdi
14009e70d:     	popq	%rsi
14009e70e:     	popq	%r12
14009e710:     	popq	%r13
14009e712:     	popq	%r14
14009e714:     	popq	%r15
14009e716:     	popq	%rbp
14009e717:     	retq
14009e718:     	leaq	0x1c9449(%rip), %r9     # 0x140267b68
14009e71f:     	movl	$0x10, %r8d
14009e725:     	xorl	%ecx, %ecx
14009e727:     	movq	%rdi, %rdx
14009e72a:     	callq	0x14024f820 <.text+0x24e820>
14009e72f:     	ud2

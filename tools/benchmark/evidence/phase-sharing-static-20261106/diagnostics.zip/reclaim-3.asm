
D:\CoapticCurrent\phase-sharing-static-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009df20:     	pushq	%rbp
14009df21:     	pushq	%r15
14009df23:     	pushq	%r14
14009df25:     	pushq	%r13
14009df27:     	pushq	%r12
14009df29:     	pushq	%rsi
14009df2a:     	pushq	%rdi
14009df2b:     	pushq	%rbx
14009df2c:     	subq	$0x308, %rsp            # imm = 0x308
14009df33:     	leaq	0x80(%rsp), %rbp
14009df3b:     	movaps	%xmm7, 0x270(%rbp)
14009df42:     	movaps	%xmm6, 0x260(%rbp)
14009df49:     	leaq	0x5000(%rcx), %rax
14009df50:     	leaq	0x30(%rcx), %r8
14009df54:     	xorl	%r9d, %r9d
14009df57:     	xorl	%esi, %esi
14009df59:     	leaq	(%rsi,%rsi,4), %r11
14009df5d:     	shlq	$0x6, %r11
14009df61:     	addq	%r8, %r11
14009df64:     	movq	%rsi, %r10
14009df67:     	jmp	0x14009df84 <.text+0x9cf84>
14009df69:     	nopl	(%rax)
14009df70:     	incq	%r10
14009df73:     	addq	$0x140, %r11            # imm = 0x140
14009df7a:     	cmpq	$0x40, %r10
14009df7e:     	je	0x14009e01e <.text+0x9d01e>
14009df84:     	cmpb	$0x1, 0x5000(%rcx,%r10)
14009df8d:     	jne	0x14009df70 <.text+0x9cf70>
14009df8f:     	movq	-0x30(%r11), %rdi
14009df93:     	cmpq	$0x2, %rdi
14009df97:     	je	0x14009df70 <.text+0x9cf70>
14009df99:     	movq	(%r11), %rsi
14009df9c:     	cmpl	$0x1, %edi
14009df9f:     	setne	%bl
14009dfa2:     	testq	%rsi, %rsi
14009dfa5:     	sete	%dil
14009dfa9:     	orb	%bl, %dil
14009dfac:     	cmpb	$0x1, %dil
14009dfb0:     	je	0x14009df70 <.text+0x9cf70>
14009dfb2:     	movq	0x250(%rbp), %rdi
14009dfb9:     	cmpq	%rdi, %rsi
14009dfbc:     	setae	%bl
14009dfbf:     	testb	%bl, %r9b
14009dfc2:     	jne	0x14009e004 <.text+0x9d004>
14009dfc4:     	movd	-0x4(%r11), %xmm6
14009dfca:     	movzbl	-0x5(%r11), %edx
14009dfcf:     	movb	%dl, 0x25f(%rbp)
14009dfd5:     	movzbl	-0x6(%r11), %r15d
14009dfda:     	movzwl	-0x8(%r11), %r12d
14009dfdf:     	movl	-0xc(%r11), %r13d
14009dfe3:     	movl	-0x10(%r11), %r14d
14009dfe7:     	movq	-0x18(%r11), %rdx
14009dfeb:     	movq	%rdx, 0x248(%rbp)
14009dff2:     	movq	-0x28(%r11), %rdx
14009dff6:     	movq	-0x20(%r11), %r9
14009dffa:     	movq	%r9, 0x240(%rbp)
14009e001:     	movq	%rsi, %rdi
14009e004:     	movq	%rdi, 0x250(%rbp)
14009e00b:     	leaq	0x1(%r10), %rsi
14009e00f:     	movb	$0x1, %r9b
14009e012:     	cmpq	$0x3f, %r10
14009e016:     	jb	0x14009df59 <.text+0x9cf59>
14009e01c:     	jmp	0x14009e028 <.text+0x9d028>
14009e01e:     	testb	$0x1, %r9b
14009e022:     	je	0x14009e2a0 <.text+0x9d2a0>
14009e028:     	cmpq	$0x1f, %rdx
14009e02c:     	ja	0x14009e07f <.text+0x9d07f>
14009e02e:     	leaq	0x37740(%rcx), %r8
14009e035:     	cmpb	$0x1, (%r8,%rdx)
14009e03a:     	jne	0x14009e07f <.text+0x9d07f>
14009e03c:     	cmpb	$0x0, 0x37760(%rcx,%rdx)
14009e044:     	jne	0x14009e07f <.text+0x9d07f>
14009e046:     	movb	$0x0, 0x37740(%rcx,%rdx)
14009e04e:     	decq	0x37788(%rcx)
14009e055:     	movq	$0x0, 0x43610(%rcx,%rdx,8)
14009e061:     	leaq	(%rdx,%rdx,8), %r9
14009e065:     	leaq	(%r9,%r9,2), %r9
14009e069:     	addq	%rdx, %r9
14009e06c:     	movb	$0x2, 0x36a(%r8,%r9)
14009e075:     	leaq	(%rdx,%rdx,2), %rdx
14009e079:     	movb	$0x2, 0x5d(%r8,%rdx,8)
14009e07f:     	movd	%xmm6, %edx
14009e083:     	movl	$0x2c, %r8d
14009e089:     	movq	0x240(%rbp), %r11
14009e090:     	movq	0x248(%rbp), %rsi
14009e097:     	jmp	0x14009e0b3 <.text+0x9d0b3>
14009e099:     	nopl	(%rax)
14009e0a0:     	incq	%rax
14009e0a3:     	addq	$0x140, %r8             # imm = 0x140
14009e0aa:     	cmpq	$0x502c, %r8            # imm = 0x502C
14009e0b1:     	je	0x14009e10c <.text+0x9d10c>
14009e0b3:     	cmpb	$0x1, (%rax)
14009e0b6:     	jne	0x14009e0a0 <.text+0x9d0a0>
14009e0b8:     	cmpl	$0x2, -0x2c(%rcx,%r8)
14009e0be:     	je	0x14009e0a0 <.text+0x9d0a0>
14009e0c0:     	cmpw	%dx, (%rcx,%r8)
14009e0c5:     	jne	0x14009e0a0 <.text+0x9d0a0>
14009e0c7:     	cmpl	%r14d, -0xc(%rcx,%r8)
14009e0cc:     	jne	0x14009e0a0 <.text+0x9d0a0>
14009e0ce:     	cmpl	%r13d, -0x8(%rcx,%r8)
14009e0d3:     	jne	0x14009e0a0 <.text+0x9d0a0>
14009e0d5:     	cmpw	%r12w, -0x4(%rcx,%r8)
14009e0db:     	jne	0x14009e0a0 <.text+0x9d0a0>
14009e0dd:     	cmpb	%r15b, -0x2(%rcx,%r8)
14009e0e2:     	jne	0x14009e0a0 <.text+0x9d0a0>
14009e0e4:     	movq	-0x1c(%rcx,%r8), %r9
14009e0e9:     	xorq	%r11, %r9
14009e0ec:     	movq	-0x14(%rcx,%r8), %r10
14009e0f1:     	xorq	%rsi, %r10
14009e0f4:     	orq	%r9, %r10
14009e0f7:     	jne	0x14009e0a0 <.text+0x9d0a0>
14009e0f9:     	movb	$0x0, (%rax)
14009e0fc:     	decq	0x5048(%rcx)
14009e103:     	movq	$0x2, -0x2c(%rcx,%r8)
14009e10c:     	movq	%rcx, %rsi
14009e10f:     	xorps	%xmm7, %xmm7
14009e112:     	movaps	%xmm7, 0x230(%rbp)
14009e119:     	movb	$0x0, 0x212(%rbp)
14009e120:     	movw	%dx, 0x210(%rbp)
14009e127:     	movw	$0x200, 0x21b(%rbp)     # imm = 0x200
14009e130:     	movq	$0x0, 0x213(%rbp)
14009e13b:     	movq	$0x8, 0x1f0(%rbp)
14009e146:     	movq	$0x0, 0x1f8(%rbp)
14009e151:     	movq	$0x1, 0x200(%rbp)
14009e15c:     	movq	$0x0, 0x208(%rbp)
14009e167:     	leaq	0x220(%rbp), %rcx
14009e16e:     	leaq	0x1f0(%rbp), %rdx
14009e175:     	leaq	0x230(%rbp), %r8
14009e17c:     	movl	$0x10, %r9d
14009e182:     	callq	0x140110570 <.text+0x10f570>
14009e187:     	cmpb	$0x0, 0x220(%rbp)
14009e18e:     	jne	0x14009e29c <.text+0x9d29c>
14009e194:     	movq	0x228(%rbp), %rdi
14009e19b:     	movaps	%xmm7, 0xe0(%rbp)
14009e1a2:     	movaps	%xmm7, 0xf0(%rbp)
14009e1a9:     	movaps	%xmm7, 0x100(%rbp)
14009e1b0:     	movaps	%xmm7, 0x110(%rbp)
14009e1b7:     	movaps	%xmm7, 0x120(%rbp)
14009e1be:     	movaps	%xmm7, 0x130(%rbp)
14009e1c5:     	movaps	%xmm7, 0x140(%rbp)
14009e1cc:     	movaps	%xmm7, 0x150(%rbp)
14009e1d3:     	movaps	%xmm7, 0x160(%rbp)
14009e1da:     	movaps	%xmm7, 0x170(%rbp)
14009e1e1:     	movaps	%xmm7, 0x180(%rbp)
14009e1e8:     	movaps	%xmm7, 0x190(%rbp)
14009e1ef:     	movaps	%xmm7, 0x1a0(%rbp)
14009e1f6:     	movaps	%xmm7, 0x1b0(%rbp)
14009e1fd:     	movaps	%xmm7, 0x1c0(%rbp)
14009e204:     	movaps	%xmm7, 0x1d0(%rbp)
14009e20b:     	cmpq	$0x11, %rdi
14009e20f:     	jae	0x14009e2c4 <.text+0x9d2c4>
14009e215:     	leaq	0xe0(%rbp), %rbx
14009e21c:     	leaq	0x230(%rbp), %rdx
14009e223:     	movq	%rbx, %rcx
14009e226:     	movq	%rdi, %r8
14009e229:     	callq	0x14024edd0 <.text+0x24ddd0>
14009e22e:     	movw	%di, 0x1e0(%rbp)
14009e235:     	movq	$0x0, -0x60(%rbp)
14009e23d:     	movq	0x248(%rbp), %rax
14009e244:     	movq	%rax, -0x48(%rbp)
14009e248:     	movq	0x240(%rbp), %rax
14009e24f:     	movq	%rax, -0x50(%rbp)
14009e253:     	movl	%r14d, -0x40(%rbp)
14009e257:     	movl	%r13d, -0x3c(%rbp)
14009e25b:     	movw	%r12w, -0x38(%rbp)
14009e260:     	movb	%r15b, -0x36(%rbp)
14009e264:     	movzbl	0x25f(%rbp), %eax
14009e26b:     	movb	%al, -0x35(%rbp)
14009e26e:     	movd	%xmm6, -0x34(%rbp)
14009e273:     	movq	0x250(%rbp), %rax
14009e27a:     	movq	%rax, -0x30(%rbp)
14009e27e:     	leaq	-0x28(%rbp), %rcx
14009e282:     	movl	$0x108, %r8d            # imm = 0x108
14009e288:     	movq	%rbx, %rdx
14009e28b:     	callq	0x14024edd0 <.text+0x24ddd0>
14009e290:     	leaq	-0x60(%rbp), %rdx
14009e294:     	movq	%rsi, %rcx
14009e297:     	callq	0x140213dd0 <.text+0x212dd0>
14009e29c:     	movb	$0x1, %al
14009e29e:     	jmp	0x14009e2a2 <.text+0x9d2a2>
14009e2a0:     	xorl	%eax, %eax
14009e2a2:     	movaps	0x260(%rbp), %xmm6
14009e2a9:     	movaps	0x270(%rbp), %xmm7
14009e2b0:     	addq	$0x308, %rsp            # imm = 0x308
14009e2b7:     	popq	%rbx
14009e2b8:     	popq	%rdi
14009e2b9:     	popq	%rsi
14009e2ba:     	popq	%r12
14009e2bc:     	popq	%r13
14009e2be:     	popq	%r14
14009e2c0:     	popq	%r15
14009e2c2:     	popq	%rbp
14009e2c3:     	retq
14009e2c4:     	leaq	0x1c989d(%rip), %r9     # 0x140267b68
14009e2cb:     	movl	$0x10, %r8d
14009e2d1:     	xorl	%ecx, %ecx
14009e2d3:     	movq	%rdi, %rdx
14009e2d6:     	callq	0x14024f820 <.text+0x24e820>
14009e2db:     	ud2

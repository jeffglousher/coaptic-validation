
D:\CoapticCurrent\phase-sharing-static-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009d820:     	pushq	%rbp
14009d821:     	pushq	%r15
14009d823:     	pushq	%r14
14009d825:     	pushq	%r13
14009d827:     	pushq	%r12
14009d829:     	pushq	%rsi
14009d82a:     	pushq	%rdi
14009d82b:     	pushq	%rbx
14009d82c:     	subq	$0x318, %rsp            # imm = 0x318
14009d833:     	leaq	0x80(%rsp), %rbp
14009d83b:     	movaps	%xmm7, 0x280(%rbp)
14009d842:     	movaps	%xmm6, 0x270(%rbp)
14009d849:     	leaq	0x30(%rcx), %rdx
14009d84d:     	xorl	%r8d, %r8d
14009d850:     	xorl	%r11d, %r11d
14009d853:     	leaq	(%r11,%r11,4), %r10
14009d857:     	shlq	$0x6, %r10
14009d85b:     	addq	%rdx, %r10
14009d85e:     	movq	%r11, %r9
14009d861:     	jmp	0x14009d884 <.text+0x9c884>
14009d863:     	nopw	%cs:(%rax,%rax)
14009d870:     	incq	%r9
14009d873:     	addq	$0x140, %r10            # imm = 0x140
14009d87a:     	cmpq	$0x4, %r9
14009d87e:     	je	0x14009d90e <.text+0x9c90e>
14009d884:     	cmpb	$0x1, 0x510(%rcx,%r9)
14009d88d:     	jne	0x14009d870 <.text+0x9c870>
14009d88f:     	movq	-0x30(%r10), %rsi
14009d893:     	cmpq	$0x2, %rsi
14009d897:     	je	0x14009d870 <.text+0x9c870>
14009d899:     	movq	(%r10), %r11
14009d89c:     	cmpl	$0x1, %esi
14009d89f:     	setne	%bl
14009d8a2:     	testq	%r11, %r11
14009d8a5:     	sete	%sil
14009d8a9:     	orb	%bl, %sil
14009d8ac:     	cmpb	$0x1, %sil
14009d8b0:     	je	0x14009d870 <.text+0x9c870>
14009d8b2:     	movq	0x268(%rbp), %rsi
14009d8b9:     	cmpq	%rsi, %r11
14009d8bc:     	setae	%bl
14009d8bf:     	testb	%bl, %r8b
14009d8c2:     	jne	0x14009d8f4 <.text+0x9c8f4>
14009d8c4:     	movq	-0x28(%r10), %rax
14009d8c8:     	movd	-0x4(%r10), %xmm6
14009d8ce:     	movzbl	-0x5(%r10), %edi
14009d8d3:     	movzbl	-0x6(%r10), %r15d
14009d8d8:     	movzwl	-0x8(%r10), %r12d
14009d8dd:     	movl	-0xc(%r10), %r13d
14009d8e1:     	movl	-0x10(%r10), %r14d
14009d8e5:     	movups	-0x20(%r10), %xmm0
14009d8ea:     	movaps	%xmm0, 0x240(%rbp)
14009d8f1:     	movq	%r11, %rsi
14009d8f4:     	movq	%rsi, 0x268(%rbp)
14009d8fb:     	leaq	0x1(%r9), %r11
14009d8ff:     	movb	$0x1, %r8b
14009d902:     	cmpq	$0x3, %r9
14009d906:     	jb	0x14009d853 <.text+0x9c853>
14009d90c:     	jmp	0x14009d918 <.text+0x9c918>
14009d90e:     	testb	$0x1, %r8b
14009d912:     	je	0x14009db58 <.text+0x9cb58>
14009d918:     	cmpq	$0x1, %rax
14009d91c:     	ja	0x14009d974 <.text+0x9c974>
14009d91e:     	cmpb	$0x1, 0x1e80(%rcx,%rax)
14009d926:     	jne	0x14009d974 <.text+0x9c974>
14009d928:     	cmpb	$0x0, 0x1e82(%rcx,%rax)
14009d930:     	jne	0x14009d974 <.text+0x9c974>
14009d932:     	movb	$0x0, 0x1e80(%rcx,%rax)
14009d93a:     	decq	0x1e78(%rcx)
14009d941:     	leaq	0x14f8(%rcx), %rdx
14009d948:     	movq	$0x0, 0x1df8(%rcx,%rax,8)
14009d954:     	leaq	(%rax,%rax,8), %r8
14009d958:     	leaq	(%r8,%r8,2), %r8
14009d95c:     	addq	%rax, %r8
14009d95f:     	movb	$0x2, 0x95a(%rdx,%r8)
14009d968:     	leaq	(%rax,%rax,2), %rax
14009d96c:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009d974:     	movaps	0x240(%rbp), %xmm0
14009d97b:     	movaps	%xmm0, -0x60(%rbp)
14009d97f:     	movl	%r14d, %esi
14009d982:     	movl	%r14d, -0x50(%rbp)
14009d986:     	movl	%r13d, %r14d
14009d989:     	movl	%r13d, -0x4c(%rbp)
14009d98d:     	movl	%r12d, %r13d
14009d990:     	movw	%r12w, -0x48(%rbp)
14009d995:     	movl	%r15d, %r12d
14009d998:     	movb	%r15b, -0x46(%rbp)
14009d99c:     	movl	%edi, %r15d
14009d99f:     	movb	%dil, -0x45(%rbp)
14009d9a3:     	movd	%xmm6, %edi
14009d9a7:     	movd	%xmm6, -0x44(%rbp)
14009d9ac:     	leaq	-0x60(%rbp), %rdx
14009d9b0:     	movq	%rcx, 0x260(%rbp)
14009d9b7:     	callq	0x140214200 <.text+0x213200>
14009d9bc:     	xorps	%xmm7, %xmm7
14009d9bf:     	movaps	%xmm7, 0x250(%rbp)
14009d9c6:     	movb	$0x0, 0x222(%rbp)
14009d9cd:     	movw	%di, 0x220(%rbp)
14009d9d4:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009d9dd:     	movq	$0x0, 0x223(%rbp)
14009d9e8:     	movq	$0x8, 0x200(%rbp)
14009d9f3:     	movq	$0x0, 0x208(%rbp)
14009d9fe:     	movq	$0x1, 0x210(%rbp)
14009da09:     	movq	$0x0, 0x218(%rbp)
14009da14:     	leaq	0x230(%rbp), %rcx
14009da1b:     	leaq	0x200(%rbp), %rdx
14009da22:     	leaq	0x250(%rbp), %r8
14009da29:     	movl	$0x10, %r9d
14009da2f:     	callq	0x140110570 <.text+0x10f570>
14009da34:     	cmpb	$0x0, 0x230(%rbp)
14009da3b:     	jne	0x14009db54 <.text+0x9cb54>
14009da41:     	movq	0x238(%rbp), %rdi
14009da48:     	movaps	%xmm7, 0xe0(%rbp)
14009da4f:     	movaps	%xmm7, 0xf0(%rbp)
14009da56:     	movaps	%xmm7, 0x100(%rbp)
14009da5d:     	movaps	%xmm7, 0x110(%rbp)
14009da64:     	movaps	%xmm7, 0x120(%rbp)
14009da6b:     	movaps	%xmm7, 0x130(%rbp)
14009da72:     	movaps	%xmm7, 0x140(%rbp)
14009da79:     	movaps	%xmm7, 0x150(%rbp)
14009da80:     	movaps	%xmm7, 0x160(%rbp)
14009da87:     	movaps	%xmm7, 0x170(%rbp)
14009da8e:     	movaps	%xmm7, 0x180(%rbp)
14009da95:     	movaps	%xmm7, 0x190(%rbp)
14009da9c:     	movaps	%xmm7, 0x1a0(%rbp)
14009daa3:     	movaps	%xmm7, 0x1b0(%rbp)
14009daaa:     	movaps	%xmm7, 0x1c0(%rbp)
14009dab1:     	movaps	%xmm7, 0x1d0(%rbp)
14009dab8:     	movaps	0x240(%rbp), %xmm0
14009dabf:     	movups	%xmm0, 0x1f0(%rbp)
14009dac6:     	cmpq	$0x11, %rdi
14009daca:     	jae	0x14009db7c <.text+0x9cb7c>
14009dad0:     	leaq	0xe0(%rbp), %rbx
14009dad7:     	leaq	0x250(%rbp), %rdx
14009dade:     	movq	%rbx, %rcx
14009dae1:     	movq	%rdi, %r8
14009dae4:     	callq	0x14024edd0 <.text+0x24ddd0>
14009dae9:     	movw	%di, 0x1e0(%rbp)
14009daf0:     	movq	$0x0, -0x60(%rbp)
14009daf8:     	movups	0x1e8(%rbp), %xmm0
14009daff:     	movups	%xmm0, -0x58(%rbp)
14009db03:     	movq	0x1f8(%rbp), %rax
14009db0a:     	movq	%rax, -0x48(%rbp)
14009db0e:     	movl	%esi, -0x40(%rbp)
14009db11:     	movl	%r14d, -0x3c(%rbp)
14009db15:     	movw	%r13w, -0x38(%rbp)
14009db1a:     	movb	%r12b, -0x36(%rbp)
14009db1e:     	movb	%r15b, -0x35(%rbp)
14009db22:     	movd	%xmm6, -0x34(%rbp)
14009db27:     	movq	0x268(%rbp), %rax
14009db2e:     	movq	%rax, -0x30(%rbp)
14009db32:     	leaq	-0x28(%rbp), %rcx
14009db36:     	movl	$0x108, %r8d            # imm = 0x108
14009db3c:     	movq	%rbx, %rdx
14009db3f:     	callq	0x14024edd0 <.text+0x24ddd0>
14009db44:     	leaq	-0x60(%rbp), %rdx
14009db48:     	movq	0x260(%rbp), %rcx
14009db4f:     	callq	0x140213f70 <.text+0x212f70>
14009db54:     	movb	$0x1, %al
14009db56:     	jmp	0x14009db5a <.text+0x9cb5a>
14009db58:     	xorl	%eax, %eax
14009db5a:     	movaps	0x270(%rbp), %xmm6
14009db61:     	movaps	0x280(%rbp), %xmm7
14009db68:     	addq	$0x318, %rsp            # imm = 0x318
14009db6f:     	popq	%rbx
14009db70:     	popq	%rdi
14009db71:     	popq	%rsi
14009db72:     	popq	%r12
14009db74:     	popq	%r13
14009db76:     	popq	%r14
14009db78:     	popq	%r15
14009db7a:     	popq	%rbp
14009db7b:     	retq
14009db7c:     	leaq	0x1c9fe5(%rip), %r9     # 0x140267b68
14009db83:     	movl	$0x10, %r8d
14009db89:     	xorl	%ecx, %ecx
14009db8b:     	movq	%rdi, %rdx
14009db8e:     	callq	0x14024f820 <.text+0x24e820>
14009db93:     	ud2

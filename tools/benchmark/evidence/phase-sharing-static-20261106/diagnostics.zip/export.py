"""Retain the completed cohort without executing or replacing measurements."""
from pathlib import Path
import hashlib, json, re, shutil, zipfile

root = Path(__file__).resolve().parent
out = Path('D:/codex-work/coaptic-validation/tools/benchmark/evidence/phase-sharing-static-20261106')
prior = out.parent / 'replay-chunk-staging-20261106'
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
write = lambda p, x: p.write_text(json.dumps(x, indent=2) + '\n', encoding='utf-8')
assert read(root / 'measurement.json')['status'] == 'complete'
out.mkdir(exist_ok=True)
for name in ['candidate.patch', 'fixture-sha256.json', 'METHOD-BEFORE.json', 'METHOD.json', 'measurement.json', 'reclaim-frames.json']:
    shutil.copyfile(root / name, out / name)
source = read(root / 'source-verification.json')
source['patch_sha256'] = {'candidate.patch': source['patch_sha256']}
write(out / 'source-verification.json', source)
for name in ['.gitattributes']:
    shutil.copyfile(prior / name, out / name)
shutil.copyfile(root / 'portable-prepare.py', out / 'prepare.py')
layout = (root / 'owner-layout.txt').read_text()
owners = []
for line in layout.splitlines():
    m = re.match(r'print-type-size type: `(.*)`: (\d+) bytes, alignment: (\d+) bytes', line)
    if m:
        owners.append({'type': m[1], 'bytes': int(m[2]), 'alignment': int(m[3]), 'fields': []})
    else:
        m = re.match(r'print-type-size     field `(.*)`: (\d+) bytes', line)
        if m and owners:
            owners[-1]['fields'].append({'name': m[1], 'bytes': int(m[2])})
write(root / 'owners.json', owners)
write(out / 'owners.json', owners)
memory = read(prior / 'memory-comparison.json')
actual={}
for owner,profile,size,field in [('SmallDevice App','small-device',32,'app_including_transport_inline_bytes'),('Service fixed App','service-fixed',1024,'server_app_including_transport_inline_bytes'),('Service allocated App','service-allocated',1024,'server_app_including_transport_inline_bytes'),('Service allocated pool heap','service-allocated',1024,'server_pool_requested_heap_bytes')]:
 actual[owner]=read(root/f'qualify-B-ordinary-{profile}-unprotected-sync-{size}.json')['memory'][field]
for row in memory['rows']:
    row['candidate'] = actual.get(row['owner'], row['baseline'])
for record in memory['layout_records']:
    if 'baseline-future-layout.txt' not in record['file']:
        prefix = record['record'].split('`: ')[0] + '`: '
        record['record'] = next(line for line in layout.splitlines() if line.startswith(prefix))
        record['file'] = str(root / 'owner-layout.txt')
        next(row for row in memory['rows'] if row['owner']==record['owner'])['candidate']=int(re.search(r'`: (\d+) bytes',record['record'])[1])
memory['candidate_layout_sha256'] = hashlib.sha256((root / 'owner-layout.txt').read_bytes()).hexdigest()
memory['warning'] = memory['warning'].split(' Allocator metadata/rounding')[0] + ' Requested heap excludes allocator metadata and rounding. Startup allocation count matches baseline; no separate deadline allocation.'
write(root / 'memory-comparison.json', memory)
write(out / 'memory-comparison.json', memory)

def archive(name, files, relative):
    hashes = {}
    with zipfile.ZipFile(out / (name + '.zip'), 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(set(files)):
            member = relative(p)
            data = p.read_bytes()
            hashes[member] = hashlib.sha256(data).hexdigest()
            z.writestr(member, data)
    write(out / ({'observations': 'observation', 'diagnostics': 'diagnostic'}.get(name, name) + '-sha256.json'), hashes)

files = [p for pat in ['measure-*.json', 'measure-*.stderr', 'qualify-*.json', 'qualify-*.stderr'] for p in root.glob(pat)]
files += [root / n for n in ['METHOD.json', 'METHOD-BEFORE.json', 'measurement.json', 'measure.py', 'source-verification.json', 'fixture-sha256.json', 'owner-layout.txt', 'owners.json', 'memory-comparison.json', 'process-exits.jsonl']]
files += list((root / 'B').glob('*'))
archive('observations', files, lambda p: 'candidate/' + p.relative_to(root).as_posix())
files = [p for p in root.iterdir() if p.is_file() and (p.suffix in ['.asm', '.log', '.py', '.patch'] or p.name in ['encoder-frames.json', 'candidate-encoder-symbols.txt', 'build-results.json', 'review.txt', 'preflight-host.json', 'reclaim-frames.json', 'reclaim-symbols.txt', 'baseline-reclaim-symbols.txt', 'inline-replay-symbols.txt', 'inline-replay.json', 'preflight-copy.json', 'qualification.json', 'focused-checks.json', 'development-note.txt', 'short-writer-callers.json', 'candidate-procedures.json', 'previous-procedures.json', 'baseline-procedures.json', 'inspection-note.txt', 'check-reuse.json', 'initial-focused-checks.json', 'initial-source-verification.json', 'initial-METHOD-BEFORE.json', 'reproduction-check.json', 'reproduction-initial.json'])]
archive('diagnostics', files, lambda p: p.name)
archive('layout32', [p for p in (root / 'layout32').iterdir() if p.is_file()], lambda p: p.name)
layout32 = read(prior / 'layout32-comparison.json')
layout32['candidate'] = source['source']
for row in layout32['rows']:
    prefix = row['baseline_record'].split('`: ')[0] + '`: '
    row['candidate_record'] = next(line for line in (root / 'layout32/candidate-layout.txt').read_text().splitlines() if line.startswith(prefix))
    row['candidate'] = int(row['candidate_record'].split('`: ')[1].split(' ')[0])
layout32['memory_nongrowth'] = all(r['candidate'] <= r['baseline'] for r in layout32['rows'])
assert layout32['memory_nongrowth']
write(out / 'layout32-comparison.json', layout32)
v = (prior / 'verify.py').read_text()
start = v.index('        if kind == "ordinary":')
end = v.index('        count = 8192', start)
v = v[:start] + """        if kind == 'ordinary':
            assert set(a['memory'])==set(b['memory'])
            reducible={'app_including_transport_inline_bytes','server_app_including_transport_inline_bytes','server_pool_requested_heap_bytes','client_app_including_transport_inline_bytes','client_pool_requested_heap_bytes'}
            for key,value in a['memory'].items():
                if key in reducible:assert type(b['memory'][key]) is int and 0<=b['memory'][key]<=value
                else:assert b['memory'][key]==value
            if profile=='small-device':assert b['memory']['app_including_transport_inline_bytes']<=a['memory']['app_including_transport_inline_bytes']
            else:
                keys=['server_app_including_transport_inline_bytes','server_pool_requested_heap_bytes']
                assert sum(b['memory'][k] for k in keys)<=sum(a['memory'][k] for k in keys)
        else:
            assert b['app_inline_bytes']<=a['app_inline_bytes']
            if profile=='fixed':assert b['app_inline_bytes']<=a['app_inline_bytes']
""" + v[end:]
v = v.replace('== layout32["memory_nongrowth"] == False', '== layout32["memory_nongrowth"] == True')
v = v.replace('== [16, 256, 0, -8, 16, 256]', '== [0, 0, 0, 0, 0, 0]')
v = v.replace('32-bit layout regression verified; this integration is rejected independently of the CPU result', '32-bit selected object nongrowth verified; no target runtime claim')
(out / 'verify.py').write_text(v)
print(json.dumps({'output': str(out), 'bytes': sum(p.stat().st_size for p in out.iterdir() if p.is_file())}))

with (out/'verify.py').open('a') as f:
    f.write("\nwith zipfile.ZipFile(ROOT / 'diagnostics.zip') as archive:\n    reclaim = json.loads(archive.read('reclaim-frames.json'))\n    assert reclaim == json.loads((ROOT/'reclaim-frames.json').read_text())\n    assert reclaim['nongrowth'] and len(reclaim['rows']) == 4\n    for row in reclaim['rows']:\n        assert row['candidate'] <= row['baseline']\n        assert hashlib.sha256(archive.read(row['assembly'])).hexdigest() == row['sha256']\nprint('Selected reclaim frames nongrowing; not peak-stack evidence')\n")

with (out/'verify.py').open('a') as f:
 f.write("\nassert all(row['candidate']<row['baseline'] for row in memory['rows'] if row['owner'].startswith('Service') and 'complete progress future' in row['owner'])\nwith zipfile.ZipFile(ROOT/'diagnostics.zip') as archive:\n    checks=json.loads(archive.read('focused-checks.json'))\n    assert len(checks)==3 and all(c['exit_code']==0 for c in checks)\nprint('Complete Service future shrink and focused checks verified')\n")

archive('untimed-precursor', [p for p in (root/'untimed-precursor').rglob('*') if p.is_file()], lambda p:p.relative_to(root/'untimed-precursor').as_posix())
with (out/'verify.py').open('a') as f:
 f.write("\nwith zipfile.ZipFile(ROOT/'untimed-precursor.zip') as z:\n    for n,h in json.loads((ROOT/'untimed-precursor-sha256.json').read_text()).items():\n        assert hashlib.sha256(z.read(n)).hexdigest()==h,n\nprint('Untimed8-byte growth failure retained and verified')\n")

shutil.copyfile(root/'qualification.json', out/'qualification.json')
shutil.copyfile(root/'reproduction-check.json', out/'reproduction-check.json')
with (out/'verify.py').open('a', encoding='utf-8') as f:
    f.write("\nwith zipfile.ZipFile(ROOT/'diagnostics.zip') as z:\n    checks=json.loads(z.read('qualification.json'))\n    assert checks==json.loads((ROOT/'qualification.json').read_text())\n    assert [v['name'] for v in checks]==['clippy-no-default','test-all','test-no-default','test-alloc','test-oscore','test-std','msrv-no-default','msrv-all','docs']\n    assert all(v['exit_code']==0 for v in checks)\n    assert all(v['name']+'.log' in z.namelist() for v in checks)\n    proof=json.loads(z.read('reproduction-check.json'))\n    assert proof==json.loads((ROOT/'reproduction-check.json').read_text())\n    assert proof['reconstructed_core_files']==148 and proof['source']==json.loads((ROOT/'source-verification.json').read_text())['source']\nprint('Nine final qualification lanes and exact LF source reconstruction verified')\n")

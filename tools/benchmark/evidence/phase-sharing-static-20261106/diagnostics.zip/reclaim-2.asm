
D:\CoapticCurrent\phase-sharing-static-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009dba0:     	pushq	%rbp
14009dba1:     	pushq	%r15
14009dba3:     	pushq	%r14
14009dba5:     	pushq	%r13
14009dba7:     	pushq	%r12
14009dba9:     	pushq	%rsi
14009dbaa:     	pushq	%rdi
14009dbab:     	pushq	%rbx
14009dbac:     	subq	$0x318, %rsp            # imm = 0x318
14009dbb3:     	leaq	0x80(%rsp), %rbp
14009dbbb:     	movaps	%xmm7, 0x280(%rbp)
14009dbc2:     	movaps	%xmm6, 0x270(%rbp)
14009dbc9:     	leaq	0x30(%rcx), %rdx
14009dbcd:     	xorl	%r8d, %r8d
14009dbd0:     	xorl	%r11d, %r11d
14009dbd3:     	leaq	(%r11,%r11,4), %r10
14009dbd7:     	shlq	$0x6, %r10
14009dbdb:     	addq	%rdx, %r10
14009dbde:     	movq	%r11, %r9
14009dbe1:     	jmp	0x14009dc04 <.text+0x9cc04>
14009dbe3:     	nopw	%cs:(%rax,%rax)
14009dbf0:     	incq	%r9
14009dbf3:     	addq	$0x140, %r10            # imm = 0x140
14009dbfa:     	cmpq	$0x4, %r9
14009dbfe:     	je	0x14009dc8e <.text+0x9cc8e>
14009dc04:     	cmpb	$0x1, 0x510(%rcx,%r9)
14009dc0d:     	jne	0x14009dbf0 <.text+0x9cbf0>
14009dc0f:     	movq	-0x30(%r10), %rsi
14009dc13:     	cmpq	$0x2, %rsi
14009dc17:     	je	0x14009dbf0 <.text+0x9cbf0>
14009dc19:     	movq	(%r10), %r11
14009dc1c:     	cmpl	$0x1, %esi
14009dc1f:     	setne	%bl
14009dc22:     	testq	%r11, %r11
14009dc25:     	sete	%sil
14009dc29:     	orb	%bl, %sil
14009dc2c:     	cmpb	$0x1, %sil
14009dc30:     	je	0x14009dbf0 <.text+0x9cbf0>
14009dc32:     	movq	0x268(%rbp), %rsi
14009dc39:     	cmpq	%rsi, %r11
14009dc3c:     	setae	%bl
14009dc3f:     	testb	%bl, %r8b
14009dc42:     	jne	0x14009dc74 <.text+0x9cc74>
14009dc44:     	movq	-0x28(%r10), %rax
14009dc48:     	movd	-0x4(%r10), %xmm6
14009dc4e:     	movzbl	-0x5(%r10), %edi
14009dc53:     	movzbl	-0x6(%r10), %r15d
14009dc58:     	movzwl	-0x8(%r10), %r12d
14009dc5d:     	movl	-0xc(%r10), %r13d
14009dc61:     	movl	-0x10(%r10), %r14d
14009dc65:     	movups	-0x20(%r10), %xmm0
14009dc6a:     	movaps	%xmm0, 0x240(%rbp)
14009dc71:     	movq	%r11, %rsi
14009dc74:     	movq	%rsi, 0x268(%rbp)
14009dc7b:     	leaq	0x1(%r9), %r11
14009dc7f:     	movb	$0x1, %r8b
14009dc82:     	cmpq	$0x3, %r9
14009dc86:     	jb	0x14009dbd3 <.text+0x9cbd3>
14009dc8c:     	jmp	0x14009dc98 <.text+0x9cc98>
14009dc8e:     	testb	$0x1, %r8b
14009dc92:     	je	0x14009ded8 <.text+0x9ced8>
14009dc98:     	cmpq	$0x1, %rax
14009dc9c:     	ja	0x14009dcf4 <.text+0x9ccf4>
14009dc9e:     	cmpb	$0x1, 0x4420(%rcx,%rax)
14009dca6:     	jne	0x14009dcf4 <.text+0x9ccf4>
14009dca8:     	cmpb	$0x0, 0x4422(%rcx,%rax)
14009dcb0:     	jne	0x14009dcf4 <.text+0x9ccf4>
14009dcb2:     	movb	$0x0, 0x4420(%rcx,%rax)
14009dcba:     	decq	0x4418(%rcx)
14009dcc1:     	leaq	0x3a98(%rcx), %rdx
14009dcc8:     	movq	$0x0, 0x4398(%rcx,%rax,8)
14009dcd4:     	leaq	(%rax,%rax,8), %r8
14009dcd8:     	leaq	(%r8,%r8,2), %r8
14009dcdc:     	addq	%rax, %r8
14009dcdf:     	movb	$0x2, 0x95a(%rdx,%r8)
14009dce8:     	leaq	(%rax,%rax,2), %rax
14009dcec:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009dcf4:     	movaps	0x240(%rbp), %xmm0
14009dcfb:     	movaps	%xmm0, -0x60(%rbp)
14009dcff:     	movl	%r14d, %esi
14009dd02:     	movl	%r14d, -0x50(%rbp)
14009dd06:     	movl	%r13d, %r14d
14009dd09:     	movl	%r13d, -0x4c(%rbp)
14009dd0d:     	movl	%r12d, %r13d
14009dd10:     	movw	%r12w, -0x48(%rbp)
14009dd15:     	movl	%r15d, %r12d
14009dd18:     	movb	%r15b, -0x46(%rbp)
14009dd1c:     	movl	%edi, %r15d
14009dd1f:     	movb	%dil, -0x45(%rbp)
14009dd23:     	movd	%xmm6, %edi
14009dd27:     	movd	%xmm6, -0x44(%rbp)
14009dd2c:     	leaq	-0x60(%rbp), %rdx
14009dd30:     	movq	%rcx, 0x260(%rbp)
14009dd37:     	callq	0x140214200 <.text+0x213200>
14009dd3c:     	xorps	%xmm7, %xmm7
14009dd3f:     	movaps	%xmm7, 0x250(%rbp)
14009dd46:     	movb	$0x0, 0x222(%rbp)
14009dd4d:     	movw	%di, 0x220(%rbp)
14009dd54:     	movw	$0x200, 0x22b(%rbp)     # imm = 0x200
14009dd5d:     	movq	$0x0, 0x223(%rbp)
14009dd68:     	movq	$0x8, 0x200(%rbp)
14009dd73:     	movq	$0x0, 0x208(%rbp)
14009dd7e:     	movq	$0x1, 0x210(%rbp)
14009dd89:     	movq	$0x0, 0x218(%rbp)
14009dd94:     	leaq	0x230(%rbp), %rcx
14009dd9b:     	leaq	0x200(%rbp), %rdx
14009dda2:     	leaq	0x250(%rbp), %r8
14009dda9:     	movl	$0x10, %r9d
14009ddaf:     	callq	0x140110570 <.text+0x10f570>
14009ddb4:     	cmpb	$0x0, 0x230(%rbp)
14009ddbb:     	jne	0x14009ded4 <.text+0x9ced4>
14009ddc1:     	movq	0x238(%rbp), %rdi
14009ddc8:     	movaps	%xmm7, 0xe0(%rbp)
14009ddcf:     	movaps	%xmm7, 0xf0(%rbp)
14009ddd6:     	movaps	%xmm7, 0x100(%rbp)
14009dddd:     	movaps	%xmm7, 0x110(%rbp)
14009dde4:     	movaps	%xmm7, 0x120(%rbp)
14009ddeb:     	movaps	%xmm7, 0x130(%rbp)
14009ddf2:     	movaps	%xmm7, 0x140(%rbp)
14009ddf9:     	movaps	%xmm7, 0x150(%rbp)
14009de00:     	movaps	%xmm7, 0x160(%rbp)
14009de07:     	movaps	%xmm7, 0x170(%rbp)
14009de0e:     	movaps	%xmm7, 0x180(%rbp)
14009de15:     	movaps	%xmm7, 0x190(%rbp)
14009de1c:     	movaps	%xmm7, 0x1a0(%rbp)
14009de23:     	movaps	%xmm7, 0x1b0(%rbp)
14009de2a:     	movaps	%xmm7, 0x1c0(%rbp)
14009de31:     	movaps	%xmm7, 0x1d0(%rbp)
14009de38:     	movaps	0x240(%rbp), %xmm0
14009de3f:     	movups	%xmm0, 0x1f0(%rbp)
14009de46:     	cmpq	$0x11, %rdi
14009de4a:     	jae	0x14009defc <.text+0x9cefc>
14009de50:     	leaq	0xe0(%rbp), %rbx
14009de57:     	leaq	0x250(%rbp), %rdx
14009de5e:     	movq	%rbx, %rcx
14009de61:     	movq	%rdi, %r8
14009de64:     	callq	0x14024edd0 <.text+0x24ddd0>
14009de69:     	movw	%di, 0x1e0(%rbp)
14009de70:     	movq	$0x0, -0x60(%rbp)
14009de78:     	movups	0x1e8(%rbp), %xmm0
14009de7f:     	movups	%xmm0, -0x58(%rbp)
14009de83:     	movq	0x1f8(%rbp), %rax
14009de8a:     	movq	%rax, -0x48(%rbp)
14009de8e:     	movl	%esi, -0x40(%rbp)
14009de91:     	movl	%r14d, -0x3c(%rbp)
14009de95:     	movw	%r13w, -0x38(%rbp)
14009de9a:     	movb	%r12b, -0x36(%rbp)
14009de9e:     	movb	%r15b, -0x35(%rbp)
14009dea2:     	movd	%xmm6, -0x34(%rbp)
14009dea7:     	movq	0x268(%rbp), %rax
14009deae:     	movq	%rax, -0x30(%rbp)
14009deb2:     	leaq	-0x28(%rbp), %rcx
14009deb6:     	movl	$0x108, %r8d            # imm = 0x108
14009debc:     	movq	%rbx, %rdx
14009debf:     	callq	0x14024edd0 <.text+0x24ddd0>
14009dec4:     	leaq	-0x60(%rbp), %rdx
14009dec8:     	movq	0x260(%rbp), %rcx
14009decf:     	callq	0x140213f70 <.text+0x212f70>
14009ded4:     	movb	$0x1, %al
14009ded6:     	jmp	0x14009deda <.text+0x9ceda>
14009ded8:     	xorl	%eax, %eax
14009deda:     	movaps	0x270(%rbp), %xmm6
14009dee1:     	movaps	0x280(%rbp), %xmm7
14009dee8:     	addq	$0x318, %rsp            # imm = 0x318
14009deef:     	popq	%rbx
14009def0:     	popq	%rdi
14009def1:     	popq	%rsi
14009def2:     	popq	%r12
14009def4:     	popq	%r13
14009def6:     	popq	%r14
14009def8:     	popq	%r15
14009defa:     	popq	%rbp
14009defb:     	retq
14009defc:     	leaq	0x1c9c65(%rip), %r9     # 0x140267b68
14009df03:     	movl	$0x10, %r8d
14009df09:     	xorl	%ecx, %ecx
14009df0b:     	movq	%rdi, %rdx
14009df0e:     	callq	0x14024f820 <.text+0x24e820>
14009df13:     	ud2


D:\CoapticCurrent\phase-sharing-static-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068000:     	pushq	%rbp
140068001:     	pushq	%r15
140068003:     	pushq	%r14
140068005:     	pushq	%r13
140068007:     	pushq	%r12
140068009:     	pushq	%rsi
14006800a:     	pushq	%rdi
14006800b:     	pushq	%rbx
14006800c:     	subq	$0x4f8, %rsp            # imm = 0x4F8
140068013:     	leaq	0x80(%rsp), %rbp
14006801b:     	movq	%r9, %rbx
14006801e:     	movq	%r8, %r14
140068021:     	movq	%rdx, %rdi
140068024:     	movq	%rcx, %rsi
140068027:     	movq	0x4f0(%rbp), %r12
14006802e:     	leaq	-0x10(%rbp), %rcx
140068032:     	movl	$0x400, %r8d            # imm = 0x400
140068038:     	xorl	%edx, %edx
14006803a:     	callq	0x14024ede2 <.text+0x24dde2>
14006803f:     	movq	0x8(%r12), %r13
140068044:     	movl	$0x3, %eax
140068049:     	cmpq	$0x3, %r13
14006804d:     	ja	0x14006826c <.text+0x6726c>
140068053:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
14006805c:     	jne	0x14006826c <.text+0x6726c>
140068062:     	movq	0x2b750(%rdi,%r13,8), %rdx
14006806a:     	cmpq	$0x4001, %rdx           # imm = 0x4001
140068071:     	jae	0x1400682c8 <.text+0x672c8>
140068077:     	movq	0x10(%r12), %rcx
14006807c:     	movq	0x18(%r12), %r15
140068081:     	movq	%r15, %r8
140068084:     	movl	$0xb, %eax
140068089:     	addq	%rcx, %r8
14006808c:     	jb	0x14006826c <.text+0x6726c>
140068092:     	cmpq	$0x400, %r15            # imm = 0x400
140068099:     	ja	0x14006826c <.text+0x6726c>
14006809f:     	cmpq	%rdx, %r8
1400680a2:     	ja	0x14006826c <.text+0x6726c>
1400680a8:     	movq	%r13, %rax
1400680ab:     	shlq	$0xe, %rax
1400680af:     	leaq	(%rdi,%rax), %rdx
1400680b3:     	addq	$0x1b750, %rdx          # imm = 0x1B750
1400680ba:     	addq	%rcx, %rdx
1400680bd:     	leaq	-0x10(%rbp), %rcx
1400680c1:     	movq	%r15, %r8
1400680c4:     	callq	0x14024edd0 <.text+0x24ddd0>
1400680c9:     	cmpb	$0x0, 0x4f8(%rbp)
1400680d0:     	je	0x1400680e8 <.text+0x670e8>
1400680d2:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
1400680d9:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
1400680e2:     	jne	0x140068287 <.text+0x67287>
1400680e8:     	movq	$0x0, 0x470(%rbp)
1400680f3:     	movq	%rdi, %rcx
1400680f6:     	callq	0x14009a430 <.text+0x99430>
1400680fb:     	testb	$0x1, %al
1400680fd:     	je	0x1400682ba <.text+0x672ba>
140068103:     	movq	%rdx, %r13
140068106:     	movq	0x500(%rbp), %rdx
14006810d:     	movzwl	0x4e8(%rbp), %ecx
140068114:     	movzbl	0x4e0(%rbp), %eax
14006811b:     	movq	(%r12), %r8
14006811f:     	movq	0x470(%rbp), %r9
140068126:     	movq	%r9, 0x438(%rbp)
14006812d:     	movq	0x468(%rbp), %r9
140068134:     	movq	%r9, 0x440(%rbp)
14006813b:     	movq	%r8, 0x448(%rbp)
140068142:     	movzbl	0x4f8(%rbp), %r8d
14006814a:     	movb	%r8b, 0x450(%rbp)
140068151:     	movups	0x60(%r14), %xmm0
140068156:     	movups	0x6c(%r14), %xmm1
14006815b:     	movups	%xmm1, 0x3fc(%rbp)
140068162:     	movaps	%xmm0, 0x3f0(%rbp)
140068169:     	leaq	0x8e(%r14), %r8
140068170:     	movq	0x7e(%r14), %r9
140068174:     	movq	0x85(%r14), %r10
14006817b:     	movq	%r10, 0x45f(%rbp)
140068182:     	movq	%r9, 0x458(%rbp)
140068189:     	leaq	0x458(%rbp), %r9
140068190:     	movq	%r9, 0x68(%rsp)
140068195:     	movq	%rdx, 0x60(%rsp)
14006819a:     	movq	%r14, 0x58(%rsp)
14006819f:     	leaq	0x438(%rbp), %rdx
1400681a6:     	movq	%rdx, 0x50(%rsp)
1400681ab:     	movq	%r15, 0x48(%rsp)
1400681b0:     	leaq	-0x10(%rbp), %rdx
1400681b4:     	movq	%rdx, 0x40(%rsp)
1400681b9:     	movq	%rbx, 0x38(%rsp)
1400681be:     	movq	%r8, 0x30(%rsp)
1400681c3:     	movw	%cx, 0x28(%rsp)
1400681c8:     	movb	%al, 0x20(%rsp)
1400681cc:     	leaq	0x418(%rbp), %rcx
1400681d3:     	leaq	0x3f0(%rbp), %r8
1400681da:     	movq	%rdi, %rdx
1400681dd:     	movq	%r13, %r9
1400681e0:     	callq	0x140082370 <.text+0x81370>
1400681e5:     	cmpb	$-0x1, 0x418(%rbp)
1400681ec:     	je	0x1400682bf <.text+0x672bf>
1400681f2:     	cmpb	$0x1, 0x37740(%rdi,%r13)
1400681fb:     	jne	0x140068255 <.text+0x67255>
1400681fd:     	cmpb	$0x0, 0x37760(%rdi,%r13)
140068206:     	jne	0x140068255 <.text+0x67255>
140068208:     	movb	$0x0, 0x37740(%rdi,%r13)
140068211:     	decq	0x37788(%rdi)
140068218:     	leaq	0x37740(%rdi), %rax
14006821f:     	movq	$0x0, 0x43610(%rdi,%r13,8)
14006822b:     	leaq	(,%r13,8), %rcx
140068233:     	addq	%r13, %rcx
140068236:     	leaq	(%rcx,%rcx,2), %rcx
14006823a:     	addq	%r13, %rcx
14006823d:     	movb	$0x2, 0x36a(%rax,%rcx)
140068245:     	leaq	(,%r13,2), %rcx
14006824d:     	addq	%r13, %rcx
140068250:     	movb	$0x2, 0x5d(%rax,%rcx,8)
140068255:     	movups	0x418(%rbp), %xmm0
14006825c:     	movups	0x428(%rbp), %xmm1
140068263:     	movups	%xmm1, 0x10(%rsi)
140068267:     	movups	%xmm0, (%rsi)
14006826a:     	jmp	0x140068273 <.text+0x67273>
14006826c:     	movb	$0xa, (%rsi)
14006826f:     	movq	%rax, 0x8(%rsi)
140068273:     	addq	$0x4f8, %rsp            # imm = 0x4F8
14006827a:     	popq	%rbx
14006827b:     	popq	%rdi
14006827c:     	popq	%rsi
14006827d:     	popq	%r12
14006827f:     	popq	%r13
140068281:     	popq	%r14
140068283:     	popq	%r15
140068285:     	popq	%rbp
140068286:     	retq
140068287:     	addq	%rdi, %rax
14006828a:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
140068290:     	movq	0x98(%rax), %rax
140068297:     	movq	%rax, 0x468(%rbp)
14006829e:     	movl	$0x1, %eax
1400682a3:     	movq	%rax, 0x470(%rbp)
1400682aa:     	movq	%rdi, %rcx
1400682ad:     	callq	0x14009a430 <.text+0x99430>
1400682b2:     	testb	$0x1, %al
1400682b4:     	jne	0x140068103 <.text+0x67103>
1400682ba:     	movb	$0x9, (%rsi)
1400682bd:     	jmp	0x140068273 <.text+0x67273>
1400682bf:     	movq	%r13, 0x8(%rsi)
1400682c3:     	movb	$-0x1, (%rsi)
1400682c6:     	jmp	0x140068273 <.text+0x67273>
1400682c8:     	leaq	0x202971(%rip), %r9     # 0x14026ac40
1400682cf:     	movl	$0x4000, %r8d           # imm = 0x4000
1400682d5:     	xorl	%ecx, %ecx
1400682d7:     	callq	0x14024f820 <.text+0x24e820>
1400682dc:     	ud2

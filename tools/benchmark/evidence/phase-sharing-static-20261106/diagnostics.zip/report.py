"""Render the exact retained phase-sharing cohort; never execute native probes."""
from pathlib import Path
import json, subprocess, sys

root = Path(__file__).resolve().parent
out = Path('D:/codex-work/coaptic-validation/tools/benchmark/evidence/phase-sharing-static-20261106')
prior = out.parent / 'replay-row-presence-20261106'
source = (prior / 'render.py').read_text(encoding='utf-8')
prefix = source[:source.index('document=')]
prefix = prefix.replace("('replay-row-presence-20261106','Replay row presence')", "('replay-row-presence-20261106','Replay row presence'),('replay-shared-dispatch-20261106','Replay + shared dispatch / flat inbox'),('replay-scratch-original-inbox-20261106','Replay + shared scratch / original inbox'),('borrowed-send-chain-20261106','Replay + five borrowed send helpers'),('phase-sharing-static-20261106','Phase sharing / original replay')")
body = '''document = f\'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Coaptic phase sharing comparison</title><style>{css}</style></head><body>
<p><strong class="{'good' if passed else 'bad'}">{status}.</strong> {len(result['failed_point_guards'])} workload bounds exceed +2%. All nine final qualification lanes pass; merge is recorded separately.</p>
<p class="muted">Exact native source <code>3e592ad</code> versus pinned <code>bd63199</code>. 64 process pairs per workload, 28 workloads, 3,584 timing outputs. Complete server-App thread CPU cycles in memory transport.</p>
<h2>CPU cost: lower is better</h2>{''.join(svg)}
<small>Dot = geometric mean change; segment ends at one-sided 95% upper bound. Dashed line = +2% preservation limit.</small>
<p class="muted">Largest upper bound: {html.escape(' / '.join(map(str,worst['cell'])))}.</p>{cpu}
<p>The slowest point result is retained fixed OSCORE sync: +0.851%, upper bound +1.299%. It passes the declared 2% tolerance; aggregate gains do not mean every workload gets faster.</p>
<h2>Complete memory owners</h2>{mem}
<p>Both Service progress futures shrink by 1,416 bytes (8.37%). SmallDevice future and all selected resident App/pool owners stay unchanged. Futures and pool fields are nested owners: do not add their sizes twice. Requested heap excludes allocator bookkeeping; these are not peak-RAM or reserved-stack measurements.</p>
<h2>What changed</h2><p>Blockwise dispatch borrows storage used by the collected-response body in a later phase. Five retained-send helpers borrow immutable response metadata from their callers. Resident scratch capacity is a type constant, so the shared owner stores no capacity field. A nonzero encoded body length lets the enum fit the existing storage.</p>
<p>Original replay storage, client inbox ownership and retained-chunk copying are preserved. This cohort measures the integrated lifetime changes together; no gains from separate experiments are added.</p>
<h2>32-bit static layout</h2>{mem32}
<p class="muted">Installed Thumbv7EM target, actual core types with unit transport; no device execution. All selected owners equal baseline. The untimed precursor grew both Service Apps by 8 bytes and is preserved separately.</p>
<details><summary>All 28 matched workloads</summary>{cells}<p>A failed upper bound can reflect unresolved preservation, rather than a proven regression. No trimming or replacement samples.</p></details>
<details><summary>Largest fixed-Service pool owners</summary>{bars}<p>The pool is already inside the App total. Independent packet/body capacities dominate resident storage. Preallocation bounds allocations but does not automatically share temporary owners across phases.</p></details>
<details><summary>Retained prior experiments</summary>{history}<p>Separate cohorts against the same pinned baseline. No causal subtraction, unchanged resampling or reclassification of earlier failures.</p></details>
<details><summary>Checks and tradeoffs</summary><p>926 library, 11 allocation, 27 retained-Q, 13 footprint and 5 scratch-admission tests pass at 9f2c014. Exact 3e592ad adds one rustdoc line only; byte comparison justifies test reuse. Formatting and strict all-target/all-feature Clippy pass at 3e592ad. The original missing-doc lint failure is retained. General static review found no actionable issue. All-feature testing passes 1,681 tests (one explicitly ignored idle microbenchmark); no-default, alloc, oscore and std lanes pass. Both Rust 1.89 feature checks, no-default strict lint and rustdoc pass.</p>
<p>Encoder frames remain 1,280/1,296 bytes and selected reclaim frames do not grow. Custom resident backing types now declare stable writable CAPACITY; admission checks actual readable/writable slices before entropy. Datagram-only temporary scratch is unchanged. Oversized custom scratch switches initialized variants when a body is collected; startup and custom-switch cost are unmeasured. Body release timing and the 4,096-byte collection limit are preserved.</p>
<p>Actual sync and async wait/progress use immediate-ready memory transport and a pending timer. Client preparation, authentication and verification are outside the server clock. No network throughput/latency, executor scheduling, peak memory, hardware qualification or new libcoap ranking is claimed.</p></details>
</body></html>\'''
(ROOT/'comparison.html').write_text(document,encoding='utf-8')
print(ROOT/'comparison.html')
'''
(out / 'render.py').write_text(prefix + body, encoding='utf-8')
subprocess.run([sys.executable, '-B', str(out / 'render.py')], check=True)
x = json.loads((out / 'measurement.json').read_text())
verdict = 'passes the frozen runtime preservation rule; qualification and merge are separate' if x['runtime_accepted'] else 'is rejected under the frozen runtime preservation rule'
memory = json.loads((out / 'memory-comparison.json').read_text())
rows = '\n'.join(f"- {v['owner']}: {v['baseline']:,} to {v['candidate']:,} bytes ({v['candidate']-v['baseline']:+,})." for v in memory['rows'])
readme = f'''# Shared phase storage with static resident capacity

Exact native candidate 3e592adb1fd52c5e6918af1b4e810bb874413bad versus pinned
baseline bd63199b652193b4c0a882e5840e72d992cf1362 {verdict}.
All 64 pairs across 28 workloads are retained; {len(x['failed_point_guards'])} cell bounds fail.
Complete server-App CPU change: sync {(x['groups']['all-sync']['ratio']-1)*100:+.3f}%,
async {(x['groups']['all-async']['ratio']-1)*100:+.3f}%.
comparison.html contains the chart and comparable owner/workload tables.
Slowest point: retained fixed OSCORE sync +0.851%, upper bound +1.299%, within
the declared 2% tolerance. Aggregate gains do not mean every workload is faster.

Blockwise dispatch shares the collected-response backing. Five retained-send
helpers borrow immutable SendResponse metadata. ResidentScratch declares fixed
writable capacity as a type constant; no runtime capacity field is stored.
NonZeroU16 body length permits enum niche reuse. Original replay, client inbox
and retained chunk implementations remain. Previous failed cohorts remain failed.

The prospective memory rule requires no selected App/pool, future or emitted-frame
growth and strictly smaller complete Service progress futures. Resident App/pool
shrink is not required for this lifetime-only target. Every workload and both
ordinary/all sync/async CPU upper 95% bounds must be at most 1.02.
No earlier failure is reclassified under this rule.

## Matched memory owners

{rows}

Nested owners must not be added again. Requested heap excludes allocator metadata
and rounding; complete future objects are not peak stack or task reservations.
Selected Thumbv7EM unit-transport App/table layouts remain equal to baseline.
No target runtime claim. Untimed precursor 73e3aaf grew both selected Service Apps
by 8 bytes; its source, checks and failure remain in untimed-precursor.zip.

SmallDevice uses Constrained, 4 routes, 1 Call, 0 deferred, 4 security requests,
1 association, 2 RX/2 TX datagrams of 1152 bytes, 4 dedup, 2 Observe, no bodies.
Ordinary Service uses 32 routes, 4 Calls, 8 deferred, 4 security requests,
1 association, 32 RX/32 TX datagrams of 1472 bytes, 64 dedup, 32 Observe,
4 RX/4 TX bodies of 16384 bytes. Reported capacity fields are compared; unchanged
pinned fixture/source preserves capacities absent from individual outputs.

926 library, 11 allocation, 27 retained-Q, 13 footprint and 5 scratch-admission
checks pass at 9f2c014. Exact 3e592ad adds one rustdoc line only; check-reuse.json
records the byte comparison. Formatting and strict all-target/all-feature lint
pass at 3e592ad. The original missing-doc lint failure remains in diagnostics.
General static review found no actionable issue. All nine final qualification lanes
pass: strict no-default lint, all-feature tests (1681 passed, one explicitly ignored
idle microbenchmark), no-default/alloc/oscore/std library tests, both Rust 1.89
feature checks and rustdoc. qualification.json and logs retain commands/results.
Portable reconstruction now verifies all 148 native source hashes after explicit
LF normalization; the initial host CRLF mismatch is retained.

Selected encoder frames remain 1280/1296 bytes; reclaim frames do not grow.
Custom resident scratch implementations must declare stable writable CAPACITY;
actual readable/writable slices are checked before entropy. Temporary scratch
bounds and datagram-only behavior remain unchanged. Custom large scratch changes
initialized variant on body collection. Startup and custom-switch costs are
unmeasured. Body release timing and the 4096-byte collection limit are unchanged.

Run `python -B verify.py` to verify retained hashes/exits and recompute CPU results
without executing probes. `prepare.py CORE_REPO NEW_OUTPUT candidate` reconstructs
the exact native source from baseline and patch. The unchanged fixture is sibling
dispatch-scratch-20261104/fixture. observations.zip retains binaries/PDBs and raw
samples; diagnostics.zip retains builds/checks/review/lowering; layout32.zip has
the target static evidence. Local owner/mailbox metadata is excluded.

Actual sync and async wait/progress use immediate-ready memory transport and a
pending timer. Client preparation/authentication/verification are outside the
clock. No socket latency, maximum throughput, peak device RAM, executor policy,
hardware qualification or new libcoap ranking follows from this cohort.
'''
(out / 'README.md').write_text(readme, encoding='utf-8')

from pathlib import Path
import subprocess,json,os
r=Path(__file__).resolve().parent;repo=Path('C:/Users/jeffg/.t3/worktrees/coaptic/t3-a578955c');env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR='D:/coaptic-batch-interop-target');results=[]
for name,args in [('fmt',['fmt','--all','--','--check']),('clippy-all',['clippy','--locked','--offline','--all-targets','--all-features','--','-D','warnings'])]:
 cmd=[str(Path.home()/'.cargo/bin/agent-resources.exe'),'run','--id','coaptic-core-reusable','--directory',str(repo),'--','cargo',*args]
 with (r/(name+'.log')).open('wb') as log:p=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'exit_code':p.returncode,'command':cmd});print(results[-1],flush=True);assert p.returncode==0
prior=json.loads((r/'initial-focused-checks.json').read_text());test=next(x for x in prior if x['name']=='tests');assert test['exit_code']==0;test['reused_from']='9f2c01439d5d6240ff320e1334a6aa2b281b460b';results.insert(1,test);(r/'focused-checks.json').write_text(json.dumps(results,indent=2))

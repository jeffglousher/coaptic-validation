
D:\CoapticCurrent\phase-sharing-static-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140067d10:     	pushq	%rbp
140067d11:     	pushq	%r15
140067d13:     	pushq	%r14
140067d15:     	pushq	%r13
140067d17:     	pushq	%r12
140067d19:     	pushq	%rsi
140067d1a:     	pushq	%rdi
140067d1b:     	pushq	%rbx
140067d1c:     	subq	$0x508, %rsp            # imm = 0x508
140067d23:     	leaq	0x80(%rsp), %rbp
140067d2b:     	movq	%r9, %rbx
140067d2e:     	movq	%r8, %r14
140067d31:     	movq	%rdx, %rdi
140067d34:     	movq	%rcx, %rsi
140067d37:     	movq	0x500(%rbp), %r12
140067d3e:     	movq	%rbp, %rcx
140067d41:     	movl	$0x400, %r8d            # imm = 0x400
140067d47:     	xorl	%edx, %edx
140067d49:     	callq	0x14024ede2 <.text+0x24dde2>
140067d4e:     	movq	0x8(%r12), %r13
140067d53:     	movl	$0x3, %eax
140067d58:     	cmpq	$0x3, %r13
140067d5c:     	ja	0x140067f85 <.text+0x66f85>
140067d62:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
140067d6b:     	jne	0x140067f85 <.text+0x66f85>
140067d71:     	movq	0x2b750(%rdi,%r13,8), %rdx
140067d79:     	cmpq	$0x4001, %rdx           # imm = 0x4001
140067d80:     	jae	0x140067fe1 <.text+0x66fe1>
140067d86:     	movq	0x10(%r12), %rcx
140067d8b:     	movq	0x18(%r12), %r15
140067d90:     	movq	%r15, %r8
140067d93:     	movl	$0xb, %eax
140067d98:     	addq	%rcx, %r8
140067d9b:     	jb	0x140067f85 <.text+0x66f85>
140067da1:     	cmpq	$0x400, %r15            # imm = 0x400
140067da8:     	ja	0x140067f85 <.text+0x66f85>
140067dae:     	cmpq	%rdx, %r8
140067db1:     	ja	0x140067f85 <.text+0x66f85>
140067db7:     	movq	%r13, %rax
140067dba:     	shlq	$0xe, %rax
140067dbe:     	leaq	(%rdi,%rax), %rdx
140067dc2:     	addq	$0x1b750, %rdx          # imm = 0x1B750
140067dc9:     	addq	%rcx, %rdx
140067dcc:     	movq	%rbp, %rcx
140067dcf:     	movq	%r15, %r8
140067dd2:     	callq	0x14024edd0 <.text+0x24ddd0>
140067dd7:     	cmpb	$0x0, 0x508(%rbp)
140067dde:     	je	0x140067df6 <.text+0x66df6>
140067de0:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
140067de7:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
140067df0:     	jne	0x140067fa0 <.text+0x66fa0>
140067df6:     	movq	$0x0, 0x480(%rbp)
140067e01:     	movq	%rdi, %rcx
140067e04:     	callq	0x14009a430 <.text+0x99430>
140067e09:     	testb	$0x1, %al
140067e0b:     	je	0x140067fd3 <.text+0x66fd3>
140067e11:     	movq	%rdx, %r13
140067e14:     	movq	0x518(%rbp), %rdx
140067e1b:     	movq	0x510(%rbp), %r8
140067e22:     	movzwl	0x4f8(%rbp), %ecx
140067e29:     	movzbl	0x4f0(%rbp), %eax
140067e30:     	movq	(%r12), %r9
140067e34:     	movq	0x480(%rbp), %r10
140067e3b:     	movq	%r10, 0x448(%rbp)
140067e42:     	movq	0x478(%rbp), %r10
140067e49:     	movq	%r10, 0x450(%rbp)
140067e50:     	movq	%r9, 0x458(%rbp)
140067e57:     	movzbl	0x508(%rbp), %r9d
140067e5f:     	movb	%r9b, 0x460(%rbp)
140067e66:     	movups	0x60(%r14), %xmm0
140067e6b:     	movups	0x6c(%r14), %xmm1
140067e70:     	movups	%xmm1, 0x40c(%rbp)
140067e77:     	movaps	%xmm0, 0x400(%rbp)
140067e7e:     	leaq	0x8e(%r14), %r9
140067e85:     	movq	0x7e(%r14), %r10
140067e89:     	movq	0x85(%r14), %r11
140067e90:     	movq	%r11, 0x46f(%rbp)
140067e97:     	movq	%r10, 0x468(%rbp)
140067e9e:     	leaq	0x468(%rbp), %r10
140067ea5:     	movq	%r10, 0x70(%rsp)
140067eaa:     	movq	%rdx, 0x68(%rsp)
140067eaf:     	movq	%r8, 0x60(%rsp)
140067eb4:     	movq	%r14, 0x58(%rsp)
140067eb9:     	leaq	0x448(%rbp), %rdx
140067ec0:     	movq	%rdx, 0x50(%rsp)
140067ec5:     	movq	%r15, 0x48(%rsp)
140067eca:     	movq	%rbp, %rdx
140067ecd:     	movq	%rdx, 0x40(%rsp)
140067ed2:     	movq	%rbx, 0x38(%rsp)
140067ed7:     	movq	%r9, 0x30(%rsp)
140067edc:     	movw	%cx, 0x28(%rsp)
140067ee1:     	movb	%al, 0x20(%rsp)
140067ee5:     	leaq	0x428(%rbp), %rcx
140067eec:     	leaq	0x400(%rbp), %r8
140067ef3:     	movq	%rdi, %rdx
140067ef6:     	movq	%r13, %r9
140067ef9:     	callq	0x140080b80 <.text+0x7fb80>
140067efe:     	cmpb	$-0x1, 0x428(%rbp)
140067f05:     	je	0x140067fd8 <.text+0x66fd8>
140067f0b:     	cmpb	$0x1, 0x37740(%rdi,%r13)
140067f14:     	jne	0x140067f6e <.text+0x66f6e>
140067f16:     	cmpb	$0x0, 0x37760(%rdi,%r13)
140067f1f:     	jne	0x140067f6e <.text+0x66f6e>
140067f21:     	movb	$0x0, 0x37740(%rdi,%r13)
140067f2a:     	decq	0x37788(%rdi)
140067f31:     	leaq	0x37740(%rdi), %rax
140067f38:     	movq	$0x0, 0x43610(%rdi,%r13,8)
140067f44:     	leaq	(,%r13,8), %rcx
140067f4c:     	addq	%r13, %rcx
140067f4f:     	leaq	(%rcx,%rcx,2), %rcx
140067f53:     	addq	%r13, %rcx
140067f56:     	movb	$0x2, 0x36a(%rax,%rcx)
140067f5e:     	leaq	(,%r13,2), %rcx
140067f66:     	addq	%r13, %rcx
140067f69:     	movb	$0x2, 0x5d(%rax,%rcx,8)
140067f6e:     	movups	0x428(%rbp), %xmm0
140067f75:     	movups	0x438(%rbp), %xmm1
140067f7c:     	movups	%xmm1, 0x10(%rsi)
140067f80:     	movups	%xmm0, (%rsi)
140067f83:     	jmp	0x140067f8c <.text+0x66f8c>
140067f85:     	movb	$0xa, (%rsi)
140067f88:     	movq	%rax, 0x8(%rsi)
140067f8c:     	addq	$0x508, %rsp            # imm = 0x508
140067f93:     	popq	%rbx
140067f94:     	popq	%rdi
140067f95:     	popq	%rsi
140067f96:     	popq	%r12
140067f98:     	popq	%r13
140067f9a:     	popq	%r14
140067f9c:     	popq	%r15
140067f9e:     	popq	%rbp
140067f9f:     	retq
140067fa0:     	addq	%rdi, %rax
140067fa3:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
140067fa9:     	movq	0x98(%rax), %rax
140067fb0:     	movq	%rax, 0x478(%rbp)
140067fb7:     	movl	$0x1, %eax
140067fbc:     	movq	%rax, 0x480(%rbp)
140067fc3:     	movq	%rdi, %rcx
140067fc6:     	callq	0x14009a430 <.text+0x99430>
140067fcb:     	testb	$0x1, %al
140067fcd:     	jne	0x140067e11 <.text+0x66e11>
140067fd3:     	movb	$0x9, (%rsi)
140067fd6:     	jmp	0x140067f8c <.text+0x66f8c>
140067fd8:     	movq	%r13, 0x8(%rsi)
140067fdc:     	movb	$-0x1, (%rsi)
140067fdf:     	jmp	0x140067f8c <.text+0x66f8c>
140067fe1:     	leaq	0x202c58(%rip), %r9     # 0x14026ac40
140067fe8:     	movl	$0x4000, %r8d           # imm = 0x4000
140067fee:     	xorl	%ecx, %ecx
140067ff0:     	callq	0x14024f820 <.text+0x24e820>
140067ff5:     	ud2

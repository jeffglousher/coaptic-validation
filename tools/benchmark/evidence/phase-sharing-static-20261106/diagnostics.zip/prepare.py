from pathlib import Path
import subprocess,json,hashlib,shutil
r=Path(__file__).resolve().parent
p=Path('D:/CoapticCurrent/phase-sharing-only-20261106')
repo=Path('C:/Users/jeffg/.t3/worktrees/coaptic/t3-a578955c')
sha='3e592adb1fd52c5e6918af1b4e810bb874413bad';old='73e3aafa9385b8a9cd5b7954ce2b0d344704fb01'
v=json.loads((p/'source-verification.json').read_text());v['source']=sha
core=Path(v['fixture_root'])/'coaptic'
for name in v['source_file_hashes']:
 data=subprocess.check_output(['git','-C',str(repo),'show',sha+':'+name]).replace(b'\r\n',b'\n')
 if (core/name).read_bytes()!=data:(core/name).write_bytes(data)
 v['source_file_hashes'][name]=hashlib.sha256(data).hexdigest()
patch=subprocess.check_output(['git','-C',str(repo),'diff','--binary',v['baseline'],sha,'--','src','crates','tests','Cargo.toml','Cargo.lock'])
(r/'candidate.patch').write_bytes(patch);v['patch_sha256']=hashlib.sha256(patch).hexdigest()
(r/'source-verification.json').write_text(json.dumps(v,indent=2)+'\n')
for name in ['build-preflight.py','build.py','layout.py','inspect.py','inspect-inline.py','inspect-reclaim.py','check-preflight.py','baseline-reclaim-symbols.txt','measure.py','qualify.py','focused-checks.py','fixture-sha256.json','inspect-callers.py']:
 (r/name).write_text((p/name).read_text().replace(old,sha))
(r/'B').mkdir(exist_ok=True);(r/'layout32').mkdir(exist_ok=True)
for name in ['audit.py','Cargo.toml','Cargo.lock','lib.rs','baseline-build.log','baseline-constants.txt','baseline-layout.txt','baseline-source.json']:
 (r/'layout32'/name).write_bytes((p/'layout32'/name).read_bytes())
m=json.loads((p/'METHOD-BEFORE.json').read_text());m['candidate']=sha
m['hypothesis']=m['source_hypothesis']='Share dispatch/collected-body backing with no resident capacity field. New ResidentScratch stable writable capacity is declared on the type and verified against actual slices at admission. NonZero body length permits enum niche reuse. Original replay/client/chunk behavior and five send-metadata borrows. Complete-Service-future shrink with all resident owners nongrowing.'
m['preflight_repair']='Untimed73e3aaf failed32-bit App nongrowth by8bytes in both Service types; retained in untimed-precursor. New type-level capacity removes stored bookkeeping. No prior failure reclassification and no unchanged runtime resampling.'
m['tradeoffs']='New resident backing contract requires stable Default writable capacity, checked against actual readable/writable slices before entropy; temporary scratch bounds unchanged. Custom ResidentScratch implementations need a CAPACITY constant. Large backing remains unsliced. Startup/custom variant-switch initialization costs unmeasured.'
(r/'METHOD-BEFORE.json').write_text(json.dumps(m,indent=2)+'\n');print({'source':sha,'verified_files':len(v['source_file_hashes'])})

"""Inspect missing baseline App field order, without any new timing sample."""
from pathlib import Path
import hashlib
import io
import json
import os
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('C:/Users/jeffg/.t3/worktrees/coaptic/t3-a578955c')
FIXTURE = Path('D:/CoapticCurrent/replay-active-copy-20261105/fixture')
source = json.loads((ROOT / 'source-verification.json').read_text())
output = ROOT / 'baseline-app-layout.txt'
assert not output.exists()
saved = {}
hashes = {}
archive_bytes = subprocess.check_output(['git', '-C', str(REPO), 'archive', source['baseline']])
try:
    with tarfile.open(fileobj=io.BytesIO(archive_bytes)) as archive:
        for name in source['source_file_hashes']:
            path = FIXTURE / 'coaptic' / name
            data = archive.extractfile(name).read()
            hashes[name] = hashlib.sha256(data.replace(b'\r\n', b'\n')).hexdigest()
            original = path.read_bytes()
            if original != data:
                saved[path] = original
                path.write_bytes(data)
    (ROOT / 'baseline-app-layout-method.json').write_text(json.dumps(dict(
        baseline=source['baseline'], source_file_hashes=hashes,
        scope='App field order and size only; no timing, no peak-stack claim',
        output_budget_bytes=131072), indent=2))
    env = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1',
               RUSTFLAGS='-Cforce-frame-pointers=yes', RUSTC_BOOTSTRAP='1')
    cmd = [str(Path.home()/'.cargo/bin/agent-resources.exe'), 'run', '--id',
           'coaptic-core-reusable', '--directory', str(FIXTURE/'probe'), '--',
           'cargo', 'rustc', '--locked', '--offline', '--release', '--bin',
           'dispatch-probe', '--', '-Zprint-type-sizes']
    size = 0
    keep = False
    with output.open('w', encoding='utf-8') as out, (ROOT/'baseline-app-layout-build.log').open('w') as err:
        process = subprocess.Popen(cmd, cwd=FIXTURE/'probe', env=env,
                                   stdout=subprocess.PIPE, stderr=err, text=True)
        for line in process.stdout:
            if line.startswith('print-type-size type:'):
                keep = line.startswith('print-type-size type: `coaptic::App<')
            if keep:
                size += len(line.encode())
                if size <= 131072:
                    out.write(line)
        code = process.wait()
    assert code == 0 and size <= 131072, (code, size)
    print(json.dumps(dict(exit_code=code, retained_bytes=size, restored_files=len(saved))))
finally:
    for path, data in saved.items():
        path.write_bytes(data)

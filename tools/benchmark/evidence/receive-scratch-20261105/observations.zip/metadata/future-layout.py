from pathlib import Path
import os, subprocess

root = Path(__file__).resolve().parent.parent
phase = Path(__file__).resolve().parent
env = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1',
           RUSTFLAGS='-Cforce-frame-pointers=yes', RUSTC_BOOTSTRAP='1')
command = [str(Path.home()/'.cargo/bin/agent-resources.exe'), 'run',
           '--id', 'coaptic-core-reusable', '--directory', str(root/'fixture/probe'),
           '--', 'cargo', 'rustc', '--locked', '--offline', '--release',
           '--bin', 'dispatch-probe', '--', '-Zprint-type-sizes']
output = phase/'future-layout.txt'
assert not output.exists()
keep = False
size = 0
with output.open('w', encoding='utf-8') as target, (phase/'future-layout-build.log').open('w') as errors:
    p = subprocess.Popen(command, cwd=root/'fixture/probe', env=env,
                         stdout=subprocess.PIPE, stderr=errors, text=True)
    for line in p.stdout:
        if line.startswith('print-type-size type:'):
            keep = line.startswith('print-type-size type: `{async fn body of coaptic::') and 'profiles::Constrained>' in line and 'CoreIo,' in line
        if keep:
            size += len(line.encode())
            if size <= 2*1024*1024:
                target.write(line)
    code = p.wait()
assert size <= 2*1024*1024, 'Diagnostic budget exceeded; retained prefix is incomplete'
print({'exit_code':code, 'retained_bytes':size, 'source':'fbba2ab production',
       'scope':'compiler layout diagnostic only; not a timing binary'})
raise SystemExit(code)

﻿from pathlib import Path
import subprocess,os,json,hashlib
r=Path(__file__).resolve().parent;repo=Path('C:/Users/jeffg/.t3/worktrees/coaptic/t3-a578955c');fixture=Path('D:/CoapticCurrent/replay-active-copy-20261105/fixture/coaptic');verification=json.loads(Path('D:/CoapticCurrent/body-transfer-borrow-20261106/single-destination/source-verification.json').read_text());candidate=verification['source'];baseline=verification['baseline'];names=list(verification['source_file_hashes']);wrapper=str(Path.home()/'.cargo/bin/agent-resources.exe')
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR='D:/coaptic-batch-interop-target',RUSTC_BOOTSTRAP='1',RUSTFLAGS='-Cforce-frame-pointers=yes');records=[]
def overlay(sha):
 hashes={}
 for name in names:
  data=subprocess.check_output(['git','-C',str(repo),'show',sha+':'+name]).replace(b'\r\n',b'\n');p=fixture/name
  if p.read_bytes()!=data:p.write_bytes(data)
  hashes[name]=hashlib.sha256(data).hexdigest()
 return hashes
try:
 for label,sha in [('candidate',candidate),('baseline',baseline)]:
  hashes=overlay(sha);(r/(label+'-source.json')).write_text(json.dumps({'source':sha,'hashes':hashes},indent=2)+'\n')
  args=['cargo','+stable','rustc','--offline','--release','--target','thumbv7em-none-eabi','--lib','--','-Zprint-type-sizes','--emit=llvm-ir'];cmd=[wrapper,'run','--id','coaptic-core-reusable','--directory',str(r),'--',*args]
  keep=False;size=0
  with (r/(label+'-layout.txt')).open('w',encoding='utf-8') as out,(r/(label+'-build.log')).open('w',encoding='utf-8') as err:
   p=subprocess.Popen(cmd,cwd=r,env=env,stdout=subprocess.PIPE,stderr=err,text=True,encoding='utf-8',errors='replace')
   for line in p.stdout:
    if line.startswith('print-type-size type:'):keep=line.startswith('print-type-size type: `coaptic::') and any(x in line for x in ['::App<','::DedupEntry','::DedupTable<','::DedupScan','::HeapOccupancy'])
    if keep:
     size+=len(line.encode())
     if size<=512*1024:out.write(line)
   code=p.wait()
  record={'label':label,'source':sha,'exit_code':code,'layout_bytes':size,'command':cmd};records.append(record);print(record,flush=True);assert code==0 and size<=512*1024
  files=list(Path('D:/coaptic-batch-interop-target/thumbv7em-none-eabi/release/deps').glob('coaptic_layout_audit-*.ll'));p=max(files,key=lambda p:p.stat().st_mtime);lines=[s for s in p.read_text(encoding='utf-8').splitlines() if '@COAPTIC_LAYOUT =' in s];assert len(lines)==1;(r/(label+'-constants.txt')).write_text(lines[0]+'\n');print(lines[0],flush=True)
finally:
 assert overlay(candidate)==verification['source_file_hashes']
 (r/'results.json').write_text(json.dumps(records,indent=2)+'\n')

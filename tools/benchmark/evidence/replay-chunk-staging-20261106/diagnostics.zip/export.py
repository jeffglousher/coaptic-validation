from pathlib import Path
import json, re, hashlib, shutil, zipfile
native=Path(__file__).resolve().parent
root=native/'single-destination'
out=Path('D:/codex-work/coaptic-validation/tools/benchmark/evidence/replay-chunk-staging-20261106')
prior=out.parent/'shared-dispatch-20261106'
assert (root/'measurement.json').is_file()
assert json.loads((root/'measurement.json').read_text())['status']=='complete'
out.mkdir(exist_ok=True)
for name in ['candidate.patch','fixture-sha256.json','METHOD-BEFORE.json','METHOD.json','measurement.json']:
 shutil.copyfile(root/name,out/name)
src=json.loads((root/'source-verification.json').read_text());src['patch_sha256']={'candidate.patch':src['patch_sha256']}
(out/'source-verification.json').write_text(json.dumps(src,indent=2)+'\n')
shutil.copyfile(prior/'prepare.py',out/'prepare.py')
shutil.copyfile(prior/'.gitattributes',out/'.gitattributes')
# Parse the complete, narrow compiler output; nested fields remain nested.
layout=(root/'owner-layout.txt').read_text();owners=[];current=None
for line in layout.splitlines():
 m=re.match(r'print-type-size type: `(.*)`: (\d+) bytes, alignment: (\d+) bytes',line)
 if m:
  current={'type':m[1],'bytes':int(m[2]),'alignment':int(m[3]),'fields':[]};owners.append(current)
 else:
  m=re.match(r'print-type-size     field `(.*)`: (\d+) bytes',line)
  if m and current is not None:current['fields'].append({'name':m[1],'bytes':int(m[2])})
(root/'owners.json').write_text(json.dumps(owners,indent=2)+'\n');shutil.copyfile(root/'owners.json',out/'owners.json')
memory=json.loads((prior/'memory-comparison.json').read_text())
for row in memory['rows']:
 if row['owner']=='SmallDevice App': row['candidate']=14920
 elif row['owner']=='Service fixed App':row['candidate']=315400
 elif row['owner']=='Service allocated App':row['candidate']=35672
 elif row['owner']=='Service allocated pool heap':row['candidate']=282256
 else:row['candidate']=row['baseline']
for record in memory['layout_records']:
 if 'baseline-future-layout.txt' not in record['file']:
  typ=record['record'].split('`: ')[0]
  record['record']=next(line for line in layout.splitlines() if line.startswith(typ+'`: '))
  record['file']=str(root/'owner-layout.txt')
memory['candidate_layout_sha256']=hashlib.sha256((root/'owner-layout.txt').read_bytes()).hexdigest()
memory['warning']+=' Allocator metadata/rounding is excluded from requested heap; new nonempty allocated Dedup has one additional startup request.'
(root/'memory-comparison.json').write_text(json.dumps(memory,indent=2)+'\n');shutil.copyfile(root/'memory-comparison.json',out/'memory-comparison.json')
# Keep ordinary observations in the same established archive shape.
files=[]
for pat in ['measure-*.json','measure-*.stderr','qualify-*.json','qualify-*.stderr']:
 files.extend(root.glob(pat))
files += [root/n for n in ['METHOD.json','METHOD-BEFORE.json','measurement.json','measure.py','source-verification.json','fixture-sha256.json','owner-layout.txt','owners.json','memory-comparison.json','process-exits.jsonl']]
files += list((root/'B').glob('*'))
hashes={}
with zipfile.ZipFile(out/'observations.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files):
  name='candidate/'+p.relative_to(root).as_posix();data=p.read_bytes();hashes[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
(out/'observation-sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
files=[p for p in native.rglob('*') if p.is_file() and root not in p.parents and 'reconstruction' not in p.parts and p.name not in ['progress-notice.json']]
files += [p for p in root.iterdir() if p.is_file() and (p.suffix in ['.asm','.log'] or p.name in ['encoder-frames.json','candidate-encoder-symbols.txt','build-results.json','layout-preflight.json','review.txt'])]
hashes={}
with zipfile.ZipFile(out/'diagnostics.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files):
  data=p.read_bytes();name=p.relative_to(native).as_posix();hashes[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
(out/'diagnostic-sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
# Reuse the independent result verifier with the new exact memory contract.
v=(prior/'verify.py').read_text()
v=v.replace('expected["app_including_transport_inline_bytes"] -= 688','expected["app_including_transport_inline_bytes"] -= 16')
v=v.replace('expected["server_app_including_transport_inline_bytes"] -= 672\n                expected["client_app_including_transport_inline_bytes"] -= 672','if profile == "service-fixed":\n                    expected["server_app_including_transport_inline_bytes"] -= 256\n                else:\n                    expected["server_pool_requested_heap_bytes"] -= 256\n                expected["client_pool_requested_heap_bytes"] -= 32')
v=v.replace('a["app_inline_bytes"] - 672','a["app_inline_bytes"] - (64 if profile == "fixed" else 0)')
v=v.replace('for name, digest in json.loads((ROOT / "fixture-sha256.json").read_text()).items():','with zipfile.ZipFile(ROOT / "observations.zip") as archive:\n    events = [json.loads(line) for line in archive.read("candidate/process-exits.jsonl").decode().splitlines()]\n    assert len(events) == 3640\n    labels = {e["label"] for e in events}\n    assert len(labels) == len(events)\n    assert all(e["exit_code"] == 0 for e in events)\n    assert labels == {name.removeprefix("candidate/").removesuffix(".json") for name in archive.namelist() if name.startswith(("candidate/measure-", "candidate/qualify-")) and name.endswith(".json")}\n    for e in events:\n        assert e["stdout_bytes"] == len(archive.read("candidate/" + e["label"] + ".json"))\n\n'+'for name, digest in json.loads((ROOT / "fixture-sha256.json").read_text()).items():')
(out/'verify.py').write_text(v)
print(json.dumps({'output':str(out),'archive_members':len(files),'total_bytes':sum(p.stat().st_size for p in out.iterdir() if p.is_file())}))

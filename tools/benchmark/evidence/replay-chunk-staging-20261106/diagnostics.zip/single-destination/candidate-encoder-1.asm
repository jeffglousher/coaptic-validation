
D:\CoapticCurrent\body-transfer-borrow-20261106\single-destination\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068990:     	pushq	%rbp
140068991:     	pushq	%r15
140068993:     	pushq	%r14
140068995:     	pushq	%r13
140068997:     	pushq	%r12
140068999:     	pushq	%rsi
14006899a:     	pushq	%rdi
14006899b:     	pushq	%rbx
14006899c:     	subq	$0x508, %rsp            # imm = 0x508
1400689a3:     	leaq	0x80(%rsp), %rbp
1400689ab:     	movq	0x500(%rbp), %r12
1400689b2:     	movq	0x8(%r12), %rdi
1400689b7:     	movl	$0x3, %r10d
1400689bd:     	cmpq	$0x3, %rdi
1400689c1:     	ja	0x140068aa1 <.text+0x67aa1>
1400689c7:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
1400689cf:     	jne	0x140068aa1 <.text+0x67aa1>
1400689d5:     	movq	0x26700(%rdx,%rdi,8), %rax
1400689dd:     	cmpq	$0x4001, %rax           # imm = 0x4001
1400689e3:     	jae	0x140068c7e <.text+0x67c7e>
1400689e9:     	movq	0x10(%r12), %r11
1400689ee:     	movq	0x18(%r12), %r15
1400689f3:     	movq	%r15, %rsi
1400689f6:     	movl	$0xb, %r10d
1400689fc:     	addq	%r11, %rsi
1400689ff:     	jb	0x140068aa1 <.text+0x67aa1>
140068a05:     	cmpq	$0x400, %r15            # imm = 0x400
140068a0c:     	ja	0x140068aa1 <.text+0x67aa1>
140068a12:     	cmpq	%rax, %rsi
140068a15:     	ja	0x140068aa1 <.text+0x67aa1>
140068a1b:     	movq	%r8, %r13
140068a1e:     	movq	%r9, 0x470(%rbp)
140068a25:     	movq	%rcx, 0x480(%rbp)
140068a2c:     	movzbl	0x508(%rbp), %r14d
140068a34:     	movq	%rdi, %rax
140068a37:     	shlq	$0xe, %rax
140068a3b:     	movq	%rdx, %rsi
140068a3e:     	leaq	(%rdx,%rax), %rbx
140068a42:     	addq	$0x16700, %rbx          # imm = 0x16700
140068a49:     	addq	%r11, %rbx
140068a4c:     	movl	$0x400, %r8d            # imm = 0x400
140068a52:     	cmpq	$0x400, %r15            # imm = 0x400
140068a59:     	je	0x140068a68 <.text+0x67a68>
140068a5b:     	movq	%rbp, %rcx
140068a5e:     	xorl	%edx, %edx
140068a60:     	callq	0x1402510b2 <.text+0x2500b2>
140068a65:     	movq	%r15, %r8
140068a68:     	movq	%rbp, %rcx
140068a6b:     	movq	%rbx, %rdx
140068a6e:     	callq	0x1402510a0 <.text+0x2500a0>
140068a73:     	testb	%r14b, %r14b
140068a76:     	je	0x140068abc <.text+0x67abc>
140068a78:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
140068a7f:     	movq	%rsi, %rcx
140068a82:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
140068a8b:     	jne	0x140068c33 <.text+0x67c33>
140068a91:     	xorl	%edi, %edi
140068a93:     	callq	0x14009b840 <.text+0x9a840>
140068a98:     	testb	$0x1, %al
140068a9a:     	jne	0x140068ace <.text+0x67ace>
140068a9c:     	jmp	0x140068c5c <.text+0x67c5c>
140068aa1:     	movb	$0xa, (%rcx)
140068aa4:     	movq	%r10, 0x8(%rcx)
140068aa8:     	addq	$0x508, %rsp            # imm = 0x508
140068aaf:     	popq	%rbx
140068ab0:     	popq	%rdi
140068ab1:     	popq	%rsi
140068ab2:     	popq	%r12
140068ab4:     	popq	%r13
140068ab6:     	popq	%r14
140068ab8:     	popq	%r15
140068aba:     	popq	%rbp
140068abb:     	retq
140068abc:     	xorl	%edi, %edi
140068abe:     	movq	%rsi, %rcx
140068ac1:     	callq	0x14009b840 <.text+0x9a840>
140068ac6:     	testb	$0x1, %al
140068ac8:     	je	0x140068c5c <.text+0x67c5c>
140068ace:     	movq	%rdx, %rbx
140068ad1:     	movq	0x518(%rbp), %rdx
140068ad8:     	movq	0x510(%rbp), %r8
140068adf:     	movzwl	0x4f8(%rbp), %ecx
140068ae6:     	movzbl	0x4f0(%rbp), %eax
140068aed:     	movq	(%r12), %r9
140068af1:     	movq	%rdi, 0x440(%rbp)
140068af8:     	movq	0x478(%rbp), %r10
140068aff:     	movq	%r10, 0x448(%rbp)
140068b06:     	movq	%r9, 0x450(%rbp)
140068b0d:     	movb	%r14b, 0x458(%rbp)
140068b14:     	movups	0x60(%r13), %xmm0
140068b19:     	movups	0x6c(%r13), %xmm1
140068b1e:     	movups	%xmm1, 0x40c(%rbp)
140068b25:     	movaps	%xmm0, 0x400(%rbp)
140068b2c:     	leaq	0x8e(%r13), %r9
140068b33:     	movq	0x7e(%r13), %r10
140068b37:     	movq	0x85(%r13), %r11
140068b3e:     	movq	%r11, 0x467(%rbp)
140068b45:     	movq	%r10, 0x460(%rbp)
140068b4c:     	leaq	0x460(%rbp), %r10
140068b53:     	movq	%r10, 0x70(%rsp)
140068b58:     	movq	%rdx, 0x68(%rsp)
140068b5d:     	movq	%r8, 0x60(%rsp)
140068b62:     	movq	%r13, 0x58(%rsp)
140068b67:     	leaq	0x440(%rbp), %rdx
140068b6e:     	movq	%rdx, 0x50(%rsp)
140068b73:     	movq	%r15, 0x48(%rsp)
140068b78:     	movq	%rbp, %rdx
140068b7b:     	movq	%rdx, 0x40(%rsp)
140068b80:     	movq	0x470(%rbp), %rdx
140068b87:     	movq	%rdx, 0x38(%rsp)
140068b8c:     	movq	%r9, 0x30(%rsp)
140068b91:     	movw	%cx, 0x28(%rsp)
140068b96:     	movb	%al, 0x20(%rsp)
140068b9a:     	leaq	0x420(%rbp), %rcx
140068ba1:     	leaq	0x400(%rbp), %r8
140068ba8:     	movq	%rsi, %rdx
140068bab:     	movq	%rbx, %r9
140068bae:     	callq	0x140081a40 <.text+0x80a40>
140068bb3:     	cmpb	$-0x1, 0x420(%rbp)
140068bba:     	je	0x140068c6b <.text+0x67c6b>
140068bc0:     	cmpb	$0x1, 0x37640(%rsi,%rbx)
140068bc8:     	movq	0x480(%rbp), %rax
140068bcf:     	jne	0x140068c19 <.text+0x67c19>
140068bd1:     	cmpb	$0x0, 0x37660(%rsi,%rbx)
140068bd9:     	jne	0x140068c19 <.text+0x67c19>
140068bdb:     	movb	$0x0, 0x37640(%rsi,%rbx)
140068be3:     	decq	0x37688(%rsi)
140068bea:     	leaq	0x37640(%rsi), %rcx
140068bf1:     	movq	$0x0, 0x43510(%rsi,%rbx,8)
140068bfd:     	leaq	(%rbx,%rbx,8), %rdx
140068c01:     	leaq	(%rdx,%rdx,2), %rdx
140068c05:     	addq	%rbx, %rdx
140068c08:     	movb	$0x2, 0x36a(%rcx,%rdx)
140068c10:     	leaq	(%rbx,%rbx,2), %rdx
140068c14:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140068c19:     	movups	0x420(%rbp), %xmm0
140068c20:     	movups	0x430(%rbp), %xmm1
140068c27:     	movups	%xmm1, 0x10(%rax)
140068c2b:     	movups	%xmm0, (%rax)
140068c2e:     	jmp	0x140068aa8 <.text+0x67aa8>
140068c33:     	addq	%rcx, %rax
140068c36:     	addq	$0x15c28, %rax          # imm = 0x15C28
140068c3c:     	movq	0x98(%rax), %rax
140068c43:     	movq	%rax, 0x478(%rbp)
140068c4a:     	movl	$0x1, %edi
140068c4f:     	callq	0x14009b840 <.text+0x9a840>
140068c54:     	testb	$0x1, %al
140068c56:     	jne	0x140068ace <.text+0x67ace>
140068c5c:     	movq	0x480(%rbp), %rax
140068c63:     	movb	$0x9, (%rax)
140068c66:     	jmp	0x140068aa8 <.text+0x67aa8>
140068c6b:     	movq	0x480(%rbp), %rax
140068c72:     	movq	%rbx, 0x8(%rax)
140068c76:     	movb	$-0x1, (%rax)
140068c79:     	jmp	0x140068aa8 <.text+0x67aa8>
140068c7e:     	leaq	0x203fab(%rip), %r9     # 0x14026cc30
140068c85:     	movl	$0x4000, %r8d           # imm = 0x4000
140068c8b:     	xorl	%ecx, %ecx
140068c8d:     	movq	%rax, %rdx
140068c90:     	callq	0x140251b30 <.text+0x250b30>
140068c95:     	ud2

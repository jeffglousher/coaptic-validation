
D:\CoapticCurrent\body-transfer-borrow-20261106\single-destination\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068ca0:     	pushq	%rbp
140068ca1:     	pushq	%r15
140068ca3:     	pushq	%r14
140068ca5:     	pushq	%r13
140068ca7:     	pushq	%r12
140068ca9:     	pushq	%rsi
140068caa:     	pushq	%rdi
140068cab:     	pushq	%rbx
140068cac:     	subq	$0x4f8, %rsp            # imm = 0x4F8
140068cb3:     	leaq	0x80(%rsp), %rbp
140068cbb:     	movq	0x4f0(%rbp), %r12
140068cc2:     	movq	0x8(%r12), %rdi
140068cc7:     	movl	$0x3, %r10d
140068ccd:     	cmpq	$0x3, %rdi
140068cd1:     	ja	0x140068db3 <.text+0x67db3>
140068cd7:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
140068cdf:     	jne	0x140068db3 <.text+0x67db3>
140068ce5:     	movq	0x26700(%rdx,%rdi,8), %rax
140068ced:     	cmpq	$0x4001, %rax           # imm = 0x4001
140068cf3:     	jae	0x140068f85 <.text+0x67f85>
140068cf9:     	movq	0x10(%r12), %r11
140068cfe:     	movq	0x18(%r12), %r15
140068d03:     	movq	%r15, %rsi
140068d06:     	movl	$0xb, %r10d
140068d0c:     	addq	%r11, %rsi
140068d0f:     	jb	0x140068db3 <.text+0x67db3>
140068d15:     	cmpq	$0x400, %r15            # imm = 0x400
140068d1c:     	ja	0x140068db3 <.text+0x67db3>
140068d22:     	cmpq	%rax, %rsi
140068d25:     	ja	0x140068db3 <.text+0x67db3>
140068d2b:     	movq	%r8, %r13
140068d2e:     	movq	%r9, 0x460(%rbp)
140068d35:     	movq	%rcx, 0x470(%rbp)
140068d3c:     	movzbl	0x4f8(%rbp), %r14d
140068d44:     	movq	%rdi, %rax
140068d47:     	shlq	$0xe, %rax
140068d4b:     	movq	%rdx, %rsi
140068d4e:     	leaq	(%rdx,%rax), %rbx
140068d52:     	addq	$0x16700, %rbx          # imm = 0x16700
140068d59:     	addq	%r11, %rbx
140068d5c:     	movl	$0x400, %r8d            # imm = 0x400
140068d62:     	cmpq	$0x400, %r15            # imm = 0x400
140068d69:     	je	0x140068d79 <.text+0x67d79>
140068d6b:     	leaq	-0x10(%rbp), %rcx
140068d6f:     	xorl	%edx, %edx
140068d71:     	callq	0x1402510b2 <.text+0x2500b2>
140068d76:     	movq	%r15, %r8
140068d79:     	leaq	-0x10(%rbp), %rcx
140068d7d:     	movq	%rbx, %rdx
140068d80:     	callq	0x1402510a0 <.text+0x2500a0>
140068d85:     	testb	%r14b, %r14b
140068d88:     	je	0x140068dce <.text+0x67dce>
140068d8a:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
140068d91:     	movq	%rsi, %rcx
140068d94:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
140068d9d:     	jne	0x140068f3a <.text+0x67f3a>
140068da3:     	xorl	%edi, %edi
140068da5:     	callq	0x14009b840 <.text+0x9a840>
140068daa:     	testb	$0x1, %al
140068dac:     	jne	0x140068de0 <.text+0x67de0>
140068dae:     	jmp	0x140068f63 <.text+0x67f63>
140068db3:     	movb	$0xa, (%rcx)
140068db6:     	movq	%r10, 0x8(%rcx)
140068dba:     	addq	$0x4f8, %rsp            # imm = 0x4F8
140068dc1:     	popq	%rbx
140068dc2:     	popq	%rdi
140068dc3:     	popq	%rsi
140068dc4:     	popq	%r12
140068dc6:     	popq	%r13
140068dc8:     	popq	%r14
140068dca:     	popq	%r15
140068dcc:     	popq	%rbp
140068dcd:     	retq
140068dce:     	xorl	%edi, %edi
140068dd0:     	movq	%rsi, %rcx
140068dd3:     	callq	0x14009b840 <.text+0x9a840>
140068dd8:     	testb	$0x1, %al
140068dda:     	je	0x140068f63 <.text+0x67f63>
140068de0:     	movq	%rdx, %rbx
140068de3:     	movq	0x500(%rbp), %rdx
140068dea:     	movzwl	0x4e8(%rbp), %ecx
140068df1:     	movzbl	0x4e0(%rbp), %eax
140068df8:     	movq	(%r12), %r8
140068dfc:     	movq	%rdi, 0x430(%rbp)
140068e03:     	movq	0x468(%rbp), %r9
140068e0a:     	movq	%r9, 0x438(%rbp)
140068e11:     	movq	%r8, 0x440(%rbp)
140068e18:     	movb	%r14b, 0x448(%rbp)
140068e1f:     	movups	0x60(%r13), %xmm0
140068e24:     	movups	0x6c(%r13), %xmm1
140068e29:     	movups	%xmm1, 0x3fc(%rbp)
140068e30:     	movaps	%xmm0, 0x3f0(%rbp)
140068e37:     	leaq	0x8e(%r13), %r8
140068e3e:     	movq	0x7e(%r13), %r9
140068e42:     	movq	0x85(%r13), %r10
140068e49:     	movq	%r10, 0x457(%rbp)
140068e50:     	movq	%r9, 0x450(%rbp)
140068e57:     	leaq	0x450(%rbp), %r9
140068e5e:     	movq	%r9, 0x68(%rsp)
140068e63:     	movq	%rdx, 0x60(%rsp)
140068e68:     	movq	%r13, 0x58(%rsp)
140068e6d:     	leaq	0x430(%rbp), %rdx
140068e74:     	movq	%rdx, 0x50(%rsp)
140068e79:     	movq	%r15, 0x48(%rsp)
140068e7e:     	leaq	-0x10(%rbp), %rdx
140068e82:     	movq	%rdx, 0x40(%rsp)
140068e87:     	movq	0x460(%rbp), %rdx
140068e8e:     	movq	%rdx, 0x38(%rsp)
140068e93:     	movq	%r8, 0x30(%rsp)
140068e98:     	movw	%cx, 0x28(%rsp)
140068e9d:     	movb	%al, 0x20(%rsp)
140068ea1:     	leaq	0x410(%rbp), %rcx
140068ea8:     	leaq	0x3f0(%rbp), %r8
140068eaf:     	movq	%rsi, %rdx
140068eb2:     	movq	%rbx, %r9
140068eb5:     	callq	0x140083230 <.text+0x82230>
140068eba:     	cmpb	$-0x1, 0x410(%rbp)
140068ec1:     	je	0x140068f72 <.text+0x67f72>
140068ec7:     	cmpb	$0x1, 0x37640(%rsi,%rbx)
140068ecf:     	movq	0x470(%rbp), %rax
140068ed6:     	jne	0x140068f20 <.text+0x67f20>
140068ed8:     	cmpb	$0x0, 0x37660(%rsi,%rbx)
140068ee0:     	jne	0x140068f20 <.text+0x67f20>
140068ee2:     	movb	$0x0, 0x37640(%rsi,%rbx)
140068eea:     	decq	0x37688(%rsi)
140068ef1:     	leaq	0x37640(%rsi), %rcx
140068ef8:     	movq	$0x0, 0x43510(%rsi,%rbx,8)
140068f04:     	leaq	(%rbx,%rbx,8), %rdx
140068f08:     	leaq	(%rdx,%rdx,2), %rdx
140068f0c:     	addq	%rbx, %rdx
140068f0f:     	movb	$0x2, 0x36a(%rcx,%rdx)
140068f17:     	leaq	(%rbx,%rbx,2), %rdx
140068f1b:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140068f20:     	movups	0x410(%rbp), %xmm0
140068f27:     	movups	0x420(%rbp), %xmm1
140068f2e:     	movups	%xmm1, 0x10(%rax)
140068f32:     	movups	%xmm0, (%rax)
140068f35:     	jmp	0x140068dba <.text+0x67dba>
140068f3a:     	addq	%rcx, %rax
140068f3d:     	addq	$0x15c28, %rax          # imm = 0x15C28
140068f43:     	movq	0x98(%rax), %rax
140068f4a:     	movq	%rax, 0x468(%rbp)
140068f51:     	movl	$0x1, %edi
140068f56:     	callq	0x14009b840 <.text+0x9a840>
140068f5b:     	testb	$0x1, %al
140068f5d:     	jne	0x140068de0 <.text+0x67de0>
140068f63:     	movq	0x470(%rbp), %rax
140068f6a:     	movb	$0x9, (%rax)
140068f6d:     	jmp	0x140068dba <.text+0x67dba>
140068f72:     	movq	0x470(%rbp), %rax
140068f79:     	movq	%rbx, 0x8(%rax)
140068f7d:     	movb	$-0x1, (%rax)
140068f80:     	jmp	0x140068dba <.text+0x67dba>
140068f85:     	leaq	0x203ca4(%rip), %r9     # 0x14026cc30
140068f8c:     	movl	$0x4000, %r8d           # imm = 0x4000
140068f92:     	xorl	%ecx, %ecx
140068f94:     	movq	%rax, %rdx
140068f97:     	callq	0x140251b30 <.text+0x250b30>
140068f9c:     	ud2

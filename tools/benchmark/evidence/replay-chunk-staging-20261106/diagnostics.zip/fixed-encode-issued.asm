
D:\CoapticCurrent\oscore-packet-staging-20261104\option-reuse\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400684f0:     	pushq	%rbp
1400684f1:     	pushq	%r15
1400684f3:     	pushq	%r14
1400684f5:     	pushq	%r13
1400684f7:     	pushq	%r12
1400684f9:     	pushq	%rsi
1400684fa:     	pushq	%rdi
1400684fb:     	pushq	%rbx
1400684fc:     	subq	$0x4f8, %rsp            # imm = 0x4F8
140068503:     	leaq	0x80(%rsp), %rbp
14006850b:     	movq	%r9, %rbx
14006850e:     	movq	%r8, %r14
140068511:     	movq	%rdx, %rdi
140068514:     	movq	%rcx, %rsi
140068517:     	movq	0x4f0(%rbp), %r12
14006851e:     	leaq	-0x10(%rbp), %rcx
140068522:     	movl	$0x400, %r8d            # imm = 0x400
140068528:     	xorl	%edx, %edx
14006852a:     	callq	0x140250e22 <.text+0x24fe22>
14006852f:     	movq	0x8(%r12), %r13
140068534:     	movl	$0x3, %eax
140068539:     	cmpq	$0x3, %r13
14006853d:     	ja	0x14006875c <.text+0x6775c>
140068543:     	cmpb	$0x1, 0x1b748(%rdi,%r13)
14006854c:     	jne	0x14006875c <.text+0x6775c>
140068552:     	movq	0x2b750(%rdi,%r13,8), %rdx
14006855a:     	cmpq	$0x4001, %rdx           # imm = 0x4001
140068561:     	jae	0x1400687b8 <.text+0x677b8>
140068567:     	movq	0x10(%r12), %rcx
14006856c:     	movq	0x18(%r12), %r15
140068571:     	movq	%r15, %r8
140068574:     	movl	$0xb, %eax
140068579:     	addq	%rcx, %r8
14006857c:     	jb	0x14006875c <.text+0x6775c>
140068582:     	cmpq	$0x400, %r15            # imm = 0x400
140068589:     	ja	0x14006875c <.text+0x6775c>
14006858f:     	cmpq	%rdx, %r8
140068592:     	ja	0x14006875c <.text+0x6775c>
140068598:     	movq	%r13, %rax
14006859b:     	shlq	$0xe, %rax
14006859f:     	leaq	(%rdi,%rax), %rdx
1400685a3:     	addq	$0x1b750, %rdx          # imm = 0x1B750
1400685aa:     	addq	%rcx, %rdx
1400685ad:     	leaq	-0x10(%rbp), %rcx
1400685b1:     	movq	%r15, %r8
1400685b4:     	callq	0x140250e10 <.text+0x24fe10>
1400685b9:     	cmpb	$0x0, 0x4f8(%rbp)
1400685c0:     	je	0x1400685d8 <.text+0x675d8>
1400685c2:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
1400685c9:     	cmpq	$0x2, 0x1ac78(%rdi,%rax)
1400685d2:     	jne	0x140068777 <.text+0x67777>
1400685d8:     	movq	$0x0, 0x470(%rbp)
1400685e3:     	movq	%rdi, %rcx
1400685e6:     	callq	0x14009a980 <.text+0x99980>
1400685eb:     	testb	$0x1, %al
1400685ed:     	je	0x1400687aa <.text+0x677aa>
1400685f3:     	movq	%rdx, %r13
1400685f6:     	movq	0x500(%rbp), %rdx
1400685fd:     	movzwl	0x4e8(%rbp), %ecx
140068604:     	movzbl	0x4e0(%rbp), %eax
14006860b:     	movq	(%r12), %r8
14006860f:     	movq	0x470(%rbp), %r9
140068616:     	movq	%r9, 0x438(%rbp)
14006861d:     	movq	0x468(%rbp), %r9
140068624:     	movq	%r9, 0x440(%rbp)
14006862b:     	movq	%r8, 0x448(%rbp)
140068632:     	movzbl	0x4f8(%rbp), %r8d
14006863a:     	movb	%r8b, 0x450(%rbp)
140068641:     	movups	0x60(%r14), %xmm0
140068646:     	movups	0x6c(%r14), %xmm1
14006864b:     	movups	%xmm1, 0x3fc(%rbp)
140068652:     	movaps	%xmm0, 0x3f0(%rbp)
140068659:     	leaq	0x8e(%r14), %r8
140068660:     	movq	0x7e(%r14), %r9
140068664:     	movq	0x85(%r14), %r10
14006866b:     	movq	%r10, 0x45f(%rbp)
140068672:     	movq	%r9, 0x458(%rbp)
140068679:     	leaq	0x458(%rbp), %r9
140068680:     	movq	%r9, 0x68(%rsp)
140068685:     	movq	%rdx, 0x60(%rsp)
14006868a:     	movq	%r14, 0x58(%rsp)
14006868f:     	leaq	0x438(%rbp), %rdx
140068696:     	movq	%rdx, 0x50(%rsp)
14006869b:     	movq	%r15, 0x48(%rsp)
1400686a0:     	leaq	-0x10(%rbp), %rdx
1400686a4:     	movq	%rdx, 0x40(%rsp)
1400686a9:     	movq	%rbx, 0x38(%rsp)
1400686ae:     	movq	%r8, 0x30(%rsp)
1400686b3:     	movw	%cx, 0x28(%rsp)
1400686b8:     	movb	%al, 0x20(%rsp)
1400686bc:     	leaq	0x418(%rbp), %rcx
1400686c3:     	leaq	0x3f0(%rbp), %r8
1400686ca:     	movq	%rdi, %rdx
1400686cd:     	movq	%r13, %r9
1400686d0:     	callq	0x140082880 <.text+0x81880>
1400686d5:     	cmpb	$-0x1, 0x418(%rbp)
1400686dc:     	je	0x1400687af <.text+0x677af>
1400686e2:     	cmpb	$0x1, 0x37740(%rdi,%r13)
1400686eb:     	jne	0x140068745 <.text+0x67745>
1400686ed:     	cmpb	$0x0, 0x37760(%rdi,%r13)
1400686f6:     	jne	0x140068745 <.text+0x67745>
1400686f8:     	movb	$0x0, 0x37740(%rdi,%r13)
140068701:     	decq	0x37788(%rdi)
140068708:     	leaq	0x37740(%rdi), %rax
14006870f:     	movq	$0x0, 0x43610(%rdi,%r13,8)
14006871b:     	leaq	(,%r13,8), %rcx
140068723:     	addq	%r13, %rcx
140068726:     	leaq	(%rcx,%rcx,2), %rcx
14006872a:     	addq	%r13, %rcx
14006872d:     	movb	$0x2, 0x36a(%rax,%rcx)
140068735:     	leaq	(,%r13,2), %rcx
14006873d:     	addq	%r13, %rcx
140068740:     	movb	$0x2, 0x5d(%rax,%rcx,8)
140068745:     	movups	0x418(%rbp), %xmm0
14006874c:     	movups	0x428(%rbp), %xmm1
140068753:     	movups	%xmm1, 0x10(%rsi)
140068757:     	movups	%xmm0, (%rsi)
14006875a:     	jmp	0x140068763 <.text+0x67763>
14006875c:     	movb	$0xa, (%rsi)
14006875f:     	movq	%rax, 0x8(%rsi)
140068763:     	addq	$0x4f8, %rsp            # imm = 0x4F8
14006876a:     	popq	%rbx
14006876b:     	popq	%rdi
14006876c:     	popq	%rsi
14006876d:     	popq	%r12
14006876f:     	popq	%r13
140068771:     	popq	%r14
140068773:     	popq	%r15
140068775:     	popq	%rbp
140068776:     	retq
140068777:     	addq	%rdi, %rax
14006877a:     	addq	$0x1ac78, %rax          # imm = 0x1AC78
140068780:     	movq	0x98(%rax), %rax
140068787:     	movq	%rax, 0x468(%rbp)
14006878e:     	movl	$0x1, %eax
140068793:     	movq	%rax, 0x470(%rbp)
14006879a:     	movq	%rdi, %rcx
14006879d:     	callq	0x14009a980 <.text+0x99980>
1400687a2:     	testb	$0x1, %al
1400687a4:     	jne	0x1400685f3 <.text+0x675f3>
1400687aa:     	movb	$0x9, (%rsi)
1400687ad:     	jmp	0x140068763 <.text+0x67763>
1400687af:     	movq	%r13, 0x8(%rsi)
1400687b3:     	movb	$-0x1, (%rsi)
1400687b6:     	jmp	0x140068763 <.text+0x67763>
1400687b8:     	leaq	0x204459(%rip), %r9     # 0x14026cc18
1400687bf:     	movl	$0x4000, %r8d           # imm = 0x4000
1400687c5:     	xorl	%ecx, %ecx
1400687c7:     	callq	0x140251860 <.text+0x250860>
1400687cc:     	ud2

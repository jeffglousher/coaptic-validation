
D:\CoapticCurrent\body-transfer-borrow-20261106\slice-staging\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068cd0:     	pushq	%rbp
140068cd1:     	pushq	%r15
140068cd3:     	pushq	%r14
140068cd5:     	pushq	%r13
140068cd7:     	pushq	%r12
140068cd9:     	pushq	%rsi
140068cda:     	pushq	%rdi
140068cdb:     	pushq	%rbx
140068cdc:     	subq	$0x8d8, %rsp            # imm = 0x8D8
140068ce3:     	leaq	0x80(%rsp), %rbp
140068ceb:     	movq	0x8d0(%rbp), %r12
140068cf2:     	movq	0x8(%r12), %r13
140068cf7:     	movl	$0x3, %r10d
140068cfd:     	cmpq	$0x3, %r13
140068d01:     	ja	0x140068da2 <.text+0x67da2>
140068d07:     	cmpb	$0x1, 0x166f8(%rdx,%r13)
140068d10:     	jne	0x140068da2 <.text+0x67da2>
140068d16:     	movq	0x26700(%rdx,%r13,8), %rax
140068d1e:     	cmpq	$0x4001, %rax           # imm = 0x4001
140068d24:     	jae	0x140068fbc <.text+0x67fbc>
140068d2a:     	movq	0x10(%r12), %r11
140068d2f:     	movq	0x18(%r12), %rdi
140068d34:     	movq	%rdi, %rsi
140068d37:     	movl	$0xb, %r10d
140068d3d:     	addq	%r11, %rsi
140068d40:     	jb	0x140068da2 <.text+0x67da2>
140068d42:     	cmpq	$0x400, %rdi            # imm = 0x400
140068d49:     	ja	0x140068da2 <.text+0x67da2>
140068d4b:     	cmpq	%rax, %rsi
140068d4e:     	ja	0x140068da2 <.text+0x67da2>
140068d50:     	movq	%r8, 0x850(%rbp)
140068d57:     	movq	%r9, 0x848(%rbp)
140068d5e:     	movq	%rcx, %r15
140068d61:     	movq	%r13, %rax
140068d64:     	shlq	$0xe, %rax
140068d68:     	movq	%rdx, %rsi
140068d6b:     	leaq	(%rdx,%rax), %rbx
140068d6f:     	addq	$0x16700, %rbx          # imm = 0x16700
140068d76:     	addq	%r11, %rbx
140068d79:     	cmpq	$0x400, %rdi            # imm = 0x400
140068d80:     	jne	0x140068dbd <.text+0x67dbd>
140068d82:     	leaq	-0x10(%rbp), %rcx
140068d86:     	movl	$0x400, %r8d            # imm = 0x400
140068d8c:     	movq	%rbx, %rdx
140068d8f:     	callq	0x140251140 <.text+0x250140>
140068d94:     	cmpb	$0x0, 0x8d8(%rbp)
140068d9b:     	movq	%rsi, %rcx
140068d9e:     	jne	0x140068e00 <.text+0x67e00>
140068da0:     	jmp	0x140068e16 <.text+0x67e16>
140068da2:     	movb	$0xa, (%rcx)
140068da5:     	movq	%r10, 0x8(%rcx)
140068da9:     	addq	$0x8d8, %rsp            # imm = 0x8D8
140068db0:     	popq	%rbx
140068db1:     	popq	%rdi
140068db2:     	popq	%rsi
140068db3:     	popq	%r12
140068db5:     	popq	%r13
140068db7:     	popq	%r14
140068db9:     	popq	%r15
140068dbb:     	popq	%rbp
140068dbc:     	retq
140068dbd:     	leaq	0x3f0(%rbp), %r14
140068dc4:     	movl	$0x400, %r8d            # imm = 0x400
140068dca:     	movq	%r14, %rcx
140068dcd:     	xorl	%edx, %edx
140068dcf:     	callq	0x140251152 <.text+0x250152>
140068dd4:     	movq	%r14, %rcx
140068dd7:     	movq	%rbx, %rdx
140068dda:     	movq	%rdi, %r8
140068ddd:     	callq	0x140251140 <.text+0x250140>
140068de2:     	leaq	-0x10(%rbp), %rcx
140068de6:     	movl	$0x400, %r8d            # imm = 0x400
140068dec:     	movq	%r14, %rdx
140068def:     	callq	0x140251140 <.text+0x250140>
140068df4:     	cmpb	$0x0, 0x8d8(%rbp)
140068dfb:     	movq	%rsi, %rcx
140068dfe:     	je	0x140068e16 <.text+0x67e16>
140068e00:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
140068e07:     	cmpq	$0x2, 0x15c28(%rcx,%rax)
140068e10:     	jne	0x140068f83 <.text+0x67f83>
140068e16:     	xorl	%r14d, %r14d
140068e19:     	callq	0x14009b8e0 <.text+0x9a8e0>
140068e1e:     	testb	$0x1, %al
140068e20:     	je	0x140068fa6 <.text+0x67fa6>
140068e26:     	movq	%rdx, %rbx
140068e29:     	movq	0x8e0(%rbp), %rdx
140068e30:     	movzwl	0x8c8(%rbp), %ecx
140068e37:     	movzbl	0x8c0(%rbp), %eax
140068e3e:     	movq	(%r12), %r8
140068e42:     	movq	%r14, 0x3f0(%rbp)
140068e49:     	movq	%r13, 0x3f8(%rbp)
140068e50:     	movq	%r8, 0x400(%rbp)
140068e57:     	movzbl	0x8d8(%rbp), %r8d
140068e5f:     	movb	%r8b, 0x408(%rbp)
140068e66:     	movq	0x850(%rbp), %r8
140068e6d:     	movups	0x60(%r8), %xmm0
140068e72:     	movups	0x6c(%r8), %xmm1
140068e77:     	movups	%xmm1, 0x7fc(%rbp)
140068e7e:     	movaps	%xmm0, 0x7f0(%rbp)
140068e85:     	leaq	0x8e(%r8), %r9
140068e8c:     	movq	0x7e(%r8), %r10
140068e90:     	movq	0x85(%r8), %r11
140068e97:     	movq	%r11, 0x83f(%rbp)
140068e9e:     	movq	%r10, 0x838(%rbp)
140068ea5:     	leaq	0x838(%rbp), %r10
140068eac:     	movq	%r10, 0x68(%rsp)
140068eb1:     	movq	%rdx, 0x60(%rsp)
140068eb6:     	movq	%r8, 0x58(%rsp)
140068ebb:     	leaq	0x3f0(%rbp), %rdx
140068ec2:     	movq	%rdx, 0x50(%rsp)
140068ec7:     	movq	%rdi, 0x48(%rsp)
140068ecc:     	leaq	-0x10(%rbp), %rdx
140068ed0:     	movq	%rdx, 0x40(%rsp)
140068ed5:     	movq	0x848(%rbp), %rdx
140068edc:     	movq	%rdx, 0x38(%rsp)
140068ee1:     	movq	%r9, 0x30(%rsp)
140068ee6:     	movw	%cx, 0x28(%rsp)
140068eeb:     	movb	%al, 0x20(%rsp)
140068eef:     	leaq	0x818(%rbp), %rcx
140068ef6:     	leaq	0x7f0(%rbp), %r8
140068efd:     	movq	%rsi, %rdx
140068f00:     	movq	%rbx, %r9
140068f03:     	callq	0x1400832d0 <.text+0x822d0>
140068f08:     	cmpb	$-0x1, 0x818(%rbp)
140068f0f:     	je	0x140068faf <.text+0x67faf>
140068f15:     	cmpb	$0x1, 0x37640(%rsi,%rbx)
140068f1d:     	jne	0x140068f67 <.text+0x67f67>
140068f1f:     	cmpb	$0x0, 0x37660(%rsi,%rbx)
140068f27:     	jne	0x140068f67 <.text+0x67f67>
140068f29:     	movb	$0x0, 0x37640(%rsi,%rbx)
140068f31:     	decq	0x37688(%rsi)
140068f38:     	leaq	0x37640(%rsi), %rax
140068f3f:     	movq	$0x0, 0x43510(%rsi,%rbx,8)
140068f4b:     	leaq	(%rbx,%rbx,8), %rcx
140068f4f:     	leaq	(%rcx,%rcx,2), %rcx
140068f53:     	addq	%rbx, %rcx
140068f56:     	movb	$0x2, 0x36a(%rax,%rcx)
140068f5e:     	leaq	(%rbx,%rbx,2), %rcx
140068f62:     	movb	$0x2, 0x5d(%rax,%rcx,8)
140068f67:     	movups	0x818(%rbp), %xmm0
140068f6e:     	movups	0x828(%rbp), %xmm1
140068f75:     	movups	%xmm1, 0x10(%r15)
140068f7a:     	movups	%xmm0, (%r15)
140068f7e:     	jmp	0x140068da9 <.text+0x67da9>
140068f83:     	addq	%rcx, %rax
140068f86:     	addq	$0x15c28, %rax          # imm = 0x15C28
140068f8c:     	movq	0x98(%rax), %r13
140068f93:     	movl	$0x1, %r14d
140068f99:     	callq	0x14009b8e0 <.text+0x9a8e0>
140068f9e:     	testb	$0x1, %al
140068fa0:     	jne	0x140068e26 <.text+0x67e26>
140068fa6:     	movb	$0x9, (%r15)
140068faa:     	jmp	0x140068da9 <.text+0x67da9>
140068faf:     	movq	%rbx, 0x8(%r15)
140068fb3:     	movb	$-0x1, (%r15)
140068fb7:     	jmp	0x140068da9 <.text+0x67da9>
140068fbc:     	leaq	0x203c6d(%rip), %r9     # 0x14026cc30
140068fc3:     	movl	$0x4000, %r8d           # imm = 0x4000
140068fc9:     	xorl	%ecx, %ecx
140068fcb:     	movq	%rax, %rdx
140068fce:     	callq	0x140251bd0 <.text+0x250bd0>
140068fd3:     	ud2

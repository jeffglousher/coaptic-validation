
D:\CoapticCurrent\body-transfer-borrow-20261106\slice-staging\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400689c0:     	pushq	%rbp
1400689c1:     	pushq	%r15
1400689c3:     	pushq	%r14
1400689c5:     	pushq	%r13
1400689c7:     	pushq	%r12
1400689c9:     	pushq	%rsi
1400689ca:     	pushq	%rdi
1400689cb:     	pushq	%rbx
1400689cc:     	subq	$0x8e8, %rsp            # imm = 0x8E8
1400689d3:     	leaq	0x80(%rsp), %rbp
1400689db:     	movq	0x8e0(%rbp), %r12
1400689e2:     	movq	0x8(%r12), %r13
1400689e7:     	movl	$0x3, %r10d
1400689ed:     	cmpq	$0x3, %r13
1400689f1:     	ja	0x140068a91 <.text+0x67a91>
1400689f7:     	cmpb	$0x1, 0x166f8(%rdx,%r13)
140068a00:     	jne	0x140068a91 <.text+0x67a91>
140068a06:     	movq	0x26700(%rdx,%r13,8), %rax
140068a0e:     	cmpq	$0x4001, %rax           # imm = 0x4001
140068a14:     	jae	0x140068cb5 <.text+0x67cb5>
140068a1a:     	movq	0x10(%r12), %r11
140068a1f:     	movq	0x18(%r12), %rdi
140068a24:     	movq	%rdi, %rsi
140068a27:     	movl	$0xb, %r10d
140068a2d:     	addq	%r11, %rsi
140068a30:     	jb	0x140068a91 <.text+0x67a91>
140068a32:     	cmpq	$0x400, %rdi            # imm = 0x400
140068a39:     	ja	0x140068a91 <.text+0x67a91>
140068a3b:     	cmpq	%rax, %rsi
140068a3e:     	ja	0x140068a91 <.text+0x67a91>
140068a40:     	movq	%r8, 0x860(%rbp)
140068a47:     	movq	%r9, 0x858(%rbp)
140068a4e:     	movq	%rcx, %r15
140068a51:     	movq	%r13, %rax
140068a54:     	shlq	$0xe, %rax
140068a58:     	movq	%rdx, %rsi
140068a5b:     	leaq	(%rdx,%rax), %rbx
140068a5f:     	addq	$0x16700, %rbx          # imm = 0x16700
140068a66:     	addq	%r11, %rbx
140068a69:     	cmpq	$0x400, %rdi            # imm = 0x400
140068a70:     	jne	0x140068aac <.text+0x67aac>
140068a72:     	movq	%rbp, %rcx
140068a75:     	movl	$0x400, %r8d            # imm = 0x400
140068a7b:     	movq	%rbx, %rdx
140068a7e:     	callq	0x140251140 <.text+0x250140>
140068a83:     	cmpb	$0x0, 0x8e8(%rbp)
140068a8a:     	movq	%rsi, %rcx
140068a8d:     	jne	0x140068aee <.text+0x67aee>
140068a8f:     	jmp	0x140068b04 <.text+0x67b04>
140068a91:     	movb	$0xa, (%rcx)
140068a94:     	movq	%r10, 0x8(%rcx)
140068a98:     	addq	$0x8e8, %rsp            # imm = 0x8E8
140068a9f:     	popq	%rbx
140068aa0:     	popq	%rdi
140068aa1:     	popq	%rsi
140068aa2:     	popq	%r12
140068aa4:     	popq	%r13
140068aa6:     	popq	%r14
140068aa8:     	popq	%r15
140068aaa:     	popq	%rbp
140068aab:     	retq
140068aac:     	leaq	0x400(%rbp), %r14
140068ab3:     	movl	$0x400, %r8d            # imm = 0x400
140068ab9:     	movq	%r14, %rcx
140068abc:     	xorl	%edx, %edx
140068abe:     	callq	0x140251152 <.text+0x250152>
140068ac3:     	movq	%r14, %rcx
140068ac6:     	movq	%rbx, %rdx
140068ac9:     	movq	%rdi, %r8
140068acc:     	callq	0x140251140 <.text+0x250140>
140068ad1:     	movq	%rbp, %rcx
140068ad4:     	movl	$0x400, %r8d            # imm = 0x400
140068ada:     	movq	%r14, %rdx
140068add:     	callq	0x140251140 <.text+0x250140>
140068ae2:     	cmpb	$0x0, 0x8e8(%rbp)
140068ae9:     	movq	%rsi, %rcx
140068aec:     	je	0x140068b04 <.text+0x67b04>
140068aee:     	imulq	$0x2b0, %r13, %rax      # imm = 0x2B0
140068af5:     	cmpq	$0x2, 0x15c28(%rcx,%rax)
140068afe:     	jne	0x140068c7c <.text+0x67c7c>
140068b04:     	xorl	%r14d, %r14d
140068b07:     	callq	0x14009b8e0 <.text+0x9a8e0>
140068b0c:     	testb	$0x1, %al
140068b0e:     	je	0x140068c9f <.text+0x67c9f>
140068b14:     	movq	%rdx, %rbx
140068b17:     	movq	0x8f8(%rbp), %rdx
140068b1e:     	movq	0x8f0(%rbp), %r8
140068b25:     	movzwl	0x8d8(%rbp), %ecx
140068b2c:     	movzbl	0x8d0(%rbp), %eax
140068b33:     	movq	(%r12), %r9
140068b37:     	movq	%r14, 0x400(%rbp)
140068b3e:     	movq	%r13, 0x408(%rbp)
140068b45:     	movq	%r9, 0x410(%rbp)
140068b4c:     	movzbl	0x8e8(%rbp), %r9d
140068b54:     	movb	%r9b, 0x418(%rbp)
140068b5b:     	movq	0x860(%rbp), %r9
140068b62:     	movups	0x60(%r9), %xmm0
140068b67:     	movups	0x6c(%r9), %xmm1
140068b6c:     	movups	%xmm1, 0x80c(%rbp)
140068b73:     	movaps	%xmm0, 0x800(%rbp)
140068b7a:     	leaq	0x8e(%r9), %r10
140068b81:     	movq	0x7e(%r9), %r11
140068b85:     	movq	0x85(%r9), %r14
140068b8c:     	movq	%r14, 0x84f(%rbp)
140068b93:     	movq	%r11, 0x848(%rbp)
140068b9a:     	leaq	0x848(%rbp), %r11
140068ba1:     	movq	%r11, 0x70(%rsp)
140068ba6:     	movq	%rdx, 0x68(%rsp)
140068bab:     	movq	%r8, 0x60(%rsp)
140068bb0:     	movq	%r9, 0x58(%rsp)
140068bb5:     	leaq	0x400(%rbp), %rdx
140068bbc:     	movq	%rdx, 0x50(%rsp)
140068bc1:     	movq	%rdi, 0x48(%rsp)
140068bc6:     	movq	%rbp, %rdx
140068bc9:     	movq	%rdx, 0x40(%rsp)
140068bce:     	movq	0x858(%rbp), %rdx
140068bd5:     	movq	%rdx, 0x38(%rsp)
140068bda:     	movq	%r10, 0x30(%rsp)
140068bdf:     	movw	%cx, 0x28(%rsp)
140068be4:     	movb	%al, 0x20(%rsp)
140068be8:     	leaq	0x828(%rbp), %rcx
140068bef:     	leaq	0x800(%rbp), %r8
140068bf6:     	movq	%rsi, %rdx
140068bf9:     	movq	%rbx, %r9
140068bfc:     	callq	0x140081ae0 <.text+0x80ae0>
140068c01:     	cmpb	$-0x1, 0x828(%rbp)
140068c08:     	je	0x140068ca8 <.text+0x67ca8>
140068c0e:     	cmpb	$0x1, 0x37640(%rsi,%rbx)
140068c16:     	jne	0x140068c60 <.text+0x67c60>
140068c18:     	cmpb	$0x0, 0x37660(%rsi,%rbx)
140068c20:     	jne	0x140068c60 <.text+0x67c60>
140068c22:     	movb	$0x0, 0x37640(%rsi,%rbx)
140068c2a:     	decq	0x37688(%rsi)
140068c31:     	leaq	0x37640(%rsi), %rax
140068c38:     	movq	$0x0, 0x43510(%rsi,%rbx,8)
140068c44:     	leaq	(%rbx,%rbx,8), %rcx
140068c48:     	leaq	(%rcx,%rcx,2), %rcx
140068c4c:     	addq	%rbx, %rcx
140068c4f:     	movb	$0x2, 0x36a(%rax,%rcx)
140068c57:     	leaq	(%rbx,%rbx,2), %rcx
140068c5b:     	movb	$0x2, 0x5d(%rax,%rcx,8)
140068c60:     	movups	0x828(%rbp), %xmm0
140068c67:     	movups	0x838(%rbp), %xmm1
140068c6e:     	movups	%xmm1, 0x10(%r15)
140068c73:     	movups	%xmm0, (%r15)
140068c77:     	jmp	0x140068a98 <.text+0x67a98>
140068c7c:     	addq	%rcx, %rax
140068c7f:     	addq	$0x15c28, %rax          # imm = 0x15C28
140068c85:     	movq	0x98(%rax), %r13
140068c8c:     	movl	$0x1, %r14d
140068c92:     	callq	0x14009b8e0 <.text+0x9a8e0>
140068c97:     	testb	$0x1, %al
140068c99:     	jne	0x140068b14 <.text+0x67b14>
140068c9f:     	movb	$0x9, (%r15)
140068ca3:     	jmp	0x140068a98 <.text+0x67a98>
140068ca8:     	movq	%rbx, 0x8(%r15)
140068cac:     	movb	$-0x1, (%r15)
140068cb0:     	jmp	0x140068a98 <.text+0x67a98>
140068cb5:     	leaq	0x203f74(%rip), %r9     # 0x14026cc30
140068cbc:     	movl	$0x4000, %r8d           # imm = 0x4000
140068cc2:     	xorl	%ecx, %ecx
140068cc4:     	movq	%rax, %rdx
140068cc7:     	callq	0x140251bd0 <.text+0x250bd0>
140068ccc:     	ud2

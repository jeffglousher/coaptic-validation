
D:\CoapticCurrent\body-transfer-borrow-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068dd0:     	pushq	%rbp
140068dd1:     	pushq	%r15
140068dd3:     	pushq	%r14
140068dd5:     	pushq	%r13
140068dd7:     	pushq	%r12
140068dd9:     	pushq	%rsi
140068dda:     	pushq	%rdi
140068ddb:     	pushq	%rbx
140068ddc:     	subq	$0x8f8, %rsp            # imm = 0x8F8
140068de3:     	leaq	0x80(%rsp), %rbp
140068deb:     	movq	0x8f0(%rbp), %r15
140068df2:     	movq	0x8(%r15), %r12
140068df6:     	movb	$0x3, %r10b
140068df9:     	cmpq	$0x3, %r12
140068dfd:     	ja	0x140068f85 <.text+0x67f85>
140068e03:     	cmpb	$0x1, 0x166f8(%rdx,%r12)
140068e0c:     	jne	0x140068f85 <.text+0x67f85>
140068e12:     	movq	0x26700(%rdx,%r12,8), %rax
140068e1a:     	cmpq	$0x4001, %rax           # imm = 0x4001
140068e20:     	jae	0x14006914b <.text+0x6814b>
140068e26:     	movq	0x10(%r15), %r11
140068e2a:     	movq	0x18(%r15), %rsi
140068e2e:     	movq	%rsi, %rdi
140068e31:     	movb	$0xb, %r10b
140068e34:     	addq	%r11, %rdi
140068e37:     	jb	0x140068f85 <.text+0x67f85>
140068e3d:     	cmpq	$0x400, %rsi            # imm = 0x400
140068e44:     	ja	0x140068f85 <.text+0x67f85>
140068e4a:     	cmpq	%rax, %rdi
140068e4d:     	ja	0x140068f85 <.text+0x67f85>
140068e53:     	movq	%r8, 0x870(%rbp)
140068e5a:     	movq	%r9, 0x868(%rbp)
140068e61:     	movq	%rcx, %r14
140068e64:     	leaq	-0x8(%rbp), %r13
140068e68:     	movq	%r12, %rax
140068e6b:     	shlq	$0xe, %rax
140068e6f:     	movq	%rdx, %rdi
140068e72:     	leaq	(%rdx,%rax), %rbx
140068e76:     	addq	$0x16700, %rbx          # imm = 0x16700
140068e7d:     	addq	%r11, %rbx
140068e80:     	cmpq	$0x400, %rsi            # imm = 0x400
140068e87:     	je	0x140068e9a <.text+0x67e9a>
140068e89:     	leaq	-0x10(%rbp), %rcx
140068e8d:     	movl	$0x400, %r8d            # imm = 0x400
140068e93:     	xorl	%edx, %edx
140068e95:     	callq	0x1402513e2 <.text+0x2503e2>
140068e9a:     	leaq	-0x10(%rbp), %rcx
140068e9e:     	movq	%rbx, %rdx
140068ea1:     	movq	%rsi, %r8
140068ea4:     	callq	0x1402513d0 <.text+0x2503d0>
140068ea9:     	movzbl	-0x9(%rbp), %eax
140068ead:     	movzbl	-0x1(%rbp), %ecx
140068eb1:     	movzbl	0x7(%rbp), %r8d
140068eb6:     	movzbl	0xf(%rbp), %r9d
140068ebb:     	leaq	0x17(%rbp), %rdx
140068ebf:     	movl	-0x10(%rbp), %r10d
140068ec3:     	movl	-0xd(%rbp), %r11d
140068ec7:     	movl	%r10d, 0x3f0(%rbp)
140068ece:     	movl	%r11d, 0x3f3(%rbp)
140068ed5:     	movb	%al, 0x3f7(%rbp)
140068edb:     	movl	(%r13), %eax
140068edf:     	movl	0x3(%r13), %r10d
140068ee3:     	movl	%eax, 0x3f8(%rbp)
140068ee9:     	movl	%r10d, 0x3fb(%rbp)
140068ef0:     	movb	%cl, 0x3ff(%rbp)
140068ef6:     	movl	0x8(%r13), %eax
140068efa:     	movl	0xb(%r13), %ecx
140068efe:     	movl	%eax, 0x400(%rbp)
140068f04:     	movl	%ecx, 0x403(%rbp)
140068f0a:     	movb	%r8b, 0x407(%rbp)
140068f11:     	movl	0x10(%r13), %eax
140068f15:     	movl	0x13(%r13), %ecx
140068f19:     	movl	%ecx, 0x40b(%rbp)
140068f1f:     	movl	%eax, 0x408(%rbp)
140068f25:     	movb	%r9b, 0x40f(%rbp)
140068f2c:     	movl	0x18(%r13), %eax
140068f30:     	movl	0x1b(%r13), %ecx
140068f34:     	movl	%ecx, 0x413(%rbp)
140068f3a:     	movl	%eax, 0x410(%rbp)
140068f40:     	leaq	0x417(%rbp), %rcx
140068f47:     	movl	$0x3d9, %r8d            # imm = 0x3D9
140068f4d:     	callq	0x1402513d0 <.text+0x2503d0>
140068f52:     	cmpb	$0x0, 0x8f8(%rbp)
140068f59:     	je	0x140068fa0 <.text+0x67fa0>
140068f5b:     	imulq	$0x2b0, %r12, %rax      # imm = 0x2B0
140068f62:     	movq	%rdi, %rcx
140068f65:     	cmpq	$0x2, 0x15c28(%rdi,%rax)
140068f6e:     	jne	0x140069112 <.text+0x68112>
140068f74:     	xorl	%r12d, %r12d
140068f77:     	callq	0x14009bb70 <.text+0x9ab70>
140068f7c:     	testb	$0x1, %al
140068f7e:     	jne	0x140068fb3 <.text+0x67fb3>
140068f80:     	jmp	0x140069135 <.text+0x68135>
140068f85:     	movb	$0xa, (%rcx)
140068f88:     	movb	%r10b, 0x8(%rcx)
140068f8c:     	addq	$0x8f8, %rsp            # imm = 0x8F8
140068f93:     	popq	%rbx
140068f94:     	popq	%rdi
140068f95:     	popq	%rsi
140068f96:     	popq	%r12
140068f98:     	popq	%r13
140068f9a:     	popq	%r14
140068f9c:     	popq	%r15
140068f9e:     	popq	%rbp
140068f9f:     	retq
140068fa0:     	xorl	%r12d, %r12d
140068fa3:     	movq	%rdi, %rcx
140068fa6:     	callq	0x14009bb70 <.text+0x9ab70>
140068fab:     	testb	$0x1, %al
140068fad:     	je	0x140069135 <.text+0x68135>
140068fb3:     	movq	%rdx, %rbx
140068fb6:     	movq	0x900(%rbp), %rdx
140068fbd:     	movzwl	0x8e8(%rbp), %ecx
140068fc4:     	movzbl	0x8e0(%rbp), %eax
140068fcb:     	movq	(%r15), %r8
140068fce:     	movq	%r12, 0x838(%rbp)
140068fd5:     	movq	%r13, 0x840(%rbp)
140068fdc:     	movq	%r8, 0x848(%rbp)
140068fe3:     	movzbl	0x8f8(%rbp), %r8d
140068feb:     	movb	%r8b, 0x850(%rbp)
140068ff2:     	movq	0x870(%rbp), %r8
140068ff9:     	movups	0x60(%r8), %xmm0
140068ffe:     	movups	0x6c(%r8), %xmm1
140069003:     	movups	%xmm1, 0x7fc(%rbp)
14006900a:     	movaps	%xmm0, 0x7f0(%rbp)
140069011:     	leaq	0x8e(%r8), %r9
140069018:     	movq	0x7e(%r8), %r10
14006901c:     	movq	0x85(%r8), %r11
140069023:     	movq	%r11, 0x85f(%rbp)
14006902a:     	movq	%r10, 0x858(%rbp)
140069031:     	leaq	0x858(%rbp), %r10
140069038:     	movq	%r10, 0x68(%rsp)
14006903d:     	movq	%rdx, 0x60(%rsp)
140069042:     	movq	%r8, 0x58(%rsp)
140069047:     	leaq	0x838(%rbp), %rdx
14006904e:     	movq	%rdx, 0x50(%rsp)
140069053:     	movq	%rsi, 0x48(%rsp)
140069058:     	leaq	0x3f0(%rbp), %rdx
14006905f:     	movq	%rdx, 0x40(%rsp)
140069064:     	movq	0x868(%rbp), %rdx
14006906b:     	movq	%rdx, 0x38(%rsp)
140069070:     	movq	%r9, 0x30(%rsp)
140069075:     	movw	%cx, 0x28(%rsp)
14006907a:     	movb	%al, 0x20(%rsp)
14006907e:     	leaq	0x818(%rbp), %rcx
140069085:     	leaq	0x7f0(%rbp), %r8
14006908c:     	movq	%rdi, %rdx
14006908f:     	movq	%rbx, %r9
140069092:     	callq	0x140083560 <.text+0x82560>
140069097:     	cmpb	$-0x1, 0x818(%rbp)
14006909e:     	je	0x14006913e <.text+0x6813e>
1400690a4:     	cmpb	$0x1, 0x37640(%rdi,%rbx)
1400690ac:     	jne	0x1400690f6 <.text+0x680f6>
1400690ae:     	cmpb	$0x0, 0x37660(%rdi,%rbx)
1400690b6:     	jne	0x1400690f6 <.text+0x680f6>
1400690b8:     	movb	$0x0, 0x37640(%rdi,%rbx)
1400690c0:     	decq	0x37688(%rdi)
1400690c7:     	leaq	0x37640(%rdi), %rax
1400690ce:     	movq	$0x0, 0x43510(%rdi,%rbx,8)
1400690da:     	leaq	(%rbx,%rbx,8), %rcx
1400690de:     	leaq	(%rcx,%rcx,2), %rcx
1400690e2:     	addq	%rbx, %rcx
1400690e5:     	movb	$0x2, 0x36a(%rax,%rcx)
1400690ed:     	leaq	(%rbx,%rbx,2), %rcx
1400690f1:     	movb	$0x2, 0x5d(%rax,%rcx,8)
1400690f6:     	movups	0x818(%rbp), %xmm0
1400690fd:     	movups	0x828(%rbp), %xmm1
140069104:     	movups	%xmm1, 0x10(%r14)
140069109:     	movups	%xmm0, (%r14)
14006910d:     	jmp	0x140068f8c <.text+0x67f8c>
140069112:     	addq	%rcx, %rax
140069115:     	addq	$0x15c28, %rax          # imm = 0x15C28
14006911b:     	movq	0x98(%rax), %r13
140069122:     	movl	$0x1, %r12d
140069128:     	callq	0x14009bb70 <.text+0x9ab70>
14006912d:     	testb	$0x1, %al
14006912f:     	jne	0x140068fb3 <.text+0x67fb3>
140069135:     	movb	$0x9, (%r14)
140069139:     	jmp	0x140068f8c <.text+0x67f8c>
14006913e:     	movq	%rbx, 0x8(%r14)
140069142:     	movb	$-0x1, (%r14)
140069146:     	jmp	0x140068f8c <.text+0x67f8c>
14006914b:     	leaq	0x203ade(%rip), %r9     # 0x14026cc30
140069152:     	movl	$0x4000, %r8d           # imm = 0x4000
140069158:     	xorl	%ecx, %ecx
14006915a:     	movq	%rax, %rdx
14006915d:     	callq	0x140251e60 <.text+0x250e60>
140069162:     	ud2

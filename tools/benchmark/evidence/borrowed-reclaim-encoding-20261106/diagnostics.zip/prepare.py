from pathlib import Path
import json, subprocess, hashlib, shutil
r = Path(__file__).resolve().parent
prior = Path('D:/CoapticCurrent/owned-replay-reclaim-20261106')
repo = Path('C:/Users/jeffg/.t3/worktrees/coaptic/t3-a578955c')
sha = '40e195ab66a839f19df5949a3fff9d0c2e35336c'
old = '32c32d1997fd416f9cd80feeaa867eb4d8b452bb'
v = json.loads((prior/'source-verification.json').read_text())
v['source'] = sha
fixture = Path(v['fixture_root'])/'coaptic'
for name in v['source_file_hashes']:
    data = subprocess.check_output(['git','-C',str(repo),'show',sha+':'+name]).replace(b'\r\n',b'\n')
    p = fixture/name
    if p.read_bytes() != data: p.write_bytes(data)
    v['source_file_hashes'][name] = hashlib.sha256(data).hexdigest()
patch = subprocess.check_output(['git','-C',str(repo),'diff','--binary',v['baseline'],sha,'--','src','crates','tests','Cargo.toml','Cargo.lock'])
(r/'candidate.patch').write_bytes(patch)
v['patch_sha256'] = hashlib.sha256(patch).hexdigest()
(r/'source-verification.json').write_text(json.dumps(v,indent=2)+'\n')
for name in ['build-preflight.py','build.py','layout.py','inspect.py','measure.py','qualify.py']:
    text = (prior/name).read_text().replace(old,sha)
    if name == 'inspect.py':
        text = text.replace('(?=^\\d+ \\| S_LPROC32)', '(?=^\\s*\\d+ \\| S_LPROC32)')
    (r/name).write_text(text)
(r/'B').mkdir(exist_ok=True)
(r/'layout32').mkdir(exist_ok=True)
for name in ['audit.py','Cargo.toml','Cargo.lock','lib.rs','baseline-build.log','baseline-constants.txt','baseline-layout.txt','baseline-source.json']:
    shutil.copyfile(prior/'layout32'/name,r/'layout32'/name)
shutil.copyfile(prior/'fixture-sha256.json',r/'fixture-sha256.json')
m = json.loads((prior/'METHOD-BEFORE.json').read_text())
m['candidate'] = sha
m['source_hypothesis'] = m['hypothesis'] = 'Encode the reclaimed empty ACK into a borrowed16-byte destination, returning only its length; construct the same-key/deadline row in storage. This removes the previous full-row return boundary and its emitted304-byte copy. Retain owned reclaim search reduction, compact replay/occupancy and full-chunk initialization. Require selected reclaim frames to nongrow before any timing.'
m['tradeoffs'] = 'No added resident owner or allocation. The unmerged optional hook now takes a borrowed encoding callback, validates its returned length, and preserves release-before-encoding, exact duplicate-key and cursor behavior. Full64-bit deadlines/capacities/security remain; active-owner Eq/Hash semantics are explicitly documented. Fixed storage retains one exact-key walk.'
m['preflight_repair'] = 'Prior32c32d1 fails3CPU bounds and fixed-Service reclaim frame grows32 bytes over pinned baseline. Eliminate emitted row-return copy with a distinct API/ownership change; no unchanged source resampling.'
m['memory_rule'] += ' Additionally require selected reclaim frame sizes <= pinned baseline: SmallDevice800, ConstrainedWithBodies800, Servicefixed784, Serviceallocated800 bytes; compiler reservations only, no peak-stack claim.'
(r/'METHOD-BEFORE.json').write_text(json.dumps(m,indent=2)+'\n')
print({'source':sha,'verified_files':len(v['source_file_hashes'])},flush=True)

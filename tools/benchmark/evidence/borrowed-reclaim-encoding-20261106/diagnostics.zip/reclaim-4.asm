
D:\CoapticCurrent\borrowed-reclaim-encoding-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009f9a0:     	pushq	%rbp
14009f9a1:     	pushq	%r15
14009f9a3:     	pushq	%r14
14009f9a5:     	pushq	%r13
14009f9a7:     	pushq	%r12
14009f9a9:     	pushq	%rsi
14009f9aa:     	pushq	%rdi
14009f9ab:     	pushq	%rbx
14009f9ac:     	subq	$0x218, %rsp            # imm = 0x218
14009f9b3:     	leaq	0x80(%rsp), %rbp
14009f9bb:     	movaps	%xmm6, 0x180(%rbp)
14009f9c2:     	movq	0xe8(%rcx), %rax
14009f9c9:     	testq	%rax, %rax
14009f9cc:     	je	0x14009fad1 <.text+0x9ead1>
14009f9d2:     	leaq	0xc0(%rcx), %rsi
14009f9d9:     	movq	0xe0(%rcx), %r9
14009f9e0:     	movq	0xc8(%rcx), %r10
14009f9e7:     	movq	0xd0(%rcx), %r11
14009f9ee:     	xorl	%r8d, %r8d
14009f9f1:     	movl	$0x1, %edi
14009f9f6:     	movq	%rax, %r15
14009f9f9:     	xorl	%r14d, %r14d
14009f9fc:     	imulq	$0x130, %r14, %r12      # imm = 0x130
14009fa03:     	addq	%r10, %r12
14009fa06:     	jmp	0x14009fa1f <.text+0x9ea1f>
14009fa08:     	nopl	(%rax,%rax)
14009fa10:     	incq	%r14
14009fa13:     	addq	$0x130, %r12            # imm = 0x130
14009fa1a:     	cmpq	%r14, %r15
14009fa1d:     	je	0x14009fa86 <.text+0x9ea86>
14009fa1f:     	cmpq	%rax, %r14
14009fa22:     	jae	0x14009fa10 <.text+0x9ea10>
14009fa24:     	cmpl	$0x0, (%r9,%r14,4)
14009fa29:     	je	0x14009fa10 <.text+0x9ea10>
14009fa2b:     	cmpq	%r11, %r14
14009fa2e:     	jae	0x14009fa10 <.text+0x9ea10>
14009fa30:     	movzwl	(%r12), %r13d
14009fa35:     	cmpw	$-0x1, %r13w
14009fa3a:     	je	0x14009fa10 <.text+0x9ea10>
14009fa3c:     	movq	0x128(%r12), %r15
14009fa44:     	cmpw	$0x2, %r13w
14009fa49:     	setne	%r12b
14009fa4d:     	testq	%r15, %r15
14009fa50:     	sete	%r13b
14009fa54:     	orb	%r12b, %r13b
14009fa57:     	cmpq	%rbx, %r15
14009fa5a:     	setae	%r12b
14009fa5e:     	andb	%r8b, %r12b
14009fa61:     	testb	%r13b, %r13b
14009fa64:     	cmoveq	%rdi, %r8
14009fa68:     	orb	%r13b, %r12b
14009fa6b:     	cmoveq	%r14, %rdx
14009fa6f:     	cmoveq	%r15, %rbx
14009fa73:     	incq	%r14
14009fa76:     	cmpq	%rax, %r14
14009fa79:     	movq	%rax, %r15
14009fa7c:     	cmovaq	%r14, %r15
14009fa80:     	jb	0x14009f9fc <.text+0x9e9fc>
14009fa86:     	testb	$0x1, %r8b
14009fa8a:     	je	0x14009fad1 <.text+0x9ead1>
14009fa8c:     	cmpq	%rax, %rdx
14009fa8f:     	jae	0x14009fad1 <.text+0x9ead1>
14009fa91:     	movq	0xe0(%rcx), %r8
14009fa98:     	xorl	%eax, %eax
14009fa9a:     	cmpl	$0x0, (%r8,%rdx,4)
14009fa9f:     	je	0x14009fad3 <.text+0x9ead3>
14009faa1:     	cmpq	0xd0(%rcx), %rdx
14009faa8:     	jae	0x14009fad3 <.text+0x9ead3>
14009faaa:     	movq	0xc8(%rcx), %r9
14009fab1:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009fab8:     	cmpw	$0x2, (%r9,%rax)
14009fabe:     	jne	0x14009fad1 <.text+0x9ead1>
14009fac0:     	addq	%rax, %r9
14009fac3:     	movzbl	0x122(%r9), %r14d
14009facb:     	cmpb	$0x2, %r14b
14009facf:     	jne	0x14009faee <.text+0x9eaee>
14009fad1:     	xorl	%eax, %eax
14009fad3:     	movaps	0x180(%rbp), %xmm6
14009fada:     	addq	$0x218, %rsp            # imm = 0x218
14009fae1:     	popq	%rbx
14009fae2:     	popq	%rdi
14009fae3:     	popq	%rsi
14009fae4:     	popq	%r12
14009fae6:     	popq	%r13
14009fae8:     	popq	%r14
14009faea:     	popq	%r15
14009faec:     	popq	%rbp
14009faed:     	retq
14009faee:     	movzbl	0x123(%r9), %r15d
14009faf6:     	movss	0x124(%r9), %xmm6
14009faff:     	movzwl	0x124(%r9), %eax
14009fb07:     	movq	0x8(%r9), %r10
14009fb0b:     	movups	0x108(%r9), %xmm0
14009fb13:     	movups	0x112(%r9), %xmm1
14009fb1b:     	movups	%xmm1, 0x11a(%rbp)
14009fb22:     	movaps	%xmm0, 0x110(%rbp)
14009fb29:     	cmpq	0x88(%rcx), %r10
14009fb30:     	jae	0x14009fb86 <.text+0x9eb86>
14009fb32:     	movq	0x80(%rcx), %r11
14009fb39:     	cmpb	$0x1, (%r11,%r10)
14009fb3e:     	jne	0x14009fb86 <.text+0x9eb86>
14009fb40:     	cmpq	0xa0(%rcx), %r10
14009fb47:     	jae	0x14009fb57 <.text+0x9eb57>
14009fb49:     	movq	0x98(%rcx), %rdi
14009fb50:     	cmpb	$0x0, (%rdi,%r10)
14009fb55:     	jne	0x14009fb86 <.text+0x9eb86>
14009fb57:     	movb	$0x0, (%r11,%r10)
14009fb5c:     	decq	0xb0(%rcx)
14009fb63:     	cmpq	0x70(%rcx), %r10
14009fb67:     	jae	0x14009fb86 <.text+0x9eb86>
14009fb69:     	movq	0x68(%rcx), %r11
14009fb6d:     	imulq	$0x58, %r10, %r10
14009fb71:     	movq	$0x0, 0x30(%r11,%r10)
14009fb7a:     	movb	$0x2, 0x52(%r11,%r10)
14009fb80:     	movb	$0x2, 0x25(%r11,%r10)
14009fb86:     	cmpl	$0x0, (%r8,%rdx,4)
14009fb8b:     	je	0x14009fba2 <.text+0x9eba2>
14009fb8d:     	movl	$0x0, (%r8,%rdx,4)
14009fb95:     	decq	0xf8(%rcx)
14009fb9c:     	movw	$0xffff, (%r9)          # imm = 0xFFFF
14009fba2:     	movq	%rcx, %r12
14009fba5:     	xorps	%xmm0, %xmm0
14009fba8:     	movaps	%xmm0, 0x170(%rbp)
14009fbaf:     	movb	$0x0, 0x152(%rbp)
14009fbb6:     	movw	%ax, 0x150(%rbp)
14009fbbd:     	leaq	0x153(%rbp), %rcx
14009fbc4:     	movw	$0x200, 0x15b(%rbp)     # imm = 0x200
14009fbcd:     	movq	$0x0, 0x153(%rbp)
14009fbd8:     	movq	$0x8, 0x130(%rbp)
14009fbe3:     	movq	$0x0, 0x138(%rbp)
14009fbee:     	movq	$0x1, 0x140(%rbp)
14009fbf9:     	movq	$0x0, 0x148(%rbp)
14009fc04:     	movq	%rcx, 0x30(%rsp)
14009fc09:     	movw	%ax, 0x28(%rsp)
14009fc0e:     	movq	$0x0, 0x58(%rsp)
14009fc17:     	movq	$0x1, 0x50(%rsp)
14009fc20:     	movq	$0x8, 0x48(%rsp)
14009fc29:     	movq	$0x8, 0x40(%rsp)
14009fc32:     	movq	$0x0, 0x38(%rsp)
14009fc3b:     	movb	$0x0, 0x20(%rsp)
14009fc40:     	leaq	0x160(%rbp), %rcx
14009fc47:     	leaq	0x170(%rbp), %rdx
14009fc4e:     	movl	$0x10, %r8d
14009fc54:     	movb	$0x2, %r9b
14009fc57:     	callq	0x140005590 <.text+0x4590>
14009fc5c:     	movq	0x168(%rbp), %rdi
14009fc63:     	cmpq	$0x11, %rdi
14009fc67:     	setae	%al
14009fc6a:     	orb	0x160(%rbp), %al
14009fc70:     	jne	0x14009fd1d <.text+0x9ed1d>
14009fc76:     	movq	%r12, %rcx
14009fc79:     	addq	$0xd8, %rcx
14009fc80:     	callq	0x140219660 <.text+0x218660>
14009fc85:     	cmpq	$0x1, %rax
14009fc89:     	jne	0x14009fd1d <.text+0x9ed1d>
14009fc8f:     	movups	0x11a(%rbp), %xmm0
14009fc96:     	movups	%xmm0, 0xf2(%rbp)
14009fc9d:     	movaps	0x110(%rbp), %xmm0
14009fca4:     	movups	%xmm0, 0xe8(%rbp)
14009fcab:     	movb	%r14b, 0x102(%rbp)
14009fcb2:     	movb	%r15b, 0x103(%rbp)
14009fcb9:     	movss	%xmm6, 0x104(%rbp)
14009fcc1:     	movq	%rbx, 0x108(%rbp)
14009fcc8:     	testq	%rdi, %rdi
14009fccb:     	je	0x14009fd0b <.text+0x9ed0b>
14009fccd:     	movw	%di, -0x1e(%rbp)
14009fcd1:     	leaq	-0x1c(%rbp), %rbx
14009fcd5:     	movl	$0x100, %r8d            # imm = 0x100
14009fcdb:     	subq	%rdi, %r8
14009fcde:     	leaq	(%rdi,%rbp), %rcx
14009fce2:     	addq	$-0x1c, %rcx
14009fce6:     	movq	%rdx, %r14
14009fce9:     	xorl	%edx, %edx
14009fceb:     	callq	0x140251722 <.text+0x250722>
14009fcf0:     	leaq	0x170(%rbp), %rdx
14009fcf7:     	movq	%rbx, %rcx
14009fcfa:     	movq	%rdi, %r8
14009fcfd:     	callq	0x140251710 <.text+0x250710>
14009fd02:     	movq	%r14, %rdx
14009fd05:     	movw	$0x1, %ax
14009fd09:     	jmp	0x14009fd0d <.text+0x9ed0d>
14009fd0b:     	xorl	%eax, %eax
14009fd0d:     	movw	%ax, -0x20(%rbp)
14009fd11:     	leaq	-0x20(%rbp), %r8
14009fd15:     	movq	%rsi, %rcx
14009fd18:     	callq	0x14000b5f0 <.text+0xa5f0>
14009fd1d:     	movb	$0x1, %al
14009fd1f:     	jmp	0x14009fad3 <.text+0x9ead3>

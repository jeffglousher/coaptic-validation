
D:\CoapticCurrent\borrowed-reclaim-encoding-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009e5d0:     	pushq	%rbp
14009e5d1:     	pushq	%r15
14009e5d3:     	pushq	%r14
14009e5d5:     	pushq	%r13
14009e5d7:     	pushq	%r12
14009e5d9:     	pushq	%rsi
14009e5da:     	pushq	%rdi
14009e5db:     	pushq	%rbx
14009e5dc:     	subq	$0x218, %rsp            # imm = 0x218
14009e5e3:     	leaq	0x80(%rsp), %rbp
14009e5eb:     	movaps	%xmm6, 0x180(%rbp)
14009e5f2:     	leaq	0x14c0(%rcx), %r8
14009e5f9:     	leaq	0x528(%rcx), %rsi
14009e600:     	leaq	0x650(%rcx), %rax
14009e607:     	xorl	%r10d, %r10d
14009e60a:     	movl	$0x1, %r11d
14009e610:     	xorl	%r9d, %r9d
14009e613:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009e61a:     	addq	%rax, %rdi
14009e61d:     	jmp	0x14009e630 <.text+0x9d630>
14009e61f:     	nop
14009e620:     	incq	%r10
14009e623:     	addq	$0x130, %rdi            # imm = 0x130
14009e62a:     	cmpq	$0x4, %r10
14009e62e:     	je	0x14009e681 <.text+0x9d681>
14009e630:     	cmpl	$0x0, 0x4c0(%rsi,%r10,4)
14009e639:     	je	0x14009e620 <.text+0x9d620>
14009e63b:     	movzwl	-0x128(%rdi), %ebx
14009e642:     	cmpw	$-0x1, %bx
14009e646:     	je	0x14009e620 <.text+0x9d620>
14009e648:     	movq	(%rdi), %rdi
14009e64b:     	cmpw	$0x2, %bx
14009e64f:     	setne	%bl
14009e652:     	testq	%rdi, %rdi
14009e655:     	sete	%r15b
14009e659:     	orb	%bl, %r15b
14009e65c:     	cmpq	%r14, %rdi
14009e65f:     	setae	%bl
14009e662:     	andb	%r9b, %bl
14009e665:     	testb	%r15b, %r15b
14009e668:     	cmoveq	%r11, %r9
14009e66c:     	orb	%r15b, %bl
14009e66f:     	cmoveq	%r10, %rdx
14009e673:     	cmoveq	%rdi, %r14
14009e677:     	cmpq	$0x3, %r10
14009e67b:     	leaq	0x1(%r10), %r10
14009e67f:     	jb	0x14009e613 <.text+0x9d613>
14009e681:     	xorl	%eax, %eax
14009e683:     	cmpq	$0x1, %r9
14009e687:     	jne	0x14009e6ba <.text+0x9d6ba>
14009e689:     	cmpq	$0x4, %rdx
14009e68d:     	jae	0x14009e6ba <.text+0x9d6ba>
14009e68f:     	cmpl	$0x0, 0x9e8(%rcx,%rdx,4)
14009e697:     	je	0x14009e6b8 <.text+0x9d6b8>
14009e699:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009e6a0:     	cmpw	$0x2, (%rsi,%rax)
14009e6a5:     	jne	0x14009e6b8 <.text+0x9d6b8>
14009e6a7:     	addq	%rsi, %rax
14009e6aa:     	movzbl	0x122(%rax), %r15d
14009e6b2:     	cmpb	$0x2, %r15b
14009e6b6:     	jne	0x14009e6d5 <.text+0x9d6d5>
14009e6b8:     	xorl	%eax, %eax
14009e6ba:     	movaps	0x180(%rbp), %xmm6
14009e6c1:     	addq	$0x218, %rsp            # imm = 0x218
14009e6c8:     	popq	%rbx
14009e6c9:     	popq	%rdi
14009e6ca:     	popq	%rsi
14009e6cb:     	popq	%r12
14009e6cd:     	popq	%r13
14009e6cf:     	popq	%r14
14009e6d1:     	popq	%r15
14009e6d3:     	popq	%rbp
14009e6d4:     	retq
14009e6d5:     	movq	0x8(%rax), %r9
14009e6d9:     	movq	0x108(%rax), %r12
14009e6e0:     	movq	0x110(%rax), %rdx
14009e6e7:     	movq	%rdx, 0x170(%rbp)
14009e6ee:     	movl	0x118(%rax), %r13d
14009e6f5:     	movl	0x11c(%rax), %edi
14009e6fb:     	movzwl	0x120(%rax), %ebx
14009e702:     	movzbl	0x123(%rax), %edx
14009e709:     	movb	%dl, 0x17f(%rbp)
14009e70f:     	movss	0x124(%rax), %xmm6
14009e717:     	movzwl	0x124(%rax), %eax
14009e71e:     	movzwl	%ax, %edx
14009e721:     	cmpq	$0x1, %r9
14009e725:     	ja	0x14009e77a <.text+0x9d77a>
14009e727:     	cmpb	$0x1, 0x1e48(%rcx,%r9)
14009e730:     	jne	0x14009e77a <.text+0x9d77a>
14009e732:     	cmpb	$0x0, 0x1e4a(%rcx,%r9)
14009e73b:     	jne	0x14009e77a <.text+0x9d77a>
14009e73d:     	movb	$0x0, 0x1e48(%rcx,%r9)
14009e746:     	decq	0x1e40(%rcx)
14009e74d:     	movq	$0x0, 0x1dc0(%rcx,%r9,8)
14009e759:     	leaq	(%r9,%r9,8), %r10
14009e75d:     	leaq	(%r10,%r10,2), %r10
14009e761:     	addq	%r9, %r10
14009e764:     	movb	$0x2, 0x95a(%r8,%r10)
14009e76d:     	leaq	(%r9,%r9,2), %r9
14009e771:     	movb	$0x2, 0x91d(%r8,%r9,8)
14009e77a:     	addl	$0x2, %edx
14009e77d:     	xorl	%r10d, %r10d
14009e780:     	movb	$0x1, %r11b
14009e783:     	cmpl	%edx, 0x9e8(%rcx)
14009e789:     	jne	0x14009e804 <.text+0x9d804>
14009e78b:     	cmpw	$-0x1, 0x528(%rcx)
14009e793:     	je	0x14009e804 <.text+0x9d804>
14009e795:     	cmpw	%ax, 0x64c(%rcx)
14009e79c:     	sete	%r8b
14009e7a0:     	cmpl	%r13d, 0x640(%rcx)
14009e7a7:     	sete	%r9b
14009e7ab:     	andb	%r8b, %r9b
14009e7ae:     	cmpl	%edi, 0x644(%rcx)
14009e7b4:     	sete	%r8b
14009e7b8:     	cmpw	%bx, 0x648(%rcx)
14009e7bf:     	sete	%r10b
14009e7c3:     	andb	%r8b, %r10b
14009e7c6:     	andb	%r9b, %r10b
14009e7c9:     	cmpb	%r15b, 0x64a(%rcx)
14009e7d0:     	sete	%r8b
14009e7d4:     	movq	0x638(%rcx), %r9
14009e7db:     	xorq	0x170(%rbp), %r9
14009e7e2:     	movq	0x630(%rcx), %r11
14009e7e9:     	xorq	%r12, %r11
14009e7ec:     	orq	%r9, %r11
14009e7ef:     	sete	%r9b
14009e7f3:     	andb	%r8b, %r9b
14009e7f6:     	andb	%r10b, %r9b
14009e7f9:     	movzbl	%r9b, %r10d
14009e7fd:     	movl	%r10d, %r11d
14009e800:     	xorb	$0x1, %r11b
14009e804:     	xorl	%r8d, %r8d
14009e807:     	cmpl	%edx, 0x9ec(%rcx)
14009e80d:     	movw	%bx, 0x17c(%rbp)
14009e814:     	movl	%edi, 0x178(%rbp)
14009e81a:     	jne	0x14009e8c5 <.text+0x9d8c5>
14009e820:     	cmpw	$-0x1, 0x658(%rcx)
14009e828:     	je	0x14009e8c5 <.text+0x9d8c5>
14009e82e:     	cmpw	%ax, 0x77c(%rcx)
14009e835:     	setne	%r8b
14009e839:     	cmpl	%r13d, 0x770(%rcx)
14009e840:     	setne	%r9b
14009e844:     	orb	%r8b, %r9b
14009e847:     	cmpl	%edi, 0x774(%rcx)
14009e84d:     	setne	%r8b
14009e851:     	cmpw	%bx, 0x778(%rcx)
14009e858:     	setne	%bl
14009e85b:     	orb	%r8b, %bl
14009e85e:     	orb	%r9b, %bl
14009e861:     	cmpb	%r15b, 0x77a(%rcx)
14009e868:     	setne	%r9b
14009e86c:     	movq	0x768(%rcx), %r8
14009e873:     	xorq	0x170(%rbp), %r8
14009e87a:     	movq	0x760(%rcx), %rdi
14009e881:     	xorq	%r12, %rdi
14009e884:     	orq	%r8, %rdi
14009e887:     	setne	%r8b
14009e88b:     	orb	%r9b, %r8b
14009e88e:     	orb	%bl, %r8b
14009e891:     	orb	%r8b, %r11b
14009e894:     	testb	%r8b, %r8b
14009e897:     	movl	$0x1, %r9d
14009e89d:     	cmovneq	%r10, %r9
14009e8a1:     	testb	$0x1, %r11b
14009e8a5:     	je	0x14009e9b6 <.text+0x9d9b6>
14009e8ab:     	notb	%r8b
14009e8ae:     	movzbl	%r8b, %r8d
14009e8b2:     	andl	$0x1, %r8d
14009e8b6:     	movl	0x178(%rbp), %edi
14009e8bc:     	movzwl	0x17c(%rbp), %ebx
14009e8c3:     	jmp	0x14009e8c8 <.text+0x9d8c8>
14009e8c5:     	movq	%r10, %r9
14009e8c8:     	cmpl	%edx, 0x9f0(%rcx)
14009e8ce:     	jne	0x14009e941 <.text+0x9d941>
14009e8d0:     	cmpw	$-0x1, 0x788(%rcx)
14009e8d8:     	je	0x14009e941 <.text+0x9d941>
14009e8da:     	cmpw	%ax, 0x8ac(%rcx)
14009e8e1:     	jne	0x14009e941 <.text+0x9d941>
14009e8e3:     	cmpl	%r13d, 0x8a0(%rcx)
14009e8ea:     	jne	0x14009e941 <.text+0x9d941>
14009e8ec:     	cmpl	%edi, 0x8a4(%rcx)
14009e8f2:     	jne	0x14009e941 <.text+0x9d941>
14009e8f4:     	cmpw	%bx, 0x8a8(%rcx)
14009e8fb:     	jne	0x14009e941 <.text+0x9d941>
14009e8fd:     	cmpb	%r15b, 0x8aa(%rcx)
14009e904:     	jne	0x14009e941 <.text+0x9d941>
14009e906:     	movq	0x890(%rcx), %r10
14009e90d:     	xorq	%r12, %r10
14009e910:     	movq	0x898(%rcx), %r11
14009e917:     	xorq	0x170(%rbp), %r11
14009e91e:     	orq	%r10, %r11
14009e921:     	jne	0x14009e941 <.text+0x9d941>
14009e923:     	movb	$0x1, %dil
14009e926:     	testq	%r9, %r9
14009e929:     	jne	0x14009e9bc <.text+0x9d9bc>
14009e92f:     	movl	$0x1, %r9d
14009e935:     	movl	$0x2, %r8d
14009e93b:     	movl	0x178(%rbp), %edi
14009e941:     	cmpl	%edx, 0x9f4(%rcx)
14009e947:     	jne	0x14009e9ad <.text+0x9d9ad>
14009e949:     	cmpw	$-0x1, 0x8b8(%rcx)
14009e951:     	je	0x14009e9ad <.text+0x9d9ad>
14009e953:     	cmpw	%ax, 0x9dc(%rcx)
14009e95a:     	jne	0x14009e9ad <.text+0x9d9ad>
14009e95c:     	cmpl	%r13d, 0x9d0(%rcx)
14009e963:     	jne	0x14009e9ad <.text+0x9d9ad>
14009e965:     	cmpl	%edi, 0x9d4(%rcx)
14009e96b:     	jne	0x14009e9ad <.text+0x9d9ad>
14009e96d:     	cmpw	%bx, 0x9d8(%rcx)
14009e974:     	jne	0x14009e9ad <.text+0x9d9ad>
14009e976:     	cmpb	%r15b, 0x9da(%rcx)
14009e97d:     	jne	0x14009e9ad <.text+0x9d9ad>
14009e97f:     	movq	0x9c0(%rcx), %rdx
14009e986:     	xorq	%r12, %rdx
14009e989:     	movq	0x9c8(%rcx), %r10
14009e990:     	xorq	0x170(%rbp), %r10
14009e997:     	orq	%rdx, %r10
14009e99a:     	jne	0x14009e9ad <.text+0x9d9ad>
14009e99c:     	testq	%r9, %r9
14009e99f:     	movl	$0x3, %edx
14009e9a4:     	cmoveq	%rdx, %r8
14009e9a8:     	movl	%r9d, %edi
14009e9ab:     	jmp	0x14009e9bc <.text+0x9d9bc>
14009e9ad:     	xorl	%edi, %edi
14009e9af:     	testq	%r9, %r9
14009e9b2:     	jne	0x14009e9bc <.text+0x9d9bc>
14009e9b4:     	jmp	0x14009e9e7 <.text+0x9d9e7>
14009e9b6:     	movb	$0x1, %dil
14009e9b9:     	xorl	%r8d, %r8d
14009e9bc:     	cmpl	$0x0, 0x9e8(%rcx,%r8,4)
14009e9c5:     	je	0x14009e9e7 <.text+0x9d9e7>
14009e9c7:     	movl	$0x0, 0x9e8(%rcx,%r8,4)
14009e9d3:     	decq	0xa00(%rcx)
14009e9da:     	imulq	$0x130, %r8, %rdx       # imm = 0x130
14009e9e1:     	movw	$0xffff, (%rsi,%rdx)    # imm = 0xFFFF
14009e9e7:     	movl	%r13d, 0x16c(%rbp)
14009e9ee:     	movq	%r12, %r13
14009e9f1:     	xorps	%xmm0, %xmm0
14009e9f4:     	movaps	%xmm0, 0x150(%rbp)
14009e9fb:     	movb	$0x0, 0x132(%rbp)
14009ea02:     	movw	%ax, 0x130(%rbp)
14009ea09:     	leaq	0x133(%rbp), %rdx
14009ea10:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009ea19:     	movq	$0x0, 0x133(%rbp)
14009ea24:     	movq	$0x8, 0x110(%rbp)
14009ea2f:     	movq	$0x0, 0x118(%rbp)
14009ea3a:     	movq	$0x1, 0x120(%rbp)
14009ea45:     	movq	$0x0, 0x128(%rbp)
14009ea50:     	movq	%rdx, 0x30(%rsp)
14009ea55:     	movw	%ax, 0x28(%rsp)
14009ea5a:     	movq	$0x0, 0x58(%rsp)
14009ea63:     	movq	$0x1, 0x50(%rsp)
14009ea6c:     	movq	$0x8, 0x48(%rsp)
14009ea75:     	movq	$0x8, 0x40(%rsp)
14009ea7e:     	movq	$0x0, 0x38(%rsp)
14009ea87:     	movb	$0x0, 0x20(%rsp)
14009ea8c:     	leaq	0x140(%rbp), %rax
14009ea93:     	leaq	0x150(%rbp), %rdx
14009ea9a:     	movl	$0x10, %r8d
14009eaa0:     	movq	%rcx, %r12
14009eaa3:     	movq	%rax, %rcx
14009eaa6:     	movb	$0x2, %r9b
14009eaa9:     	callq	0x140005590 <.text+0x4590>
14009eaae:     	cmpb	$0x0, 0x140(%rbp)
14009eab5:     	jne	0x14009ec6e <.text+0x9dc6e>
14009eabb:     	testb	%dil, %dil
14009eabe:     	jne	0x14009ec6e <.text+0x9dc6e>
14009eac4:     	movq	0x148(%rbp), %rbx
14009eacb:     	cmpq	$0x10, %rbx
14009eacf:     	ja	0x14009ec6e <.text+0x9dc6e>
14009ead5:     	movq	%r12, %rax
14009ead8:     	cmpq	$0x4, 0xa00(%r12)
14009eae1:     	je	0x14009ec6e <.text+0x9dc6e>
14009eae7:     	movq	0x9f8(%rax), %rdi
14009eaee:     	cmpq	$0x3, %rdi
14009eaf2:     	ja	0x14009ec86 <.text+0x9dc86>
14009eaf8:     	cmpl	$0x0, 0x9e8(%rax,%rdi,4)
14009eb00:     	je	0x14009eb7a <.text+0x9db7a>
14009eb02:     	leaq	(,%rdi,4), %rdx
14009eb0a:     	xorl	%ecx, %ecx
14009eb0c:     	cmpl	$0x0, 0x9e8(%rax,%rdx)
14009eb14:     	je	0x14009eb6d <.text+0x9db6d>
14009eb16:     	addq	$0x4, %rdx
14009eb1a:     	decq	%rcx
14009eb1d:     	cmpq	$0x10, %rdx
14009eb21:     	jne	0x14009eb0c <.text+0x9db0c>
14009eb23:     	testq	%rdi, %rdi
14009eb26:     	je	0x14009ec6e <.text+0x9dc6e>
14009eb2c:     	cmpl	$0x0, 0x9e8(%rax)
14009eb33:     	je	0x14009ec75 <.text+0x9dc75>
14009eb39:     	cmpq	$0x1, %rdi
14009eb3d:     	je	0x14009ec6e <.text+0x9dc6e>
14009eb43:     	cmpl	$0x0, 0x9ec(%rax)
14009eb4a:     	je	0x14009ec7c <.text+0x9dc7c>
14009eb50:     	cmpq	$0x2, %rdi
14009eb54:     	je	0x14009ec6e <.text+0x9dc6e>
14009eb5a:     	movl	$0x2, %edi
14009eb5f:     	cmpl	$0x0, 0x9f0(%rax)
14009eb66:     	je	0x14009eb70 <.text+0x9db70>
14009eb68:     	jmp	0x14009ec6e <.text+0x9dc6e>
14009eb6d:     	subq	%rcx, %rdi
14009eb70:     	cmpq	$0x4, %rdi
14009eb74:     	jae	0x14009ec9c <.text+0x9dc9c>
14009eb7a:     	movl	$0x1, 0x9e8(%rax,%rdi,4)
14009eb85:     	incq	0xa00(%rax)
14009eb8c:     	leaq	0x1(%rdi), %rdx
14009eb90:     	xorl	%ecx, %ecx
14009eb92:     	cmpq	$0x4, %rdx
14009eb96:     	movl	$0x0, %r8d
14009eb9c:     	cmovneq	%rdx, %r8
14009eba0:     	movq	%r8, 0x9f8(%rax)
14009eba7:     	movq	0x170(%rbp), %rdx
14009ebae:     	movq	%rdx, 0xf0(%rbp)
14009ebb5:     	movq	%r13, 0xe8(%rbp)
14009ebbc:     	movl	0x16c(%rbp), %edx
14009ebc2:     	movl	%edx, 0xf8(%rbp)
14009ebc8:     	movl	0x178(%rbp), %edx
14009ebce:     	movl	%edx, 0xfc(%rbp)
14009ebd4:     	movzwl	0x17c(%rbp), %edx
14009ebdb:     	movw	%dx, 0x100(%rbp)
14009ebe2:     	movb	%r15b, 0x102(%rbp)
14009ebe9:     	movzbl	0x17f(%rbp), %edx
14009ebf0:     	movb	%dl, 0x103(%rbp)
14009ebf6:     	movss	%xmm6, 0x104(%rbp)
14009ebfe:     	movq	%r14, 0x108(%rbp)
14009ec05:     	testq	%rbx, %rbx
14009ec08:     	je	0x14009ec43 <.text+0x9dc43>
14009ec0a:     	movw	%bx, -0x1e(%rbp)
14009ec0e:     	leaq	-0x1c(%rbp), %r14
14009ec12:     	movl	$0x100, %r8d            # imm = 0x100
14009ec18:     	subq	%rbx, %r8
14009ec1b:     	leaq	(%rbx,%rbp), %rcx
14009ec1f:     	addq	$-0x1c, %rcx
14009ec23:     	xorl	%edx, %edx
14009ec25:     	callq	0x140251722 <.text+0x250722>
14009ec2a:     	leaq	0x150(%rbp), %rdx
14009ec31:     	movq	%r14, %rcx
14009ec34:     	movq	%rbx, %r8
14009ec37:     	callq	0x140251710 <.text+0x250710>
14009ec3c:     	movq	%r12, %rax
14009ec3f:     	movw	$0x1, %cx
14009ec43:     	movw	%cx, -0x20(%rbp)
14009ec47:     	movzwl	0x104(%rbp), %ecx
14009ec4e:     	addl	$0x2, %ecx
14009ec51:     	movl	%ecx, 0x9e8(%rax,%rdi,4)
14009ec58:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009ec5f:     	addq	%rax, %rsi
14009ec62:     	leaq	-0x20(%rbp), %rcx
14009ec66:     	movq	%rsi, %rdx
14009ec69:     	callq	0x14000b1c0 <.text+0xa1c0>
14009ec6e:     	movb	$0x1, %al
14009ec70:     	jmp	0x14009e6ba <.text+0x9d6ba>
14009ec75:     	xorl	%edi, %edi
14009ec77:     	jmp	0x14009eb70 <.text+0x9db70>
14009ec7c:     	movl	$0x1, %edi
14009ec81:     	jmp	0x14009eb70 <.text+0x9db70>
14009ec86:     	leaq	0x1ce0e3(%rip), %r8     # 0x14026cd70
14009ec8d:     	movl	$0x4, %edx
14009ec92:     	movq	%rdi, %rcx
14009ec95:     	callq	0x140251f93 <.text+0x250f93>
14009ec9a:     	ud2
14009ec9c:     	leaq	0x1ce0e5(%rip), %r8     # 0x14026cd88
14009eca3:     	movl	$0x4, %edx
14009eca8:     	movq	%rdi, %rcx
14009ecab:     	callq	0x140251f93 <.text+0x250f93>
14009ecb0:     	ud2

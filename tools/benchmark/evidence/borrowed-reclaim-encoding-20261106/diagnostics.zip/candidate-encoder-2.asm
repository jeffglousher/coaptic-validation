
D:\CoapticCurrent\borrowed-reclaim-encoding-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068670:     	pushq	%rbp
140068671:     	pushq	%r15
140068673:     	pushq	%r14
140068675:     	pushq	%r13
140068677:     	pushq	%r12
140068679:     	pushq	%rsi
14006867a:     	pushq	%rdi
14006867b:     	pushq	%rbx
14006867c:     	subq	$0x4f8, %rsp            # imm = 0x4F8
140068683:     	leaq	0x80(%rsp), %rbp
14006868b:     	movq	0x4f0(%rbp), %r12
140068692:     	movq	0x8(%r12), %rdi
140068697:     	movl	$0x3, %r10d
14006869d:     	cmpq	$0x3, %rdi
1400686a1:     	ja	0x140068783 <.text+0x67783>
1400686a7:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
1400686af:     	jne	0x140068783 <.text+0x67783>
1400686b5:     	movq	0x26700(%rdx,%rdi,8), %rax
1400686bd:     	cmpq	$0x4001, %rax           # imm = 0x4001
1400686c3:     	jae	0x140068955 <.text+0x67955>
1400686c9:     	movq	0x10(%r12), %r11
1400686ce:     	movq	0x18(%r12), %r15
1400686d3:     	movq	%r15, %rsi
1400686d6:     	movl	$0xb, %r10d
1400686dc:     	addq	%r11, %rsi
1400686df:     	jb	0x140068783 <.text+0x67783>
1400686e5:     	cmpq	$0x400, %r15            # imm = 0x400
1400686ec:     	ja	0x140068783 <.text+0x67783>
1400686f2:     	cmpq	%rax, %rsi
1400686f5:     	ja	0x140068783 <.text+0x67783>
1400686fb:     	movq	%r8, %r13
1400686fe:     	movq	%r9, 0x460(%rbp)
140068705:     	movq	%rcx, 0x470(%rbp)
14006870c:     	movzbl	0x4f8(%rbp), %r14d
140068714:     	movq	%rdi, %rax
140068717:     	shlq	$0xe, %rax
14006871b:     	movq	%rdx, %rsi
14006871e:     	leaq	(%rdx,%rax), %rbx
140068722:     	addq	$0x16700, %rbx          # imm = 0x16700
140068729:     	addq	%r11, %rbx
14006872c:     	movl	$0x400, %r8d            # imm = 0x400
140068732:     	cmpq	$0x400, %r15            # imm = 0x400
140068739:     	je	0x140068749 <.text+0x67749>
14006873b:     	leaq	-0x10(%rbp), %rcx
14006873f:     	xorl	%edx, %edx
140068741:     	callq	0x140251722 <.text+0x250722>
140068746:     	movq	%r15, %r8
140068749:     	leaq	-0x10(%rbp), %rcx
14006874d:     	movq	%rbx, %rdx
140068750:     	callq	0x140251710 <.text+0x250710>
140068755:     	testb	%r14b, %r14b
140068758:     	je	0x14006879e <.text+0x6779e>
14006875a:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
140068761:     	movq	%rsi, %rcx
140068764:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
14006876d:     	jne	0x14006890a <.text+0x6790a>
140068773:     	xorl	%edi, %edi
140068775:     	callq	0x14009b200 <.text+0x9a200>
14006877a:     	testb	$0x1, %al
14006877c:     	jne	0x1400687b0 <.text+0x677b0>
14006877e:     	jmp	0x140068933 <.text+0x67933>
140068783:     	movb	$0xa, (%rcx)
140068786:     	movq	%r10, 0x8(%rcx)
14006878a:     	addq	$0x4f8, %rsp            # imm = 0x4F8
140068791:     	popq	%rbx
140068792:     	popq	%rdi
140068793:     	popq	%rsi
140068794:     	popq	%r12
140068796:     	popq	%r13
140068798:     	popq	%r14
14006879a:     	popq	%r15
14006879c:     	popq	%rbp
14006879d:     	retq
14006879e:     	xorl	%edi, %edi
1400687a0:     	movq	%rsi, %rcx
1400687a3:     	callq	0x14009b200 <.text+0x9a200>
1400687a8:     	testb	$0x1, %al
1400687aa:     	je	0x140068933 <.text+0x67933>
1400687b0:     	movq	%rdx, %rbx
1400687b3:     	movq	0x500(%rbp), %rdx
1400687ba:     	movzwl	0x4e8(%rbp), %ecx
1400687c1:     	movzbl	0x4e0(%rbp), %eax
1400687c8:     	movq	(%r12), %r8
1400687cc:     	movq	%rdi, 0x430(%rbp)
1400687d3:     	movq	0x468(%rbp), %r9
1400687da:     	movq	%r9, 0x438(%rbp)
1400687e1:     	movq	%r8, 0x440(%rbp)
1400687e8:     	movb	%r14b, 0x448(%rbp)
1400687ef:     	movups	0x60(%r13), %xmm0
1400687f4:     	movups	0x6c(%r13), %xmm1
1400687f9:     	movups	%xmm1, 0x3fc(%rbp)
140068800:     	movaps	%xmm0, 0x3f0(%rbp)
140068807:     	leaq	0x8e(%r13), %r8
14006880e:     	movq	0x7e(%r13), %r9
140068812:     	movq	0x85(%r13), %r10
140068819:     	movq	%r10, 0x457(%rbp)
140068820:     	movq	%r9, 0x450(%rbp)
140068827:     	leaq	0x450(%rbp), %r9
14006882e:     	movq	%r9, 0x68(%rsp)
140068833:     	movq	%rdx, 0x60(%rsp)
140068838:     	movq	%r13, 0x58(%rsp)
14006883d:     	leaq	0x430(%rbp), %rdx
140068844:     	movq	%rdx, 0x50(%rsp)
140068849:     	movq	%r15, 0x48(%rsp)
14006884e:     	leaq	-0x10(%rbp), %rdx
140068852:     	movq	%rdx, 0x40(%rsp)
140068857:     	movq	0x460(%rbp), %rdx
14006885e:     	movq	%rdx, 0x38(%rsp)
140068863:     	movq	%r8, 0x30(%rsp)
140068868:     	movw	%cx, 0x28(%rsp)
14006886d:     	movb	%al, 0x20(%rsp)
140068871:     	leaq	0x410(%rbp), %rcx
140068878:     	leaq	0x3f0(%rbp), %r8
14006887f:     	movq	%rsi, %rdx
140068882:     	movq	%rbx, %r9
140068885:     	callq	0x140082af0 <.text+0x81af0>
14006888a:     	cmpb	$-0x1, 0x410(%rbp)
140068891:     	je	0x140068942 <.text+0x67942>
140068897:     	cmpb	$0x1, 0x37400(%rsi,%rbx)
14006889f:     	movq	0x470(%rbp), %rax
1400688a6:     	jne	0x1400688f0 <.text+0x678f0>
1400688a8:     	cmpb	$0x0, 0x37420(%rsi,%rbx)
1400688b0:     	jne	0x1400688f0 <.text+0x678f0>
1400688b2:     	movb	$0x0, 0x37400(%rsi,%rbx)
1400688ba:     	decq	0x37448(%rsi)
1400688c1:     	leaq	0x37400(%rsi), %rcx
1400688c8:     	movq	$0x0, 0x432d0(%rsi,%rbx,8)
1400688d4:     	leaq	(%rbx,%rbx,8), %rdx
1400688d8:     	leaq	(%rdx,%rdx,2), %rdx
1400688dc:     	addq	%rbx, %rdx
1400688df:     	movb	$0x2, 0x36a(%rcx,%rdx)
1400688e7:     	leaq	(%rbx,%rbx,2), %rdx
1400688eb:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
1400688f0:     	movups	0x410(%rbp), %xmm0
1400688f7:     	movups	0x420(%rbp), %xmm1
1400688fe:     	movups	%xmm1, 0x10(%rax)
140068902:     	movups	%xmm0, (%rax)
140068905:     	jmp	0x14006878a <.text+0x6778a>
14006890a:     	addq	%rcx, %rax
14006890d:     	addq	$0x15c28, %rax          # imm = 0x15C28
140068913:     	movq	0x98(%rax), %rax
14006891a:     	movq	%rax, 0x468(%rbp)
140068921:     	movl	$0x1, %edi
140068926:     	callq	0x14009b200 <.text+0x9a200>
14006892b:     	testb	$0x1, %al
14006892d:     	jne	0x1400687b0 <.text+0x677b0>
140068933:     	movq	0x470(%rbp), %rax
14006893a:     	movb	$0x9, (%rax)
14006893d:     	jmp	0x14006878a <.text+0x6778a>
140068942:     	movq	0x470(%rbp), %rax
140068949:     	movq	%rbx, 0x8(%rax)
14006894d:     	movb	$-0x1, (%rax)
140068950:     	jmp	0x14006878a <.text+0x6778a>
140068955:     	leaq	0x2042c4(%rip), %r9     # 0x14026cc20
14006895c:     	movl	$0x4000, %r8d           # imm = 0x4000
140068962:     	xorl	%ecx, %ecx
140068964:     	movq	%rax, %rdx
140068967:     	callq	0x1402521a0 <.text+0x2511a0>
14006896c:     	ud2

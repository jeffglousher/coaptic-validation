
D:\CoapticCurrent\borrowed-reclaim-encoding-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140068360:     	pushq	%rbp
140068361:     	pushq	%r15
140068363:     	pushq	%r14
140068365:     	pushq	%r13
140068367:     	pushq	%r12
140068369:     	pushq	%rsi
14006836a:     	pushq	%rdi
14006836b:     	pushq	%rbx
14006836c:     	subq	$0x508, %rsp            # imm = 0x508
140068373:     	leaq	0x80(%rsp), %rbp
14006837b:     	movq	0x500(%rbp), %r12
140068382:     	movq	0x8(%r12), %rdi
140068387:     	movl	$0x3, %r10d
14006838d:     	cmpq	$0x3, %rdi
140068391:     	ja	0x140068471 <.text+0x67471>
140068397:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
14006839f:     	jne	0x140068471 <.text+0x67471>
1400683a5:     	movq	0x26700(%rdx,%rdi,8), %rax
1400683ad:     	cmpq	$0x4001, %rax           # imm = 0x4001
1400683b3:     	jae	0x14006864e <.text+0x6764e>
1400683b9:     	movq	0x10(%r12), %r11
1400683be:     	movq	0x18(%r12), %r15
1400683c3:     	movq	%r15, %rsi
1400683c6:     	movl	$0xb, %r10d
1400683cc:     	addq	%r11, %rsi
1400683cf:     	jb	0x140068471 <.text+0x67471>
1400683d5:     	cmpq	$0x400, %r15            # imm = 0x400
1400683dc:     	ja	0x140068471 <.text+0x67471>
1400683e2:     	cmpq	%rax, %rsi
1400683e5:     	ja	0x140068471 <.text+0x67471>
1400683eb:     	movq	%r8, %r13
1400683ee:     	movq	%r9, 0x470(%rbp)
1400683f5:     	movq	%rcx, 0x480(%rbp)
1400683fc:     	movzbl	0x508(%rbp), %r14d
140068404:     	movq	%rdi, %rax
140068407:     	shlq	$0xe, %rax
14006840b:     	movq	%rdx, %rsi
14006840e:     	leaq	(%rdx,%rax), %rbx
140068412:     	addq	$0x16700, %rbx          # imm = 0x16700
140068419:     	addq	%r11, %rbx
14006841c:     	movl	$0x400, %r8d            # imm = 0x400
140068422:     	cmpq	$0x400, %r15            # imm = 0x400
140068429:     	je	0x140068438 <.text+0x67438>
14006842b:     	movq	%rbp, %rcx
14006842e:     	xorl	%edx, %edx
140068430:     	callq	0x140251722 <.text+0x250722>
140068435:     	movq	%r15, %r8
140068438:     	movq	%rbp, %rcx
14006843b:     	movq	%rbx, %rdx
14006843e:     	callq	0x140251710 <.text+0x250710>
140068443:     	testb	%r14b, %r14b
140068446:     	je	0x14006848c <.text+0x6748c>
140068448:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
14006844f:     	movq	%rsi, %rcx
140068452:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
14006845b:     	jne	0x140068603 <.text+0x67603>
140068461:     	xorl	%edi, %edi
140068463:     	callq	0x14009b200 <.text+0x9a200>
140068468:     	testb	$0x1, %al
14006846a:     	jne	0x14006849e <.text+0x6749e>
14006846c:     	jmp	0x14006862c <.text+0x6762c>
140068471:     	movb	$0xa, (%rcx)
140068474:     	movq	%r10, 0x8(%rcx)
140068478:     	addq	$0x508, %rsp            # imm = 0x508
14006847f:     	popq	%rbx
140068480:     	popq	%rdi
140068481:     	popq	%rsi
140068482:     	popq	%r12
140068484:     	popq	%r13
140068486:     	popq	%r14
140068488:     	popq	%r15
14006848a:     	popq	%rbp
14006848b:     	retq
14006848c:     	xorl	%edi, %edi
14006848e:     	movq	%rsi, %rcx
140068491:     	callq	0x14009b200 <.text+0x9a200>
140068496:     	testb	$0x1, %al
140068498:     	je	0x14006862c <.text+0x6762c>
14006849e:     	movq	%rdx, %rbx
1400684a1:     	movq	0x518(%rbp), %rdx
1400684a8:     	movq	0x510(%rbp), %r8
1400684af:     	movzwl	0x4f8(%rbp), %ecx
1400684b6:     	movzbl	0x4f0(%rbp), %eax
1400684bd:     	movq	(%r12), %r9
1400684c1:     	movq	%rdi, 0x440(%rbp)
1400684c8:     	movq	0x478(%rbp), %r10
1400684cf:     	movq	%r10, 0x448(%rbp)
1400684d6:     	movq	%r9, 0x450(%rbp)
1400684dd:     	movb	%r14b, 0x458(%rbp)
1400684e4:     	movups	0x60(%r13), %xmm0
1400684e9:     	movups	0x6c(%r13), %xmm1
1400684ee:     	movups	%xmm1, 0x40c(%rbp)
1400684f5:     	movaps	%xmm0, 0x400(%rbp)
1400684fc:     	leaq	0x8e(%r13), %r9
140068503:     	movq	0x7e(%r13), %r10
140068507:     	movq	0x85(%r13), %r11
14006850e:     	movq	%r11, 0x467(%rbp)
140068515:     	movq	%r10, 0x460(%rbp)
14006851c:     	leaq	0x460(%rbp), %r10
140068523:     	movq	%r10, 0x70(%rsp)
140068528:     	movq	%rdx, 0x68(%rsp)
14006852d:     	movq	%r8, 0x60(%rsp)
140068532:     	movq	%r13, 0x58(%rsp)
140068537:     	leaq	0x440(%rbp), %rdx
14006853e:     	movq	%rdx, 0x50(%rsp)
140068543:     	movq	%r15, 0x48(%rsp)
140068548:     	movq	%rbp, %rdx
14006854b:     	movq	%rdx, 0x40(%rsp)
140068550:     	movq	0x470(%rbp), %rdx
140068557:     	movq	%rdx, 0x38(%rsp)
14006855c:     	movq	%r9, 0x30(%rsp)
140068561:     	movw	%cx, 0x28(%rsp)
140068566:     	movb	%al, 0x20(%rsp)
14006856a:     	leaq	0x420(%rbp), %rcx
140068571:     	leaq	0x400(%rbp), %r8
140068578:     	movq	%rsi, %rdx
14006857b:     	movq	%rbx, %r9
14006857e:     	callq	0x140081300 <.text+0x80300>
140068583:     	cmpb	$-0x1, 0x420(%rbp)
14006858a:     	je	0x14006863b <.text+0x6763b>
140068590:     	cmpb	$0x1, 0x37400(%rsi,%rbx)
140068598:     	movq	0x480(%rbp), %rax
14006859f:     	jne	0x1400685e9 <.text+0x675e9>
1400685a1:     	cmpb	$0x0, 0x37420(%rsi,%rbx)
1400685a9:     	jne	0x1400685e9 <.text+0x675e9>
1400685ab:     	movb	$0x0, 0x37400(%rsi,%rbx)
1400685b3:     	decq	0x37448(%rsi)
1400685ba:     	leaq	0x37400(%rsi), %rcx
1400685c1:     	movq	$0x0, 0x432d0(%rsi,%rbx,8)
1400685cd:     	leaq	(%rbx,%rbx,8), %rdx
1400685d1:     	leaq	(%rdx,%rdx,2), %rdx
1400685d5:     	addq	%rbx, %rdx
1400685d8:     	movb	$0x2, 0x36a(%rcx,%rdx)
1400685e0:     	leaq	(%rbx,%rbx,2), %rdx
1400685e4:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
1400685e9:     	movups	0x420(%rbp), %xmm0
1400685f0:     	movups	0x430(%rbp), %xmm1
1400685f7:     	movups	%xmm1, 0x10(%rax)
1400685fb:     	movups	%xmm0, (%rax)
1400685fe:     	jmp	0x140068478 <.text+0x67478>
140068603:     	addq	%rcx, %rax
140068606:     	addq	$0x15c28, %rax          # imm = 0x15C28
14006860c:     	movq	0x98(%rax), %rax
140068613:     	movq	%rax, 0x478(%rbp)
14006861a:     	movl	$0x1, %edi
14006861f:     	callq	0x14009b200 <.text+0x9a200>
140068624:     	testb	$0x1, %al
140068626:     	jne	0x14006849e <.text+0x6749e>
14006862c:     	movq	0x480(%rbp), %rax
140068633:     	movb	$0x9, (%rax)
140068636:     	jmp	0x140068478 <.text+0x67478>
14006863b:     	movq	0x480(%rbp), %rax
140068642:     	movq	%rbx, 0x8(%rax)
140068646:     	movb	$-0x1, (%rax)
140068649:     	jmp	0x140068478 <.text+0x67478>
14006864e:     	leaq	0x2045cb(%rip), %r9     # 0x14026cc20
140068655:     	movl	$0x4000, %r8d           # imm = 0x4000
14006865b:     	xorl	%ecx, %ecx
14006865d:     	movq	%rax, %rdx
140068660:     	callq	0x1402521a0 <.text+0x2511a0>
140068665:     	ud2

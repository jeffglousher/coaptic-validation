
D:\CoapticCurrent\borrowed-reclaim-encoding-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009f3b0:     	pushq	%rbp
14009f3b1:     	pushq	%r15
14009f3b3:     	pushq	%r14
14009f3b5:     	pushq	%r13
14009f3b7:     	pushq	%r12
14009f3b9:     	pushq	%rsi
14009f3ba:     	pushq	%rdi
14009f3bb:     	pushq	%rbx
14009f3bc:     	subq	$0x218, %rsp            # imm = 0x218
14009f3c3:     	leaq	0x80(%rsp), %rbp
14009f3cb:     	movaps	%xmm6, 0x180(%rbp)
14009f3d2:     	leaq	0x37400(%rcx), %rdx
14009f3d9:     	leaq	0x26720(%rcx), %rsi
14009f3e0:     	leaq	0x2b320(%rcx), %r15
14009f3e7:     	leaq	0x26848(%rcx), %rax
14009f3ee:     	xorl	%r10d, %r10d
14009f3f1:     	movl	$0x1, %r11d
14009f3f7:     	xorl	%r9d, %r9d
14009f3fa:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009f401:     	addq	%rax, %rdi
14009f404:     	jmp	0x14009f420 <.text+0x9e420>
14009f406:     	nopw	%cs:(%rax,%rax)
14009f410:     	incq	%r10
14009f413:     	addq	$0x130, %rdi            # imm = 0x130
14009f41a:     	cmpq	$0x40, %r10
14009f41e:     	je	0x14009f471 <.text+0x9e471>
14009f420:     	cmpl	$0x0, 0x4c00(%rsi,%r10,4)
14009f429:     	je	0x14009f410 <.text+0x9e410>
14009f42b:     	movzwl	-0x128(%rdi), %ebx
14009f432:     	cmpw	$-0x1, %bx
14009f436:     	je	0x14009f410 <.text+0x9e410>
14009f438:     	movq	(%rdi), %rdi
14009f43b:     	cmpw	$0x2, %bx
14009f43f:     	setne	%bl
14009f442:     	testq	%rdi, %rdi
14009f445:     	sete	%r12b
14009f449:     	orb	%bl, %r12b
14009f44c:     	cmpq	%r14, %rdi
14009f44f:     	setae	%bl
14009f452:     	andb	%r9b, %bl
14009f455:     	testb	%r12b, %r12b
14009f458:     	cmoveq	%r11, %r9
14009f45c:     	orb	%r12b, %bl
14009f45f:     	cmoveq	%r10, %r8
14009f463:     	cmoveq	%rdi, %r14
14009f467:     	cmpq	$0x3f, %r10
14009f46b:     	leaq	0x1(%r10), %r10
14009f46f:     	jb	0x14009f3fa <.text+0x9e3fa>
14009f471:     	xorl	%eax, %eax
14009f473:     	cmpq	$0x1, %r9
14009f477:     	jne	0x14009f4a7 <.text+0x9e4a7>
14009f479:     	cmpq	$0x40, %r8
14009f47d:     	jae	0x14009f4a7 <.text+0x9e4a7>
14009f47f:     	cmpl	$0x0, (%r15,%r8,4)
14009f484:     	je	0x14009f4a5 <.text+0x9e4a5>
14009f486:     	imulq	$0x130, %r8, %rax       # imm = 0x130
14009f48d:     	cmpw	$0x2, (%rsi,%rax)
14009f492:     	jne	0x14009f4a5 <.text+0x9e4a5>
14009f494:     	addq	%rsi, %rax
14009f497:     	movzbl	0x122(%rax), %r12d
14009f49f:     	cmpb	$0x2, %r12b
14009f4a3:     	jne	0x14009f4c2 <.text+0x9e4c2>
14009f4a5:     	xorl	%eax, %eax
14009f4a7:     	movaps	0x180(%rbp), %xmm6
14009f4ae:     	addq	$0x218, %rsp            # imm = 0x218
14009f4b5:     	popq	%rbx
14009f4b6:     	popq	%rdi
14009f4b7:     	popq	%rsi
14009f4b8:     	popq	%r12
14009f4ba:     	popq	%r13
14009f4bc:     	popq	%r14
14009f4be:     	popq	%r15
14009f4c0:     	popq	%rbp
14009f4c1:     	retq
14009f4c2:     	movq	0x8(%rax), %r9
14009f4c6:     	movq	0x108(%rax), %r8
14009f4cd:     	movq	%r8, 0x160(%rbp)
14009f4d4:     	movq	0x110(%rax), %r8
14009f4db:     	movq	%r8, 0x168(%rbp)
14009f4e2:     	movl	0x118(%rax), %edi
14009f4e8:     	movl	0x11c(%rax), %r8d
14009f4ef:     	movl	%r8d, 0x174(%rbp)
14009f4f6:     	movzwl	0x120(%rax), %r8d
14009f4fe:     	movw	%r8w, 0x17c(%rbp)
14009f506:     	movzbl	0x123(%rax), %r8d
14009f50e:     	movb	%r8b, 0x17f(%rbp)
14009f515:     	movss	0x124(%rax), %xmm6
14009f51d:     	movzwl	0x124(%rax), %eax
14009f524:     	movzwl	%ax, %r8d
14009f528:     	cmpq	$0x1f, %r9
14009f52c:     	ja	0x14009f57a <.text+0x9e57a>
14009f52e:     	cmpb	$0x1, (%rdx,%r9)
14009f533:     	jne	0x14009f57a <.text+0x9e57a>
14009f535:     	cmpb	$0x0, 0x37420(%rcx,%r9)
14009f53e:     	jne	0x14009f57a <.text+0x9e57a>
14009f540:     	movb	$0x0, 0x37400(%rcx,%r9)
14009f549:     	decq	0x37448(%rcx)
14009f550:     	movq	$0x0, 0x432d0(%rcx,%r9,8)
14009f55c:     	leaq	(%r9,%r9,8), %r10
14009f560:     	leaq	(%r10,%r10,2), %r10
14009f564:     	addq	%r9, %r10
14009f567:     	movb	$0x2, 0x36a(%rdx,%r10)
14009f570:     	leaq	(%r9,%r9,2), %r9
14009f574:     	movb	$0x2, 0x5d(%rdx,%r9,8)
14009f57a:     	addl	$0x2, %r8d
14009f57e:     	leaq	0x26844(%rcx), %r9
14009f585:     	xorl	%r10d, %r10d
14009f588:     	xorl	%edx, %edx
14009f58a:     	jmp	0x14009f5a3 <.text+0x9e5a3>
14009f58c:     	nopl	(%rax)
14009f590:     	movq	%rbx, %r11
14009f593:     	incq	%r10
14009f596:     	addq	$0x130, %r9             # imm = 0x130
14009f59d:     	cmpq	$0x40, %r10
14009f5a1:     	je	0x14009f621 <.text+0x9e621>
14009f5a3:     	movq	%r11, %rbx
14009f5a6:     	cmpl	%r8d, (%r15,%r10,4)
14009f5aa:     	jne	0x14009f590 <.text+0x9e590>
14009f5ac:     	cmpw	$-0x1, -0x124(%r9)
14009f5b5:     	je	0x14009f590 <.text+0x9e590>
14009f5b7:     	cmpw	%ax, (%r9)
14009f5bb:     	jne	0x14009f590 <.text+0x9e590>
14009f5bd:     	cmpl	%edi, -0xc(%r9)
14009f5c1:     	jne	0x14009f590 <.text+0x9e590>
14009f5c3:     	movl	0x174(%rbp), %r11d
14009f5ca:     	cmpl	%r11d, -0x8(%r9)
14009f5ce:     	jne	0x14009f590 <.text+0x9e590>
14009f5d0:     	movzwl	0x17c(%rbp), %r11d
14009f5d8:     	cmpw	%r11w, -0x4(%r9)
14009f5dd:     	jne	0x14009f590 <.text+0x9e590>
14009f5df:     	cmpb	%r12b, -0x2(%r9)
14009f5e3:     	jne	0x14009f590 <.text+0x9e590>
14009f5e5:     	movq	-0x1c(%r9), %r11
14009f5e9:     	xorq	0x160(%rbp), %r11
14009f5f0:     	movq	-0x14(%r9), %r13
14009f5f4:     	xorq	0x168(%rbp), %r13
14009f5fb:     	orq	%r11, %r13
14009f5fe:     	jne	0x14009f590 <.text+0x9e590>
14009f600:     	movq	%r10, %r11
14009f603:     	cmpq	$0x1, %rdx
14009f607:     	movl	$0x1, %edx
14009f60c:     	jne	0x14009f593 <.text+0x9e593>
14009f60e:     	movb	$0x1, %dl
14009f610:     	movl	%edx, 0x178(%rbp)
14009f616:     	movq	%rbx, %r11
14009f619:     	cmpq	$0x3f, %rbx
14009f61d:     	jbe	0x14009f638 <.text+0x9e638>
14009f61f:     	jmp	0x14009f65f <.text+0x9e65f>
14009f621:     	cmpq	$0x40, %r11
14009f625:     	setb	%r8b
14009f629:     	movl	$0x0, 0x178(%rbp)
14009f633:     	testb	%r8b, %dl
14009f636:     	je	0x14009f65f <.text+0x9e65f>
14009f638:     	cmpl	$0x0, (%r15,%r11,4)
14009f63d:     	je	0x14009f65f <.text+0x9e65f>
14009f63f:     	movl	$0x0, 0x2b320(%rcx,%r11,4)
14009f64b:     	decq	0x2b428(%rcx)
14009f652:     	imulq	$0x130, %r11, %rdx      # imm = 0x130
14009f659:     	movw	$0xffff, (%rsi,%rdx)    # imm = 0xFFFF
14009f65f:     	pxor	%xmm0, %xmm0
14009f663:     	movdqa	%xmm0, 0x150(%rbp)
14009f66b:     	movb	$0x0, 0x132(%rbp)
14009f672:     	movw	%ax, 0x130(%rbp)
14009f679:     	leaq	0x133(%rbp), %rdx
14009f680:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009f689:     	movq	$0x0, 0x133(%rbp)
14009f694:     	movq	$0x8, 0x110(%rbp)
14009f69f:     	movq	$0x0, 0x118(%rbp)
14009f6aa:     	movq	$0x1, 0x120(%rbp)
14009f6b5:     	movq	$0x0, 0x128(%rbp)
14009f6c0:     	movq	%rdx, 0x30(%rsp)
14009f6c5:     	movw	%ax, 0x28(%rsp)
14009f6ca:     	movq	$0x0, 0x58(%rsp)
14009f6d3:     	movq	$0x1, 0x50(%rsp)
14009f6dc:     	movq	$0x8, 0x48(%rsp)
14009f6e5:     	movq	$0x8, 0x40(%rsp)
14009f6ee:     	movq	$0x0, 0x38(%rsp)
14009f6f7:     	movb	$0x0, 0x20(%rsp)
14009f6fc:     	leaq	0x140(%rbp), %rax
14009f703:     	leaq	0x150(%rbp), %rdx
14009f70a:     	movl	$0x10, %r8d
14009f710:     	movq	%rcx, %rbx
14009f713:     	movq	%rax, %rcx
14009f716:     	movb	$0x2, %r9b
14009f719:     	callq	0x140005590 <.text+0x4590>
14009f71e:     	movq	0x148(%rbp), %r13
14009f725:     	cmpq	$0x11, %r13
14009f729:     	setae	%cl
14009f72c:     	orb	0x178(%rbp), %cl
14009f732:     	orb	0x140(%rbp), %cl
14009f738:     	testb	$0x1, %cl
14009f73b:     	jne	0x14009f8c6 <.text+0x9e8c6>
14009f741:     	movq	%rbx, %rax
14009f744:     	cmpq	$0x40, 0x2b428(%rbx)
14009f74c:     	je	0x14009f8c6 <.text+0x9e8c6>
14009f752:     	movq	0x2b420(%rax), %rbx
14009f759:     	cmpq	$0x3f, %rbx
14009f75d:     	ja	0x14009f986 <.text+0x9e986>
14009f763:     	cmpl	$0x0, (%r15,%rbx,4)
14009f768:     	je	0x14009f7d3 <.text+0x9e7d3>
14009f76a:     	leaq	(,%rbx,4), %rdx
14009f772:     	leaq	(%r15,%rbx,4), %rcx
14009f776:     	xorl	%r8d, %r8d
14009f779:     	movq	%rdx, %r9
14009f77c:     	cmpl	$0x0, (%r15,%r9)
14009f781:     	je	0x14009f7c6 <.text+0x9e7c6>
14009f783:     	addq	$0x4, %r9
14009f787:     	decq	%r8
14009f78a:     	cmpq	$0x100, %r9             # imm = 0x100
14009f791:     	jne	0x14009f77c <.text+0x9e77c>
14009f793:     	testq	%rbx, %rbx
14009f796:     	je	0x14009f8c6 <.text+0x9e8c6>
14009f79c:     	addq	$-0x4, %rdx
14009f7a0:     	cmpq	$0xc, %rdx
14009f7a4:     	jae	0x14009f8cd <.text+0x9e8cd>
14009f7aa:     	xorl	%ebx, %ebx
14009f7ac:     	movq	%r15, %r9
14009f7af:     	cmpl	$0x0, (%r9)
14009f7b3:     	je	0x14009f7c9 <.text+0x9e7c9>
14009f7b5:     	addq	$0x4, %r9
14009f7b9:     	incq	%rbx
14009f7bc:     	cmpq	%rcx, %r9
14009f7bf:     	jne	0x14009f7af <.text+0x9e7af>
14009f7c1:     	jmp	0x14009f8c6 <.text+0x9e8c6>
14009f7c6:     	subq	%r8, %rbx
14009f7c9:     	cmpq	$0x40, %rbx
14009f7cd:     	jae	0x14009f970 <.text+0x9e970>
14009f7d3:     	movl	$0x1, 0x2b320(%rax,%rbx,4)
14009f7de:     	incq	0x2b428(%rax)
14009f7e5:     	leaq	0x1(%rbx), %rdx
14009f7e9:     	xorl	%ecx, %ecx
14009f7eb:     	cmpq	$0x40, %rdx
14009f7ef:     	movl	$0x0, %r8d
14009f7f5:     	cmovneq	%rdx, %r8
14009f7f9:     	movq	%r8, 0x2b420(%rax)
14009f800:     	movq	0x168(%rbp), %rax
14009f807:     	movq	%rax, 0xf0(%rbp)
14009f80e:     	movq	0x160(%rbp), %rax
14009f815:     	movq	%rax, 0xe8(%rbp)
14009f81c:     	movl	%edi, 0xf8(%rbp)
14009f822:     	movl	0x174(%rbp), %eax
14009f828:     	movl	%eax, 0xfc(%rbp)
14009f82e:     	movzwl	0x17c(%rbp), %eax
14009f835:     	movw	%ax, 0x100(%rbp)
14009f83c:     	movb	%r12b, 0x102(%rbp)
14009f843:     	movzbl	0x17f(%rbp), %eax
14009f84a:     	movb	%al, 0x103(%rbp)
14009f850:     	movss	%xmm6, 0x104(%rbp)
14009f858:     	movq	%r14, 0x108(%rbp)
14009f85f:     	testq	%r13, %r13
14009f862:     	je	0x14009f89e <.text+0x9e89e>
14009f864:     	movw	%r13w, -0x1e(%rbp)
14009f869:     	leaq	-0x1c(%rbp), %r14
14009f86d:     	movl	$0x100, %r8d            # imm = 0x100
14009f873:     	subq	%r13, %r8
14009f876:     	leaq	-0x1c(,%r13), %rcx
14009f87e:     	addq	%rbp, %rcx
14009f881:     	xorl	%edx, %edx
14009f883:     	callq	0x140251722 <.text+0x250722>
14009f888:     	leaq	0x150(%rbp), %rdx
14009f88f:     	movq	%r14, %rcx
14009f892:     	movq	%r13, %r8
14009f895:     	callq	0x140251710 <.text+0x250710>
14009f89a:     	movw	$0x1, %cx
14009f89e:     	movw	%cx, -0x20(%rbp)
14009f8a2:     	movzwl	0x104(%rbp), %eax
14009f8a9:     	addl	$0x2, %eax
14009f8ac:     	movl	%eax, (%r15,%rbx,4)
14009f8b0:     	imulq	$0x130, %rbx, %rax      # imm = 0x130
14009f8b7:     	addq	%rax, %rsi
14009f8ba:     	leaq	-0x20(%rbp), %rcx
14009f8be:     	movq	%rsi, %rdx
14009f8c1:     	callq	0x14000b1c0 <.text+0xa1c0>
14009f8c6:     	movb	$0x1, %al
14009f8c8:     	jmp	0x14009f4a7 <.text+0x9e4a7>
14009f8cd:     	shrq	$0x2, %rdx
14009f8d1:     	incq	%rdx
14009f8d4:     	movq	%rdx, %rbx
14009f8d7:     	andq	$-0x4, %rbx
14009f8db:     	leaq	(%r15,%rbx,4), %r9
14009f8df:     	xorl	%r8d, %r8d
14009f8e2:     	pxor	%xmm1, %xmm1
14009f8e6:     	movdqu	(%r15,%r8,4), %xmm0
14009f8ec:     	movdqa	%xmm0, %xmm2
14009f8f0:     	pcmpeqd	%xmm1, %xmm2
14009f8f4:     	movmskps	%xmm2, %r10d
14009f8f8:     	testl	%r10d, %r10d
14009f8fb:     	jne	0x14009f911 <.text+0x9e911>
14009f8fd:     	addq	$0x4, %r8
14009f901:     	cmpq	%r8, %rbx
14009f904:     	jne	0x14009f8e6 <.text+0x9e8e6>
14009f906:     	cmpq	%rbx, %rdx
14009f909:     	jne	0x14009f7af <.text+0x9e7af>
14009f90f:     	jmp	0x14009f8c6 <.text+0x9e8c6>
14009f911:     	pxor	%xmm1, %xmm1
14009f915:     	pcmpeqd	%xmm1, %xmm0
14009f919:     	pand	0x1c443f(%rip), %xmm0   # 0x140263d60
14009f921:     	movdqa	0x1c2337(%rip), %xmm1   # 0x140261c60
14009f929:     	movdqa	%xmm0, %xmm2
14009f92d:     	por	%xmm1, %xmm2
14009f931:     	pshufd	$0xee, %xmm0, %xmm3     # xmm3 = xmm0[2,3,2,3]
14009f936:     	por	%xmm3, %xmm1
14009f93a:     	pcmpgtd	%xmm1, %xmm2
14009f93e:     	pand	%xmm2, %xmm0
14009f942:     	pandn	%xmm3, %xmm2
14009f946:     	por	%xmm0, %xmm2
14009f94a:     	movd	%xmm2, %ecx
14009f94e:     	pshufd	$0x55, %xmm2, %xmm0     # xmm0 = xmm2[1,1,1,1]
14009f953:     	movd	%xmm0, %edx
14009f957:     	cmpl	%edx, %ecx
14009f959:     	cmoval	%ecx, %edx
14009f95c:     	movl	$0x4, %ebx
14009f961:     	subl	%edx, %ebx
14009f963:     	addq	%r8, %rbx
14009f966:     	cmpq	$0x40, %rbx
14009f96a:     	jb	0x14009f7d3 <.text+0x9e7d3>
14009f970:     	leaq	0x1cd411(%rip), %r8     # 0x14026cd88
14009f977:     	movl	$0x40, %edx
14009f97c:     	movq	%rbx, %rcx
14009f97f:     	callq	0x140251f93 <.text+0x250f93>
14009f984:     	ud2
14009f986:     	leaq	0x1cd3e3(%rip), %r8     # 0x14026cd70
14009f98d:     	movl	$0x40, %edx
14009f992:     	movq	%rbx, %rcx
14009f995:     	callq	0x140251f93 <.text+0x250f93>
14009f99a:     	ud2

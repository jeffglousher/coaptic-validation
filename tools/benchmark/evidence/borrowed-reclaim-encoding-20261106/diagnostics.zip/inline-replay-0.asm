
D:\CoapticCurrent\borrowed-reclaim-encoding-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14000b1c0:     	pushq	%rbp
14000b1c1:     	movq	%rsp, %rbp
14000b1c4:     	movzwl	(%rcx), %eax
14000b1c7:     	testl	%eax, %eax
14000b1c9:     	je	0x14000b1e5 <.text+0xa1e5>
14000b1cb:     	cmpl	$0x1, %eax
14000b1ce:     	jne	0x14000b216 <.text+0xa216>
14000b1d0:     	movl	$0x130, %r8d            # imm = 0x130
14000b1d6:     	movq	%rcx, %rax
14000b1d9:     	movq	%rdx, %rcx
14000b1dc:     	movq	%rax, %rdx
14000b1df:     	popq	%rbp
14000b1e0:     	jmp	0x140251710 <.text+0x250710>
14000b1e5:     	movw	$0x0, (%rdx)
14000b1ea:     	movups	0x108(%rcx), %xmm0
14000b1f1:     	movups	0x118(%rcx), %xmm1
14000b1f8:     	movups	%xmm0, 0x108(%rdx)
14000b1ff:     	movups	%xmm1, 0x118(%rdx)
14000b206:     	movq	0x128(%rcx), %rax
14000b20d:     	movq	%rax, 0x128(%rdx)
14000b214:     	popq	%rbp
14000b215:     	retq
14000b216:     	leaq	0x108(%rcx), %rax
14000b21d:     	movq	0x8(%rcx), %r9
14000b221:     	movq	0x128(%rcx), %r8
14000b228:     	movq	%rdx, %rcx
14000b22b:     	movq	%rax, %rdx
14000b22e:     	popq	%rbp
14000b22f:     	jmp	0x14000b290 <.text+0xa290>

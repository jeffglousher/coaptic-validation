from pathlib import Path
import json, hashlib, re
r=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
v=read(r/'source-verification.json');f=Path(v['fixture_root'])
assert all(hashlib.sha256((f/'coaptic'/n).read_bytes()).hexdigest()==h for n,h in v['source_file_hashes'].items())
for n,h in read(r/'fixture-sha256.json').items():
    candidates=[p for p in f.rglob(Path(n.replace('\\','/')).name) if p.is_file()]
    assert sum(hashlib.sha256(p.read_bytes()).hexdigest()==h for p in candidates)==1,n
prior=Path('D:/CoapticCurrent/replay-occupancy-index-20261106/memory-comparison.json')
layout=(r/'owner-layout.txt').read_text();rows=[]
for record in read(prior)['layout_records']:
    if 'baseline-future-layout.txt' not in record['file']:
        prefix=record['record'].split('`: ')[0]+'`: '
        line=next(s for s in layout.splitlines() if s.startswith(prefix))
        a=int(re.search(r'`: (\d+) bytes',record['record'])[1]);b=int(re.search(r'`: (\d+) bytes',line)[1])
        assert b<=a
        rows.append({'owner':record['owner'],'baseline':a,'candidate':b})
assert sorted(x['frame'] for x in read(r/'encoder-frames.json'))==[1280,1296]
reclaim=read(r/'reclaim-frames.json');assert reclaim['nongrowth']
assert read(r/'layout32/preflight.json')['nongrowth']
assert all(x['exit_code']==0 for x in read(r/'build-results.json'))
x={'future_rows':rows,'encoder_frames':[1280,1296],'reclaim_nongrowth':True,'source_hashes_verified':len(v['source_file_hashes']),'fixture_files_verified':7}
(r/'preflight-host.json').write_text(json.dumps(x,indent=2)+'\n')
print(x)

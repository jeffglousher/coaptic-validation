
D:\CoapticCurrent\borrowed-reclaim-encoding-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009ecc0:     	pushq	%rbp
14009ecc1:     	pushq	%r15
14009ecc3:     	pushq	%r14
14009ecc5:     	pushq	%r13
14009ecc7:     	pushq	%r12
14009ecc9:     	pushq	%rsi
14009ecca:     	pushq	%rdi
14009eccb:     	pushq	%rbx
14009eccc:     	subq	$0x218, %rsp            # imm = 0x218
14009ecd3:     	leaq	0x80(%rsp), %rbp
14009ecdb:     	movaps	%xmm6, 0x180(%rbp)
14009ece2:     	leaq	0x3a60(%rcx), %r8
14009ece9:     	leaq	0x2ac8(%rcx), %rsi
14009ecf0:     	leaq	0x2bf0(%rcx), %rax
14009ecf7:     	xorl	%r10d, %r10d
14009ecfa:     	movl	$0x1, %r11d
14009ed00:     	xorl	%r9d, %r9d
14009ed03:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009ed0a:     	addq	%rax, %rdi
14009ed0d:     	jmp	0x14009ed20 <.text+0x9dd20>
14009ed0f:     	nop
14009ed10:     	incq	%r10
14009ed13:     	addq	$0x130, %rdi            # imm = 0x130
14009ed1a:     	cmpq	$0x4, %r10
14009ed1e:     	je	0x14009ed71 <.text+0x9dd71>
14009ed20:     	cmpl	$0x0, 0x4c0(%rsi,%r10,4)
14009ed29:     	je	0x14009ed10 <.text+0x9dd10>
14009ed2b:     	movzwl	-0x128(%rdi), %ebx
14009ed32:     	cmpw	$-0x1, %bx
14009ed36:     	je	0x14009ed10 <.text+0x9dd10>
14009ed38:     	movq	(%rdi), %rdi
14009ed3b:     	cmpw	$0x2, %bx
14009ed3f:     	setne	%bl
14009ed42:     	testq	%rdi, %rdi
14009ed45:     	sete	%r15b
14009ed49:     	orb	%bl, %r15b
14009ed4c:     	cmpq	%r14, %rdi
14009ed4f:     	setae	%bl
14009ed52:     	andb	%r9b, %bl
14009ed55:     	testb	%r15b, %r15b
14009ed58:     	cmoveq	%r11, %r9
14009ed5c:     	orb	%r15b, %bl
14009ed5f:     	cmoveq	%r10, %rdx
14009ed63:     	cmoveq	%rdi, %r14
14009ed67:     	cmpq	$0x3, %r10
14009ed6b:     	leaq	0x1(%r10), %r10
14009ed6f:     	jb	0x14009ed03 <.text+0x9dd03>
14009ed71:     	xorl	%eax, %eax
14009ed73:     	cmpq	$0x1, %r9
14009ed77:     	jne	0x14009edaa <.text+0x9ddaa>
14009ed79:     	cmpq	$0x4, %rdx
14009ed7d:     	jae	0x14009edaa <.text+0x9ddaa>
14009ed7f:     	cmpl	$0x0, 0x2f88(%rcx,%rdx,4)
14009ed87:     	je	0x14009eda8 <.text+0x9dda8>
14009ed89:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009ed90:     	cmpw	$0x2, (%rsi,%rax)
14009ed95:     	jne	0x14009eda8 <.text+0x9dda8>
14009ed97:     	addq	%rsi, %rax
14009ed9a:     	movzbl	0x122(%rax), %r15d
14009eda2:     	cmpb	$0x2, %r15b
14009eda6:     	jne	0x14009edc5 <.text+0x9ddc5>
14009eda8:     	xorl	%eax, %eax
14009edaa:     	movaps	0x180(%rbp), %xmm6
14009edb1:     	addq	$0x218, %rsp            # imm = 0x218
14009edb8:     	popq	%rbx
14009edb9:     	popq	%rdi
14009edba:     	popq	%rsi
14009edbb:     	popq	%r12
14009edbd:     	popq	%r13
14009edbf:     	popq	%r14
14009edc1:     	popq	%r15
14009edc3:     	popq	%rbp
14009edc4:     	retq
14009edc5:     	movq	0x8(%rax), %r9
14009edc9:     	movq	0x108(%rax), %r12
14009edd0:     	movq	0x110(%rax), %rdx
14009edd7:     	movq	%rdx, 0x170(%rbp)
14009edde:     	movl	0x118(%rax), %r13d
14009ede5:     	movl	0x11c(%rax), %edi
14009edeb:     	movzwl	0x120(%rax), %ebx
14009edf2:     	movzbl	0x123(%rax), %edx
14009edf9:     	movb	%dl, 0x17f(%rbp)
14009edff:     	movss	0x124(%rax), %xmm6
14009ee07:     	movzwl	0x124(%rax), %eax
14009ee0e:     	movzwl	%ax, %edx
14009ee11:     	cmpq	$0x1, %r9
14009ee15:     	ja	0x14009ee6a <.text+0x9de6a>
14009ee17:     	cmpb	$0x1, 0x43e8(%rcx,%r9)
14009ee20:     	jne	0x14009ee6a <.text+0x9de6a>
14009ee22:     	cmpb	$0x0, 0x43ea(%rcx,%r9)
14009ee2b:     	jne	0x14009ee6a <.text+0x9de6a>
14009ee2d:     	movb	$0x0, 0x43e8(%rcx,%r9)
14009ee36:     	decq	0x43e0(%rcx)
14009ee3d:     	movq	$0x0, 0x4360(%rcx,%r9,8)
14009ee49:     	leaq	(%r9,%r9,8), %r10
14009ee4d:     	leaq	(%r10,%r10,2), %r10
14009ee51:     	addq	%r9, %r10
14009ee54:     	movb	$0x2, 0x95a(%r8,%r10)
14009ee5d:     	leaq	(%r9,%r9,2), %r9
14009ee61:     	movb	$0x2, 0x91d(%r8,%r9,8)
14009ee6a:     	addl	$0x2, %edx
14009ee6d:     	xorl	%r10d, %r10d
14009ee70:     	movb	$0x1, %r11b
14009ee73:     	cmpl	%edx, 0x2f88(%rcx)
14009ee79:     	jne	0x14009eef4 <.text+0x9def4>
14009ee7b:     	cmpw	$-0x1, 0x2ac8(%rcx)
14009ee83:     	je	0x14009eef4 <.text+0x9def4>
14009ee85:     	cmpw	%ax, 0x2bec(%rcx)
14009ee8c:     	sete	%r8b
14009ee90:     	cmpl	%r13d, 0x2be0(%rcx)
14009ee97:     	sete	%r9b
14009ee9b:     	andb	%r8b, %r9b
14009ee9e:     	cmpl	%edi, 0x2be4(%rcx)
14009eea4:     	sete	%r8b
14009eea8:     	cmpw	%bx, 0x2be8(%rcx)
14009eeaf:     	sete	%r10b
14009eeb3:     	andb	%r8b, %r10b
14009eeb6:     	andb	%r9b, %r10b
14009eeb9:     	cmpb	%r15b, 0x2bea(%rcx)
14009eec0:     	sete	%r8b
14009eec4:     	movq	0x2bd8(%rcx), %r9
14009eecb:     	xorq	0x170(%rbp), %r9
14009eed2:     	movq	0x2bd0(%rcx), %r11
14009eed9:     	xorq	%r12, %r11
14009eedc:     	orq	%r9, %r11
14009eedf:     	sete	%r9b
14009eee3:     	andb	%r8b, %r9b
14009eee6:     	andb	%r10b, %r9b
14009eee9:     	movzbl	%r9b, %r10d
14009eeed:     	movl	%r10d, %r11d
14009eef0:     	xorb	$0x1, %r11b
14009eef4:     	xorl	%r8d, %r8d
14009eef7:     	cmpl	%edx, 0x2f8c(%rcx)
14009eefd:     	movw	%bx, 0x17c(%rbp)
14009ef04:     	movl	%edi, 0x178(%rbp)
14009ef0a:     	jne	0x14009efb5 <.text+0x9dfb5>
14009ef10:     	cmpw	$-0x1, 0x2bf8(%rcx)
14009ef18:     	je	0x14009efb5 <.text+0x9dfb5>
14009ef1e:     	cmpw	%ax, 0x2d1c(%rcx)
14009ef25:     	setne	%r8b
14009ef29:     	cmpl	%r13d, 0x2d10(%rcx)
14009ef30:     	setne	%r9b
14009ef34:     	orb	%r8b, %r9b
14009ef37:     	cmpl	%edi, 0x2d14(%rcx)
14009ef3d:     	setne	%r8b
14009ef41:     	cmpw	%bx, 0x2d18(%rcx)
14009ef48:     	setne	%bl
14009ef4b:     	orb	%r8b, %bl
14009ef4e:     	orb	%r9b, %bl
14009ef51:     	cmpb	%r15b, 0x2d1a(%rcx)
14009ef58:     	setne	%r9b
14009ef5c:     	movq	0x2d08(%rcx), %r8
14009ef63:     	xorq	0x170(%rbp), %r8
14009ef6a:     	movq	0x2d00(%rcx), %rdi
14009ef71:     	xorq	%r12, %rdi
14009ef74:     	orq	%r8, %rdi
14009ef77:     	setne	%r8b
14009ef7b:     	orb	%r9b, %r8b
14009ef7e:     	orb	%bl, %r8b
14009ef81:     	orb	%r8b, %r11b
14009ef84:     	testb	%r8b, %r8b
14009ef87:     	movl	$0x1, %r9d
14009ef8d:     	cmovneq	%r10, %r9
14009ef91:     	testb	$0x1, %r11b
14009ef95:     	je	0x14009f0a6 <.text+0x9e0a6>
14009ef9b:     	notb	%r8b
14009ef9e:     	movzbl	%r8b, %r8d
14009efa2:     	andl	$0x1, %r8d
14009efa6:     	movl	0x178(%rbp), %edi
14009efac:     	movzwl	0x17c(%rbp), %ebx
14009efb3:     	jmp	0x14009efb8 <.text+0x9dfb8>
14009efb5:     	movq	%r10, %r9
14009efb8:     	cmpl	%edx, 0x2f90(%rcx)
14009efbe:     	jne	0x14009f031 <.text+0x9e031>
14009efc0:     	cmpw	$-0x1, 0x2d28(%rcx)
14009efc8:     	je	0x14009f031 <.text+0x9e031>
14009efca:     	cmpw	%ax, 0x2e4c(%rcx)
14009efd1:     	jne	0x14009f031 <.text+0x9e031>
14009efd3:     	cmpl	%r13d, 0x2e40(%rcx)
14009efda:     	jne	0x14009f031 <.text+0x9e031>
14009efdc:     	cmpl	%edi, 0x2e44(%rcx)
14009efe2:     	jne	0x14009f031 <.text+0x9e031>
14009efe4:     	cmpw	%bx, 0x2e48(%rcx)
14009efeb:     	jne	0x14009f031 <.text+0x9e031>
14009efed:     	cmpb	%r15b, 0x2e4a(%rcx)
14009eff4:     	jne	0x14009f031 <.text+0x9e031>
14009eff6:     	movq	0x2e30(%rcx), %r10
14009effd:     	xorq	%r12, %r10
14009f000:     	movq	0x2e38(%rcx), %r11
14009f007:     	xorq	0x170(%rbp), %r11
14009f00e:     	orq	%r10, %r11
14009f011:     	jne	0x14009f031 <.text+0x9e031>
14009f013:     	movb	$0x1, %dil
14009f016:     	testq	%r9, %r9
14009f019:     	jne	0x14009f0ac <.text+0x9e0ac>
14009f01f:     	movl	$0x1, %r9d
14009f025:     	movl	$0x2, %r8d
14009f02b:     	movl	0x178(%rbp), %edi
14009f031:     	cmpl	%edx, 0x2f94(%rcx)
14009f037:     	jne	0x14009f09d <.text+0x9e09d>
14009f039:     	cmpw	$-0x1, 0x2e58(%rcx)
14009f041:     	je	0x14009f09d <.text+0x9e09d>
14009f043:     	cmpw	%ax, 0x2f7c(%rcx)
14009f04a:     	jne	0x14009f09d <.text+0x9e09d>
14009f04c:     	cmpl	%r13d, 0x2f70(%rcx)
14009f053:     	jne	0x14009f09d <.text+0x9e09d>
14009f055:     	cmpl	%edi, 0x2f74(%rcx)
14009f05b:     	jne	0x14009f09d <.text+0x9e09d>
14009f05d:     	cmpw	%bx, 0x2f78(%rcx)
14009f064:     	jne	0x14009f09d <.text+0x9e09d>
14009f066:     	cmpb	%r15b, 0x2f7a(%rcx)
14009f06d:     	jne	0x14009f09d <.text+0x9e09d>
14009f06f:     	movq	0x2f60(%rcx), %rdx
14009f076:     	xorq	%r12, %rdx
14009f079:     	movq	0x2f68(%rcx), %r10
14009f080:     	xorq	0x170(%rbp), %r10
14009f087:     	orq	%rdx, %r10
14009f08a:     	jne	0x14009f09d <.text+0x9e09d>
14009f08c:     	testq	%r9, %r9
14009f08f:     	movl	$0x3, %edx
14009f094:     	cmoveq	%rdx, %r8
14009f098:     	movl	%r9d, %edi
14009f09b:     	jmp	0x14009f0ac <.text+0x9e0ac>
14009f09d:     	xorl	%edi, %edi
14009f09f:     	testq	%r9, %r9
14009f0a2:     	jne	0x14009f0ac <.text+0x9e0ac>
14009f0a4:     	jmp	0x14009f0d7 <.text+0x9e0d7>
14009f0a6:     	movb	$0x1, %dil
14009f0a9:     	xorl	%r8d, %r8d
14009f0ac:     	cmpl	$0x0, 0x2f88(%rcx,%r8,4)
14009f0b5:     	je	0x14009f0d7 <.text+0x9e0d7>
14009f0b7:     	movl	$0x0, 0x2f88(%rcx,%r8,4)
14009f0c3:     	decq	0x2fa0(%rcx)
14009f0ca:     	imulq	$0x130, %r8, %rdx       # imm = 0x130
14009f0d1:     	movw	$0xffff, (%rsi,%rdx)    # imm = 0xFFFF
14009f0d7:     	movl	%r13d, 0x16c(%rbp)
14009f0de:     	movq	%r12, %r13
14009f0e1:     	xorps	%xmm0, %xmm0
14009f0e4:     	movaps	%xmm0, 0x150(%rbp)
14009f0eb:     	movb	$0x0, 0x132(%rbp)
14009f0f2:     	movw	%ax, 0x130(%rbp)
14009f0f9:     	leaq	0x133(%rbp), %rdx
14009f100:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009f109:     	movq	$0x0, 0x133(%rbp)
14009f114:     	movq	$0x8, 0x110(%rbp)
14009f11f:     	movq	$0x0, 0x118(%rbp)
14009f12a:     	movq	$0x1, 0x120(%rbp)
14009f135:     	movq	$0x0, 0x128(%rbp)
14009f140:     	movq	%rdx, 0x30(%rsp)
14009f145:     	movw	%ax, 0x28(%rsp)
14009f14a:     	movq	$0x0, 0x58(%rsp)
14009f153:     	movq	$0x1, 0x50(%rsp)
14009f15c:     	movq	$0x8, 0x48(%rsp)
14009f165:     	movq	$0x8, 0x40(%rsp)
14009f16e:     	movq	$0x0, 0x38(%rsp)
14009f177:     	movb	$0x0, 0x20(%rsp)
14009f17c:     	leaq	0x140(%rbp), %rax
14009f183:     	leaq	0x150(%rbp), %rdx
14009f18a:     	movl	$0x10, %r8d
14009f190:     	movq	%rcx, %r12
14009f193:     	movq	%rax, %rcx
14009f196:     	movb	$0x2, %r9b
14009f199:     	callq	0x140005590 <.text+0x4590>
14009f19e:     	cmpb	$0x0, 0x140(%rbp)
14009f1a5:     	jne	0x14009f35e <.text+0x9e35e>
14009f1ab:     	testb	%dil, %dil
14009f1ae:     	jne	0x14009f35e <.text+0x9e35e>
14009f1b4:     	movq	0x148(%rbp), %rbx
14009f1bb:     	cmpq	$0x10, %rbx
14009f1bf:     	ja	0x14009f35e <.text+0x9e35e>
14009f1c5:     	movq	%r12, %rax
14009f1c8:     	cmpq	$0x4, 0x2fa0(%r12)
14009f1d1:     	je	0x14009f35e <.text+0x9e35e>
14009f1d7:     	movq	0x2f98(%rax), %rdi
14009f1de:     	cmpq	$0x3, %rdi
14009f1e2:     	ja	0x14009f376 <.text+0x9e376>
14009f1e8:     	cmpl	$0x0, 0x2f88(%rax,%rdi,4)
14009f1f0:     	je	0x14009f26a <.text+0x9e26a>
14009f1f2:     	leaq	(,%rdi,4), %rdx
14009f1fa:     	xorl	%ecx, %ecx
14009f1fc:     	cmpl	$0x0, 0x2f88(%rax,%rdx)
14009f204:     	je	0x14009f25d <.text+0x9e25d>
14009f206:     	addq	$0x4, %rdx
14009f20a:     	decq	%rcx
14009f20d:     	cmpq	$0x10, %rdx
14009f211:     	jne	0x14009f1fc <.text+0x9e1fc>
14009f213:     	testq	%rdi, %rdi
14009f216:     	je	0x14009f35e <.text+0x9e35e>
14009f21c:     	cmpl	$0x0, 0x2f88(%rax)
14009f223:     	je	0x14009f365 <.text+0x9e365>
14009f229:     	cmpq	$0x1, %rdi
14009f22d:     	je	0x14009f35e <.text+0x9e35e>
14009f233:     	cmpl	$0x0, 0x2f8c(%rax)
14009f23a:     	je	0x14009f36c <.text+0x9e36c>
14009f240:     	cmpq	$0x2, %rdi
14009f244:     	je	0x14009f35e <.text+0x9e35e>
14009f24a:     	movl	$0x2, %edi
14009f24f:     	cmpl	$0x0, 0x2f90(%rax)
14009f256:     	je	0x14009f260 <.text+0x9e260>
14009f258:     	jmp	0x14009f35e <.text+0x9e35e>
14009f25d:     	subq	%rcx, %rdi
14009f260:     	cmpq	$0x4, %rdi
14009f264:     	jae	0x14009f38c <.text+0x9e38c>
14009f26a:     	movl	$0x1, 0x2f88(%rax,%rdi,4)
14009f275:     	incq	0x2fa0(%rax)
14009f27c:     	leaq	0x1(%rdi), %rdx
14009f280:     	xorl	%ecx, %ecx
14009f282:     	cmpq	$0x4, %rdx
14009f286:     	movl	$0x0, %r8d
14009f28c:     	cmovneq	%rdx, %r8
14009f290:     	movq	%r8, 0x2f98(%rax)
14009f297:     	movq	0x170(%rbp), %rdx
14009f29e:     	movq	%rdx, 0xf0(%rbp)
14009f2a5:     	movq	%r13, 0xe8(%rbp)
14009f2ac:     	movl	0x16c(%rbp), %edx
14009f2b2:     	movl	%edx, 0xf8(%rbp)
14009f2b8:     	movl	0x178(%rbp), %edx
14009f2be:     	movl	%edx, 0xfc(%rbp)
14009f2c4:     	movzwl	0x17c(%rbp), %edx
14009f2cb:     	movw	%dx, 0x100(%rbp)
14009f2d2:     	movb	%r15b, 0x102(%rbp)
14009f2d9:     	movzbl	0x17f(%rbp), %edx
14009f2e0:     	movb	%dl, 0x103(%rbp)
14009f2e6:     	movss	%xmm6, 0x104(%rbp)
14009f2ee:     	movq	%r14, 0x108(%rbp)
14009f2f5:     	testq	%rbx, %rbx
14009f2f8:     	je	0x14009f333 <.text+0x9e333>
14009f2fa:     	movw	%bx, -0x1e(%rbp)
14009f2fe:     	leaq	-0x1c(%rbp), %r14
14009f302:     	movl	$0x100, %r8d            # imm = 0x100
14009f308:     	subq	%rbx, %r8
14009f30b:     	leaq	(%rbx,%rbp), %rcx
14009f30f:     	addq	$-0x1c, %rcx
14009f313:     	xorl	%edx, %edx
14009f315:     	callq	0x140251722 <.text+0x250722>
14009f31a:     	leaq	0x150(%rbp), %rdx
14009f321:     	movq	%r14, %rcx
14009f324:     	movq	%rbx, %r8
14009f327:     	callq	0x140251710 <.text+0x250710>
14009f32c:     	movq	%r12, %rax
14009f32f:     	movw	$0x1, %cx
14009f333:     	movw	%cx, -0x20(%rbp)
14009f337:     	movzwl	0x104(%rbp), %ecx
14009f33e:     	addl	$0x2, %ecx
14009f341:     	movl	%ecx, 0x2f88(%rax,%rdi,4)
14009f348:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009f34f:     	addq	%rax, %rsi
14009f352:     	leaq	-0x20(%rbp), %rcx
14009f356:     	movq	%rsi, %rdx
14009f359:     	callq	0x14000b1c0 <.text+0xa1c0>
14009f35e:     	movb	$0x1, %al
14009f360:     	jmp	0x14009edaa <.text+0x9ddaa>
14009f365:     	xorl	%edi, %edi
14009f367:     	jmp	0x14009f260 <.text+0x9e260>
14009f36c:     	movl	$0x1, %edi
14009f371:     	jmp	0x14009f260 <.text+0x9e260>
14009f376:     	leaq	0x1cd9f3(%rip), %r8     # 0x14026cd70
14009f37d:     	movl	$0x4, %edx
14009f382:     	movq	%rdi, %rcx
14009f385:     	callq	0x140251f93 <.text+0x250f93>
14009f38a:     	ud2
14009f38c:     	leaq	0x1cd9f5(%rip), %r8     # 0x14026cd88
14009f393:     	movl	$0x4, %edx
14009f398:     	movq	%rdi, %rcx
14009f39b:     	callq	0x140251f93 <.text+0x250f93>
14009f3a0:     	ud2

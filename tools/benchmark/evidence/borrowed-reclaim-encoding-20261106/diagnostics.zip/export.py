"""Retain the completed cohort without executing or replacing measurements."""
from pathlib import Path
import hashlib, json, re, shutil, zipfile

root = Path(__file__).resolve().parent
out = Path('D:/codex-work/coaptic-validation/tools/benchmark/evidence/borrowed-reclaim-encoding-20261106')
prior = out.parent / 'replay-chunk-staging-20261106'
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
write = lambda p, x: p.write_text(json.dumps(x, indent=2) + '\n', encoding='utf-8')
assert read(root / 'measurement.json')['status'] == 'complete'
out.mkdir(exist_ok=True)
for name in ['candidate.patch', 'fixture-sha256.json', 'METHOD-BEFORE.json', 'METHOD.json', 'measurement.json', 'reclaim-frames.json']:
    shutil.copyfile(root / name, out / name)
source = read(root / 'source-verification.json')
source['patch_sha256'] = {'candidate.patch': source['patch_sha256']}
write(out / 'source-verification.json', source)
for name in ['prepare.py', '.gitattributes']:
    shutil.copyfile(prior / name, out / name)
layout = (root / 'owner-layout.txt').read_text()
owners = []
for line in layout.splitlines():
    m = re.match(r'print-type-size type: `(.*)`: (\d+) bytes, alignment: (\d+) bytes', line)
    if m:
        owners.append({'type': m[1], 'bytes': int(m[2]), 'alignment': int(m[3]), 'fields': []})
    else:
        m = re.match(r'print-type-size     field `(.*)`: (\d+) bytes', line)
        if m and owners:
            owners[-1]['fields'].append({'name': m[1], 'bytes': int(m[2])})
write(root / 'owners.json', owners)
write(out / 'owners.json', owners)
memory = read(prior / 'memory-comparison.json')
actual = {'SmallDevice App': 14880, 'Service fixed App': 314824,
          'Service allocated App': 35648, 'Service allocated pool heap': 281680}
for row in memory['rows']:
    row['candidate'] = actual.get(row['owner'], row['baseline'])
for record in memory['layout_records']:
    if 'baseline-future-layout.txt' not in record['file']:
        prefix = record['record'].split('`: ')[0] + '`: '
        record['record'] = next(line for line in layout.splitlines() if line.startswith(prefix))
        record['file'] = str(root / 'owner-layout.txt')
memory['candidate_layout_sha256'] = hashlib.sha256((root / 'owner-layout.txt').read_bytes()).hexdigest()
memory['warning'] = memory['warning'].split(' Allocator metadata/rounding')[0] + ' Requested heap excludes allocator metadata and rounding. Startup allocation count matches baseline; no separate deadline allocation.'
write(root / 'memory-comparison.json', memory)
write(out / 'memory-comparison.json', memory)

def archive(name, files, relative):
    hashes = {}
    with zipfile.ZipFile(out / (name + '.zip'), 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(set(files)):
            member = relative(p)
            data = p.read_bytes()
            hashes[member] = hashlib.sha256(data).hexdigest()
            z.writestr(member, data)
    write(out / ({'observations': 'observation', 'diagnostics': 'diagnostic'}.get(name, name) + '-sha256.json'), hashes)

files = [p for pat in ['measure-*.json', 'measure-*.stderr', 'qualify-*.json', 'qualify-*.stderr'] for p in root.glob(pat)]
files += [root / n for n in ['METHOD.json', 'METHOD-BEFORE.json', 'measurement.json', 'measure.py', 'source-verification.json', 'fixture-sha256.json', 'owner-layout.txt', 'owners.json', 'memory-comparison.json', 'process-exits.jsonl']]
files += list((root / 'B').glob('*'))
archive('observations', files, lambda p: 'candidate/' + p.relative_to(root).as_posix())
files = [p for p in root.iterdir() if p.is_file() and (p.suffix in ['.asm', '.log', '.py'] or p.name in ['encoder-frames.json', 'candidate-encoder-symbols.txt', 'build-results.json', 'review.txt', 'preflight-host.json', 'reclaim-frames.json', 'reclaim-symbols.txt', 'baseline-reclaim-symbols.txt', 'inline-replay-symbols.txt', 'inline-replay.json'])]
archive('diagnostics', files, lambda p: p.name)
archive('layout32', [p for p in (root / 'layout32').iterdir() if p.is_file()], lambda p: p.name)
layout32 = read(prior / 'layout32-comparison.json')
layout32['candidate'] = source['source']
for row in layout32['rows']:
    prefix = row['baseline_record'].split('`: ')[0] + '`: '
    row['candidate_record'] = next(line for line in (root / 'layout32/candidate-layout.txt').read_text().splitlines() if line.startswith(prefix))
    row['candidate'] = int(row['candidate_record'].split('`: ')[1].split(' ')[0])
layout32['memory_nongrowth'] = all(r['candidate'] <= r['baseline'] for r in layout32['rows'])
assert layout32['memory_nongrowth']
write(out / 'layout32-comparison.json', layout32)
v = (prior / 'verify.py').read_text()
start = v.index('        if kind == "ordinary":')
end = v.index('        count = 8192', start)
v = v[:start] + '        if kind == "ordinary":\n            expected = dict(a["memory"])\n            if profile == "small-device":\n                expected["app_including_transport_inline_bytes"] -= 56\n            else:\n                if profile == "service-fixed":\n                    expected["server_app_including_transport_inline_bytes"] -= 832\n                else:\n                    expected["server_app_including_transport_inline_bytes"] -= 24\n                    expected["server_pool_requested_heap_bytes"] -= 832\n                expected["client_app_including_transport_inline_bytes"] -= 24\n                expected["client_pool_requested_heap_bytes"] -= 104\n            assert b["memory"] == expected, (cell, "memory")\n        else:\n            assert b["app_inline_bytes"] == a["app_inline_bytes"] - (208 if profile == "fixed" else 24)\n' + v[end:]
v = v.replace('== layout32["memory_nongrowth"] == False', '== layout32["memory_nongrowth"] == True')
v = v.replace('== [16, 256, 0, -8, 16, 256]', '== [-24, -320, -16, -8, -24, -320]')
v = v.replace('32-bit layout regression verified; this integration is rejected independently of the CPU result', '32-bit selected object nongrowth verified; no target runtime claim')
(out / 'verify.py').write_text(v)
print(json.dumps({'output': str(out), 'bytes': sum(p.stat().st_size for p in out.iterdir() if p.is_file())}))

with (out/'verify.py').open('a') as f:
    f.write("\nwith zipfile.ZipFile(ROOT / 'diagnostics.zip') as archive:\n    reclaim = json.loads(archive.read('reclaim-frames.json'))\n    assert reclaim == json.loads((ROOT/'reclaim-frames.json').read_text())\n    assert reclaim['nongrowth'] and len(reclaim['rows']) == 4\n    for row in reclaim['rows']:\n        assert row['candidate'] == 544 and row['candidate'] <= row['baseline']\n        assert hashlib.sha256(archive.read(row['assembly'])).hexdigest() == row['sha256']\nprint('Selected reclaim frames nongrowing; not peak-stack evidence')\n")

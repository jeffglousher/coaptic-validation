import json,os,sys,time,subprocess,datetime,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SUITE=Path(r'D:/codex-work/coaptic-validation')
PY=Path(sys.executable)
BUDGET=32*1024*1024
ENV=dict(os.environ,RUSTUP_TOOLCHAIN='1.99.0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_RELEASE_DEBUG='0')
def size():
 return sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())
def check_budget():
 n=size()
 if n>30*1024*1024: raise RuntimeError(f'evidence reserve reached: {n}; stop and inspect')
 if shutil.disk_usage('D:/').free<4*1024**3: raise RuntimeError('D free below4GiB; stop before next task')
 return n
def run(label,args,cwd=SUITE):
 check_budget()
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 print('START '+label,flush=True)
 with (ROOT/'execution.log').open('a',encoding='utf-8') as log:
  log.write(json.dumps({'task':label,'argv':[str(v) for v in args],'cwd':str(cwd),'started':started})+'\n');log.flush()
  child=subprocess.Popen([str(v) for v in args],cwd=cwd,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace')
  try:
   for line in child.stdout:
    log.write(line);log.flush()
    if line.startswith('saved '):
     (ROOT/'progress.json').write_text(json.dumps({'task':label,'latest':line.strip(),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bytes':check_budget()})+'\n')
    elif 'error:' in line.lower() or line.startswith('Traceback'): print(line.strip(),flush=True)
   result=child.wait()
  except BaseException:
   child.terminate();child.wait(timeout=10);raise
  log.write(json.dumps({'task':label,'exit':result,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n');log.flush()
 if result: raise RuntimeError(f'{label} exited{result}; inspect execution.log')
 print('DONE '+label,flush=True)
 if size()>BUDGET: raise RuntimeError('evidence budget exceeded')
def prepare():
 wrapper=[r'C:/Users/jeffg/.cargo/bin/agent-resources.exe','run','--id','coaptic-core-reusable','--directory',SUITE,'--']
 common=[PY,'tools/benchmark/prepare.py','--build-root',r'D:/coaptic-batch-interop-target','--python',PY]
 run('prepare-native',wrapper+common+['--go',r'D:/coaptic-tools/benchmark-go-1.26.0/go/bin/go.exe','--cmake',r'D:/coaptic-tools/python/cmake/data/bin/cmake.exe','--libcoap-source',r'D:/coaptic-tools/libcoap-4.3.5b','--libcoap-build',r'D:/coaptic-batch-interop-target/benchmark-libcoap','--peers','coaptic,coaptic-reusable,coap-rs,coap-lite-codec,aiocoap,libcoap,go-coap,http3','--output',ROOT/'native-prepared.json'])
 run('prepare-matched',wrapper+common+['--matched-oscore','--peers','coaptic,coaptic-reusable,aiocoap','--output',ROOT/'matched-manifest.json'])
 native=json.loads((ROOT/'native-prepared.json').read_text())
 for name,protocol in [('native','coap'),('http3','http3')]:
  subset=dict(native,peers=[p for p in native['peers'] if p['protocol']==protocol],cases=[c for c in native['cases'] if c['protocol']==protocol])
  subset['scope']+='; explicit '+name+' stratum'
  (ROOT/(name+'-manifest.json')).write_text(json.dumps(subset,indent=2)+'\n')
 for name in ['native','matched','http3']:
  run('plan-'+name,[PY,'tools/benchmark/campaign.py','plan','--manifest',ROOT/(name+'-manifest.json'),'--output',ROOT/name,'--windows','5','--seed','20261021'])
 run('native-security-check',[PY,'tools/benchmark/native_check.py','--server',r'D:/coaptic-batch-interop-target/release/bench-rust-server.exe','--client',r'D:/coaptic-batch-interop-target/release/bench-native-client.exe'])
def campaigns():
 for window in range(5):
  for name in ['native','matched','http3']:
   path=ROOT/name
   prior=list(path.glob('window-*.json'))
   if prior:
    latest=max(datetime.datetime.fromisoformat(json.loads(p.read_text())['finished']).timestamp() for p in prior)
    gap=60-(time.time()-latest)
    if gap>0:
     print(f'Session gap {name}: {gap:.1f}s',flush=True)
     time.sleep(min(gap+.05,60))
   run(f'{name}-window-{window}',[PY,'tools/benchmark/campaign.py','run','--campaign',path,'--window',str(window)])
 for name in ['native','matched','http3']:
  ref='http3' if name=='http3' else 'coaptic'
  run('analyze-'+name,[PY,'tools/benchmark/campaign.py','analyze','--campaign',ROOT/name,'--reference',ref,'--output',ROOT/(name+'-report.json')])
 run('small-device',[PY,'tools/benchmark/small_device_quick.py','--server',r'D:/coaptic-batch-interop-target/release/bench-rust-server.exe','--output',ROOT/'small-device.json'])
 print('ALL BENCHMARKS COMPLETE',flush=True)
if __name__=='__main__':
 if sys.argv[1]=='prepare': prepare()
 elif sys.argv[1]=='run': campaigns()
 else: raise ValueError('expected prepare or run')

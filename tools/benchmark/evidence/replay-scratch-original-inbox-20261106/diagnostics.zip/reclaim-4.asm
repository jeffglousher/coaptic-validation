
D:\CoapticCurrent\replay-scratch-original-inbox-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009e7f0:     	pushq	%rbp
14009e7f1:     	pushq	%r15
14009e7f3:     	pushq	%r14
14009e7f5:     	pushq	%r13
14009e7f7:     	pushq	%r12
14009e7f9:     	pushq	%rsi
14009e7fa:     	pushq	%rdi
14009e7fb:     	pushq	%rbx
14009e7fc:     	subq	$0x218, %rsp            # imm = 0x218
14009e803:     	leaq	0x80(%rsp), %rbp
14009e80b:     	movaps	%xmm6, 0x180(%rbp)
14009e812:     	movq	0xe8(%rcx), %r8
14009e819:     	testq	%r8, %r8
14009e81c:     	je	0x14009eb09 <.text+0x9db09>
14009e822:     	leaq	0xc0(%rcx), %r13
14009e829:     	leaq	0xd8(%rcx), %rdi
14009e830:     	movq	0xc8(%rcx), %rbx
14009e837:     	movq	0xd0(%rcx), %r10
14009e83e:     	leaq	0x28(%rbx), %rax
14009e842:     	xorl	%r11d, %r11d
14009e845:     	xorl	%r15d, %r15d
14009e848:     	imulq	$0x130, %r15, %r12      # imm = 0x130
14009e84f:     	addq	%rax, %r12
14009e852:     	jmp	0x14009e86f <.text+0x9d86f>
14009e854:     	nopw	%cs:(%rax,%rax)
14009e860:     	incq	%r15
14009e863:     	addq	$0x130, %r12            # imm = 0x130
14009e86a:     	cmpq	%r8, %r15
14009e86d:     	jae	0x14009e8da <.text+0x9d8da>
14009e86f:     	cmpq	%r10, %r15
14009e872:     	jae	0x14009e860 <.text+0x9d860>
14009e874:     	cmpb	$0x2, -0xe(%r12)
14009e87a:     	je	0x14009e860 <.text+0x9d860>
14009e87c:     	movq	%r13, %rdi
14009e87f:     	movq	-0x8(%r12), %r13
14009e884:     	cmpb	$0x3, (%r12)
14009e889:     	setne	%r12b
14009e88d:     	testq	%r13, %r13
14009e890:     	sete	%sil
14009e894:     	orb	%r12b, %sil
14009e897:     	cmpq	%r14, %r13
14009e89a:     	setae	%r12b
14009e89e:     	andb	%r11b, %r12b
14009e8a1:     	testb	%sil, %sil
14009e8a4:     	movq	%r14, %rdx
14009e8a7:     	movq	%rax, %r14
14009e8aa:     	movl	$0x1, %eax
14009e8af:     	cmoveq	%rax, %r11
14009e8b3:     	movq	%r14, %rax
14009e8b6:     	movq	%rdx, %r14
14009e8b9:     	orb	%sil, %r12b
14009e8bc:     	cmoveq	%r15, %r9
14009e8c0:     	cmoveq	%r13, %r14
14009e8c4:     	movq	%rdi, %r13
14009e8c7:     	leaq	0xd8(%rcx), %rdi
14009e8ce:     	incq	%r15
14009e8d1:     	cmpq	%r8, %r15
14009e8d4:     	jb	0x14009e848 <.text+0x9d848>
14009e8da:     	xorl	%eax, %eax
14009e8dc:     	cmpq	$0x1, %r11
14009e8e0:     	jne	0x14009eb0b <.text+0x9db0b>
14009e8e6:     	cmpq	%r10, %r9
14009e8e9:     	jae	0x14009eb0b <.text+0x9db0b>
14009e8ef:     	imulq	$0x130, %r9, %rax       # imm = 0x130
14009e8f6:     	movzbl	0x1a(%rbx,%rax), %r15d
14009e8fc:     	cmpb	$0x2, %r15b
14009e900:     	je	0x14009eb09 <.text+0x9db09>
14009e906:     	addq	%rax, %rbx
14009e909:     	cmpb	$0x3, 0x28(%rbx)
14009e90d:     	jne	0x14009eb09 <.text+0x9db09>
14009e913:     	movq	0x30(%rbx), %r10
14009e917:     	movups	(%rbx), %xmm0
14009e91a:     	movups	0xa(%rbx), %xmm1
14009e91e:     	movups	%xmm1, 0x11a(%rbp)
14009e925:     	movaps	%xmm0, 0x110(%rbp)
14009e92c:     	movzbl	0x1b(%rbx), %r12d
14009e931:     	movss	0x1c(%rbx), %xmm6
14009e936:     	movzwl	0x1c(%rbx), %eax
14009e93a:     	cmpq	0x88(%rcx), %r10
14009e941:     	jae	0x14009e997 <.text+0x9d997>
14009e943:     	movq	0x80(%rcx), %r11
14009e94a:     	cmpb	$0x1, (%r11,%r10)
14009e94f:     	jne	0x14009e997 <.text+0x9d997>
14009e951:     	cmpq	0xa0(%rcx), %r10
14009e958:     	jae	0x14009e968 <.text+0x9d968>
14009e95a:     	movq	0x98(%rcx), %rsi
14009e961:     	cmpb	$0x0, (%rsi,%r10)
14009e966:     	jne	0x14009e997 <.text+0x9d997>
14009e968:     	movb	$0x0, (%r11,%r10)
14009e96d:     	decq	0xb0(%rcx)
14009e974:     	cmpq	0x70(%rcx), %r10
14009e978:     	jae	0x14009e997 <.text+0x9d997>
14009e97a:     	movq	0x68(%rcx), %r11
14009e97e:     	imulq	$0x58, %r10, %r10
14009e982:     	movq	$0x0, 0x30(%r11,%r10)
14009e98b:     	movb	$0x2, 0x52(%r11,%r10)
14009e991:     	movb	$0x2, 0x25(%r11,%r10)
14009e997:     	cmpq	%r8, %r9
14009e99a:     	jae	0x14009e9bd <.text+0x9d9bd>
14009e99c:     	movq	0xe0(%rcx), %r8
14009e9a3:     	cmpl	$0x0, (%r8,%r9,4)
14009e9a8:     	je	0x14009e9bd <.text+0x9d9bd>
14009e9aa:     	movl	$0x0, (%r8,%r9,4)
14009e9b2:     	decq	0xf8(%rcx)
14009e9b9:     	movb	$0x2, 0x1a(%rbx)
14009e9bd:     	xorps	%xmm0, %xmm0
14009e9c0:     	movaps	%xmm0, 0x170(%rbp)
14009e9c7:     	movb	$0x0, 0x152(%rbp)
14009e9ce:     	movw	%ax, 0x150(%rbp)
14009e9d5:     	leaq	0x153(%rbp), %rcx
14009e9dc:     	movw	$0x200, 0x15b(%rbp)     # imm = 0x200
14009e9e5:     	movq	$0x0, 0x153(%rbp)
14009e9f0:     	movq	$0x8, 0x130(%rbp)
14009e9fb:     	movq	$0x0, 0x138(%rbp)
14009ea06:     	movq	$0x1, 0x140(%rbp)
14009ea11:     	movq	$0x0, 0x148(%rbp)
14009ea1c:     	movq	%rcx, 0x30(%rsp)
14009ea21:     	movw	%ax, 0x28(%rsp)
14009ea26:     	movq	$0x0, 0x58(%rsp)
14009ea2f:     	movq	$0x1, 0x50(%rsp)
14009ea38:     	movq	$0x8, 0x48(%rsp)
14009ea41:     	movq	$0x8, 0x40(%rsp)
14009ea4a:     	movq	$0x0, 0x38(%rsp)
14009ea53:     	movb	$0x0, 0x20(%rsp)
14009ea58:     	leaq	0x160(%rbp), %rcx
14009ea5f:     	leaq	0x170(%rbp), %rdx
14009ea66:     	movl	$0x10, %r8d
14009ea6c:     	movb	$0x2, %r9b
14009ea6f:     	callq	0x140005590 <.text+0x4590>
14009ea74:     	movq	0x168(%rbp), %rbx
14009ea7b:     	cmpq	$0x11, %rbx
14009ea7f:     	setae	%al
14009ea82:     	orb	0x160(%rbp), %al
14009ea88:     	jne	0x14009eb36 <.text+0x9db36>
14009ea8e:     	movq	%rdi, %rcx
14009ea91:     	callq	0x140219d40 <.text+0x218d40>
14009ea96:     	cmpq	$0x1, %rax
14009ea9a:     	jne	0x14009eb36 <.text+0x9db36>
14009eaa0:     	movups	0x11a(%rbp), %xmm0
14009eaa7:     	movups	%xmm0, -0x16(%rbp)
14009eaab:     	movaps	0x110(%rbp), %xmm0
14009eab2:     	movaps	%xmm0, -0x20(%rbp)
14009eab6:     	movb	%r15b, -0x6(%rbp)
14009eaba:     	movb	%r12b, -0x5(%rbp)
14009eabe:     	movss	%xmm6, -0x4(%rbp)
14009eac3:     	movq	%r14, (%rbp)
14009eac7:     	testq	%rbx, %rbx
14009eaca:     	je	0x14009eb26 <.text+0x9db26>
14009eacc:     	movb	$0x1, 0x8(%rbp)
14009ead0:     	movb	%bl, 0x9(%rbp)
14009ead3:     	leaq	0xa(%rbp), %rdi
14009ead7:     	movl	$0x80, %r8d
14009eadd:     	subq	%rbx, %r8
14009eae0:     	leaq	(%rbx,%rbp), %rcx
14009eae4:     	addq	$0xa, %rcx
14009eae8:     	movq	%rdx, %r14
14009eaeb:     	xorl	%edx, %edx
14009eaed:     	callq	0x140251e22 <.text+0x250e22>
14009eaf2:     	leaq	0x170(%rbp), %rdx
14009eaf9:     	movq	%rdi, %rcx
14009eafc:     	movq	%rbx, %r8
14009eaff:     	callq	0x140251e10 <.text+0x250e10>
14009eb04:     	movq	%r14, %rdx
14009eb07:     	jmp	0x14009eb2a <.text+0x9db2a>
14009eb09:     	xorl	%eax, %eax
14009eb0b:     	movaps	0x180(%rbp), %xmm6
14009eb12:     	addq	$0x218, %rsp            # imm = 0x218
14009eb19:     	popq	%rbx
14009eb1a:     	popq	%rdi
14009eb1b:     	popq	%rsi
14009eb1c:     	popq	%r12
14009eb1e:     	popq	%r13
14009eb20:     	popq	%r14
14009eb22:     	popq	%r15
14009eb24:     	popq	%rbp
14009eb25:     	retq
14009eb26:     	movb	$0x0, 0x8(%rbp)
14009eb2a:     	leaq	-0x20(%rbp), %r8
14009eb2e:     	movq	%r13, %rcx
14009eb31:     	callq	0x14000b620 <.text+0xa620>
14009eb36:     	movb	$0x1, %al
14009eb38:     	jmp	0x14009eb0b <.text+0x9db0b>

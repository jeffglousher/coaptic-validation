from pathlib import Path
import subprocess, re, json, hashlib
r=Path(__file__).resolve().parent
p=subprocess.Popen(['llvm-pdbutil','dump','--symbols',str(r/'B/dispatch-probe.pdb')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace')
lines=[];keep=0
for line in p.stdout:
    if ('S_GPROC32' in line or 'S_LPROC32' in line) and 'evict_one_dedup_pin<' in line:keep=7
    if keep:lines.append(line);keep-=1
assert p.wait()==0
s=''.join(lines);(r/'reclaim-symbols.txt').write_text(s)
records=[]
for i,chunk in enumerate(re.split(r'(?m)(?=^\s*\d+ \| S_LPROC32)',s)):
    m=re.search(r'addr = 0001:(\d+), code size = (\d+)',chunk)
    if not m:continue
    start=0x140001000+int(m[1]);cmd=['llvm-objdump','-d','--no-show-raw-insn',f'--start-address={hex(start)}',f'--stop-address={hex(start+int(m[2]))}',str(r/'B/dispatch-probe.exe')]
    data=subprocess.check_output(cmd);name=f'reclaim-{i}.asm';(r/name).write_bytes(data)
    baseline=784 if 'profiles::Service' in chunk else 800
    row={'symbol':chunk.splitlines()[0],'baseline':baseline,'candidate':int(re.search(r'\n +size = (\d+)',chunk)[1]),'code_bytes':int(m[2]),'assembly':name,'command':cmd,'sha256':hashlib.sha256(data).hexdigest()}
    records.append(row)
assert len(records)==4
x={'rows':records,'nongrowth':all(v['candidate']<=v['baseline'] for v in records),'baseline':'bd63199b652193b4c0a882e5840e72d992cf1362','candidate':'ecf1747849fdd5f95224ff58995cbb4ef6d38f59','scope':'Selected compiler frame reservations, not peak stack'}
(r/'reclaim-frames.json').write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps(x,indent=2))
assert x['nongrowth']

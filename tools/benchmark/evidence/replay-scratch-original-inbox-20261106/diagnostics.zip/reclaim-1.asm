
D:\CoapticCurrent\replay-scratch-original-inbox-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009d2a0:     	pushq	%rbp
14009d2a1:     	pushq	%r15
14009d2a3:     	pushq	%r14
14009d2a5:     	pushq	%r13
14009d2a7:     	pushq	%r12
14009d2a9:     	pushq	%rsi
14009d2aa:     	pushq	%rdi
14009d2ab:     	pushq	%rbx
14009d2ac:     	subq	$0x218, %rsp            # imm = 0x218
14009d2b3:     	leaq	0x80(%rsp), %rbp
14009d2bb:     	movaps	%xmm6, 0x180(%rbp)
14009d2c2:     	leaq	0x1970(%rcx), %rsi
14009d2c9:     	leaq	0x1998(%rcx), %r8
14009d2d0:     	movl	$0x4, %r11d
14009d2d6:     	xorl	%eax, %eax
14009d2d8:     	movl	$0x1, %r9d
14009d2de:     	xorl	%r10d, %r10d
14009d2e1:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009d2e8:     	addq	%r8, %rdi
14009d2eb:     	nopl	(%rax,%rax)
14009d2f0:     	cmpb	$0x2, -0xe(%rdi)
14009d2f4:     	jne	0x14009d310 <.text+0x9c310>
14009d2f6:     	incq	%r10
14009d2f9:     	addq	$0x130, %rdi            # imm = 0x130
14009d300:     	cmpq	%r10, %r11
14009d303:     	jne	0x14009d2f0 <.text+0x9c2f0>
14009d305:     	jmp	0x14009d355 <.text+0x9c355>
14009d307:     	nopw	(%rax,%rax)
14009d310:     	movq	-0x8(%rdi), %r11
14009d314:     	cmpb	$0x3, (%rdi)
14009d317:     	setne	%bl
14009d31a:     	testq	%r11, %r11
14009d31d:     	sete	%dil
14009d321:     	orb	%bl, %dil
14009d324:     	cmpq	%r14, %r11
14009d327:     	setae	%bl
14009d32a:     	andb	%al, %bl
14009d32c:     	testb	%dil, %dil
14009d32f:     	cmoveq	%r9, %rax
14009d333:     	orb	%dil, %bl
14009d336:     	cmoveq	%r10, %rdx
14009d33a:     	cmoveq	%r11, %r14
14009d33e:     	incq	%r10
14009d341:     	cmpq	$0x5, %r10
14009d345:     	movl	$0x4, %r11d
14009d34b:     	cmovaeq	%r10, %r11
14009d34f:     	cmpq	$0x3, %r10
14009d353:     	jbe	0x14009d2e1 <.text+0x9c2e1>
14009d355:     	testb	$0x1, %al
14009d357:     	je	0x14009d451 <.text+0x9c451>
14009d35d:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009d364:     	movzbl	0x1a(%rsi,%rax), %r15d
14009d36a:     	cmpb	$0x2, %r15b
14009d36e:     	je	0x14009d451 <.text+0x9c451>
14009d374:     	addq	%rsi, %rax
14009d377:     	cmpb	$0x3, 0x28(%rax)
14009d37b:     	jne	0x14009d451 <.text+0x9c451>
14009d381:     	movq	0x30(%rax), %r8
14009d385:     	movq	(%rax), %rdx
14009d388:     	movq	%rdx, 0x168(%rbp)
14009d38f:     	movq	0x8(%rax), %rdx
14009d393:     	movq	%rdx, 0x170(%rbp)
14009d39a:     	movl	0x10(%rax), %ebx
14009d39d:     	movl	0x14(%rax), %r12d
14009d3a1:     	movzwl	0x18(%rax), %edi
14009d3a5:     	movzbl	0x1b(%rax), %edx
14009d3a9:     	movb	%dl, 0x17f(%rbp)
14009d3af:     	movss	0x1c(%rax), %xmm6
14009d3b4:     	movzwl	0x1c(%rax), %eax
14009d3b8:     	movzwl	%ax, %edx
14009d3bb:     	cmpq	$0x1, %r8
14009d3bf:     	ja	0x14009d41b <.text+0x9c41b>
14009d3c1:     	cmpb	$0x1, 0x1968(%rcx,%r8)
14009d3ca:     	jne	0x14009d41b <.text+0x9c41b>
14009d3cc:     	cmpb	$0x0, 0x196a(%rcx,%r8)
14009d3d5:     	jne	0x14009d41b <.text+0x9c41b>
14009d3d7:     	movb	$0x0, 0x1968(%rcx,%r8)
14009d3e0:     	decq	0x1960(%rcx)
14009d3e7:     	leaq	0xfe0(%rcx), %r9
14009d3ee:     	movq	$0x0, 0x18e0(%rcx,%r8,8)
14009d3fa:     	leaq	(%r8,%r8,8), %r10
14009d3fe:     	leaq	(%r10,%r10,2), %r10
14009d402:     	addq	%r8, %r10
14009d405:     	movb	$0x2, 0x95a(%r9,%r10)
14009d40e:     	leaq	(%r8,%r8,2), %r8
14009d412:     	movb	$0x2, 0x91d(%r9,%r8,8)
14009d41b:     	addl	$0x2, %edx
14009d41e:     	movb	$0x1, %r9b
14009d421:     	cmpl	%edx, 0x1e30(%rcx)
14009d427:     	jne	0x14009d437 <.text+0x9c437>
14009d429:     	movzbl	0x198a(%rcx), %r8d
14009d431:     	cmpb	$0x2, %r8b
14009d435:     	jne	0x14009d46e <.text+0x9c46e>
14009d437:     	xorl	%r8d, %r8d
14009d43a:     	cmpl	%edx, 0x1e34(%rcx)
14009d440:     	movl	%ebx, 0x178(%rbp)
14009d446:     	jne	0x14009d4fd <.text+0x9c4fd>
14009d44c:     	jmp	0x14009d4eb <.text+0x9c4eb>
14009d451:     	xorl	%eax, %eax
14009d453:     	movaps	0x180(%rbp), %xmm6
14009d45a:     	addq	$0x218, %rsp            # imm = 0x218
14009d461:     	popq	%rbx
14009d462:     	popq	%rdi
14009d463:     	popq	%rsi
14009d464:     	popq	%r12
14009d466:     	popq	%r13
14009d468:     	popq	%r14
14009d46a:     	popq	%r15
14009d46c:     	popq	%rbp
14009d46d:     	retq
14009d46e:     	cmpw	%ax, 0x198c(%rcx)
14009d475:     	sete	%r9b
14009d479:     	cmpl	%ebx, 0x1980(%rcx)
14009d47f:     	sete	%r10b
14009d483:     	andb	%r9b, %r10b
14009d486:     	cmpl	%r12d, 0x1984(%rcx)
14009d48d:     	sete	%r9b
14009d491:     	cmpw	%di, 0x1988(%rcx)
14009d498:     	sete	%r11b
14009d49c:     	andb	%r9b, %r11b
14009d49f:     	andb	%r10b, %r11b
14009d4a2:     	cmpb	%r15b, %r8b
14009d4a5:     	sete	%r8b
14009d4a9:     	movq	0x1978(%rcx), %r9
14009d4b0:     	xorq	0x170(%rbp), %r9
14009d4b7:     	movq	0x1970(%rcx), %r10
14009d4be:     	xorq	0x168(%rbp), %r10
14009d4c5:     	orq	%r9, %r10
14009d4c8:     	sete	%r9b
14009d4cc:     	andb	%r8b, %r9b
14009d4cf:     	andb	%r11b, %r9b
14009d4d2:     	movzbl	%r9b, %r8d
14009d4d6:     	movl	%r8d, %r9d
14009d4d9:     	xorb	$0x1, %r9b
14009d4dd:     	cmpl	%edx, 0x1e34(%rcx)
14009d4e3:     	movl	%ebx, 0x178(%rbp)
14009d4e9:     	jne	0x14009d4fd <.text+0x9c4fd>
14009d4eb:     	movzbl	0x1aba(%rcx), %r10d
14009d4f3:     	cmpb	$0x2, %r10b
14009d4f7:     	jne	0x14009d5ae <.text+0x9c5ae>
14009d4fd:     	xorl	%r9d, %r9d
14009d500:     	cmpl	%edx, 0x1e38(%rcx)
14009d506:     	jne	0x14009d654 <.text+0x9c654>
14009d50c:     	movzbl	0x1bea(%rcx), %r10d
14009d514:     	cmpb	$0x2, %r10b
14009d518:     	je	0x14009d654 <.text+0x9c654>
14009d51e:     	cmpb	%r15b, %r10b
14009d521:     	jne	0x14009d654 <.text+0x9c654>
14009d527:     	cmpw	%ax, 0x1bec(%rcx)
14009d52e:     	jne	0x14009d654 <.text+0x9c654>
14009d534:     	cmpl	%ebx, 0x1be0(%rcx)
14009d53a:     	jne	0x14009d654 <.text+0x9c654>
14009d540:     	cmpl	%r12d, 0x1be4(%rcx)
14009d547:     	jne	0x14009d654 <.text+0x9c654>
14009d54d:     	cmpw	%di, 0x1be8(%rcx)
14009d554:     	jne	0x14009d654 <.text+0x9c654>
14009d55a:     	movq	0x1bd0(%rcx), %r10
14009d561:     	xorq	0x168(%rbp), %r10
14009d568:     	movq	0x1bd8(%rcx), %r11
14009d56f:     	xorq	0x170(%rbp), %r11
14009d576:     	orq	%r10, %r11
14009d579:     	jne	0x14009d654 <.text+0x9c654>
14009d57f:     	movl	%r12d, %r13d
14009d582:     	movl	%edi, %r12d
14009d585:     	movb	$0x1, %dil
14009d588:     	testq	%r8, %r8
14009d58b:     	jne	0x14009d6e0 <.text+0x9c6e0>
14009d591:     	movl	$0x1, %r8d
14009d597:     	movl	$0x2, %r9d
14009d59d:     	movl	%r12d, %edi
14009d5a0:     	movl	%r13d, %r12d
14009d5a3:     	movl	0x178(%rbp), %ebx
14009d5a9:     	jmp	0x14009d654 <.text+0x9c654>
14009d5ae:     	cmpw	%ax, 0x1abc(%rcx)
14009d5b5:     	setne	%r11b
14009d5b9:     	cmpl	%ebx, 0x1ab0(%rcx)
14009d5bf:     	setne	%bl
14009d5c2:     	orb	%r11b, %bl
14009d5c5:     	movl	%r12d, %r13d
14009d5c8:     	cmpl	%r12d, 0x1ab4(%rcx)
14009d5cf:     	setne	%r11b
14009d5d3:     	movl	%edi, %r12d
14009d5d6:     	cmpw	%di, 0x1ab8(%rcx)
14009d5dd:     	setne	%dil
14009d5e1:     	orb	%r11b, %dil
14009d5e4:     	orb	%bl, %dil
14009d5e7:     	cmpb	%r15b, %r10b
14009d5ea:     	setne	%r11b
14009d5ee:     	movq	0x1aa8(%rcx), %r10
14009d5f5:     	xorq	0x170(%rbp), %r10
14009d5fc:     	movq	0x1aa0(%rcx), %rbx
14009d603:     	xorq	0x168(%rbp), %rbx
14009d60a:     	orq	%r10, %rbx
14009d60d:     	setne	%r10b
14009d611:     	orb	%r11b, %r10b
14009d614:     	orb	%dil, %r10b
14009d617:     	orb	%r10b, %r9b
14009d61a:     	testb	%r10b, %r10b
14009d61d:     	movl	$0x1, %r11d
14009d623:     	cmoveq	%r11, %r8
14009d627:     	testb	$0x1, %r9b
14009d62b:     	je	0x14009d6da <.text+0x9c6da>
14009d631:     	notb	%r10b
14009d634:     	movzbl	%r10b, %r9d
14009d638:     	andl	$0x1, %r9d
14009d63c:     	movl	%r12d, %edi
14009d63f:     	movl	%r13d, %r12d
14009d642:     	movl	0x178(%rbp), %ebx
14009d648:     	cmpl	%edx, 0x1e38(%rcx)
14009d64e:     	je	0x14009d50c <.text+0x9c50c>
14009d654:     	cmpl	%edx, 0x1e3c(%rcx)
14009d65a:     	jne	0x14009d668 <.text+0x9c668>
14009d65c:     	movzbl	0x1d1a(%rcx), %edx
14009d663:     	cmpb	$0x2, %dl
14009d666:     	jne	0x14009d67a <.text+0x9c67a>
14009d668:     	movl	%r12d, %r13d
14009d66b:     	movl	%edi, %r12d
14009d66e:     	xorl	%edi, %edi
14009d670:     	testq	%r8, %r8
14009d673:     	jne	0x14009d6e0 <.text+0x9c6e0>
14009d675:     	jmp	0x14009d70a <.text+0x9c70a>
14009d67a:     	cmpb	%r15b, %dl
14009d67d:     	jne	0x14009d668 <.text+0x9c668>
14009d67f:     	cmpw	%ax, 0x1d1c(%rcx)
14009d686:     	jne	0x14009d668 <.text+0x9c668>
14009d688:     	cmpl	%ebx, 0x1d10(%rcx)
14009d68e:     	jne	0x14009d668 <.text+0x9c668>
14009d690:     	cmpl	%r12d, 0x1d14(%rcx)
14009d697:     	jne	0x14009d668 <.text+0x9c668>
14009d699:     	cmpw	%di, 0x1d18(%rcx)
14009d6a0:     	jne	0x14009d668 <.text+0x9c668>
14009d6a2:     	movq	0x1d00(%rcx), %rdx
14009d6a9:     	xorq	0x168(%rbp), %rdx
14009d6b0:     	movq	0x1d08(%rcx), %r10
14009d6b7:     	xorq	0x170(%rbp), %r10
14009d6be:     	orq	%rdx, %r10
14009d6c1:     	jne	0x14009d668 <.text+0x9c668>
14009d6c3:     	movl	%r12d, %r13d
14009d6c6:     	movl	%edi, %r12d
14009d6c9:     	testq	%r8, %r8
14009d6cc:     	movl	$0x3, %edx
14009d6d1:     	cmoveq	%rdx, %r9
14009d6d5:     	movl	%r8d, %edi
14009d6d8:     	jmp	0x14009d6e0 <.text+0x9c6e0>
14009d6da:     	movb	$0x1, %dil
14009d6dd:     	xorl	%r9d, %r9d
14009d6e0:     	cmpl	$0x0, 0x1e30(%rcx,%r9,4)
14009d6e9:     	je	0x14009d70a <.text+0x9c70a>
14009d6eb:     	movl	$0x0, 0x1e30(%rcx,%r9,4)
14009d6f7:     	decq	0x1e48(%rcx)
14009d6fe:     	imulq	$0x130, %r9, %rdx       # imm = 0x130
14009d705:     	movb	$0x2, 0x1a(%rsi,%rdx)
14009d70a:     	xorps	%xmm0, %xmm0
14009d70d:     	movaps	%xmm0, 0x150(%rbp)
14009d714:     	movb	$0x0, 0x132(%rbp)
14009d71b:     	movw	%ax, 0x130(%rbp)
14009d722:     	leaq	0x133(%rbp), %rdx
14009d729:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009d732:     	movq	$0x0, 0x133(%rbp)
14009d73d:     	movq	$0x8, 0x110(%rbp)
14009d748:     	movq	$0x0, 0x118(%rbp)
14009d753:     	movq	$0x1, 0x120(%rbp)
14009d75e:     	movq	$0x0, 0x128(%rbp)
14009d769:     	movq	%rdx, 0x30(%rsp)
14009d76e:     	movw	%ax, 0x28(%rsp)
14009d773:     	movq	$0x0, 0x58(%rsp)
14009d77c:     	movq	$0x1, 0x50(%rsp)
14009d785:     	movq	$0x8, 0x48(%rsp)
14009d78e:     	movq	$0x8, 0x40(%rsp)
14009d797:     	movq	$0x0, 0x38(%rsp)
14009d7a0:     	movb	$0x0, 0x20(%rsp)
14009d7a5:     	leaq	0x140(%rbp), %rax
14009d7ac:     	leaq	0x150(%rbp), %rdx
14009d7b3:     	movl	$0x10, %r8d
14009d7b9:     	movq	%rcx, %rbx
14009d7bc:     	movq	%rax, %rcx
14009d7bf:     	movb	$0x2, %r9b
14009d7c2:     	callq	0x140005590 <.text+0x4590>
14009d7c7:     	cmpb	$0x0, 0x140(%rbp)
14009d7ce:     	jne	0x14009d7ef <.text+0x9c7ef>
14009d7d0:     	testb	%dil, %dil
14009d7d3:     	jne	0x14009d7ef <.text+0x9c7ef>
14009d7d5:     	movq	%rbx, %rax
14009d7d8:     	movq	0x148(%rbp), %rbx
14009d7df:     	cmpq	$0x10, %rbx
14009d7e3:     	ja	0x14009d7ef <.text+0x9c7ef>
14009d7e5:     	cmpq	$0x4, 0x1e48(%rax)
14009d7ed:     	jne	0x14009d7f6 <.text+0x9c7f6>
14009d7ef:     	movb	$0x1, %al
14009d7f1:     	jmp	0x14009d453 <.text+0x9c453>
14009d7f6:     	movq	0x1e40(%rax), %rdi
14009d7fd:     	cmpq	$0x3, %rdi
14009d801:     	ja	0x14009d9fd <.text+0x9c9fd>
14009d807:     	cmpl	$0x0, 0x1e30(%rax,%rdi,4)
14009d80f:     	je	0x14009d882 <.text+0x9c882>
14009d811:     	leaq	(,%rdi,4), %rdx
14009d819:     	xorl	%ecx, %ecx
14009d81b:     	nopl	(%rax,%rax)
14009d820:     	cmpl	$0x0, 0x1e30(%rax,%rdx)
14009d828:     	je	0x14009d875 <.text+0x9c875>
14009d82a:     	addq	$0x4, %rdx
14009d82e:     	decq	%rcx
14009d831:     	cmpq	$0x10, %rdx
14009d835:     	jne	0x14009d820 <.text+0x9c820>
14009d837:     	testq	%rdi, %rdi
14009d83a:     	je	0x14009d7ef <.text+0x9c7ef>
14009d83c:     	cmpl	$0x0, 0x1e30(%rax)
14009d843:     	je	0x14009d9ec <.text+0x9c9ec>
14009d849:     	cmpq	$0x1, %rdi
14009d84d:     	je	0x14009d7ef <.text+0x9c7ef>
14009d84f:     	cmpl	$0x0, 0x1e34(%rax)
14009d856:     	je	0x14009d9f3 <.text+0x9c9f3>
14009d85c:     	cmpq	$0x2, %rdi
14009d860:     	je	0x14009d7ef <.text+0x9c7ef>
14009d862:     	movl	$0x2, %edi
14009d867:     	cmpl	$0x0, 0x1e38(%rax)
14009d86e:     	je	0x14009d878 <.text+0x9c878>
14009d870:     	jmp	0x14009d7ef <.text+0x9c7ef>
14009d875:     	subq	%rcx, %rdi
14009d878:     	cmpq	$0x4, %rdi
14009d87c:     	jae	0x14009da13 <.text+0x9ca13>
14009d882:     	movl	$0x1, 0x1e30(%rax,%rdi,4)
14009d88d:     	incq	0x1e48(%rax)
14009d894:     	leaq	0x1(%rdi), %rcx
14009d898:     	xorl	%edx, %edx
14009d89a:     	cmpq	$0x4, %rcx
14009d89e:     	cmovneq	%rcx, %rdx
14009d8a2:     	movq	%rdx, 0x1e40(%rax)
14009d8a9:     	movq	0x170(%rbp), %rcx
14009d8b0:     	movq	%rcx, -0x18(%rbp)
14009d8b4:     	movq	0x168(%rbp), %rcx
14009d8bb:     	movq	%rcx, -0x20(%rbp)
14009d8bf:     	movl	0x178(%rbp), %ecx
14009d8c5:     	movl	%ecx, -0x10(%rbp)
14009d8c8:     	movl	%r13d, -0xc(%rbp)
14009d8cc:     	movw	%r12w, -0x8(%rbp)
14009d8d1:     	movb	%r15b, -0x6(%rbp)
14009d8d5:     	movzbl	0x17f(%rbp), %ecx
14009d8dc:     	movb	%cl, -0x5(%rbp)
14009d8df:     	movss	%xmm6, -0x4(%rbp)
14009d8e4:     	movq	%r14, (%rbp)
14009d8e8:     	testq	%rbx, %rbx
14009d8eb:     	je	0x14009d952 <.text+0x9c952>
14009d8ed:     	movb	$0x1, 0x8(%rbp)
14009d8f1:     	movb	%bl, 0x9(%rbp)
14009d8f4:     	leaq	0xa(%rbp), %r14
14009d8f8:     	movl	$0x80, %r8d
14009d8fe:     	subq	%rbx, %r8
14009d901:     	leaq	(%rbx,%rbp), %rcx
14009d905:     	addq	$0xa, %rcx
14009d909:     	movq	%rax, %r15
14009d90c:     	xorl	%edx, %edx
14009d90e:     	callq	0x140251e22 <.text+0x250e22>
14009d913:     	leaq	0x150(%rbp), %rdx
14009d91a:     	movq	%r14, %rcx
14009d91d:     	movq	%rbx, %r8
14009d920:     	callq	0x140251e10 <.text+0x250e10>
14009d925:     	movzwl	-0x4(%rbp), %eax
14009d929:     	addl	$0x2, %eax
14009d92c:     	movl	%eax, 0x1e30(%r15,%rdi,4)
14009d934:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009d93b:     	addq	%rax, %rsi
14009d93e:     	movzbl	0x8(%rbp), %eax
14009d942:     	leaq	0x1d38e7(%rip), %rcx    # 0x140271230
14009d949:     	movslq	(%rcx,%rax,4), %rax
14009d94d:     	addq	%rcx, %rax
14009d950:     	jmpq	*%rax
14009d952:     	movb	$0x0, 0x8(%rbp)
14009d956:     	movzwl	-0x4(%rbp), %ecx
14009d95a:     	addl	$0x2, %ecx
14009d95d:     	movl	%ecx, 0x1e30(%rax,%rdi,4)
14009d964:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009d96b:     	addq	%rax, %rsi
14009d96e:     	movzbl	0x8(%rbp), %eax
14009d972:     	leaq	0x1d38b7(%rip), %rcx    # 0x140271230
14009d979:     	movslq	(%rcx,%rax,4), %rax
14009d97d:     	addq	%rcx, %rax
14009d980:     	jmpq	*%rax
14009d982:     	movaps	-0x20(%rbp), %xmm0
14009d986:     	movaps	-0x10(%rbp), %xmm1
14009d98a:     	movups	%xmm1, 0x10(%rsi)
14009d98e:     	movups	%xmm0, (%rsi)
14009d991:     	movb	$0x0, 0x28(%rsi)
14009d995:     	movq	(%rbp), %rax
14009d999:     	movq	%rax, 0x20(%rsi)
14009d99d:     	jmp	0x14009d7ef <.text+0x9c7ef>
14009d9a2:     	leaq	-0x20(%rbp), %rdx
14009d9a6:     	movl	$0x130, %r8d            # imm = 0x130
14009d9ac:     	movq	%rsi, %rcx
14009d9af:     	callq	0x140251e10 <.text+0x250e10>
14009d9b4:     	jmp	0x14009d7ef <.text+0x9c7ef>
14009d9b9:     	movq	(%rbp), %r8
14009d9bd:     	movq	0x10(%rbp), %r9
14009d9c1:     	leaq	-0x20(%rbp), %rdx
14009d9c5:     	movq	%rsi, %rcx
14009d9c8:     	callq	0x14000b2d0 <.text+0xa2d0>
14009d9cd:     	jmp	0x14009d7ef <.text+0x9c7ef>
14009d9d2:     	leaq	0xa(%rbp), %r8
14009d9d6:     	movzbl	0x9(%rbp), %r9d
14009d9db:     	leaq	-0x20(%rbp), %rdx
14009d9df:     	movq	%rsi, %rcx
14009d9e2:     	callq	0x14000b1c0 <.text+0xa1c0>
14009d9e7:     	jmp	0x14009d7ef <.text+0x9c7ef>
14009d9ec:     	xorl	%edi, %edi
14009d9ee:     	jmp	0x14009d878 <.text+0x9c878>
14009d9f3:     	movl	$0x1, %edi
14009d9f8:     	jmp	0x14009d878 <.text+0x9c878>
14009d9fd:     	leaq	0x1d039c(%rip), %r8     # 0x14026dda0
14009da04:     	movl	$0x4, %edx
14009da09:     	movq	%rdi, %rcx
14009da0c:     	callq	0x140252693 <.text+0x251693>
14009da11:     	ud2
14009da13:     	leaq	0x1d039e(%rip), %r8     # 0x14026ddb8
14009da1a:     	movl	$0x4, %edx
14009da1f:     	movq	%rdi, %rcx
14009da22:     	callq	0x140252693 <.text+0x251693>
14009da27:     	ud2


D:\CoapticCurrent\replay-scratch-original-inbox-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009da30:     	pushq	%rbp
14009da31:     	pushq	%r15
14009da33:     	pushq	%r14
14009da35:     	pushq	%r13
14009da37:     	pushq	%r12
14009da39:     	pushq	%rsi
14009da3a:     	pushq	%rdi
14009da3b:     	pushq	%rbx
14009da3c:     	subq	$0x218, %rsp            # imm = 0x218
14009da43:     	leaq	0x80(%rsp), %rbp
14009da4b:     	movaps	%xmm6, 0x180(%rbp)
14009da52:     	leaq	0x3f10(%rcx), %rsi
14009da59:     	leaq	0x3f38(%rcx), %r8
14009da60:     	movl	$0x4, %r11d
14009da66:     	xorl	%eax, %eax
14009da68:     	movl	$0x1, %r9d
14009da6e:     	xorl	%r10d, %r10d
14009da71:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009da78:     	addq	%r8, %rdi
14009da7b:     	nopl	(%rax,%rax)
14009da80:     	cmpb	$0x2, -0xe(%rdi)
14009da84:     	jne	0x14009daa0 <.text+0x9caa0>
14009da86:     	incq	%r10
14009da89:     	addq	$0x130, %rdi            # imm = 0x130
14009da90:     	cmpq	%r10, %r11
14009da93:     	jne	0x14009da80 <.text+0x9ca80>
14009da95:     	jmp	0x14009dae5 <.text+0x9cae5>
14009da97:     	nopw	(%rax,%rax)
14009daa0:     	movq	-0x8(%rdi), %r11
14009daa4:     	cmpb	$0x3, (%rdi)
14009daa7:     	setne	%bl
14009daaa:     	testq	%r11, %r11
14009daad:     	sete	%dil
14009dab1:     	orb	%bl, %dil
14009dab4:     	cmpq	%r14, %r11
14009dab7:     	setae	%bl
14009daba:     	andb	%al, %bl
14009dabc:     	testb	%dil, %dil
14009dabf:     	cmoveq	%r9, %rax
14009dac3:     	orb	%dil, %bl
14009dac6:     	cmoveq	%r10, %rdx
14009daca:     	cmoveq	%r11, %r14
14009dace:     	incq	%r10
14009dad1:     	cmpq	$0x5, %r10
14009dad5:     	movl	$0x4, %r11d
14009dadb:     	cmovaeq	%r10, %r11
14009dadf:     	cmpq	$0x3, %r10
14009dae3:     	jbe	0x14009da71 <.text+0x9ca71>
14009dae5:     	testb	$0x1, %al
14009dae7:     	je	0x14009dbe1 <.text+0x9cbe1>
14009daed:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009daf4:     	movzbl	0x1a(%rsi,%rax), %r15d
14009dafa:     	cmpb	$0x2, %r15b
14009dafe:     	je	0x14009dbe1 <.text+0x9cbe1>
14009db04:     	addq	%rsi, %rax
14009db07:     	cmpb	$0x3, 0x28(%rax)
14009db0b:     	jne	0x14009dbe1 <.text+0x9cbe1>
14009db11:     	movq	0x30(%rax), %r8
14009db15:     	movq	(%rax), %rdx
14009db18:     	movq	%rdx, 0x168(%rbp)
14009db1f:     	movq	0x8(%rax), %rdx
14009db23:     	movq	%rdx, 0x170(%rbp)
14009db2a:     	movl	0x10(%rax), %ebx
14009db2d:     	movl	0x14(%rax), %r12d
14009db31:     	movzwl	0x18(%rax), %edi
14009db35:     	movzbl	0x1b(%rax), %edx
14009db39:     	movb	%dl, 0x17f(%rbp)
14009db3f:     	movss	0x1c(%rax), %xmm6
14009db44:     	movzwl	0x1c(%rax), %eax
14009db48:     	movzwl	%ax, %edx
14009db4b:     	cmpq	$0x1, %r8
14009db4f:     	ja	0x14009dbab <.text+0x9cbab>
14009db51:     	cmpb	$0x1, 0x3f08(%rcx,%r8)
14009db5a:     	jne	0x14009dbab <.text+0x9cbab>
14009db5c:     	cmpb	$0x0, 0x3f0a(%rcx,%r8)
14009db65:     	jne	0x14009dbab <.text+0x9cbab>
14009db67:     	movb	$0x0, 0x3f08(%rcx,%r8)
14009db70:     	decq	0x3f00(%rcx)
14009db77:     	leaq	0x3580(%rcx), %r9
14009db7e:     	movq	$0x0, 0x3e80(%rcx,%r8,8)
14009db8a:     	leaq	(%r8,%r8,8), %r10
14009db8e:     	leaq	(%r10,%r10,2), %r10
14009db92:     	addq	%r8, %r10
14009db95:     	movb	$0x2, 0x95a(%r9,%r10)
14009db9e:     	leaq	(%r8,%r8,2), %r8
14009dba2:     	movb	$0x2, 0x91d(%r9,%r8,8)
14009dbab:     	addl	$0x2, %edx
14009dbae:     	movb	$0x1, %r9b
14009dbb1:     	cmpl	%edx, 0x43d0(%rcx)
14009dbb7:     	jne	0x14009dbc7 <.text+0x9cbc7>
14009dbb9:     	movzbl	0x3f2a(%rcx), %r8d
14009dbc1:     	cmpb	$0x2, %r8b
14009dbc5:     	jne	0x14009dbfe <.text+0x9cbfe>
14009dbc7:     	xorl	%r8d, %r8d
14009dbca:     	cmpl	%edx, 0x43d4(%rcx)
14009dbd0:     	movl	%ebx, 0x178(%rbp)
14009dbd6:     	jne	0x14009dc8d <.text+0x9cc8d>
14009dbdc:     	jmp	0x14009dc7b <.text+0x9cc7b>
14009dbe1:     	xorl	%eax, %eax
14009dbe3:     	movaps	0x180(%rbp), %xmm6
14009dbea:     	addq	$0x218, %rsp            # imm = 0x218
14009dbf1:     	popq	%rbx
14009dbf2:     	popq	%rdi
14009dbf3:     	popq	%rsi
14009dbf4:     	popq	%r12
14009dbf6:     	popq	%r13
14009dbf8:     	popq	%r14
14009dbfa:     	popq	%r15
14009dbfc:     	popq	%rbp
14009dbfd:     	retq
14009dbfe:     	cmpw	%ax, 0x3f2c(%rcx)
14009dc05:     	sete	%r9b
14009dc09:     	cmpl	%ebx, 0x3f20(%rcx)
14009dc0f:     	sete	%r10b
14009dc13:     	andb	%r9b, %r10b
14009dc16:     	cmpl	%r12d, 0x3f24(%rcx)
14009dc1d:     	sete	%r9b
14009dc21:     	cmpw	%di, 0x3f28(%rcx)
14009dc28:     	sete	%r11b
14009dc2c:     	andb	%r9b, %r11b
14009dc2f:     	andb	%r10b, %r11b
14009dc32:     	cmpb	%r15b, %r8b
14009dc35:     	sete	%r8b
14009dc39:     	movq	0x3f18(%rcx), %r9
14009dc40:     	xorq	0x170(%rbp), %r9
14009dc47:     	movq	0x3f10(%rcx), %r10
14009dc4e:     	xorq	0x168(%rbp), %r10
14009dc55:     	orq	%r9, %r10
14009dc58:     	sete	%r9b
14009dc5c:     	andb	%r8b, %r9b
14009dc5f:     	andb	%r11b, %r9b
14009dc62:     	movzbl	%r9b, %r8d
14009dc66:     	movl	%r8d, %r9d
14009dc69:     	xorb	$0x1, %r9b
14009dc6d:     	cmpl	%edx, 0x43d4(%rcx)
14009dc73:     	movl	%ebx, 0x178(%rbp)
14009dc79:     	jne	0x14009dc8d <.text+0x9cc8d>
14009dc7b:     	movzbl	0x405a(%rcx), %r10d
14009dc83:     	cmpb	$0x2, %r10b
14009dc87:     	jne	0x14009dd3e <.text+0x9cd3e>
14009dc8d:     	xorl	%r9d, %r9d
14009dc90:     	cmpl	%edx, 0x43d8(%rcx)
14009dc96:     	jne	0x14009dde4 <.text+0x9cde4>
14009dc9c:     	movzbl	0x418a(%rcx), %r10d
14009dca4:     	cmpb	$0x2, %r10b
14009dca8:     	je	0x14009dde4 <.text+0x9cde4>
14009dcae:     	cmpb	%r15b, %r10b
14009dcb1:     	jne	0x14009dde4 <.text+0x9cde4>
14009dcb7:     	cmpw	%ax, 0x418c(%rcx)
14009dcbe:     	jne	0x14009dde4 <.text+0x9cde4>
14009dcc4:     	cmpl	%ebx, 0x4180(%rcx)
14009dcca:     	jne	0x14009dde4 <.text+0x9cde4>
14009dcd0:     	cmpl	%r12d, 0x4184(%rcx)
14009dcd7:     	jne	0x14009dde4 <.text+0x9cde4>
14009dcdd:     	cmpw	%di, 0x4188(%rcx)
14009dce4:     	jne	0x14009dde4 <.text+0x9cde4>
14009dcea:     	movq	0x4170(%rcx), %r10
14009dcf1:     	xorq	0x168(%rbp), %r10
14009dcf8:     	movq	0x4178(%rcx), %r11
14009dcff:     	xorq	0x170(%rbp), %r11
14009dd06:     	orq	%r10, %r11
14009dd09:     	jne	0x14009dde4 <.text+0x9cde4>
14009dd0f:     	movl	%r12d, %r13d
14009dd12:     	movl	%edi, %r12d
14009dd15:     	movb	$0x1, %dil
14009dd18:     	testq	%r8, %r8
14009dd1b:     	jne	0x14009de70 <.text+0x9ce70>
14009dd21:     	movl	$0x1, %r8d
14009dd27:     	movl	$0x2, %r9d
14009dd2d:     	movl	%r12d, %edi
14009dd30:     	movl	%r13d, %r12d
14009dd33:     	movl	0x178(%rbp), %ebx
14009dd39:     	jmp	0x14009dde4 <.text+0x9cde4>
14009dd3e:     	cmpw	%ax, 0x405c(%rcx)
14009dd45:     	setne	%r11b
14009dd49:     	cmpl	%ebx, 0x4050(%rcx)
14009dd4f:     	setne	%bl
14009dd52:     	orb	%r11b, %bl
14009dd55:     	movl	%r12d, %r13d
14009dd58:     	cmpl	%r12d, 0x4054(%rcx)
14009dd5f:     	setne	%r11b
14009dd63:     	movl	%edi, %r12d
14009dd66:     	cmpw	%di, 0x4058(%rcx)
14009dd6d:     	setne	%dil
14009dd71:     	orb	%r11b, %dil
14009dd74:     	orb	%bl, %dil
14009dd77:     	cmpb	%r15b, %r10b
14009dd7a:     	setne	%r11b
14009dd7e:     	movq	0x4048(%rcx), %r10
14009dd85:     	xorq	0x170(%rbp), %r10
14009dd8c:     	movq	0x4040(%rcx), %rbx
14009dd93:     	xorq	0x168(%rbp), %rbx
14009dd9a:     	orq	%r10, %rbx
14009dd9d:     	setne	%r10b
14009dda1:     	orb	%r11b, %r10b
14009dda4:     	orb	%dil, %r10b
14009dda7:     	orb	%r10b, %r9b
14009ddaa:     	testb	%r10b, %r10b
14009ddad:     	movl	$0x1, %r11d
14009ddb3:     	cmoveq	%r11, %r8
14009ddb7:     	testb	$0x1, %r9b
14009ddbb:     	je	0x14009de6a <.text+0x9ce6a>
14009ddc1:     	notb	%r10b
14009ddc4:     	movzbl	%r10b, %r9d
14009ddc8:     	andl	$0x1, %r9d
14009ddcc:     	movl	%r12d, %edi
14009ddcf:     	movl	%r13d, %r12d
14009ddd2:     	movl	0x178(%rbp), %ebx
14009ddd8:     	cmpl	%edx, 0x43d8(%rcx)
14009ddde:     	je	0x14009dc9c <.text+0x9cc9c>
14009dde4:     	cmpl	%edx, 0x43dc(%rcx)
14009ddea:     	jne	0x14009ddf8 <.text+0x9cdf8>
14009ddec:     	movzbl	0x42ba(%rcx), %edx
14009ddf3:     	cmpb	$0x2, %dl
14009ddf6:     	jne	0x14009de0a <.text+0x9ce0a>
14009ddf8:     	movl	%r12d, %r13d
14009ddfb:     	movl	%edi, %r12d
14009ddfe:     	xorl	%edi, %edi
14009de00:     	testq	%r8, %r8
14009de03:     	jne	0x14009de70 <.text+0x9ce70>
14009de05:     	jmp	0x14009de9a <.text+0x9ce9a>
14009de0a:     	cmpb	%r15b, %dl
14009de0d:     	jne	0x14009ddf8 <.text+0x9cdf8>
14009de0f:     	cmpw	%ax, 0x42bc(%rcx)
14009de16:     	jne	0x14009ddf8 <.text+0x9cdf8>
14009de18:     	cmpl	%ebx, 0x42b0(%rcx)
14009de1e:     	jne	0x14009ddf8 <.text+0x9cdf8>
14009de20:     	cmpl	%r12d, 0x42b4(%rcx)
14009de27:     	jne	0x14009ddf8 <.text+0x9cdf8>
14009de29:     	cmpw	%di, 0x42b8(%rcx)
14009de30:     	jne	0x14009ddf8 <.text+0x9cdf8>
14009de32:     	movq	0x42a0(%rcx), %rdx
14009de39:     	xorq	0x168(%rbp), %rdx
14009de40:     	movq	0x42a8(%rcx), %r10
14009de47:     	xorq	0x170(%rbp), %r10
14009de4e:     	orq	%rdx, %r10
14009de51:     	jne	0x14009ddf8 <.text+0x9cdf8>
14009de53:     	movl	%r12d, %r13d
14009de56:     	movl	%edi, %r12d
14009de59:     	testq	%r8, %r8
14009de5c:     	movl	$0x3, %edx
14009de61:     	cmoveq	%rdx, %r9
14009de65:     	movl	%r8d, %edi
14009de68:     	jmp	0x14009de70 <.text+0x9ce70>
14009de6a:     	movb	$0x1, %dil
14009de6d:     	xorl	%r9d, %r9d
14009de70:     	cmpl	$0x0, 0x43d0(%rcx,%r9,4)
14009de79:     	je	0x14009de9a <.text+0x9ce9a>
14009de7b:     	movl	$0x0, 0x43d0(%rcx,%r9,4)
14009de87:     	decq	0x43e8(%rcx)
14009de8e:     	imulq	$0x130, %r9, %rdx       # imm = 0x130
14009de95:     	movb	$0x2, 0x1a(%rsi,%rdx)
14009de9a:     	xorps	%xmm0, %xmm0
14009de9d:     	movaps	%xmm0, 0x150(%rbp)
14009dea4:     	movb	$0x0, 0x132(%rbp)
14009deab:     	movw	%ax, 0x130(%rbp)
14009deb2:     	leaq	0x133(%rbp), %rdx
14009deb9:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009dec2:     	movq	$0x0, 0x133(%rbp)
14009decd:     	movq	$0x8, 0x110(%rbp)
14009ded8:     	movq	$0x0, 0x118(%rbp)
14009dee3:     	movq	$0x1, 0x120(%rbp)
14009deee:     	movq	$0x0, 0x128(%rbp)
14009def9:     	movq	%rdx, 0x30(%rsp)
14009defe:     	movw	%ax, 0x28(%rsp)
14009df03:     	movq	$0x0, 0x58(%rsp)
14009df0c:     	movq	$0x1, 0x50(%rsp)
14009df15:     	movq	$0x8, 0x48(%rsp)
14009df1e:     	movq	$0x8, 0x40(%rsp)
14009df27:     	movq	$0x0, 0x38(%rsp)
14009df30:     	movb	$0x0, 0x20(%rsp)
14009df35:     	leaq	0x140(%rbp), %rax
14009df3c:     	leaq	0x150(%rbp), %rdx
14009df43:     	movl	$0x10, %r8d
14009df49:     	movq	%rcx, %rbx
14009df4c:     	movq	%rax, %rcx
14009df4f:     	movb	$0x2, %r9b
14009df52:     	callq	0x140005590 <.text+0x4590>
14009df57:     	cmpb	$0x0, 0x140(%rbp)
14009df5e:     	jne	0x14009df7f <.text+0x9cf7f>
14009df60:     	testb	%dil, %dil
14009df63:     	jne	0x14009df7f <.text+0x9cf7f>
14009df65:     	movq	%rbx, %rax
14009df68:     	movq	0x148(%rbp), %rbx
14009df6f:     	cmpq	$0x10, %rbx
14009df73:     	ja	0x14009df7f <.text+0x9cf7f>
14009df75:     	cmpq	$0x4, 0x43e8(%rax)
14009df7d:     	jne	0x14009df86 <.text+0x9cf86>
14009df7f:     	movb	$0x1, %al
14009df81:     	jmp	0x14009dbe3 <.text+0x9cbe3>
14009df86:     	movq	0x43e0(%rax), %rdi
14009df8d:     	cmpq	$0x3, %rdi
14009df91:     	ja	0x14009e18d <.text+0x9d18d>
14009df97:     	cmpl	$0x0, 0x43d0(%rax,%rdi,4)
14009df9f:     	je	0x14009e012 <.text+0x9d012>
14009dfa1:     	leaq	(,%rdi,4), %rdx
14009dfa9:     	xorl	%ecx, %ecx
14009dfab:     	nopl	(%rax,%rax)
14009dfb0:     	cmpl	$0x0, 0x43d0(%rax,%rdx)
14009dfb8:     	je	0x14009e005 <.text+0x9d005>
14009dfba:     	addq	$0x4, %rdx
14009dfbe:     	decq	%rcx
14009dfc1:     	cmpq	$0x10, %rdx
14009dfc5:     	jne	0x14009dfb0 <.text+0x9cfb0>
14009dfc7:     	testq	%rdi, %rdi
14009dfca:     	je	0x14009df7f <.text+0x9cf7f>
14009dfcc:     	cmpl	$0x0, 0x43d0(%rax)
14009dfd3:     	je	0x14009e17c <.text+0x9d17c>
14009dfd9:     	cmpq	$0x1, %rdi
14009dfdd:     	je	0x14009df7f <.text+0x9cf7f>
14009dfdf:     	cmpl	$0x0, 0x43d4(%rax)
14009dfe6:     	je	0x14009e183 <.text+0x9d183>
14009dfec:     	cmpq	$0x2, %rdi
14009dff0:     	je	0x14009df7f <.text+0x9cf7f>
14009dff2:     	movl	$0x2, %edi
14009dff7:     	cmpl	$0x0, 0x43d8(%rax)
14009dffe:     	je	0x14009e008 <.text+0x9d008>
14009e000:     	jmp	0x14009df7f <.text+0x9cf7f>
14009e005:     	subq	%rcx, %rdi
14009e008:     	cmpq	$0x4, %rdi
14009e00c:     	jae	0x14009e1a3 <.text+0x9d1a3>
14009e012:     	movl	$0x1, 0x43d0(%rax,%rdi,4)
14009e01d:     	incq	0x43e8(%rax)
14009e024:     	leaq	0x1(%rdi), %rcx
14009e028:     	xorl	%edx, %edx
14009e02a:     	cmpq	$0x4, %rcx
14009e02e:     	cmovneq	%rcx, %rdx
14009e032:     	movq	%rdx, 0x43e0(%rax)
14009e039:     	movq	0x170(%rbp), %rcx
14009e040:     	movq	%rcx, -0x18(%rbp)
14009e044:     	movq	0x168(%rbp), %rcx
14009e04b:     	movq	%rcx, -0x20(%rbp)
14009e04f:     	movl	0x178(%rbp), %ecx
14009e055:     	movl	%ecx, -0x10(%rbp)
14009e058:     	movl	%r13d, -0xc(%rbp)
14009e05c:     	movw	%r12w, -0x8(%rbp)
14009e061:     	movb	%r15b, -0x6(%rbp)
14009e065:     	movzbl	0x17f(%rbp), %ecx
14009e06c:     	movb	%cl, -0x5(%rbp)
14009e06f:     	movss	%xmm6, -0x4(%rbp)
14009e074:     	movq	%r14, (%rbp)
14009e078:     	testq	%rbx, %rbx
14009e07b:     	je	0x14009e0e2 <.text+0x9d0e2>
14009e07d:     	movb	$0x1, 0x8(%rbp)
14009e081:     	movb	%bl, 0x9(%rbp)
14009e084:     	leaq	0xa(%rbp), %r14
14009e088:     	movl	$0x80, %r8d
14009e08e:     	subq	%rbx, %r8
14009e091:     	leaq	(%rbx,%rbp), %rcx
14009e095:     	addq	$0xa, %rcx
14009e099:     	movq	%rax, %r15
14009e09c:     	xorl	%edx, %edx
14009e09e:     	callq	0x140251e22 <.text+0x250e22>
14009e0a3:     	leaq	0x150(%rbp), %rdx
14009e0aa:     	movq	%r14, %rcx
14009e0ad:     	movq	%rbx, %r8
14009e0b0:     	callq	0x140251e10 <.text+0x250e10>
14009e0b5:     	movzwl	-0x4(%rbp), %eax
14009e0b9:     	addl	$0x2, %eax
14009e0bc:     	movl	%eax, 0x43d0(%r15,%rdi,4)
14009e0c4:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009e0cb:     	addq	%rax, %rsi
14009e0ce:     	movzbl	0x8(%rbp), %eax
14009e0d2:     	leaq	0x1d3167(%rip), %rcx    # 0x140271240
14009e0d9:     	movslq	(%rcx,%rax,4), %rax
14009e0dd:     	addq	%rcx, %rax
14009e0e0:     	jmpq	*%rax
14009e0e2:     	movb	$0x0, 0x8(%rbp)
14009e0e6:     	movzwl	-0x4(%rbp), %ecx
14009e0ea:     	addl	$0x2, %ecx
14009e0ed:     	movl	%ecx, 0x43d0(%rax,%rdi,4)
14009e0f4:     	imulq	$0x130, %rdi, %rax      # imm = 0x130
14009e0fb:     	addq	%rax, %rsi
14009e0fe:     	movzbl	0x8(%rbp), %eax
14009e102:     	leaq	0x1d3137(%rip), %rcx    # 0x140271240
14009e109:     	movslq	(%rcx,%rax,4), %rax
14009e10d:     	addq	%rcx, %rax
14009e110:     	jmpq	*%rax
14009e112:     	movaps	-0x20(%rbp), %xmm0
14009e116:     	movaps	-0x10(%rbp), %xmm1
14009e11a:     	movups	%xmm1, 0x10(%rsi)
14009e11e:     	movups	%xmm0, (%rsi)
14009e121:     	movb	$0x0, 0x28(%rsi)
14009e125:     	movq	(%rbp), %rax
14009e129:     	movq	%rax, 0x20(%rsi)
14009e12d:     	jmp	0x14009df7f <.text+0x9cf7f>
14009e132:     	leaq	-0x20(%rbp), %rdx
14009e136:     	movl	$0x130, %r8d            # imm = 0x130
14009e13c:     	movq	%rsi, %rcx
14009e13f:     	callq	0x140251e10 <.text+0x250e10>
14009e144:     	jmp	0x14009df7f <.text+0x9cf7f>
14009e149:     	movq	(%rbp), %r8
14009e14d:     	movq	0x10(%rbp), %r9
14009e151:     	leaq	-0x20(%rbp), %rdx
14009e155:     	movq	%rsi, %rcx
14009e158:     	callq	0x14000b2d0 <.text+0xa2d0>
14009e15d:     	jmp	0x14009df7f <.text+0x9cf7f>
14009e162:     	leaq	0xa(%rbp), %r8
14009e166:     	movzbl	0x9(%rbp), %r9d
14009e16b:     	leaq	-0x20(%rbp), %rdx
14009e16f:     	movq	%rsi, %rcx
14009e172:     	callq	0x14000b1c0 <.text+0xa1c0>
14009e177:     	jmp	0x14009df7f <.text+0x9cf7f>
14009e17c:     	xorl	%edi, %edi
14009e17e:     	jmp	0x14009e008 <.text+0x9d008>
14009e183:     	movl	$0x1, %edi
14009e188:     	jmp	0x14009e008 <.text+0x9d008>
14009e18d:     	leaq	0x1cfc0c(%rip), %r8     # 0x14026dda0
14009e194:     	movl	$0x4, %edx
14009e199:     	movq	%rdi, %rcx
14009e19c:     	callq	0x140252693 <.text+0x251693>
14009e1a1:     	ud2
14009e1a3:     	leaq	0x1cfc0e(%rip), %r8     # 0x14026ddb8
14009e1aa:     	movl	$0x4, %edx
14009e1af:     	movq	%rdi, %rcx
14009e1b2:     	callq	0x140252693 <.text+0x251693>
14009e1b7:     	ud2

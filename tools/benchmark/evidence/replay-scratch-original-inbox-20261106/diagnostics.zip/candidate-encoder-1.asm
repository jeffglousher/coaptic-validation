
D:\CoapticCurrent\replay-scratch-original-inbox-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400671a0:     	pushq	%rbp
1400671a1:     	pushq	%r15
1400671a3:     	pushq	%r14
1400671a5:     	pushq	%r13
1400671a7:     	pushq	%r12
1400671a9:     	pushq	%rsi
1400671aa:     	pushq	%rdi
1400671ab:     	pushq	%rbx
1400671ac:     	subq	$0x508, %rsp            # imm = 0x508
1400671b3:     	leaq	0x80(%rsp), %rbp
1400671bb:     	movq	0x500(%rbp), %r12
1400671c2:     	movq	0x8(%r12), %rdi
1400671c7:     	movl	$0x3, %r10d
1400671cd:     	cmpq	$0x3, %rdi
1400671d1:     	ja	0x1400672b1 <.text+0x662b1>
1400671d7:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
1400671df:     	jne	0x1400672b1 <.text+0x662b1>
1400671e5:     	movq	0x26700(%rdx,%rdi,8), %rax
1400671ed:     	cmpq	$0x4001, %rax           # imm = 0x4001
1400671f3:     	jae	0x14006748e <.text+0x6648e>
1400671f9:     	movq	0x10(%r12), %r11
1400671fe:     	movq	0x18(%r12), %r15
140067203:     	movq	%r15, %rsi
140067206:     	movl	$0xb, %r10d
14006720c:     	addq	%r11, %rsi
14006720f:     	jb	0x1400672b1 <.text+0x662b1>
140067215:     	cmpq	$0x400, %r15            # imm = 0x400
14006721c:     	ja	0x1400672b1 <.text+0x662b1>
140067222:     	cmpq	%rax, %rsi
140067225:     	ja	0x1400672b1 <.text+0x662b1>
14006722b:     	movq	%r8, %r13
14006722e:     	movq	%r9, 0x470(%rbp)
140067235:     	movq	%rcx, 0x480(%rbp)
14006723c:     	movzbl	0x508(%rbp), %r14d
140067244:     	movq	%rdi, %rax
140067247:     	shlq	$0xe, %rax
14006724b:     	movq	%rdx, %rsi
14006724e:     	leaq	(%rdx,%rax), %rbx
140067252:     	addq	$0x16700, %rbx          # imm = 0x16700
140067259:     	addq	%r11, %rbx
14006725c:     	movl	$0x400, %r8d            # imm = 0x400
140067262:     	cmpq	$0x400, %r15            # imm = 0x400
140067269:     	je	0x140067278 <.text+0x66278>
14006726b:     	movq	%rbp, %rcx
14006726e:     	xorl	%edx, %edx
140067270:     	callq	0x140251e22 <.text+0x250e22>
140067275:     	movq	%r15, %r8
140067278:     	movq	%rbp, %rcx
14006727b:     	movq	%rbx, %rdx
14006727e:     	callq	0x140251e10 <.text+0x250e10>
140067283:     	testb	%r14b, %r14b
140067286:     	je	0x1400672cc <.text+0x662cc>
140067288:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
14006728f:     	movq	%rsi, %rcx
140067292:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
14006729b:     	jne	0x140067443 <.text+0x66443>
1400672a1:     	xorl	%edi, %edi
1400672a3:     	callq	0x140099ed0 <.text+0x98ed0>
1400672a8:     	testb	$0x1, %al
1400672aa:     	jne	0x1400672de <.text+0x662de>
1400672ac:     	jmp	0x14006746c <.text+0x6646c>
1400672b1:     	movb	$0xa, (%rcx)
1400672b4:     	movq	%r10, 0x8(%rcx)
1400672b8:     	addq	$0x508, %rsp            # imm = 0x508
1400672bf:     	popq	%rbx
1400672c0:     	popq	%rdi
1400672c1:     	popq	%rsi
1400672c2:     	popq	%r12
1400672c4:     	popq	%r13
1400672c6:     	popq	%r14
1400672c8:     	popq	%r15
1400672ca:     	popq	%rbp
1400672cb:     	retq
1400672cc:     	xorl	%edi, %edi
1400672ce:     	movq	%rsi, %rcx
1400672d1:     	callq	0x140099ed0 <.text+0x98ed0>
1400672d6:     	testb	$0x1, %al
1400672d8:     	je	0x14006746c <.text+0x6646c>
1400672de:     	movq	%rdx, %rbx
1400672e1:     	movq	0x518(%rbp), %rdx
1400672e8:     	movq	0x510(%rbp), %r8
1400672ef:     	movzwl	0x4f8(%rbp), %ecx
1400672f6:     	movzbl	0x4f0(%rbp), %eax
1400672fd:     	movq	(%r12), %r9
140067301:     	movq	%rdi, 0x440(%rbp)
140067308:     	movq	0x478(%rbp), %r10
14006730f:     	movq	%r10, 0x448(%rbp)
140067316:     	movq	%r9, 0x450(%rbp)
14006731d:     	movb	%r14b, 0x458(%rbp)
140067324:     	movups	0x60(%r13), %xmm0
140067329:     	movups	0x6c(%r13), %xmm1
14006732e:     	movups	%xmm1, 0x40c(%rbp)
140067335:     	movaps	%xmm0, 0x400(%rbp)
14006733c:     	leaq	0x8e(%r13), %r9
140067343:     	movq	0x7e(%r13), %r10
140067347:     	movq	0x85(%r13), %r11
14006734e:     	movq	%r11, 0x467(%rbp)
140067355:     	movq	%r10, 0x460(%rbp)
14006735c:     	leaq	0x460(%rbp), %r10
140067363:     	movq	%r10, 0x70(%rsp)
140067368:     	movq	%rdx, 0x68(%rsp)
14006736d:     	movq	%r8, 0x60(%rsp)
140067372:     	movq	%r13, 0x58(%rsp)
140067377:     	leaq	0x440(%rbp), %rdx
14006737e:     	movq	%rdx, 0x50(%rsp)
140067383:     	movq	%r15, 0x48(%rsp)
140067388:     	movq	%rbp, %rdx
14006738b:     	movq	%rdx, 0x40(%rsp)
140067390:     	movq	0x470(%rbp), %rdx
140067397:     	movq	%rdx, 0x38(%rsp)
14006739c:     	movq	%r9, 0x30(%rsp)
1400673a1:     	movw	%cx, 0x28(%rsp)
1400673a6:     	movb	%al, 0x20(%rsp)
1400673aa:     	leaq	0x420(%rbp), %rcx
1400673b1:     	leaq	0x400(%rbp), %r8
1400673b8:     	movq	%rsi, %rdx
1400673bb:     	movq	%rbx, %r9
1400673be:     	callq	0x140080100 <.text+0x7f100>
1400673c3:     	cmpb	$-0x1, 0x420(%rbp)
1400673ca:     	je	0x14006747b <.text+0x6647b>
1400673d0:     	cmpb	$0x1, 0x326f0(%rsi,%rbx)
1400673d8:     	movq	0x480(%rbp), %rax
1400673df:     	jne	0x140067429 <.text+0x66429>
1400673e1:     	cmpb	$0x0, 0x32710(%rsi,%rbx)
1400673e9:     	jne	0x140067429 <.text+0x66429>
1400673eb:     	movb	$0x0, 0x326f0(%rsi,%rbx)
1400673f3:     	decq	0x32738(%rsi)
1400673fa:     	leaq	0x326f0(%rsi), %rcx
140067401:     	movq	$0x0, 0x3e5c0(%rsi,%rbx,8)
14006740d:     	leaq	(%rbx,%rbx,8), %rdx
140067411:     	leaq	(%rdx,%rdx,2), %rdx
140067415:     	addq	%rbx, %rdx
140067418:     	movb	$0x2, 0x36a(%rcx,%rdx)
140067420:     	leaq	(%rbx,%rbx,2), %rdx
140067424:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140067429:     	movups	0x420(%rbp), %xmm0
140067430:     	movups	0x430(%rbp), %xmm1
140067437:     	movups	%xmm1, 0x10(%rax)
14006743b:     	movups	%xmm0, (%rax)
14006743e:     	jmp	0x1400672b8 <.text+0x662b8>
140067443:     	addq	%rcx, %rax
140067446:     	addq	$0x15c28, %rax          # imm = 0x15C28
14006744c:     	movq	0x98(%rax), %rax
140067453:     	movq	%rax, 0x478(%rbp)
14006745a:     	movl	$0x1, %edi
14006745f:     	callq	0x140099ed0 <.text+0x98ed0>
140067464:     	testb	$0x1, %al
140067466:     	jne	0x1400672de <.text+0x662de>
14006746c:     	movq	0x480(%rbp), %rax
140067473:     	movb	$0x9, (%rax)
140067476:     	jmp	0x1400672b8 <.text+0x662b8>
14006747b:     	movq	0x480(%rbp), %rax
140067482:     	movq	%rbx, 0x8(%rax)
140067486:     	movb	$-0x1, (%rax)
140067489:     	jmp	0x1400672b8 <.text+0x662b8>
14006748e:     	leaq	0x2067bb(%rip), %r9     # 0x14026dc50
140067495:     	movl	$0x4000, %r8d           # imm = 0x4000
14006749b:     	xorl	%ecx, %ecx
14006749d:     	movq	%rax, %rdx
1400674a0:     	callq	0x1402528a0 <.text+0x2518a0>
1400674a5:     	ud2

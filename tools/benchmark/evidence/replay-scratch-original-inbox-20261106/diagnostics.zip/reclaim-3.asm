
D:\CoapticCurrent\replay-scratch-original-inbox-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009e1c0:     	pushq	%rbp
14009e1c1:     	pushq	%r15
14009e1c3:     	pushq	%r14
14009e1c5:     	pushq	%r13
14009e1c7:     	pushq	%r12
14009e1c9:     	pushq	%rsi
14009e1ca:     	pushq	%rdi
14009e1cb:     	pushq	%rbx
14009e1cc:     	subq	$0x218, %rsp            # imm = 0x218
14009e1d3:     	leaq	0x80(%rsp), %rbp
14009e1db:     	movaps	%xmm6, 0x180(%rbp)
14009e1e2:     	leaq	0x3f7f0(%rcx), %rsi
14009e1e9:     	leaq	0x3f818(%rcx), %r8
14009e1f0:     	movl	$0x40, %r11d
14009e1f6:     	xorl	%eax, %eax
14009e1f8:     	movl	$0x1, %r9d
14009e1fe:     	xorl	%r10d, %r10d
14009e201:     	imulq	$0x130, %r10, %rdi      # imm = 0x130
14009e208:     	addq	%r8, %rdi
14009e20b:     	nopl	(%rax,%rax)
14009e210:     	cmpb	$0x2, -0xe(%rdi)
14009e214:     	jne	0x14009e230 <.text+0x9d230>
14009e216:     	incq	%r10
14009e219:     	addq	$0x130, %rdi            # imm = 0x130
14009e220:     	cmpq	%r10, %r11
14009e223:     	jne	0x14009e210 <.text+0x9d210>
14009e225:     	jmp	0x14009e275 <.text+0x9d275>
14009e227:     	nopw	(%rax,%rax)
14009e230:     	movq	-0x8(%rdi), %r11
14009e234:     	cmpb	$0x3, (%rdi)
14009e237:     	setne	%bl
14009e23a:     	testq	%r11, %r11
14009e23d:     	sete	%dil
14009e241:     	orb	%bl, %dil
14009e244:     	cmpq	%r14, %r11
14009e247:     	setae	%bl
14009e24a:     	andb	%al, %bl
14009e24c:     	testb	%dil, %dil
14009e24f:     	cmoveq	%r9, %rax
14009e253:     	orb	%dil, %bl
14009e256:     	cmoveq	%r10, %rdx
14009e25a:     	cmoveq	%r11, %r14
14009e25e:     	incq	%r10
14009e261:     	cmpq	$0x41, %r10
14009e265:     	movl	$0x40, %r11d
14009e26b:     	cmovaeq	%r10, %r11
14009e26f:     	cmpq	$0x3f, %r10
14009e273:     	jbe	0x14009e201 <.text+0x9d201>
14009e275:     	testb	$0x1, %al
14009e277:     	je	0x14009e3ef <.text+0x9d3ef>
14009e27d:     	imulq	$0x130, %rdx, %rax      # imm = 0x130
14009e284:     	movzbl	0x1a(%rsi,%rax), %r15d
14009e28a:     	cmpb	$0x2, %r15b
14009e28e:     	je	0x14009e3ef <.text+0x9d3ef>
14009e294:     	addq	%rsi, %rax
14009e297:     	cmpb	$0x3, 0x28(%rax)
14009e29b:     	jne	0x14009e3ef <.text+0x9d3ef>
14009e2a1:     	movq	0x30(%rax), %r8
14009e2a5:     	movq	(%rax), %rdx
14009e2a8:     	movq	%rdx, 0x168(%rbp)
14009e2af:     	movq	0x8(%rax), %rdx
14009e2b3:     	movq	%rdx, 0x170(%rbp)
14009e2ba:     	movl	0x10(%rax), %edi
14009e2bd:     	movl	0x14(%rax), %edx
14009e2c0:     	movl	%edx, 0x178(%rbp)
14009e2c6:     	movzwl	0x18(%rax), %edx
14009e2ca:     	movw	%dx, 0x17c(%rbp)
14009e2d1:     	movzbl	0x1b(%rax), %edx
14009e2d5:     	movb	%dl, 0x17f(%rbp)
14009e2db:     	movss	0x1c(%rax), %xmm6
14009e2e0:     	movzwl	0x1c(%rax), %eax
14009e2e4:     	movzwl	%ax, %edx
14009e2e7:     	cmpq	$0x1f, %r8
14009e2eb:     	ja	0x14009e340 <.text+0x9d340>
14009e2ed:     	leaq	0x326f0(%rcx), %r9
14009e2f4:     	cmpb	$0x1, (%r9,%r8)
14009e2f9:     	jne	0x14009e340 <.text+0x9d340>
14009e2fb:     	cmpb	$0x0, 0x32710(%rcx,%r8)
14009e304:     	jne	0x14009e340 <.text+0x9d340>
14009e306:     	movb	$0x0, 0x326f0(%rcx,%r8)
14009e30f:     	decq	0x32738(%rcx)
14009e316:     	movq	$0x0, 0x3e5c0(%rcx,%r8,8)
14009e322:     	leaq	(%r8,%r8,8), %r10
14009e326:     	leaq	(%r10,%r10,2), %r10
14009e32a:     	addq	%r8, %r10
14009e32d:     	movb	$0x2, 0x36a(%r9,%r10)
14009e336:     	leaq	(%r8,%r8,2), %r8
14009e33a:     	movb	$0x2, 0x5d(%r9,%r8,8)
14009e340:     	leaq	0x443f0(%rcx), %r12
14009e347:     	addl	$0x2, %edx
14009e34a:     	leaq	0x3f80c(%rcx), %r9
14009e351:     	xorl	%r10d, %r10d
14009e354:     	xorl	%r8d, %r8d
14009e357:     	jmp	0x14009e377 <.text+0x9d377>
14009e359:     	nopl	(%rax)
14009e360:     	movq	%r13, %r11
14009e363:     	incq	%r10
14009e366:     	addq	$0x130, %r9             # imm = 0x130
14009e36d:     	cmpq	$0x40, %r10
14009e371:     	je	0x14009e40c <.text+0x9d40c>
14009e377:     	movq	%r11, %r13
14009e37a:     	cmpl	%edx, (%r12,%r10,4)
14009e37e:     	jne	0x14009e360 <.text+0x9d360>
14009e380:     	movzbl	-0x2(%r9), %r11d
14009e385:     	cmpb	$0x2, %r11b
14009e389:     	je	0x14009e360 <.text+0x9d360>
14009e38b:     	cmpb	%r15b, %r11b
14009e38e:     	jne	0x14009e360 <.text+0x9d360>
14009e390:     	cmpw	%ax, (%r9)
14009e394:     	jne	0x14009e360 <.text+0x9d360>
14009e396:     	cmpl	%edi, -0xc(%r9)
14009e39a:     	jne	0x14009e360 <.text+0x9d360>
14009e39c:     	movl	0x178(%rbp), %r11d
14009e3a3:     	cmpl	%r11d, -0x8(%r9)
14009e3a7:     	jne	0x14009e360 <.text+0x9d360>
14009e3a9:     	movzwl	0x17c(%rbp), %r11d
14009e3b1:     	cmpw	%r11w, -0x4(%r9)
14009e3b6:     	jne	0x14009e360 <.text+0x9d360>
14009e3b8:     	movq	-0x1c(%r9), %r11
14009e3bc:     	xorq	0x168(%rbp), %r11
14009e3c3:     	movq	-0x14(%r9), %rbx
14009e3c7:     	xorq	0x170(%rbp), %rbx
14009e3ce:     	orq	%r11, %rbx
14009e3d1:     	jne	0x14009e360 <.text+0x9d360>
14009e3d3:     	movq	%r10, %r11
14009e3d6:     	cmpq	$0x1, %r8
14009e3da:     	movl	$0x1, %r8d
14009e3e0:     	jne	0x14009e363 <.text+0x9d363>
14009e3e2:     	movb	$0x1, %bl
14009e3e4:     	movq	%r13, %r11
14009e3e7:     	cmpq	$0x3f, %r13
14009e3eb:     	jbe	0x14009e41a <.text+0x9d41a>
14009e3ed:     	jmp	0x14009e440 <.text+0x9d440>
14009e3ef:     	xorl	%eax, %eax
14009e3f1:     	movaps	0x180(%rbp), %xmm6
14009e3f8:     	addq	$0x218, %rsp            # imm = 0x218
14009e3ff:     	popq	%rbx
14009e400:     	popq	%rdi
14009e401:     	popq	%rsi
14009e402:     	popq	%r12
14009e404:     	popq	%r13
14009e406:     	popq	%r14
14009e408:     	popq	%r15
14009e40a:     	popq	%rbp
14009e40b:     	retq
14009e40c:     	cmpq	$0x40, %r11
14009e410:     	setb	%dl
14009e413:     	xorl	%ebx, %ebx
14009e415:     	testb	%dl, %r8b
14009e418:     	je	0x14009e440 <.text+0x9d440>
14009e41a:     	cmpl	$0x0, (%r12,%r11,4)
14009e41f:     	je	0x14009e440 <.text+0x9d440>
14009e421:     	movl	$0x0, 0x443f0(%rcx,%r11,4)
14009e42d:     	decq	0x444f8(%rcx)
14009e434:     	imulq	$0x130, %r11, %rdx      # imm = 0x130
14009e43b:     	movb	$0x2, 0x1a(%rsi,%rdx)
14009e440:     	pxor	%xmm0, %xmm0
14009e444:     	movdqa	%xmm0, 0x150(%rbp)
14009e44c:     	movb	$0x0, 0x132(%rbp)
14009e453:     	movw	%ax, 0x130(%rbp)
14009e45a:     	leaq	0x133(%rbp), %rdx
14009e461:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009e46a:     	movq	$0x0, 0x133(%rbp)
14009e475:     	movq	$0x8, 0x110(%rbp)
14009e480:     	movq	$0x0, 0x118(%rbp)
14009e48b:     	movq	$0x1, 0x120(%rbp)
14009e496:     	movq	$0x0, 0x128(%rbp)
14009e4a1:     	movq	%rdx, 0x30(%rsp)
14009e4a6:     	movw	%ax, 0x28(%rsp)
14009e4ab:     	movq	$0x0, 0x58(%rsp)
14009e4b4:     	movq	$0x1, 0x50(%rsp)
14009e4bd:     	movq	$0x8, 0x48(%rsp)
14009e4c6:     	movq	$0x8, 0x40(%rsp)
14009e4cf:     	movq	$0x0, 0x38(%rsp)
14009e4d8:     	movb	$0x0, 0x20(%rsp)
14009e4dd:     	leaq	0x140(%rbp), %rax
14009e4e4:     	leaq	0x150(%rbp), %rdx
14009e4eb:     	movl	$0x10, %r8d
14009e4f1:     	movq	%rcx, %r13
14009e4f4:     	movq	%rax, %rcx
14009e4f7:     	movb	$0x2, %r9b
14009e4fa:     	callq	0x140005590 <.text+0x4590>
14009e4ff:     	movq	%r13, %rax
14009e502:     	movq	0x148(%rbp), %r13
14009e509:     	cmpq	$0x11, %r13
14009e50d:     	setae	%cl
14009e510:     	orb	%bl, %cl
14009e512:     	orb	0x140(%rbp), %cl
14009e518:     	testb	$0x1, %cl
14009e51b:     	jne	0x14009e527 <.text+0x9d527>
14009e51d:     	cmpq	$0x40, 0x444f8(%rax)
14009e525:     	jne	0x14009e52e <.text+0x9d52e>
14009e527:     	movb	$0x1, %al
14009e529:     	jmp	0x14009e3f1 <.text+0x9d3f1>
14009e52e:     	movq	0x444f0(%rax), %rbx
14009e535:     	cmpq	$0x3f, %rbx
14009e539:     	ja	0x14009e7d9 <.text+0x9d7d9>
14009e53f:     	cmpl	$0x0, (%r12,%rbx,4)
14009e544:     	je	0x14009e5b0 <.text+0x9d5b0>
14009e546:     	leaq	(,%rbx,4), %rdx
14009e54e:     	leaq	(%r12,%rbx,4), %rcx
14009e552:     	xorl	%r8d, %r8d
14009e555:     	movq	%rdx, %r9
14009e558:     	nopl	(%rax,%rax)
14009e560:     	cmpl	$0x0, (%r12,%r9)
14009e565:     	je	0x14009e5a3 <.text+0x9d5a3>
14009e567:     	addq	$0x4, %r9
14009e56b:     	decq	%r8
14009e56e:     	cmpq	$0x100, %r9             # imm = 0x100
14009e575:     	jne	0x14009e560 <.text+0x9d560>
14009e577:     	testq	%rbx, %rbx
14009e57a:     	je	0x14009e527 <.text+0x9d527>
14009e57c:     	addq	$-0x4, %rdx
14009e580:     	cmpq	$0xc, %rdx
14009e584:     	jae	0x14009e71d <.text+0x9d71d>
14009e58a:     	xorl	%ebx, %ebx
14009e58c:     	movq	%r12, %r9
14009e58f:     	cmpl	$0x0, (%r9)
14009e593:     	je	0x14009e5a6 <.text+0x9d5a6>
14009e595:     	addq	$0x4, %r9
14009e599:     	incq	%rbx
14009e59c:     	cmpq	%rcx, %r9
14009e59f:     	jne	0x14009e58f <.text+0x9d58f>
14009e5a1:     	jmp	0x14009e527 <.text+0x9d527>
14009e5a3:     	subq	%r8, %rbx
14009e5a6:     	cmpq	$0x40, %rbx
14009e5aa:     	jae	0x14009e7c3 <.text+0x9d7c3>
14009e5b0:     	movl	$0x1, 0x443f0(%rax,%rbx,4)
14009e5bb:     	incq	0x444f8(%rax)
14009e5c2:     	leaq	0x1(%rbx), %rcx
14009e5c6:     	xorl	%edx, %edx
14009e5c8:     	cmpq	$0x40, %rcx
14009e5cc:     	cmovneq	%rcx, %rdx
14009e5d0:     	movq	%rdx, 0x444f0(%rax)
14009e5d7:     	movq	0x170(%rbp), %rax
14009e5de:     	movq	%rax, -0x18(%rbp)
14009e5e2:     	movq	0x168(%rbp), %rax
14009e5e9:     	movq	%rax, -0x20(%rbp)
14009e5ed:     	movl	%edi, -0x10(%rbp)
14009e5f0:     	movl	0x178(%rbp), %eax
14009e5f6:     	movl	%eax, -0xc(%rbp)
14009e5f9:     	movzwl	0x17c(%rbp), %eax
14009e600:     	movw	%ax, -0x8(%rbp)
14009e604:     	movb	%r15b, -0x6(%rbp)
14009e608:     	movzbl	0x17f(%rbp), %eax
14009e60f:     	movb	%al, -0x5(%rbp)
14009e612:     	movss	%xmm6, -0x4(%rbp)
14009e617:     	movq	%r14, (%rbp)
14009e61b:     	testq	%r13, %r13
14009e61e:     	je	0x14009e682 <.text+0x9d682>
14009e620:     	movb	$0x1, 0x8(%rbp)
14009e624:     	movb	%r13b, 0x9(%rbp)
14009e628:     	leaq	0xa(%rbp), %r14
14009e62c:     	movl	$0x80, %r8d
14009e632:     	subq	%r13, %r8
14009e635:     	leaq	0xa(,%r13), %rcx
14009e63d:     	addq	%rbp, %rcx
14009e640:     	xorl	%edx, %edx
14009e642:     	callq	0x140251e22 <.text+0x250e22>
14009e647:     	leaq	0x150(%rbp), %rdx
14009e64e:     	movq	%r14, %rcx
14009e651:     	movq	%r13, %r8
14009e654:     	callq	0x140251e10 <.text+0x250e10>
14009e659:     	movzwl	-0x4(%rbp), %eax
14009e65d:     	addl	$0x2, %eax
14009e660:     	movl	%eax, (%r12,%rbx,4)
14009e664:     	imulq	$0x130, %rbx, %rax      # imm = 0x130
14009e66b:     	addq	%rax, %rsi
14009e66e:     	movzbl	0x8(%rbp), %eax
14009e672:     	leaq	0x1d2bd7(%rip), %rcx    # 0x140271250
14009e679:     	movslq	(%rcx,%rax,4), %rax
14009e67d:     	addq	%rcx, %rax
14009e680:     	jmpq	*%rax
14009e682:     	movb	$0x0, 0x8(%rbp)
14009e686:     	movzwl	-0x4(%rbp), %eax
14009e68a:     	addl	$0x2, %eax
14009e68d:     	movl	%eax, (%r12,%rbx,4)
14009e691:     	imulq	$0x130, %rbx, %rax      # imm = 0x130
14009e698:     	addq	%rax, %rsi
14009e69b:     	movzbl	0x8(%rbp), %eax
14009e69f:     	leaq	0x1d2baa(%rip), %rcx    # 0x140271250
14009e6a6:     	movslq	(%rcx,%rax,4), %rax
14009e6aa:     	addq	%rcx, %rax
14009e6ad:     	jmpq	*%rax
14009e6af:     	movdqa	-0x20(%rbp), %xmm0
14009e6b4:     	movdqa	-0x10(%rbp), %xmm1
14009e6b9:     	movdqu	%xmm1, 0x10(%rsi)
14009e6be:     	movdqu	%xmm0, (%rsi)
14009e6c2:     	movb	$0x0, 0x28(%rsi)
14009e6c6:     	movq	(%rbp), %rax
14009e6ca:     	movq	%rax, 0x20(%rsi)
14009e6ce:     	jmp	0x14009e527 <.text+0x9d527>
14009e6d3:     	leaq	-0x20(%rbp), %rdx
14009e6d7:     	movl	$0x130, %r8d            # imm = 0x130
14009e6dd:     	movq	%rsi, %rcx
14009e6e0:     	callq	0x140251e10 <.text+0x250e10>
14009e6e5:     	jmp	0x14009e527 <.text+0x9d527>
14009e6ea:     	movq	(%rbp), %r8
14009e6ee:     	movq	0x10(%rbp), %r9
14009e6f2:     	leaq	-0x20(%rbp), %rdx
14009e6f6:     	movq	%rsi, %rcx
14009e6f9:     	callq	0x14000b2d0 <.text+0xa2d0>
14009e6fe:     	jmp	0x14009e527 <.text+0x9d527>
14009e703:     	leaq	0xa(%rbp), %r8
14009e707:     	movzbl	0x9(%rbp), %r9d
14009e70c:     	leaq	-0x20(%rbp), %rdx
14009e710:     	movq	%rsi, %rcx
14009e713:     	callq	0x14000b1c0 <.text+0xa1c0>
14009e718:     	jmp	0x14009e527 <.text+0x9d527>
14009e71d:     	shrq	$0x2, %rdx
14009e721:     	incq	%rdx
14009e724:     	movq	%rdx, %rbx
14009e727:     	andq	$-0x4, %rbx
14009e72b:     	leaq	(%r12,%rbx,4), %r9
14009e72f:     	xorl	%r8d, %r8d
14009e732:     	pxor	%xmm1, %xmm1
14009e736:     	movdqu	(%r12,%r8,4), %xmm0
14009e73c:     	movdqa	%xmm0, %xmm2
14009e740:     	pcmpeqd	%xmm1, %xmm2
14009e744:     	movmskps	%xmm2, %r10d
14009e748:     	testl	%r10d, %r10d
14009e74b:     	jne	0x14009e764 <.text+0x9d764>
14009e74d:     	addq	$0x4, %r8
14009e751:     	cmpq	%r8, %rbx
14009e754:     	jne	0x14009e736 <.text+0x9d736>
14009e756:     	cmpq	%rbx, %rdx
14009e759:     	jne	0x14009e58f <.text+0x9d58f>
14009e75f:     	jmp	0x14009e527 <.text+0x9d527>
14009e764:     	pxor	%xmm1, %xmm1
14009e768:     	pcmpeqd	%xmm1, %xmm0
14009e76c:     	pand	0x1c661c(%rip), %xmm0   # 0x140264d90
14009e774:     	movdqa	0x1c4514(%rip), %xmm1   # 0x140262c90
14009e77c:     	movdqa	%xmm0, %xmm2
14009e780:     	por	%xmm1, %xmm2
14009e784:     	pshufd	$0xee, %xmm0, %xmm3     # xmm3 = xmm0[2,3,2,3]
14009e789:     	por	%xmm3, %xmm1
14009e78d:     	pcmpgtd	%xmm1, %xmm2
14009e791:     	pand	%xmm2, %xmm0
14009e795:     	pandn	%xmm3, %xmm2
14009e799:     	por	%xmm0, %xmm2
14009e79d:     	movd	%xmm2, %ecx
14009e7a1:     	pshufd	$0x55, %xmm2, %xmm0     # xmm0 = xmm2[1,1,1,1]
14009e7a6:     	movd	%xmm0, %edx
14009e7aa:     	cmpl	%edx, %ecx
14009e7ac:     	cmoval	%ecx, %edx
14009e7af:     	movl	$0x4, %ebx
14009e7b4:     	subl	%edx, %ebx
14009e7b6:     	addq	%r8, %rbx
14009e7b9:     	cmpq	$0x40, %rbx
14009e7bd:     	jb	0x14009e5b0 <.text+0x9d5b0>
14009e7c3:     	leaq	0x1cf5ee(%rip), %r8     # 0x14026ddb8
14009e7ca:     	movl	$0x40, %edx
14009e7cf:     	movq	%rbx, %rcx
14009e7d2:     	callq	0x140252693 <.text+0x251693>
14009e7d7:     	ud2
14009e7d9:     	leaq	0x1cf5c0(%rip), %r8     # 0x14026dda0
14009e7e0:     	movl	$0x40, %edx
14009e7e5:     	movq	%rbx, %rcx
14009e7e8:     	callq	0x140252693 <.text+0x251693>
14009e7ed:     	ud2


D:\CoapticCurrent\replay-scratch-original-inbox-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
1400674b0:     	pushq	%rbp
1400674b1:     	pushq	%r15
1400674b3:     	pushq	%r14
1400674b5:     	pushq	%r13
1400674b7:     	pushq	%r12
1400674b9:     	pushq	%rsi
1400674ba:     	pushq	%rdi
1400674bb:     	pushq	%rbx
1400674bc:     	subq	$0x4f8, %rsp            # imm = 0x4F8
1400674c3:     	leaq	0x80(%rsp), %rbp
1400674cb:     	movq	0x4f0(%rbp), %r12
1400674d2:     	movq	0x8(%r12), %rdi
1400674d7:     	movl	$0x3, %r10d
1400674dd:     	cmpq	$0x3, %rdi
1400674e1:     	ja	0x1400675c3 <.text+0x665c3>
1400674e7:     	cmpb	$0x1, 0x166f8(%rdx,%rdi)
1400674ef:     	jne	0x1400675c3 <.text+0x665c3>
1400674f5:     	movq	0x26700(%rdx,%rdi,8), %rax
1400674fd:     	cmpq	$0x4001, %rax           # imm = 0x4001
140067503:     	jae	0x140067795 <.text+0x66795>
140067509:     	movq	0x10(%r12), %r11
14006750e:     	movq	0x18(%r12), %r15
140067513:     	movq	%r15, %rsi
140067516:     	movl	$0xb, %r10d
14006751c:     	addq	%r11, %rsi
14006751f:     	jb	0x1400675c3 <.text+0x665c3>
140067525:     	cmpq	$0x400, %r15            # imm = 0x400
14006752c:     	ja	0x1400675c3 <.text+0x665c3>
140067532:     	cmpq	%rax, %rsi
140067535:     	ja	0x1400675c3 <.text+0x665c3>
14006753b:     	movq	%r8, %r13
14006753e:     	movq	%r9, 0x460(%rbp)
140067545:     	movq	%rcx, 0x470(%rbp)
14006754c:     	movzbl	0x4f8(%rbp), %r14d
140067554:     	movq	%rdi, %rax
140067557:     	shlq	$0xe, %rax
14006755b:     	movq	%rdx, %rsi
14006755e:     	leaq	(%rdx,%rax), %rbx
140067562:     	addq	$0x16700, %rbx          # imm = 0x16700
140067569:     	addq	%r11, %rbx
14006756c:     	movl	$0x400, %r8d            # imm = 0x400
140067572:     	cmpq	$0x400, %r15            # imm = 0x400
140067579:     	je	0x140067589 <.text+0x66589>
14006757b:     	leaq	-0x10(%rbp), %rcx
14006757f:     	xorl	%edx, %edx
140067581:     	callq	0x140251e22 <.text+0x250e22>
140067586:     	movq	%r15, %r8
140067589:     	leaq	-0x10(%rbp), %rcx
14006758d:     	movq	%rbx, %rdx
140067590:     	callq	0x140251e10 <.text+0x250e10>
140067595:     	testb	%r14b, %r14b
140067598:     	je	0x1400675de <.text+0x665de>
14006759a:     	imulq	$0x2b0, %rdi, %rax      # imm = 0x2B0
1400675a1:     	movq	%rsi, %rcx
1400675a4:     	cmpq	$0x2, 0x15c28(%rsi,%rax)
1400675ad:     	jne	0x14006774a <.text+0x6674a>
1400675b3:     	xorl	%edi, %edi
1400675b5:     	callq	0x140099ed0 <.text+0x98ed0>
1400675ba:     	testb	$0x1, %al
1400675bc:     	jne	0x1400675f0 <.text+0x665f0>
1400675be:     	jmp	0x140067773 <.text+0x66773>
1400675c3:     	movb	$0xa, (%rcx)
1400675c6:     	movq	%r10, 0x8(%rcx)
1400675ca:     	addq	$0x4f8, %rsp            # imm = 0x4F8
1400675d1:     	popq	%rbx
1400675d2:     	popq	%rdi
1400675d3:     	popq	%rsi
1400675d4:     	popq	%r12
1400675d6:     	popq	%r13
1400675d8:     	popq	%r14
1400675da:     	popq	%r15
1400675dc:     	popq	%rbp
1400675dd:     	retq
1400675de:     	xorl	%edi, %edi
1400675e0:     	movq	%rsi, %rcx
1400675e3:     	callq	0x140099ed0 <.text+0x98ed0>
1400675e8:     	testb	$0x1, %al
1400675ea:     	je	0x140067773 <.text+0x66773>
1400675f0:     	movq	%rdx, %rbx
1400675f3:     	movq	0x500(%rbp), %rdx
1400675fa:     	movzwl	0x4e8(%rbp), %ecx
140067601:     	movzbl	0x4e0(%rbp), %eax
140067608:     	movq	(%r12), %r8
14006760c:     	movq	%rdi, 0x430(%rbp)
140067613:     	movq	0x468(%rbp), %r9
14006761a:     	movq	%r9, 0x438(%rbp)
140067621:     	movq	%r8, 0x440(%rbp)
140067628:     	movb	%r14b, 0x448(%rbp)
14006762f:     	movups	0x60(%r13), %xmm0
140067634:     	movups	0x6c(%r13), %xmm1
140067639:     	movups	%xmm1, 0x3fc(%rbp)
140067640:     	movaps	%xmm0, 0x3f0(%rbp)
140067647:     	leaq	0x8e(%r13), %r8
14006764e:     	movq	0x7e(%r13), %r9
140067652:     	movq	0x85(%r13), %r10
140067659:     	movq	%r10, 0x457(%rbp)
140067660:     	movq	%r9, 0x450(%rbp)
140067667:     	leaq	0x450(%rbp), %r9
14006766e:     	movq	%r9, 0x68(%rsp)
140067673:     	movq	%rdx, 0x60(%rsp)
140067678:     	movq	%r13, 0x58(%rsp)
14006767d:     	leaq	0x430(%rbp), %rdx
140067684:     	movq	%rdx, 0x50(%rsp)
140067689:     	movq	%r15, 0x48(%rsp)
14006768e:     	leaq	-0x10(%rbp), %rdx
140067692:     	movq	%rdx, 0x40(%rsp)
140067697:     	movq	0x460(%rbp), %rdx
14006769e:     	movq	%rdx, 0x38(%rsp)
1400676a3:     	movq	%r8, 0x30(%rsp)
1400676a8:     	movw	%cx, 0x28(%rsp)
1400676ad:     	movb	%al, 0x20(%rsp)
1400676b1:     	leaq	0x410(%rbp), %rcx
1400676b8:     	leaq	0x3f0(%rbp), %r8
1400676bf:     	movq	%rsi, %rdx
1400676c2:     	movq	%rbx, %r9
1400676c5:     	callq	0x1400818f0 <.text+0x808f0>
1400676ca:     	cmpb	$-0x1, 0x410(%rbp)
1400676d1:     	je	0x140067782 <.text+0x66782>
1400676d7:     	cmpb	$0x1, 0x326f0(%rsi,%rbx)
1400676df:     	movq	0x470(%rbp), %rax
1400676e6:     	jne	0x140067730 <.text+0x66730>
1400676e8:     	cmpb	$0x0, 0x32710(%rsi,%rbx)
1400676f0:     	jne	0x140067730 <.text+0x66730>
1400676f2:     	movb	$0x0, 0x326f0(%rsi,%rbx)
1400676fa:     	decq	0x32738(%rsi)
140067701:     	leaq	0x326f0(%rsi), %rcx
140067708:     	movq	$0x0, 0x3e5c0(%rsi,%rbx,8)
140067714:     	leaq	(%rbx,%rbx,8), %rdx
140067718:     	leaq	(%rdx,%rdx,2), %rdx
14006771c:     	addq	%rbx, %rdx
14006771f:     	movb	$0x2, 0x36a(%rcx,%rdx)
140067727:     	leaq	(%rbx,%rbx,2), %rdx
14006772b:     	movb	$0x2, 0x5d(%rcx,%rdx,8)
140067730:     	movups	0x410(%rbp), %xmm0
140067737:     	movups	0x420(%rbp), %xmm1
14006773e:     	movups	%xmm1, 0x10(%rax)
140067742:     	movups	%xmm0, (%rax)
140067745:     	jmp	0x1400675ca <.text+0x665ca>
14006774a:     	addq	%rcx, %rax
14006774d:     	addq	$0x15c28, %rax          # imm = 0x15C28
140067753:     	movq	0x98(%rax), %rax
14006775a:     	movq	%rax, 0x468(%rbp)
140067761:     	movl	$0x1, %edi
140067766:     	callq	0x140099ed0 <.text+0x98ed0>
14006776b:     	testb	$0x1, %al
14006776d:     	jne	0x1400675f0 <.text+0x665f0>
140067773:     	movq	0x470(%rbp), %rax
14006777a:     	movb	$0x9, (%rax)
14006777d:     	jmp	0x1400675ca <.text+0x665ca>
140067782:     	movq	0x470(%rbp), %rax
140067789:     	movq	%rbx, 0x8(%rax)
14006778d:     	movb	$-0x1, (%rax)
140067790:     	jmp	0x1400675ca <.text+0x665ca>
140067795:     	leaq	0x2064b4(%rip), %r9     # 0x14026dc50
14006779c:     	movl	$0x4000, %r8d           # imm = 0x4000
1400677a2:     	xorl	%ecx, %ecx
1400677a4:     	movq	%rax, %rdx
1400677a7:     	callq	0x1402528a0 <.text+0x2518a0>
1400677ac:     	ud2

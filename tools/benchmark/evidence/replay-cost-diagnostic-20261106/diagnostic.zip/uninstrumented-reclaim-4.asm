
D:\CoapticCurrent\replay-occupancy-index-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009ed30:     	pushq	%rbp
14009ed31:     	pushq	%r15
14009ed33:     	pushq	%r14
14009ed35:     	pushq	%r13
14009ed37:     	pushq	%r12
14009ed39:     	pushq	%rsi
14009ed3a:     	pushq	%rdi
14009ed3b:     	pushq	%rbx
14009ed3c:     	subq	$0x1f8, %rsp            # imm = 0x1F8
14009ed43:     	leaq	0x80(%rsp), %rbp
14009ed4b:     	movdqa	%xmm6, 0x160(%rbp)
14009ed53:     	movq	0xe8(%rcx), %rax
14009ed5a:     	testq	%rax, %rax
14009ed5d:     	je	0x14009f100 <.text+0x9e100>
14009ed63:     	movq	0x88(%rcx), %rdx
14009ed6a:     	movq	%rdx, 0x128(%rbp)
14009ed71:     	leaq	0xc0(%rcx), %rdx
14009ed78:     	movq	%rdx, 0x148(%rbp)
14009ed7f:     	movq	0xe0(%rcx), %r8
14009ed86:     	movq	0xc8(%rcx), %rdx
14009ed8d:     	movq	0xd0(%rcx), %r9
14009ed94:     	leaq	0x128(%rdx), %r11
14009ed9b:     	movw	$0xffff, %di            # imm = 0xFFFF
14009ed9f:     	xorl	%r13d, %r13d
14009eda2:     	imulq	$0x130, %r13, %r12      # imm = 0x130
14009eda9:     	movq	%r11, %rsi
14009edac:     	addq	%r11, %r12
14009edaf:     	jmp	0x14009edd3 <.text+0x9ddd3>
14009edb1:     	nopw	%cs:(%rax,%rax)
14009edc0:     	incq	%r13
14009edc3:     	addq	$0x130, %r12            # imm = 0x130
14009edca:     	cmpq	%rax, %r13
14009edcd:     	jae	0x14009eea9 <.text+0x9dea9>
14009edd3:     	cmpq	%rax, %r13
14009edd6:     	jae	0x14009edc0 <.text+0x9ddc0>
14009edd8:     	cmpl	$0x0, (%r8,%r13,4)
14009eddd:     	setne	%r10b
14009ede1:     	cmpq	%r9, %r13
14009ede4:     	setb	%r11b
14009ede8:     	andb	%r10b, %r11b
14009edeb:     	cmpb	$0x1, %r11b
14009edef:     	jne	0x14009edc0 <.text+0x9ddc0>
14009edf1:     	movzwl	-0x128(%r12), %r10d
14009edfa:     	cmpw	$-0x1, %r10w
14009edff:     	je	0x14009edc0 <.text+0x9ddc0>
14009ee01:     	movq	(%r12), %r11
14009ee05:     	cmpw	$0x2, %r10w
14009ee0a:     	setne	%r10b
14009ee0e:     	testq	%r11, %r11
14009ee11:     	sete	%r15b
14009ee15:     	orb	%r10b, %r15b
14009ee18:     	cmpb	$0x1, %r15b
14009ee1c:     	je	0x14009edc0 <.text+0x9ddc0>
14009ee1e:     	cmpw	$-0x1, %di
14009ee22:     	je	0x14009ee2d <.text+0x9de2d>
14009ee24:     	cmpq	0x150(%rbp), %r11
14009ee2b:     	jae	0x14009ee98 <.text+0x9de98>
14009ee2d:     	movl	-0x10(%r12), %ebx
14009ee32:     	movl	-0xc(%r12), %r14d
14009ee37:     	movzwl	-0x8(%r12), %r10d
14009ee3d:     	movw	%r10w, 0x15c(%rbp)
14009ee45:     	movzbl	-0x6(%r12), %r10d
14009ee4b:     	movb	%r10b, 0x15e(%rbp)
14009ee52:     	movzbl	-0x5(%r12), %r10d
14009ee58:     	movb	%r10b, 0x15f(%rbp)
14009ee5f:     	movd	-0x4(%r12), %xmm6
14009ee66:     	movq	-0x120(%r12), %r10
14009ee6e:     	movq	%r10, 0x130(%rbp)
14009ee75:     	movq	-0x20(%r12), %r10
14009ee7a:     	movq	%r10, 0x138(%rbp)
14009ee81:     	movq	-0x18(%r12), %r10
14009ee86:     	movq	%r10, 0x140(%rbp)
14009ee8d:     	movw	$0x2, %di
14009ee91:     	movq	%r11, 0x150(%rbp)
14009ee98:     	incq	%r13
14009ee9b:     	cmpq	%rax, %r13
14009ee9e:     	movq	%rsi, %r11
14009eea1:     	jb	0x14009eda2 <.text+0x9dda2>
14009eea7:     	jmp	0x14009eeb3 <.text+0x9deb3>
14009eea9:     	cmpw	$-0x1, %di
14009eead:     	je	0x14009f100 <.text+0x9e100>
14009eeb3:     	cmpw	$0x2, %di
14009eeb7:     	movq	0x130(%rbp), %rdi
14009eebe:     	jne	0x14009ef1d <.text+0x9df1d>
14009eec0:     	cmpq	0x128(%rbp), %rdi
14009eec7:     	jae	0x14009ef1d <.text+0x9df1d>
14009eec9:     	movq	0x80(%rcx), %r10
14009eed0:     	cmpb	$0x1, (%r10,%rdi)
14009eed5:     	jne	0x14009ef1d <.text+0x9df1d>
14009eed7:     	cmpq	0xa0(%rcx), %rdi
14009eede:     	jae	0x14009eeee <.text+0x9deee>
14009eee0:     	movq	0x98(%rcx), %r11
14009eee7:     	cmpb	$0x0, (%r11,%rdi)
14009eeec:     	jne	0x14009ef1d <.text+0x9df1d>
14009eeee:     	movb	$0x0, (%r10,%rdi)
14009eef3:     	decq	0xb0(%rcx)
14009eefa:     	cmpq	0x70(%rcx), %rdi
14009eefe:     	jae	0x14009ef1d <.text+0x9df1d>
14009ef00:     	movq	0x68(%rcx), %r10
14009ef04:     	imulq	$0x58, %rdi, %r11
14009ef08:     	movq	$0x0, 0x30(%r10,%r11)
14009ef11:     	movb	$0x2, 0x52(%r10,%r11)
14009ef17:     	movb	$0x2, 0x25(%r10,%r11)
14009ef1d:     	movd	%xmm6, %r10d
14009ef22:     	movzwl	%r10w, %edi
14009ef26:     	addl	$0x2, %edi
14009ef29:     	addq	$0x124, %rdx            # imm = 0x124
14009ef30:     	xorl	%r11d, %r11d
14009ef33:     	movzbl	0x15e(%rbp), %r15d
14009ef3b:     	movzwl	0x15c(%rbp), %esi
14009ef42:     	jmp	0x14009ef5f <.text+0x9df5f>
14009ef44:     	nopw	%cs:(%rax,%rax)
14009ef50:     	incq	%r11
14009ef53:     	addq	$0x130, %rdx            # imm = 0x130
14009ef5a:     	cmpq	%r11, %rax
14009ef5d:     	je	0x14009efd6 <.text+0x9dfd6>
14009ef5f:     	cmpl	%edi, (%r8,%r11,4)
14009ef63:     	sete	%r12b
14009ef67:     	cmpq	%r9, %r11
14009ef6a:     	setb	%r13b
14009ef6e:     	andb	%r12b, %r13b
14009ef71:     	cmpb	$0x1, %r13b
14009ef75:     	jne	0x14009ef50 <.text+0x9df50>
14009ef77:     	cmpw	$-0x1, -0x124(%rdx)
14009ef7f:     	je	0x14009ef50 <.text+0x9df50>
14009ef81:     	cmpw	%r10w, (%rdx)
14009ef85:     	jne	0x14009ef50 <.text+0x9df50>
14009ef87:     	cmpl	%ebx, -0xc(%rdx)
14009ef8a:     	jne	0x14009ef50 <.text+0x9df50>
14009ef8c:     	cmpl	%r14d, -0x8(%rdx)
14009ef90:     	jne	0x14009ef50 <.text+0x9df50>
14009ef92:     	cmpw	%si, -0x4(%rdx)
14009ef96:     	jne	0x14009ef50 <.text+0x9df50>
14009ef98:     	cmpb	%r15b, -0x2(%rdx)
14009ef9c:     	jne	0x14009ef50 <.text+0x9df50>
14009ef9e:     	movq	-0x1c(%rdx), %r12
14009efa2:     	xorq	0x138(%rbp), %r12
14009efa9:     	movq	-0x14(%rdx), %r13
14009efad:     	xorq	0x140(%rbp), %r13
14009efb4:     	orq	%r12, %r13
14009efb7:     	jne	0x14009ef50 <.text+0x9df50>
14009efb9:     	cmpq	%rax, %r11
14009efbc:     	jae	0x14009efd6 <.text+0x9dfd6>
14009efbe:     	movl	$0x0, (%r8,%r11,4)
14009efc6:     	decq	0xf8(%rcx)
14009efcd:     	movw	$0xffff, -0x124(%rdx)   # imm = 0xFFFF
14009efd6:     	xorps	%xmm0, %xmm0
14009efd9:     	movaps	%xmm0, 0x110(%rbp)
14009efe0:     	movb	$0x0, 0xf2(%rbp)
14009efe7:     	movw	%r10w, 0xf0(%rbp)
14009efef:     	movw	$0x200, 0xfb(%rbp)      # imm = 0x200
14009eff8:     	movq	$0x0, 0xf3(%rbp)
14009f003:     	movq	$0x8, 0xd0(%rbp)
14009f00e:     	movq	$0x0, 0xd8(%rbp)
14009f019:     	movq	$0x1, 0xe0(%rbp)
14009f024:     	movq	$0x0, 0xe8(%rbp)
14009f02f:     	leaq	0x100(%rbp), %rcx
14009f036:     	leaq	0xd0(%rbp), %rdx
14009f03d:     	leaq	0x110(%rbp), %r8
14009f044:     	movl	$0x10, %r9d
14009f04a:     	callq	0x140111d70 <.text+0x110d70>
14009f04f:     	cmpb	$0x0, 0x100(%rbp)
14009f056:     	jne	0x14009f11a <.text+0x9e11a>
14009f05c:     	movq	0x108(%rbp), %rdi
14009f063:     	movq	0x138(%rbp), %rax
14009f06a:     	movq	%rax, 0xa8(%rbp)
14009f071:     	movq	0x140(%rbp), %rax
14009f078:     	movq	%rax, 0xb0(%rbp)
14009f07f:     	movl	%ebx, 0xb8(%rbp)
14009f085:     	movl	%r14d, 0xbc(%rbp)
14009f08c:     	movw	%si, 0xc0(%rbp)
14009f093:     	movb	%r15b, 0xc2(%rbp)
14009f09a:     	movzbl	0x15f(%rbp), %eax
14009f0a1:     	movb	%al, 0xc3(%rbp)
14009f0a7:     	movd	%xmm6, 0xc4(%rbp)
14009f0af:     	movq	0x150(%rbp), %rax
14009f0b6:     	movq	%rax, 0xc8(%rbp)
14009f0bd:     	cmpq	$0x11, %rdi
14009f0c1:     	jae	0x14009f137 <.text+0x9e137>
14009f0c3:     	testq	%rdi, %rdi
14009f0c6:     	je	0x14009f104 <.text+0x9e104>
14009f0c8:     	movw	%di, -0x5e(%rbp)
14009f0cc:     	leaq	-0x5c(%rbp), %rbx
14009f0d0:     	movl	$0x100, %r8d            # imm = 0x100
14009f0d6:     	subq	%rdi, %r8
14009f0d9:     	leaq	(%rdi,%rbp), %rcx
14009f0dd:     	addq	$-0x5c, %rcx
14009f0e1:     	xorl	%edx, %edx
14009f0e3:     	callq	0x140250d72 <.text+0x24fd72>
14009f0e8:     	leaq	0x110(%rbp), %rdx
14009f0ef:     	movq	%rbx, %rcx
14009f0f2:     	movq	%rdi, %r8
14009f0f5:     	callq	0x140250d60 <.text+0x24fd60>
14009f0fa:     	movw	$0x1, %ax
14009f0fe:     	jmp	0x14009f106 <.text+0x9e106>
14009f100:     	xorl	%eax, %eax
14009f102:     	jmp	0x14009f11c <.text+0x9e11c>
14009f104:     	xorl	%eax, %eax
14009f106:     	movq	0x148(%rbp), %rcx
14009f10d:     	movw	%ax, -0x60(%rbp)
14009f111:     	leaq	-0x60(%rbp), %rdx
14009f115:     	callq	0x1400118b0 <.text+0x108b0>
14009f11a:     	movb	$0x1, %al
14009f11c:     	movaps	0x160(%rbp), %xmm6
14009f123:     	addq	$0x1f8, %rsp            # imm = 0x1F8
14009f12a:     	popq	%rbx
14009f12b:     	popq	%rdi
14009f12c:     	popq	%rsi
14009f12d:     	popq	%r12
14009f12f:     	popq	%r13
14009f131:     	popq	%r14
14009f133:     	popq	%r15
14009f135:     	popq	%rbp
14009f136:     	retq
14009f137:     	leaq	0x1c9a6a(%rip), %r9     # 0x140268ba8
14009f13e:     	movl	$0x10, %r8d
14009f144:     	xorl	%ecx, %ecx
14009f146:     	movq	%rdi, %rdx
14009f149:     	callq	0x1402517f0 <.text+0x2507f0>
14009f14e:     	ud2

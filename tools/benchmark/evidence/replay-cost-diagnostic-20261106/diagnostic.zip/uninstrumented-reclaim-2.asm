
D:\CoapticCurrent\replay-occupancy-index-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009e630:     	pushq	%rbp
14009e631:     	pushq	%r15
14009e633:     	pushq	%r14
14009e635:     	pushq	%r13
14009e637:     	pushq	%r12
14009e639:     	pushq	%rsi
14009e63a:     	pushq	%rdi
14009e63b:     	pushq	%rbx
14009e63c:     	subq	$0x1e8, %rsp            # imm = 0x1E8
14009e643:     	leaq	0x80(%rsp), %rbp
14009e64b:     	movaps	%xmm6, 0x150(%rbp)
14009e652:     	leaq	0x2ac8(%rcx), %rsi
14009e659:     	leaq	0x2bf0(%rcx), %r8
14009e660:     	movw	$0xffff, %dx            # imm = 0xFFFF
14009e664:     	xorl	%r11d, %r11d
14009e667:     	imulq	$0x130, %r11, %r10      # imm = 0x130
14009e66e:     	addq	%r8, %r10
14009e671:     	movq	%r11, %r9
14009e674:     	jmp	0x14009e694 <.text+0x9d694>
14009e676:     	nopw	%cs:(%rax,%rax)
14009e680:     	incq	%r9
14009e683:     	addq	$0x130, %r10            # imm = 0x130
14009e68a:     	cmpq	$0x4, %r9
14009e68e:     	je	0x14009e755 <.text+0x9d755>
14009e694:     	cmpl	$0x0, 0x4c0(%rsi,%r9,4)
14009e69d:     	je	0x14009e680 <.text+0x9d680>
14009e69f:     	movzwl	-0x128(%r10), %edi
14009e6a7:     	cmpw	$-0x1, %di
14009e6ab:     	je	0x14009e680 <.text+0x9d680>
14009e6ad:     	movq	(%r10), %r11
14009e6b0:     	cmpw	$0x2, %di
14009e6b4:     	setne	%dil
14009e6b8:     	testq	%r11, %r11
14009e6bb:     	movl	%r13d, %eax
14009e6be:     	movl	%r12d, %r13d
14009e6c1:     	movl	%r15d, %r12d
14009e6c4:     	movl	%r14d, %r15d
14009e6c7:     	movl	%ebx, %r14d
14009e6ca:     	sete	%bl
14009e6cd:     	orb	%dil, %bl
14009e6d0:     	cmpb	$0x1, %bl
14009e6d3:     	movl	%r14d, %ebx
14009e6d6:     	movl	%r15d, %r14d
14009e6d9:     	movl	%r12d, %r15d
14009e6dc:     	movl	%r13d, %r12d
14009e6df:     	movl	%eax, %r13d
14009e6e2:     	je	0x14009e680 <.text+0x9d680>
14009e6e4:     	cmpw	$-0x1, %dx
14009e6e8:     	je	0x14009e703 <.text+0x9d703>
14009e6ea:     	cmpq	0x148(%rbp), %r11
14009e6f1:     	jb	0x14009e703 <.text+0x9d703>
14009e6f3:     	leaq	0x1(%r9), %r11
14009e6f7:     	cmpq	$0x3, %r9
14009e6fb:     	jb	0x14009e667 <.text+0x9d667>
14009e701:     	jmp	0x14009e75f <.text+0x9d75f>
14009e703:     	movq	-0x120(%r10), %rax
14009e70a:     	movq	%rax, 0x108(%rbp)
14009e711:     	movd	-0x4(%r10), %xmm6
14009e717:     	movzbl	-0x5(%r10), %ebx
14009e71c:     	movzbl	-0x6(%r10), %r14d
14009e721:     	movzwl	-0x8(%r10), %r15d
14009e726:     	movl	-0xc(%r10), %r12d
14009e72a:     	movl	-0x10(%r10), %r13d
14009e72e:     	movups	-0x20(%r10), %xmm0
14009e733:     	movaps	%xmm0, 0xe0(%rbp)
14009e73a:     	movw	$0x2, %dx
14009e73e:     	movq	%r11, 0x148(%rbp)
14009e745:     	leaq	0x1(%r9), %r11
14009e749:     	cmpq	$0x3, %r9
14009e74d:     	jb	0x14009e667 <.text+0x9d667>
14009e753:     	jmp	0x14009e75f <.text+0x9d75f>
14009e755:     	cmpw	$-0x1, %dx
14009e759:     	je	0x14009e929 <.text+0x9d929>
14009e75f:     	cmpw	$0x2, %dx
14009e763:     	movq	0x108(%rbp), %rax
14009e76a:     	jne	0x14009e7c7 <.text+0x9d7c7>
14009e76c:     	cmpq	$0x1, %rax
14009e770:     	ja	0x14009e7c7 <.text+0x9d7c7>
14009e772:     	cmpb	$0x1, 0x43e8(%rcx,%rax)
14009e77a:     	jne	0x14009e7c7 <.text+0x9d7c7>
14009e77c:     	cmpb	$0x0, 0x43ea(%rcx,%rax)
14009e784:     	jne	0x14009e7c7 <.text+0x9d7c7>
14009e786:     	movb	$0x0, 0x43e8(%rcx,%rax)
14009e78e:     	decq	0x43e0(%rcx)
14009e795:     	leaq	0x3a60(%rcx), %rdx
14009e79c:     	movq	$0x0, 0x4360(%rcx,%rax,8)
14009e7a8:     	leaq	(%rax,%rax,8), %rcx
14009e7ac:     	leaq	(%rcx,%rcx,2), %rcx
14009e7b0:     	addq	%rax, %rcx
14009e7b3:     	movb	$0x2, 0x95a(%rdx,%rcx)
14009e7bb:     	leaq	(%rax,%rax,2), %rax
14009e7bf:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009e7c7:     	movaps	0xe0(%rbp), %xmm0
14009e7ce:     	movaps	%xmm0, 0x110(%rbp)
14009e7d5:     	movl	%r13d, 0x120(%rbp)
14009e7dc:     	movl	%r12d, 0x124(%rbp)
14009e7e3:     	movw	%r15w, 0x128(%rbp)
14009e7eb:     	movb	%r14b, 0x12a(%rbp)
14009e7f2:     	movb	%bl, 0x12b(%rbp)
14009e7f8:     	movd	%xmm6, %edi
14009e7fc:     	movd	%xmm6, 0x12c(%rbp)
14009e804:     	leaq	0x110(%rbp), %rdx
14009e80b:     	movq	%rsi, %rcx
14009e80e:     	callq	0x1402161e0 <.text+0x2151e0>
14009e813:     	xorps	%xmm0, %xmm0
14009e816:     	movaps	%xmm0, 0xf0(%rbp)
14009e81d:     	movb	$0x0, 0x132(%rbp)
14009e824:     	movw	%di, 0x130(%rbp)
14009e82b:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009e834:     	movq	$0x0, 0x133(%rbp)
14009e83f:     	movq	$0x8, 0x110(%rbp)
14009e84a:     	movq	$0x0, 0x118(%rbp)
14009e855:     	movq	$0x1, 0x120(%rbp)
14009e860:     	movq	$0x0, 0x128(%rbp)
14009e86b:     	leaq	0xd0(%rbp), %rcx
14009e872:     	leaq	0x110(%rbp), %rdx
14009e879:     	leaq	0xf0(%rbp), %r8
14009e880:     	movl	$0x10, %r9d
14009e886:     	callq	0x140111d70 <.text+0x110d70>
14009e88b:     	cmpb	$0x0, 0xd0(%rbp)
14009e892:     	jne	0x14009e93f <.text+0x9d93f>
14009e898:     	movq	0xd8(%rbp), %rdi
14009e89f:     	movaps	0xe0(%rbp), %xmm0
14009e8a6:     	movups	%xmm0, 0xa8(%rbp)
14009e8ad:     	movl	%r13d, 0xb8(%rbp)
14009e8b4:     	movl	%r12d, 0xbc(%rbp)
14009e8bb:     	movw	%r15w, 0xc0(%rbp)
14009e8c3:     	movb	%r14b, 0xc2(%rbp)
14009e8ca:     	movb	%bl, 0xc3(%rbp)
14009e8d0:     	movd	%xmm6, 0xc4(%rbp)
14009e8d8:     	movq	0x148(%rbp), %rax
14009e8df:     	movq	%rax, 0xc8(%rbp)
14009e8e6:     	cmpq	$0x11, %rdi
14009e8ea:     	jae	0x14009e95c <.text+0x9d95c>
14009e8ec:     	testq	%rdi, %rdi
14009e8ef:     	je	0x14009e92d <.text+0x9d92d>
14009e8f1:     	movw	%di, -0x5e(%rbp)
14009e8f5:     	leaq	-0x5c(%rbp), %rbx
14009e8f9:     	movl	$0x100, %r8d            # imm = 0x100
14009e8ff:     	subq	%rdi, %r8
14009e902:     	leaq	(%rdi,%rbp), %rcx
14009e906:     	addq	$-0x5c, %rcx
14009e90a:     	xorl	%edx, %edx
14009e90c:     	callq	0x140250d72 <.text+0x24fd72>
14009e911:     	leaq	0xf0(%rbp), %rdx
14009e918:     	movq	%rbx, %rcx
14009e91b:     	movq	%rdi, %r8
14009e91e:     	callq	0x140250d60 <.text+0x24fd60>
14009e923:     	movw	$0x1, %ax
14009e927:     	jmp	0x14009e92f <.text+0x9d92f>
14009e929:     	xorl	%eax, %eax
14009e92b:     	jmp	0x14009e941 <.text+0x9d941>
14009e92d:     	xorl	%eax, %eax
14009e92f:     	movw	%ax, -0x60(%rbp)
14009e933:     	leaq	-0x60(%rbp), %rdx
14009e937:     	movq	%rsi, %rcx
14009e93a:     	callq	0x140215ea0 <.text+0x214ea0>
14009e93f:     	movb	$0x1, %al
14009e941:     	movaps	0x150(%rbp), %xmm6
14009e948:     	addq	$0x1e8, %rsp            # imm = 0x1E8
14009e94f:     	popq	%rbx
14009e950:     	popq	%rdi
14009e951:     	popq	%rsi
14009e952:     	popq	%r12
14009e954:     	popq	%r13
14009e956:     	popq	%r14
14009e958:     	popq	%r15
14009e95a:     	popq	%rbp
14009e95b:     	retq
14009e95c:     	leaq	0x1ca245(%rip), %r9     # 0x140268ba8
14009e963:     	movl	$0x10, %r8d
14009e969:     	xorl	%ecx, %ecx
14009e96b:     	movq	%rdi, %rdx
14009e96e:     	callq	0x1402517f0 <.text+0x2507f0>
14009e973:     	ud2

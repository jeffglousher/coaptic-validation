from pathlib import Path
import subprocess, json, os, time, hashlib, statistics, math, psutil
r=Path(__file__).resolve().parent
assert not (r/'result.json').exists()
cells=[(mode,size) for mode in ['sync','async'] for size in [1024,16384]]
method={'purpose':'Diagnostic only, no production qualification or repeated acceptance hypothesis','sources':{'A':'bd63199b652193b4c0a882e5840e72d992cf1362','B':'42c823463b1d7eac5cca31df58e1dac7b243d610'},'cells':cells,'security':'unprotected','storage':'Service allocated, unchanged64 replay rows','operations':1024,'warmup':128,'pairs':16,'orders':['AB','BA','BA','AB']*4,'cpu':0,'phases':['store','expiry','lookup'],'counter':'Existing fixture QueryThreadCycleTime passed as a safe function pointer; RAII inclusive phase intervals; client tables excluded by64-row capacity','limits':'Counts and phase sums include128 warmups; outer App samples exclude warmup. Clock/call overhead retained. Do not sum potentially nested phase costs or infer uninstrumented CPU shares. Compiler/code-placement and measurement overhead perturb execution. No replacement samples. Original black_box field denotes retained optimizer barriers, not absence of diagnostic instrumentation.','empty_intervals':4096,'binaries':{a:hashlib.sha256((r/a/'dispatch-probe.exe').read_bytes()).hexdigest() for a in 'AB'}}
(r/'METHOD.json').write_text(json.dumps(method,indent=2)+'\n')
rows=[];events=[];proc=psutil.Process();affinity=proc.cpu_affinity();proc.cpu_affinity([0]);started=time.monotonic()
try:
    for pair,order in enumerate(method['orders']):
        for mode,size in cells:
            values={}
            for arm in order:
                env=dict(os.environ,COAPTIC_EXPIRY_PROBE='steady');env.pop('COAPTIC_DISPATCH_ASYNC',None)
                if mode=='async':env['COAPTIC_DISPATCH_ASYNC']='1'
                label=f'{pair}-{mode}-{size}-{arm}'
                with (r/(label+'.json')).open('wb') as out,(r/(label+'.stderr')).open('wb') as err:
                    child=subprocess.run([str(r/arm/'dispatch-probe.exe'),'1024','unprotected','--service-allocated',str(size)],env=env,stdout=out,stderr=err,timeout=15)
                events.append({'label':label,'exit_code':child.returncode});assert child.returncode==0
                v=json.loads((r/(label+'.json')).read_bytes())
                assert v['operations']==1024 and v['verified']==1152 and v['server_capacities']['dedup']==64
                assert v['server_poll_counts']==[size//1024]*1024
                assert len(v['phase_cost_including_warmup'])==3
                values[arm]=v
            row={'pair':pair,'mode':mode,'payload':size,'phases':{}}
            for i,name in enumerate(method['phases']):
                a,b=[values[arm]['phase_cost_including_warmup'][i] for arm in 'AB']
                assert a[1]==b[1] and a[1]>0
                row['phases'][name]={'calls':a[1],'A_cycles_per_call':a[0]/a[1],'B_cycles_per_call':b[0]/b[1],'ratio':b[0]/a[0]}
            row['empty_interval_cycles']={a:values[a]['phase_empty_4096_cycles']/4096 for a in 'AB'}
            row['instrumented_App_mean_cycles']={a:statistics.mean(values[a]['server_poll_cpu_cycles_sum']) for a in 'AB'}
            rows.append(row)
    summary=[]
    for mode,size in cells:
        subset=[v for v in rows if v['mode']==mode and v['payload']==size]
        for name in method['phases']:
            summary.append({'mode':mode,'payload':size,'phase':name,'A_mean_cycles_per_call':statistics.mean(v['phases'][name]['A_cycles_per_call'] for v in subset),'B_mean_cycles_per_call':statistics.mean(v['phases'][name]['B_cycles_per_call'] for v in subset),'paired_geomean_ratio':math.exp(statistics.mean(math.log(v['phases'][name]['ratio']) for v in subset)),'calls_per_process':subset[0]['phases'][name]['calls']})
    result={'status':'complete','rows':rows,'summary':summary,'process_exits':events,'seconds':time.monotonic()-started,'acceptance_claim':False}
    (r/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(summary,indent=2))
except BaseException as error:
    (r/'result.json').write_text(json.dumps({'status':'failed','error':str(error),'rows':rows,'process_exits':events},indent=2)+'\n');raise
finally:
    proc.cpu_affinity(affinity)


D:\CoapticCurrent\replay-occupancy-index-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009e980:     	pushq	%rbp
14009e981:     	pushq	%r15
14009e983:     	pushq	%r14
14009e985:     	pushq	%r13
14009e987:     	pushq	%r12
14009e989:     	pushq	%rsi
14009e98a:     	pushq	%rdi
14009e98b:     	pushq	%rbx
14009e98c:     	subq	$0x1e8, %rsp            # imm = 0x1E8
14009e993:     	leaq	0x80(%rsp), %rbp
14009e99b:     	movaps	%xmm6, 0x150(%rbp)
14009e9a2:     	leaq	0x2b320(%rcx), %rax
14009e9a9:     	leaq	0x26720(%rcx), %rsi
14009e9b0:     	leaq	0x26848(%rcx), %r9
14009e9b7:     	movw	$0xffff, %r8w           # imm = 0xFFFF
14009e9bc:     	xorl	%edi, %edi
14009e9be:     	imulq	$0x130, %rdi, %r11      # imm = 0x130
14009e9c5:     	addq	%r9, %r11
14009e9c8:     	movq	%rdi, %r10
14009e9cb:     	jmp	0x14009e9e4 <.text+0x9d9e4>
14009e9cd:     	nopl	(%rax)
14009e9d0:     	incq	%r10
14009e9d3:     	addq	$0x130, %r11            # imm = 0x130
14009e9da:     	cmpq	$0x40, %r10
14009e9de:     	je	0x14009ea93 <.text+0x9da93>
14009e9e4:     	cmpl	$0x0, 0x4c00(%rsi,%r10,4)
14009e9ed:     	je	0x14009e9d0 <.text+0x9d9d0>
14009e9ef:     	movzwl	-0x128(%r11), %edx
14009e9f7:     	cmpw	$-0x1, %dx
14009e9fb:     	je	0x14009e9d0 <.text+0x9d9d0>
14009e9fd:     	movq	(%r11), %rdi
14009ea00:     	cmpw	$0x2, %dx
14009ea04:     	setne	%dl
14009ea07:     	testq	%rdi, %rdi
14009ea0a:     	sete	%bl
14009ea0d:     	orb	%dl, %bl
14009ea0f:     	cmpb	$0x1, %bl
14009ea12:     	je	0x14009e9d0 <.text+0x9d9d0>
14009ea14:     	cmpw	$-0x1, %r8w
14009ea19:     	je	0x14009ea30 <.text+0x9da30>
14009ea1b:     	cmpq	0x140(%rbp), %rdi
14009ea22:     	jb	0x14009ea30 <.text+0x9da30>
14009ea24:     	leaq	0x1(%r10), %rdi
14009ea28:     	cmpq	$0x3f, %r10
14009ea2c:     	jb	0x14009e9be <.text+0x9d9be>
14009ea2e:     	jmp	0x14009ea9e <.text+0x9da9e>
14009ea30:     	movd	-0x4(%r11), %xmm6
14009ea36:     	movzbl	-0x5(%r11), %edx
14009ea3b:     	movb	%dl, 0x14f(%rbp)
14009ea41:     	movzbl	-0x6(%r11), %r14d
14009ea46:     	movzwl	-0x8(%r11), %r15d
14009ea4b:     	movl	-0xc(%r11), %r12d
14009ea4f:     	movl	-0x10(%r11), %r13d
14009ea53:     	movq	-0x18(%r11), %rdx
14009ea57:     	movq	%rdx, 0x138(%rbp)
14009ea5e:     	movq	-0x120(%r11), %rdx
14009ea65:     	movq	%rdx, 0x130(%rbp)
14009ea6c:     	movq	-0x20(%r11), %rdx
14009ea70:     	movq	%rdx, 0x128(%rbp)
14009ea77:     	movw	$0x2, %r8w
14009ea7c:     	movq	%rdi, 0x140(%rbp)
14009ea83:     	leaq	0x1(%r10), %rdi
14009ea87:     	cmpq	$0x3f, %r10
14009ea8b:     	jb	0x14009e9be <.text+0x9d9be>
14009ea91:     	jmp	0x14009ea9e <.text+0x9da9e>
14009ea93:     	cmpw	$-0x1, %r8w
14009ea98:     	je	0x14009ecdd <.text+0x9dcdd>
14009ea9e:     	cmpw	$0x2, %r8w
14009eaa3:     	movq	0x130(%rbp), %r9
14009eaaa:     	jne	0x14009eb05 <.text+0x9db05>
14009eaac:     	cmpq	$0x1f, %r9
14009eab0:     	ja	0x14009eb05 <.text+0x9db05>
14009eab2:     	leaq	0x37400(%rcx), %r8
14009eab9:     	cmpb	$0x1, (%r8,%r9)
14009eabe:     	jne	0x14009eb05 <.text+0x9db05>
14009eac0:     	cmpb	$0x0, 0x37420(%rcx,%r9)
14009eac9:     	jne	0x14009eb05 <.text+0x9db05>
14009eacb:     	movb	$0x0, 0x37400(%rcx,%r9)
14009ead4:     	decq	0x37448(%rcx)
14009eadb:     	movq	$0x0, 0x432d0(%rcx,%r9,8)
14009eae7:     	leaq	(%r9,%r9,8), %rdx
14009eaeb:     	leaq	(%rdx,%rdx,2), %rdx
14009eaef:     	addq	%r9, %rdx
14009eaf2:     	movb	$0x2, 0x36a(%r8,%rdx)
14009eafb:     	leaq	(%r9,%r9,2), %rdx
14009eaff:     	movb	$0x2, 0x5d(%r8,%rdx,8)
14009eb05:     	movd	%xmm6, %edx
14009eb09:     	movzwl	%dx, %r9d
14009eb0d:     	addl	$0x2, %r9d
14009eb11:     	xorl	%r8d, %r8d
14009eb14:     	movzbl	0x14f(%rbp), %ebx
14009eb1b:     	movq	0x128(%rbp), %rdi
14009eb22:     	jmp	0x14009eb41 <.text+0x9db41>
14009eb24:     	nopw	%cs:(%rax,%rax)
14009eb30:     	addq	$0x4, %rax
14009eb34:     	addq	$0x4c, %r8
14009eb38:     	cmpq	$0x1300, %r8            # imm = 0x1300
14009eb3f:     	je	0x14009ebbd <.text+0x9dbbd>
14009eb41:     	cmpl	%r9d, (%rax)
14009eb44:     	jne	0x14009eb30 <.text+0x9db30>
14009eb46:     	cmpw	$-0x1, 0x26720(%rcx,%r8,4)
14009eb50:     	je	0x14009eb30 <.text+0x9db30>
14009eb52:     	cmpw	%dx, 0x26844(%rcx,%r8,4)
14009eb5b:     	jne	0x14009eb30 <.text+0x9db30>
14009eb5d:     	cmpl	%r13d, 0x26838(%rcx,%r8,4)
14009eb65:     	jne	0x14009eb30 <.text+0x9db30>
14009eb67:     	cmpl	%r12d, 0x2683c(%rcx,%r8,4)
14009eb6f:     	jne	0x14009eb30 <.text+0x9db30>
14009eb71:     	cmpw	%r15w, 0x26840(%rcx,%r8,4)
14009eb7a:     	jne	0x14009eb30 <.text+0x9db30>
14009eb7c:     	cmpb	%r14b, 0x26842(%rcx,%r8,4)
14009eb84:     	jne	0x14009eb30 <.text+0x9db30>
14009eb86:     	movq	0x26828(%rcx,%r8,4), %r10
14009eb8e:     	xorq	%rdi, %r10
14009eb91:     	movq	0x26830(%rcx,%r8,4), %r11
14009eb99:     	xorq	0x138(%rbp), %r11
14009eba0:     	orq	%r10, %r11
14009eba3:     	jne	0x14009eb30 <.text+0x9db30>
14009eba5:     	movl	$0x0, (%rax)
14009ebab:     	decq	0x2b428(%rcx)
14009ebb2:     	movw	$0xffff, 0x26720(%rcx,%r8,4) # imm = 0xFFFF
14009ebbd:     	xorps	%xmm0, %xmm0
14009ebc0:     	movaps	%xmm0, 0x110(%rbp)
14009ebc7:     	movb	$0x0, 0xf2(%rbp)
14009ebce:     	movw	%dx, 0xf0(%rbp)
14009ebd5:     	movw	$0x200, 0xfb(%rbp)      # imm = 0x200
14009ebde:     	movq	$0x0, 0xf3(%rbp)
14009ebe9:     	movq	$0x8, 0xd0(%rbp)
14009ebf4:     	movq	$0x0, 0xd8(%rbp)
14009ebff:     	movq	$0x1, 0xe0(%rbp)
14009ec0a:     	movq	$0x0, 0xe8(%rbp)
14009ec15:     	leaq	0x100(%rbp), %rcx
14009ec1c:     	leaq	0xd0(%rbp), %rdx
14009ec23:     	leaq	0x110(%rbp), %r8
14009ec2a:     	movl	$0x10, %r9d
14009ec30:     	callq	0x140111d70 <.text+0x110d70>
14009ec35:     	cmpb	$0x0, 0x100(%rbp)
14009ec3c:     	jne	0x14009ecf3 <.text+0x9dcf3>
14009ec42:     	movq	%rdi, %rax
14009ec45:     	movq	0x108(%rbp), %rdi
14009ec4c:     	movq	%rax, 0xa8(%rbp)
14009ec53:     	movq	0x138(%rbp), %rax
14009ec5a:     	movq	%rax, 0xb0(%rbp)
14009ec61:     	movl	%r13d, 0xb8(%rbp)
14009ec68:     	movl	%r12d, 0xbc(%rbp)
14009ec6f:     	movw	%r15w, 0xc0(%rbp)
14009ec77:     	movb	%r14b, 0xc2(%rbp)
14009ec7e:     	movb	%bl, 0xc3(%rbp)
14009ec84:     	movd	%xmm6, 0xc4(%rbp)
14009ec8c:     	movq	0x140(%rbp), %rax
14009ec93:     	movq	%rax, 0xc8(%rbp)
14009ec9a:     	cmpq	$0x11, %rdi
14009ec9e:     	jae	0x14009ed10 <.text+0x9dd10>
14009eca0:     	testq	%rdi, %rdi
14009eca3:     	je	0x14009ece1 <.text+0x9dce1>
14009eca5:     	movw	%di, -0x5e(%rbp)
14009eca9:     	leaq	-0x5c(%rbp), %rbx
14009ecad:     	movl	$0x100, %r8d            # imm = 0x100
14009ecb3:     	subq	%rdi, %r8
14009ecb6:     	leaq	(%rdi,%rbp), %rcx
14009ecba:     	addq	$-0x5c, %rcx
14009ecbe:     	xorl	%edx, %edx
14009ecc0:     	callq	0x140250d72 <.text+0x24fd72>
14009ecc5:     	leaq	0x110(%rbp), %rdx
14009eccc:     	movq	%rbx, %rcx
14009eccf:     	movq	%rdi, %r8
14009ecd2:     	callq	0x140250d60 <.text+0x24fd60>
14009ecd7:     	movw	$0x1, %ax
14009ecdb:     	jmp	0x14009ece3 <.text+0x9dce3>
14009ecdd:     	xorl	%eax, %eax
14009ecdf:     	jmp	0x14009ecf5 <.text+0x9dcf5>
14009ece1:     	xorl	%eax, %eax
14009ece3:     	movw	%ax, -0x60(%rbp)
14009ece7:     	leaq	-0x60(%rbp), %rdx
14009eceb:     	movq	%rsi, %rcx
14009ecee:     	callq	0x140215c60 <.text+0x214c60>
14009ecf3:     	movb	$0x1, %al
14009ecf5:     	movaps	0x150(%rbp), %xmm6
14009ecfc:     	addq	$0x1e8, %rsp            # imm = 0x1E8
14009ed03:     	popq	%rbx
14009ed04:     	popq	%rdi
14009ed05:     	popq	%rsi
14009ed06:     	popq	%r12
14009ed08:     	popq	%r13
14009ed0a:     	popq	%r14
14009ed0c:     	popq	%r15
14009ed0e:     	popq	%rbp
14009ed0f:     	retq
14009ed10:     	leaq	0x1c9e91(%rip), %r9     # 0x140268ba8
14009ed17:     	movl	$0x10, %r8d
14009ed1d:     	xorl	%ecx, %ecx
14009ed1f:     	movq	%rdi, %rdx
14009ed22:     	callq	0x1402517f0 <.text+0x2507f0>
14009ed27:     	ud2


D:\CoapticCurrent\replay-occupancy-index-20261106\B\dispatch-probe.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14009e2e0:     	pushq	%rbp
14009e2e1:     	pushq	%r15
14009e2e3:     	pushq	%r14
14009e2e5:     	pushq	%r13
14009e2e7:     	pushq	%r12
14009e2e9:     	pushq	%rsi
14009e2ea:     	pushq	%rdi
14009e2eb:     	pushq	%rbx
14009e2ec:     	subq	$0x1e8, %rsp            # imm = 0x1E8
14009e2f3:     	leaq	0x80(%rsp), %rbp
14009e2fb:     	movaps	%xmm6, 0x150(%rbp)
14009e302:     	leaq	0x528(%rcx), %rsi
14009e309:     	leaq	0x650(%rcx), %r8
14009e310:     	movw	$0xffff, %dx            # imm = 0xFFFF
14009e314:     	xorl	%r11d, %r11d
14009e317:     	imulq	$0x130, %r11, %r10      # imm = 0x130
14009e31e:     	addq	%r8, %r10
14009e321:     	movq	%r11, %r9
14009e324:     	jmp	0x14009e344 <.text+0x9d344>
14009e326:     	nopw	%cs:(%rax,%rax)
14009e330:     	incq	%r9
14009e333:     	addq	$0x130, %r10            # imm = 0x130
14009e33a:     	cmpq	$0x4, %r9
14009e33e:     	je	0x14009e405 <.text+0x9d405>
14009e344:     	cmpl	$0x0, 0x4c0(%rsi,%r9,4)
14009e34d:     	je	0x14009e330 <.text+0x9d330>
14009e34f:     	movzwl	-0x128(%r10), %edi
14009e357:     	cmpw	$-0x1, %di
14009e35b:     	je	0x14009e330 <.text+0x9d330>
14009e35d:     	movq	(%r10), %r11
14009e360:     	cmpw	$0x2, %di
14009e364:     	setne	%dil
14009e368:     	testq	%r11, %r11
14009e36b:     	movl	%r13d, %eax
14009e36e:     	movl	%r12d, %r13d
14009e371:     	movl	%r15d, %r12d
14009e374:     	movl	%r14d, %r15d
14009e377:     	movl	%ebx, %r14d
14009e37a:     	sete	%bl
14009e37d:     	orb	%dil, %bl
14009e380:     	cmpb	$0x1, %bl
14009e383:     	movl	%r14d, %ebx
14009e386:     	movl	%r15d, %r14d
14009e389:     	movl	%r12d, %r15d
14009e38c:     	movl	%r13d, %r12d
14009e38f:     	movl	%eax, %r13d
14009e392:     	je	0x14009e330 <.text+0x9d330>
14009e394:     	cmpw	$-0x1, %dx
14009e398:     	je	0x14009e3b3 <.text+0x9d3b3>
14009e39a:     	cmpq	0x148(%rbp), %r11
14009e3a1:     	jb	0x14009e3b3 <.text+0x9d3b3>
14009e3a3:     	leaq	0x1(%r9), %r11
14009e3a7:     	cmpq	$0x3, %r9
14009e3ab:     	jb	0x14009e317 <.text+0x9d317>
14009e3b1:     	jmp	0x14009e40f <.text+0x9d40f>
14009e3b3:     	movq	-0x120(%r10), %rax
14009e3ba:     	movq	%rax, 0x108(%rbp)
14009e3c1:     	movd	-0x4(%r10), %xmm6
14009e3c7:     	movzbl	-0x5(%r10), %ebx
14009e3cc:     	movzbl	-0x6(%r10), %r14d
14009e3d1:     	movzwl	-0x8(%r10), %r15d
14009e3d6:     	movl	-0xc(%r10), %r12d
14009e3da:     	movl	-0x10(%r10), %r13d
14009e3de:     	movups	-0x20(%r10), %xmm0
14009e3e3:     	movaps	%xmm0, 0xe0(%rbp)
14009e3ea:     	movw	$0x2, %dx
14009e3ee:     	movq	%r11, 0x148(%rbp)
14009e3f5:     	leaq	0x1(%r9), %r11
14009e3f9:     	cmpq	$0x3, %r9
14009e3fd:     	jb	0x14009e317 <.text+0x9d317>
14009e403:     	jmp	0x14009e40f <.text+0x9d40f>
14009e405:     	cmpw	$-0x1, %dx
14009e409:     	je	0x14009e5d9 <.text+0x9d5d9>
14009e40f:     	cmpw	$0x2, %dx
14009e413:     	movq	0x108(%rbp), %rax
14009e41a:     	jne	0x14009e477 <.text+0x9d477>
14009e41c:     	cmpq	$0x1, %rax
14009e420:     	ja	0x14009e477 <.text+0x9d477>
14009e422:     	cmpb	$0x1, 0x1e48(%rcx,%rax)
14009e42a:     	jne	0x14009e477 <.text+0x9d477>
14009e42c:     	cmpb	$0x0, 0x1e4a(%rcx,%rax)
14009e434:     	jne	0x14009e477 <.text+0x9d477>
14009e436:     	movb	$0x0, 0x1e48(%rcx,%rax)
14009e43e:     	decq	0x1e40(%rcx)
14009e445:     	leaq	0x14c0(%rcx), %rdx
14009e44c:     	movq	$0x0, 0x1dc0(%rcx,%rax,8)
14009e458:     	leaq	(%rax,%rax,8), %rcx
14009e45c:     	leaq	(%rcx,%rcx,2), %rcx
14009e460:     	addq	%rax, %rcx
14009e463:     	movb	$0x2, 0x95a(%rdx,%rcx)
14009e46b:     	leaq	(%rax,%rax,2), %rax
14009e46f:     	movb	$0x2, 0x91d(%rdx,%rax,8)
14009e477:     	movaps	0xe0(%rbp), %xmm0
14009e47e:     	movaps	%xmm0, 0x110(%rbp)
14009e485:     	movl	%r13d, 0x120(%rbp)
14009e48c:     	movl	%r12d, 0x124(%rbp)
14009e493:     	movw	%r15w, 0x128(%rbp)
14009e49b:     	movb	%r14b, 0x12a(%rbp)
14009e4a2:     	movb	%bl, 0x12b(%rbp)
14009e4a8:     	movd	%xmm6, %edi
14009e4ac:     	movd	%xmm6, 0x12c(%rbp)
14009e4b4:     	leaq	0x110(%rbp), %rdx
14009e4bb:     	movq	%rsi, %rcx
14009e4be:     	callq	0x1402161e0 <.text+0x2151e0>
14009e4c3:     	xorps	%xmm0, %xmm0
14009e4c6:     	movaps	%xmm0, 0xf0(%rbp)
14009e4cd:     	movb	$0x0, 0x132(%rbp)
14009e4d4:     	movw	%di, 0x130(%rbp)
14009e4db:     	movw	$0x200, 0x13b(%rbp)     # imm = 0x200
14009e4e4:     	movq	$0x0, 0x133(%rbp)
14009e4ef:     	movq	$0x8, 0x110(%rbp)
14009e4fa:     	movq	$0x0, 0x118(%rbp)
14009e505:     	movq	$0x1, 0x120(%rbp)
14009e510:     	movq	$0x0, 0x128(%rbp)
14009e51b:     	leaq	0xd0(%rbp), %rcx
14009e522:     	leaq	0x110(%rbp), %rdx
14009e529:     	leaq	0xf0(%rbp), %r8
14009e530:     	movl	$0x10, %r9d
14009e536:     	callq	0x140111d70 <.text+0x110d70>
14009e53b:     	cmpb	$0x0, 0xd0(%rbp)
14009e542:     	jne	0x14009e5ef <.text+0x9d5ef>
14009e548:     	movq	0xd8(%rbp), %rdi
14009e54f:     	movaps	0xe0(%rbp), %xmm0
14009e556:     	movups	%xmm0, 0xa8(%rbp)
14009e55d:     	movl	%r13d, 0xb8(%rbp)
14009e564:     	movl	%r12d, 0xbc(%rbp)
14009e56b:     	movw	%r15w, 0xc0(%rbp)
14009e573:     	movb	%r14b, 0xc2(%rbp)
14009e57a:     	movb	%bl, 0xc3(%rbp)
14009e580:     	movd	%xmm6, 0xc4(%rbp)
14009e588:     	movq	0x148(%rbp), %rax
14009e58f:     	movq	%rax, 0xc8(%rbp)
14009e596:     	cmpq	$0x11, %rdi
14009e59a:     	jae	0x14009e60c <.text+0x9d60c>
14009e59c:     	testq	%rdi, %rdi
14009e59f:     	je	0x14009e5dd <.text+0x9d5dd>
14009e5a1:     	movw	%di, -0x5e(%rbp)
14009e5a5:     	leaq	-0x5c(%rbp), %rbx
14009e5a9:     	movl	$0x100, %r8d            # imm = 0x100
14009e5af:     	subq	%rdi, %r8
14009e5b2:     	leaq	(%rdi,%rbp), %rcx
14009e5b6:     	addq	$-0x5c, %rcx
14009e5ba:     	xorl	%edx, %edx
14009e5bc:     	callq	0x140250d72 <.text+0x24fd72>
14009e5c1:     	leaq	0xf0(%rbp), %rdx
14009e5c8:     	movq	%rbx, %rcx
14009e5cb:     	movq	%rdi, %r8
14009e5ce:     	callq	0x140250d60 <.text+0x24fd60>
14009e5d3:     	movw	$0x1, %ax
14009e5d7:     	jmp	0x14009e5df <.text+0x9d5df>
14009e5d9:     	xorl	%eax, %eax
14009e5db:     	jmp	0x14009e5f1 <.text+0x9d5f1>
14009e5dd:     	xorl	%eax, %eax
14009e5df:     	movw	%ax, -0x60(%rbp)
14009e5e3:     	leaq	-0x60(%rbp), %rdx
14009e5e7:     	movq	%rsi, %rcx
14009e5ea:     	callq	0x140215ea0 <.text+0x214ea0>
14009e5ef:     	movb	$0x1, %al
14009e5f1:     	movaps	0x150(%rbp), %xmm6
14009e5f8:     	addq	$0x1e8, %rsp            # imm = 0x1E8
14009e5ff:     	popq	%rbx
14009e600:     	popq	%rdi
14009e601:     	popq	%rsi
14009e602:     	popq	%r12
14009e604:     	popq	%r13
14009e606:     	popq	%r14
14009e608:     	popq	%r15
14009e60a:     	popq	%rbp
14009e60b:     	retq
14009e60c:     	leaq	0x1ca595(%rip), %r9     # 0x140268ba8
14009e613:     	movl	$0x10, %r8d
14009e619:     	xorl	%ecx, %ecx
14009e61b:     	movq	%rdi, %rdx
14009e61e:     	callq	0x1402517f0 <.text+0x2507f0>
14009e623:     	ud2

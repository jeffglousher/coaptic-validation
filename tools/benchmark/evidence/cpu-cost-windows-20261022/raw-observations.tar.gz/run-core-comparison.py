"""Alternating socket-free diagnostic; poll wall time is not process CPU."""
import json
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parent
for window in range(5):
    for security in ("unprotected", "oscore"):
        order = ("baseline", "candidate") if window % 2 == 0 else ("candidate", "baseline")
        for variant in order:
            output = root / f"core-{security}-{window}-{variant}.json"
            with output.open("x", encoding="utf-8") as stream:
                result = subprocess.run([str(root / f"{variant}-core.exe"), "50000", security],
                                        stdout=stream, stderr=subprocess.PIPE, timeout=30)
            if result.returncode:
                raise RuntimeError(result.stderr.decode(errors="replace"))
            data = json.loads(output.read_text())
            print(json.dumps(dict(window=window, security=security, variant=variant,
                                  completed=data["operations"],
                                  mean_poll_ns=sum(data["latencies_ns"])/data["operations"])), flush=True)
        time.sleep(.2)

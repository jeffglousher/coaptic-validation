import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, 'D:/codex-work/coaptic-validation/tools/benchmark')
from native_diagnostic import validate_report

root=Path(__file__).resolve().parent
paths=sorted(root.glob('baseline-spin-*.json'))+sorted(root.glob('candidate-mio-*.json'))
for path in paths:
    report=json.loads(path.read_text())['report']
    validate_report(report,64,10000,'spin',report['security'],2000)
result=dict(passed=True,windows=len(paths),verified_completions=sum(json.loads(p.read_text())['report']['completed'] for p in paths),
    validator_sha256=hashlib.sha256(Path('D:/codex-work/coaptic-validation/tools/benchmark/native_diagnostic.py').read_bytes()).hexdigest())
(root/'cpu-regrade.json').write_text(json.dumps(result)+'\n')
print(json.dumps(result))
